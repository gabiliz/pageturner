import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserClientLinkDrawer.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { isEqual } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { EditDrawer, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { ClientCompanyTree } from "/src/modules/admin/clients/components/index.ts?t=1701096626433";
import { userClientQueryService } from "/src/modules/admin/users/services/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
const UserClientLinkDrawer = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    user
  } = props;
  const theme = useTheme();
  const {
    data: userClients,
    isLoading
  } = userClientQueryService.useFindAll(user.id);
  const {
    mutateAsync: update,
    isLoading: isUpdating
  } = userClientQueryService.useUpdate(user.id);
  const [selection, setSelection] = useState([]);
  const saveUserClient = useCallback(async () => {
    const userClient = selection.map((rel) => {
      return {
        usuarioId: user.id,
        clienteId: rel.clienteId,
        empresas: selection.map((rel2) => rel2.clienteId === rel.clienteId && {
          empresaId: rel2.empresaId
        }).filter((comp) => comp !== false)
      };
    });
    const seen = /* @__PURE__ */ new Set();
    const userClientFiltered = userClient.filter((el) => {
      const duplicate = seen.has(el.clienteId);
      seen.add(el.clienteId);
      return !duplicate;
    });
    await update(userClientFiltered);
    onDismiss();
  }, [user, selection, update]);
  useEffect(() => {
    if (userClients) {
      const relationships = userClients.reduce((result, client) => {
        const companies = client.empresas;
        const clientCompanies = companies.map(({
          empresaId
        }) => ({
          empresaId,
          clienteId: client.clienteId
        }));
        return [...result, ...clientCompanies];
      }, []);
      setSelection((selection2) => {
        if (!isEqual(selection2, relationships)) {
          return relationships;
        }
        return selection2;
      });
    }
  }, [userClients]);
  return /* @__PURE__ */ jsxDEV(EditDrawer, { title: "Clientes", isOpen, onDismiss, onSave: saveUserClient, disabled: isLoading || isUpdating, loading: isUpdating, children: [
    isLoading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx",
      lineNumber: 83,
      columnNumber: 21
    }, this),
    !isLoading && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Text, { variant: "medium", styles: {
        root: {
          color: theme.colors.neutralLight[600],
          marginBottom: theme.spacing.lg
        }
      }, children: "Selecione os clientes que o usuário poderá acessar" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ClientCompanyTree, { selection, onSelect: setSelection }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx",
        lineNumber: 93,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx",
      lineNumber: 84,
      columnNumber: 22
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
};
_s(UserClientLinkDrawer, "RsJkpIkf8XkFYqZnLpKRXk9dAtI=", false, function() {
  return [useTheme, userClientQueryService.useFindAll, userClientQueryService.useUpdate];
});
_c = UserClientLinkDrawer;
export default UserClientLinkDrawer;
var _c;
$RefreshReg$(_c, "UserClientLinkDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserClientLinkDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEZRLFNBRWEsVUFGYjs7Ozs7Ozs7Ozs7Ozs7OztBQTVGUixTQUFhQSxVQUFVQyxhQUFhQyxpQkFBaUI7QUFDckQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFlBQVlDLHFCQUFxQjtBQUUxQyxTQUFTQyx5QkFBeUI7QUFFbEMsU0FBU0MsOEJBQThCO0FBRXZDLFNBQVNDLGdCQUFnQjtBQVN6QixNQUFNQyx1QkFBdURDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBV0M7QUFBQUEsRUFBSyxJQUFJSjtBQUVwQyxRQUFNSyxRQUFRUCxTQUFTO0FBQ3ZCLFFBQU07QUFBQSxJQUFFUSxNQUFNQztBQUFBQSxJQUFhQztBQUFBQSxFQUFVLElBQUlYLHVCQUF1QlksV0FBV0wsS0FBS00sRUFBRTtBQUNsRixRQUFNO0FBQUEsSUFBRUMsYUFBYUM7QUFBQUEsSUFBUUosV0FBV0s7QUFBQUEsRUFBVyxJQUFJaEIsdUJBQXVCaUIsVUFBVVYsS0FBS00sRUFBRTtBQUMvRixRQUFNLENBQUNLLFdBQVdDLFlBQVksSUFBSTNCLFNBQXNDLEVBQUU7QUFFMUUsUUFBTTRCLGlCQUFpQjNCLFlBQVksWUFBWTtBQUM3QyxVQUFNNEIsYUFBYUgsVUFBVUksSUFBSUMsU0FBTztBQUN0QyxhQUFPO0FBQUEsUUFDTEMsV0FBV2pCLEtBQUtNO0FBQUFBLFFBQ2hCWSxXQUFXRixJQUFJRTtBQUFBQSxRQUNmQyxVQUFVUixVQUNQSSxJQUFJSyxVQUFRQSxLQUFLRixjQUFjRixJQUFJRSxhQUFhO0FBQUEsVUFBRUcsV0FBV0QsS0FBS0M7QUFBQUEsUUFBVSxDQUFDLEVBQzdFQyxPQUFPQyxVQUFRQSxTQUFTLEtBQUs7QUFBQSxNQUNsQztBQUFBLElBQ0YsQ0FBQztBQUNELFVBQU1DLE9BQU8sb0JBQUlDLElBQUk7QUFDckIsVUFBTUMscUJBQWlEWixXQUFXUSxPQUFPSyxRQUFNO0FBQzdFLFlBQU1DLFlBQVlKLEtBQUtLLElBQUlGLEdBQUdULFNBQVM7QUFDdkNNLFdBQUtNLElBQUlILEdBQUdULFNBQVM7QUFDckIsYUFBTyxDQUFDVTtBQUFBQSxJQUNWLENBQUM7QUFFRCxVQUFNcEIsT0FBT2tCLGtCQUFrQjtBQUMvQjNCLGNBQVU7QUFBQSxFQUNaLEdBQUcsQ0FBQ0MsTUFBTVcsV0FBV0gsTUFBTSxDQUFDO0FBRTVCckIsWUFBVSxNQUFNO0FBQ2QsUUFBSWdCLGFBQWE7QUFDZixZQUFNNEIsZ0JBQTZDNUIsWUFDaEQ2QixPQUNDLENBQUNDLFFBQVFDLFdBQVc7QUFDbEIsY0FBTUMsWUFBWUQsT0FBT2Y7QUFDekIsY0FBTWlCLGtCQUFrQkQsVUFBVXBCLElBQ2hDLENBQUM7QUFBQSxVQUFFTTtBQUFBQSxRQUFVLE9BQU87QUFBQSxVQUNsQkE7QUFBQUEsVUFDQUgsV0FBV2dCLE9BQU9oQjtBQUFBQSxRQUNwQixFQUNGO0FBQ0EsZUFBTyxDQUFDLEdBQUdlLFFBQVEsR0FBR0csZUFBZTtBQUFBLE1BQ3ZDLEdBQ0EsRUFDRjtBQUNGeEIsbUJBQWFELGdCQUFhO0FBQ3hCLFlBQUksQ0FBQ3RCLFFBQVFzQixZQUFXb0IsYUFBYSxHQUFHO0FBQ3RDLGlCQUFPQTtBQUFBQSxRQUNUO0FBQ0EsZUFBT3BCO0FBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ1IsV0FBVyxDQUFDO0FBWWhCLFNBQ0UsdUJBQUMsY0FDQyxPQUFNLFlBQ04sUUFDQSxXQUNBLFFBQVFVLGdCQUNSLFVBQVVULGFBQWFLLFlBQ3ZCLFNBQVNBLFlBRVJMO0FBQUFBLGlCQUNDLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBRWYsQ0FBQ0EsYUFBYSxtQ0FDYjtBQUFBLDZCQUFDLFFBQ0MsU0FBUSxVQUNSLFFBQVE7QUFBQSxRQUNOaUMsTUFBTTtBQUFBLFVBQ0pDLE9BQU9yQyxNQUFNc0MsT0FBT0MsYUFBYSxHQUFHO0FBQUEsVUFDcENDLGNBQWN4QyxNQUFNeUMsUUFBUUM7QUFBQUEsUUFDOUI7QUFBQSxNQUNGLEdBQUUsa0VBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxxQkFDQyxXQUNBLFVBQVUvQixnQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXlCO0FBQUEsU0FkWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JmO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNmLEdBL0ZLRixzQkFBbUQ7QUFBQSxVQUd6Q0QsVUFDMkJELHVCQUF1QlksWUFDVFosdUJBQXVCaUIsU0FBUztBQUFBO0FBQUFrQyxLQUxuRmpEO0FBaUdOLGVBQWVBO0FBQW9CLElBQUFpRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsIlRleHQiLCJpc0VxdWFsIiwiRWRpdERyYXdlciIsIkxvYWRpbmdTY3JlZW4iLCJDbGllbnRDb21wYW55VHJlZSIsInVzZXJDbGllbnRRdWVyeVNlcnZpY2UiLCJ1c2VUaGVtZSIsIlVzZXJDbGllbnRMaW5rRHJhd2VyIiwicHJvcHMiLCJfcyIsImlzT3BlbiIsIm9uRGlzbWlzcyIsInVzZXIiLCJ0aGVtZSIsImRhdGEiLCJ1c2VyQ2xpZW50cyIsImlzTG9hZGluZyIsInVzZUZpbmRBbGwiLCJpZCIsIm11dGF0ZUFzeW5jIiwidXBkYXRlIiwiaXNVcGRhdGluZyIsInVzZVVwZGF0ZSIsInNlbGVjdGlvbiIsInNldFNlbGVjdGlvbiIsInNhdmVVc2VyQ2xpZW50IiwidXNlckNsaWVudCIsIm1hcCIsInJlbCIsInVzdWFyaW9JZCIsImNsaWVudGVJZCIsImVtcHJlc2FzIiwicmVsMiIsImVtcHJlc2FJZCIsImZpbHRlciIsImNvbXAiLCJzZWVuIiwiU2V0IiwidXNlckNsaWVudEZpbHRlcmVkIiwiZWwiLCJkdXBsaWNhdGUiLCJoYXMiLCJhZGQiLCJyZWxhdGlvbnNoaXBzIiwicmVkdWNlIiwicmVzdWx0IiwiY2xpZW50IiwiY29tcGFuaWVzIiwiY2xpZW50Q29tcGFuaWVzIiwicm9vdCIsImNvbG9yIiwiY29sb3JzIiwibmV1dHJhbExpZ2h0IiwibWFyZ2luQm90dG9tIiwic3BhY2luZyIsImxnIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQ2xpZW50TGlua0RyYXdlci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlckNsaWVudExpbmtEcmF3ZXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgaXNFcXVhbCB9IGZyb20gJ2xvZGFzaC1lcydcbmltcG9ydCB7IEVkaXREcmF3ZXIsIExvYWRpbmdTY3JlZW4gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IEFwcERyYXdlclByb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMvZHJhd2VyL0FwcERyYXdlcidcbmltcG9ydCB7IENsaWVudENvbXBhbnlUcmVlIH0gZnJvbSAnLi4vLi4vY2xpZW50cy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgVXNlckNsaWVudENvbXBhbnlDb21tYW5kLCBDbGllbnRDb21wYW55UmVsYXRpb25zaGlwLCBDb21wYW55SWQgfSBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vVXNlckNsaWVudENvbXBhbnknXG5pbXBvcnQgeyB1c2VyQ2xpZW50UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5pbXBvcnQgVXNlciBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vVXNlcidcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuXG5pbnRlcmZhY2UgVXNlckNsaWVudExpbmtEcmF3ZXJQcm9wcyBleHRlbmRzIFBpY2s8XG5BcHBEcmF3ZXJQcm9wcyxcbidpc09wZW4nfCdvbkRpc21pc3MnXG4+IHtcbiAgdXNlcjogUGFydGlhbDxVc2VyPlxufVxuXG5jb25zdCBVc2VyQ2xpZW50TGlua0RyYXdlcjogRkM8VXNlckNsaWVudExpbmtEcmF3ZXJQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBpc09wZW4sIG9uRGlzbWlzcywgdXNlciB9ID0gcHJvcHNcblxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcbiAgY29uc3QgeyBkYXRhOiB1c2VyQ2xpZW50cywgaXNMb2FkaW5nIH0gPSB1c2VyQ2xpZW50UXVlcnlTZXJ2aWNlLnVzZUZpbmRBbGwodXNlci5pZClcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogdXBkYXRlLCBpc0xvYWRpbmc6IGlzVXBkYXRpbmcgfSA9IHVzZXJDbGllbnRRdWVyeVNlcnZpY2UudXNlVXBkYXRlKHVzZXIuaWQpXG4gIGNvbnN0IFtzZWxlY3Rpb24sIHNldFNlbGVjdGlvbl0gPSB1c2VTdGF0ZTxDbGllbnRDb21wYW55UmVsYXRpb25zaGlwW10+KFtdKVxuXG4gIGNvbnN0IHNhdmVVc2VyQ2xpZW50ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXJDbGllbnQgPSBzZWxlY3Rpb24ubWFwKHJlbCA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB1c3VhcmlvSWQ6IHVzZXIuaWQsXG4gICAgICAgIGNsaWVudGVJZDogcmVsLmNsaWVudGVJZCxcbiAgICAgICAgZW1wcmVzYXM6IHNlbGVjdGlvblxuICAgICAgICAgIC5tYXAocmVsMiA9PiByZWwyLmNsaWVudGVJZCA9PT0gcmVsLmNsaWVudGVJZCAmJiB7IGVtcHJlc2FJZDogcmVsMi5lbXByZXNhSWQgfSlcbiAgICAgICAgICAuZmlsdGVyKGNvbXAgPT4gY29tcCAhPT0gZmFsc2UpIGFzIENvbXBhbnlJZFtdLFxuICAgICAgfVxuICAgIH0pXG4gICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQoKVxuICAgIGNvbnN0IHVzZXJDbGllbnRGaWx0ZXJlZDogVXNlckNsaWVudENvbXBhbnlDb21tYW5kW10gPSB1c2VyQ2xpZW50LmZpbHRlcihlbCA9PiB7XG4gICAgICBjb25zdCBkdXBsaWNhdGUgPSBzZWVuLmhhcyhlbC5jbGllbnRlSWQpXG4gICAgICBzZWVuLmFkZChlbC5jbGllbnRlSWQpXG4gICAgICByZXR1cm4gIWR1cGxpY2F0ZVxuICAgIH0pXG5cbiAgICBhd2FpdCB1cGRhdGUodXNlckNsaWVudEZpbHRlcmVkKVxuICAgIG9uRGlzbWlzcygpXG4gIH0sIFt1c2VyLCBzZWxlY3Rpb24sIHVwZGF0ZV0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodXNlckNsaWVudHMpIHtcbiAgICAgIGNvbnN0IHJlbGF0aW9uc2hpcHM6IENsaWVudENvbXBhbnlSZWxhdGlvbnNoaXBbXSA9IHVzZXJDbGllbnRzXG4gICAgICAgIC5yZWR1Y2UoXG4gICAgICAgICAgKHJlc3VsdCwgY2xpZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjb21wYW5pZXMgPSBjbGllbnQuZW1wcmVzYXNcbiAgICAgICAgICAgIGNvbnN0IGNsaWVudENvbXBhbmllcyA9IGNvbXBhbmllcy5tYXA8Q2xpZW50Q29tcGFueVJlbGF0aW9uc2hpcD4oXG4gICAgICAgICAgICAgICh7IGVtcHJlc2FJZCB9KSA9PiAoe1xuICAgICAgICAgICAgICAgIGVtcHJlc2FJZCxcbiAgICAgICAgICAgICAgICBjbGllbnRlSWQ6IGNsaWVudC5jbGllbnRlSWQsXG4gICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgcmV0dXJuIFsuLi5yZXN1bHQsIC4uLmNsaWVudENvbXBhbmllc11cbiAgICAgICAgICB9LFxuICAgICAgICAgIFtdIGFzIENsaWVudENvbXBhbnlSZWxhdGlvbnNoaXBbXSxcbiAgICAgICAgKVxuICAgICAgc2V0U2VsZWN0aW9uKHNlbGVjdGlvbiA9PiB7XG4gICAgICAgIGlmICghaXNFcXVhbChzZWxlY3Rpb24sIHJlbGF0aW9uc2hpcHMpKSB7XG4gICAgICAgICAgcmV0dXJuIHJlbGF0aW9uc2hpcHNcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2VsZWN0aW9uXG4gICAgICB9KVxuICAgIH1cbiAgfSwgW3VzZXJDbGllbnRzXSlcblxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xuICAvLyAgIGlmICh1c2VyQ2xpZW50cykge1xuICAvLyAgICAgY29uc3Qgc2VhcmNoID0gc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpXG4gIC8vICAgICBzZXRGaWx0ZXJlZERhdGEodXNlckNsaWVudHMuZmlsdGVyKChjbGllbnQpID0+IChcbiAgLy8gICAgICAgY2xpZW50Li50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaCkgfHxcbiAgLy8gICAgICAgY2xpZW50LmRlc2NyaWNhby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaCkgfHxcbiAgLy8gICAgICAgKGNsaWVudC5tb2R1bG8gPiAwICYmIE1vZHVsZUVudW1bY2xpZW50Lm1vZHVsb10udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gpKSkpIGFzIFBlbmRlbmN5W10pXG4gIC8vICAgfVxuICAvLyB9LCBbdGV4dEZpbHRlcl0pXG5cbiAgcmV0dXJuIChcbiAgICA8RWRpdERyYXdlclxuICAgICAgdGl0bGU9XCJDbGllbnRlc1wiXG4gICAgICBpc09wZW49e2lzT3Blbn1cbiAgICAgIG9uRGlzbWlzcz17b25EaXNtaXNzfVxuICAgICAgb25TYXZlPXtzYXZlVXNlckNsaWVudH1cbiAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgaXNVcGRhdGluZ31cbiAgICAgIGxvYWRpbmc9e2lzVXBkYXRpbmd9XG4gICAgPlxuICAgICAge2lzTG9hZGluZyAmJiAoXG4gICAgICAgIDxMb2FkaW5nU2NyZWVuIC8+XG4gICAgICApfVxuICAgICAgeyFpc0xvYWRpbmcgJiYgPD5cbiAgICAgICAgPFRleHRcbiAgICAgICAgICB2YXJpYW50PVwibWVkaXVtXCJcbiAgICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgY29sb3I6IHRoZW1lLmNvbG9ycy5uZXV0cmFsTGlnaHRbNjAwXSxcbiAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiB0aGVtZS5zcGFjaW5nLmxnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgU2VsZWNpb25lIG9zIGNsaWVudGVzIHF1ZSBvIHVzdcOhcmlvIHBvZGVyw6EgYWNlc3NhclxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxDbGllbnRDb21wYW55VHJlZVxuICAgICAgICAgIHNlbGVjdGlvbj17c2VsZWN0aW9ufVxuICAgICAgICAgIG9uU2VsZWN0PXtzZXRTZWxlY3Rpb259XG4gICAgICAgIC8+XG4gICAgICA8Lz59XG4gICAgPC9FZGl0RHJhd2VyPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJDbGllbnRMaW5rRHJhd2VyXG4iXX0=