import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/persona/Persona.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/Persona.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Persona as PersonaFluent } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
const Persona = ({
  name,
  ...props
}) => {
  const imageInitials = name.match(/\b\w/g)?.slice(0, 2).join("");
  return /* @__PURE__ */ jsxDEV(PersonaFluent, { imageInitials, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/Persona.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_c = Persona;
export default Persona;
var _c;
$RefreshReg$(_c, "Persona");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/Persona.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7QUFaSiwyQkFBd0JBO0FBQVdDLElBQWE7QUFBUTtBQUFpQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFPekUsTUFBTUQsVUFBNEJBLENBQUM7QUFBQSxFQUFFRTtBQUFBQSxFQUFNLEdBQUdDO0FBQU0sTUFBTTtBQUV4RCxRQUFNQyxnQkFBZ0JGLEtBQUtHLE1BQU0sT0FBTyxHQUFHQyxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxLQUFLLEVBQUU7QUFFOUQsU0FDRSx1QkFBQyxpQkFDQyxlQUNBLEdBQUlKLFNBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVZO0FBR2hCO0FBVUFLLEtBcEJNUjtBQXNCTixlQUFlQTtBQUFPLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQZXJzb25hIiwiUGVyc29uYUZsdWVudCIsIm5hbWUiLCJwcm9wcyIsImltYWdlSW5pdGlhbHMiLCJtYXRjaCIsInNsaWNlIiwiam9pbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGVyc29uYS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9wZXJzb25hL1BlcnNvbmEudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVBlcnNvbmFQcm9wcywgUGVyc29uYSBhcyBQZXJzb25hRmx1ZW50IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcblxuaW50ZXJmYWNlIFBlcnNvbmFQcm9wcyBleHRlbmRzIElQZXJzb25hUHJvcHMge1xuICBuYW1lOiBzdHJpbmdcbn1cblxuY29uc3QgUGVyc29uYTogRkM8UGVyc29uYVByb3BzPiA9ICh7IG5hbWUsIC4uLnByb3BzIH0pID0+IHtcbiAgLy8gY29uc3QgcGVyc29uYVN0eWxlcyA9IHVzZVBpdm90U3R5bGVzKClcbiAgY29uc3QgaW1hZ2VJbml0aWFscyA9IG5hbWUubWF0Y2goL1xcYlxcdy9nKT8uc2xpY2UoMCwgMikuam9pbignJylcblxuICByZXR1cm4gKFxuICAgIDxQZXJzb25hRmx1ZW50XG4gICAgICBpbWFnZUluaXRpYWxzPXtpbWFnZUluaXRpYWxzfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuLy8gY29uc3QgdXNlUGl2b3RTdHlsZXMgPSAoKSA9PiB7XG4vLyAgIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxuXG4vLyAgIGNvbnN0IHBlcnNvbmFTdHlsZXM6IFBhcnRpYWw8SVBlcnNvbmFTdHlsZXM+ID0ge1xuXG4vLyAgIH1cblxuLy8gICByZXR1cm4gcGVyc29uYVN0eWxlc1xuLy8gfVxuXG5leHBvcnQgZGVmYXVsdCBQZXJzb25hXG4iXX0=