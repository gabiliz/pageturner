import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];
import __vite__cjsImport1_reactDom from "/node_modules/.vite/deps/react-dom.js?v=9f90a7ff"; const createPortal = __vite__cjsImport1_reactDom["createPortal"];
export const useDraggableInPortal = () => {
  const element = useRef(document.createElement("div")).current;
  useEffect(() => {
    if (element) {
      element.style.pointerEvents = "none";
      element.style.position = "absolute";
      element.style.height = "100%";
      element.style.width = "100%";
      element.style.top = "0";
      document.body.appendChild(element);
      return () => {
        document.body.removeChild(element);
      };
    }
  }, [element]);
  return (render) => (provided) => {
    const result = render(provided);
    const style = provided.draggableProps.style;
    if (style.position === "fixed") {
      return createPortal(result, element);
    }
    return result;
  };
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRyYWdnYWJsZUluUG9ydGFsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERyYWdnYWJsZVByb3ZpZGVkLCBEcmFnZ2luZ1N0eWxlIH0gZnJvbSAncmVhY3QtYmVhdXRpZnVsLWRuZCdcbmltcG9ydCB7IFJlYWN0RWxlbWVudCwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gJ3JlYWN0LWRvbSdcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1tb2R1bGUtYm91bmRhcnktdHlwZXNcbmV4cG9ydCBjb25zdCB1c2VEcmFnZ2FibGVJblBvcnRhbCA9ICgpID0+IHtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4oZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpLmN1cnJlbnRcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChlbGVtZW50KSB7XG4gICAgICBlbGVtZW50LnN0eWxlLnBvaW50ZXJFdmVudHMgPSAnbm9uZSdcbiAgICAgIGVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnXG4gICAgICBlbGVtZW50LnN0eWxlLmhlaWdodCA9ICcxMDAlJ1xuICAgICAgZWxlbWVudC5zdHlsZS53aWR0aCA9ICcxMDAlJ1xuICAgICAgZWxlbWVudC5zdHlsZS50b3AgPSAnMCdcblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtZW50KVxuXG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW1lbnQpXG4gICAgICB9XG4gICAgfVxuICB9LCBbZWxlbWVudF0pXG5cbiAgcmV0dXJuIChyZW5kZXI6IChwcm92aWRlZDogRHJhZ2dhYmxlUHJvdmlkZWQpID0+IFJlYWN0RWxlbWVudCkgPT4gKHByb3ZpZGVkOiBEcmFnZ2FibGVQcm92aWRlZCkgPT4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSB0ZXN0aW5nLWxpYnJhcnkvcmVuZGVyLXJlc3VsdC1uYW1pbmctY29udmVudGlvblxuICAgIGNvbnN0IHJlc3VsdCA9IHJlbmRlcihwcm92aWRlZClcbiAgICBjb25zdCBzdHlsZSA9IHByb3ZpZGVkLmRyYWdnYWJsZVByb3BzLnN0eWxlIGFzIERyYWdnaW5nU3R5bGVcbiAgICBpZiAoc3R5bGUucG9zaXRpb24gPT09ICdmaXhlZCcpIHtcbiAgICAgIHJldHVybiBjcmVhdGVQb3J0YWwocmVzdWx0LCBlbGVtZW50KVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsU0FBdUIsV0FBVyxjQUFjO0FBQ2hELFNBQVMsb0JBQW9CO0FBR3RCLGFBQU0sdUJBQXVCLE1BQU07QUFDeEMsUUFBTSxVQUFVLE9BQXVCLFNBQVMsY0FBYyxLQUFLLENBQUMsRUFBRTtBQUV0RSxZQUFVLE1BQU07QUFDZCxRQUFJLFNBQVM7QUFDWCxjQUFRLE1BQU0sZ0JBQWdCO0FBQzlCLGNBQVEsTUFBTSxXQUFXO0FBQ3pCLGNBQVEsTUFBTSxTQUFTO0FBQ3ZCLGNBQVEsTUFBTSxRQUFRO0FBQ3RCLGNBQVEsTUFBTSxNQUFNO0FBRXBCLGVBQVMsS0FBSyxZQUFZLE9BQU87QUFFakMsYUFBTyxNQUFNO0FBQ1gsaUJBQVMsS0FBSyxZQUFZLE9BQU87QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQyxPQUFPLENBQUM7QUFFWixTQUFPLENBQUMsV0FBMEQsQ0FBQyxhQUFnQztBQUVqRyxVQUFNLFNBQVMsT0FBTyxRQUFRO0FBQzlCLFVBQU0sUUFBUSxTQUFTLGVBQWU7QUFDdEMsUUFBSSxNQUFNLGFBQWEsU0FBUztBQUM5QixhQUFPLGFBQWEsUUFBUSxPQUFPO0FBQUEsSUFDckM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGOyIsIm5hbWVzIjpbXX0=