import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/tag/Tag.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tag/Tag.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyles, FontWeights, IconButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const memo = __vite__cjsImport4_react["memo"]; const useCallback = __vite__cjsImport4_react["useCallback"]; const useState = __vite__cjsImport4_react["useState"];
import { useThemeColors } from "/src/shared/hooks/index.ts";
const Tag = (props) => {
  _s();
  const styles = useStyles(props);
  const [cursor, setCursor] = useState("default");
  const {
    white
  } = useThemeColors();
  const handleMouseEnter = useCallback(() => {
    if (props.onClick !== void 0) {
      setCursor("pointer");
    }
  }, [props.onClick]);
  const handleMouseLeave = useCallback(() => {
    if (props.onClick !== void 0) {
      setCursor("default");
    }
  }, [props.onClick]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles, onClick: props.onClick, onMouseEnter: handleMouseEnter, onMouseLeave: handleMouseLeave, style: {
    cursor
  }, children: [
    props.text,
    props.onRemove && /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
      iconName: "Cancel",
      styles: {
        root: {
          fontSize: 10
        }
      }
    }, disabled: false, onClick: (ev) => {
      ev.stopPropagation();
      props.onRemove?.();
    }, styles: {
      root: {
        color: props.color ?? white,
        width: 10,
        height: 10,
        marginLeft: 5
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tag/Tag.tsx",
      lineNumber: 38,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tag/Tag.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(Tag, "wIEaWIisIW9c9wfNFl7jSJUbZWU=", false, function() {
  return [useStyles, useThemeColors];
});
_c = Tag;
const useStyles = (props) => {
  _s2();
  const colors = useThemeColors();
  const {
    backgroundColor = colors.blue[600],
    color = colors.white,
    border = "0px"
  } = props;
  return mergeStyles({
    display: "inline-block",
    whiteSpace: "nowrap",
    width: props.width,
    fontSize: props.fontSize ?? "12px",
    fontWeight: FontWeights.semibold,
    backgroundColor,
    color,
    padding: props.padding ?? "3px 8px",
    textAlign: "center",
    border,
    borderRadius: "4px",
    transition: "filter .1s",
    ":hover": {
      filter: props.onClick ? "brightness(0.95)" : void 0
    }
  });
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default _c2 = memo(Tag);
var _c, _c2;
$RefreshReg$(_c, "Tag");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tag/Tag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNROzs7Ozs7Ozs7Ozs7Ozs7O0FBM0NSLFNBQVNBLGFBQWFDLGFBQWFDLGtCQUFrQjtBQUNyRCxTQUFhQyxNQUFvQkMsYUFBYUMsZ0JBQWdCO0FBQzlELFNBQVNDLHNCQUFzQjtBQWMvQixNQUFNQyxNQUFxQkMsV0FBVTtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLFNBQVNDLFVBQVVILEtBQUs7QUFDOUIsUUFBTSxDQUFDSSxRQUFRQyxTQUFTLElBQUlSLFNBQWlCLFNBQVM7QUFDdEQsUUFBTTtBQUFBLElBQUVTO0FBQUFBLEVBQU0sSUFBSVIsZUFBZTtBQUVqQyxRQUFNUyxtQkFBbUJYLFlBQVksTUFBTTtBQUN6QyxRQUFJSSxNQUFNUSxZQUFZQyxRQUFXO0FBQy9CSixnQkFBVSxTQUFTO0FBQUEsSUFDckI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0wsTUFBTVEsT0FBTyxDQUFDO0FBRWxCLFFBQU1FLG1CQUFtQmQsWUFBWSxNQUFNO0FBQ3pDLFFBQUlJLE1BQU1RLFlBQVlDLFFBQVc7QUFDL0JKLGdCQUFVLFNBQVM7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsR0FBRyxDQUFDTCxNQUFNUSxPQUFPLENBQUM7QUFFbEIsU0FDRSx1QkFBQyxTQUNDLFdBQVdOLFFBQ1gsU0FBU0YsTUFBTVEsU0FDZixjQUFjRCxrQkFDZCxjQUFjRyxrQkFDZCxPQUFPO0FBQUEsSUFBRU47QUFBQUEsRUFBZSxHQUV2Qko7QUFBQUEsVUFBTVc7QUFBQUEsSUFDTlgsTUFBTVksWUFDTCx1QkFBQyxjQUNDLFdBQVc7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVlgsUUFBUTtBQUFBLFFBQ05ZLE1BQU07QUFBQSxVQUNKQyxVQUFVO0FBQUEsUUFDWjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLEdBQ0EsVUFBVSxPQUNWLFNBQVVDLFFBQU87QUFDZkEsU0FBR0MsZ0JBQWdCO0FBQ25CakIsWUFBTVksV0FBVztBQUFBLElBQ25CLEdBQ0EsUUFBUTtBQUFBLE1BQ05FLE1BQU07QUFBQSxRQUNKSSxPQUFPbEIsTUFBTWtCLFNBQVNaO0FBQUFBLFFBQ3RCYSxPQUFPO0FBQUEsUUFDUEMsUUFBUTtBQUFBLFFBQ1JDLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRixLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJJO0FBQUEsT0E5QlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNwQixHQXJES0YsS0FBaUI7QUFBQSxVQUNOSSxXQUVHTCxjQUFjO0FBQUE7QUFBQXdCLEtBSDVCdkI7QUF1RE4sTUFBTUksWUFBWUEsQ0FBQ0gsVUFBb0I7QUFBQXVCLE1BQUE7QUFDckMsUUFBTUMsU0FBUzFCLGVBQWU7QUFDOUIsUUFBTTtBQUFBLElBQUUyQixrQkFBa0JELE9BQU9FLEtBQUssR0FBRztBQUFBLElBQUdSLFFBQVFNLE9BQU9sQjtBQUFBQSxJQUFPcUIsU0FBUztBQUFBLEVBQU0sSUFBSTNCO0FBQ3JGLFNBQU9SLFlBQVk7QUFBQSxJQUNqQm9DLFNBQVM7QUFBQSxJQUNUQyxZQUFZO0FBQUEsSUFDWlYsT0FBT25CLE1BQU1tQjtBQUFBQSxJQUNiSixVQUFVZixNQUFNZSxZQUFZO0FBQUEsSUFDNUJlLFlBQVlyQyxZQUFZc0M7QUFBQUEsSUFDeEJOO0FBQUFBLElBQ0FQO0FBQUFBLElBQ0FjLFNBQVNoQyxNQUFNZ0MsV0FBVztBQUFBLElBQzFCQyxXQUFXO0FBQUEsSUFDWE47QUFBQUEsSUFDQU8sY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxJQUNaLFVBQVU7QUFBQSxNQUNSQyxRQUFRcEMsTUFBTVEsVUFBVSxxQkFBcUJDO0FBQUFBLElBQy9DO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ2MsSUFwQktwQixXQUFTO0FBQUEsVUFDRUwsY0FBYztBQUFBO0FBcUIvQixlQUFBdUMsTUFBZTFDLEtBQUtJLEdBQUc7QUFBQyxJQUFBdUIsSUFBQWU7QUFBQUMsYUFBQWhCLElBQUE7QUFBQWdCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlcyIsIkZvbnRXZWlnaHRzIiwiSWNvbkJ1dHRvbiIsIm1lbW8iLCJ1c2VDYWxsYmFjayIsInVzZVN0YXRlIiwidXNlVGhlbWVDb2xvcnMiLCJUYWciLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiY3Vyc29yIiwic2V0Q3Vyc29yIiwid2hpdGUiLCJoYW5kbGVNb3VzZUVudGVyIiwib25DbGljayIsInVuZGVmaW5lZCIsImhhbmRsZU1vdXNlTGVhdmUiLCJ0ZXh0Iiwib25SZW1vdmUiLCJpY29uTmFtZSIsInJvb3QiLCJmb250U2l6ZSIsImV2Iiwic3RvcFByb3BhZ2F0aW9uIiwiY29sb3IiLCJ3aWR0aCIsImhlaWdodCIsIm1hcmdpbkxlZnQiLCJfYyIsIl9zMiIsImNvbG9ycyIsImJhY2tncm91bmRDb2xvciIsImJsdWUiLCJib3JkZXIiLCJkaXNwbGF5Iiwid2hpdGVTcGFjZSIsImZvbnRXZWlnaHQiLCJzZW1pYm9sZCIsInBhZGRpbmciLCJ0ZXh0QWxpZ24iLCJib3JkZXJSYWRpdXMiLCJ0cmFuc2l0aW9uIiwiZmlsdGVyIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGFnLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3RhZy9UYWcudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZXMsIEZvbnRXZWlnaHRzLCBJY29uQnV0dG9uIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMsIG1lbW8sIFJlYWN0RWxlbWVudCwgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZUNvbG9ycyB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5pbnRlcmZhY2UgVGFnUHJvcHMge1xuICB0ZXh0OiBzdHJpbmcgfCBSZWFjdEVsZW1lbnRcbiAgY29sb3I/OiBzdHJpbmdcbiAgYmFja2dyb3VuZENvbG9yPzogc3RyaW5nXG4gIGJvcmRlcj86IHN0cmluZ1xuICBvblJlbW92ZT86ICgpID0+IHZvaWRcbiAgb25DbGljaz86ICgpID0+IHZvaWRcbiAgcGFkZGluZz86IHN0cmluZ1xuICB3aWR0aD86IHN0cmluZ1xuICBmb250U2l6ZT86IHN0cmluZ1xufVxuXG5jb25zdCBUYWc6IEZDPFRhZ1Byb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMocHJvcHMpXG4gIGNvbnN0IFtjdXJzb3IsIHNldEN1cnNvcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdkZWZhdWx0JylcbiAgY29uc3QgeyB3aGl0ZSB9ID0gdXNlVGhlbWVDb2xvcnMoKVxuXG4gIGNvbnN0IGhhbmRsZU1vdXNlRW50ZXIgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHByb3BzLm9uQ2xpY2sgIT09IHVuZGVmaW5lZCkge1xuICAgICAgc2V0Q3Vyc29yKCdwb2ludGVyJylcbiAgICB9XG4gIH0sIFtwcm9wcy5vbkNsaWNrXSlcblxuICBjb25zdCBoYW5kbGVNb3VzZUxlYXZlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChwcm9wcy5vbkNsaWNrICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHNldEN1cnNvcignZGVmYXVsdCcpXG4gICAgfVxuICB9LCBbcHJvcHMub25DbGlja10pXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e3N0eWxlc31cbiAgICAgIG9uQ2xpY2s9e3Byb3BzLm9uQ2xpY2t9XG4gICAgICBvbk1vdXNlRW50ZXI9e2hhbmRsZU1vdXNlRW50ZXJ9XG4gICAgICBvbk1vdXNlTGVhdmU9e2hhbmRsZU1vdXNlTGVhdmV9XG4gICAgICBzdHlsZT17eyBjdXJzb3I6IGN1cnNvciB9fVxuICAgID5cbiAgICAgIHtwcm9wcy50ZXh0fVxuICAgICAge3Byb3BzLm9uUmVtb3ZlICYmXG4gICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgaWNvblByb3BzPXt7XG4gICAgICAgICAgICBpY29uTmFtZTogJ0NhbmNlbCcsXG4gICAgICAgICAgICBzdHlsZXM6IHtcbiAgICAgICAgICAgICAgcm9vdDoge1xuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfX1cbiAgICAgICAgICBkaXNhYmxlZD17ZmFsc2V9XG4gICAgICAgICAgb25DbGljaz17KGV2KSA9PiB7XG4gICAgICAgICAgICBldi5zdG9wUHJvcGFnYXRpb24oKVxuICAgICAgICAgICAgcHJvcHMub25SZW1vdmU/LigpXG4gICAgICAgICAgfX1cbiAgICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgY29sb3I6IHByb3BzLmNvbG9yID8/IHdoaXRlLFxuICAgICAgICAgICAgICB3aWR0aDogMTAsXG4gICAgICAgICAgICAgIGhlaWdodDogMTAsXG4gICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IDUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICB9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKHByb3BzOiBUYWdQcm9wcykgPT4ge1xuICBjb25zdCBjb2xvcnMgPSB1c2VUaGVtZUNvbG9ycygpXG4gIGNvbnN0IHsgYmFja2dyb3VuZENvbG9yID0gY29sb3JzLmJsdWVbNjAwXSwgY29sb3IgPSBjb2xvcnMud2hpdGUsIGJvcmRlciA9ICcwcHgnIH0gPSBwcm9wc1xuICByZXR1cm4gbWVyZ2VTdHlsZXMoe1xuICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxuICAgIHdpZHRoOiBwcm9wcy53aWR0aCxcbiAgICBmb250U2l6ZTogcHJvcHMuZm9udFNpemUgPz8gJzEycHgnLFxuICAgIGZvbnRXZWlnaHQ6IEZvbnRXZWlnaHRzLnNlbWlib2xkLFxuICAgIGJhY2tncm91bmRDb2xvcixcbiAgICBjb2xvcixcbiAgICBwYWRkaW5nOiBwcm9wcy5wYWRkaW5nID8/ICczcHggOHB4JyxcbiAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgIGJvcmRlcjogYm9yZGVyLFxuICAgIGJvcmRlclJhZGl1czogJzRweCcsXG4gICAgdHJhbnNpdGlvbjogJ2ZpbHRlciAuMXMnLFxuICAgICc6aG92ZXInOiB7XG4gICAgICBmaWx0ZXI6IHByb3BzLm9uQ2xpY2sgPyAnYnJpZ2h0bmVzcygwLjk1KScgOiB1bmRlZmluZWQsXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWVtbyhUYWcpXG4iXX0=