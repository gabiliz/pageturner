import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/tooltip/TooltipHost.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tooltip/TooltipHost.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TooltipHost as FluentTooltip } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
const TooltipHost = (props) => {
  return /* @__PURE__ */ jsxDEV(FluentTooltip, { ...props, children: props.children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tooltip/TooltipHost.tsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = TooltipHost;
export default TooltipHost;
var _c;
$RefreshReg$(_c, "TooltipHost");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/tooltip/TooltipHost.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0k7QUFMSiwyQkFBMEI7QUFBaUJBO0FBQXFCO0FBQWlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdqRixNQUFNQyxjQUFzQ0MsV0FBVTtBQUNwRCxTQUNFLHVCQUFDLGlCQUFjLEdBQUlBLE9BQ2hCQSxnQkFBTUMsWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxLQU5LSDtBQVFOLGVBQWVBO0FBQVcsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZsdWVudFRvb2x0aXAiLCJUb29sdGlwSG9zdCIsInByb3BzIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvb2x0aXBIb3N0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3Rvb2x0aXAvVG9vbHRpcEhvc3QudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVRvb2x0aXBIb3N0UHJvcHMsIFRvb2x0aXBIb3N0IGFzIEZsdWVudFRvb2x0aXAgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBUb29sdGlwSG9zdDogRkM8SVRvb2x0aXBIb3N0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEZsdWVudFRvb2x0aXAgey4uLnByb3BzfT5cbiAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICA8L0ZsdWVudFRvb2x0aXA+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgVG9vbHRpcEhvc3RcbiJdfQ==