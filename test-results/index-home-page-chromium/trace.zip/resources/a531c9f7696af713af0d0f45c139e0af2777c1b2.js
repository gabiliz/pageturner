import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/progress/ProgressBar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
const ProgressBar = (props) => {
  _s();
  const {
    percentageValue,
    risk
  } = props;
  const styles = useStyles(risk);
  return /* @__PURE__ */ jsxDEV("progress", { className: styles.progressBar, max: 100, value: percentageValue }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressBar.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_s(ProgressBar, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = ProgressBar;
const useStyles = (props) => {
  _s2();
  const colors = useThemeColors();
  return mergeStyleSets({
    progressBar: {
      color: colors.blue[500],
      fontSize: ".4em",
      width: "100%",
      height: "1.6em",
      background: colors.white,
      borderRadius: "9px",
      overflow: "hidden",
      border: "none",
      appearance: "none",
      "&::-moz-progress-bar": {
        backgroundColor: {
          0: colors.green[300],
          1: colors.yellow[500],
          2: colors.red[500]
        }[props]
      },
      "&::-webkit-progress-value": {
        backgroundColor: {
          0: colors.green[300],
          1: colors.yellow[500],
          2: colors.red[500]
        }[props]
      },
      "&::-webkit-progress-bar": {
        backgroundColor: colors.white
      }
    }
  });
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default ProgressBar;
var _c;
$RefreshReg$(_c, "ProgressBar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaVCxTQUFTQSxzQkFBc0I7QUFFL0IsU0FBU0Msc0JBQXNCO0FBTy9CLE1BQU1DLGNBQXFDQyxXQUFVO0FBQUFDLEtBQUE7QUFDbkQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQWlCQztBQUFBQSxFQUFLLElBQUlIO0FBQ2xDLFFBQU1JLFNBQVNDLFVBQVVGLElBQUk7QUFDN0IsU0FBTyx1QkFBQyxjQUNOLFdBQVdDLE9BQU9FLGFBQ2xCLEtBQUssS0FDTCxPQUFPSixtQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR2tCO0FBRTNCO0FBQUNELEdBUktGLGFBQWlDO0FBQUEsVUFFdEJNLFNBQVM7QUFBQTtBQUFBRSxLQUZwQlI7QUFVTixNQUFNTSxZQUFZQSxDQUFDTCxVQUFpQjtBQUFBUSxNQUFBO0FBQ2xDLFFBQU1DLFNBQVNYLGVBQWU7QUFDOUIsU0FBT0QsZUFBZTtBQUFBLElBQ3BCUyxhQUFhO0FBQUEsTUFDWEksT0FBT0QsT0FBT0UsS0FBSyxHQUFHO0FBQUEsTUFDdEJDLFVBQVU7QUFBQSxNQUNWQyxPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLE1BQ1JDLFlBQVlOLE9BQU9PO0FBQUFBLE1BQ25CQyxjQUFjO0FBQUEsTUFDZEMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFFWix3QkFBd0I7QUFBQSxRQUN0QkMsaUJBQWlCO0FBQUEsVUFDZixHQUFHWixPQUFPYSxNQUFNLEdBQUc7QUFBQSxVQUNuQixHQUFHYixPQUFPYyxPQUFPLEdBQUc7QUFBQSxVQUNwQixHQUFHZCxPQUFPZSxJQUFJLEdBQUc7QUFBQSxRQUNuQixFQUFFeEIsS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLDZCQUE2QjtBQUFBLFFBQzNCcUIsaUJBQWlCO0FBQUEsVUFDZixHQUFHWixPQUFPYSxNQUFNLEdBQUc7QUFBQSxVQUNuQixHQUFHYixPQUFPYyxPQUFPLEdBQUc7QUFBQSxVQUNwQixHQUFHZCxPQUFPZSxJQUFJLEdBQUc7QUFBQSxRQUNuQixFQUFFeEIsS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLDJCQUEyQjtBQUFBLFFBQ3pCcUIsaUJBQWlCWixPQUFPTztBQUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDUixJQWpDS0gsV0FBUztBQUFBLFVBQ0VQLGNBQWM7QUFBQTtBQWtDL0IsZUFBZUM7QUFBVyxJQUFBUTtBQUFBa0IsYUFBQWxCLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsInVzZVRoZW1lQ29sb3JzIiwiUHJvZ3Jlc3NCYXIiLCJwcm9wcyIsIl9zIiwicGVyY2VudGFnZVZhbHVlIiwicmlzayIsInN0eWxlcyIsInVzZVN0eWxlcyIsInByb2dyZXNzQmFyIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJjb2xvciIsImJsdWUiLCJmb250U2l6ZSIsIndpZHRoIiwiaGVpZ2h0IiwiYmFja2dyb3VuZCIsIndoaXRlIiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJib3JkZXIiLCJhcHBlYXJhbmNlIiwiYmFja2dyb3VuZENvbG9yIiwiZ3JlZW4iLCJ5ZWxsb3ciLCJyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9ncmVzc0Jhci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9wcm9ncmVzcy9Qcm9ncmVzc0Jhci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZUNvbG9ycyB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5pbnRlcmZhY2UgUHJvZ3Jlc3NCYXJQcm9wcyB7XG4gIHBlcmNlbnRhZ2VWYWx1ZTogbnVtYmVyXG4gIHJpc2s6IDB8MXwyXG59XG5cbmNvbnN0IFByb2dyZXNzQmFyOiBGQzxQcm9ncmVzc0JhclByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IHBlcmNlbnRhZ2VWYWx1ZSwgcmlzayB9ID0gcHJvcHNcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKHJpc2spXG4gIHJldHVybiA8cHJvZ3Jlc3NcbiAgICBjbGFzc05hbWU9e3N0eWxlcy5wcm9ncmVzc0Jhcn1cbiAgICBtYXg9ezEwMH1cbiAgICB2YWx1ZT17cGVyY2VudGFnZVZhbHVlfVxuICAvPlxufVxuXG5jb25zdCB1c2VTdHlsZXMgPSAocHJvcHM6IDB8MXwyKSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcbiAgICBwcm9ncmVzc0Jhcjoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ibHVlWzUwMF0sXG4gICAgICBmb250U2l6ZTogJy40ZW0nLFxuICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgIGhlaWdodDogJzEuNmVtJyxcbiAgICAgIGJhY2tncm91bmQ6IGNvbG9ycy53aGl0ZSxcbiAgICAgIGJvcmRlclJhZGl1czogJzlweCcsXG4gICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgIGFwcGVhcmFuY2U6ICdub25lJyxcblxuICAgICAgJyY6Oi1tb3otcHJvZ3Jlc3MtYmFyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHtcbiAgICAgICAgICAwOiBjb2xvcnMuZ3JlZW5bMzAwXSxcbiAgICAgICAgICAxOiBjb2xvcnMueWVsbG93WzUwMF0sXG4gICAgICAgICAgMjogY29sb3JzLnJlZFs1MDBdLFxuICAgICAgICB9W3Byb3BzXSxcbiAgICAgIH0sXG4gICAgICAnJjo6LXdlYmtpdC1wcm9ncmVzcy12YWx1ZSc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB7XG4gICAgICAgICAgMDogY29sb3JzLmdyZWVuWzMwMF0sXG4gICAgICAgICAgMTogY29sb3JzLnllbGxvd1s1MDBdLFxuICAgICAgICAgIDI6IGNvbG9ycy5yZWRbNTAwXSxcbiAgICAgICAgfVtwcm9wc10sXG4gICAgICB9LFxuICAgICAgJyY6Oi13ZWJraXQtcHJvZ3Jlc3MtYmFyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy53aGl0ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgUHJvZ3Jlc3NCYXJcbiJdfQ==