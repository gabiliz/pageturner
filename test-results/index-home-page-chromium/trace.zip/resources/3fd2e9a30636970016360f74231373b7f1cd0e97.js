import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/PageContent.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/PageContent.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const PageContent = (props) => {
  return /* @__PURE__ */ jsxDEV("div", { ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/PageContent.tsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = PageContent;
export default PageContent;
var _c;
$RefreshReg$(_c, "PageContent");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/PageContent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUk7QUFOSiwyQkFBMkI7QUFBRUEsSUFBaUI7QUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJN0QsTUFBTUMsY0FBcUNDLFdBQVU7QUFDbkQsU0FDRSx1QkFBQyxTQUFJLEdBQUlBLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnQjtBQUVwQjtBQUFDQyxLQUpLRjtBQU1OLGVBQWVBO0FBQVcsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlByb3BzV2l0aENoaWxkcmVuIiwiUGFnZUNvbnRlbnQiLCJwcm9wcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGFnZUNvbnRlbnQudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VDb250ZW50LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBIVE1MQXR0cmlidXRlcywgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcblxudHlwZSBQYWdlQ29udGVudFByb3BzID0gUHJvcHNXaXRoQ2hpbGRyZW48SFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+PlxuXG5jb25zdCBQYWdlQ29udGVudDogRkM8UGFnZUNvbnRlbnRQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IHsuLi5wcm9wc30+PC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGFnZUNvbnRlbnRcbiJdfQ==