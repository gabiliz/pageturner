export default function formatPhone(phone) {
  return phone.length < 11 ? phone.replace(
    /(\d{2})(\d{4})(\d{4})/,
    "($1) $2-$3"
  ) : phone.replace(
    /(\d{2})(\d{1})(\d{4})(\d{4})/,
    "($1) $2 $3-$4"
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm1hdFBob25lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGZvcm1hdFBob25lIChwaG9uZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHBob25lLmxlbmd0aCA8IDExXG4gICAgPyBwaG9uZS5yZXBsYWNlKFxuICAgICAgLyhcXGR7Mn0pKFxcZHs0fSkoXFxkezR9KS8sXG4gICAgICAnKCQxKSAkMi0kMycsXG4gICAgKVxuICAgIDogcGhvbmUucmVwbGFjZShcbiAgICAgIC8oXFxkezJ9KShcXGR7MX0pKFxcZHs0fSkoXFxkezR9KS8sXG4gICAgICAnKCQxKSAkMiAkMy0kNCcsXG4gICAgKVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsWUFBYSxPQUF1QjtBQUMxRCxTQUFPLE1BQU0sU0FBUyxLQUNsQixNQUFNO0FBQUEsSUFDTjtBQUFBLElBQ0E7QUFBQSxFQUNGLElBQ0UsTUFBTTtBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNKOyIsIm5hbWVzIjpbXX0=