import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/contentPage/AppPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, IconButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { BreadCrumb, PageTitle, PageSubtitle, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/theme.ts";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
import FlexItem from "/src/shared/components/FlexBox/FlexItem.tsx";
const AppPage = (props) => {
  _s();
  const {
    title,
    renderTitle,
    subtitle,
    renderSubtitle,
    renderBreadCrumb,
    breadCrumb,
    children,
    topRightCorner,
    docsUrl,
    isTitleFixed = false,
    smallTitleSubtitleGap = false,
    hasBackground = false
  } = props;
  const {
    spacing
  } = useTheme();
  const styles = useAppPageStyles(hasBackground);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.appPage, children: /* @__PURE__ */ jsxDEV(FlexColumn, { gap: isTitleFixed ? 0 : spacing.xxl, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", horizontalAlign: "space-between", gap: spacing.md, styles: {
      backgroundColor: hasBackground ? "#fff" : void 0,
      position: isTitleFixed ? "sticky" : "initial",
      top: 0,
      left: 0,
      zIndex: isTitleFixed ? 10 : "auto"
    }, children: [
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", children: [
          renderTitle ? renderTitle() : /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "flex-start", verticalAlign: "center", children: /* @__PURE__ */ jsxDEV(PageTitle, { children: title }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
            lineNumber: 56,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
            lineNumber: 55,
            columnNumber: 46
          }, this),
          docsUrl && /* @__PURE__ */ jsxDEV(TooltipHost, { content: "Abrir documentação", children: /* @__PURE__ */ jsxDEV(IconButton, { className: styles.documentationButton, iconProps: {
            iconName: "Unknown",
            styles: {
              root: {
                fontSize: 20
              }
            }
          }, onClick: () => window.open("https://auditordocs.martinellilabs.com.br" + docsUrl) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
            lineNumber: 59,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
            lineNumber: 58,
            columnNumber: 27
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
          lineNumber: 54,
          columnNumber: 13
        }, this),
        renderSubtitle ? renderSubtitle() : /* @__PURE__ */ jsxDEV(PageSubtitle, { hideMarginTop: smallTitleSubtitleGap, children: subtitle }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
          lineNumber: 70,
          columnNumber: 50
        }, this),
        (breadCrumb || renderBreadCrumb) && /* @__PURE__ */ jsxDEV("div", { className: styles.breadcrumb, children: renderBreadCrumb ? renderBreadCrumb() : breadCrumb && /* @__PURE__ */ jsxDEV(BreadCrumb, { items: breadCrumb }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
          lineNumber: 74,
          columnNumber: 72
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
          lineNumber: 73,
          columnNumber: 50
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
        lineNumber: 53,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: topRightCorner }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
        lineNumber: 77,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
      lineNumber: 46,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
      lineNumber: 81,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
    lineNumber: 45,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx",
    lineNumber: 44,
    columnNumber: 10
  }, this);
};
_s(AppPage, "imGIQuHuJvwOYeKVhuTn9AN9pRQ=", false, function() {
  return [useTheme, useAppPageStyles];
});
_c = AppPage;
const useAppPageStyles = (hasBackground) => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  const location = useLocation();
  const hideSideMenu = location.pathname === "/backlog-monitor" || location.pathname === "/form-list" || location.pathname === "/answer";
  return mergeStyleSets({
    appPage: {
      backgroundColor: hasBackground ? "#fff" : void 0,
      padding: `${spacing.xxl}`,
      maxWidth: hideSideMenu ? 902 : "100%",
      margin: hideSideMenu ? "auto" : 0
    },
    breadcrumb: {
      marginTop: `${spacing.xl}`
    },
    documentationButton: {
      marginLeft: 8,
      color: colors.primary,
      "&:hover": {
        color: colors.purple[800],
        border: "none"
      },
      "&:hover .is-disabled": {
        color: colors.purple[800],
        border: "none"
      },
      "&:active": {
        color: colors.purple[800],
        border: "none"
      },
      "&.is-disabled": {
        opacity: 0.5,
        border: "none"
      }
    }
  });
};
_s2(useAppPageStyles, "qTWoSURoz0jaQfH4iV3AKhru7+s=", false, function() {
  return [useTheme, useLocation];
});
export default AppPage;
var _c;
$RefreshReg$(_c, "AppPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/AppPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUVrQjs7Ozs7Ozs7Ozs7Ozs7OztBQWxFbEIsU0FBU0EsZ0JBQWdCQyxrQkFBa0I7QUFDM0MsU0FBU0MsWUFBNEJDLFdBQVdDLGNBQWNDLG1CQUFtQjtBQUNqRixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGNBQWM7QUFnQnJCLE1BQU1DLFVBQTZCQyxXQUFVO0FBQUFDLEtBQUE7QUFDM0MsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLGVBQWU7QUFBQSxJQUNmQyx3QkFBd0I7QUFBQSxJQUN4QkMsZ0JBQWdCO0FBQUEsRUFDbEIsSUFBSWI7QUFFSixRQUFNO0FBQUEsSUFBRWM7QUFBQUEsRUFBUSxJQUFJbkIsU0FBUztBQUM3QixRQUFNb0IsU0FBU0MsaUJBQWlCSCxhQUFhO0FBRTdDLFNBQ0UsdUJBQUMsU0FBSSxXQUFXRSxPQUFPRSxTQUNyQixpQ0FBQyxjQUNDLEtBQU1OLGVBQWUsSUFBSUcsUUFBUUksS0FFakM7QUFBQSwyQkFBQyxXQUNDLGVBQWMsVUFDZCxpQkFBZ0IsaUJBQ2hCLEtBQUtKLFFBQVFLLElBQ2IsUUFBUTtBQUFBLE1BQ05DLGlCQUFpQlAsZ0JBQWdCLFNBQVNRO0FBQUFBLE1BQzFDQyxVQUFVWCxlQUFlLFdBQVc7QUFBQSxNQUNwQ1ksS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxRQUFRZCxlQUFlLEtBQUs7QUFBQSxJQUM5QixHQUVBO0FBQUEsNkJBQUMsWUFDQztBQUFBLCtCQUFDLFdBQVEsZUFBYyxVQUNwQlI7QUFBQUEsd0JBQ0dBLFlBQVksSUFDWix1QkFBQyxXQUNELGlCQUFnQixjQUNoQixlQUFjLFVBRWQsaUNBQUMsYUFBV0QsbUJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0IsS0FKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLRjtBQUFBLFVBRURRLFdBQ0MsdUJBQUMsZUFDQyxTQUFRLHNCQUVSLGlDQUFDLGNBQ0MsV0FBV0ssT0FBT1cscUJBQ2xCLFdBQVc7QUFBQSxZQUNUQyxVQUFVO0FBQUEsWUFDVlosUUFBUTtBQUFBLGNBQ05hLE1BQU07QUFBQSxnQkFDSkMsVUFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQUEsVUFDRixHQUNBLFNBQVMsTUFBTUMsT0FBT0MsS0FBSyw4Q0FBOENyQixPQUFPLEtBVmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVW9GLEtBYnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFFQ0wsaUJBQ0dBLGVBQWUsSUFDZix1QkFBQyxnQkFBYSxlQUFlTyx1QkFDNUJSLHNCQUREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFRjtBQUFBLFNBRUFHLGNBQWNELHFCQUNkLHVCQUFDLFNBQUksV0FBV1MsT0FBT2lCLFlBQ3BCMUIsNkJBQ0dBLGlCQUFpQixJQUNqQkMsY0FBYyx1QkFBQyxjQUFXLE9BQU9BLGNBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsS0FIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLE1BQ0EsdUJBQUMsWUFDRUUsNEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZEQTtBQUFBLElBQ0EsdUJBQUMsWUFDRUQsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0VBLEtBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzRUE7QUFFSjtBQUFDUCxHQTVGS0YsU0FBeUI7QUFBQSxVQWdCVEosVUFDTHFCLGdCQUFnQjtBQUFBO0FBQUFpQixLQWpCM0JsQztBQThGTixNQUFNaUIsbUJBQW1CQSxDQUFDSCxrQkFBMkI7QUFBQXFCLE1BQUE7QUFDbkQsUUFBTTtBQUFBLElBQUVwQjtBQUFBQSxJQUFTcUI7QUFBQUEsRUFBTyxJQUFJeEMsU0FBUztBQUNyQyxRQUFNeUMsV0FBVzFDLFlBQVk7QUFDN0IsUUFBTTJDLGVBQWVELFNBQVNFLGFBQWEsc0JBQzNDRixTQUFTRSxhQUFhLGdCQUN0QkYsU0FBU0UsYUFBYTtBQUV0QixTQUFPbEQsZUFBZTtBQUFBLElBQ3BCNkIsU0FBUztBQUFBLE1BQ1BHLGlCQUFpQlAsZ0JBQWdCLFNBQVNRO0FBQUFBLE1BQzFDa0IsU0FBVSxHQUFFekIsUUFBUUk7QUFBQUEsTUFDcEJzQixVQUFVSCxlQUFlLE1BQU07QUFBQSxNQUMvQkksUUFBUUosZUFBZSxTQUFTO0FBQUEsSUFDbEM7QUFBQSxJQUNBTCxZQUFZO0FBQUEsTUFDVlUsV0FBWSxHQUFFNUIsUUFBUTZCO0FBQUFBLElBQ3hCO0FBQUEsSUFDQWpCLHFCQUFxQjtBQUFBLE1BQ25Ca0IsWUFBWTtBQUFBLE1BQ1pDLE9BQU9WLE9BQU9XO0FBQUFBLE1BQ2QsV0FBVztBQUFBLFFBQ1RELE9BQU9WLE9BQU9ZLE9BQU8sR0FBRztBQUFBLFFBQ3hCQyxRQUFRO0FBQUEsTUFDVjtBQUFBLE1BQ0Esd0JBQXdCO0FBQUEsUUFDdEJILE9BQU9WLE9BQU9ZLE9BQU8sR0FBRztBQUFBLFFBQ3hCQyxRQUFRO0FBQUEsTUFDVjtBQUFBLE1BQ0EsWUFBWTtBQUFBLFFBQ1ZILE9BQU9WLE9BQU9ZLE9BQU8sR0FBRztBQUFBLFFBQ3hCQyxRQUFRO0FBQUEsTUFDVjtBQUFBLE1BQ0EsaUJBQWlCO0FBQUEsUUFDZkMsU0FBUztBQUFBLFFBQ1RELFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNkLElBdENLbEIsa0JBQWdCO0FBQUEsVUFDUXJCLFVBQ1hELFdBQVc7QUFBQTtBQXNDOUIsZUFBZUs7QUFBTyxJQUFBa0M7QUFBQWlCLGFBQUFqQixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJJY29uQnV0dG9uIiwiQnJlYWRDcnVtYiIsIlBhZ2VUaXRsZSIsIlBhZ2VTdWJ0aXRsZSIsIlRvb2x0aXBIb3N0IiwidXNlTG9jYXRpb24iLCJ1c2VUaGVtZSIsIkZsZXhDb2x1bW4iLCJGbGV4Um93IiwiRmxleEl0ZW0iLCJBcHBQYWdlIiwicHJvcHMiLCJfcyIsInRpdGxlIiwicmVuZGVyVGl0bGUiLCJzdWJ0aXRsZSIsInJlbmRlclN1YnRpdGxlIiwicmVuZGVyQnJlYWRDcnVtYiIsImJyZWFkQ3J1bWIiLCJjaGlsZHJlbiIsInRvcFJpZ2h0Q29ybmVyIiwiZG9jc1VybCIsImlzVGl0bGVGaXhlZCIsInNtYWxsVGl0bGVTdWJ0aXRsZUdhcCIsImhhc0JhY2tncm91bmQiLCJzcGFjaW5nIiwic3R5bGVzIiwidXNlQXBwUGFnZVN0eWxlcyIsImFwcFBhZ2UiLCJ4eGwiLCJtZCIsImJhY2tncm91bmRDb2xvciIsInVuZGVmaW5lZCIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsInpJbmRleCIsImRvY3VtZW50YXRpb25CdXR0b24iLCJpY29uTmFtZSIsInJvb3QiLCJmb250U2l6ZSIsIndpbmRvdyIsIm9wZW4iLCJicmVhZGNydW1iIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJsb2NhdGlvbiIsImhpZGVTaWRlTWVudSIsInBhdGhuYW1lIiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwibWFyZ2luVG9wIiwieGwiLCJtYXJnaW5MZWZ0IiwiY29sb3IiLCJwcmltYXJ5IiwicHVycGxlIiwiYm9yZGVyIiwib3BhY2l0eSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcFBhZ2UudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvY29udGVudFBhZ2UvQXBwUGFnZS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IG1lcmdlU3R5bGVTZXRzLCBJY29uQnV0dG9uIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBCcmVhZENydW1iLCBCcmVhZENydW1iSXRlbSwgUGFnZVRpdGxlLCBQYWdlU3VidGl0bGUsIFRvb2x0aXBIb3N0IH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcy90aGVtZSdcclxuaW1wb3J0IEZsZXhDb2x1bW4gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhDb2x1bW4nXHJcbmltcG9ydCBGbGV4Um93IGZyb20gJy4vLi4vRmxleEJveC9GbGV4Um93J1xyXG5pbXBvcnQgRmxleEl0ZW0gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhJdGVtJ1xyXG5cclxuaW50ZXJmYWNlIEFwcFBhZ2VQcm9wcyB7XHJcbiAgdGl0bGU/OiBzdHJpbmdcclxuICBkb2NzVXJsPzogc3RyaW5nXHJcbiAgcmVuZGVyVGl0bGU/OiAoKSA9PiBSZWFjdE5vZGVcclxuICBzdWJ0aXRsZT86IHN0cmluZyB8IFJlYWN0Tm9kZVxyXG4gIHJlbmRlclN1YnRpdGxlPzogKCkgPT4gUmVhY3ROb2RlXHJcbiAgYnJlYWRDcnVtYj86IEJyZWFkQ3J1bWJJdGVtW11cclxuICByZW5kZXJCcmVhZENydW1iPzogKCkgPT4gUmVhY3ROb2RlXHJcbiAgdG9wUmlnaHRDb3JuZXI/OiBSZWFjdE5vZGVcclxuICBpc1RpdGxlRml4ZWQ/OiBib29sZWFuXHJcbiAgc21hbGxUaXRsZVN1YnRpdGxlR2FwPzogYm9vbGVhblxyXG4gIGhhc0JhY2tncm91bmQ/OiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IEFwcFBhZ2U6IEZDPEFwcFBhZ2VQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7XHJcbiAgICB0aXRsZSxcclxuICAgIHJlbmRlclRpdGxlLFxyXG4gICAgc3VidGl0bGUsXHJcbiAgICByZW5kZXJTdWJ0aXRsZSxcclxuICAgIHJlbmRlckJyZWFkQ3J1bWIsXHJcbiAgICBicmVhZENydW1iLFxyXG4gICAgY2hpbGRyZW4sXHJcbiAgICB0b3BSaWdodENvcm5lcixcclxuICAgIGRvY3NVcmwsXHJcbiAgICBpc1RpdGxlRml4ZWQgPSBmYWxzZSxcclxuICAgIHNtYWxsVGl0bGVTdWJ0aXRsZUdhcCA9IGZhbHNlLFxyXG4gICAgaGFzQmFja2dyb3VuZCA9IGZhbHNlLFxyXG4gIH0gPSBwcm9wc1xyXG5cclxuICBjb25zdCB7IHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBzdHlsZXMgPSB1c2VBcHBQYWdlU3R5bGVzKGhhc0JhY2tncm91bmQpXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFwcFBhZ2V9PlxyXG4gICAgICA8RmxleENvbHVtblxyXG4gICAgICAgIGdhcD17IGlzVGl0bGVGaXhlZCA/IDAgOiBzcGFjaW5nLnh4bCB9XHJcbiAgICAgID5cclxuICAgICAgICA8RmxleFJvd1xyXG4gICAgICAgICAgdmVydGljYWxBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICBob3Jpem9udGFsQWxpZ249XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgIGdhcD17c3BhY2luZy5tZH1cclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGhhc0JhY2tncm91bmQgPyAnI2ZmZicgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBpc1RpdGxlRml4ZWQgPyAnc3RpY2t5JyA6ICdpbml0aWFsJyxcclxuICAgICAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgICAgICBsZWZ0OiAwLFxyXG4gICAgICAgICAgICB6SW5kZXg6IGlzVGl0bGVGaXhlZCA/IDEwIDogJ2F1dG8nLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgICAgIDxGbGV4Um93IHZlcnRpY2FsQWxpZ249J2NlbnRlcic+XHJcbiAgICAgICAgICAgICAge3JlbmRlclRpdGxlXHJcbiAgICAgICAgICAgICAgICA/IHJlbmRlclRpdGxlKClcclxuICAgICAgICAgICAgICAgIDogPEZsZXhSb3dcclxuICAgICAgICAgICAgICAgICAgaG9yaXpvbnRhbEFsaWduPSdmbGV4LXN0YXJ0J1xyXG4gICAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxQYWdlVGl0bGU+e3RpdGxlfTwvUGFnZVRpdGxlPlxyXG4gICAgICAgICAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB7ZG9jc1VybCAmJlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXBIb3N0XHJcbiAgICAgICAgICAgICAgICAgIGNvbnRlbnQ9J0FicmlyIGRvY3VtZW50YcOnw6NvJ1xyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmRvY3VtZW50YXRpb25CdXR0b259XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uTmFtZTogJ1Vua25vd24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGVzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMjAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93Lm9wZW4oJ2h0dHBzOi8vYXVkaXRvcmRvY3MubWFydGluZWxsaWxhYnMuY29tLmJyJyArIGRvY3NVcmwpfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Ub29sdGlwSG9zdD5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvRmxleFJvdz5cclxuXHJcbiAgICAgICAgICAgIHtyZW5kZXJTdWJ0aXRsZVxyXG4gICAgICAgICAgICAgID8gcmVuZGVyU3VidGl0bGUoKVxyXG4gICAgICAgICAgICAgIDogPFBhZ2VTdWJ0aXRsZSBoaWRlTWFyZ2luVG9wPXtzbWFsbFRpdGxlU3VidGl0bGVHYXB9PlxyXG4gICAgICAgICAgICAgICAge3N1YnRpdGxlfVxyXG4gICAgICAgICAgICAgIDwvUGFnZVN1YnRpdGxlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHsoYnJlYWRDcnVtYiB8fCByZW5kZXJCcmVhZENydW1iKSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5icmVhZGNydW1ifT5cclxuICAgICAgICAgICAgICAgIHtyZW5kZXJCcmVhZENydW1iXHJcbiAgICAgICAgICAgICAgICAgID8gcmVuZGVyQnJlYWRDcnVtYigpXHJcbiAgICAgICAgICAgICAgICAgIDogYnJlYWRDcnVtYiAmJiA8QnJlYWRDcnVtYiBpdGVtcz17YnJlYWRDcnVtYn0gLz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgICAgIHt0b3BSaWdodENvcm5lcn1cclxuICAgICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgIDxGbGV4SXRlbT5cclxuICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L0ZsZXhJdGVtPlxyXG4gICAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZUFwcFBhZ2VTdHlsZXMgPSAoaGFzQmFja2dyb3VuZDogYm9vbGVhbikgPT4ge1xyXG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgaGlkZVNpZGVNZW51ID0gbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvYmFja2xvZy1tb25pdG9yJyB8fFxyXG4gIGxvY2F0aW9uLnBhdGhuYW1lID09PSAnL2Zvcm0tbGlzdCcgfHxcclxuICBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy9hbnN3ZXInXHJcblxyXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBhcHBQYWdlOiB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogaGFzQmFja2dyb3VuZCA/ICcjZmZmJyA6IHVuZGVmaW5lZCxcclxuICAgICAgcGFkZGluZzogYCR7c3BhY2luZy54eGx9YCxcclxuICAgICAgbWF4V2lkdGg6IGhpZGVTaWRlTWVudSA/IDkwMiA6ICcxMDAlJyxcclxuICAgICAgbWFyZ2luOiBoaWRlU2lkZU1lbnUgPyAnYXV0bycgOiAwLFxyXG4gICAgfSxcclxuICAgIGJyZWFkY3J1bWI6IHtcclxuICAgICAgbWFyZ2luVG9wOiBgJHtzcGFjaW5nLnhsfWAsXHJcbiAgICB9LFxyXG4gICAgZG9jdW1lbnRhdGlvbkJ1dHRvbjoge1xyXG4gICAgICBtYXJnaW5MZWZ0OiA4LFxyXG4gICAgICBjb2xvcjogY29sb3JzLnByaW1hcnksXHJcbiAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXHJcbiAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgIH0sXHJcbiAgICAgICcmOmhvdmVyIC5pcy1kaXNhYmxlZCc6IHtcclxuICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxyXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICB9LFxyXG4gICAgICAnJjphY3RpdmUnOiB7XHJcbiAgICAgICAgY29sb3I6IGNvbG9ycy5wdXJwbGVbODAwXSxcclxuICAgICAgICBib3JkZXI6ICdub25lJyxcclxuICAgICAgfSxcclxuICAgICAgJyYuaXMtZGlzYWJsZWQnOiB7XHJcbiAgICAgICAgb3BhY2l0eTogMC41LFxyXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHBQYWdlXHJcbiJdfQ==