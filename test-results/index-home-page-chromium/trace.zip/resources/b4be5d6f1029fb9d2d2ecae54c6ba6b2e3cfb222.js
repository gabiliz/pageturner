import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/scrollablePane/ScrollablePane.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/scrollablePane/ScrollablePane.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ScrollablePane as ScrollablePaneFluent } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const ScrollablePane = (props) => {
  _s();
  const styles = useScrollBarStyles();
  return /* @__PURE__ */ jsxDEV(ScrollablePaneFluent, { styles, ...props, children: props.children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/scrollablePane/ScrollablePane.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_s(ScrollablePane, "Tq3kkv7Ci+rOsOXe9BURMCiFTCo=", false, function() {
  return [useScrollBarStyles];
});
_c = ScrollablePane;
const useScrollBarStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return () => ({
    root: {
      selectors: {
        ".ms-ScrollablePane--contentContainer": {
          scrollbarWidth: "thin",
          borderRadius: "4px",
          scrollbarColor: `${colors.gray[300]} ${colors.gray[200]}`
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar": {
          width: "5px",
          paddingLeft: "5px"
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar-track": {
          background: colors.gray[200]
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar-thumb": {
          background: colors.gray[300]
        }
      }
    },
    contentContainer: {
      overflowX: "hidden"
    }
  });
};
_s2(useScrollBarStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default ScrollablePane;
var _c;
$RefreshReg$(_c, "ScrollablePane");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/scrollablePane/ScrollablePane.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQSixTQUFTQSxrQkFBa0JDLDRCQUF5RTtBQUVwRyxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUYsaUJBQTRDRyxXQUFVO0FBQUFDLEtBQUE7QUFDMUQsUUFBTUMsU0FBU0MsbUJBQW1CO0FBQ2xDLFNBQ0UsdUJBQUMsd0JBQ0MsUUFDQSxHQUFJSCxPQUVIQSxnQkFBTUksWUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDSCxHQVZLSixnQkFBd0M7QUFBQSxVQUM3Qk0sa0JBQWtCO0FBQUE7QUFBQUUsS0FEN0JSO0FBWU4sTUFBTU0scUJBQXFCQSxNQUFNO0FBQUFHLE1BQUE7QUFDL0IsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSVIsU0FBUztBQUU1QixTQUFPLE9BQXVDO0FBQUEsSUFDNUNTLE1BQU07QUFBQSxNQUNKQyxXQUFXO0FBQUEsUUFDVCx3Q0FBd0M7QUFBQSxVQUN0Q0MsZ0JBQWdCO0FBQUEsVUFDaEJDLGNBQWM7QUFBQSxVQUNkQyxnQkFBaUIsR0FBRUwsT0FBT00sS0FBSyxHQUFHLEtBQUtOLE9BQU9NLEtBQUssR0FBRztBQUFBLFFBQ3hEO0FBQUEsUUFDQSwyREFBMkQ7QUFBQSxVQUN6REMsT0FBTztBQUFBLFVBQ1BDLGFBQWE7QUFBQSxRQUNmO0FBQUEsUUFDQSxpRUFBaUU7QUFBQSxVQUMvREMsWUFBWVQsT0FBT00sS0FBSyxHQUFHO0FBQUEsUUFDN0I7QUFBQSxRQUNBLGlFQUFpRTtBQUFBLFVBQy9ERyxZQUFZVCxPQUFPTSxLQUFLLEdBQUc7QUFBQSxRQUM3QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQUksa0JBQWtCO0FBQUEsTUFDaEJDLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNGO0FBQUNaLElBM0JLSCxvQkFBa0I7QUFBQSxVQUNISixRQUFRO0FBQUE7QUE0QjdCLGVBQWVGO0FBQWMsSUFBQVE7QUFBQWMsYUFBQWQsSUFBQSIsIm5hbWVzIjpbIlNjcm9sbGFibGVQYW5lIiwiU2Nyb2xsYWJsZVBhbmVGbHVlbnQiLCJ1c2VUaGVtZSIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTY3JvbGxCYXJTdHlsZXMiLCJjaGlsZHJlbiIsIl9jIiwiX3MyIiwiY29sb3JzIiwicm9vdCIsInNlbGVjdG9ycyIsInNjcm9sbGJhcldpZHRoIiwiYm9yZGVyUmFkaXVzIiwic2Nyb2xsYmFyQ29sb3IiLCJncmF5Iiwid2lkdGgiLCJwYWRkaW5nTGVmdCIsImJhY2tncm91bmQiLCJjb250ZW50Q29udGFpbmVyIiwib3ZlcmZsb3dYIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2Nyb2xsYWJsZVBhbmUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvc2Nyb2xsYWJsZVBhbmUvU2Nyb2xsYWJsZVBhbmUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2Nyb2xsYWJsZVBhbmUgYXMgU2Nyb2xsYWJsZVBhbmVGbHVlbnQsIElTY3JvbGxhYmxlUGFuZVByb3BzLCBJU2Nyb2xsYWJsZVBhbmVTdHlsZXMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcblxuY29uc3QgU2Nyb2xsYWJsZVBhbmU6IEZDPElTY3JvbGxhYmxlUGFuZVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCBzdHlsZXMgPSB1c2VTY3JvbGxCYXJTdHlsZXMoKVxuICByZXR1cm4gKFxuICAgIDxTY3JvbGxhYmxlUGFuZUZsdWVudFxuICAgICAgc3R5bGVzPXtzdHlsZXN9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgIDwvU2Nyb2xsYWJsZVBhbmVGbHVlbnQ+XG4gIClcbn1cblxuY29uc3QgdXNlU2Nyb2xsQmFyU3R5bGVzID0gKCkgPT4ge1xuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiAoKTogUGFydGlhbDxJU2Nyb2xsYWJsZVBhbmVTdHlsZXM+ID0+ICh7XG4gICAgcm9vdDoge1xuICAgICAgc2VsZWN0b3JzOiB7XG4gICAgICAgICcubXMtU2Nyb2xsYWJsZVBhbmUtLWNvbnRlbnRDb250YWluZXInOiB7XG4gICAgICAgICAgc2Nyb2xsYmFyV2lkdGg6ICd0aGluJyxcbiAgICAgICAgICBib3JkZXJSYWRpdXM6ICc0cHgnLFxuICAgICAgICAgIHNjcm9sbGJhckNvbG9yOiBgJHtjb2xvcnMuZ3JheVszMDBdfSAke2NvbG9ycy5ncmF5WzIwMF19YCxcbiAgICAgICAgfSxcbiAgICAgICAgJy5tcy1TY3JvbGxhYmxlUGFuZS0tY29udGVudENvbnRhaW5lcjo6LXdlYmtpdC1zY3JvbGxiYXInOiB7XG4gICAgICAgICAgd2lkdGg6ICc1cHgnLFxuICAgICAgICAgIHBhZGRpbmdMZWZ0OiAnNXB4JyxcbiAgICAgICAgfSxcbiAgICAgICAgJy5tcy1TY3JvbGxhYmxlUGFuZS0tY29udGVudENvbnRhaW5lcjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2snOiB7XG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLmdyYXlbMjAwXSxcbiAgICAgICAgfSxcbiAgICAgICAgJy5tcy1TY3JvbGxhYmxlUGFuZS0tY29udGVudENvbnRhaW5lcjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWInOiB7XG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLmdyYXlbMzAwXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBjb250ZW50Q29udGFpbmVyOiB7XG4gICAgICBvdmVyZmxvd1g6ICdoaWRkZW4nLFxuICAgIH0sXG4gIH0pXG59XG5cbmV4cG9ydCBkZWZhdWx0IFNjcm9sbGFibGVQYW5lXG4iXX0=