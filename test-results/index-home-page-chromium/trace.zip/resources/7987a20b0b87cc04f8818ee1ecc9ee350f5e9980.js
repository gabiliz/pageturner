import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/providers/FluentThemeProvider.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/FluentThemeProvider.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ThemeProvider } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { bodyStyles } from "/src/shared/style/styleReset.ts";
const appTheme = {
  palette: {
    themePrimary: "#17416A",
    themeLighterAlt: "#eff6f9",
    themeLighter: "#c3dde8",
    themeLight: "#94c1d3",
    themeTertiary: "#438ba8",
    themeSecondary: "#0f5f7f",
    themeDarkAlt: "#004763",
    themeDark: "#003c53",
    themeDarker: "#002c3d",
    neutralLighterAlt: "#faf9f8",
    neutralLighter: "#f3f2f1",
    neutralLight: "#edebe9",
    neutralQuaternaryAlt: "#e1dfdd",
    neutralQuaternary: "#d0d0d0",
    neutralTertiaryAlt: "#c8c6c4",
    neutralTertiary: "#b4b2b0",
    neutralSecondary: "#9b9997",
    neutralPrimaryAlt: "#83817e",
    neutralPrimary: "#201f1e",
    neutralDark: "#52504e",
    black: "#3a3836",
    white: "#ffffff",
    yellowLight: "#FFEBA8",
    yellow: "#FFD23E",
    yellowDark: "#9A7D1D",
    greenLight: "#7DEF96",
    green: "#51CC6C",
    greenDark: "#005012",
    red: "#C80A2D",
    redDark: "#520312",
    purple: "#9834D4",
    blueLight: "#ECF6FF",
    blueMid: "#77B5F1"
  }
};
const FluentThemeProvider = (props) => {
  return /* @__PURE__ */ jsxDEV(ThemeProvider, { style: bodyStyles, theme: appTheme, children: props.children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/FluentThemeProvider.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_c = FluentThemeProvider;
export default FluentThemeProvider;
var _c;
$RefreshReg$(_c, "FluentThemeProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/FluentThemeProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENJO0FBNUNKLDJCQUF3QkE7QUFBb0I7QUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFN0QsU0FBU0Msa0JBQWtCO0FBRTNCLE1BQU1DLFdBQXlCO0FBQUEsRUFDN0JDLFNBQVM7QUFBQSxJQUNQQyxjQUFjO0FBQUEsSUFDZEMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxJQUNkQyxZQUFZO0FBQUEsSUFDWkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLElBQ1hDLGFBQWE7QUFBQSxJQUNiQyxtQkFBbUI7QUFBQSxJQUNuQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGNBQWM7QUFBQSxJQUNkQyxzQkFBc0I7QUFBQSxJQUN0QkMsbUJBQW1CO0FBQUEsSUFDbkJDLG9CQUFvQjtBQUFBLElBQ3BCQyxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsSUFDbEJDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLE9BQU87QUFBQSxJQUNQQyxXQUFXO0FBQUEsSUFDWEMsS0FBSztBQUFBLElBQ0xDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxFQUNYO0FBQ0Y7QUFFQSxNQUFNQyxzQkFBb0VDLFdBQVU7QUFDbEYsU0FDRSx1QkFBQyxpQkFDQyxPQUFPckMsWUFDUCxPQUFPQyxVQUVOb0MsZ0JBQU1DLFlBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0MsS0FUS0g7QUFXTixlQUFlQTtBQUFtQixJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUGFydGlhbFRoZW1lIiwiYm9keVN0eWxlcyIsImFwcFRoZW1lIiwicGFsZXR0ZSIsInRoZW1lUHJpbWFyeSIsInRoZW1lTGlnaHRlckFsdCIsInRoZW1lTGlnaHRlciIsInRoZW1lTGlnaHQiLCJ0aGVtZVRlcnRpYXJ5IiwidGhlbWVTZWNvbmRhcnkiLCJ0aGVtZURhcmtBbHQiLCJ0aGVtZURhcmsiLCJ0aGVtZURhcmtlciIsIm5ldXRyYWxMaWdodGVyQWx0IiwibmV1dHJhbExpZ2h0ZXIiLCJuZXV0cmFsTGlnaHQiLCJuZXV0cmFsUXVhdGVybmFyeUFsdCIsIm5ldXRyYWxRdWF0ZXJuYXJ5IiwibmV1dHJhbFRlcnRpYXJ5QWx0IiwibmV1dHJhbFRlcnRpYXJ5IiwibmV1dHJhbFNlY29uZGFyeSIsIm5ldXRyYWxQcmltYXJ5QWx0IiwibmV1dHJhbFByaW1hcnkiLCJuZXV0cmFsRGFyayIsImJsYWNrIiwid2hpdGUiLCJ5ZWxsb3dMaWdodCIsInllbGxvdyIsInllbGxvd0RhcmsiLCJncmVlbkxpZ2h0IiwiZ3JlZW4iLCJncmVlbkRhcmsiLCJyZWQiLCJyZWREYXJrIiwicHVycGxlIiwiYmx1ZUxpZ2h0IiwiYmx1ZU1pZCIsIkZsdWVudFRoZW1lUHJvdmlkZXIiLCJwcm9wcyIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGbHVlbnRUaGVtZVByb3ZpZGVyLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9wcm92aWRlcnMvRmx1ZW50VGhlbWVQcm92aWRlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUaGVtZVByb3ZpZGVyLCBQYXJ0aWFsVGhlbWUgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGJvZHlTdHlsZXMgfSBmcm9tICcuLi9zdHlsZS9zdHlsZVJlc2V0J1xuXG5jb25zdCBhcHBUaGVtZTogUGFydGlhbFRoZW1lID0ge1xuICBwYWxldHRlOiB7XG4gICAgdGhlbWVQcmltYXJ5OiAnIzE3NDE2QScsXG4gICAgdGhlbWVMaWdodGVyQWx0OiAnI2VmZjZmOScsXG4gICAgdGhlbWVMaWdodGVyOiAnI2MzZGRlOCcsXG4gICAgdGhlbWVMaWdodDogJyM5NGMxZDMnLFxuICAgIHRoZW1lVGVydGlhcnk6ICcjNDM4YmE4JyxcbiAgICB0aGVtZVNlY29uZGFyeTogJyMwZjVmN2YnLFxuICAgIHRoZW1lRGFya0FsdDogJyMwMDQ3NjMnLFxuICAgIHRoZW1lRGFyazogJyMwMDNjNTMnLFxuICAgIHRoZW1lRGFya2VyOiAnIzAwMmMzZCcsXG4gICAgbmV1dHJhbExpZ2h0ZXJBbHQ6ICcjZmFmOWY4JyxcbiAgICBuZXV0cmFsTGlnaHRlcjogJyNmM2YyZjEnLFxuICAgIG5ldXRyYWxMaWdodDogJyNlZGViZTknLFxuICAgIG5ldXRyYWxRdWF0ZXJuYXJ5QWx0OiAnI2UxZGZkZCcsXG4gICAgbmV1dHJhbFF1YXRlcm5hcnk6ICcjZDBkMGQwJyxcbiAgICBuZXV0cmFsVGVydGlhcnlBbHQ6ICcjYzhjNmM0JyxcbiAgICBuZXV0cmFsVGVydGlhcnk6ICcjYjRiMmIwJyxcbiAgICBuZXV0cmFsU2Vjb25kYXJ5OiAnIzliOTk5NycsXG4gICAgbmV1dHJhbFByaW1hcnlBbHQ6ICcjODM4MTdlJyxcbiAgICBuZXV0cmFsUHJpbWFyeTogJyMyMDFmMWUnLFxuICAgIG5ldXRyYWxEYXJrOiAnIzUyNTA0ZScsXG4gICAgYmxhY2s6ICcjM2EzODM2JyxcbiAgICB3aGl0ZTogJyNmZmZmZmYnLFxuICAgIHllbGxvd0xpZ2h0OiAnI0ZGRUJBOCcsXG4gICAgeWVsbG93OiAnI0ZGRDIzRScsXG4gICAgeWVsbG93RGFyazogJyM5QTdEMUQnLFxuICAgIGdyZWVuTGlnaHQ6ICcjN0RFRjk2JyxcbiAgICBncmVlbjogJyM1MUNDNkMnLFxuICAgIGdyZWVuRGFyazogJyMwMDUwMTInLFxuICAgIHJlZDogJyNDODBBMkQnLFxuICAgIHJlZERhcms6ICcjNTIwMzEyJyxcbiAgICBwdXJwbGU6ICcjOTgzNEQ0JyxcbiAgICBibHVlTGlnaHQ6ICcjRUNGNkZGJyxcbiAgICBibHVlTWlkOiAnIzc3QjVGMScsXG4gIH0sXG59XG5cbmNvbnN0IEZsdWVudFRoZW1lUHJvdmlkZXI6IEZDPFByb3BzV2l0aENoaWxkcmVuPFJlY29yZDxuZXZlciwgbmV2ZXI+Pj4gPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8VGhlbWVQcm92aWRlclxuICAgICAgc3R5bGU9e2JvZHlTdHlsZXN9XG4gICAgICB0aGVtZT17YXBwVGhlbWV9XG4gICAgPlxuICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgIDwvVGhlbWVQcm92aWRlcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBGbHVlbnRUaGVtZVByb3ZpZGVyXG4iXX0=