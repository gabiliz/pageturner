import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/PageRoutes.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const lazy = __vite__cjsImport3_react["lazy"]; const Suspense = __vite__cjsImport3_react["Suspense"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { ErrorScreen, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { navLinkGroups } from "/src/modules/admin/components/index.ts?t=1701096626433";
import { fiscalLinks } from "/src/modules/fiscal/components/index.ts?t=1701096626433";
import { Route, Navigate, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { adminRTController, auditRTController, fiscalRTController } from "/src/shared/realtime/index.ts";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { analyticalRevisionType } from "/src/modules/audit/analyticalRevision/enums/analyticalRevisionType.ts";
import { AuditProcessing } from "/src/modules/audit/audits/components/index.ts?t=1701096626433";
const Users = lazy(_c = () => import("/src/modules/admin/users/pages/Users.tsx"));
_c2 = Users;
const Rules = lazy(_c3 = () => import("/src/modules/fiscal/rules/pages/Rules.tsx"));
_c4 = Rules;
const RulesQueries = lazy(_c5 = () => import("/src/modules/fiscal/rules/pages/RulesQueries.tsx"));
_c6 = RulesQueries;
const Offices = lazy(_c7 = () => import("/src/modules/admin/offices/pages/Offices.tsx"));
_c8 = Offices;
const ProjectTypes = lazy(_c9 = () => import("/src/modules/fiscal/projectTypes/pages/ProjectTypes.tsx"));
_c10 = ProjectTypes;
const Roles = lazy(_c11 = () => import("/src/modules/admin/roles/pages/Roles.tsx"));
_c12 = Roles;
const Profiles = lazy(_c13 = () => import("/src/modules/admin/profiles/pages/Profiles.tsx"));
_c14 = Profiles;
const Clients = lazy(_c15 = () => import("/src/modules/admin/clients/pages/Clients.tsx"));
_c16 = Clients;
const ClientCompanies = lazy(_c17 = () => import("/src/modules/admin/clients/pages/ClientCompanies.tsx"));
_c18 = ClientCompanies;
const Projects = lazy(_c19 = () => import("/src/modules/fiscal/projects/pages/Projects.tsx"));
_c20 = Projects;
const ProjectConfiguration = lazy(_c21 = () => import("/src/modules/fiscal/projects/pages/ProjectConfiguration.tsx"));
_c22 = ProjectConfiguration;
const Contracts = lazy(_c23 = () => import("/src/modules/admin/contracts/pages/Contracts.tsx"));
_c24 = Contracts;
const ContractConfiguration = lazy(_c25 = () => import("/src/modules/admin/contracts/pages/ContractConfiguration.tsx"));
_c26 = ContractConfiguration;
const Audits = lazy(_c27 = () => import("/src/modules/audit/audits/pages/Audits.tsx"));
_c28 = Audits;
const AnalyticalRevisionPage = lazy(_c29 = () => import("/src/modules/audit/analyticalRevision/pages/AnalyticalRevisionPage.tsx"));
_c30 = AnalyticalRevisionPage;
const TestProcessPage = lazy(_c31 = () => import("/src/modules/audit/testProcess/pages/TestProcessPage.tsx"));
_c32 = TestProcessPage;
const LayoutBalances = lazy(_c33 = () => import("/src/modules/admin/layoutBalance/pages/LayoutBalances.tsx"));
_c34 = LayoutBalances;
const BacklogMonitor = lazy(_c35 = () => import("/src/modules/admin/backlogMonitor/pages/BacklogMonitor.tsx"));
_c36 = BacklogMonitor;
const BalanceSheetDetailPage = lazy(_c37 = () => import("/src/modules/admin/balance/pages/BalanceSheetDetailPage.tsx"));
_c38 = BalanceSheetDetailPage;
const LedgerAccountPage = lazy(_c39 = () => import("/src/modules/admin/ledgerAccount/pages/LedgerAccountPage.tsx"));
_c40 = LedgerAccountPage;
const ProcessOccurrences = lazy(_c41 = () => import("/src/modules/fiscal/projects/components/process/pages/ProcessOccurrences.tsx"));
_c42 = ProcessOccurrences;
const ProcessOccurrencesDetailsPage = lazy(_c43 = () => import("/src/modules/fiscal/projects/components/process/pages/ProcessOccurrencesDetailsPage.tsx"));
_c44 = ProcessOccurrencesDetailsPage;
const RiskForm = lazy(_c45 = () => import("/src/modules/audit/riskForm/pages/RiskForm.tsx?t=1701096626433"));
_c46 = RiskForm;
const RiskFormEdit = lazy(_c47 = () => import("/src/modules/audit/riskForm/pages/RiskFormEdit.tsx?t=1701096626433"));
_c48 = RiskFormEdit;
const RiskFormForward = lazy(_c49 = () => import("/src/modules/audit/riskForm/pages/RiskFormForward.tsx?t=1701096626433"));
_c50 = RiskFormForward;
const AuditRiskForm = lazy(_c51 = () => import("/src/modules/audit/auditsRiskForm/pages/AuditsRiskForm.tsx"));
_c52 = AuditRiskForm;
const AuditRiskFormAnswers = lazy(_c53 = () => import("/src/modules/audit/auditsRiskForm/pages/AuditsRiskFormAnswers.tsx"));
_c54 = AuditRiskFormAnswers;
const Auditors = lazy(_c55 = () => import("/src/modules/audit/auditors/pages/Auditors.tsx"));
_c56 = Auditors;
const AuditDocuments = lazy(_c57 = () => import("/src/modules/audit/documents/pages/AuditDocuments.tsx"));
_c58 = AuditDocuments;
const AuditMaterialityPage = lazy(_c59 = () => import("/src/modules/audit/materiality/pages/AuditMaterialityPage.tsx"));
_c60 = AuditMaterialityPage;
const Tests = lazy(_c61 = () => import("/src/modules/audit/testRegister/pages/Tests.tsx"));
_c62 = Tests;
const Parameters = lazy(_c63 = () => import("/src/modules/audit/parameters/pages/Parameters.tsx"));
_c64 = Parameters;
const RiskDash = lazy(_c65 = () => import("/src/modules/audit/riskDashboard/pages/RiskDash.tsx"));
_c66 = RiskDash;
const TestDistribution = lazy(_c67 = () => import("/src/modules/audit/testDistribution/pages/TestDistribution.tsx"));
_c68 = TestDistribution;
const VisitScheduler = lazy(_c69 = () => import("/src/modules/audit/visitScheduler/pages/VisitScheduler.tsx"));
_c70 = VisitScheduler;
const ApprovalFlowPage = lazy(_c71 = () => import("/src/modules/audit/approvalFlow/pages/ApprovalFlowPage.tsx"));
_c72 = ApprovalFlowPage;
const ExecutionTestsPage = lazy(_c73 = () => import("/src/modules/audit/executionTests/pages/ExecutionTestsPage.tsx"));
_c74 = ExecutionTestsPage;
const MaterialitiesPage = lazy(_c75 = () => import("/src/modules/audit/materiality/pages/AuditMaterialityConfigPage.tsx"));
_c76 = MaterialitiesPage;
const TestDashboardPage = lazy(_c77 = () => import("/src/modules/audit/testDashboard/pages/TestDashboard.tsx"));
_c78 = TestDashboardPage;
const AdjustmentBallotsPage = lazy(_c79 = () => import("/src/modules/audit/adjustmentBallots/pages/AdjustmentBallotsPage.tsx"));
_c80 = AdjustmentBallotsPage;
const AdjustmentBallotsDetailsPage = lazy(_c81 = () => import("/src/modules/audit/adjustmentBallots/pages/AdjustmentBallotsDetailsPage.tsx"));
_c82 = AdjustmentBallotsDetailsPage;
const MeetingMinute = lazy(_c83 = () => import("/src/modules/audit/meetingMinute/pages/MeetingMinute.tsx"));
_c84 = MeetingMinute;
const Workflows = lazy(_c85 = () => import("/src/modules/audit/workflows/pages/Workflows.tsx"));
_c86 = Workflows;
const OpinionDash = lazy(_c87 = () => import("/src/modules/audit/opinionDashboard/pages/OpinionDash.tsx"));
_c88 = OpinionDash;
const FinancialStatementsOldPage = lazy(_c89 = () => import("/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx?t=1701096626433"));
_c90 = FinancialStatementsOldPage;
const FinancialStatementsPage = lazy(_c91 = () => import("/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx?t=1701096626433"));
_c92 = FinancialStatementsPage;
const FinancialStatementsImportPage = lazy(_c93 = () => import("/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx?t=1701096626433"));
_c94 = FinancialStatementsImportPage;
const FinancialStatementsPublicPage = lazy(_c95 = () => import("/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx?t=1701096626433"));
_c96 = FinancialStatementsPublicPage;
const PageRoutes = () => {
  _s();
  adminRTController.start();
  auditRTController.start();
  fiscalRTController.start();
  const {
    hasPermission
  } = usePermissions();
  const linksAdmin = useMemo(() => {
    return navLinkGroups[0].links.find((navLink) => hasPermission(navLink.key, "Visualizar", navLink?.onlyAdmin));
  }, []);
  const linksFiscal = useMemo(() => {
    return fiscalLinks[0].links.find((navLink) => hasPermission(navLink.key, "Visualizar", navLink?.onlyAdmin));
  }, []);
  return /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
    lineNumber: 121,
    columnNumber: 30
  }, this), children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/backlog-monitor", replace: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 123,
      columnNumber: 34
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 123,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin", element: /* @__PURE__ */ jsxDEV(Navigate, { to: linksAdmin?.url || "/admin/offices", replace: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 124,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 124,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal", element: /* @__PURE__ */ jsxDEV(Navigate, { to: linksFiscal?.url || "/fiscal/project-types", replace: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 125,
      columnNumber: 40
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 125,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/audit/audits", replace: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 126,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 126,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/offices", element: /* @__PURE__ */ jsxDEV(Offices, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 127,
      columnNumber: 47
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 127,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/roles", element: /* @__PURE__ */ jsxDEV(Roles, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 128,
      columnNumber: 45
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 128,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/layoutBalance", element: /* @__PURE__ */ jsxDEV(LayoutBalances, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 129,
      columnNumber: 53
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 129,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/profiles", element: /* @__PURE__ */ jsxDEV(Profiles, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 130,
      columnNumber: 48
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 130,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/users", element: /* @__PURE__ */ jsxDEV(Users, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 131,
      columnNumber: 45
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/clients", element: /* @__PURE__ */ jsxDEV(Clients, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 132,
      columnNumber: 47
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 132,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/clients/:clientId/companies", element: /* @__PURE__ */ jsxDEV(ClientCompanies, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 133,
      columnNumber: 69
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 133,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/client/:clientId/companies/:companyId/balances/:balanceSheetId", element: /* @__PURE__ */ jsxDEV(BalanceSheetDetailPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 134,
      columnNumber: 104
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 134,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/clients/:clientId/contracts", element: /* @__PURE__ */ jsxDEV(Contracts, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 135,
      columnNumber: 69
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 135,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/clients/:clientId/contracts/:contractId/*", element: /* @__PURE__ */ jsxDEV(ContractConfiguration, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 136,
      columnNumber: 83
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 136,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/backlog-monitor", element: /* @__PURE__ */ jsxDEV(BacklogMonitor, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 137,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 137,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/project-types", element: /* @__PURE__ */ jsxDEV(ProjectTypes, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 138,
      columnNumber: 54
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 138,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/config-rules", element: /* @__PURE__ */ jsxDEV(Rules, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 139,
      columnNumber: 53
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 139,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/config-rules/:ruleId/queries", element: /* @__PURE__ */ jsxDEV(RulesQueries, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 140,
      columnNumber: 71
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/projects", element: /* @__PURE__ */ jsxDEV(Projects, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 141,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/projects/:projectId/edit", element: /* @__PURE__ */ jsxDEV(ProjectConfiguration, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 142,
      columnNumber: 67
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 142,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/projects/:projectId/edit/process/:processId/occurrences", element: /* @__PURE__ */ jsxDEV(ProcessOccurrences, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 143,
      columnNumber: 98
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 143,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/projects/:projectId/edit/process/:processId/occurrences/:ruleId", element: /* @__PURE__ */ jsxDEV(ProcessOccurrencesDetailsPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 144,
      columnNumber: 106
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 144,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits", element: /* @__PURE__ */ jsxDEV(Audits, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 145,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 145,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/risk-form", element: /* @__PURE__ */ jsxDEV(RiskForm, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 146,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 146,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/tests", element: /* @__PURE__ */ jsxDEV(Tests, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 147,
      columnNumber: 45
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 147,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/workflows", element: /* @__PURE__ */ jsxDEV(Workflows, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 148,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 148,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/risk-form/create", element: /* @__PURE__ */ jsxDEV(RiskFormEdit, { isCreating: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 149,
      columnNumber: 56
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 149,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/risk-form/:riskFormId/edit", element: /* @__PURE__ */ jsxDEV(RiskFormEdit, { isCreating: false }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 150,
      columnNumber: 66
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 150,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/financial-statements", element: /* @__PURE__ */ jsxDEV(FinancialStatementsPublicPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 151,
      columnNumber: 56
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 151,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:auditId", element: /* @__PURE__ */ jsxDEV(AuditProcessing, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 152,
      columnNumber: 55
    }, this), children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/opinion", element: /* @__PURE__ */ jsxDEV(OpinionDash, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 153,
        columnNumber: 56
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 153,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/dashboard", element: /* @__PURE__ */ jsxDEV(TestDashboardPage, { isAnalysis: false }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 154,
        columnNumber: 58
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 154,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/risk-form", element: /* @__PURE__ */ jsxDEV(AuditRiskForm, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 155,
        columnNumber: 67
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 155,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/dashboard", element: /* @__PURE__ */ jsxDEV(RiskDash, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 156,
        columnNumber: 67
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 156,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/risk-form/:formId/answers", element: /* @__PURE__ */ jsxDEV(AuditRiskFormAnswers, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 157,
        columnNumber: 83
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 157,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/parameters", element: /* @__PURE__ */ jsxDEV(Parameters, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 158,
        columnNumber: 70
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 158,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/test-distribution", element: /* @__PURE__ */ jsxDEV(TestDistribution, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 159,
        columnNumber: 77
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 159,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/analytical-revision", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAnalyticalRevision: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 160,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 160,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/auditors", element: /* @__PURE__ */ jsxDEV(Auditors, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 161,
        columnNumber: 68
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 161,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/approval-flow", element: /* @__PURE__ */ jsxDEV(ApprovalFlowPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 162,
        columnNumber: 73
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 162,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/documents", element: /* @__PURE__ */ jsxDEV(AuditDocuments, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 163,
        columnNumber: 69
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 163,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/materiality", element: /* @__PURE__ */ jsxDEV(AuditMaterialityPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 164,
        columnNumber: 71
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 164,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/visit-scheduler", element: /* @__PURE__ */ jsxDEV(VisitScheduler, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 165,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 165,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/materiality/:materialityId", element: /* @__PURE__ */ jsxDEV(MaterialitiesPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 166,
        columnNumber: 86
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 166,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/dashboard", element: /* @__PURE__ */ jsxDEV(TestDashboardPage, { isAnalysis: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 167,
        columnNumber: 69
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 167,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/financial-statements/old", element: /* @__PURE__ */ jsxDEV(FinancialStatementsOldPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 168,
        columnNumber: 86
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 168,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/financial-statements", element: /* @__PURE__ */ jsxDEV(FinancialStatementsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 169,
        columnNumber: 82
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 169,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/financial-statements/details/:financialId", element: /* @__PURE__ */ jsxDEV(FinancialStatementsImportPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 170,
        columnNumber: 103
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 170,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 171,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 171,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 172,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 172,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing/:groupToShow", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 173,
        columnNumber: 92
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 173,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing/:groupToShow", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 174,
        columnNumber: 88
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 174,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing/:groupToShow/:companyId/:codeAcc/:page", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 175,
        columnNumber: 118
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 175,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing/:groupToShow/:companyId/:codeAcc/:page", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 176,
        columnNumber: 114
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 176,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/:testProcessType/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(ExecutionTestsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 177,
        columnNumber: 106
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 177,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/:testProcessType", element: /* @__PURE__ */ jsxDEV(TestProcessPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 178,
        columnNumber: 78
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 178,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/:revisionPathType/:groupToShow/:companyId/:codeAcc/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(ExecutionTestsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 179,
        columnNumber: 138
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 179,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/adjustment-ballot", element: /* @__PURE__ */ jsxDEV(AdjustmentBallotsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 180,
        columnNumber: 82
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 180,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/adjustment-ballot/:adjustmentBallotId", element: /* @__PURE__ */ jsxDEV(AdjustmentBallotsDetailsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 181,
        columnNumber: 102
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/meeting-minutes", element: /* @__PURE__ */ jsxDEV(MeetingMinute, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 182,
        columnNumber: 80
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 182,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/opinion", element: /* @__PURE__ */ jsxDEV(OpinionDash, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 182,
        columnNumber: 146
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 182,
        columnNumber: 101
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/dashboard", element: /* @__PURE__ */ jsxDEV(TestDashboardPage, { isAnalysis: false }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 183,
        columnNumber: 58
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 183,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/risk-form", element: /* @__PURE__ */ jsxDEV(AuditRiskForm, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 184,
        columnNumber: 67
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 184,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/dashboard", element: /* @__PURE__ */ jsxDEV(RiskDash, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 185,
        columnNumber: 67
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 185,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/risk-form/:formId/answers", element: /* @__PURE__ */ jsxDEV(AuditRiskFormAnswers, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 186,
        columnNumber: 83
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 186,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/parameters", element: /* @__PURE__ */ jsxDEV(Parameters, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 187,
        columnNumber: 70
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 187,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/test-distribution", element: /* @__PURE__ */ jsxDEV(TestDistribution, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 188,
        columnNumber: 77
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 188,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/analytical-revision", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAnalyticalRevision: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 189,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 189,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/auditors", element: /* @__PURE__ */ jsxDEV(Auditors, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 190,
        columnNumber: 68
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 190,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/approval-flow", element: /* @__PURE__ */ jsxDEV(ApprovalFlowPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 191,
        columnNumber: 73
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 191,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/documents", element: /* @__PURE__ */ jsxDEV(AuditDocuments, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 192,
        columnNumber: 69
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 192,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/materiality", element: /* @__PURE__ */ jsxDEV(AuditMaterialityPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 193,
        columnNumber: 71
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/visit-scheduler", element: /* @__PURE__ */ jsxDEV(VisitScheduler, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 194,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 194,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/planning/materiality/:materialityId", element: /* @__PURE__ */ jsxDEV(MaterialitiesPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 195,
        columnNumber: 86
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 195,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/dashboard", element: /* @__PURE__ */ jsxDEV(TestDashboardPage, { isAnalysis: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 196,
        columnNumber: 69
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 197,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 197,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 198,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 198,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing/:groupToShow", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 199,
        columnNumber: 92
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 199,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing/:groupToShow", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 200,
        columnNumber: 88
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 200,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/patrimonial-testing/:groupToShow/:companyId/:codeAcc/:page", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.patrimonial, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 201,
        columnNumber: 118
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 201,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/results-testing/:groupToShow/:companyId/:codeAcc/:page", element: /* @__PURE__ */ jsxDEV(AnalyticalRevisionPage, { isAuditTesting: true, revisionType: analyticalRevisionType.result, hideMenu: true }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 202,
        columnNumber: 114
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 202,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/:testProcessType/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(ExecutionTestsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 203,
        columnNumber: 106
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/:auditMenu/:testProcessType", element: /* @__PURE__ */ jsxDEV(TestProcessPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 204,
        columnNumber: 78
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 204,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/analysis/:revisionPathType/:groupToShow/:companyId/:codeAcc/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(ExecutionTestsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 205,
        columnNumber: 138
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 205,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/adjustment-ballot", element: /* @__PURE__ */ jsxDEV(AdjustmentBallotsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 206,
        columnNumber: 82
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 206,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/adjustment-ballot/:adjustmentBallotId", element: /* @__PURE__ */ jsxDEV(AdjustmentBallotsDetailsPage, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 207,
        columnNumber: 102
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 207,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "control-panel/communication/meeting-minutes", element: /* @__PURE__ */ jsxDEV(MeetingMinute, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 208,
        columnNumber: 80
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
        lineNumber: 208,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 152,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/clients/:clientId/companies/:companyId/chart-of-accounts/:chartOfAccountsId", element: /* @__PURE__ */ jsxDEV(LedgerAccountPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 210,
      columnNumber: 117
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 210,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/backlog-monitor", element: /* @__PURE__ */ jsxDEV(BacklogMonitor, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 211,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 211,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/form-list", element: /* @__PURE__ */ jsxDEV(RiskFormForward, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 212,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 212,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 213,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 213,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(ErrorScreen, { type: "notFound" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 214,
      columnNumber: 34
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
      lineNumber: 214,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
    lineNumber: 122,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx",
    lineNumber: 121,
    columnNumber: 10
  }, this);
};
_s(PageRoutes, "EChvV5cCqb7Fjmgkkie6ekhaBh8=", false, function() {
  return [usePermissions];
});
_c97 = PageRoutes;
export default PageRoutes;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32, _c33, _c34, _c35, _c36, _c37, _c38, _c39, _c40, _c41, _c42, _c43, _c44, _c45, _c46, _c47, _c48, _c49, _c50, _c51, _c52, _c53, _c54, _c55, _c56, _c57, _c58, _c59, _c60, _c61, _c62, _c63, _c64, _c65, _c66, _c67, _c68, _c69, _c70, _c71, _c72, _c73, _c74, _c75, _c76, _c77, _c78, _c79, _c80, _c81, _c82, _c83, _c84, _c85, _c86, _c87, _c88, _c89, _c90, _c91, _c92, _c93, _c94, _c95, _c96, _c97;
$RefreshReg$(_c, "Users$lazy");
$RefreshReg$(_c2, "Users");
$RefreshReg$(_c3, "Rules$lazy");
$RefreshReg$(_c4, "Rules");
$RefreshReg$(_c5, "RulesQueries$lazy");
$RefreshReg$(_c6, "RulesQueries");
$RefreshReg$(_c7, "Offices$lazy");
$RefreshReg$(_c8, "Offices");
$RefreshReg$(_c9, "ProjectTypes$lazy");
$RefreshReg$(_c10, "ProjectTypes");
$RefreshReg$(_c11, "Roles$lazy");
$RefreshReg$(_c12, "Roles");
$RefreshReg$(_c13, "Profiles$lazy");
$RefreshReg$(_c14, "Profiles");
$RefreshReg$(_c15, "Clients$lazy");
$RefreshReg$(_c16, "Clients");
$RefreshReg$(_c17, "ClientCompanies$lazy");
$RefreshReg$(_c18, "ClientCompanies");
$RefreshReg$(_c19, "Projects$lazy");
$RefreshReg$(_c20, "Projects");
$RefreshReg$(_c21, "ProjectConfiguration$lazy");
$RefreshReg$(_c22, "ProjectConfiguration");
$RefreshReg$(_c23, "Contracts$lazy");
$RefreshReg$(_c24, "Contracts");
$RefreshReg$(_c25, "ContractConfiguration$lazy");
$RefreshReg$(_c26, "ContractConfiguration");
$RefreshReg$(_c27, "Audits$lazy");
$RefreshReg$(_c28, "Audits");
$RefreshReg$(_c29, "AnalyticalRevisionPage$lazy");
$RefreshReg$(_c30, "AnalyticalRevisionPage");
$RefreshReg$(_c31, "TestProcessPage$lazy");
$RefreshReg$(_c32, "TestProcessPage");
$RefreshReg$(_c33, "LayoutBalances$lazy");
$RefreshReg$(_c34, "LayoutBalances");
$RefreshReg$(_c35, "BacklogMonitor$lazy");
$RefreshReg$(_c36, "BacklogMonitor");
$RefreshReg$(_c37, "BalanceSheetDetailPage$lazy");
$RefreshReg$(_c38, "BalanceSheetDetailPage");
$RefreshReg$(_c39, "LedgerAccountPage$lazy");
$RefreshReg$(_c40, "LedgerAccountPage");
$RefreshReg$(_c41, "ProcessOccurrences$lazy");
$RefreshReg$(_c42, "ProcessOccurrences");
$RefreshReg$(_c43, "ProcessOccurrencesDetailsPage$lazy");
$RefreshReg$(_c44, "ProcessOccurrencesDetailsPage");
$RefreshReg$(_c45, "RiskForm$lazy");
$RefreshReg$(_c46, "RiskForm");
$RefreshReg$(_c47, "RiskFormEdit$lazy");
$RefreshReg$(_c48, "RiskFormEdit");
$RefreshReg$(_c49, "RiskFormForward$lazy");
$RefreshReg$(_c50, "RiskFormForward");
$RefreshReg$(_c51, "AuditRiskForm$lazy");
$RefreshReg$(_c52, "AuditRiskForm");
$RefreshReg$(_c53, "AuditRiskFormAnswers$lazy");
$RefreshReg$(_c54, "AuditRiskFormAnswers");
$RefreshReg$(_c55, "Auditors$lazy");
$RefreshReg$(_c56, "Auditors");
$RefreshReg$(_c57, "AuditDocuments$lazy");
$RefreshReg$(_c58, "AuditDocuments");
$RefreshReg$(_c59, "AuditMaterialityPage$lazy");
$RefreshReg$(_c60, "AuditMaterialityPage");
$RefreshReg$(_c61, "Tests$lazy");
$RefreshReg$(_c62, "Tests");
$RefreshReg$(_c63, "Parameters$lazy");
$RefreshReg$(_c64, "Parameters");
$RefreshReg$(_c65, "RiskDash$lazy");
$RefreshReg$(_c66, "RiskDash");
$RefreshReg$(_c67, "TestDistribution$lazy");
$RefreshReg$(_c68, "TestDistribution");
$RefreshReg$(_c69, "VisitScheduler$lazy");
$RefreshReg$(_c70, "VisitScheduler");
$RefreshReg$(_c71, "ApprovalFlowPage$lazy");
$RefreshReg$(_c72, "ApprovalFlowPage");
$RefreshReg$(_c73, "ExecutionTestsPage$lazy");
$RefreshReg$(_c74, "ExecutionTestsPage");
$RefreshReg$(_c75, "MaterialitiesPage$lazy");
$RefreshReg$(_c76, "MaterialitiesPage");
$RefreshReg$(_c77, "TestDashboardPage$lazy");
$RefreshReg$(_c78, "TestDashboardPage");
$RefreshReg$(_c79, "AdjustmentBallotsPage$lazy");
$RefreshReg$(_c80, "AdjustmentBallotsPage");
$RefreshReg$(_c81, "AdjustmentBallotsDetailsPage$lazy");
$RefreshReg$(_c82, "AdjustmentBallotsDetailsPage");
$RefreshReg$(_c83, "MeetingMinute$lazy");
$RefreshReg$(_c84, "MeetingMinute");
$RefreshReg$(_c85, "Workflows$lazy");
$RefreshReg$(_c86, "Workflows");
$RefreshReg$(_c87, "OpinionDash$lazy");
$RefreshReg$(_c88, "OpinionDash");
$RefreshReg$(_c89, "FinancialStatementsOldPage$lazy");
$RefreshReg$(_c90, "FinancialStatementsOldPage");
$RefreshReg$(_c91, "FinancialStatementsPage$lazy");
$RefreshReg$(_c92, "FinancialStatementsPage");
$RefreshReg$(_c93, "FinancialStatementsImportPage$lazy");
$RefreshReg$(_c94, "FinancialStatementsImportPage");
$RefreshReg$(_c95, "FinancialStatementsPublicPage$lazy");
$RefreshReg$(_c96, "FinancialStatementsPublicPage");
$RefreshReg$(_c97, "PageRoutes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/routes/PageRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUV3Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXpFeEIsU0FBYUEsTUFBTUMsVUFBVUMsZUFBZTtBQUM1QyxTQUFTQyxhQUFhQyxxQkFBcUI7QUFDM0MsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxPQUFPQyxVQUFVQyxjQUFjO0FBQ3hDLFNBQVNDLG1CQUFtQkMsbUJBQW1CQywwQkFBMEI7QUFDekUsU0FBdUJDLHNCQUFzQjtBQUM3QyxTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MsdUJBQXVCO0FBQ2hDLE1BQU1DLFFBQVFoQixLQUFJaUIsS0FBQ0EsTUFBTSxPQUFPLG9DQUFvQyxDQUFDO0FBQUNDLE1BQWhFRjtBQUNOLE1BQU1HLFFBQVFuQixLQUFJb0IsTUFBQ0EsTUFBTSxPQUFPLHFDQUFxQyxDQUFDO0FBQUNDLE1BQWpFRjtBQUNOLE1BQU1HLGVBQWV0QixLQUFJdUIsTUFBQ0EsTUFBTSxPQUFPLDRDQUE0QyxDQUFDO0FBQUNDLE1BQS9FRjtBQUNOLE1BQU1HLFVBQVV6QixLQUFJMEIsTUFBQ0EsTUFBTSxPQUFPLHdDQUF3QyxDQUFDO0FBQUNDLE1BQXRFRjtBQUNOLE1BQU1HLGVBQWU1QixLQUFJNkIsTUFBQ0EsTUFBTSxPQUFPLG1EQUFtRCxDQUFDO0FBQUNDLE9BQXRGRjtBQUNOLE1BQU1HLFFBQVEvQixLQUFJZ0MsT0FBQ0EsTUFBTSxPQUFPLG9DQUFvQyxDQUFDO0FBQUNDLE9BQWhFRjtBQUNOLE1BQU1HLFdBQVdsQyxLQUFJbUMsT0FBQ0EsTUFBTSxPQUFPLDBDQUEwQyxDQUFDO0FBQUNDLE9BQXpFRjtBQUNOLE1BQU1HLFVBQVVyQyxLQUFJc0MsT0FBQ0EsTUFBTSxPQUFPLHdDQUF3QyxDQUFDO0FBQUNDLE9BQXRFRjtBQUNOLE1BQU1HLGtCQUFrQnhDLEtBQUl5QyxPQUFDQSxNQUFNLE9BQU8sZ0RBQWdELENBQUM7QUFBQ0MsT0FBdEZGO0FBQ04sTUFBTUcsV0FBVzNDLEtBQUk0QyxPQUFDQSxNQUFNLE9BQU8sMkNBQTJDLENBQUM7QUFBQ0MsT0FBMUVGO0FBQ04sTUFBTUcsdUJBQXVCOUMsS0FBSStDLE9BQUNBLE1BQU0sT0FBTyx1REFBdUQsQ0FBQztBQUFDQyxPQUFsR0Y7QUFDTixNQUFNRyxZQUFZakQsS0FBSWtELE9BQUNBLE1BQU0sT0FBTyw0Q0FBNEMsQ0FBQztBQUFDQyxPQUE1RUY7QUFDTixNQUFNRyx3QkFBd0JwRCxLQUFJcUQsT0FBQ0EsTUFBTSxPQUFPLHdEQUF3RCxDQUFDO0FBQUNDLE9BQXBHRjtBQUNOLE1BQU1HLFNBQVN2RCxLQUFJd0QsT0FBQ0EsTUFBTSxPQUFPLHNDQUFzQyxDQUFDO0FBQUNDLE9BQW5FRjtBQUNOLE1BQU1HLHlCQUF5QjFELEtBQUkyRCxPQUFDQSxNQUFNLE9BQU8sa0VBQWtFLENBQUM7QUFBQ0MsT0FBL0dGO0FBQ04sTUFBTUcsa0JBQWtCN0QsS0FBSThELE9BQUNBLE1BQU0sT0FBTyxvREFBb0QsQ0FBQztBQUFDQyxPQUExRkY7QUFDTixNQUFNRyxpQkFBaUJoRSxLQUFJaUUsT0FBQ0EsTUFBTSxPQUFPLHFEQUFxRCxDQUFDO0FBQUNDLE9BQTFGRjtBQUNOLE1BQU1HLGlCQUFpQm5FLEtBQUlvRSxPQUFDQSxNQUFNLE9BQU8sc0RBQXNELENBQUM7QUFBQ0MsT0FBM0ZGO0FBQ04sTUFBTUcseUJBQXlCdEUsS0FBSXVFLE9BQUNBLE1BQU0sT0FBTyx1REFBdUQsQ0FBQztBQUFDQyxPQUFwR0Y7QUFDTixNQUFNRyxvQkFBb0J6RSxLQUFJMEUsT0FBQ0EsTUFBTSxPQUFPLHdEQUF3RCxDQUFDO0FBQUNDLE9BQWhHRjtBQUNOLE1BQU1HLHFCQUFxQjVFLEtBQUk2RSxPQUFDQSxNQUFNLE9BQU8sd0VBQXdFLENBQUM7QUFBQ0MsT0FBakhGO0FBQ04sTUFBTUcsZ0NBQWdDL0UsS0FBSWdGLE9BQUNBLE1BQU0sT0FBTyxtRkFBbUYsQ0FBQztBQUFDQyxPQUF2SUY7QUFDTixNQUFNRyxXQUFXbEYsS0FBSW1GLE9BQUNBLE1BQU0sT0FBTywwQ0FBMEMsQ0FBQztBQUFDQyxPQUF6RUY7QUFDTixNQUFNRyxlQUFlckYsS0FBSXNGLE9BQUNBLE1BQU0sT0FBTyw4Q0FBOEMsQ0FBQztBQUFDQyxPQUFqRkY7QUFDTixNQUFNRyxrQkFBa0J4RixLQUFJeUYsT0FBQ0EsTUFBTSxPQUFPLGlEQUFpRCxDQUFDO0FBQUNDLE9BQXZGRjtBQUNOLE1BQU1HLGdCQUFnQjNGLEtBQUk0RixPQUFDQSxNQUFNLE9BQU8sc0RBQXNELENBQUM7QUFBQ0MsT0FBMUZGO0FBQ04sTUFBTUcsdUJBQXVCOUYsS0FBSStGLE9BQUNBLE1BQU0sT0FBTyw2REFBNkQsQ0FBQztBQUFDQyxPQUF4R0Y7QUFDTixNQUFNRyxXQUFXakcsS0FBSWtHLE9BQUNBLE1BQU0sT0FBTywwQ0FBMEMsQ0FBQztBQUFDQyxPQUF6RUY7QUFDTixNQUFNRyxpQkFBaUJwRyxLQUFJcUcsT0FBQ0EsTUFBTSxPQUFPLGlEQUFpRCxDQUFDO0FBQUNDLE9BQXRGRjtBQUNOLE1BQU1HLHVCQUF1QnZHLEtBQUl3RyxPQUFDQSxNQUFNLE9BQU8seURBQXlELENBQUM7QUFBQ0MsT0FBcEdGO0FBQ04sTUFBTUcsUUFBUTFHLEtBQUkyRyxPQUFDQSxNQUFNLE9BQU8sMkNBQTJDLENBQUM7QUFBQ0MsT0FBdkVGO0FBQ04sTUFBTUcsYUFBYTdHLEtBQUk4RyxPQUFDQSxNQUFNLE9BQU8sOENBQThDLENBQUM7QUFBQ0MsT0FBL0VGO0FBQ04sTUFBTUcsV0FBV2hILEtBQUlpSCxPQUFDQSxNQUFNLE9BQU8sK0NBQStDLENBQUM7QUFBQ0MsT0FBOUVGO0FBQ04sTUFBTUcsbUJBQW1CbkgsS0FBSW9ILE9BQUNBLE1BQU0sT0FBTyw0REFBNEQsQ0FBQztBQUFDQyxPQUFuR0Y7QUFDTixNQUFNRyxpQkFBaUJ0SCxLQUFJdUgsT0FBQ0EsTUFBTSxPQUFPLHNEQUFzRCxDQUFDO0FBQUNDLE9BQTNGRjtBQUNOLE1BQU1HLG1CQUFtQnpILEtBQUkwSCxPQUFDQSxNQUFNLE9BQU8sd0RBQXdELENBQUM7QUFBQ0MsT0FBL0ZGO0FBQ04sTUFBTUcscUJBQXFCNUgsS0FBSTZILE9BQUNBLE1BQU0sT0FBTywwREFBMEQsQ0FBQztBQUFDQyxPQUFuR0Y7QUFDTixNQUFNRyxvQkFBb0IvSCxLQUFJZ0ksT0FBQ0EsTUFBTSxPQUFPLCtEQUErRCxDQUFDO0FBQUNDLE9BQXZHRjtBQUNOLE1BQU1HLG9CQUFvQmxJLEtBQUltSSxPQUFDQSxNQUFNLE9BQU8sb0RBQW9ELENBQUM7QUFBQ0MsT0FBNUZGO0FBQ04sTUFBTUcsd0JBQXdCckksS0FBSXNJLE9BQUNBLE1BQU0sT0FBTyxnRUFBZ0UsQ0FBQztBQUFDQyxPQUE1R0Y7QUFDTixNQUFNRywrQkFBK0J4SSxLQUFJeUksT0FBQ0EsTUFBTSxPQUFPLHVFQUF1RSxDQUFDO0FBQUNDLE9BQTFIRjtBQUNOLE1BQU1HLGdCQUFnQjNJLEtBQUk0SSxPQUFDQSxNQUFNLE9BQU8sb0RBQW9ELENBQUM7QUFBQ0MsT0FBeEZGO0FBQ04sTUFBTUcsWUFBWTlJLEtBQUkrSSxPQUFDQSxNQUFNLE9BQU8sNENBQTRDLENBQUM7QUFBQ0MsT0FBNUVGO0FBQ04sTUFBTUcsY0FBY2pKLEtBQUlrSixPQUFDQSxNQUFNLE9BQU8scURBQXFELENBQUM7QUFBQ0MsT0FBdkZGO0FBQ04sTUFBTUcsNkJBQTZCcEosS0FBSXFKLE9BQUNBLE1BQU0sT0FBTyx1RUFBdUUsQ0FBQztBQUFDQyxPQUF4SEY7QUFDTixNQUFNRywwQkFBMEJ2SixLQUFJd0osT0FBQ0EsTUFBTSxPQUFPLG9FQUFvRSxDQUFDO0FBQUNDLE9BQWxIRjtBQUNOLE1BQU1HLGdDQUFnQzFKLEtBQUkySixPQUFDQSxNQUFNLE9BQU8sMEVBQTBFLENBQUM7QUFBQ0MsT0FBOUhGO0FBQ04sTUFBTUcsZ0NBQWdDN0osS0FBSThKLE9BQUNBLE1BQU0sT0FBTywwRUFBMEUsQ0FBQztBQUFDQyxPQUE5SEY7QUFFTixNQUFNRyxhQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCdkosb0JBQWtCd0osTUFBTTtBQUN4QnZKLG9CQUFrQnVKLE1BQU07QUFDeEJ0SixxQkFBbUJzSixNQUFNO0FBRXpCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFjLElBQUl0SixlQUFlO0FBRXpDLFFBQU11SixhQUFhbEssUUFBUSxNQUFNO0FBQy9CLFdBQU9HLGNBQWMsQ0FBQyxFQUFFZ0ssTUFBTUMsS0FBS0MsYUFBV0osY0FBY0ksUUFBUUMsS0FBcUIsY0FBY0QsU0FBU0UsU0FBUyxDQUFDO0FBQUEsRUFDNUgsR0FBRyxFQUFFO0FBRUwsUUFBTUMsY0FBY3hLLFFBQVEsTUFBTTtBQUNoQyxXQUFPSSxZQUFZLENBQUMsRUFBRStKLE1BQU1DLEtBQUtDLGFBQVdKLGNBQWNJLFFBQVFDLEtBQXFCLGNBQWNELFNBQVNFLFNBQVMsQ0FBQztBQUFBLEVBQzFILEdBQUcsRUFBRTtBQUNMLFNBQ0UsdUJBQUMsWUFBUyxVQUFVLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYyxHQUNoQyxpQ0FBQyxVQUNDO0FBQUEsMkJBQUMsU0FDQyxNQUFLLEtBQ0wsU0FBUyx1QkFBQyxZQUFTLElBQUcsb0JBQW1CLFNBQU8sUUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QyxLQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFEO0FBQUEsSUFFckQsdUJBQUMsU0FDQyxNQUFLLFVBQ0wsU0FBUyx1QkFBQyxZQUFTLElBQUlMLFlBQVlPLE9BQWlCLGtCQUFrQixTQUFPLFFBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0UsS0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVrRjtBQUFBLElBRWxGLHVCQUFDLFNBQ0MsTUFBSyxXQUNMLFNBQVMsdUJBQUMsWUFBUyxJQUFJRCxhQUFhQyxPQUFpQix5QkFBeUIsU0FBTyxRQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFLEtBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFMEY7QUFBQSxJQUUxRix1QkFBQyxTQUNDLE1BQUssVUFDTCxTQUFTLHVCQUFDLFlBQVMsSUFBRyxpQkFBZ0IsU0FBTyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9DLEtBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFa0Q7QUFBQSxJQUVsRCx1QkFBQyxTQUNDLE1BQUssa0JBQ0wsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXVCO0FBQUEsSUFFdkIsdUJBQUMsU0FDQyxNQUFLLGdCQUNMLFNBQVMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU0sS0FGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVxQjtBQUFBLElBRXJCLHVCQUFDLFNBQ0MsTUFBSyx3QkFDTCxTQUFTLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRThCO0FBQUEsSUFFOUIsdUJBQUMsU0FDQyxNQUFLLG1CQUNMLFNBQVMsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVMsS0FGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUV3QjtBQUFBLElBRXhCLHVCQUFDLFNBQ0MsTUFBSyxnQkFDTCxTQUFTLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFNLEtBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFcUI7QUFBQSxJQUVyQix1QkFBQyxTQUNDLE1BQUssa0JBQ0wsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXVCO0FBQUEsSUFFdkIsdUJBQUMsU0FDQyxNQUFNLHNDQUNOLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixLQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRStCO0FBQUEsSUFFL0IsdUJBQUMsU0FDQyxNQUFNLHlFQUNOLFNBQVMsdUJBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QixLQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXNDO0FBQUEsSUFFdEMsdUJBQUMsU0FDQyxNQUFNLHNDQUNOLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVUsS0FGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUV3QjtBQUFBLElBRXhCLHVCQUFDLFNBQ0MsTUFBTSxvREFDTixTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsS0FGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVvQztBQUFBLElBRXBDLHVCQUFDLFNBQ0MsTUFBSyxvQkFDTCxTQUFTLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRThCO0FBQUEsSUFFOUIsdUJBQUMsU0FDQyxNQUFLLHlCQUNMLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhLEtBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFNEI7QUFBQSxJQUU1Qix1QkFBQyxTQUNDLE1BQUssd0JBQ0wsU0FBUyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFCO0FBQUEsSUFFckIsdUJBQUMsU0FDQyxNQUFNLHdDQUNOLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhLEtBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFMkI7QUFBQSxJQUUzQix1QkFBQyxTQUNDLE1BQUssb0JBQ0wsU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUyxLQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXdCO0FBQUEsSUFFeEIsdUJBQUMsU0FDQyxNQUFNLG9DQUNOLFNBQVMsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQixLQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRW1DO0FBQUEsSUFFbkMsdUJBQUMsU0FDQyxNQUFNLG1FQUNOLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWlDO0FBQUEsSUFFakMsdUJBQUMsU0FDQyxNQUFNLDJFQUNOLFNBQVMsdUJBQUMsbUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QixLQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRTRDO0FBQUEsSUFFNUMsdUJBQUMsU0FDQyxNQUFLLGlCQUNMLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVzQjtBQUFBLElBRXRCLHVCQUFDLFNBQ0MsTUFBSyxvQkFDTCxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFd0I7QUFBQSxJQUV4Qix1QkFBQyxTQUNDLE1BQUssZ0JBQ0wsU0FBUyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTSxLQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFCO0FBQUEsSUFFckIsdUJBQUMsU0FDQyxNQUFLLG9CQUNMLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVUsS0FGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUV3QjtBQUFBLElBRXhCLHVCQUFDLFNBQ0MsTUFBSywyQkFDTCxTQUFTLHVCQUFDLGdCQUFhLFlBQVksUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQixLQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRThDO0FBQUEsSUFFOUMsdUJBQUMsU0FDQyxNQUFLLHFDQUNMLFNBQVMsdUJBQUMsZ0JBQWEsWUFBWSxTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDLEtBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFOEM7QUFBQSxJQUU5Qyx1QkFBQyxTQUNDLE1BQU0seUJBQ04sU0FBUyx1QkFBQyxtQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFNkM7QUFBQSxJQUU3Qyx1QkFBQyxTQUFNLE1BQUssMEJBQXlCLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixHQUM1RDtBQUFBLDZCQUFDLFNBQ0MsTUFBSyx5QkFDTCxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTJCO0FBQUEsTUFFM0IsdUJBQUMsU0FDQyxNQUFLLDJCQUNMLFNBQVMsdUJBQUMscUJBQWtCLFlBQVksU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQyxLQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRW1EO0FBQUEsTUFFbkQsdUJBQUMsU0FDQyxNQUFLLG9DQUNMLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEtBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFNEI7QUFBQSxNQUU1Qix1QkFBQyxTQUNDLE1BQUssb0NBQ0wsU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUyxLQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXVCO0FBQUEsTUFFdkIsdUJBQUMsU0FDQyxNQUFLLG9EQUNMLFNBQVMsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQixLQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRW1DO0FBQUEsTUFFbkMsdUJBQUMsU0FDQyxNQUFNLHFDQUNOLFNBQVMsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEtBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFeUI7QUFBQSxNQUV6Qix1QkFBQyxTQUNDLE1BQU0sNENBQ04sU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEtBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFK0I7QUFBQSxNQUUvQix1QkFBQyxTQUNDLE1BQU0sOENBQ04sU0FBUyx1QkFBQywwQkFDUixzQkFBb0IsUUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQ2EsS0FIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlLO0FBQUEsTUFFTCx1QkFBQyxTQUNDLE1BQU0sbUNBQ04sU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUyxLQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXVCO0FBQUEsTUFFdkIsdUJBQUMsU0FDQyxNQUFNLHdDQUNOLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRStCO0FBQUEsTUFFL0IsdUJBQUMsU0FDQyxNQUFNLG9DQUNOLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFNkI7QUFBQSxNQUU3Qix1QkFBQyxTQUNDLE1BQU0sc0NBQ04sU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCLEtBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFbUM7QUFBQSxNQUVuQyx1QkFBQyxTQUNDLE1BQU0sMENBQ04sU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU2QjtBQUFBLE1BRTdCLHVCQUFDLFNBQ0MsTUFBTSxxREFDTixTQUFTLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVnQztBQUFBLE1BRWhDLHVCQUFDLFNBQ0MsTUFBSyxzQ0FDTCxTQUFTLHVCQUFDLHFCQUFrQixZQUFZLFFBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0MsS0FGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVrRDtBQUFBLE1BRWxELHVCQUFDLFNBQ0MsTUFBTSxxREFDTixTQUFTLHVCQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkIsS0FGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUwQztBQUFBLE1BRTFDLHVCQUFDLFNBQ0MsTUFBTSxpREFDTixTQUFTLHVCQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0IsS0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUV1QztBQUFBLE1BRXZDLHVCQUFDLFNBQ0MsTUFBTSxzRUFDTixTQUFTLHVCQUFDLG1DQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEIsS0FGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU2QztBQUFBLE1BRTdDLHVCQUFDLFNBQ0MsTUFBTSw4Q0FDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYzdKLHVCQUF1QjhKLGFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSwwQ0FDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYzlKLHVCQUF1QitKLFFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSwyREFDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYy9KLHVCQUF1QjhKLGFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSx1REFDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYzlKLHVCQUF1QitKLFFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSxxRkFDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYy9KLHVCQUF1QjhKLGFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSxpRkFDTixTQUFTLHVCQUFDLDBCQUNSLGdCQUFjLE1BQ2QsY0FBYzlKLHVCQUF1QitKLFFBQ3JDLFVBQVEsUUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSx5RUFDTixTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVrQztBQUFBLE1BRWxDLHVCQUFDLFNBQ0MsTUFBTSw2Q0FDTixTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0IsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUrQjtBQUFBLE1BRS9CLHVCQUFDLFNBQ0MsTUFBTSx5R0FDTixTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVrQztBQUFBLE1BRWxDLHVCQUFDLFNBQ0MsTUFBTSxpREFDTixTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0IsS0FGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVvQztBQUFBLE1BRXBDLHVCQUFDLFNBQ0MsTUFBTSxxRUFDTixTQUFTLHVCQUFDLGtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkIsS0FGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUyQztBQUFBLE1BRTNDLHVCQUFDLFNBQ0MsTUFBTSwrQ0FDTixTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxLQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTRCO0FBQUEsTUFDMUIsdUJBQUMsU0FDRCxNQUFLLHlCQUNMLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFeUI7QUFBQSxNQUUzQix1QkFBQyxTQUNDLE1BQUssMkJBQ0wsU0FBUyx1QkFBQyxxQkFBa0IsWUFBWSxTQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDLEtBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFbUQ7QUFBQSxNQUVuRCx1QkFBQyxTQUNDLE1BQUssb0NBQ0wsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsS0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU0QjtBQUFBLE1BRTVCLHVCQUFDLFNBQ0MsTUFBSyxvQ0FDTCxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTLEtBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFdUI7QUFBQSxNQUV2Qix1QkFBQyxTQUNDLE1BQUssb0RBQ0wsU0FBUyx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCLEtBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFbUM7QUFBQSxNQUVuQyx1QkFBQyxTQUNDLE1BQU0scUNBQ04sU0FBUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVcsS0FGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUV5QjtBQUFBLE1BRXpCLHVCQUFDLFNBQ0MsTUFBTSw0Q0FDTixTQUFTLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsS0FGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUrQjtBQUFBLE1BRS9CLHVCQUFDLFNBQ0MsTUFBTSw4Q0FDTixTQUFTLHVCQUFDLDBCQUNSLHNCQUFvQixRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFDYSxLQUh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUs7QUFBQSxNQUVMLHVCQUFDLFNBQ0MsTUFBTSxtQ0FDTixTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTLEtBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFdUI7QUFBQSxNQUV2Qix1QkFBQyxTQUNDLE1BQU0sd0NBQ04sU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEtBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFK0I7QUFBQSxNQUUvQix1QkFBQyxTQUNDLE1BQU0sb0NBQ04sU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU2QjtBQUFBLE1BRTdCLHVCQUFDLFNBQ0MsTUFBTSxzQ0FDTixTQUFTLHVCQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUIsS0FGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVtQztBQUFBLE1BRW5DLHVCQUFDLFNBQ0MsTUFBTSwwQ0FDTixTQUFTLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxLQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTZCO0FBQUEsTUFFN0IsdUJBQUMsU0FDQyxNQUFNLHFEQUNOLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQixLQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWdDO0FBQUEsTUFFaEMsdUJBQUMsU0FDQyxNQUFLLHNDQUNMLFNBQVMsdUJBQUMscUJBQWtCLFlBQVksUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQyxLQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWtEO0FBQUEsTUFFbEQsdUJBQUMsU0FDQyxNQUFNLDhDQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjL0osdUJBQXVCOEosYUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLDBDQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjOUosdUJBQXVCK0osUUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLDJEQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjL0osdUJBQXVCOEosYUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLHVEQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjOUosdUJBQXVCK0osUUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLHFGQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjL0osdUJBQXVCOEosYUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLGlGQUNOLFNBQVMsdUJBQUMsMEJBQ1IsZ0JBQWMsTUFDZCxjQUFjOUosdUJBQXVCK0osUUFDckMsVUFBUSxRQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQyxLQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSztBQUFBLE1BRUwsdUJBQUMsU0FDQyxNQUFNLHlFQUNOLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQixLQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWtDO0FBQUEsTUFFbEMsdUJBQUMsU0FDQyxNQUFNLDZDQUNOLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQixLQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRStCO0FBQUEsTUFFL0IsdUJBQUMsU0FDQyxNQUFNLHlHQUNOLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQixLQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWtDO0FBQUEsTUFFbEMsdUJBQUMsU0FDQyxNQUFNLGlEQUNOLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQixLQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRW9DO0FBQUEsTUFFcEMsdUJBQUMsU0FDQyxNQUFNLHFFQUNOLFNBQVMsdUJBQUMsa0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QixLQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTJDO0FBQUEsTUFFM0MsdUJBQUMsU0FDQyxNQUFNLCtDQUNOLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEtBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFNEI7QUFBQSxTQXRSOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdSQTtBQUFBLElBQ0EsdUJBQUMsU0FDQyxNQUFNLHNGQUNOLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQixLQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWdDO0FBQUEsSUFFaEMsdUJBQUMsU0FDQyxNQUFLLG9CQUNMLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFOEI7QUFBQSxJQUU5Qix1QkFBQyxTQUNDLE1BQUssY0FDTCxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUUrQjtBQUFBLElBRS9CLHVCQUFDLFNBQ0MsTUFBSyxTQUNMLFNBQVMsdUJBQUMsWUFBUyxJQUFHLEtBQUksU0FBTyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCLEtBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFc0M7QUFBQSxJQUV0Qyx1QkFBQyxTQUNDLE1BQUssS0FDTCxTQUFTLHVCQUFDLGVBQVksTUFBSyxjQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCLEtBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFMkM7QUFBQSxPQWhhN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWthQSxLQW5hRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb2FBO0FBRUo7QUFBQ1osR0FyYktELFlBQWM7QUFBQSxVQUtRbkosY0FBYztBQUFBO0FBQUFpSyxPQUxwQ2Q7QUF1Yk4sZUFBZUE7QUFBVSxJQUFBL0ksSUFBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQWU7QUFBQUMsYUFBQTlKLElBQUE7QUFBQThKLGFBQUE3SixLQUFBO0FBQUE2SixhQUFBM0osS0FBQTtBQUFBMkosYUFBQTFKLEtBQUE7QUFBQTBKLGFBQUF4SixLQUFBO0FBQUF3SixhQUFBdkosS0FBQTtBQUFBdUosYUFBQXJKLEtBQUE7QUFBQXFKLGFBQUFwSixLQUFBO0FBQUFvSixhQUFBbEosS0FBQTtBQUFBa0osYUFBQWpKLE1BQUE7QUFBQWlKLGFBQUEvSSxNQUFBO0FBQUErSSxhQUFBOUksTUFBQTtBQUFBOEksYUFBQTVJLE1BQUE7QUFBQTRJLGFBQUEzSSxNQUFBO0FBQUEySSxhQUFBekksTUFBQTtBQUFBeUksYUFBQXhJLE1BQUE7QUFBQXdJLGFBQUF0SSxNQUFBO0FBQUFzSSxhQUFBckksTUFBQTtBQUFBcUksYUFBQW5JLE1BQUE7QUFBQW1JLGFBQUFsSSxNQUFBO0FBQUFrSSxhQUFBaEksTUFBQTtBQUFBZ0ksYUFBQS9ILE1BQUE7QUFBQStILGFBQUE3SCxNQUFBO0FBQUE2SCxhQUFBNUgsTUFBQTtBQUFBNEgsYUFBQTFILE1BQUE7QUFBQTBILGFBQUF6SCxNQUFBO0FBQUF5SCxhQUFBdkgsTUFBQTtBQUFBdUgsYUFBQXRILE1BQUE7QUFBQXNILGFBQUFwSCxNQUFBO0FBQUFvSCxhQUFBbkgsTUFBQTtBQUFBbUgsYUFBQWpILE1BQUE7QUFBQWlILGFBQUFoSCxNQUFBO0FBQUFnSCxhQUFBOUcsTUFBQTtBQUFBOEcsYUFBQTdHLE1BQUE7QUFBQTZHLGFBQUEzRyxNQUFBO0FBQUEyRyxhQUFBMUcsTUFBQTtBQUFBMEcsYUFBQXhHLE1BQUE7QUFBQXdHLGFBQUF2RyxNQUFBO0FBQUF1RyxhQUFBckcsTUFBQTtBQUFBcUcsYUFBQXBHLE1BQUE7QUFBQW9HLGFBQUFsRyxNQUFBO0FBQUFrRyxhQUFBakcsTUFBQTtBQUFBaUcsYUFBQS9GLE1BQUE7QUFBQStGLGFBQUE5RixNQUFBO0FBQUE4RixhQUFBNUYsTUFBQTtBQUFBNEYsYUFBQTNGLE1BQUE7QUFBQTJGLGFBQUF6RixNQUFBO0FBQUF5RixhQUFBeEYsTUFBQTtBQUFBd0YsYUFBQXRGLE1BQUE7QUFBQXNGLGFBQUFyRixNQUFBO0FBQUFxRixhQUFBbkYsTUFBQTtBQUFBbUYsYUFBQWxGLE1BQUE7QUFBQWtGLGFBQUFoRixNQUFBO0FBQUFnRixhQUFBL0UsTUFBQTtBQUFBK0UsYUFBQTdFLE1BQUE7QUFBQTZFLGFBQUE1RSxNQUFBO0FBQUE0RSxhQUFBMUUsTUFBQTtBQUFBMEUsYUFBQXpFLE1BQUE7QUFBQXlFLGFBQUF2RSxNQUFBO0FBQUF1RSxhQUFBdEUsTUFBQTtBQUFBc0UsYUFBQXBFLE1BQUE7QUFBQW9FLGFBQUFuRSxNQUFBO0FBQUFtRSxhQUFBakUsTUFBQTtBQUFBaUUsYUFBQWhFLE1BQUE7QUFBQWdFLGFBQUE5RCxNQUFBO0FBQUE4RCxhQUFBN0QsTUFBQTtBQUFBNkQsYUFBQTNELE1BQUE7QUFBQTJELGFBQUExRCxNQUFBO0FBQUEwRCxhQUFBeEQsTUFBQTtBQUFBd0QsYUFBQXZELE1BQUE7QUFBQXVELGFBQUFyRCxNQUFBO0FBQUFxRCxhQUFBcEQsTUFBQTtBQUFBb0QsYUFBQWxELE1BQUE7QUFBQWtELGFBQUFqRCxNQUFBO0FBQUFpRCxhQUFBL0MsTUFBQTtBQUFBK0MsYUFBQTlDLE1BQUE7QUFBQThDLGFBQUE1QyxNQUFBO0FBQUE0QyxhQUFBM0MsTUFBQTtBQUFBMkMsYUFBQXpDLE1BQUE7QUFBQXlDLGFBQUF4QyxNQUFBO0FBQUF3QyxhQUFBdEMsTUFBQTtBQUFBc0MsYUFBQXJDLE1BQUE7QUFBQXFDLGFBQUFuQyxNQUFBO0FBQUFtQyxhQUFBbEMsTUFBQTtBQUFBa0MsYUFBQWhDLE1BQUE7QUFBQWdDLGFBQUEvQixNQUFBO0FBQUErQixhQUFBN0IsTUFBQTtBQUFBNkIsYUFBQTVCLE1BQUE7QUFBQTRCLGFBQUExQixNQUFBO0FBQUEwQixhQUFBekIsTUFBQTtBQUFBeUIsYUFBQXZCLE1BQUE7QUFBQXVCLGFBQUF0QixNQUFBO0FBQUFzQixhQUFBcEIsTUFBQTtBQUFBb0IsYUFBQW5CLE1BQUE7QUFBQW1CLGFBQUFqQixNQUFBO0FBQUFpQixhQUFBaEIsTUFBQTtBQUFBZ0IsYUFBQUQsTUFBQSIsIm5hbWVzIjpbImxhenkiLCJTdXNwZW5zZSIsInVzZU1lbW8iLCJFcnJvclNjcmVlbiIsIkxvYWRpbmdTY3JlZW4iLCJuYXZMaW5rR3JvdXBzIiwiZmlzY2FsTGlua3MiLCJSb3V0ZSIsIk5hdmlnYXRlIiwiUm91dGVzIiwiYWRtaW5SVENvbnRyb2xsZXIiLCJhdWRpdFJUQ29udHJvbGxlciIsImZpc2NhbFJUQ29udHJvbGxlciIsInVzZVBlcm1pc3Npb25zIiwiYW5hbHl0aWNhbFJldmlzaW9uVHlwZSIsIkF1ZGl0UHJvY2Vzc2luZyIsIlVzZXJzIiwiX2MiLCJfYzIiLCJSdWxlcyIsIl9jMyIsIl9jNCIsIlJ1bGVzUXVlcmllcyIsIl9jNSIsIl9jNiIsIk9mZmljZXMiLCJfYzciLCJfYzgiLCJQcm9qZWN0VHlwZXMiLCJfYzkiLCJfYzEwIiwiUm9sZXMiLCJfYzExIiwiX2MxMiIsIlByb2ZpbGVzIiwiX2MxMyIsIl9jMTQiLCJDbGllbnRzIiwiX2MxNSIsIl9jMTYiLCJDbGllbnRDb21wYW5pZXMiLCJfYzE3IiwiX2MxOCIsIlByb2plY3RzIiwiX2MxOSIsIl9jMjAiLCJQcm9qZWN0Q29uZmlndXJhdGlvbiIsIl9jMjEiLCJfYzIyIiwiQ29udHJhY3RzIiwiX2MyMyIsIl9jMjQiLCJDb250cmFjdENvbmZpZ3VyYXRpb24iLCJfYzI1IiwiX2MyNiIsIkF1ZGl0cyIsIl9jMjciLCJfYzI4IiwiQW5hbHl0aWNhbFJldmlzaW9uUGFnZSIsIl9jMjkiLCJfYzMwIiwiVGVzdFByb2Nlc3NQYWdlIiwiX2MzMSIsIl9jMzIiLCJMYXlvdXRCYWxhbmNlcyIsIl9jMzMiLCJfYzM0IiwiQmFja2xvZ01vbml0b3IiLCJfYzM1IiwiX2MzNiIsIkJhbGFuY2VTaGVldERldGFpbFBhZ2UiLCJfYzM3IiwiX2MzOCIsIkxlZGdlckFjY291bnRQYWdlIiwiX2MzOSIsIl9jNDAiLCJQcm9jZXNzT2NjdXJyZW5jZXMiLCJfYzQxIiwiX2M0MiIsIlByb2Nlc3NPY2N1cnJlbmNlc0RldGFpbHNQYWdlIiwiX2M0MyIsIl9jNDQiLCJSaXNrRm9ybSIsIl9jNDUiLCJfYzQ2IiwiUmlza0Zvcm1FZGl0IiwiX2M0NyIsIl9jNDgiLCJSaXNrRm9ybUZvcndhcmQiLCJfYzQ5IiwiX2M1MCIsIkF1ZGl0Umlza0Zvcm0iLCJfYzUxIiwiX2M1MiIsIkF1ZGl0Umlza0Zvcm1BbnN3ZXJzIiwiX2M1MyIsIl9jNTQiLCJBdWRpdG9ycyIsIl9jNTUiLCJfYzU2IiwiQXVkaXREb2N1bWVudHMiLCJfYzU3IiwiX2M1OCIsIkF1ZGl0TWF0ZXJpYWxpdHlQYWdlIiwiX2M1OSIsIl9jNjAiLCJUZXN0cyIsIl9jNjEiLCJfYzYyIiwiUGFyYW1ldGVycyIsIl9jNjMiLCJfYzY0IiwiUmlza0Rhc2giLCJfYzY1IiwiX2M2NiIsIlRlc3REaXN0cmlidXRpb24iLCJfYzY3IiwiX2M2OCIsIlZpc2l0U2NoZWR1bGVyIiwiX2M2OSIsIl9jNzAiLCJBcHByb3ZhbEZsb3dQYWdlIiwiX2M3MSIsIl9jNzIiLCJFeGVjdXRpb25UZXN0c1BhZ2UiLCJfYzczIiwiX2M3NCIsIk1hdGVyaWFsaXRpZXNQYWdlIiwiX2M3NSIsIl9jNzYiLCJUZXN0RGFzaGJvYXJkUGFnZSIsIl9jNzciLCJfYzc4IiwiQWRqdXN0bWVudEJhbGxvdHNQYWdlIiwiX2M3OSIsIl9jODAiLCJBZGp1c3RtZW50QmFsbG90c0RldGFpbHNQYWdlIiwiX2M4MSIsIl9jODIiLCJNZWV0aW5nTWludXRlIiwiX2M4MyIsIl9jODQiLCJXb3JrZmxvd3MiLCJfYzg1IiwiX2M4NiIsIk9waW5pb25EYXNoIiwiX2M4NyIsIl9jODgiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzT2xkUGFnZSIsIl9jODkiLCJfYzkwIiwiRmluYW5jaWFsU3RhdGVtZW50c1BhZ2UiLCJfYzkxIiwiX2M5MiIsIkZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnRQYWdlIiwiX2M5MyIsIl9jOTQiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljUGFnZSIsIl9jOTUiLCJfYzk2IiwiUGFnZVJvdXRlcyIsIl9zIiwic3RhcnQiLCJoYXNQZXJtaXNzaW9uIiwibGlua3NBZG1pbiIsImxpbmtzIiwiZmluZCIsIm5hdkxpbmsiLCJrZXkiLCJvbmx5QWRtaW4iLCJsaW5rc0Zpc2NhbCIsInVybCIsInBhdHJpbW9uaWFsIiwicmVzdWx0IiwiX2M5NyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2VSb3V0ZXMudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvcm91dGVzL1BhZ2VSb3V0ZXMudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIGxhenksIFN1c3BlbnNlLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBFcnJvclNjcmVlbiwgTG9hZGluZ1NjcmVlbiB9IGZyb20gJy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgbmF2TGlua0dyb3VwcyB9IGZyb20gJy4uL21vZHVsZXMvYWRtaW4vY29tcG9uZW50cydcbmltcG9ydCB7IGZpc2NhbExpbmtzIH0gZnJvbSAnLi4vbW9kdWxlcy9maXNjYWwvY29tcG9uZW50cydcbmltcG9ydCB7IFJvdXRlLCBOYXZpZ2F0ZSwgUm91dGVzIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IGFkbWluUlRDb250cm9sbGVyLCBhdWRpdFJUQ29udHJvbGxlciwgZmlzY2FsUlRDb250cm9sbGVyIH0gZnJvbSAnLi4vc2hhcmVkL3JlYWx0aW1lJ1xuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uL21vZHVsZXMvYXV0aC9ob29rcy9wZXJtaXNzaW9ucydcbmltcG9ydCB7IGFuYWx5dGljYWxSZXZpc2lvblR5cGUgfSBmcm9tICcuLi9tb2R1bGVzL2F1ZGl0L2FuYWx5dGljYWxSZXZpc2lvbi9lbnVtcy9hbmFseXRpY2FsUmV2aXNpb25UeXBlJ1xuaW1wb3J0IHsgQXVkaXRQcm9jZXNzaW5nIH0gZnJvbSAnLi4vbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cydcbmNvbnN0IFVzZXJzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vdXNlcnMvcGFnZXMvVXNlcnMnKSlcbmNvbnN0IFJ1bGVzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvZmlzY2FsL3J1bGVzL3BhZ2VzL1J1bGVzJykpXG5jb25zdCBSdWxlc1F1ZXJpZXMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9maXNjYWwvcnVsZXMvcGFnZXMvUnVsZXNRdWVyaWVzJykpXG5jb25zdCBPZmZpY2VzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vb2ZmaWNlcy9wYWdlcy9PZmZpY2VzJykpXG5jb25zdCBQcm9qZWN0VHlwZXMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9maXNjYWwvcHJvamVjdFR5cGVzL3BhZ2VzL1Byb2plY3RUeXBlcycpKVxuY29uc3QgUm9sZXMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hZG1pbi9yb2xlcy9wYWdlcy9Sb2xlcycpKVxuY29uc3QgUHJvZmlsZXMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hZG1pbi9wcm9maWxlcy9wYWdlcy9Qcm9maWxlcycpKVxuY29uc3QgQ2xpZW50cyA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2FkbWluL2NsaWVudHMvcGFnZXMvQ2xpZW50cycpKVxuY29uc3QgQ2xpZW50Q29tcGFuaWVzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vY2xpZW50cy9wYWdlcy9DbGllbnRDb21wYW5pZXMnKSlcbmNvbnN0IFByb2plY3RzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvZmlzY2FsL3Byb2plY3RzL3BhZ2VzL1Byb2plY3RzJykpXG5jb25zdCBQcm9qZWN0Q29uZmlndXJhdGlvbiA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2Zpc2NhbC9wcm9qZWN0cy9wYWdlcy9Qcm9qZWN0Q29uZmlndXJhdGlvbicpKVxuY29uc3QgQ29udHJhY3RzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL3BhZ2VzL0NvbnRyYWN0cycpKVxuY29uc3QgQ29udHJhY3RDb25maWd1cmF0aW9uID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL3BhZ2VzL0NvbnRyYWN0Q29uZmlndXJhdGlvbicpKVxuY29uc3QgQXVkaXRzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvYXVkaXRzL3BhZ2VzL0F1ZGl0cycpKVxuY29uc3QgQW5hbHl0aWNhbFJldmlzaW9uUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2FuYWx5dGljYWxSZXZpc2lvbi9wYWdlcy9BbmFseXRpY2FsUmV2aXNpb25QYWdlJykpXG5jb25zdCBUZXN0UHJvY2Vzc1BhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC90ZXN0UHJvY2Vzcy9wYWdlcy9UZXN0UHJvY2Vzc1BhZ2UnKSlcbmNvbnN0IExheW91dEJhbGFuY2VzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYWRtaW4vbGF5b3V0QmFsYW5jZS9wYWdlcy9MYXlvdXRCYWxhbmNlcycpKVxuY29uc3QgQmFja2xvZ01vbml0b3IgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hZG1pbi9iYWNrbG9nTW9uaXRvci9wYWdlcy9CYWNrbG9nTW9uaXRvcicpKVxuY29uc3QgQmFsYW5jZVNoZWV0RGV0YWlsUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2FkbWluL2JhbGFuY2UvcGFnZXMvQmFsYW5jZVNoZWV0RGV0YWlsUGFnZScpKVxuY29uc3QgTGVkZ2VyQWNjb3VudFBhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hZG1pbi9sZWRnZXJBY2NvdW50L3BhZ2VzL0xlZGdlckFjY291bnRQYWdlJykpXG5jb25zdCBQcm9jZXNzT2NjdXJyZW5jZXMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9maXNjYWwvcHJvamVjdHMvY29tcG9uZW50cy9wcm9jZXNzL3BhZ2VzL1Byb2Nlc3NPY2N1cnJlbmNlcycpKVxuY29uc3QgUHJvY2Vzc09jY3VycmVuY2VzRGV0YWlsc1BhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9maXNjYWwvcHJvamVjdHMvY29tcG9uZW50cy9wcm9jZXNzL3BhZ2VzL1Byb2Nlc3NPY2N1cnJlbmNlc0RldGFpbHNQYWdlJykpXG5jb25zdCBSaXNrRm9ybSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L3Jpc2tGb3JtL3BhZ2VzL1Jpc2tGb3JtJykpXG5jb25zdCBSaXNrRm9ybUVkaXQgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9yaXNrRm9ybS9wYWdlcy9SaXNrRm9ybUVkaXQnKSlcbmNvbnN0IFJpc2tGb3JtRm9yd2FyZCA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L3Jpc2tGb3JtL3BhZ2VzL1Jpc2tGb3JtRm9yd2FyZCcpKVxuY29uc3QgQXVkaXRSaXNrRm9ybSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2F1ZGl0c1Jpc2tGb3JtL3BhZ2VzL0F1ZGl0c1Jpc2tGb3JtJykpXG5jb25zdCBBdWRpdFJpc2tGb3JtQW5zd2VycyA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2F1ZGl0c1Jpc2tGb3JtL3BhZ2VzL0F1ZGl0c1Jpc2tGb3JtQW5zd2VycycpKVxuY29uc3QgQXVkaXRvcnMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9hdWRpdG9ycy9wYWdlcy9BdWRpdG9ycycpKVxuY29uc3QgQXVkaXREb2N1bWVudHMgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9kb2N1bWVudHMvcGFnZXMvQXVkaXREb2N1bWVudHMnKSlcbmNvbnN0IEF1ZGl0TWF0ZXJpYWxpdHlQYWdlID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvbWF0ZXJpYWxpdHkvcGFnZXMvQXVkaXRNYXRlcmlhbGl0eVBhZ2UnKSlcbmNvbnN0IFRlc3RzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvdGVzdFJlZ2lzdGVyL3BhZ2VzL1Rlc3RzJykpXG5jb25zdCBQYXJhbWV0ZXJzID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvcGFyYW1ldGVycy9wYWdlcy9QYXJhbWV0ZXJzJykpXG5jb25zdCBSaXNrRGFzaCA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L3Jpc2tEYXNoYm9hcmQvcGFnZXMvUmlza0Rhc2gnKSlcbmNvbnN0IFRlc3REaXN0cmlidXRpb24gPSBsYXp5KCgpID0+IGltcG9ydCgnLi8uLi9tb2R1bGVzL2F1ZGl0L3Rlc3REaXN0cmlidXRpb24vcGFnZXMvVGVzdERpc3RyaWJ1dGlvbicpKVxuY29uc3QgVmlzaXRTY2hlZHVsZXIgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC92aXNpdFNjaGVkdWxlci9wYWdlcy9WaXNpdFNjaGVkdWxlcicpKVxuY29uc3QgQXBwcm92YWxGbG93UGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLy4uL21vZHVsZXMvYXVkaXQvYXBwcm92YWxGbG93L3BhZ2VzL0FwcHJvdmFsRmxvd1BhZ2UnKSlcbmNvbnN0IEV4ZWN1dGlvblRlc3RzUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2V4ZWN1dGlvblRlc3RzL3BhZ2VzL0V4ZWN1dGlvblRlc3RzUGFnZScpKVxuY29uc3QgTWF0ZXJpYWxpdGllc1BhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9tYXRlcmlhbGl0eS9wYWdlcy9BdWRpdE1hdGVyaWFsaXR5Q29uZmlnUGFnZScpKVxuY29uc3QgVGVzdERhc2hib2FyZFBhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC90ZXN0RGFzaGJvYXJkL3BhZ2VzL1Rlc3REYXNoYm9hcmQnKSlcbmNvbnN0IEFkanVzdG1lbnRCYWxsb3RzUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2FkanVzdG1lbnRCYWxsb3RzL3BhZ2VzL0FkanVzdG1lbnRCYWxsb3RzUGFnZScpKVxuY29uc3QgQWRqdXN0bWVudEJhbGxvdHNEZXRhaWxzUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2FkanVzdG1lbnRCYWxsb3RzL3BhZ2VzL0FkanVzdG1lbnRCYWxsb3RzRGV0YWlsc1BhZ2UnKSlcbmNvbnN0IE1lZXRpbmdNaW51dGUgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9tZWV0aW5nTWludXRlL3BhZ2VzL01lZXRpbmdNaW51dGUnKSlcbmNvbnN0IFdvcmtmbG93cyA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L3dvcmtmbG93cy9wYWdlcy9Xb3JrZmxvd3MnKSlcbmNvbnN0IE9waW5pb25EYXNoID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvb3BpbmlvbkRhc2hib2FyZC9wYWdlcy9PcGluaW9uRGFzaCcpKVxuY29uc3QgRmluYW5jaWFsU3RhdGVtZW50c09sZFBhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9maW5hbmNpYWxTdGF0ZW1lbnRzL3BhZ2VzL0ZpbmFuY2lhbFN0YXRlbWVudHNPbGRQYWdlJykpXG5jb25zdCBGaW5hbmNpYWxTdGF0ZW1lbnRzUGFnZSA9IGxhenkoKCkgPT4gaW1wb3J0KCcuLi9tb2R1bGVzL2F1ZGl0L2ZpbmFuY2lhbFN0YXRlbWVudHMvcGFnZXMvRmluYW5jaWFsU3RhdGVtZW50c1BhZ2UnKSlcbmNvbnN0IEZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnRQYWdlID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4uL21vZHVsZXMvYXVkaXQvZmluYW5jaWFsU3RhdGVtZW50cy9wYWdlcy9GaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZScpKVxuY29uc3QgRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2UgPSBsYXp5KCgpID0+IGltcG9ydCgnLi4vbW9kdWxlcy9hdWRpdC9maW5hbmNpYWxTdGF0ZW1lbnRzL3BhZ2VzL0ZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlJykpXG5cbmNvbnN0IFBhZ2VSb3V0ZXM6IEZDID0gKCkgPT4ge1xuICBhZG1pblJUQ29udHJvbGxlci5zdGFydCgpXG4gIGF1ZGl0UlRDb250cm9sbGVyLnN0YXJ0KClcbiAgZmlzY2FsUlRDb250cm9sbGVyLnN0YXJ0KClcblxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcblxuICBjb25zdCBsaW5rc0FkbWluID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIG5hdkxpbmtHcm91cHNbMF0ubGlua3MuZmluZChuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5rZXkgYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicsIG5hdkxpbms/Lm9ubHlBZG1pbikpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGxpbmtzRmlzY2FsID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGZpc2NhbExpbmtzWzBdLmxpbmtzLmZpbmQobmF2TGluayA9PiBoYXNQZXJtaXNzaW9uKG5hdkxpbmsua2V5IGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInLCBuYXZMaW5rPy5vbmx5QWRtaW4pKVxuICB9LCBbXSlcbiAgcmV0dXJuIChcbiAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nU2NyZWVuIC8+fT5cbiAgICAgIDxSb3V0ZXM+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9Jy8nXG4gICAgICAgICAgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2JhY2tsb2ctbW9uaXRvclwiIHJlcGxhY2UvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD0nL2FkbWluJ1xuICAgICAgICAgIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz17bGlua3NBZG1pbj8udXJsIGFzIHN0cmluZyB8fCAnL2FkbWluL29mZmljZXMnfSByZXBsYWNlLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9Jy9maXNjYWwnXG4gICAgICAgICAgZWxlbWVudD17PE5hdmlnYXRlIHRvPXtsaW5rc0Zpc2NhbD8udXJsIGFzIHN0cmluZyB8fCAnL2Zpc2NhbC9wcm9qZWN0LXR5cGVzJ30gcmVwbGFjZS8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPScvYXVkaXQnXG4gICAgICAgICAgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2F1ZGl0L2F1ZGl0c1wiIHJlcGxhY2UvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIi9hZG1pbi9vZmZpY2VzXCJcbiAgICAgICAgICBlbGVtZW50PXs8T2ZmaWNlcyAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIi9hZG1pbi9yb2xlc1wiXG4gICAgICAgICAgZWxlbWVudD17PFJvbGVzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2FkbWluL2xheW91dEJhbGFuY2VcIlxuICAgICAgICAgIGVsZW1lbnQ9ezxMYXlvdXRCYWxhbmNlcyAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIi9hZG1pbi9wcm9maWxlc1wiXG4gICAgICAgICAgZWxlbWVudD17PFByb2ZpbGVzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2FkbWluL3VzZXJzXCJcbiAgICAgICAgICBlbGVtZW50PXs8VXNlcnMgLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9XCIvYWRtaW4vY2xpZW50c1wiXG4gICAgICAgICAgZWxlbWVudD17PENsaWVudHMgLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9eycvYWRtaW4vY2xpZW50cy86Y2xpZW50SWQvY29tcGFuaWVzJ31cbiAgICAgICAgICBlbGVtZW50PXs8Q2xpZW50Q29tcGFuaWVzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPXsnL2FkbWluL2NsaWVudC86Y2xpZW50SWQvY29tcGFuaWVzLzpjb21wYW55SWQvYmFsYW5jZXMvOmJhbGFuY2VTaGVldElkJ31cbiAgICAgICAgICBlbGVtZW50PXs8QmFsYW5jZVNoZWV0RGV0YWlsUGFnZSAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD17Jy9hZG1pbi9jbGllbnRzLzpjbGllbnRJZC9jb250cmFjdHMnfVxuICAgICAgICAgIGVsZW1lbnQ9ezxDb250cmFjdHMvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD17Jy9hZG1pbi9jbGllbnRzLzpjbGllbnRJZC9jb250cmFjdHMvOmNvbnRyYWN0SWQvKid9XG4gICAgICAgICAgZWxlbWVudD17PENvbnRyYWN0Q29uZmlndXJhdGlvbi8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2JhY2tsb2ctbW9uaXRvclwiXG4gICAgICAgICAgZWxlbWVudD17PEJhY2tsb2dNb25pdG9yIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2Zpc2NhbC9wcm9qZWN0LXR5cGVzXCJcbiAgICAgICAgICBlbGVtZW50PXs8UHJvamVjdFR5cGVzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2Zpc2NhbC9jb25maWctcnVsZXNcIlxuICAgICAgICAgIGVsZW1lbnQ9ezxSdWxlcyAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD17Jy9maXNjYWwvY29uZmlnLXJ1bGVzLzpydWxlSWQvcXVlcmllcyd9XG4gICAgICAgICAgZWxlbWVudD17PFJ1bGVzUXVlcmllcy8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2Zpc2NhbC9wcm9qZWN0c1wiXG4gICAgICAgICAgZWxlbWVudD17PFByb2plY3RzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPXsnL2Zpc2NhbC9wcm9qZWN0cy86cHJvamVjdElkL2VkaXQnfVxuICAgICAgICAgIGVsZW1lbnQ9ezxQcm9qZWN0Q29uZmlndXJhdGlvbi8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPXsnL2Zpc2NhbC9wcm9qZWN0cy86cHJvamVjdElkL2VkaXQvcHJvY2Vzcy86cHJvY2Vzc0lkL29jY3VycmVuY2VzJ31cbiAgICAgICAgICBlbGVtZW50PXs8UHJvY2Vzc09jY3VycmVuY2VzLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9eycvZmlzY2FsL3Byb2plY3RzLzpwcm9qZWN0SWQvZWRpdC9wcm9jZXNzLzpwcm9jZXNzSWQvb2NjdXJyZW5jZXMvOnJ1bGVJZCd9XG4gICAgICAgICAgZWxlbWVudD17PFByb2Nlc3NPY2N1cnJlbmNlc0RldGFpbHNQYWdlLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9XCIvYXVkaXQvYXVkaXRzXCJcbiAgICAgICAgICBlbGVtZW50PXs8QXVkaXRzIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2F1ZGl0L3Jpc2stZm9ybVwiXG4gICAgICAgICAgZWxlbWVudD17PFJpc2tGb3JtIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2F1ZGl0L3Rlc3RzXCJcbiAgICAgICAgICBlbGVtZW50PXs8VGVzdHMgLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9XCIvYXVkaXQvd29ya2Zsb3dzXCJcbiAgICAgICAgICBlbGVtZW50PXs8V29ya2Zsb3dzLz59XG4gICAgICAgIC8+XG4gICAgICAgIDxSb3V0ZVxuICAgICAgICAgIHBhdGg9XCIvYXVkaXQvcmlzay1mb3JtL2NyZWF0ZVwiXG4gICAgICAgICAgZWxlbWVudD17PFJpc2tGb3JtRWRpdCBpc0NyZWF0aW5nPXt0cnVlfSAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIi9hdWRpdC9yaXNrLWZvcm0vOnJpc2tGb3JtSWQvZWRpdFwiXG4gICAgICAgICAgZWxlbWVudD17PFJpc2tGb3JtRWRpdCBpc0NyZWF0aW5nPXtmYWxzZX0vPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD17Jy9maW5hbmNpYWwtc3RhdGVtZW50cyd9XG4gICAgICAgICAgZWxlbWVudD17PEZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9hdWRpdC9hdWRpdHMvOmF1ZGl0SWRcIiBlbGVtZW50PXs8QXVkaXRQcm9jZXNzaW5nIC8+fT5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCJjb250cm9sLXBhbmVsL29waW5pb25cIlxuICAgICAgICAgICAgZWxlbWVudD17PE9waW5pb25EYXNoIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiY29udHJvbC1wYW5lbC9kYXNoYm9hcmRcIlxuICAgICAgICAgICAgZWxlbWVudD17PFRlc3REYXNoYm9hcmRQYWdlIGlzQW5hbHlzaXM9e2ZhbHNlfS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiY29udHJvbC1wYW5lbC9wbGFubmluZy9yaXNrLWZvcm1cIlxuICAgICAgICAgICAgZWxlbWVudD17PEF1ZGl0Umlza0Zvcm0vPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD1cImNvbnRyb2wtcGFuZWwvcGxhbm5pbmcvZGFzaGJvYXJkXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9ezxSaXNrRGFzaC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiY29udHJvbC1wYW5lbC9wbGFubmluZy9yaXNrLWZvcm0vOmZvcm1JZC9hbnN3ZXJzXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBdWRpdFJpc2tGb3JtQW5zd2Vycy8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9wbGFubmluZy9wYXJhbWV0ZXJzJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxQYXJhbWV0ZXJzLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL3Rlc3QtZGlzdHJpYnV0aW9uJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxUZXN0RGlzdHJpYnV0aW9uLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL2FuYWx5dGljYWwtcmV2aXNpb24nfVxuICAgICAgICAgICAgZWxlbWVudD17PEFuYWx5dGljYWxSZXZpc2lvblBhZ2VcbiAgICAgICAgICAgICAgaXNBbmFseXRpY2FsUmV2aXNpb25cbiAgICAgICAgICAgIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9wbGFubmluZy9hdWRpdG9ycyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QXVkaXRvcnMvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvcGxhbm5pbmcvYXBwcm92YWwtZmxvdyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QXBwcm92YWxGbG93UGFnZS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9wbGFubmluZy9kb2N1bWVudHMnfVxuICAgICAgICAgICAgZWxlbWVudD17PEF1ZGl0RG9jdW1lbnRzLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL21hdGVyaWFsaXR5J31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBdWRpdE1hdGVyaWFsaXR5UGFnZS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9wbGFubmluZy92aXNpdC1zY2hlZHVsZXInfVxuICAgICAgICAgICAgZWxlbWVudD17PFZpc2l0U2NoZWR1bGVyLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL21hdGVyaWFsaXR5LzptYXRlcmlhbGl0eUlkJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxNYXRlcmlhbGl0aWVzUGFnZS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiY29udHJvbC1wYW5lbC86YXVkaXRNZW51L2Rhc2hib2FyZFwiXG4gICAgICAgICAgICBlbGVtZW50PXs8VGVzdERhc2hib2FyZFBhZ2UgaXNBbmFseXNpcz17dHJ1ZX0vPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvOmF1ZGl0TWVudS9maW5hbmNpYWwtc3RhdGVtZW50cy9vbGQnfVxuICAgICAgICAgICAgZWxlbWVudD17PEZpbmFuY2lhbFN0YXRlbWVudHNPbGRQYWdlIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC86YXVkaXRNZW51L2ZpbmFuY2lhbC1zdGF0ZW1lbnRzJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxGaW5hbmNpYWxTdGF0ZW1lbnRzUGFnZSAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvOmF1ZGl0TWVudS9maW5hbmNpYWwtc3RhdGVtZW50cy9kZXRhaWxzLzpmaW5hbmNpYWxJZCd9XG4gICAgICAgICAgICBlbGVtZW50PXs8RmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2UgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzL3BhdHJpbW9uaWFsLXRlc3RpbmcnfVxuICAgICAgICAgICAgZWxlbWVudD17PEFuYWx5dGljYWxSZXZpc2lvblBhZ2VcbiAgICAgICAgICAgICAgaXNBdWRpdFRlc3RpbmdcbiAgICAgICAgICAgICAgcmV2aXNpb25UeXBlPXthbmFseXRpY2FsUmV2aXNpb25UeXBlLnBhdHJpbW9uaWFsfVxuICAgICAgICAgICAgICBoaWRlTWVudVxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzL3Jlc3VsdHMtdGVzdGluZyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0F1ZGl0VGVzdGluZ1xuICAgICAgICAgICAgICByZXZpc2lvblR5cGU9e2FuYWx5dGljYWxSZXZpc2lvblR5cGUucmVzdWx0fVxuICAgICAgICAgICAgICBoaWRlTWVudVxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzL3BhdHJpbW9uaWFsLXRlc3RpbmcvOmdyb3VwVG9TaG93J31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBbmFseXRpY2FsUmV2aXNpb25QYWdlXG4gICAgICAgICAgICAgIGlzQXVkaXRUZXN0aW5nXG4gICAgICAgICAgICAgIHJldmlzaW9uVHlwZT17YW5hbHl0aWNhbFJldmlzaW9uVHlwZS5wYXRyaW1vbmlhbH1cbiAgICAgICAgICAgICAgaGlkZU1lbnVcbiAgICAgICAgICAgIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9hbmFseXNpcy9yZXN1bHRzLXRlc3RpbmcvOmdyb3VwVG9TaG93J31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBbmFseXRpY2FsUmV2aXNpb25QYWdlXG4gICAgICAgICAgICAgIGlzQXVkaXRUZXN0aW5nXG4gICAgICAgICAgICAgIHJldmlzaW9uVHlwZT17YW5hbHl0aWNhbFJldmlzaW9uVHlwZS5yZXN1bHR9XG4gICAgICAgICAgICAgIGhpZGVNZW51XG4gICAgICAgICAgICAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvcGF0cmltb25pYWwtdGVzdGluZy86Z3JvdXBUb1Nob3cvOmNvbXBhbnlJZC86Y29kZUFjYy86cGFnZSd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0F1ZGl0VGVzdGluZ1xuICAgICAgICAgICAgICByZXZpc2lvblR5cGU9e2FuYWx5dGljYWxSZXZpc2lvblR5cGUucGF0cmltb25pYWx9XG4gICAgICAgICAgICAgIGhpZGVNZW51XG4gICAgICAgICAgICAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvcmVzdWx0cy10ZXN0aW5nLzpncm91cFRvU2hvdy86Y29tcGFueUlkLzpjb2RlQWNjLzpwYWdlJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBbmFseXRpY2FsUmV2aXNpb25QYWdlXG4gICAgICAgICAgICAgIGlzQXVkaXRUZXN0aW5nXG4gICAgICAgICAgICAgIHJldmlzaW9uVHlwZT17YW5hbHl0aWNhbFJldmlzaW9uVHlwZS5yZXN1bHR9XG4gICAgICAgICAgICAgIGhpZGVNZW51XG4gICAgICAgICAgICAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvOmF1ZGl0TWVudS86dGVzdFByb2Nlc3NUeXBlL3Rlc3RzLzp2aXNpb25UeXBlLzp0ZXN0SWQvKid9XG4gICAgICAgICAgICBlbGVtZW50PXs8RXhlY3V0aW9uVGVzdHNQYWdlIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC86YXVkaXRNZW51Lzp0ZXN0UHJvY2Vzc1R5cGUnfVxuICAgICAgICAgICAgZWxlbWVudD17PFRlc3RQcm9jZXNzUGFnZSAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvOnJldmlzaW9uUGF0aFR5cGUvOmdyb3VwVG9TaG93Lzpjb21wYW55SWQvOmNvZGVBY2MvdGVzdHMvOnZpc2lvblR5cGUvOnRlc3RJZC8qJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxFeGVjdXRpb25UZXN0c1BhZ2UgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2NvbW11bmljYXRpb24vYWRqdXN0bWVudC1iYWxsb3QnfVxuICAgICAgICAgICAgZWxlbWVudD17PEFkanVzdG1lbnRCYWxsb3RzUGFnZS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9jb21tdW5pY2F0aW9uL2FkanVzdG1lbnQtYmFsbG90LzphZGp1c3RtZW50QmFsbG90SWQnfVxuICAgICAgICAgICAgZWxlbWVudD17PEFkanVzdG1lbnRCYWxsb3RzRGV0YWlsc1BhZ2UvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvY29tbXVuaWNhdGlvbi9tZWV0aW5nLW1pbnV0ZXMnfVxuICAgICAgICAgICAgZWxlbWVudD17PE1lZXRpbmdNaW51dGUvPn1cbiAgICAgICAgICAvPjxSb3V0ZVxuICAgICAgICAgICAgcGF0aD1cImNvbnRyb2wtcGFuZWwvb3BpbmlvblwiXG4gICAgICAgICAgICBlbGVtZW50PXs8T3BpbmlvbkRhc2ggLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCJjb250cm9sLXBhbmVsL2Rhc2hib2FyZFwiXG4gICAgICAgICAgICBlbGVtZW50PXs8VGVzdERhc2hib2FyZFBhZ2UgaXNBbmFseXNpcz17ZmFsc2V9Lz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCJjb250cm9sLXBhbmVsL3BsYW5uaW5nL3Jpc2stZm9ybVwiXG4gICAgICAgICAgICBlbGVtZW50PXs8QXVkaXRSaXNrRm9ybS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiY29udHJvbC1wYW5lbC9wbGFubmluZy9kYXNoYm9hcmRcIlxuICAgICAgICAgICAgZWxlbWVudD17PFJpc2tEYXNoLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCJjb250cm9sLXBhbmVsL3BsYW5uaW5nL3Jpc2stZm9ybS86Zm9ybUlkL2Fuc3dlcnNcIlxuICAgICAgICAgICAgZWxlbWVudD17PEF1ZGl0Umlza0Zvcm1BbnN3ZXJzLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL3BhcmFtZXRlcnMnfVxuICAgICAgICAgICAgZWxlbWVudD17PFBhcmFtZXRlcnMvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvcGxhbm5pbmcvdGVzdC1kaXN0cmlidXRpb24nfVxuICAgICAgICAgICAgZWxlbWVudD17PFRlc3REaXN0cmlidXRpb24vPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvcGxhbm5pbmcvYW5hbHl0aWNhbC1yZXZpc2lvbid9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0FuYWx5dGljYWxSZXZpc2lvblxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL2F1ZGl0b3JzJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBdWRpdG9ycy8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9wbGFubmluZy9hcHByb3ZhbC1mbG93J31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBcHByb3ZhbEZsb3dQYWdlLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL2RvY3VtZW50cyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QXVkaXREb2N1bWVudHMvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvcGxhbm5pbmcvbWF0ZXJpYWxpdHknfVxuICAgICAgICAgICAgZWxlbWVudD17PEF1ZGl0TWF0ZXJpYWxpdHlQYWdlLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL3BsYW5uaW5nL3Zpc2l0LXNjaGVkdWxlcid9XG4gICAgICAgICAgICBlbGVtZW50PXs8VmlzaXRTY2hlZHVsZXIvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvcGxhbm5pbmcvbWF0ZXJpYWxpdHkvOm1hdGVyaWFsaXR5SWQnfVxuICAgICAgICAgICAgZWxlbWVudD17PE1hdGVyaWFsaXRpZXNQYWdlLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCJjb250cm9sLXBhbmVsLzphdWRpdE1lbnUvZGFzaGJvYXJkXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9ezxUZXN0RGFzaGJvYXJkUGFnZSBpc0FuYWx5c2lzPXt0cnVlfS8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9hbmFseXNpcy9wYXRyaW1vbmlhbC10ZXN0aW5nJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBbmFseXRpY2FsUmV2aXNpb25QYWdlXG4gICAgICAgICAgICAgIGlzQXVkaXRUZXN0aW5nXG4gICAgICAgICAgICAgIHJldmlzaW9uVHlwZT17YW5hbHl0aWNhbFJldmlzaW9uVHlwZS5wYXRyaW1vbmlhbH1cbiAgICAgICAgICAgICAgaGlkZU1lbnVcbiAgICAgICAgICAgIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9hbmFseXNpcy9yZXN1bHRzLXRlc3RpbmcnfVxuICAgICAgICAgICAgZWxlbWVudD17PEFuYWx5dGljYWxSZXZpc2lvblBhZ2VcbiAgICAgICAgICAgICAgaXNBdWRpdFRlc3RpbmdcbiAgICAgICAgICAgICAgcmV2aXNpb25UeXBlPXthbmFseXRpY2FsUmV2aXNpb25UeXBlLnJlc3VsdH1cbiAgICAgICAgICAgICAgaGlkZU1lbnVcbiAgICAgICAgICAgIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9hbmFseXNpcy9wYXRyaW1vbmlhbC10ZXN0aW5nLzpncm91cFRvU2hvdyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0F1ZGl0VGVzdGluZ1xuICAgICAgICAgICAgICByZXZpc2lvblR5cGU9e2FuYWx5dGljYWxSZXZpc2lvblR5cGUucGF0cmltb25pYWx9XG4gICAgICAgICAgICAgIGhpZGVNZW51XG4gICAgICAgICAgICAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvcmVzdWx0cy10ZXN0aW5nLzpncm91cFRvU2hvdyd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0F1ZGl0VGVzdGluZ1xuICAgICAgICAgICAgICByZXZpc2lvblR5cGU9e2FuYWx5dGljYWxSZXZpc2lvblR5cGUucmVzdWx0fVxuICAgICAgICAgICAgICBoaWRlTWVudVxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzL3BhdHJpbW9uaWFsLXRlc3RpbmcvOmdyb3VwVG9TaG93Lzpjb21wYW55SWQvOmNvZGVBY2MvOnBhZ2UnfVxuICAgICAgICAgICAgZWxlbWVudD17PEFuYWx5dGljYWxSZXZpc2lvblBhZ2VcbiAgICAgICAgICAgICAgaXNBdWRpdFRlc3RpbmdcbiAgICAgICAgICAgICAgcmV2aXNpb25UeXBlPXthbmFseXRpY2FsUmV2aXNpb25UeXBlLnBhdHJpbW9uaWFsfVxuICAgICAgICAgICAgICBoaWRlTWVudVxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzL3Jlc3VsdHMtdGVzdGluZy86Z3JvdXBUb1Nob3cvOmNvbXBhbnlJZC86Y29kZUFjYy86cGFnZSd9XG4gICAgICAgICAgICBlbGVtZW50PXs8QW5hbHl0aWNhbFJldmlzaW9uUGFnZVxuICAgICAgICAgICAgICBpc0F1ZGl0VGVzdGluZ1xuICAgICAgICAgICAgICByZXZpc2lvblR5cGU9e2FuYWx5dGljYWxSZXZpc2lvblR5cGUucmVzdWx0fVxuICAgICAgICAgICAgICBoaWRlTWVudVxuICAgICAgICAgICAgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsLzphdWRpdE1lbnUvOnRlc3RQcm9jZXNzVHlwZS90ZXN0cy86dmlzaW9uVHlwZS86dGVzdElkLyonfVxuICAgICAgICAgICAgZWxlbWVudD17PEV4ZWN1dGlvblRlc3RzUGFnZSAvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvOmF1ZGl0TWVudS86dGVzdFByb2Nlc3NUeXBlJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxUZXN0UHJvY2Vzc1BhZ2UgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2FuYWx5c2lzLzpyZXZpc2lvblBhdGhUeXBlLzpncm91cFRvU2hvdy86Y29tcGFueUlkLzpjb2RlQWNjL3Rlc3RzLzp2aXNpb25UeXBlLzp0ZXN0SWQvKid9XG4gICAgICAgICAgICBlbGVtZW50PXs8RXhlY3V0aW9uVGVzdHNQYWdlIC8+fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPXsnY29udHJvbC1wYW5lbC9jb21tdW5pY2F0aW9uL2FkanVzdG1lbnQtYmFsbG90J31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBZGp1c3RtZW50QmFsbG90c1BhZ2UvPn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxSb3V0ZVxuICAgICAgICAgICAgcGF0aD17J2NvbnRyb2wtcGFuZWwvY29tbXVuaWNhdGlvbi9hZGp1c3RtZW50LWJhbGxvdC86YWRqdXN0bWVudEJhbGxvdElkJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxBZGp1c3RtZW50QmFsbG90c0RldGFpbHNQYWdlLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9eydjb250cm9sLXBhbmVsL2NvbW11bmljYXRpb24vbWVldGluZy1taW51dGVzJ31cbiAgICAgICAgICAgIGVsZW1lbnQ9ezxNZWV0aW5nTWludXRlLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD17Jy9hZG1pbi9jbGllbnRzLzpjbGllbnRJZC9jb21wYW5pZXMvOmNvbXBhbnlJZC9jaGFydC1vZi1hY2NvdW50cy86Y2hhcnRPZkFjY291bnRzSWQnfVxuICAgICAgICAgIGVsZW1lbnQ9ezxMZWRnZXJBY2NvdW50UGFnZS8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2JhY2tsb2ctbW9uaXRvclwiXG4gICAgICAgICAgZWxlbWVudD17PEJhY2tsb2dNb25pdG9yIC8+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL2Zvcm0tbGlzdFwiXG4gICAgICAgICAgZWxlbWVudD17PFJpc2tGb3JtRm9yd2FyZCAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD0nL2F1dGgnXG4gICAgICAgICAgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIipcIlxuICAgICAgICAgIGVsZW1lbnQ9ezxFcnJvclNjcmVlbiB0eXBlPVwibm90Rm91bmRcIiAvPn1cbiAgICAgICAgLz5cbiAgICAgIDwvUm91dGVzPlxuICAgIDwvU3VzcGVuc2U+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGFnZVJvdXRlc1xuIl19