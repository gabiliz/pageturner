import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-YNY3AOFZ.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
