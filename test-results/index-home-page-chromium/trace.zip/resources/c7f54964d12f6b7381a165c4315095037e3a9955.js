import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileActions.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"];
import { CommandButton, PrimaryButton, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
const ProfileActions = (props) => {
  _s();
  const {
    disabledRemoveButton,
    onAdd,
    onRemove,
    disabledAddButton,
    deletePermission,
    createPermission
  } = props;
  const tooltipText = useCallback(() => {
    return disabledAddButton ? "Todos os níveis foram selecionados" : "";
  }, [disabledAddButton]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(TooltipHost, { content: tooltipText(), id: "add-flow-dropdown-tooltip", children: createPermission && /* @__PURE__ */ jsxDEV(PrimaryButton, { iconProps: {
      iconName: "Add",
      style: {
        fontSize: 14
      }
    }, text: "Adicionar", onClick: onAdd, disabled: disabledAddButton }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx",
      lineNumber: 27,
      columnNumber: 30
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    deletePermission && /* @__PURE__ */ jsxDEV(CommandButton, { iconProps: {
      iconName: "Trash",
      style: {
        fontSize: 14
      }
    }, text: "Excluir", disabled: disabledRemoveButton, onClick: onRemove }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx",
      lineNumber: 34,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_s(ProfileActions, "QY/GdCTSqV+IYHYCE2iB/CyHSmo=");
_c = ProfileActions;
export default ProfileActions;
var _c;
$RefreshReg$(_c, "ProfileActions");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJJLG1CQUt5QixjQUx6Qjs7Ozs7Ozs7Ozs7Ozs7OztBQTdCSixTQUFhQSxtQkFBbUI7QUFDaEMsU0FBU0MsZUFBZUMsZUFBZUMsbUJBQW1CO0FBVzFELE1BQU1DLGlCQUEyQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3pELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlQO0FBRUosUUFBTVEsY0FBY2IsWUFBWSxNQUFNO0FBQ3BDLFdBQU9VLG9CQUNILHVDQUNBO0FBQUEsRUFDTixHQUFHLENBQUNBLGlCQUFpQixDQUFDO0FBRXRCLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxlQUNDLFNBQVNHLFlBQVksR0FDckIsSUFBRyw2QkFFRkQsOEJBQW9CLHVCQUFDLGlCQUNwQixXQUFXO0FBQUEsTUFBRUUsVUFBVTtBQUFBLE1BQU9DLE9BQU87QUFBQSxRQUFFQyxVQUFVO0FBQUEsTUFBRztBQUFBLElBQUUsR0FDdEQsTUFBSyxhQUNMLFNBQVNSLE9BQ1QsVUFBVUUscUJBSlM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlTLEtBUmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0NDLG9CQUFvQix1QkFBQyxpQkFDcEIsV0FBVztBQUFBLE1BQUVHLFVBQVU7QUFBQSxNQUFTQyxPQUFPO0FBQUEsUUFBRUMsVUFBVTtBQUFBLE1BQUc7QUFBQSxJQUFFLEdBQ3hELE1BQUssV0FDTCxVQUFVVCxzQkFDVixTQUFTRSxZQUpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJRDtBQUFBLE9BaEJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBO0FBRUo7QUFBQ0gsR0FyQ0tGLGdCQUF1QztBQUFBYSxLQUF2Q2I7QUF1Q04sZUFBZUE7QUFBYyxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJDb21tYW5kQnV0dG9uIiwiUHJpbWFyeUJ1dHRvbiIsIlRvb2x0aXBIb3N0IiwiUHJvZmlsZUFjdGlvbnMiLCJwcm9wcyIsIl9zIiwiZGlzYWJsZWRSZW1vdmVCdXR0b24iLCJvbkFkZCIsIm9uUmVtb3ZlIiwiZGlzYWJsZWRBZGRCdXR0b24iLCJkZWxldGVQZXJtaXNzaW9uIiwiY3JlYXRlUGVybWlzc2lvbiIsInRvb2x0aXBUZXh0IiwiaWNvbk5hbWUiLCJzdHlsZSIsImZvbnRTaXplIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlQWN0aW9ucy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3Byb2ZpbGVzL2NvbXBvbmVudHMvUHJvZmlsZUFjdGlvbnMudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDb21tYW5kQnV0dG9uLCBQcmltYXJ5QnV0dG9uLCBUb29sdGlwSG9zdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5pbnRlcmZhY2UgUHJvZmlsZUFjdGlvbnNQcm9wcyB7XG4gIGRpc2FibGVkUmVtb3ZlQnV0dG9uOiBib29sZWFuXG4gIGRpc2FibGVkQWRkQnV0dG9uPzogYm9vbGVhblxuICBvbkFkZDogKCkgPT4gdm9pZFxuICBvblJlbW92ZTogKCkgPT4gdm9pZFxuICBkZWxldGVQZXJtaXNzaW9uOiBib29sZWFuXG4gIGNyZWF0ZVBlcm1pc3Npb246IGJvb2xlYW5cbn1cblxuY29uc3QgUHJvZmlsZUFjdGlvbnM6IEZDPFByb2ZpbGVBY3Rpb25zUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBkaXNhYmxlZFJlbW92ZUJ1dHRvbixcbiAgICBvbkFkZCxcbiAgICBvblJlbW92ZSxcbiAgICBkaXNhYmxlZEFkZEJ1dHRvbixcbiAgICBkZWxldGVQZXJtaXNzaW9uLFxuICAgIGNyZWF0ZVBlcm1pc3Npb24sXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IHRvb2x0aXBUZXh0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBkaXNhYmxlZEFkZEJ1dHRvblxuICAgICAgPyAnVG9kb3Mgb3MgbsOtdmVpcyBmb3JhbSBzZWxlY2lvbmFkb3MnXG4gICAgICA6ICcnXG4gIH0sIFtkaXNhYmxlZEFkZEJ1dHRvbl0pXG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFRvb2x0aXBIb3N0XG4gICAgICAgIGNvbnRlbnQ9e3Rvb2x0aXBUZXh0KCl9XG4gICAgICAgIGlkPSdhZGQtZmxvdy1kcm9wZG93bi10b29sdGlwJ1xuICAgICAgPlxuICAgICAgICB7Y3JlYXRlUGVybWlzc2lvbiAmJiA8UHJpbWFyeUJ1dHRvblxuICAgICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0FkZCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICAgICAgdGV4dD1cIkFkaWNpb25hclwiXG4gICAgICAgICAgb25DbGljaz17b25BZGR9XG4gICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkQWRkQnV0dG9ufVxuICAgICAgICAvPn1cbiAgICAgIDwvVG9vbHRpcEhvc3Q+XG4gICAgICB7ZGVsZXRlUGVybWlzc2lvbiAmJiA8Q29tbWFuZEJ1dHRvblxuICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdUcmFzaCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICAgIHRleHQ9XCJFeGNsdWlyXCJcbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkUmVtb3ZlQnV0dG9ufVxuICAgICAgICBvbkNsaWNrPXtvblJlbW92ZX1cbiAgICAgIC8+fVxuICAgIDwvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVBY3Rpb25zXG4iXX0=