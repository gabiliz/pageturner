import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/roles/components/RolesDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RolesDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { roleQueryService as service } from "/src/modules/admin/roles/services/index.ts";
const RolesDropdown = (props) => {
  _s();
  const {
    label,
    styles,
    disabled = false
  } = props;
  const {
    data
  } = service.useFindAllPaginated();
  const options = useMemo(() => data?.value.map((role) => ({
    key: role.id,
    text: role.nome
  })) ?? [], [data]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { label, allowFreeform: true, autoComplete: "on", options, disabled, styles, calloutProps: {
    calloutMinWidth: 80
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RolesDropdown.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_s(RolesDropdown, "NSJ1gXFGWIyWJXFNGs+sZgixTAk=", false, function() {
  return [service.useFindAllPaginated];
});
_c = RolesDropdown;
export default RolesDropdown;
var _c;
$RefreshReg$(_c, "RolesDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RolesDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJKLFNBQWFBLGVBQWU7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQkMsZUFBZTtBQVE1QyxNQUFNQyxnQkFBZ0NBLENBQUNDLFVBQXNCO0FBQUFDLEtBQUE7QUFDM0QsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVc7QUFBQSxFQUNiLElBQUlKO0FBRUosUUFBTTtBQUFBLElBQUVLO0FBQUFBLEVBQUssSUFBSVAsUUFBUVEsb0JBQW9CO0FBRTdDLFFBQU1DLFVBQVVaLFFBQ2QsTUFBTVUsTUFBTUcsTUFBTUMsSUFBSUMsV0FBUztBQUFBLElBQzdCQyxLQUFLRCxLQUFLRTtBQUFBQSxJQUNWQyxNQUFNSCxLQUFLSTtBQUFBQSxFQUNiLEVBQUUsS0FBSyxJQUNQLENBQUNULElBQUksQ0FDUDtBQUVBLFNBQ0UsdUJBQUMsWUFDQyxPQUNBLGVBQWUsTUFDZixjQUFhLE1BQ2IsU0FDQSxVQUNBLFFBQ0EsY0FBYztBQUFBLElBQ1pVLGlCQUFpQjtBQUFBLEVBQ25CLEdBQ0EsR0FBSWYsU0FWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVVk7QUFHaEI7QUFBQ0MsR0EvQktGLGVBQTZCO0FBQUEsVUFPaEJELFFBQVFRLG1CQUFtQjtBQUFBO0FBQUFVLEtBUHhDakI7QUFpQ04sZUFBZUE7QUFBYSxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJDb21ib0JveCIsInJvbGVRdWVyeVNlcnZpY2UiLCJzZXJ2aWNlIiwiUm9sZXNEcm9wZG93biIsInByb3BzIiwiX3MiLCJsYWJlbCIsInN0eWxlcyIsImRpc2FibGVkIiwiZGF0YSIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCJvcHRpb25zIiwidmFsdWUiLCJtYXAiLCJyb2xlIiwia2V5IiwiaWQiLCJ0ZXh0Iiwibm9tZSIsImNhbGxvdXRNaW5XaWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUm9sZXNEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3JvbGVzL2NvbXBvbmVudHMvUm9sZXNEcm9wZG93bi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJQ29tYm9Cb3hQcm9wcywgSUNvbWJvQm94U3R5bGVzLCBJRHJvcGRvd25PcHRpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQ29tYm9Cb3ggfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IHJvbGVRdWVyeVNlcnZpY2UgYXMgc2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xuXG5pbnRlcmZhY2UgUm9sZXNQcm9wcyBleHRlbmRzIFBhcnRpYWw8SUNvbWJvQm94UHJvcHM+IHtcbiAgbGFiZWw/OiBzdHJpbmdcbiAgZGlzYWJsZWQ/OiBib29sZWFuXG4gIHN0eWxlcz86IFBhcnRpYWw8SUNvbWJvQm94U3R5bGVzPlxufVxuXG5jb25zdCBSb2xlc0Ryb3Bkb3duOiBGQzxSb2xlc1Byb3BzPiA9IChwcm9wczogUm9sZXNQcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgbGFiZWwsXG4gICAgc3R5bGVzLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IHsgZGF0YSB9ID0gc2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKClcblxuICBjb25zdCBvcHRpb25zID0gdXNlTWVtbzxJRHJvcGRvd25PcHRpb25bXT4oXG4gICAgKCkgPT4gZGF0YT8udmFsdWUubWFwKHJvbGUgPT4gKHtcbiAgICAgIGtleTogcm9sZS5pZCBhcyBzdHJpbmcsXG4gICAgICB0ZXh0OiByb2xlLm5vbWUsXG4gICAgfSkpID8/IFtdLFxuICAgIFtkYXRhXSxcbiAgKVxuXG4gIHJldHVybiAoXG4gICAgPENvbWJvQm94XG4gICAgICBsYWJlbD17bGFiZWx9XG4gICAgICBhbGxvd0ZyZWVmb3JtPXt0cnVlfVxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcbiAgICAgIG9wdGlvbnM9e29wdGlvbnN9XG4gICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICBzdHlsZXM9e3N0eWxlc31cbiAgICAgIGNhbGxvdXRQcm9wcz17e1xuICAgICAgICBjYWxsb3V0TWluV2lkdGg6IDgwLFxuICAgICAgfX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFJvbGVzRHJvcGRvd25cbiJdfQ==