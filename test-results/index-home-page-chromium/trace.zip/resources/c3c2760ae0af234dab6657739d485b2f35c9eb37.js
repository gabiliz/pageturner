import {
  FLUENT_CDN_BASE_URL,
  registerIcons
} from "/node_modules/.vite/deps/chunk-XOB7MPSE.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-2EIJ3ZL6.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-JYWLVXGS.js?v=9f90a7ff";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@fluentui/react-file-type-icons/lib/initializeFileTypeIcons.js
var React = __toESM(require_react());

// node_modules/@fluentui/react-file-type-icons/lib/FileTypeIconMap.js
var FileTypeIconMap = {
  accdb: {
    extensions: ["accdb", "mdb"]
  },
  archive: {
    extensions: ["7z", "ace", "arc", "arj", "dmg", "gz", "iso", "lzh", "pkg", "rar", "sit", "tgz", "tar", "z"]
  },
  audio: {
    extensions: [
      "aif",
      "aiff",
      "aac",
      "alac",
      "amr",
      "ape",
      "au",
      "awb",
      "dct",
      "dss",
      "dvf",
      "flac",
      "gsm",
      "m4a",
      "m4p",
      "mid",
      "mmf",
      "mp3",
      "oga",
      "ra",
      "rm",
      "wav",
      "wma",
      "wv"
    ]
  },
  calendar: {
    extensions: ["ical", "icalendar", "ics", "ifb", "vcs"]
  },
  classifier: {
    extensions: ["classifier"]
  },
  clipchamp: {
    extensions: ["clipchamp"]
  },
  code: {
    extensions: [
      "abap",
      "ada",
      "adp",
      "ahk",
      "as",
      "as3",
      "asc",
      "ascx",
      "asm",
      "asp",
      "awk",
      "bash",
      "bash_login",
      "bash_logout",
      "bash_profile",
      "bashrc",
      "bat",
      "bib",
      "bsh",
      "build",
      "builder",
      "c",
      "cbl",
      "c++",
      "capfile",
      "cc",
      "cfc",
      "cfm",
      "cfml",
      "cl",
      "clj",
      "cls",
      "cmake",
      "cmd",
      "coffee",
      "config",
      "cpp",
      "cpt",
      "cpy",
      "cs",
      "cshtml",
      "cson",
      "csproj",
      "css",
      "ctp",
      "cxx",
      "d",
      "ddl",
      "di",
      "disco",
      "dml",
      "dtd",
      "dtml",
      "el",
      "emakefile",
      "erb",
      "erl",
      "f",
      "f90",
      "f95",
      "fs",
      "fsi",
      "fsscript",
      "fsx",
      "gemfile",
      "gemspec",
      "gitconfig",
      "go",
      "groovy",
      "gvy",
      "h",
      "h++",
      "haml",
      "handlebars",
      "hbs",
      "hcp",
      "hh",
      "hpp",
      "hrl",
      "hs",
      "htc",
      "hxx",
      "idl",
      "iim",
      "inc",
      "inf",
      "ini",
      "inl",
      "ipp",
      "irbrc",
      "jade",
      "jav",
      "java",
      "js",
      "json",
      "jsp",
      "jsproj",
      "jsx",
      "l",
      "less",
      "lhs",
      "lisp",
      "log",
      "lst",
      "ltx",
      "lua",
      "m",
      "mak",
      "make",
      "manifest",
      "master",
      "md",
      "markdn",
      "markdown",
      "mdown",
      "mkdn",
      "ml",
      "mli",
      "mll",
      "mly",
      "mm",
      "mud",
      "nfo",
      "opml",
      "osascript",
      "p",
      "pas",
      "patch",
      "php",
      "php2",
      "php3",
      "php4",
      "php5",
      "phtml",
      "pl",
      "pm",
      "pod",
      "pp",
      "profile",
      "ps1",
      "ps1xml",
      "psd1",
      "psm1",
      "pss",
      "pt",
      "py",
      "pyw",
      "r",
      "rake",
      "rb",
      "rbx",
      "rc",
      "rdf",
      "re",
      "reg",
      "rest",
      "resw",
      "resx",
      "rhtml",
      "rjs",
      "rprofile",
      "rpy",
      "rss",
      "rst",
      "ruby",
      "rxml",
      "s",
      "sass",
      "scala",
      "scm",
      "sconscript",
      "sconstruct",
      "script",
      "scss",
      "sgml",
      "sh",
      "shtml",
      "sml",
      "svn-base",
      "swift",
      "sql",
      "sty",
      "tcl",
      "tex",
      "textile",
      "tld",
      "tli",
      "tmpl",
      "tpl",
      "vb",
      "vi",
      "vim",
      "vmg",
      "webpart",
      "wsp",
      "wsdl",
      "xhtml",
      "xoml",
      "xsd",
      "xslt",
      "yaml",
      "yaws",
      "yml",
      "zsh"
    ]
  },
  contact: {
    extensions: ["vcf"]
  },
  /*  css: {},  not broken out yet, snapping to 'code' for now */
  csv: {
    extensions: ["csv"]
  },
  desktopfolder: {},
  docset: {},
  documentsfolder: {},
  docx: {
    extensions: ["doc", "docm", "docx", "docb"]
  },
  dotx: {
    extensions: ["dot", "dotm", "dotx"]
  },
  email: {
    extensions: ["eml", "msg", "oft", "ost", "pst"]
  },
  exe: {
    extensions: ["application", "appref-ms", "apk", "app", "appx", "exe", "ipa", "msi", "xap"]
  },
  favoritesfolder: {},
  folder: {},
  font: {
    extensions: ["ttf", "otf", "woff"]
  },
  form: {},
  genericfile: {},
  html: {
    extensions: ["htm", "html", "mht"]
  },
  ipynb: {
    extensions: ["nnb", "ipynb"]
  },
  link: {
    extensions: ["lnk", "link", "url", "website", "webloc"]
  },
  linkedfolder: {},
  listitem: {},
  loop: {
    extensions: ["fluid", "loop", "note"]
  },
  loopworkspace: {},
  officescript: {
    extensions: ["osts"]
  },
  splist: {},
  model: {
    extensions: [
      "3ds",
      "3mf",
      "blend",
      "cool",
      "dae",
      "df",
      "dwfx",
      "dwg",
      "dxf",
      "fbx",
      "glb",
      "gltf",
      "holo",
      "layer",
      "layout",
      "max",
      "mcworld",
      "mtl",
      "obj",
      "off",
      "ply",
      "skp",
      "stp",
      "stl",
      "t",
      "thl",
      "x"
    ]
  },
  mpp: {
    extensions: ["mpp"]
  },
  mpt: {
    extensions: ["mpt"]
  },
  multiple: {},
  one: {
    // This is a partial OneNote page or section export. Not whole notebooks, see "onetoc"
    extensions: ["one"]
  },
  onetoc: {
    // This is an entire OneNote notebook.
    extensions: ["ms-one-stub", "onetoc", "onetoc2", "onepkg"]
    // This represents a complete, logical notebook.
  },
  pbiapp: {},
  pdf: {
    extensions: ["pdf"]
  },
  photo: {
    extensions: [
      "arw",
      "bmp",
      "cr2",
      "crw",
      "dic",
      "dicm",
      "dcm",
      "dcm30",
      "dcr",
      "dds",
      "dib",
      "dng",
      "erf",
      "gif",
      "heic",
      "heif",
      "ico",
      "jfi",
      "jfif",
      "jif",
      "jpe",
      "jpeg",
      "jpg",
      "jxr",
      "kdc",
      "mrw",
      "nef",
      "orf",
      "pct",
      "pict",
      "png",
      "pns",
      "psb",
      "psd",
      "raw",
      "tga",
      "tif",
      "tiff",
      "wdp"
    ]
  },
  photo360: {},
  picturesfolder: {},
  potx: {
    extensions: ["pot", "potm", "potx"]
  },
  powerbi: {
    extensions: ["pbids", "pbix"]
  },
  ppsx: {
    extensions: ["pps", "ppsm", "ppsx"]
  },
  pptx: {
    extensions: ["ppt", "pptm", "pptx", "sldx", "sldm"]
  },
  presentation: {
    extensions: ["odp", "gslides", "key"]
  },
  pub: {
    extensions: ["pub"]
  },
  spo: {
    extensions: ["aspx"]
  },
  sponews: {},
  spreadsheet: {
    extensions: ["odc", "ods", "gsheet", "numbers", "tsv"]
  },
  rtf: {
    extensions: ["epub", "gdoc", "odt", "rtf", "wri", "pages"]
  },
  sharedfolder: {},
  playlist: {},
  sway: {},
  sysfile: {
    extensions: [
      "bak",
      "bin",
      "cab",
      "cache",
      "cat",
      "cer",
      "class",
      "dat",
      "db",
      "dbg",
      "dl_",
      "dll",
      "ithmb",
      "jar",
      "kb",
      "ldt",
      "lrprev",
      "pkpass",
      "ppa",
      "ppam",
      "pdb",
      "rom",
      "thm",
      "thmx",
      "vsl",
      "xla",
      "xlam",
      "xlb",
      "xll"
    ]
  },
  txt: {
    extensions: ["dif", "diff", "readme", "out", "plist", "properties", "text", "txt"]
  },
  vaultclosed: {},
  vaultopen: {},
  vector: {
    extensions: [
      "ai",
      "ait",
      "cvs",
      "dgn",
      "gdraw",
      "pd",
      "emf",
      "eps",
      "fig",
      "ind",
      "indd",
      "indl",
      "indt",
      "indb",
      "ps",
      "svg",
      "svgz",
      "wmf",
      "oxps",
      "xps",
      "xd",
      "sketch"
    ]
  },
  video: {
    extensions: [
      "3g2",
      "3gp",
      "3gp2",
      "3gpp",
      "asf",
      "avi",
      "dvr-ms",
      "flv",
      "m1v",
      "m4v",
      "mkv",
      "mod",
      "mov",
      "mm4p",
      "mp2",
      "mp2v",
      "mp4",
      "mp4v",
      "mpa",
      "mpe",
      "mpeg",
      "mpg",
      "mpv",
      "mpv2",
      "mts",
      "ogg",
      "qt",
      "swf",
      "ts",
      "vob",
      "webm",
      "wlmp",
      "wm",
      "wmv",
      "wmx"
    ]
  },
  video360: {},
  vsdx: {
    extensions: ["vdx", "vsd", "vsdm", "vsdx", "vsw", "vdw"]
  },
  vssx: {
    extensions: ["vss", "vssm", "vssx"]
  },
  vstx: {
    extensions: ["vst", "vstm", "vstx", "vsx"]
  },
  whiteboard: {
    extensions: ["whiteboard", "wbtx"]
  },
  xlsx: {
    extensions: ["xlc", "xls", "xlsb", "xlsm", "xlsx", "xlw"]
  },
  xltx: {
    extensions: ["xlt", "xltm", "xltx"]
  },
  xml: {
    extensions: ["xaml", "xml", "xsl"]
  },
  xsn: {
    extensions: ["xsn"]
  },
  zip: {
    extensions: ["zip"]
  }
};

// node_modules/@fluentui/react-file-type-icons/lib/initializeFileTypeIcons.js
var PNG_SUFFIX = "_png";
var SVG_SUFFIX = "_svg";
var DEFAULT_BASE_URL = FLUENT_CDN_BASE_URL + "/assets/item-types/";
var ICON_SIZES = [16, 20, 24, 32, 40, 48, 64, 96];
function initializeFileTypeIcons(baseUrl, options) {
  if (baseUrl === void 0) {
    baseUrl = DEFAULT_BASE_URL;
  }
  ICON_SIZES.forEach(function(size) {
    _initializeIcons(baseUrl, size, options);
  });
}
function _initializeIcons(baseUrl, size, options) {
  var iconTypes = Object.keys(FileTypeIconMap);
  var fileTypeIcons = {};
  iconTypes.forEach(function(type) {
    var baseUrlSizeType = baseUrl + size + "/" + type;
    fileTypeIcons[type + size + PNG_SUFFIX] = React.createElement("img", { src: baseUrlSizeType + ".png", alt: "" });
    fileTypeIcons[type + size + SVG_SUFFIX] = React.createElement("img", { src: baseUrlSizeType + ".svg", alt: "" });
    fileTypeIcons[type + size + "_1.5x" + PNG_SUFFIX] = React.createElement("img", { src: baseUrl + size + "_1.5x/" + type + ".png", height: "100%", width: "100%", alt: "" });
    fileTypeIcons[type + size + "_1.5x" + SVG_SUFFIX] = React.createElement("img", { src: baseUrl + size + "_1.5x/" + type + ".svg", height: "100%", width: "100%", alt: "" });
    fileTypeIcons[type + size + "_2x" + PNG_SUFFIX] = React.createElement("img", { src: baseUrl + size + "_2x/" + type + ".png", height: "100%", width: "100%", alt: "" });
    fileTypeIcons[type + size + "_3x" + PNG_SUFFIX] = React.createElement("img", { src: baseUrl + size + "_3x/" + type + ".png", height: "100%", width: "100%", alt: "" });
    fileTypeIcons[type + size + "_4x" + PNG_SUFFIX] = React.createElement("img", { src: baseUrl + size + "_4x/" + type + ".png", height: "100%", width: "100%", alt: "" });
  });
  registerIcons({
    fontFace: {},
    style: {
      width: size,
      height: size,
      overflow: "hidden"
    },
    icons: fileTypeIcons,
    mergeImageProps: true
  }, options);
}

// node_modules/@fluentui/react-file-type-icons/lib/FileIconType.js
var FileIconType;
(function(FileIconType2) {
  FileIconType2[FileIconType2["docset"] = 1] = "docset";
  FileIconType2[FileIconType2["folder"] = 2] = "folder";
  FileIconType2[FileIconType2["genericFile"] = 3] = "genericFile";
  FileIconType2[FileIconType2["listItem"] = 4] = "listItem";
  FileIconType2[FileIconType2["sharedFolder"] = 5] = "sharedFolder";
  FileIconType2[FileIconType2["multiple"] = 6] = "multiple";
  FileIconType2[FileIconType2["stream"] = 7] = "stream";
  FileIconType2[FileIconType2["news"] = 8] = "news";
  FileIconType2[FileIconType2["desktopFolder"] = 9] = "desktopFolder";
  FileIconType2[FileIconType2["documentsFolder"] = 10] = "documentsFolder";
  FileIconType2[FileIconType2["picturesFolder"] = 11] = "picturesFolder";
  FileIconType2[FileIconType2["linkedFolder"] = 12] = "linkedFolder";
  FileIconType2[FileIconType2["list"] = 13] = "list";
  FileIconType2[FileIconType2["form"] = 14] = "form";
  FileIconType2[FileIconType2["sway"] = 15] = "sway";
  FileIconType2[FileIconType2["playlist"] = 16] = "playlist";
})(FileIconType || (FileIconType = {}));

// node_modules/@fluentui/react-file-type-icons/lib/getFileTypeIconProps.js
var _extensionToIconName;
var GENERIC_FILE = "genericfile";
var FOLDER = "folder";
var SHARED_FOLDER = "sharedfolder";
var DOCSET_FOLDER = "docset";
var LIST_ITEM = "listitem";
var LIST = "splist";
var MULTIPLE_ITEMS = "multiple";
var NEWS = "sponews";
var STREAM = "video";
var DESKTOP_FOLDER = "desktopfolder";
var DOCUMENTS_FOLDER = "documentsfolder";
var PICTURES_FOLDER = "picturesfolder";
var LINKED_FOLDER = "linkedfolder";
var FORM = "form";
var SWAY = "sway";
var PLAYLIST = "playlist";
var DEFAULT_ICON_SIZE = 16;
function getFileTypeIconProps(options) {
  var iconBaseName;
  var extension = options.extension, type = options.type, size = options.size, imageFileType = options.imageFileType;
  iconBaseName = getFileTypeIconNameFromExtensionOrType(extension, type);
  var _size = size || DEFAULT_ICON_SIZE;
  var suffix = getFileTypeIconSuffix(_size, imageFileType);
  return { iconName: iconBaseName + suffix, "aria-label": extension };
}
function getFileTypeIconNameFromExtensionOrType(extension, type) {
  var iconBaseName;
  if (extension) {
    if (!_extensionToIconName) {
      _extensionToIconName = {};
      for (var iconName in FileTypeIconMap) {
        if (FileTypeIconMap.hasOwnProperty(iconName)) {
          var extensions = FileTypeIconMap[iconName].extensions;
          if (extensions) {
            for (var i = 0; i < extensions.length; i++) {
              _extensionToIconName[extensions[i]] = iconName;
            }
          }
        }
      }
    }
    extension = extension.replace(".", "").toLowerCase();
    return _extensionToIconName[extension] || GENERIC_FILE;
  } else if (type) {
    switch (type) {
      case FileIconType.docset:
        iconBaseName = DOCSET_FOLDER;
        break;
      case FileIconType.folder:
        iconBaseName = FOLDER;
        break;
      case FileIconType.listItem:
        iconBaseName = LIST_ITEM;
        break;
      case FileIconType.sharedFolder:
        iconBaseName = SHARED_FOLDER;
        break;
      case FileIconType.stream:
        iconBaseName = STREAM;
        break;
      case FileIconType.multiple:
        iconBaseName = MULTIPLE_ITEMS;
        break;
      case FileIconType.news:
        iconBaseName = NEWS;
        break;
      case FileIconType.desktopFolder:
        iconBaseName = DESKTOP_FOLDER;
        break;
      case FileIconType.documentsFolder:
        iconBaseName = DOCUMENTS_FOLDER;
        break;
      case FileIconType.picturesFolder:
        iconBaseName = PICTURES_FOLDER;
        break;
      case FileIconType.linkedFolder:
        iconBaseName = LINKED_FOLDER;
        break;
      case FileIconType.list:
        iconBaseName = LIST;
        break;
      case FileIconType.form:
        iconBaseName = FORM;
        break;
      case FileIconType.sway:
        iconBaseName = SWAY;
        break;
      case FileIconType.playlist:
        iconBaseName = PLAYLIST;
        break;
    }
  }
  return iconBaseName || GENERIC_FILE;
}
function getFileTypeIconSuffix(size, imageFileType) {
  if (imageFileType === void 0) {
    imageFileType = "svg";
  }
  var devicePixelRatio = window.devicePixelRatio;
  var devicePixelRatioSuffix = "";
  if (imageFileType === "svg" && devicePixelRatio > 1 && devicePixelRatio <= 1.5) {
    if (size !== 20) {
      devicePixelRatioSuffix = "_1.5x";
    }
  } else if (imageFileType === "png") {
    if (devicePixelRatio > 1 && devicePixelRatio <= 1.5) {
      devicePixelRatioSuffix = size === 20 ? "_2x" : "_1.5x";
    } else if (devicePixelRatio > 1.5 && devicePixelRatio <= 2) {
      devicePixelRatioSuffix = "_2x";
    } else if (devicePixelRatio > 2 && devicePixelRatio <= 3) {
      devicePixelRatioSuffix = "_3x";
    } else if (devicePixelRatio > 3) {
      devicePixelRatioSuffix = "_4x";
    }
  }
  return size + devicePixelRatioSuffix + "_" + imageFileType;
}

// node_modules/@fluentui/react-file-type-icons/lib/getFileTypeIconAsHTMLString.js
function getFileTypeIconAsHTMLString(options, baseUrl) {
  if (baseUrl === void 0) {
    baseUrl = DEFAULT_BASE_URL;
  }
  var extension = options.extension, _a = options.size, size = _a === void 0 ? DEFAULT_ICON_SIZE : _a, type = options.type, imageFileType = options.imageFileType;
  var baseIconName = getFileTypeIconNameFromExtensionOrType(extension, type);
  var baseSuffix = getFileTypeIconSuffix(size, imageFileType);
  var suffixArray = baseSuffix.split("_");
  var src;
  if (suffixArray.length === 3) {
    src = "" + baseUrl + size + "_" + suffixArray[1] + "/" + baseIconName + "." + suffixArray[2];
    return '<img src="' + src + '" height="100%" width="100%" />';
  } else if (suffixArray.length === 2) {
    src = "" + baseUrl + size + "/" + baseIconName + "." + suffixArray[1];
    return '<img src="' + src + '" alt="" />';
  }
}

// node_modules/@fluentui/react-file-type-icons/lib/version.js
setVersion("@fluentui/react-file-type-icons", "8.8.13");
export {
  FileIconType,
  FileTypeIconMap,
  getFileTypeIconAsHTMLString,
  getFileTypeIconProps,
  initializeFileTypeIcons
};
//# sourceMappingURL=@fluentui_react-file-type-icons.js.map
