import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/SideBarModulesRoutes.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideBarModulesRoutes.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { SideBarModules } from "/src/shared/components/modules/index.ts?t=1701096626433";
const SideBarModulesRoutes = () => {
  return /* @__PURE__ */ jsxDEV(Routes, { children: /* @__PURE__ */ jsxDEV(Route, { path: "/:module/*", element: /* @__PURE__ */ jsxDEV(SideBarModules, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideBarModulesRoutes.tsx",
    lineNumber: 6,
    columnNumber: 41
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideBarModulesRoutes.tsx",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideBarModulesRoutes.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = SideBarModulesRoutes;
export default SideBarModulesRoutes;
var _c;
$RefreshReg$(_c, "SideBarModulesRoutes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/routes/SideBarModulesRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU2lCO0FBVGpCLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLE9BQU9DLGNBQWM7QUFDOUIsU0FBU0Msc0JBQXNCO0FBRS9CLE1BQU1DLHVCQUEyQkEsTUFBTTtBQUNyQyxTQUNFLHVCQUFDLFVBQ0MsaUNBQUMsU0FDQyxNQUFLLGNBQ0wsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWUsS0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUU4QixLQUhoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDQyxLQVRLRDtBQVdOLGVBQWVBO0FBQW9CLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSb3V0ZSIsIlJvdXRlcyIsIlNpZGVCYXJNb2R1bGVzIiwiU2lkZUJhck1vZHVsZXNSb3V0ZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpZGVCYXJNb2R1bGVzUm91dGVzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3JvdXRlcy9TaWRlQmFyTW9kdWxlc1JvdXRlcy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUm91dGUsIFJvdXRlcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBTaWRlQmFyTW9kdWxlcyB9IGZyb20gJy4uL3NoYXJlZC9jb21wb25lbnRzL21vZHVsZXMnXG5cbmNvbnN0IFNpZGVCYXJNb2R1bGVzUm91dGVzOiBGQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvOm1vZHVsZS8qXCJcbiAgICAgICAgZWxlbWVudD17PFNpZGVCYXJNb2R1bGVzIC8+fVxuICAgICAgLz5cbiAgICA8L1JvdXRlcz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBTaWRlQmFyTW9kdWxlc1JvdXRlc1xuIl19