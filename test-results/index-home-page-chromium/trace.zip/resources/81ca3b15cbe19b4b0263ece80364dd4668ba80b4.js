import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAvatarUpload.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useRef = __vite__cjsImport4_react["useRef"]; const useCallback = __vite__cjsImport4_react["useCallback"];
import { convertFileToBase64, resizeImage } from "/src/shared/utils/index.ts";
import { UserAvatar } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexRow } from "/src/shared/components/index.ts?t=1701096626433";
const UserAvatarUpload = (props) => {
  _s();
  const {
    image,
    onChange,
    hasImage,
    removeImage
  } = props;
  const theme = useTheme();
  const fileInput = useRef(null);
  const openFileSelector = useCallback(() => {
    fileInput.current?.click();
  }, []);
  const selectImage = useCallback(async (event) => {
    if (event?.target.files?.length) {
      const newImage = await resizeImage(await convertFileToBase64(event?.target.files[0]));
      onChange(newImage.replace(/^data:.+;base64,/, ""));
    }
  }, [onChange]);
  return /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.lg, children: [
    /* @__PURE__ */ jsxDEV(UserAvatar, { image }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
      /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.lg, children: [
        /* @__PURE__ */ jsxDEV(Link, { underline: false, styles: {
          root: {
            fontSize: theme.fontSize.sm
          }
        }, onClick: openFileSelector, children: image ? "Alterar foto" : "Enviar foto" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
          lineNumber: 37,
          columnNumber: 11
        }, this),
        hasImage && /* @__PURE__ */ jsxDEV(Link, { underline: false, styles: {
          root: {
            fontSize: theme.fontSize.sm
          }
        }, onClick: () => removeImage(), children: "Remover foto" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
          lineNumber: 44,
          columnNumber: 24
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          color: theme.colors.gray[600]
        }
      }, children: "A foto ajuda seus colegas a identificarem você no sistema" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("input", { ref: fileInput, type: "file", accept: "image/*", style: {
      display: "none"
    }, onChange: selectImage }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(UserAvatarUpload, "GfZD8hnpeN3LSajM2Dguevsdop4=", false, function() {
  return [useTheme];
});
_c = UserAvatarUpload;
export default UserAvatarUpload;
var _c;
$RefreshReg$(_c, "UserAvatarUpload");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatarUpload.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBckNOLFNBQVNBLE1BQU1DLFlBQVk7QUFDM0IsU0FBYUMsUUFBUUMsbUJBQWdDO0FBQ3JELFNBQVNDLHFCQUFxQkMsbUJBQW1CO0FBQ2pELFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWUMsZUFBZTtBQVNwQyxNQUFNQyxtQkFBMkNDLFdBQVU7QUFBQUMsS0FBQTtBQUN6RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsSUFBVUM7QUFBQUEsSUFBVUM7QUFBQUEsRUFBWSxJQUFJTDtBQUVuRCxRQUFNTSxRQUFRVixTQUFTO0FBQ3ZCLFFBQU1XLFlBQVloQixPQUF5QixJQUFJO0FBRS9DLFFBQU1pQixtQkFBbUJoQixZQUFZLE1BQU07QUFDekNlLGNBQVVFLFNBQVNDLE1BQU07QUFBQSxFQUMzQixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjbkIsWUFBWSxPQUFPb0IsVUFBMEM7QUFDL0UsUUFBSUEsT0FBT0MsT0FBT0MsT0FBT0MsUUFBUTtBQUMvQixZQUFNQyxXQUFXLE1BQU10QixZQUNyQixNQUFNRCxvQkFBb0JtQixPQUFPQyxPQUFPQyxNQUFNLENBQUMsQ0FBQyxDQUNsRDtBQUNBWCxlQUFTYSxTQUFTQyxRQUFRLG9CQUFvQixFQUFFLENBQUM7QUFBQSxJQUNuRDtBQUFBLEVBQ0YsR0FBRyxDQUFDZCxRQUFRLENBQUM7QUFFYixTQUNFLHVCQUFDLFdBQ0MsS0FBTUcsTUFBTVksUUFBUUMsSUFFcEI7QUFBQSwyQkFBQyxjQUFXLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGNBQ0M7QUFBQSw2QkFBQyxXQUNDLEtBQU1iLE1BQU1ZLFFBQVFDLElBRXBCO0FBQUEsK0JBQUMsUUFDQyxXQUFXLE9BQ1gsUUFBUTtBQUFBLFVBQ05DLE1BQU07QUFBQSxZQUNKQyxVQUFVZixNQUFNZSxTQUFTQztBQUFBQSxVQUMzQjtBQUFBLFFBQ0YsR0FDQSxTQUFTZCxrQkFFUk4sa0JBQ0csaUJBQ0EsaUJBWE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQ0UsWUFBWSx1QkFBQyxRQUNaLFdBQVcsT0FDWCxRQUFRO0FBQUEsVUFDTmdCLE1BQU07QUFBQSxZQUNKQyxVQUFVZixNQUFNZSxTQUFTQztBQUFBQSxVQUMzQjtBQUFBLFFBQ0YsR0FDQSxTQUFTLE1BQU1qQixZQUFZLEdBQUUsNEJBUGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVYjtBQUFBLFdBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUNBLHVCQUFDLFFBQUssUUFBUTtBQUFBLFFBQUVlLE1BQU07QUFBQSxVQUFFRyxPQUFPakIsTUFBTWtCLE9BQU9DLEtBQUssR0FBRztBQUFBLFFBQUU7QUFBQSxNQUFFLEdBQUUseUVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0E7QUFBQSxJQUNBLHVCQUFDLFdBQ0MsS0FBS2xCLFdBQ0wsTUFBSyxRQUNMLFFBQU8sV0FDUCxPQUFPO0FBQUEsTUFBRW1CLFNBQVM7QUFBQSxJQUFPLEdBQ3pCLFVBQVVmLGVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUt3QjtBQUFBLE9BM0MxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNBO0FBRUo7QUFBQ1YsR0FuRUtGLGtCQUF1QztBQUFBLFVBRzdCSCxRQUFRO0FBQUE7QUFBQStCLEtBSGxCNUI7QUFxRU4sZUFBZUE7QUFBZ0IsSUFBQTRCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiVGV4dCIsInVzZVJlZiIsInVzZUNhbGxiYWNrIiwiY29udmVydEZpbGVUb0Jhc2U2NCIsInJlc2l6ZUltYWdlIiwiVXNlckF2YXRhciIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIkZsZXhSb3ciLCJVc2VyQXZhdGFyVXBsb2FkIiwicHJvcHMiLCJfcyIsImltYWdlIiwib25DaGFuZ2UiLCJoYXNJbWFnZSIsInJlbW92ZUltYWdlIiwidGhlbWUiLCJmaWxlSW5wdXQiLCJvcGVuRmlsZVNlbGVjdG9yIiwiY3VycmVudCIsImNsaWNrIiwic2VsZWN0SW1hZ2UiLCJldmVudCIsInRhcmdldCIsImZpbGVzIiwibGVuZ3RoIiwibmV3SW1hZ2UiLCJyZXBsYWNlIiwic3BhY2luZyIsImxnIiwicm9vdCIsImZvbnRTaXplIiwic20iLCJjb2xvciIsImNvbG9ycyIsImdyYXkiLCJkaXNwbGF5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQXZhdGFyVXBsb2FkLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vdXNlcnMvY29tcG9uZW50cy9Vc2VyQXZhdGFyVXBsb2FkLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgdXNlUmVmLCB1c2VDYWxsYmFjaywgQ2hhbmdlRXZlbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNvbnZlcnRGaWxlVG9CYXNlNjQsIHJlc2l6ZUltYWdlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xuaW1wb3J0IHsgVXNlckF2YXRhciB9IGZyb20gJy4nXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcbmltcG9ydCB7IEZsZXhDb2x1bW4sIEZsZXhSb3cgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcblxuaW50ZXJmYWNlIEF2YXRhclVwbG9hZFByb3BzIHtcbiAgaW1hZ2U/OiBzdHJpbmcgfCBudWxsXG4gIG9uQ2hhbmdlOiAocGF0aDogc3RyaW5nKSA9PiB2b2lkXG4gIGhhc0ltYWdlOiBib29sZWFuXG4gIHJlbW92ZUltYWdlOiAoKSA9PiB2b2lkXG59XG5cbmNvbnN0IFVzZXJBdmF0YXJVcGxvYWQ6IEZDPEF2YXRhclVwbG9hZFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGltYWdlLCBvbkNoYW5nZSwgaGFzSW1hZ2UsIHJlbW92ZUltYWdlIH0gPSBwcm9wc1xuXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxuICBjb25zdCBmaWxlSW5wdXQgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbClcblxuICBjb25zdCBvcGVuRmlsZVNlbGVjdG9yID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGZpbGVJbnB1dC5jdXJyZW50Py5jbGljaygpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHNlbGVjdEltYWdlID0gdXNlQ2FsbGJhY2soYXN5bmMgKGV2ZW50PzogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBpZiAoZXZlbnQ/LnRhcmdldC5maWxlcz8ubGVuZ3RoKSB7XG4gICAgICBjb25zdCBuZXdJbWFnZSA9IGF3YWl0IHJlc2l6ZUltYWdlKFxuICAgICAgICBhd2FpdCBjb252ZXJ0RmlsZVRvQmFzZTY0KGV2ZW50Py50YXJnZXQuZmlsZXNbMF0pLFxuICAgICAgKVxuICAgICAgb25DaGFuZ2UobmV3SW1hZ2UucmVwbGFjZSgvXmRhdGE6Lis7YmFzZTY0LC8sICcnKSlcbiAgICB9XG4gIH0sIFtvbkNoYW5nZV0pXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleFJvd1xuICAgICAgZ2FwPXsgdGhlbWUuc3BhY2luZy5sZyB9XG4gICAgPlxuICAgICAgPFVzZXJBdmF0YXIgaW1hZ2U9e2ltYWdlfSAvPlxuICAgICAgPEZsZXhDb2x1bW4+XG4gICAgICAgIDxGbGV4Um93XG4gICAgICAgICAgZ2FwPXsgdGhlbWUuc3BhY2luZy5sZyB9XG4gICAgICAgID5cbiAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgdW5kZXJsaW5lPXtmYWxzZX1cbiAgICAgICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLnNtLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9e29wZW5GaWxlU2VsZWN0b3J9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2ltYWdlXG4gICAgICAgICAgICAgID8gJ0FsdGVyYXIgZm90bydcbiAgICAgICAgICAgICAgOiAnRW52aWFyIGZvdG8nXG4gICAgICAgICAgICB9XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIHtoYXNJbWFnZSAmJiA8TGlua1xuICAgICAgICAgICAgdW5kZXJsaW5lPXtmYWxzZX1cbiAgICAgICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLnNtLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZUltYWdlKCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgUmVtb3ZlciBmb3RvXG4gICAgICAgICAgPC9MaW5rPn1cbiAgICAgICAgPC9GbGV4Um93PlxuICAgICAgICA8VGV4dCBzdHlsZXM9e3sgcm9vdDogeyBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbNjAwXSB9IH19PlxuICAgICAgICAgIEEgZm90byBhanVkYSBzZXVzIGNvbGVnYXMgYSBpZGVudGlmaWNhcmVtIHZvY8OqIG5vIHNpc3RlbWFcbiAgICAgICAgPC9UZXh0PlxuICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAgPGlucHV0XG4gICAgICAgIHJlZj17ZmlsZUlucHV0fVxuICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiAnbm9uZScgfX1cbiAgICAgICAgb25DaGFuZ2U9e3NlbGVjdEltYWdlfVxuICAgICAgLz5cbiAgICA8L0ZsZXhSb3c+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgVXNlckF2YXRhclVwbG9hZFxuIl19