function getSelectedKeyFromNavLinks(pathname, navLinks) {
  let selected = "";
  navLinks.filter((nav) => !!nav.links).forEach(({ links }) => {
    links?.forEach((link) => {
      if (link.links && link.links.length > 0) {
        link.links.forEach((subLink) => {
          selected = subLink.key && pathname.includes(subLink.key) ? subLink.key : selected;
        });
      } else {
        selected = link.key && pathname.includes(link.key) ? link.key : selected;
      }
    });
  });
  return selected;
}
export default getSelectedKeyFromNavLinks;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElOYXZMaW5rR3JvdXAgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5cbmZ1bmN0aW9uIGdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzIChwYXRobmFtZTogc3RyaW5nLCBuYXZMaW5rczogSU5hdkxpbmtHcm91cFtdKTogc3RyaW5nIHtcbiAgbGV0IHNlbGVjdGVkID0gJydcblxuICBuYXZMaW5rc1xuICAgIC5maWx0ZXIobmF2ID0+ICEhbmF2LmxpbmtzKVxuICAgIC5mb3JFYWNoKCh7IGxpbmtzIH0pID0+IHtcbiAgICAgIGxpbmtzPy5mb3JFYWNoKGxpbmsgPT4ge1xuICAgICAgICBpZiAobGluay5saW5rcyAmJiBsaW5rLmxpbmtzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBsaW5rLmxpbmtzLmZvckVhY2goc3ViTGluayA9PiB7XG4gICAgICAgICAgICBzZWxlY3RlZCA9IHN1Ykxpbmsua2V5ICYmIHBhdGhuYW1lLmluY2x1ZGVzKHN1Ykxpbmsua2V5KVxuICAgICAgICAgICAgICA/IHN1Ykxpbmsua2V5XG4gICAgICAgICAgICAgIDogc2VsZWN0ZWRcbiAgICAgICAgICB9KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbGVjdGVkID0gbGluay5rZXkgJiYgcGF0aG5hbWUuaW5jbHVkZXMobGluay5rZXkpXG4gICAgICAgICAgICA/IGxpbmsua2V5XG4gICAgICAgICAgICA6IHNlbGVjdGVkXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSlcblxuICByZXR1cm4gc2VsZWN0ZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3NcbiJdLCJtYXBwaW5ncyI6IkFBRUEsU0FBUywyQkFBNEIsVUFBa0IsVUFBbUM7QUFDeEYsTUFBSSxXQUFXO0FBRWYsV0FDRyxPQUFPLFNBQU8sQ0FBQyxDQUFDLElBQUksS0FBSyxFQUN6QixRQUFRLENBQUMsRUFBRSxNQUFNLE1BQU07QUFDdEIsV0FBTyxRQUFRLFVBQVE7QUFDckIsVUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsR0FBRztBQUN2QyxhQUFLLE1BQU0sUUFBUSxhQUFXO0FBQzVCLHFCQUFXLFFBQVEsT0FBTyxTQUFTLFNBQVMsUUFBUSxHQUFHLElBQ25ELFFBQVEsTUFDUjtBQUFBLFFBQ04sQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLG1CQUFXLEtBQUssT0FBTyxTQUFTLFNBQVMsS0FBSyxHQUFHLElBQzdDLEtBQUssTUFDTDtBQUFBLE1BQ047QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILENBQUM7QUFFSCxTQUFPO0FBQ1Q7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=