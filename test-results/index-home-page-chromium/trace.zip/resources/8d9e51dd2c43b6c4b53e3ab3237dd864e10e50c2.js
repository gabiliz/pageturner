import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/offices/components/OfficeEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { UsersDropdown } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexItem, FlexRow, MaskedTextField, StateDropdown, TextField } from "/src/shared/components/index.ts?t=1701096626433";
const emptyOffice = {
  nome: "",
  socioResponsavelId: null,
  gerenteResponsavelId: null,
  endereco: "",
  numero: "",
  bairro: "",
  cidade: "",
  estado: "",
  cep: ""
};
const OfficeEditForm = (props) => {
  _s();
  const theme = useTheme();
  const {
    formData,
    onChange,
    apiError
  } = props;
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange,
    onNumberTextChange,
    onDropdownChange,
    onFieldError
  } = useFormData(formData ?? emptyOffice);
  useEffect(() => {
    if (formData) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData, onChange]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", required: true, value: localFormData.nome, onChange: onTextChange("nome"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("nome", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(UsersDropdown, { label: "Sócio responsável", selectedKey: localFormData.socioResponsavelId, onChange: onDropdownChange("socioResponsavelId"), errorMessage: apiError?.errors?.messages ? onFieldError("socioResponsavelId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(UsersDropdown, { label: "Gerente responsável", selectedKey: localFormData.gerenteResponsavelId, onChange: onDropdownChange("gerenteResponsavelId"), errorMessage: apiError?.errors?.messages ? onFieldError("gerenteResponsavelId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MaskedTextField, { label: "CEP", mask: "99999-999", maskChar: " ", value: localFormData.cep, onChange: onNumberTextChange("cep"), styles: {
      fieldGroup: {
        width: "50%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("cep", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.sm, children: [
      /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Endereço", value: localFormData.endereco, onChange: onTextChange("endereco"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("endereco", apiError?.errors?.messages) : void 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(TextField, { label: "Número", value: localFormData.numero, onChange: onTextChange("numero"), maxLength: 20, errorMessage: apiError?.errors?.messages ? onFieldError("numero", apiError?.errors?.messages) : void 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 57,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Bairro", styles: {
      fieldGroup: {
        width: "50%"
      }
    }, value: localFormData.bairro, onChange: onTextChange("bairro"), maxLength: 50, errorMessage: apiError?.errors?.messages ? onFieldError("bairro", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.sm, children: [
      /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Cidade", value: localFormData.cidade, onChange: onTextChange("cidade"), maxLength: 50, errorMessage: apiError?.errors?.messages ? onFieldError("cidade", apiError?.errors?.messages) : void 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 67,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(StateDropdown, { label: "Estado", styles: {
        root: {
          width: 100
        }
      }, selectedKey: localFormData.estado, onChange: onDropdownChange("estado"), errorMessage: apiError?.errors?.messages ? onFieldError("estado", apiError?.errors?.messages) : void 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 70,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
        lineNumber: 69,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_s(OfficeEditForm, "rpc1nVCGUBG1/Cx076/Hg1xh6Zw=", false, function() {
  return [useTheme, useFormData];
});
_c = OfficeEditForm;
export default OfficeEditForm;
var _c;
$RefreshReg$(_c, "OfficeEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUNOLFNBQWFBLGlCQUFpQjtBQUc5QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFlBQVlDLFVBQVVDLFNBQVNDLGlCQUFpQkMsZUFBZUMsaUJBQWlCO0FBRXpGLE1BQU1DLGNBQXNCO0FBQUEsRUFDMUJDLE1BQU07QUFBQSxFQUNOQyxvQkFBb0I7QUFBQSxFQUNwQkMsc0JBQXNCO0FBQUEsRUFDdEJDLFVBQVU7QUFBQSxFQUNWQyxRQUFRO0FBQUEsRUFDUkMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxRQUFRO0FBQUEsRUFDUkMsS0FBSztBQUNQO0FBRUEsTUFBTUMsaUJBQTZDQyxXQUFVO0FBQUFDLEtBQUE7QUFDM0QsUUFBTUMsUUFBUXBCLFNBQVM7QUFDdkIsUUFBTTtBQUFBLElBQUVxQjtBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxFQUFTLElBQUlMO0FBRXpDLFFBQU07QUFBQSxJQUNKRyxVQUFVRztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUkvQixZQUFvQnNCLFlBQVlkLFdBQVc7QUFFL0NWLFlBQVUsTUFBTTtBQUNkLFFBQUl3QixVQUFVO0FBQ1pLLHVCQUFpQkwsUUFBUTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLENBQUNBLFFBQVEsQ0FBQztBQUVieEIsWUFBVSxNQUFNO0FBQ2R5QixlQUFXRSxhQUFhO0FBQUEsRUFDMUIsR0FBRyxDQUFDQSxlQUFlRixRQUFRLENBQUM7QUFFNUIsU0FDRSx1QkFBQyxjQUFXLEtBQU0sSUFDaEI7QUFBQSwyQkFBQyxhQUNDLE9BQU0sUUFDTixVQUFRLE1BQ1IsT0FBT0UsY0FBY2hCLE1BQ3JCLFVBQVVtQixhQUFhLE1BQU0sR0FDN0IsV0FBVyxLQUNYLGNBQWNKLFVBQVVRLFFBQVFDLFdBQzVCRixhQUFhLFFBQVFQLFVBQVVRLFFBQVFDLFFBQVEsSUFDL0NDLFVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNHO0FBQUEsSUFFSCx1QkFBQyxpQkFDQyxPQUFNLHFCQUNOLGFBQWFULGNBQWNmLG9CQUMzQixVQUFVb0IsaUJBQWlCLG9CQUFvQixHQUMvQyxjQUFjTixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSxzQkFBc0JQLFVBQVVRLFFBQVFDLFFBQVEsSUFDN0RDLFVBTk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9HO0FBQUEsSUFFSCx1QkFBQyxpQkFDQyxPQUFNLHVCQUNOLGFBQWFULGNBQWNkLHNCQUMzQixVQUFVbUIsaUJBQWlCLHNCQUFzQixHQUNqRCxjQUFjTixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSx3QkFBd0JQLFVBQVVRLFFBQVFDLFFBQVEsSUFDL0RDLFVBTk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9HO0FBQUEsSUFFSCx1QkFBQyxtQkFDQyxPQUFNLE9BQ04sTUFBSyxhQUNMLFVBQVMsS0FDVCxPQUFPVCxjQUFjUixLQUNyQixVQUFVWSxtQkFBbUIsS0FBSyxHQUNsQyxRQUFRO0FBQUEsTUFBRU0sWUFBWTtBQUFBLFFBQUVDLE9BQU87QUFBQSxNQUFNO0FBQUEsSUFBRSxHQUN2QyxjQUFjWixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSxPQUFPUCxVQUFVUSxRQUFRQyxRQUFRLElBQzlDQyxVQVROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVRztBQUFBLElBRUgsdUJBQUMsV0FBUSxLQUFNYixNQUFNZ0IsUUFBUUMsSUFDM0I7QUFBQSw2QkFBQyxZQUFTLE1BQU0sR0FDZCxpQ0FBQyxhQUNDLE9BQU0sWUFDTixPQUFPYixjQUFjYixVQUNyQixVQUFVZ0IsYUFBYSxVQUFVLEdBQ2pDLFdBQVcsS0FDWCxjQUFjSixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSxZQUFZUCxVQUFVUSxRQUFRQyxRQUFRLElBQ25EQyxVQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRRyxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BQ0EsdUJBQUMsWUFDQyxpQ0FBQyxhQUNDLE9BQU0sVUFDTixPQUFPVCxjQUFjWixRQUNyQixVQUFVZSxhQUFhLFFBQVEsR0FDL0IsV0FBVyxJQUNYLGNBQWNKLFVBQVVRLFFBQVFDLFdBQzVCRixhQUFhLFVBQVVQLFVBQVVRLFFBQVFDLFFBQVEsSUFDakRDLFVBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFHLEtBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBQ0EsdUJBQUMsYUFDQyxPQUFNLFVBQ04sUUFBUTtBQUFBLE1BQUVDLFlBQVk7QUFBQSxRQUFFQyxPQUFPO0FBQUEsTUFBTTtBQUFBLElBQUUsR0FDdkMsT0FBT1gsY0FBY1gsUUFDckIsVUFBVWMsYUFBYSxRQUFRLEdBQy9CLFdBQVcsSUFDWCxjQUFjSixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSxVQUFVUCxVQUFVUSxRQUFRQyxRQUFRLElBQ2pEQyxVQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTRztBQUFBLElBRUgsdUJBQUMsV0FBUSxLQUFNYixNQUFNZ0IsUUFBUUMsSUFDM0I7QUFBQSw2QkFBQyxZQUFTLE1BQU0sR0FDZCxpQ0FBQyxhQUNDLE9BQU0sVUFDTixPQUFPYixjQUFjVixRQUNyQixVQUFVYSxhQUFhLFFBQVEsR0FDL0IsV0FBVyxJQUNYLGNBQWNKLFVBQVVRLFFBQVFDLFdBQzVCRixhQUFhLFVBQVVQLFVBQVVRLFFBQVFDLFFBQVEsSUFDakRDLFVBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFHLEtBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxZQUNDLGlDQUFDLGlCQUNDLE9BQU0sVUFDTixRQUFRO0FBQUEsUUFDTkssTUFBTTtBQUFBLFVBQUVILE9BQU87QUFBQSxRQUFJO0FBQUEsTUFDckIsR0FDQSxhQUFhWCxjQUFjVCxRQUMzQixVQUFVYyxpQkFBaUIsUUFBUSxHQUNuQyxjQUFjTixVQUFVUSxRQUFRQyxXQUM1QkYsYUFBYSxVQUFVUCxVQUFVUSxRQUFRQyxRQUFRLElBQ2pEQyxVQVROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVRyxLQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQTFHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkdBO0FBRUo7QUFBQ2QsR0FySUtGLGdCQUF5QztBQUFBLFVBQy9CakIsVUFVVkQsV0FBVztBQUFBO0FBQUF3QyxLQVhYdEI7QUF1SU4sZUFBZUE7QUFBYyxJQUFBc0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIlVzZXJzRHJvcGRvd24iLCJ1c2VGb3JtRGF0YSIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsIk1hc2tlZFRleHRGaWVsZCIsIlN0YXRlRHJvcGRvd24iLCJUZXh0RmllbGQiLCJlbXB0eU9mZmljZSIsIm5vbWUiLCJzb2Npb1Jlc3BvbnNhdmVsSWQiLCJnZXJlbnRlUmVzcG9uc2F2ZWxJZCIsImVuZGVyZWNvIiwibnVtZXJvIiwiYmFpcnJvIiwiY2lkYWRlIiwiZXN0YWRvIiwiY2VwIiwiT2ZmaWNlRWRpdEZvcm0iLCJwcm9wcyIsIl9zIiwidGhlbWUiLCJmb3JtRGF0YSIsIm9uQ2hhbmdlIiwiYXBpRXJyb3IiLCJsb2NhbEZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJzZXRMb2NhbEZvcm1EYXRhIiwib25UZXh0Q2hhbmdlIiwib25OdW1iZXJUZXh0Q2hhbmdlIiwib25Ecm9wZG93bkNoYW5nZSIsIm9uRmllbGRFcnJvciIsImVycm9ycyIsIm1lc3NhZ2VzIiwidW5kZWZpbmVkIiwiZmllbGRHcm91cCIsIndpZHRoIiwic3BhY2luZyIsInNtIiwicm9vdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiT2ZmaWNlRWRpdEZvcm0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9vZmZpY2VzL2NvbXBvbmVudHMvT2ZmaWNlRWRpdEZvcm0udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgT2ZmaWNlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9PZmZpY2UnXHJcbmltcG9ydCB7IEVkaXRGb3JtUHJvcHMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdHlwZXMvRWRpdEZvcm0nXHJcbmltcG9ydCB7IFVzZXJzRHJvcGRvd24gfSBmcm9tICcuLi8uLi91c2Vycy9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VGb3JtRGF0YSwgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IEZsZXhDb2x1bW4sIEZsZXhJdGVtLCBGbGV4Um93LCBNYXNrZWRUZXh0RmllbGQsIFN0YXRlRHJvcGRvd24sIFRleHRGaWVsZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5cclxuY29uc3QgZW1wdHlPZmZpY2U6IE9mZmljZSA9IHtcclxuICBub21lOiAnJyxcclxuICBzb2Npb1Jlc3BvbnNhdmVsSWQ6IG51bGwsXHJcbiAgZ2VyZW50ZVJlc3BvbnNhdmVsSWQ6IG51bGwsXHJcbiAgZW5kZXJlY286ICcnLFxyXG4gIG51bWVybzogJycsXHJcbiAgYmFpcnJvOiAnJyxcclxuICBjaWRhZGU6ICcnLFxyXG4gIGVzdGFkbzogJycsXHJcbiAgY2VwOiAnJyxcclxufVxyXG5cclxuY29uc3QgT2ZmaWNlRWRpdEZvcm06IEZDPEVkaXRGb3JtUHJvcHM8T2ZmaWNlPj4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcclxuICBjb25zdCB7IGZvcm1EYXRhLCBvbkNoYW5nZSwgYXBpRXJyb3IgfSA9IHByb3BzXHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGZvcm1EYXRhOiBsb2NhbEZvcm1EYXRhLFxyXG4gICAgc2V0Rm9ybURhdGE6IHNldExvY2FsRm9ybURhdGEsXHJcbiAgICBvblRleHRDaGFuZ2UsXHJcbiAgICBvbk51bWJlclRleHRDaGFuZ2UsXHJcbiAgICBvbkRyb3Bkb3duQ2hhbmdlLFxyXG4gICAgb25GaWVsZEVycm9yLFxyXG4gIH0gPSB1c2VGb3JtRGF0YTxPZmZpY2U+KGZvcm1EYXRhID8/IGVtcHR5T2ZmaWNlKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGZvcm1EYXRhKSB7XHJcbiAgICAgIHNldExvY2FsRm9ybURhdGEoZm9ybURhdGEpXHJcbiAgICB9XHJcbiAgfSwgW2Zvcm1EYXRhXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIG9uQ2hhbmdlPy4obG9jYWxGb3JtRGF0YSlcclxuICB9LCBbbG9jYWxGb3JtRGF0YSwgb25DaGFuZ2VdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEZsZXhDb2x1bW4gZ2FwPXsgMTIgfT5cclxuICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgIGxhYmVsPVwiTm9tZVwiXHJcbiAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5ub21lfVxyXG4gICAgICAgIG9uQ2hhbmdlPXtvblRleHRDaGFuZ2UoJ25vbWUnKX1cclxuICAgICAgICBtYXhMZW5ndGg9ezEwMH1cclxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignbm9tZScsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICB9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxVc2Vyc0Ryb3Bkb3duXHJcbiAgICAgICAgbGFiZWw9XCJTw7NjaW8gcmVzcG9uc8OhdmVsXCJcclxuICAgICAgICBzZWxlY3RlZEtleT17bG9jYWxGb3JtRGF0YS5zb2Npb1Jlc3BvbnNhdmVsSWR9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uRHJvcGRvd25DaGFuZ2UoJ3NvY2lvUmVzcG9uc2F2ZWxJZCcpfVxyXG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgID8gb25GaWVsZEVycm9yKCdzb2Npb1Jlc3BvbnNhdmVsSWQnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8VXNlcnNEcm9wZG93blxyXG4gICAgICAgIGxhYmVsPVwiR2VyZW50ZSByZXNwb25zw6F2ZWxcIlxyXG4gICAgICAgIHNlbGVjdGVkS2V5PXtsb2NhbEZvcm1EYXRhLmdlcmVudGVSZXNwb25zYXZlbElkfVxyXG4gICAgICAgIG9uQ2hhbmdlPXtvbkRyb3Bkb3duQ2hhbmdlKCdnZXJlbnRlUmVzcG9uc2F2ZWxJZCcpfVxyXG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgID8gb25GaWVsZEVycm9yKCdnZXJlbnRlUmVzcG9uc2F2ZWxJZCcsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICB9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxNYXNrZWRUZXh0RmllbGRcclxuICAgICAgICBsYWJlbD1cIkNFUFwiXHJcbiAgICAgICAgbWFzaz1cIjk5OTk5LTk5OVwiXHJcbiAgICAgICAgbWFza0NoYXI9XCIgXCJcclxuICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5jZXB9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uTnVtYmVyVGV4dENoYW5nZSgnY2VwJyl9XHJcbiAgICAgICAgc3R5bGVzPXt7IGZpZWxkR3JvdXA6IHsgd2lkdGg6ICc1MCUnIH0gfX1cclxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignY2VwJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuICAgICAgPEZsZXhSb3cgZ2FwPXsgdGhlbWUuc3BhY2luZy5zbSB9PlxyXG4gICAgICAgIDxGbGV4SXRlbSBncm93PXsxfSA+XHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIGxhYmVsPVwiRW5kZXJlw6dvXCJcclxuICAgICAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEuZW5kZXJlY299XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvblRleHRDaGFuZ2UoJ2VuZGVyZWNvJyl9XHJcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwfVxyXG4gICAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ2VuZGVyZWNvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0ZsZXhJdGVtPlxyXG4gICAgICAgIDxGbGV4SXRlbT5cclxuICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJOw7ptZXJvXCJcclxuICAgICAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEubnVtZXJvfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdudW1lcm8nKX1cclxuICAgICAgICAgICAgbWF4TGVuZ3RoPXsyMH1cclxuICAgICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdudW1lcm8nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgIDwvRmxleFJvdz5cclxuICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgIGxhYmVsPVwiQmFpcnJvXCJcclxuICAgICAgICBzdHlsZXM9e3sgZmllbGRHcm91cDogeyB3aWR0aDogJzUwJScgfSB9fVxyXG4gICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLmJhaXJyb31cclxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdiYWlycm8nKX1cclxuICAgICAgICBtYXhMZW5ndGg9ezUwfVxyXG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgID8gb25GaWVsZEVycm9yKCdiYWlycm8nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8RmxleFJvdyBnYXA9eyB0aGVtZS5zcGFjaW5nLnNtIH0+XHJcbiAgICAgICAgPEZsZXhJdGVtIGdyb3c9ezF9ID5cclxuICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJDaWRhZGVcIlxyXG4gICAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5jaWRhZGV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvblRleHRDaGFuZ2UoJ2NpZGFkZScpfVxyXG4gICAgICAgICAgICBtYXhMZW5ndGg9ezUwfVxyXG4gICAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ2NpZGFkZScsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9GbGV4SXRlbT5cclxuICAgICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgICA8U3RhdGVEcm9wZG93blxyXG4gICAgICAgICAgICBsYWJlbD1cIkVzdGFkb1wiXHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6IDEwMCB9LFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBzZWxlY3RlZEtleT17bG9jYWxGb3JtRGF0YS5lc3RhZG99XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkRyb3Bkb3duQ2hhbmdlKCdlc3RhZG8nKX1cclxuICAgICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdlc3RhZG8nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgIDwvRmxleFJvdz5cclxuICAgIDwvRmxleENvbHVtbj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE9mZmljZUVkaXRGb3JtXHJcbiJdfQ==