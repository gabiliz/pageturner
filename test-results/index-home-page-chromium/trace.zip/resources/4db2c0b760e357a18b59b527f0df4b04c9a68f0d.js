import {
  loadTheme
} from "/node_modules/.vite/deps/chunk-2EIJ3ZL6.js?v=9f90a7ff";
import {
  Customizations,
  GlobalSettings,
  IsFocusVisibleClassName,
  getLanguage,
  getWindow,
  memoizeFunction,
  merge,
  mergeSettings,
  warn
} from "/node_modules/.vite/deps/chunk-JYWLVXGS.js?v=9f90a7ff";
import {
  Stylesheet,
  __assign,
  fontFace,
  keyframes,
  mergeStyles,
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";

// node_modules/@fluentui/style-utilities/lib/utilities/buildClassMap.js
function buildClassMap(styles) {
  var classes = {};
  var _loop_1 = function(styleName2) {
    if (styles.hasOwnProperty(styleName2)) {
      var className_1;
      Object.defineProperty(classes, styleName2, {
        get: function() {
          if (className_1 === void 0) {
            className_1 = mergeStyles(styles[styleName2]).toString();
          }
          return className_1;
        },
        enumerable: true,
        configurable: true
      });
    }
  };
  for (var styleName in styles) {
    _loop_1(styleName);
  }
  return classes;
}

// node_modules/@fluentui/style-utilities/lib/utilities/icons.js
var ICON_SETTING_NAME = "icons";
var _iconSettings = GlobalSettings.getValue(ICON_SETTING_NAME, {
  __options: {
    disableWarnings: false,
    warnOnMissingIcons: true
  },
  __remapped: {}
});
var stylesheet = Stylesheet.getInstance();
if (stylesheet && stylesheet.onReset) {
  stylesheet.onReset(function() {
    for (var name_1 in _iconSettings) {
      if (_iconSettings.hasOwnProperty(name_1) && !!_iconSettings[name_1].subset) {
        _iconSettings[name_1].subset.className = void 0;
      }
    }
  });
}
var normalizeIconName = function(name) {
  return name.toLowerCase();
};
function registerIcons(iconSubset, options) {
  var subset = __assign(__assign({}, iconSubset), { isRegistered: false, className: void 0 });
  var icons = iconSubset.icons;
  options = options ? __assign(__assign({}, _iconSettings.__options), options) : _iconSettings.__options;
  for (var iconName in icons) {
    if (icons.hasOwnProperty(iconName)) {
      var code = icons[iconName];
      var normalizedIconName = normalizeIconName(iconName);
      if (_iconSettings[normalizedIconName]) {
        _warnDuplicateIcon(iconName);
      } else {
        _iconSettings[normalizedIconName] = {
          code,
          subset
        };
      }
    }
  }
}
function unregisterIcons(iconNames) {
  var options = _iconSettings.__options;
  var _loop_1 = function(iconName2) {
    var normalizedIconName = normalizeIconName(iconName2);
    if (_iconSettings[normalizedIconName]) {
      delete _iconSettings[normalizedIconName];
    } else {
      if (!options.disableWarnings) {
        warn('The icon "'.concat(iconName2, '" tried to unregister but was not registered.'));
      }
    }
    if (_iconSettings.__remapped[normalizedIconName]) {
      delete _iconSettings.__remapped[normalizedIconName];
    }
    Object.keys(_iconSettings.__remapped).forEach(function(key) {
      if (_iconSettings.__remapped[key] === normalizedIconName) {
        delete _iconSettings.__remapped[key];
      }
    });
  };
  for (var _i = 0, iconNames_1 = iconNames; _i < iconNames_1.length; _i++) {
    var iconName = iconNames_1[_i];
    _loop_1(iconName);
  }
}
function registerIconAlias(iconName, mappedToName) {
  _iconSettings.__remapped[normalizeIconName(iconName)] = normalizeIconName(mappedToName);
}
function getIcon(name) {
  var icon = void 0;
  var options = _iconSettings.__options;
  name = name ? normalizeIconName(name) : "";
  name = _iconSettings.__remapped[name] || name;
  if (name) {
    icon = _iconSettings[name];
    if (icon) {
      var subset = icon.subset;
      if (subset && subset.fontFace) {
        if (!subset.isRegistered) {
          fontFace(subset.fontFace);
          subset.isRegistered = true;
        }
        if (!subset.className) {
          subset.className = mergeStyles(subset.style, {
            fontFamily: subset.fontFace.fontFamily,
            fontWeight: subset.fontFace.fontWeight || "normal",
            fontStyle: subset.fontFace.fontStyle || "normal"
          });
        }
      }
    } else {
      if (!options.disableWarnings && options.warnOnMissingIcons) {
        warn('The icon "'.concat(name, '" was used but not registered. See https://github.com/microsoft/fluentui/wiki/Using-icons for more information.'));
      }
    }
  }
  return icon;
}
function setIconOptions(options) {
  _iconSettings.__options = __assign(__assign({}, _iconSettings.__options), options);
}
var _missingIcons = [];
var _missingIconsTimer = void 0;
function _warnDuplicateIcon(iconName) {
  var options = _iconSettings.__options;
  var warningDelay = 2e3;
  var maxIconsInMessage = 10;
  if (!options.disableWarnings) {
    _missingIcons.push(iconName);
    if (_missingIconsTimer === void 0) {
      _missingIconsTimer = setTimeout(function() {
        warn("Some icons were re-registered. Applications should only call registerIcons for any given icon once. Redefining what an icon is may have unintended consequences. Duplicates include: \n" + _missingIcons.slice(0, maxIconsInMessage).join(", ") + (_missingIcons.length > maxIconsInMessage ? " (+ ".concat(_missingIcons.length - maxIconsInMessage, " more)") : ""));
        _missingIconsTimer = void 0;
        _missingIcons = [];
      }, warningDelay);
    }
  }
}

// node_modules/@fluentui/style-utilities/lib/utilities/getIconClassName.js
var defaultIconStyles = {
  display: "inline-block"
};
function getIconClassName(name) {
  var className = "";
  var icon = getIcon(name);
  if (icon) {
    className = mergeStyles(icon.subset.className, defaultIconStyles, {
      selectors: {
        "::before": {
          content: '"'.concat(icon.code, '"')
        }
      }
    });
  }
  return className;
}

// node_modules/@fluentui/theme/lib/utilities/makeSemanticColors.js
function makeSemanticColors(p, e, s, isInverted, depComments) {
  if (depComments === void 0) {
    depComments = false;
  }
  var semanticColors = __assign({
    primaryButtonBorder: "transparent",
    errorText: !isInverted ? "#a4262c" : "#F1707B",
    messageText: !isInverted ? "#323130" : "#F3F2F1",
    messageLink: !isInverted ? "#005A9E" : "#6CB8F6",
    messageLinkHovered: !isInverted ? "#004578" : "#82C7FF",
    infoIcon: !isInverted ? "#605e5c" : "#C8C6C4",
    errorIcon: !isInverted ? "#A80000" : "#F1707B",
    blockingIcon: !isInverted ? "#FDE7E9" : "#442726",
    warningIcon: !isInverted ? "#797775" : "#C8C6C4",
    severeWarningIcon: !isInverted ? "#D83B01" : "#FCE100",
    successIcon: !isInverted ? "#107C10" : "#92C353",
    infoBackground: !isInverted ? "#f3f2f1" : "#323130",
    errorBackground: !isInverted ? "#FDE7E9" : "#442726",
    blockingBackground: !isInverted ? "#FDE7E9" : "#442726",
    warningBackground: !isInverted ? "#FFF4CE" : "#433519",
    severeWarningBackground: !isInverted ? "#FED9CC" : "#4F2A0F",
    successBackground: !isInverted ? "#DFF6DD" : "#393D1B",
    // deprecated
    warningHighlight: !isInverted ? "#ffb900" : "#fff100",
    successText: !isInverted ? "#107C10" : "#92c353"
  }, s);
  var fullSemanticColors = getSemanticColors(p, e, semanticColors, isInverted);
  return _fixDeprecatedSlots(fullSemanticColors, depComments);
}
function getSemanticColors(p, e, s, isInverted, depComments) {
  if (depComments === void 0) {
    depComments = false;
  }
  var result = {};
  var _a = p || {}, white = _a.white, black = _a.black, themePrimary = _a.themePrimary, themeDark = _a.themeDark, themeDarker = _a.themeDarker, themeDarkAlt = _a.themeDarkAlt, themeLighter = _a.themeLighter, neutralLight = _a.neutralLight, neutralLighter = _a.neutralLighter, neutralDark = _a.neutralDark, neutralQuaternary = _a.neutralQuaternary, neutralQuaternaryAlt = _a.neutralQuaternaryAlt, neutralPrimary = _a.neutralPrimary, neutralSecondary = _a.neutralSecondary, neutralSecondaryAlt = _a.neutralSecondaryAlt, neutralTertiary = _a.neutralTertiary, neutralTertiaryAlt = _a.neutralTertiaryAlt, neutralLighterAlt = _a.neutralLighterAlt, accent = _a.accent;
  if (white) {
    result.bodyBackground = white;
    result.bodyFrameBackground = white;
    result.accentButtonText = white;
    result.buttonBackground = white;
    result.primaryButtonText = white;
    result.primaryButtonTextHovered = white;
    result.primaryButtonTextPressed = white;
    result.inputBackground = white;
    result.inputForegroundChecked = white;
    result.listBackground = white;
    result.menuBackground = white;
    result.cardStandoutBackground = white;
  }
  if (black) {
    result.bodyTextChecked = black;
    result.buttonTextCheckedHovered = black;
  }
  if (themePrimary) {
    result.link = themePrimary;
    result.primaryButtonBackground = themePrimary;
    result.inputBackgroundChecked = themePrimary;
    result.inputIcon = themePrimary;
    result.inputFocusBorderAlt = themePrimary;
    result.menuIcon = themePrimary;
    result.menuHeader = themePrimary;
    result.accentButtonBackground = themePrimary;
  }
  if (themeDark) {
    result.primaryButtonBackgroundPressed = themeDark;
    result.inputBackgroundCheckedHovered = themeDark;
    result.inputIconHovered = themeDark;
  }
  if (themeDarker) {
    result.linkHovered = themeDarker;
  }
  if (themeDarkAlt) {
    result.primaryButtonBackgroundHovered = themeDarkAlt;
  }
  if (themeLighter) {
    result.inputPlaceholderBackgroundChecked = themeLighter;
  }
  if (neutralLight) {
    result.bodyBackgroundChecked = neutralLight;
    result.bodyFrameDivider = neutralLight;
    result.bodyDivider = neutralLight;
    result.variantBorder = neutralLight;
    result.buttonBackgroundCheckedHovered = neutralLight;
    result.buttonBackgroundPressed = neutralLight;
    result.listItemBackgroundChecked = neutralLight;
    result.listHeaderBackgroundPressed = neutralLight;
    result.menuItemBackgroundPressed = neutralLight;
    result.menuItemBackgroundChecked = neutralLight;
  }
  if (neutralLighter) {
    result.bodyBackgroundHovered = neutralLighter;
    result.buttonBackgroundHovered = neutralLighter;
    result.buttonBackgroundDisabled = neutralLighter;
    result.buttonBorderDisabled = neutralLighter;
    result.primaryButtonBackgroundDisabled = neutralLighter;
    result.disabledBackground = neutralLighter;
    result.listItemBackgroundHovered = neutralLighter;
    result.listHeaderBackgroundHovered = neutralLighter;
    result.menuItemBackgroundHovered = neutralLighter;
  }
  if (neutralQuaternary) {
    result.primaryButtonTextDisabled = neutralQuaternary;
    result.disabledSubtext = neutralQuaternary;
  }
  if (neutralQuaternaryAlt) {
    result.listItemBackgroundCheckedHovered = neutralQuaternaryAlt;
  }
  if (neutralTertiary) {
    result.disabledBodyText = neutralTertiary;
    result.variantBorderHovered = (s === null || s === void 0 ? void 0 : s.variantBorderHovered) || neutralTertiary;
    result.buttonTextDisabled = neutralTertiary;
    result.inputIconDisabled = neutralTertiary;
    result.disabledText = neutralTertiary;
  }
  if (neutralPrimary) {
    result.bodyText = neutralPrimary;
    result.actionLink = neutralPrimary;
    result.buttonText = neutralPrimary;
    result.inputBorderHovered = neutralPrimary;
    result.inputText = neutralPrimary;
    result.listText = neutralPrimary;
    result.menuItemText = neutralPrimary;
  }
  if (neutralLighterAlt) {
    result.bodyStandoutBackground = neutralLighterAlt;
    result.defaultStateBackground = neutralLighterAlt;
  }
  if (neutralDark) {
    result.actionLinkHovered = neutralDark;
    result.buttonTextHovered = neutralDark;
    result.buttonTextChecked = neutralDark;
    result.buttonTextPressed = neutralDark;
    result.inputTextHovered = neutralDark;
    result.menuItemTextHovered = neutralDark;
  }
  if (neutralSecondary) {
    result.bodySubtext = neutralSecondary;
    result.focusBorder = neutralSecondary;
    result.inputBorder = neutralSecondary;
    result.smallInputBorder = neutralSecondary;
    result.inputPlaceholderText = neutralSecondary;
  }
  if (neutralSecondaryAlt) {
    result.buttonBorder = neutralSecondaryAlt;
  }
  if (neutralTertiaryAlt) {
    result.disabledBodySubtext = neutralTertiaryAlt;
    result.disabledBorder = neutralTertiaryAlt;
    result.buttonBackgroundChecked = neutralTertiaryAlt;
    result.menuDivider = neutralTertiaryAlt;
  }
  if (accent) {
    result.accentButtonBackground = accent;
  }
  if (e === null || e === void 0 ? void 0 : e.elevation4) {
    result.cardShadow = e.elevation4;
  }
  if (!isInverted && (e === null || e === void 0 ? void 0 : e.elevation8)) {
    result.cardShadowHovered = e.elevation8;
  } else if (result.variantBorderHovered) {
    result.cardShadowHovered = "0 0 1px " + result.variantBorderHovered;
  }
  result = __assign(__assign({}, result), s);
  return result;
}
function _fixDeprecatedSlots(s, depComments) {
  var dep = "";
  if (depComments === true) {
    dep = " /* @deprecated */";
  }
  s.listTextColor = s.listText + dep;
  s.menuItemBackgroundChecked += dep;
  s.warningHighlight += dep;
  s.warningText = s.messageText + dep;
  s.successText += dep;
  return s;
}

// node_modules/@fluentui/theme/lib/mergeThemes.js
function mergeThemes(theme, partialTheme) {
  var _a, _b, _c;
  if (partialTheme === void 0) {
    partialTheme = {};
  }
  var mergedTheme = merge({}, theme, partialTheme, {
    semanticColors: getSemanticColors(partialTheme.palette, partialTheme.effects, partialTheme.semanticColors, partialTheme.isInverted === void 0 ? theme.isInverted : partialTheme.isInverted)
  });
  if (((_a = partialTheme.palette) === null || _a === void 0 ? void 0 : _a.themePrimary) && !((_b = partialTheme.palette) === null || _b === void 0 ? void 0 : _b.accent)) {
    mergedTheme.palette.accent = partialTheme.palette.themePrimary;
  }
  if (partialTheme.defaultFontStyle) {
    for (var _i = 0, _d = Object.keys(mergedTheme.fonts); _i < _d.length; _i++) {
      var fontStyle = _d[_i];
      mergedTheme.fonts[fontStyle] = merge(mergedTheme.fonts[fontStyle], partialTheme.defaultFontStyle, (_c = partialTheme === null || partialTheme === void 0 ? void 0 : partialTheme.fonts) === null || _c === void 0 ? void 0 : _c[fontStyle]);
    }
  }
  return mergedTheme;
}

// node_modules/@fluentui/theme/lib/colors/FluentColors.js
var CommunicationColors;
(function(CommunicationColors2) {
  CommunicationColors2.shade30 = "#004578";
  CommunicationColors2.shade20 = "#005a9e";
  CommunicationColors2.shade10 = "#106ebe";
  CommunicationColors2.primary = "#0078d4";
  CommunicationColors2.tint10 = "#2b88d8";
  CommunicationColors2.tint20 = "#c7e0f4";
  CommunicationColors2.tint30 = "#deecf9";
  CommunicationColors2.tint40 = "#eff6fc";
})(CommunicationColors || (CommunicationColors = {}));
var NeutralColors;
(function(NeutralColors2) {
  NeutralColors2.black = "#000000";
  NeutralColors2.gray220 = "#11100f";
  NeutralColors2.gray210 = "#161514";
  NeutralColors2.gray200 = "#1b1a19";
  NeutralColors2.gray190 = "#201f1e";
  NeutralColors2.gray180 = "#252423";
  NeutralColors2.gray170 = "#292827";
  NeutralColors2.gray160 = "#323130";
  NeutralColors2.gray150 = "#3b3a39";
  NeutralColors2.gray140 = "#484644";
  NeutralColors2.gray130 = "#605e5c";
  NeutralColors2.gray120 = "#797775";
  NeutralColors2.gray110 = "#8a8886";
  NeutralColors2.gray100 = "#979593";
  NeutralColors2.gray90 = "#a19f9d";
  NeutralColors2.gray80 = "#b3b0ad";
  NeutralColors2.gray70 = "#bebbb8";
  NeutralColors2.gray60 = "#c8c6c4";
  NeutralColors2.gray50 = "#d2d0ce";
  NeutralColors2.gray40 = "#e1dfdd";
  NeutralColors2.gray30 = "#edebe9";
  NeutralColors2.gray20 = "#f3f2f1";
  NeutralColors2.gray10 = "#faf9f8";
  NeutralColors2.white = "#ffffff";
})(NeutralColors || (NeutralColors = {}));
var SharedColors;
(function(SharedColors2) {
  SharedColors2.pinkRed10 = "#750b1c";
  SharedColors2.red20 = "#a4262c";
  SharedColors2.red10 = "#d13438";
  SharedColors2.redOrange20 = "#603d30";
  SharedColors2.redOrange10 = "#da3b01";
  SharedColors2.orange30 = "#8e562e";
  SharedColors2.orange20 = "#ca5010";
  SharedColors2.orange10 = "#ffaa44";
  SharedColors2.yellow10 = "#fce100";
  SharedColors2.orangeYellow20 = "#986f0b";
  SharedColors2.orangeYellow10 = "#c19c00";
  SharedColors2.yellowGreen10 = "#8cbd18";
  SharedColors2.green20 = "#0b6a0b";
  SharedColors2.green10 = "#498205";
  SharedColors2.greenCyan10 = "#00ad56";
  SharedColors2.cyan40 = "#005e50";
  SharedColors2.cyan30 = "#005b70";
  SharedColors2.cyan20 = "#038387";
  SharedColors2.cyan10 = "#00b7c3";
  SharedColors2.cyanBlue20 = "#004e8c";
  SharedColors2.cyanBlue10 = "#0078d4";
  SharedColors2.blue10 = "#4f6bed";
  SharedColors2.blueMagenta40 = "#373277";
  SharedColors2.blueMagenta30 = "#5c2e91";
  SharedColors2.blueMagenta20 = "#8764b8";
  SharedColors2.blueMagenta10 = "#8378de";
  SharedColors2.magenta20 = "#881798";
  SharedColors2.magenta10 = "#c239b3";
  SharedColors2.magentaPink20 = "#9b0062";
  SharedColors2.magentaPink10 = "#e3008c";
  SharedColors2.gray40 = "#393939";
  SharedColors2.gray30 = "#7a7574";
  SharedColors2.gray20 = "#69797e";
  SharedColors2.gray10 = "#a0aeb2";
})(SharedColors || (SharedColors = {}));

// node_modules/@fluentui/theme/lib/colors/DefaultPalette.js
var DefaultPalette = {
  themeDarker: "#004578",
  themeDark: "#005a9e",
  themeDarkAlt: "#106ebe",
  themePrimary: "#0078d4",
  themeSecondary: "#2b88d8",
  themeTertiary: "#71afe5",
  themeLight: "#c7e0f4",
  themeLighter: "#deecf9",
  themeLighterAlt: "#eff6fc",
  black: "#000000",
  blackTranslucent40: "rgba(0,0,0,.4)",
  neutralDark: "#201f1e",
  neutralPrimary: "#323130",
  neutralPrimaryAlt: "#3b3a39",
  neutralSecondary: "#605e5c",
  neutralSecondaryAlt: "#8a8886",
  neutralTertiary: "#a19f9d",
  neutralTertiaryAlt: "#c8c6c4",
  neutralQuaternary: "#d2d0ce",
  neutralQuaternaryAlt: "#e1dfdd",
  neutralLight: "#edebe9",
  neutralLighter: "#f3f2f1",
  neutralLighterAlt: "#faf9f8",
  accent: "#0078d4",
  white: "#ffffff",
  whiteTranslucent40: "rgba(255,255,255,.4)",
  yellowDark: "#d29200",
  yellow: "#ffb900",
  yellowLight: "#fff100",
  orange: "#d83b01",
  orangeLight: "#ea4300",
  orangeLighter: "#ff8c00",
  redDark: "#a4262c",
  red: "#e81123",
  magentaDark: "#5c005c",
  magenta: "#b4009e",
  magentaLight: "#e3008c",
  purpleDark: "#32145a",
  purple: "#5c2d91",
  purpleLight: "#b4a0ff",
  blueDark: "#002050",
  blueMid: "#00188f",
  blue: "#0078d4",
  blueLight: "#00bcf2",
  tealDark: "#004b50",
  teal: "#008272",
  tealLight: "#00b294",
  greenDark: "#004b1c",
  green: "#107c10",
  greenLight: "#bad80a"
};

// node_modules/@fluentui/theme/lib/effects/FluentDepths.js
var Depths;
(function(Depths2) {
  Depths2.depth0 = "0 0 0 0 transparent";
  Depths2.depth4 = "0 1.6px 3.6px 0 rgba(0, 0, 0, 0.132), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.108)";
  Depths2.depth8 = "0 3.2px 7.2px 0 rgba(0, 0, 0, 0.132), 0 0.6px 1.8px 0 rgba(0, 0, 0, 0.108)";
  Depths2.depth16 = "0 6.4px 14.4px 0 rgba(0, 0, 0, 0.132), 0 1.2px 3.6px 0 rgba(0, 0, 0, 0.108)";
  Depths2.depth64 = "0 25.6px 57.6px 0 rgba(0, 0, 0, 0.22), 0 4.8px 14.4px 0 rgba(0, 0, 0, 0.18)";
})(Depths || (Depths = {}));

// node_modules/@fluentui/theme/lib/effects/DefaultEffects.js
var DefaultEffects = {
  elevation4: Depths.depth4,
  elevation8: Depths.depth8,
  elevation16: Depths.depth16,
  elevation64: Depths.depth64,
  roundedCorner2: "2px",
  roundedCorner4: "4px",
  roundedCorner6: "6px"
};

// node_modules/@fluentui/theme/lib/spacing/DefaultSpacing.js
var DefaultSpacing = {
  s2: "4px",
  s1: "8px",
  m: "16px",
  l1: "20px",
  l2: "32px"
};

// node_modules/@fluentui/theme/lib/motion/FluentMotion.js
var fadeInAnimationName = keyframes({
  from: { opacity: 0 },
  to: { opacity: 1 }
});
var fadeOutAnimationName = keyframes({
  from: { opacity: 1 },
  to: { opacity: 0 }
});
var scaleDownInAnimationName = keyframes({
  from: { transform: "scale3d(1.15, 1.15, 1)" },
  to: { transform: "scale3d(1, 1, 1)" }
});
var scaleDownOutAnimationName = keyframes({
  from: { transform: "scale3d(1, 1, 1)" },
  to: { transform: "scale3d(0.9, 0.9, 1)" }
});
var slideLeftOutAnimationName = keyframes({
  from: { transform: "translate3d(0, 0, 0)" },
  to: { transform: "translate3d(-48px, 0, 0)" }
});
var slideRightOutAnimationName = keyframes({
  from: { transform: "translate3d(0, 0, 0)" },
  to: { transform: "translate3d(48px, 0, 0)" }
});
var slideLeftInAnimationName = keyframes({
  from: { transform: "translate3d(48px, 0, 0)" },
  to: { transform: "translate3d(0, 0, 0)" }
});
var slideRightInAnimationName = keyframes({
  from: { transform: "translate3d(-48px, 0, 0)" },
  to: { transform: "translate3d(0, 0, 0)" }
});
var slideUpOutAnimationName = keyframes({
  from: { transform: "translate3d(0, 0, 0)" },
  to: { transform: "translate3d(0, -48px, 0)" }
});
var slideDownOutAnimationName = keyframes({
  from: { transform: "translate3d(0, 0, 0)" },
  to: { transform: "translate3d(0, 48px, 0)" }
});
var slideUpInAnimationName = keyframes({
  from: { transform: "translate3d(0, 48px, 0)" },
  to: { transform: "translate3d(0, 0, 0)" }
});
var slideDownInAnimationName = keyframes({
  from: { transform: "translate3d(0, -48px, 0)" },
  to: { transform: "translate3d(0, 0, 0)" }
});
var MotionDurations;
(function(MotionDurations2) {
  MotionDurations2.duration1 = "100ms";
  MotionDurations2.duration2 = "200ms";
  MotionDurations2.duration3 = "300ms";
  MotionDurations2.duration4 = "400ms";
})(MotionDurations || (MotionDurations = {}));
var MotionTimings;
(function(MotionTimings2) {
  MotionTimings2.accelerate = "cubic-bezier(0.9, 0.1, 1, 0.2)";
  MotionTimings2.decelerate = "cubic-bezier(0.1, 0.9, 0.2, 1)";
  MotionTimings2.linear = "cubic-bezier(0, 0, 1, 1)";
  MotionTimings2.standard = "cubic-bezier(0.8, 0, 0.2, 1)";
})(MotionTimings || (MotionTimings = {}));
function _createAnimation(animationName, animationDuration, animationTimingFunction) {
  return "".concat(animationName, " ").concat(animationDuration, " ").concat(animationTimingFunction);
}
var MotionAnimations;
(function(MotionAnimations2) {
  MotionAnimations2.fadeIn = _createAnimation(fadeInAnimationName, MotionDurations.duration1, MotionTimings.linear);
  MotionAnimations2.fadeOut = _createAnimation(fadeOutAnimationName, MotionDurations.duration1, MotionTimings.linear);
  MotionAnimations2.scaleDownIn = _createAnimation(scaleDownInAnimationName, MotionDurations.duration3, MotionTimings.decelerate);
  MotionAnimations2.scaleDownOut = _createAnimation(scaleDownOutAnimationName, MotionDurations.duration3, MotionTimings.decelerate);
  MotionAnimations2.slideLeftOut = _createAnimation(slideLeftOutAnimationName, MotionDurations.duration1, MotionTimings.accelerate);
  MotionAnimations2.slideRightOut = _createAnimation(slideRightOutAnimationName, MotionDurations.duration1, MotionTimings.accelerate);
  MotionAnimations2.slideLeftIn = _createAnimation(slideLeftInAnimationName, MotionDurations.duration1, MotionTimings.decelerate);
  MotionAnimations2.slideRightIn = _createAnimation(slideRightInAnimationName, MotionDurations.duration1, MotionTimings.decelerate);
  MotionAnimations2.slideUpOut = _createAnimation(slideUpOutAnimationName, MotionDurations.duration1, MotionTimings.accelerate);
  MotionAnimations2.slideDownOut = _createAnimation(slideDownOutAnimationName, MotionDurations.duration1, MotionTimings.accelerate);
  MotionAnimations2.slideUpIn = _createAnimation(slideUpInAnimationName, MotionDurations.duration1, MotionTimings.decelerate);
  MotionAnimations2.slideDownIn = _createAnimation(slideDownInAnimationName, MotionDurations.duration1, MotionTimings.decelerate);
})(MotionAnimations || (MotionAnimations = {}));

// node_modules/@fluentui/theme/lib/motion/AnimationStyles.js
var EASING_FUNCTION_1 = "cubic-bezier(.1,.9,.2,1)";
var EASING_FUNCTION_2 = "cubic-bezier(.1,.25,.75,.9)";
var DURATION_1 = "0.167s";
var DURATION_2 = "0.267s";
var DURATION_3 = "0.367s";
var DURATION_4 = "0.467s";
var FADE_IN = keyframes({
  from: { opacity: 0 },
  to: { opacity: 1 }
});
var FADE_OUT = keyframes({
  from: { opacity: 1 },
  to: { opacity: 0, visibility: "hidden" }
});
var SLIDE_RIGHT_IN10 = _createSlideInX(-10);
var SLIDE_RIGHT_IN20 = _createSlideInX(-20);
var SLIDE_RIGHT_IN40 = _createSlideInX(-40);
var SLIDE_RIGHT_IN400 = _createSlideInX(-400);
var SLIDE_LEFT_IN10 = _createSlideInX(10);
var SLIDE_LEFT_IN20 = _createSlideInX(20);
var SLIDE_LEFT_IN40 = _createSlideInX(40);
var SLIDE_LEFT_IN400 = _createSlideInX(400);
var SLIDE_UP_IN10 = _createSlideInY(10);
var SLIDE_UP_IN20 = _createSlideInY(20);
var SLIDE_DOWN_IN10 = _createSlideInY(-10);
var SLIDE_DOWN_IN20 = _createSlideInY(-20);
var SLIDE_RIGHT_OUT10 = _createSlideOutX(10);
var SLIDE_RIGHT_OUT20 = _createSlideOutX(20);
var SLIDE_RIGHT_OUT40 = _createSlideOutX(40);
var SLIDE_RIGHT_OUT400 = _createSlideOutX(400);
var SLIDE_LEFT_OUT10 = _createSlideOutX(-10);
var SLIDE_LEFT_OUT20 = _createSlideOutX(-20);
var SLIDE_LEFT_OUT40 = _createSlideOutX(-40);
var SLIDE_LEFT_OUT400 = _createSlideOutX(-400);
var SLIDE_UP_OUT10 = _createSlideOutY(-10);
var SLIDE_UP_OUT20 = _createSlideOutY(-20);
var SLIDE_DOWN_OUT10 = _createSlideOutY(10);
var SLIDE_DOWN_OUT20 = _createSlideOutY(20);
var SCALE_UP100 = keyframes({
  from: { transform: "scale3d(.98,.98,1)" },
  to: { transform: "scale3d(1,1,1)" }
});
var SCALE_DOWN98 = keyframes({
  from: { transform: "scale3d(1,1,1)" },
  to: { transform: "scale3d(.98,.98,1)" }
});
var SCALE_DOWN100 = keyframes({
  from: { transform: "scale3d(1.03,1.03,1)" },
  to: { transform: "scale3d(1,1,1)" }
});
var SCALE_UP103 = keyframes({
  from: { transform: "scale3d(1,1,1)" },
  to: { transform: "scale3d(1.03,1.03,1)" }
});
var ROTATE90 = keyframes({
  from: { transform: "rotateZ(0deg)" },
  to: { transform: "rotateZ(90deg)" }
});
var ROTATE_N90 = keyframes({
  from: { transform: "rotateZ(0deg)" },
  to: { transform: "rotateZ(-90deg)" }
});
var AnimationVariables = {
  easeFunction1: EASING_FUNCTION_1,
  easeFunction2: EASING_FUNCTION_2,
  durationValue1: DURATION_1,
  durationValue2: DURATION_2,
  durationValue3: DURATION_3,
  durationValue4: DURATION_4
};
var AnimationStyles = {
  slideRightIn10: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_RIGHT_IN10), DURATION_3, EASING_FUNCTION_1),
  slideRightIn20: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_RIGHT_IN20), DURATION_3, EASING_FUNCTION_1),
  slideRightIn40: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_RIGHT_IN40), DURATION_3, EASING_FUNCTION_1),
  slideRightIn400: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_RIGHT_IN400), DURATION_3, EASING_FUNCTION_1),
  slideLeftIn10: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_LEFT_IN10), DURATION_3, EASING_FUNCTION_1),
  slideLeftIn20: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_LEFT_IN20), DURATION_3, EASING_FUNCTION_1),
  slideLeftIn40: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_LEFT_IN40), DURATION_3, EASING_FUNCTION_1),
  slideLeftIn400: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_LEFT_IN400), DURATION_3, EASING_FUNCTION_1),
  slideUpIn10: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_UP_IN10), DURATION_3, EASING_FUNCTION_1),
  slideUpIn20: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_UP_IN20), DURATION_3, EASING_FUNCTION_1),
  slideDownIn10: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_DOWN_IN10), DURATION_3, EASING_FUNCTION_1),
  slideDownIn20: _createAnimation2("".concat(FADE_IN, ",").concat(SLIDE_DOWN_IN20), DURATION_3, EASING_FUNCTION_1),
  slideRightOut10: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_RIGHT_OUT10), DURATION_3, EASING_FUNCTION_1),
  slideRightOut20: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_RIGHT_OUT20), DURATION_3, EASING_FUNCTION_1),
  slideRightOut40: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_RIGHT_OUT40), DURATION_3, EASING_FUNCTION_1),
  slideRightOut400: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_RIGHT_OUT400), DURATION_3, EASING_FUNCTION_1),
  slideLeftOut10: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_LEFT_OUT10), DURATION_3, EASING_FUNCTION_1),
  slideLeftOut20: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_LEFT_OUT20), DURATION_3, EASING_FUNCTION_1),
  slideLeftOut40: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_LEFT_OUT40), DURATION_3, EASING_FUNCTION_1),
  slideLeftOut400: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_LEFT_OUT400), DURATION_3, EASING_FUNCTION_1),
  slideUpOut10: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_UP_OUT10), DURATION_3, EASING_FUNCTION_1),
  slideUpOut20: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_UP_OUT20), DURATION_3, EASING_FUNCTION_1),
  slideDownOut10: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_DOWN_OUT10), DURATION_3, EASING_FUNCTION_1),
  slideDownOut20: _createAnimation2("".concat(FADE_OUT, ",").concat(SLIDE_DOWN_OUT20), DURATION_3, EASING_FUNCTION_1),
  scaleUpIn100: _createAnimation2("".concat(FADE_IN, ",").concat(SCALE_UP100), DURATION_3, EASING_FUNCTION_1),
  scaleDownIn100: _createAnimation2("".concat(FADE_IN, ",").concat(SCALE_DOWN100), DURATION_3, EASING_FUNCTION_1),
  scaleUpOut103: _createAnimation2("".concat(FADE_OUT, ",").concat(SCALE_UP103), DURATION_1, EASING_FUNCTION_2),
  scaleDownOut98: _createAnimation2("".concat(FADE_OUT, ",").concat(SCALE_DOWN98), DURATION_1, EASING_FUNCTION_2),
  fadeIn100: _createAnimation2(FADE_IN, DURATION_1, EASING_FUNCTION_2),
  fadeIn200: _createAnimation2(FADE_IN, DURATION_2, EASING_FUNCTION_2),
  fadeIn400: _createAnimation2(FADE_IN, DURATION_3, EASING_FUNCTION_2),
  fadeIn500: _createAnimation2(FADE_IN, DURATION_4, EASING_FUNCTION_2),
  fadeOut100: _createAnimation2(FADE_OUT, DURATION_1, EASING_FUNCTION_2),
  fadeOut200: _createAnimation2(FADE_OUT, DURATION_2, EASING_FUNCTION_2),
  fadeOut400: _createAnimation2(FADE_OUT, DURATION_3, EASING_FUNCTION_2),
  fadeOut500: _createAnimation2(FADE_OUT, DURATION_4, EASING_FUNCTION_2),
  rotate90deg: _createAnimation2(ROTATE90, "0.1s", EASING_FUNCTION_2),
  rotateN90deg: _createAnimation2(ROTATE_N90, "0.1s", EASING_FUNCTION_2)
  // expandCollapse 100/200/400, delay 100/200
};
function _createAnimation2(animationName, animationDuration, animationTimingFunction) {
  return {
    animationName,
    animationDuration,
    animationTimingFunction,
    animationFillMode: "both"
  };
}
function _createSlideInX(fromX) {
  return keyframes({
    from: { transform: "translate3d(".concat(fromX, "px,0,0)"), pointerEvents: "none" },
    to: { transform: "translate3d(0,0,0)", pointerEvents: "auto" }
  });
}
function _createSlideInY(fromY) {
  return keyframes({
    from: { transform: "translate3d(0,".concat(fromY, "px,0)"), pointerEvents: "none" },
    to: { transform: "translate3d(0,0,0)", pointerEvents: "auto" }
  });
}
function _createSlideOutX(toX) {
  return keyframes({
    from: { transform: "translate3d(0,0,0)" },
    to: { transform: "translate3d(".concat(toX, "px,0,0)") }
  });
}
function _createSlideOutY(toY) {
  return keyframes({
    from: { transform: "translate3d(0,0,0)" },
    to: { transform: "translate3d(0,".concat(toY, "px,0)") }
  });
}

// node_modules/@fluentui/theme/lib/fonts/FluentFonts.js
var LocalizedFontNames;
(function(LocalizedFontNames2) {
  LocalizedFontNames2.Arabic = "Segoe UI Web (Arabic)";
  LocalizedFontNames2.Cyrillic = "Segoe UI Web (Cyrillic)";
  LocalizedFontNames2.EastEuropean = "Segoe UI Web (East European)";
  LocalizedFontNames2.Greek = "Segoe UI Web (Greek)";
  LocalizedFontNames2.Hebrew = "Segoe UI Web (Hebrew)";
  LocalizedFontNames2.Thai = "Leelawadee UI Web";
  LocalizedFontNames2.Vietnamese = "Segoe UI Web (Vietnamese)";
  LocalizedFontNames2.WestEuropean = "Segoe UI Web (West European)";
  LocalizedFontNames2.Selawik = "Selawik Web";
  LocalizedFontNames2.Armenian = "Segoe UI Web (Armenian)";
  LocalizedFontNames2.Georgian = "Segoe UI Web (Georgian)";
})(LocalizedFontNames || (LocalizedFontNames = {}));
var LocalizedFontFamilies;
(function(LocalizedFontFamilies2) {
  LocalizedFontFamilies2.Arabic = "'".concat(LocalizedFontNames.Arabic, "'");
  LocalizedFontFamilies2.ChineseSimplified = "'Microsoft Yahei UI', Verdana, Simsun";
  LocalizedFontFamilies2.ChineseTraditional = "'Microsoft Jhenghei UI', Pmingliu";
  LocalizedFontFamilies2.Cyrillic = "'".concat(LocalizedFontNames.Cyrillic, "'");
  LocalizedFontFamilies2.EastEuropean = "'".concat(LocalizedFontNames.EastEuropean, "'");
  LocalizedFontFamilies2.Greek = "'".concat(LocalizedFontNames.Greek, "'");
  LocalizedFontFamilies2.Hebrew = "'".concat(LocalizedFontNames.Hebrew, "'");
  LocalizedFontFamilies2.Hindi = "'Nirmala UI'";
  LocalizedFontFamilies2.Japanese = "'Yu Gothic UI', 'Meiryo UI', Meiryo, 'MS Pgothic', Osaka";
  LocalizedFontFamilies2.Korean = "'Malgun Gothic', Gulim";
  LocalizedFontFamilies2.Selawik = "'".concat(LocalizedFontNames.Selawik, "'");
  LocalizedFontFamilies2.Thai = "'Leelawadee UI Web', 'Kmer UI'";
  LocalizedFontFamilies2.Vietnamese = "'".concat(LocalizedFontNames.Vietnamese, "'");
  LocalizedFontFamilies2.WestEuropean = "'".concat(LocalizedFontNames.WestEuropean, "'");
  LocalizedFontFamilies2.Armenian = "'".concat(LocalizedFontNames.Armenian, "'");
  LocalizedFontFamilies2.Georgian = "'".concat(LocalizedFontNames.Georgian, "'");
})(LocalizedFontFamilies || (LocalizedFontFamilies = {}));
var FontSizes;
(function(FontSizes2) {
  FontSizes2.size10 = "10px";
  FontSizes2.size12 = "12px";
  FontSizes2.size14 = "14px";
  FontSizes2.size16 = "16px";
  FontSizes2.size18 = "18px";
  FontSizes2.size20 = "20px";
  FontSizes2.size24 = "24px";
  FontSizes2.size28 = "28px";
  FontSizes2.size32 = "32px";
  FontSizes2.size42 = "42px";
  FontSizes2.size68 = "68px";
  FontSizes2.mini = "10px";
  FontSizes2.xSmall = "10px";
  FontSizes2.small = "12px";
  FontSizes2.smallPlus = "12px";
  FontSizes2.medium = "14px";
  FontSizes2.mediumPlus = "16px";
  FontSizes2.icon = "16px";
  FontSizes2.large = "18px";
  FontSizes2.xLarge = "20px";
  FontSizes2.xLargePlus = "24px";
  FontSizes2.xxLarge = "28px";
  FontSizes2.xxLargePlus = "32px";
  FontSizes2.superLarge = "42px";
  FontSizes2.mega = "68px";
})(FontSizes || (FontSizes = {}));
var FontWeights;
(function(FontWeights2) {
  FontWeights2.light = 100;
  FontWeights2.semilight = 300;
  FontWeights2.regular = 400;
  FontWeights2.semibold = 600;
  FontWeights2.bold = 700;
})(FontWeights || (FontWeights = {}));
var IconFontSizes;
(function(IconFontSizes2) {
  IconFontSizes2.xSmall = "10px";
  IconFontSizes2.small = "12px";
  IconFontSizes2.medium = "16px";
  IconFontSizes2.large = "20px";
})(IconFontSizes || (IconFontSizes = {}));

// node_modules/@fluentui/theme/lib/fonts/createFontStyles.js
var FontFamilyFallbacks = "'Segoe UI', -apple-system, BlinkMacSystemFont, 'Roboto', 'Helvetica Neue', sans-serif";
var defaultFontFamily = "'Segoe UI', '".concat(LocalizedFontNames.WestEuropean, "'");
var LanguageToFontMap = {
  ar: LocalizedFontFamilies.Arabic,
  bg: LocalizedFontFamilies.Cyrillic,
  cs: LocalizedFontFamilies.EastEuropean,
  el: LocalizedFontFamilies.Greek,
  et: LocalizedFontFamilies.EastEuropean,
  he: LocalizedFontFamilies.Hebrew,
  hi: LocalizedFontFamilies.Hindi,
  hr: LocalizedFontFamilies.EastEuropean,
  hu: LocalizedFontFamilies.EastEuropean,
  ja: LocalizedFontFamilies.Japanese,
  kk: LocalizedFontFamilies.EastEuropean,
  ko: LocalizedFontFamilies.Korean,
  lt: LocalizedFontFamilies.EastEuropean,
  lv: LocalizedFontFamilies.EastEuropean,
  pl: LocalizedFontFamilies.EastEuropean,
  ru: LocalizedFontFamilies.Cyrillic,
  sk: LocalizedFontFamilies.EastEuropean,
  "sr-latn": LocalizedFontFamilies.EastEuropean,
  th: LocalizedFontFamilies.Thai,
  tr: LocalizedFontFamilies.EastEuropean,
  uk: LocalizedFontFamilies.Cyrillic,
  vi: LocalizedFontFamilies.Vietnamese,
  "zh-hans": LocalizedFontFamilies.ChineseSimplified,
  "zh-hant": LocalizedFontFamilies.ChineseTraditional,
  hy: LocalizedFontFamilies.Armenian,
  ka: LocalizedFontFamilies.Georgian
};
function _fontFamilyWithFallbacks(fontFamily) {
  return "".concat(fontFamily, ", ").concat(FontFamilyFallbacks);
}
function _getLocalizedFontFamily(language) {
  for (var lang in LanguageToFontMap) {
    if (LanguageToFontMap.hasOwnProperty(lang) && language && lang.indexOf(language) === 0) {
      return LanguageToFontMap[lang];
    }
  }
  return defaultFontFamily;
}
function _createFont(size, weight, fontFamily) {
  return {
    fontFamily,
    MozOsxFontSmoothing: "grayscale",
    WebkitFontSmoothing: "antialiased",
    fontSize: size,
    fontWeight: weight
  };
}
function createFontStyles(localeCode) {
  var localizedFont = _getLocalizedFontFamily(localeCode);
  var fontFamilyWithFallback = _fontFamilyWithFallbacks(localizedFont);
  var fontStyles = {
    tiny: _createFont(FontSizes.mini, FontWeights.regular, fontFamilyWithFallback),
    xSmall: _createFont(FontSizes.xSmall, FontWeights.regular, fontFamilyWithFallback),
    small: _createFont(FontSizes.small, FontWeights.regular, fontFamilyWithFallback),
    smallPlus: _createFont(FontSizes.smallPlus, FontWeights.regular, fontFamilyWithFallback),
    medium: _createFont(FontSizes.medium, FontWeights.regular, fontFamilyWithFallback),
    mediumPlus: _createFont(FontSizes.mediumPlus, FontWeights.regular, fontFamilyWithFallback),
    large: _createFont(FontSizes.large, FontWeights.regular, fontFamilyWithFallback),
    xLarge: _createFont(FontSizes.xLarge, FontWeights.semibold, fontFamilyWithFallback),
    xLargePlus: _createFont(FontSizes.xLargePlus, FontWeights.semibold, fontFamilyWithFallback),
    xxLarge: _createFont(FontSizes.xxLarge, FontWeights.semibold, fontFamilyWithFallback),
    xxLargePlus: _createFont(FontSizes.xxLargePlus, FontWeights.semibold, fontFamilyWithFallback),
    superLarge: _createFont(FontSizes.superLarge, FontWeights.semibold, fontFamilyWithFallback),
    mega: _createFont(FontSizes.mega, FontWeights.semibold, fontFamilyWithFallback)
  };
  return fontStyles;
}

// node_modules/@fluentui/theme/lib/fonts/DefaultFontStyles.js
var DefaultBaseUrl = "https://res-1.cdn.office.net/files/fabric-cdn-prod_20230815.002/assets";
var DefaultFontStyles = createFontStyles(getLanguage());
function _registerFontFace(fontFamily, url, fontWeight, localFontName) {
  fontFamily = "'".concat(fontFamily, "'");
  var localFontSrc = localFontName !== void 0 ? "local('".concat(localFontName, "'),") : "";
  fontFace({
    fontFamily,
    src: localFontSrc + "url('".concat(url, ".woff2') format('woff2'),") + "url('".concat(url, ".woff') format('woff')"),
    fontWeight,
    fontStyle: "normal",
    fontDisplay: "swap"
  });
}
function _registerFontFaceSet(baseUrl, fontFamily, cdnFolder, cdnFontName, localFontName) {
  if (cdnFontName === void 0) {
    cdnFontName = "segoeui";
  }
  var urlBase = "".concat(baseUrl, "/").concat(cdnFolder, "/").concat(cdnFontName);
  _registerFontFace(fontFamily, urlBase + "-light", FontWeights.light, localFontName && localFontName + " Light");
  _registerFontFace(fontFamily, urlBase + "-semilight", FontWeights.semilight, localFontName && localFontName + " SemiLight");
  _registerFontFace(fontFamily, urlBase + "-regular", FontWeights.regular, localFontName);
  _registerFontFace(fontFamily, urlBase + "-semibold", FontWeights.semibold, localFontName && localFontName + " SemiBold");
  _registerFontFace(fontFamily, urlBase + "-bold", FontWeights.bold, localFontName && localFontName + " Bold");
}
function registerDefaultFontFaces(baseUrl) {
  if (baseUrl) {
    var fontUrl = "".concat(baseUrl, "/fonts");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Thai, "leelawadeeui-thai", "leelawadeeui");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Arabic, "segoeui-arabic");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Cyrillic, "segoeui-cyrillic");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.EastEuropean, "segoeui-easteuropean");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Greek, "segoeui-greek");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Hebrew, "segoeui-hebrew");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Vietnamese, "segoeui-vietnamese");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.WestEuropean, "segoeui-westeuropean", "segoeui", "Segoe UI");
    _registerFontFaceSet(fontUrl, LocalizedFontFamilies.Selawik, "selawik", "selawik");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Armenian, "segoeui-armenian");
    _registerFontFaceSet(fontUrl, LocalizedFontNames.Georgian, "segoeui-georgian");
    _registerFontFace("Leelawadee UI Web", "".concat(fontUrl, "/leelawadeeui-thai/leelawadeeui-semilight"), FontWeights.light);
    _registerFontFace("Leelawadee UI Web", "".concat(fontUrl, "/leelawadeeui-thai/leelawadeeui-bold"), FontWeights.semibold);
  }
}
function _getFontBaseUrl() {
  var _a, _b;
  var fabricConfig = (_a = getWindow()) === null || _a === void 0 ? void 0 : _a.FabricConfig;
  return (_b = fabricConfig === null || fabricConfig === void 0 ? void 0 : fabricConfig.fontBaseUrl) !== null && _b !== void 0 ? _b : DefaultBaseUrl;
}
registerDefaultFontFaces(_getFontBaseUrl());

// node_modules/@fluentui/theme/lib/createTheme.js
function createTheme(theme, depComments) {
  if (theme === void 0) {
    theme = {};
  }
  if (depComments === void 0) {
    depComments = false;
  }
  var isInverted = !!theme.isInverted;
  var baseTheme = {
    palette: DefaultPalette,
    effects: DefaultEffects,
    fonts: DefaultFontStyles,
    spacing: DefaultSpacing,
    isInverted,
    disableGlobalClassNames: false,
    semanticColors: makeSemanticColors(DefaultPalette, DefaultEffects, void 0, isInverted, depComments),
    rtl: void 0
  };
  return mergeThemes(baseTheme, theme);
}

// node_modules/@fluentui/theme/lib/FluentTheme.js
var FluentTheme = createTheme({});

// node_modules/@fluentui/theme/lib/version.js
setVersion("@fluentui/theme", "2.6.36");

// node_modules/@fluentui/style-utilities/lib/styles/CommonStyles.js
var HighContrastSelector = "@media screen and (-ms-high-contrast: active), screen and (forced-colors: active)";
var HighContrastSelectorWhite = (
  // eslint-disable-next-line @fluentui/max-len
  "@media screen and (-ms-high-contrast: black-on-white), screen and (forced-colors: active) and (prefers-color-scheme: light)"
);
var HighContrastSelectorBlack = (
  // eslint-disable-next-line @fluentui/max-len
  "@media screen and (-ms-high-contrast: white-on-black), screen and (forced-colors: active) and (prefers-color-scheme: dark)"
);
var EdgeChromiumHighContrastSelector = "@media screen and (-ms-high-contrast: active), screen and (forced-colors: active)";
var ScreenWidthMinSmall = 320;
var ScreenWidthMinMedium = 480;
var ScreenWidthMinLarge = 640;
var ScreenWidthMinXLarge = 1024;
var ScreenWidthMinXXLarge = 1366;
var ScreenWidthMinXXXLarge = 1920;
var ScreenWidthMaxSmall = ScreenWidthMinMedium - 1;
var ScreenWidthMaxMedium = ScreenWidthMinLarge - 1;
var ScreenWidthMaxLarge = ScreenWidthMinXLarge - 1;
var ScreenWidthMaxXLarge = ScreenWidthMinXXLarge - 1;
var ScreenWidthMaxXXLarge = ScreenWidthMinXXXLarge - 1;
var ScreenWidthMinUhfMobile = 768;
function getScreenSelector(min, max) {
  var minSelector = typeof min === "number" ? " and (min-width: ".concat(min, "px)") : "";
  var maxSelector = typeof max === "number" ? " and (max-width: ".concat(max, "px)") : "";
  return "@media only screen".concat(minSelector).concat(maxSelector);
}
function getHighContrastNoAdjustStyle() {
  return {
    forcedColorAdjust: "none",
    MsHighContrastAdjust: "none"
  };
}
function getEdgeChromiumNoHighContrastAdjustSelector() {
  var _a;
  return _a = {}, // eslint-disable-next-line deprecation/deprecation
  _a[EdgeChromiumHighContrastSelector] = {
    forcedColorAdjust: "none",
    MsHighContrastAdjust: "none"
  }, _a;
}

// node_modules/@fluentui/style-utilities/lib/styles/zIndexes.js
var ZIndexes;
(function(ZIndexes2) {
  ZIndexes2.Nav = 1;
  ZIndexes2.ScrollablePane = 1;
  ZIndexes2.FocusStyle = 1;
  ZIndexes2.Coachmark = 1e3;
  ZIndexes2.Layer = 1e6;
  ZIndexes2.KeytipLayer = 1000001;
})(ZIndexes || (ZIndexes = {}));

// node_modules/@fluentui/style-utilities/lib/styles/getFocusStyle.js
function getFocusStyle(theme, insetOrOptions, position, highContrastStyle, borderColor, outlineColor, isFocusedOnly, borderRadius) {
  if (typeof insetOrOptions === "number" || !insetOrOptions) {
    return _getFocusStyleInternal(theme, {
      inset: insetOrOptions,
      position,
      highContrastStyle,
      borderColor,
      outlineColor,
      isFocusedOnly,
      borderRadius
    });
  } else {
    return _getFocusStyleInternal(theme, insetOrOptions);
  }
}
function _getFocusStyleInternal(theme, options) {
  var _a, _b;
  if (options === void 0) {
    options = {};
  }
  var borderRadius = options.borderRadius, _c = options.inset, inset = _c === void 0 ? 0 : _c, _d = options.width, width = _d === void 0 ? 1 : _d, _e = options.position, position = _e === void 0 ? "relative" : _e, highContrastStyle = options.highContrastStyle, _f = options.borderColor, borderColor = _f === void 0 ? theme.palette.white : _f, _g = options.outlineColor, outlineColor = _g === void 0 ? theme.palette.neutralSecondary : _g, _h = options.isFocusedOnly, isFocusedOnly = _h === void 0 ? true : _h, pointerEvents = options.pointerEvents;
  return {
    // Clear browser-specific focus styles and use 'transparent' as placeholder for focus style.
    outline: "transparent",
    // Requirement because pseudo-element is absolutely positioned.
    position,
    selectors: (_a = {
      // Clear the focus border in Firefox.
      // Reference: http://stackoverflow.com/a/199319/1436671
      "::-moz-focus-inner": {
        border: "0"
      }
    }, // When the element that uses this mixin is in a :focus state, add a pseudo-element to
    // create a border.
    _a[".".concat(IsFocusVisibleClassName, " &").concat(isFocusedOnly ? ":focus" : "", ":after")] = {
      content: '""',
      position: "absolute",
      pointerEvents,
      left: inset + 1,
      top: inset + 1,
      bottom: inset + 1,
      right: inset + 1,
      border: "".concat(width, "px solid ").concat(borderColor),
      outline: "".concat(width, "px solid ").concat(outlineColor),
      zIndex: ZIndexes.FocusStyle,
      borderRadius,
      selectors: (_b = {}, _b[HighContrastSelector] = highContrastStyle, _b)
    }, _a)
  };
}
function focusClear() {
  return {
    selectors: {
      "&::-moz-focus-inner": {
        // Clear the focus border in Firefox. Reference: http://stackoverflow.com/a/199319/1436671
        border: 0
      },
      "&": {
        // Clear browser specific focus styles and use transparent as placeholder for focus style
        outline: "transparent"
      }
    }
  };
}
function getFocusOutlineStyle(theme, inset, width, color) {
  var _a;
  if (inset === void 0) {
    inset = 0;
  }
  if (width === void 0) {
    width = 1;
  }
  return {
    selectors: (_a = {}, _a[":global(".concat(IsFocusVisibleClassName, ") &:focus")] = {
      outline: "".concat(width, " solid ").concat(color || theme.palette.neutralSecondary),
      outlineOffset: "".concat(-inset, "px")
    }, _a)
  };
}
var getInputFocusStyle = function(borderColor, borderRadius, borderType, borderPosition) {
  var _a, _b, _c;
  if (borderType === void 0) {
    borderType = "border";
  }
  if (borderPosition === void 0) {
    borderPosition = -1;
  }
  var isBorderBottom = borderType === "borderBottom";
  return {
    borderColor,
    selectors: {
      ":after": (_a = {
        pointerEvents: "none",
        content: "''",
        position: "absolute",
        left: isBorderBottom ? 0 : borderPosition,
        top: borderPosition,
        bottom: borderPosition,
        right: isBorderBottom ? 0 : borderPosition
      }, _a[borderType] = "2px solid ".concat(borderColor), _a.borderRadius = borderRadius, _a.width = borderType === "borderBottom" ? "100%" : void 0, _a.selectors = (_b = {}, _b[HighContrastSelector] = (_c = {}, _c[borderType === "border" ? "borderColor" : "borderBottomColor"] = "Highlight", _c), _b), _a)
    }
  };
};

// node_modules/@fluentui/style-utilities/lib/styles/hiddenContentStyle.js
var hiddenContentStyle = {
  position: "absolute",
  width: 1,
  height: 1,
  margin: -1,
  padding: 0,
  border: 0,
  overflow: "hidden",
  whiteSpace: "nowrap"
};

// node_modules/@fluentui/style-utilities/lib/styles/PulsingBeaconAnimationStyles.js
var DEFAULT_DURATION = "14s";
var DEFAULT_DELAY = "2s";
var DEFAULT_ITERATION_COUNT = "1";
function _continuousPulseStepOne(beaconColorOne, innerDimension) {
  return {
    borderColor: beaconColorOne,
    borderWidth: "0px",
    width: innerDimension,
    height: innerDimension
  };
}
function _continuousPulseStepTwo(borderWidth) {
  return {
    opacity: 1,
    borderWidth
  };
}
function _continuousPulseStepThree() {
  return {
    opacity: 1
  };
}
function _continuousPulseStepFour(beaconColorTwo, outerDimension) {
  return {
    borderWidth: "0",
    width: outerDimension,
    height: outerDimension,
    opacity: 0,
    borderColor: beaconColorTwo
  };
}
function _continuousPulseStepFive(beaconColorOne, innerDimension) {
  return __assign(__assign({}, _continuousPulseStepOne(beaconColorOne, innerDimension)), {
    opacity: 0
  });
}
function _continuousPulseAnimationDouble(beaconColorOne, beaconColorTwo, innerDimension, outerDimension, borderWidth) {
  return keyframes({
    "0%": _continuousPulseStepOne(beaconColorOne, innerDimension),
    "1.42%": _continuousPulseStepTwo(borderWidth),
    "3.57%": _continuousPulseStepThree(),
    "7.14%": _continuousPulseStepFour(beaconColorTwo, outerDimension),
    "8%": _continuousPulseStepFive(beaconColorOne, innerDimension),
    "29.99%": _continuousPulseStepFive(beaconColorOne, innerDimension),
    "30%": _continuousPulseStepOne(beaconColorOne, innerDimension),
    "31.42%": _continuousPulseStepTwo(borderWidth),
    "33.57%": _continuousPulseStepThree(),
    "37.14%": _continuousPulseStepFour(beaconColorTwo, outerDimension),
    "38%": _continuousPulseStepFive(beaconColorOne, innerDimension),
    "79.42%": _continuousPulseStepFive(beaconColorOne, innerDimension),
    "79.43": _continuousPulseStepOne(beaconColorOne, innerDimension),
    "81.85": _continuousPulseStepTwo(borderWidth),
    "83.42": _continuousPulseStepThree(),
    "87%": _continuousPulseStepFour(beaconColorTwo, outerDimension),
    "100%": {}
  });
}
function _continuousPulseAnimationSingle(beaconColorOne, beaconColorTwo, innerDimension, outerDimension, borderWidth) {
  return keyframes({
    "0%": _continuousPulseStepOne(beaconColorOne, innerDimension),
    "14.2%": _continuousPulseStepTwo(borderWidth),
    "35.7%": _continuousPulseStepThree(),
    "71.4%": _continuousPulseStepFour(beaconColorTwo, outerDimension),
    "100%": {}
  });
}
function _createDefaultAnimation(animationName, delayLength) {
  return {
    animationName,
    animationIterationCount: DEFAULT_ITERATION_COUNT,
    animationDuration: DEFAULT_DURATION,
    animationDelay: delayLength || DEFAULT_DELAY
  };
}
var PulsingBeaconAnimationStyles = {
  continuousPulseAnimationDouble: _continuousPulseAnimationDouble,
  continuousPulseAnimationSingle: _continuousPulseAnimationSingle,
  createDefaultAnimation: _createDefaultAnimation
};

// node_modules/@fluentui/style-utilities/lib/styles/getGlobalClassNames.js
var _getGlobalClassNames = memoizeFunction(function(classNames, disableGlobalClassNames) {
  var styleSheet = Stylesheet.getInstance();
  if (disableGlobalClassNames) {
    return Object.keys(classNames).reduce(function(acc, className) {
      acc[className] = styleSheet.getClassName(classNames[className]);
      return acc;
    }, {});
  }
  return classNames;
});
function getGlobalClassNames(classNames, theme, disableGlobalClassNames) {
  return _getGlobalClassNames(classNames, disableGlobalClassNames !== void 0 ? disableGlobalClassNames : theme.disableGlobalClassNames);
}

// node_modules/@fluentui/style-utilities/lib/styles/scheme.js
function getThemedContext(context, scheme, theme) {
  var newContext = context;
  var newSettings;
  var schemeSource = theme || Customizations.getSettings(["theme"], void 0, context.customizations).theme;
  if (theme) {
    newSettings = { theme };
  }
  var schemeTheme = scheme && schemeSource && schemeSource.schemes && schemeSource.schemes[scheme];
  if (schemeSource && schemeTheme && schemeSource !== schemeTheme) {
    newSettings = { theme: schemeTheme };
    newSettings.theme.schemes = schemeSource.schemes;
  }
  if (newSettings) {
    newContext = {
      customizations: {
        settings: mergeSettings(context.customizations.settings, newSettings),
        scopedSettings: context.customizations.scopedSettings
      }
    };
  }
  return newContext;
}

// node_modules/@fluentui/style-utilities/lib/styles/theme.js
var _theme = createTheme({});
var _onThemeChangeCallbacks = [];
var ThemeSettingName = "theme";
function initializeThemeInCustomizations() {
  var _a;
  var _b, _c;
  var win = getWindow();
  if ((_b = win === null || win === void 0 ? void 0 : win.FabricConfig) === null || _b === void 0 ? void 0 : _b.legacyTheme) {
    loadTheme2(win.FabricConfig.legacyTheme);
  } else if (!Customizations.getSettings([ThemeSettingName]).theme) {
    if ((_c = win === null || win === void 0 ? void 0 : win.FabricConfig) === null || _c === void 0 ? void 0 : _c.theme) {
      _theme = createTheme(win.FabricConfig.theme);
    }
    Customizations.applySettings((_a = {}, _a[ThemeSettingName] = _theme, _a));
  }
}
initializeThemeInCustomizations();
function getTheme(depComments) {
  if (depComments === void 0) {
    depComments = false;
  }
  if (depComments === true) {
    _theme = createTheme({}, depComments);
  }
  return _theme;
}
function registerOnThemeChangeCallback(callback) {
  if (_onThemeChangeCallbacks.indexOf(callback) === -1) {
    _onThemeChangeCallbacks.push(callback);
  }
}
function removeOnThemeChangeCallback(callback) {
  var i = _onThemeChangeCallbacks.indexOf(callback);
  if (i === -1) {
    return;
  }
  _onThemeChangeCallbacks.splice(i, 1);
}
function loadTheme2(theme, depComments) {
  var _a;
  if (depComments === void 0) {
    depComments = false;
  }
  _theme = createTheme(theme, depComments);
  loadTheme(__assign(__assign(__assign(__assign({}, _theme.palette), _theme.semanticColors), _theme.effects), _loadFonts(_theme)));
  Customizations.applySettings((_a = {}, _a[ThemeSettingName] = _theme, _a));
  _onThemeChangeCallbacks.forEach(function(callback) {
    try {
      callback(_theme);
    } catch (e) {
    }
  });
  return _theme;
}
function _loadFonts(theme) {
  var lines = {};
  for (var _i = 0, _a = Object.keys(theme.fonts); _i < _a.length; _i++) {
    var fontName = _a[_i];
    var font = theme.fonts[fontName];
    for (var _b = 0, _c = Object.keys(font); _b < _c.length; _b++) {
      var propName = _c[_b];
      var name_1 = fontName + propName.charAt(0).toUpperCase() + propName.slice(1);
      var value = font[propName];
      if (propName === "fontSize" && typeof value === "number") {
        value = value + "px";
      }
      lines[name_1] = value;
    }
  }
  return lines;
}

// node_modules/@fluentui/style-utilities/lib/styles/GeneralStyles.js
var normalize = {
  boxShadow: "none",
  margin: 0,
  padding: 0,
  boxSizing: "border-box"
};
var noWrap = {
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap"
};

// node_modules/@fluentui/style-utilities/lib/styles/getFadedOverflowStyle.js
var DEFAULT_HEIGHT = "50%";
var DEFAULT_WIDTH = 20;
function getFadedOverflowStyle(theme, color, direction, width, height) {
  if (color === void 0) {
    color = "bodyBackground";
  }
  if (direction === void 0) {
    direction = "horizontal";
  }
  if (width === void 0) {
    width = getDefaultValue("width", direction);
  }
  if (height === void 0) {
    height = getDefaultValue("height", direction);
  }
  var colorValue = theme.semanticColors[color] || theme.palette[color];
  var rgbColor = color2rgb(colorValue);
  var rgba = "rgba(".concat(rgbColor.r, ", ").concat(rgbColor.g, ", ").concat(rgbColor.b, ", 0)");
  var gradientDirection = direction === "vertical" ? "to bottom" : "to right";
  return {
    content: '""',
    position: "absolute",
    right: 0,
    bottom: 0,
    width,
    height,
    pointerEvents: "none",
    backgroundImage: "linear-gradient(".concat(gradientDirection, ", ").concat(rgba, " 0%, ").concat(colorValue, " 100%)")
  };
}
function color2rgb(colorValue) {
  if (colorValue[0] === "#") {
    return {
      r: parseInt(colorValue.slice(1, 3), 16),
      g: parseInt(colorValue.slice(3, 5), 16),
      b: parseInt(colorValue.slice(5, 7), 16)
    };
  } else if (colorValue.indexOf("rgba(") === 0) {
    colorValue = colorValue.match(/rgba\(([^)]+)\)/)[1];
    var parts = colorValue.split(/ *, */).map(Number);
    return {
      r: parts[0],
      g: parts[1],
      b: parts[2]
    };
  }
  return {
    r: 255,
    g: 255,
    b: 255
  };
}
function getDefaultValue(style, direction) {
  if (style === "width") {
    return direction === "horizontal" ? DEFAULT_WIDTH : "100%";
  } else {
    return direction === "vertical" ? DEFAULT_HEIGHT : "100%";
  }
}

// node_modules/@fluentui/style-utilities/lib/styles/getPlaceholderStyles.js
function getPlaceholderStyles(styles) {
  return {
    selectors: {
      "::placeholder": styles,
      ":-ms-input-placeholder": styles,
      "::-ms-input-placeholder": styles
      // Edge
    }
  };
}

// node_modules/@fluentui/style-utilities/lib/classNames/AnimationClassNames.js
var AnimationClassNames = buildClassMap(AnimationStyles);

// node_modules/@fluentui/style-utilities/lib/classNames/FontClassNames.js
var FontClassNames = buildClassMap(DefaultFontStyles);

// node_modules/@fluentui/style-utilities/lib/classNames/ColorClassNames.js
var ColorClassNames = {};
for (colorName in DefaultPalette) {
  if (DefaultPalette.hasOwnProperty(colorName)) {
    _defineGetter(ColorClassNames, colorName, "", false, "color");
    _defineGetter(ColorClassNames, colorName, "Hover", true, "color");
    _defineGetter(ColorClassNames, colorName, "Background", false, "background");
    _defineGetter(ColorClassNames, colorName, "BackgroundHover", true, "background");
    _defineGetter(ColorClassNames, colorName, "Border", false, "borderColor");
    _defineGetter(ColorClassNames, colorName, "BorderHover", true, "borderColor");
  }
}
var colorName;
function _defineGetter(obj, colorName, suffix, isHover, cssProperty) {
  Object.defineProperty(obj, colorName + suffix, {
    get: function() {
      var _a;
      var style = (_a = {}, _a[cssProperty] = getTheme().palette[colorName], _a);
      return mergeStyles(isHover ? { selectors: { ":hover": style } } : style).toString();
    },
    enumerable: true,
    configurable: true
  });
}

// node_modules/@fluentui/style-utilities/lib/cdn.js
var FLUENT_CDN_BASE_URL = "https://res.cdn.office.net/files/fabric-cdn-prod_20230815.002";

// node_modules/@fluentui/style-utilities/lib/version.js
setVersion("@fluentui/style-utilities", "8.9.18");

// node_modules/@fluentui/style-utilities/lib/index.js
initializeThemeInCustomizations();

export {
  buildClassMap,
  registerIcons,
  unregisterIcons,
  registerIconAlias,
  getIcon,
  setIconOptions,
  getIconClassName,
  mergeThemes,
  CommunicationColors,
  NeutralColors,
  SharedColors,
  DefaultPalette,
  Depths,
  DefaultEffects,
  DefaultSpacing,
  MotionDurations,
  MotionTimings,
  MotionAnimations,
  AnimationVariables,
  AnimationStyles,
  LocalizedFontNames,
  LocalizedFontFamilies,
  FontSizes,
  FontWeights,
  IconFontSizes,
  createFontStyles,
  DefaultFontStyles,
  registerDefaultFontFaces,
  createTheme,
  FluentTheme,
  HighContrastSelector,
  HighContrastSelectorWhite,
  HighContrastSelectorBlack,
  EdgeChromiumHighContrastSelector,
  ScreenWidthMinSmall,
  ScreenWidthMinMedium,
  ScreenWidthMinLarge,
  ScreenWidthMinXLarge,
  ScreenWidthMinXXLarge,
  ScreenWidthMinXXXLarge,
  ScreenWidthMaxSmall,
  ScreenWidthMaxMedium,
  ScreenWidthMaxLarge,
  ScreenWidthMaxXLarge,
  ScreenWidthMaxXXLarge,
  ScreenWidthMinUhfMobile,
  getScreenSelector,
  getHighContrastNoAdjustStyle,
  getEdgeChromiumNoHighContrastAdjustSelector,
  ZIndexes,
  getFocusStyle,
  focusClear,
  getFocusOutlineStyle,
  getInputFocusStyle,
  hiddenContentStyle,
  PulsingBeaconAnimationStyles,
  getGlobalClassNames,
  getThemedContext,
  ThemeSettingName,
  getTheme,
  registerOnThemeChangeCallback,
  removeOnThemeChangeCallback,
  loadTheme2 as loadTheme,
  normalize,
  noWrap,
  getFadedOverflowStyle,
  getPlaceholderStyles,
  AnimationClassNames,
  FontClassNames,
  ColorClassNames,
  FLUENT_CDN_BASE_URL
};
//# sourceMappingURL=chunk-XOB7MPSE.js.map
