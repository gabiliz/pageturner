export var TestFocusEnum = /* @__PURE__ */ ((TestFocusEnum2) => {
  TestFocusEnum2[TestFocusEnum2["CONTABIL"] = 0] = "CONTABIL";
  TestFocusEnum2[TestFocusEnum2["FISCAL"] = 1] = "FISCAL";
  TestFocusEnum2[TestFocusEnum2["OPERACIONAL"] = 2] = "OPERACIONAL";
  TestFocusEnum2[TestFocusEnum2["COMPONENTES"] = 3] = "COMPONENTES";
  TestFocusEnum2[TestFocusEnum2["DUE"] = 4] = "DUE";
  return TestFocusEnum2;
})(TestFocusEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRlc3RGb2N1c0VudW0udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cbmV4cG9ydCBlbnVtIFRlc3RGb2N1c0VudW0ge1xuICBDT05UQUJJTCxcbiAgRklTQ0FMLFxuICBPUEVSQUNJT05BTCxcbiAgQ09NUE9ORU5URVMsXG4gIERVRSxcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ08sV0FBSyxnQkFBTCxrQkFBS0EsbUJBQUw7QUFDTCxFQUFBQSw4QkFBQTtBQUNBLEVBQUFBLDhCQUFBO0FBQ0EsRUFBQUEsOEJBQUE7QUFDQSxFQUFBQSw4QkFBQTtBQUNBLEVBQUFBLDhCQUFBO0FBTFUsU0FBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbIlRlc3RGb2N1c0VudW0iXX0=