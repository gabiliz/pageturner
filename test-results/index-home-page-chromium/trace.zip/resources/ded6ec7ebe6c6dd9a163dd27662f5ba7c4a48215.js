import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/richTextEditor/RichTextEditor.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Placeholder } from "/node_modules/.vite/deps/@tiptap_extension-placeholder.js?v=9f90a7ff";
import { useEditor } from "/node_modules/.vite/deps/@tiptap_react.js?v=9f90a7ff";
import { StarterKit } from "/node_modules/.vite/deps/@tiptap_starter-kit.js?v=9f90a7ff";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport6_react["useEffect"];
import MenuBar from "/src/shared/components/richTextEditor/MenuBar.tsx?t=1701096626433";
import { CharacterCount } from "/node_modules/.vite/deps/@tiptap_extension-character-count.js?v=9f90a7ff";
import { EditorContentStyled, RichTextContainer, RichTextSuffix } from "/src/shared/components/richTextEditor/RichTextEditor.styles.ts";
import { generateContent } from "/src/shared/components/richTextEditor/utils/generateContent.ts";
const RichTextEditor = ({
  content,
  onChangeOutput,
  onCrlShiftEnter,
  placeholder,
  styles: style,
  limit,
  onRenderSuffix,
  minHeight,
  onFocus,
  onBlur
}) => {
  _s();
  const editor = useEditor({
    extensions: [CharacterCount.configure({
      limit
    }), StarterKit, Placeholder.configure({
      placeholder
    })],
    onFocus: (props) => onFocus?.(props),
    onBlur: (props) => onBlur?.(props),
    editorProps: {
      handleKeyDown: (_, e) => {
        if (e.key === "Enter" && e.shiftKey && e.ctrlKey && onCrlShiftEnter) {
          onCrlShiftEnter(e);
        }
      }
    },
    content: generateContent(content),
    onUpdate: ({
      editor: editor2
    }) => {
      if (editor2.isEmpty)
        return onChangeOutput(null);
      const html = editor2.getHTML();
      onChangeOutput(html);
    }
  });
  useEffect(() => {
    if (content === "" && editor) {
      editor.commands.clearContent(true);
    }
  }, [editor, content]);
  return /* @__PURE__ */ jsxDEV(RichTextContainer, { minHeight, style, children: [
    /* @__PURE__ */ jsxDEV(MenuBar, { editor }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(EditorContentStyled, { editor }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this),
    onRenderSuffix !== void 0 && /* @__PURE__ */ jsxDEV(RichTextSuffix, { children: onRenderSuffix() }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx",
      lineNumber: 69,
      columnNumber: 40
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx",
    lineNumber: 64,
    columnNumber: 10
  }, this);
};
_s(RichTextEditor, "WZCukF8Lohz+YFud2L+u9c9a75g=", false, function() {
  return [useEditor];
});
_c = RichTextEditor;
export default RichTextEditor;
var _c;
$RefreshReg$(_c, "RichTextEditor");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/RichTextEditor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVNOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUVOLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBd0M7QUFDakQsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQXVDQyxpQkFBaUI7QUFDeEQsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MscUJBQXFCQyxtQkFBbUJDLHNCQUFzQjtBQUN2RSxTQUFTQyx1QkFBdUI7QUFlaEMsTUFBTUMsaUJBQTJDQSxDQUFDO0FBQUEsRUFDaERDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFFBQVFDO0FBQUFBLEVBQ1JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsU0FBU3RCLFVBQVU7QUFBQSxJQUN2QnVCLFlBQVksQ0FDVm5CLGVBQWVvQixVQUFVO0FBQUEsTUFDdkJSO0FBQUFBLElBQ0YsQ0FBQyxHQUNEZixZQUNBRixZQUFZeUIsVUFBVTtBQUFBLE1BQ3BCWDtBQUFBQSxJQUNGLENBQUMsQ0FBQztBQUFBLElBRUpNLFNBQVVNLFdBQVVOLFVBQVVNLEtBQUs7QUFBQSxJQUNuQ0wsUUFBU0ssV0FBVUwsU0FBU0ssS0FBSztBQUFBLElBQ2pDQyxhQUFhO0FBQUEsTUFDWEMsZUFBZUEsQ0FBQ0MsR0FBR0MsTUFBTTtBQUN2QixZQUFJQSxFQUFFQyxRQUFRLFdBQVdELEVBQUVFLFlBQVlGLEVBQUVHLFdBQVdwQixpQkFBaUI7QUFDbkVBLDBCQUFnQmlCLENBQUM7QUFBQSxRQUNuQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQW5CLFNBQVNGLGdCQUFnQkUsT0FBTztBQUFBLElBQ2hDdUIsVUFBVUEsQ0FBQztBQUFBLE1BQUVYO0FBQUFBLElBQU8sTUFBTTtBQUN4QixVQUFJQSxRQUFPWTtBQUFTLGVBQU92QixlQUFlLElBQUk7QUFFOUMsWUFBTXdCLE9BQU9iLFFBQU9jLFFBQVE7QUFFNUJ6QixxQkFBZXdCLElBQUk7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUVEakMsWUFBVSxNQUFNO0FBQ2QsUUFBSVEsWUFBWSxNQUFNWSxRQUFRO0FBQzVCQSxhQUFPZSxTQUFTQyxhQUFhLElBQUk7QUFBQSxJQUNuQztBQUFBLEVBQ0YsR0FBRyxDQUFDaEIsUUFBUVosT0FBTyxDQUFDO0FBRXBCLFNBQ0UsdUJBQUMscUJBQ0MsV0FDQSxPQUVBO0FBQUEsMkJBQUMsV0FBUSxVQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUV4Qix1QkFBQyx1QkFDQyxVQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDaUI7QUFBQSxJQUdoQk8sbUJBQW1Cc0IsVUFDbEIsdUJBQUMsa0JBQ0V0Qix5QkFBZSxLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNJLEdBakVLWixnQkFBd0M7QUFBQSxVQVk3QlQsU0FBUztBQUFBO0FBQUF3QyxLQVpwQi9CO0FBbUVOLGVBQWVBO0FBQWMsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQbGFjZWhvbGRlciIsInVzZUVkaXRvciIsIlN0YXJ0ZXJLaXQiLCJ1c2VFZmZlY3QiLCJNZW51QmFyIiwiQ2hhcmFjdGVyQ291bnQiLCJFZGl0b3JDb250ZW50U3R5bGVkIiwiUmljaFRleHRDb250YWluZXIiLCJSaWNoVGV4dFN1ZmZpeCIsImdlbmVyYXRlQ29udGVudCIsIlJpY2hUZXh0RWRpdG9yIiwiY29udGVudCIsIm9uQ2hhbmdlT3V0cHV0Iiwib25DcmxTaGlmdEVudGVyIiwicGxhY2Vob2xkZXIiLCJzdHlsZXMiLCJzdHlsZSIsImxpbWl0Iiwib25SZW5kZXJTdWZmaXgiLCJtaW5IZWlnaHQiLCJvbkZvY3VzIiwib25CbHVyIiwiX3MiLCJlZGl0b3IiLCJleHRlbnNpb25zIiwiY29uZmlndXJlIiwicHJvcHMiLCJlZGl0b3JQcm9wcyIsImhhbmRsZUtleURvd24iLCJfIiwiZSIsImtleSIsInNoaWZ0S2V5IiwiY3RybEtleSIsIm9uVXBkYXRlIiwiaXNFbXB0eSIsImh0bWwiLCJnZXRIVE1MIiwiY29tbWFuZHMiLCJjbGVhckNvbnRlbnQiLCJ1bmRlZmluZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJpY2hUZXh0RWRpdG9yLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3JpY2hUZXh0RWRpdG9yL1JpY2hUZXh0RWRpdG9yLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBsYWNlaG9sZGVyIH0gZnJvbSAnQHRpcHRhcC9leHRlbnNpb24tcGxhY2Vob2xkZXInXG5pbXBvcnQgeyB1c2VFZGl0b3IsIENvbnRlbnQsIEVkaXRvckV2ZW50cyB9IGZyb20gJ0B0aXB0YXAvcmVhY3QnXG5pbXBvcnQgeyBTdGFydGVyS2l0IH0gZnJvbSAnQHRpcHRhcC9zdGFydGVyLWtpdCdcbmltcG9ydCB7IENTU1Byb3BlcnRpZXMsIEZDLCBSZWFjdE5vZGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IE1lbnVCYXIgZnJvbSAnLi9NZW51QmFyJ1xuaW1wb3J0IHsgQ2hhcmFjdGVyQ291bnQgfSBmcm9tICdAdGlwdGFwL2V4dGVuc2lvbi1jaGFyYWN0ZXItY291bnQnXG5pbXBvcnQgeyBFZGl0b3JDb250ZW50U3R5bGVkLCBSaWNoVGV4dENvbnRhaW5lciwgUmljaFRleHRTdWZmaXggfSBmcm9tICcuL1JpY2hUZXh0RWRpdG9yLnN0eWxlcydcbmltcG9ydCB7IGdlbmVyYXRlQ29udGVudCB9IGZyb20gJy4vdXRpbHMvZ2VuZXJhdGVDb250ZW50J1xuXG5pbnRlcmZhY2UgSVJpY2hUZXh0RWRpdG9yUHJvcHMge1xuICBjb250ZW50OiBDb250ZW50XG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nXG4gIG9uQ2hhbmdlT3V0cHV0OiAoY29udGVudDogQ29udGVudCkgPT4gdm9pZFxuICBzdHlsZXM/OiBDU1NQcm9wZXJ0aWVzXG4gIGxpbWl0PzogbnVtYmVyXG4gIG1pbkhlaWdodD86IHN0cmluZ1xuICBvbkNybFNoaWZ0RW50ZXI/OiAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHZvaWRcbiAgb25SZW5kZXJTdWZmaXg/OiAoKSA9PiBSZWFjdE5vZGVcbiAgb25Gb2N1cz86IChwcm9wczpFZGl0b3JFdmVudHNbJ2ZvY3VzJ10pID0+IHZvaWRcbiAgb25CbHVyPzogKHByb3BzOkVkaXRvckV2ZW50c1snYmx1ciddKSA9PiB2b2lkXG59XG5cbmNvbnN0IFJpY2hUZXh0RWRpdG9yOiBGQzxJUmljaFRleHRFZGl0b3JQcm9wcz4gPSAoe1xuICBjb250ZW50LFxuICBvbkNoYW5nZU91dHB1dCxcbiAgb25DcmxTaGlmdEVudGVyLFxuICBwbGFjZWhvbGRlcixcbiAgc3R5bGVzOiBzdHlsZSxcbiAgbGltaXQsXG4gIG9uUmVuZGVyU3VmZml4LFxuICBtaW5IZWlnaHQsXG4gIG9uRm9jdXMsXG4gIG9uQmx1cixcbn0pID0+IHtcbiAgY29uc3QgZWRpdG9yID0gdXNlRWRpdG9yKHtcbiAgICBleHRlbnNpb25zOiBbXG4gICAgICBDaGFyYWN0ZXJDb3VudC5jb25maWd1cmUoe1xuICAgICAgICBsaW1pdCxcbiAgICAgIH0pLFxuICAgICAgU3RhcnRlcktpdCxcbiAgICAgIFBsYWNlaG9sZGVyLmNvbmZpZ3VyZSh7XG4gICAgICAgIHBsYWNlaG9sZGVyOiBwbGFjZWhvbGRlcixcbiAgICAgIH0pLFxuICAgIF0sXG4gICAgb25Gb2N1czogKHByb3BzKSA9PiBvbkZvY3VzPy4ocHJvcHMpLFxuICAgIG9uQmx1cjogKHByb3BzKSA9PiBvbkJsdXI/Lihwcm9wcyksXG4gICAgZWRpdG9yUHJvcHM6IHtcbiAgICAgIGhhbmRsZUtleURvd246IChfLCBlKSA9PiB7XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyAmJiBlLnNoaWZ0S2V5ICYmIGUuY3RybEtleSAmJiBvbkNybFNoaWZ0RW50ZXIpIHtcbiAgICAgICAgICBvbkNybFNoaWZ0RW50ZXIoZSlcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9LFxuICAgIGNvbnRlbnQ6IGdlbmVyYXRlQ29udGVudChjb250ZW50KSxcbiAgICBvblVwZGF0ZTogKHsgZWRpdG9yIH0pID0+IHtcbiAgICAgIGlmIChlZGl0b3IuaXNFbXB0eSkgcmV0dXJuIG9uQ2hhbmdlT3V0cHV0KG51bGwpXG5cbiAgICAgIGNvbnN0IGh0bWwgPSBlZGl0b3IuZ2V0SFRNTCgpXG5cbiAgICAgIG9uQ2hhbmdlT3V0cHV0KGh0bWwpXG4gICAgfSxcbiAgfSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjb250ZW50ID09PSAnJyAmJiBlZGl0b3IpIHtcbiAgICAgIGVkaXRvci5jb21tYW5kcy5jbGVhckNvbnRlbnQodHJ1ZSlcbiAgICB9XG4gIH0sIFtlZGl0b3IsIGNvbnRlbnRdKVxuXG4gIHJldHVybiAoXG4gICAgPFJpY2hUZXh0Q29udGFpbmVyXG4gICAgICBtaW5IZWlnaHQ9e21pbkhlaWdodH1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICA+XG4gICAgICA8TWVudUJhciBlZGl0b3I9e2VkaXRvcn0gLz5cblxuICAgICAgPEVkaXRvckNvbnRlbnRTdHlsZWRcbiAgICAgICAgZWRpdG9yPXtlZGl0b3J9XG4gICAgICAvPlxuXG4gICAgICB7b25SZW5kZXJTdWZmaXggIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgIDxSaWNoVGV4dFN1ZmZpeD5cbiAgICAgICAgICB7b25SZW5kZXJTdWZmaXgoKX1cbiAgICAgICAgPC9SaWNoVGV4dFN1ZmZpeD5cbiAgICAgICl9XG4gICAgPC9SaWNoVGV4dENvbnRhaW5lcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSaWNoVGV4dEVkaXRvclxuIl19