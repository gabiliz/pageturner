import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { AppPage, FlexColumn, FlexRow, LoadingScreen, PageTitle } from "/src/shared/components/index.ts?t=1701096626433";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { FinancialStatementsPublicPageContext } from "/src/modules/audit/financialStatements/contexts/FinancialStatementsPublicPageContext.ts";
import { useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { financialStatementsQueryService, financialStatementsRevisionClientDetailsQueryService, financialStatementsRevisionClientTokenService, financialStatementsRevisionClientVersionQueryService } from "/src/modules/audit/financialStatements/services/index.ts";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { FinancialStatementsPublicPageActions, FinancialStatementsPublicPageErrorScreen, FinancialStatementsPublicSection, FinancialStatementsVersionTag } from "/src/modules/audit/financialStatements/components/index.ts?t=1701096626433";
const FinancialStatementsPublicPage = () => {
  _s();
  const {
    fontWeight,
    fontSize,
    colors,
    spacing
  } = useTheme();
  const [searchParams] = useSearchParams();
  const {
    auditId,
    financialId
  } = useParams();
  const tokenEnvio = searchParams.get("tokenEnvio");
  const codigoEnvio = searchParams.get("codigoEnvio");
  const [validationToken, setValidationToken] = useState();
  const [isVisibleFileAnnotations, {
    setTrue: setVisibleFileAnnotations,
    setFalse: setFalseFileAnnotations
  }] = useBoolean(true);
  const [financialCurrentVersion, setfinancialCurrentVersion] = useState();
  function changeVersion(version) {
    setfinancialCurrentVersion(version);
  }
  function changeFileAnnotationsVisibility(visible) {
    if (visible) {
      setVisibleFileAnnotations();
    } else {
      setFalseFileAnnotations();
    }
  }
  const {
    data: financialStatement,
    isLoading
  } = financialStatementsQueryService.useFindOne(auditId, financialId);
  const {
    data: versions,
    isLoading: isLoadingVersions
  } = financialStatementsRevisionClientVersionQueryService.useFindAll(validationToken);
  const {
    data: details,
    isLoading: isLoadingDetails
  } = financialStatementsRevisionClientDetailsQueryService.useFindOne(validationToken);
  const {
    mutateAsync: validateToken,
    isError
  } = useValidateToken(codigoEnvio, tokenEnvio);
  async function getValidationToken() {
    const {
      data: {
        token
      }
    } = await validateToken();
    setValidationToken(token);
  }
  useEffect(() => {
    getValidationToken();
  }, []);
  useEffect(() => {
    if (versions) {
      changeVersion(versions[0]);
    }
  }, [versions]);
  if (isError || !versions || !details) {
    return /* @__PURE__ */ jsxDEV(FinancialStatementsPublicPageErrorScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
      lineNumber: 78,
      columnNumber: 12
    }, this);
  } else if (isLoading || isLoadingVersions || isLoadingDetails) {
    return /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
      lineNumber: 80,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(FinancialStatementsPublicPageContext.Provider, { value: {
    financialStatement,
    isVisibleFileAnnotations,
    changeFileAnnotationsVisibility,
    financialCurrentVersion,
    changeVersion,
    validationToken
  }, children: /* @__PURE__ */ jsxDEV(AppPage, { renderTitle: () => /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: spacing.md, children: [
      /* @__PURE__ */ jsxDEV(PageTitle, { children: "Demonstração financeira" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
        lineNumber: 92,
        columnNumber: 13
      }, this),
      financialCurrentVersion && /* @__PURE__ */ jsxDEV(FinancialStatementsVersionTag, { version: financialCurrentVersion.versao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
        lineNumber: 93,
        columnNumber: 41
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
      lineNumber: 91,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        fontWeight: fontWeight.regular,
        fontSize: fontSize.h4,
        color: colors.gray[400]
      }
    }, children: [
      "Contrato ",
      details?.data.contrato.numeroProposta,
      " - ",
      details?.data.contrato.exercicio,
      " - ",
      details?.data.empresa.razaoSocial
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
      lineNumber: 95,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
    lineNumber: 90,
    columnNumber: 35
  }, this), topRightCorner: /* @__PURE__ */ jsxDEV(FinancialStatementsPublicPageActions, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
    lineNumber: 104,
    columnNumber: 40
  }, this), children: /* @__PURE__ */ jsxDEV(FinancialStatementsPublicSection, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
    lineNumber: 105,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
    lineNumber: 90,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
};
_s(FinancialStatementsPublicPage, "8RfFf7y720m6shRWkC8mndCJbcY=", false, function() {
  return [useTheme, useSearchParams, useParams, useBoolean, financialStatementsQueryService.useFindOne, financialStatementsRevisionClientVersionQueryService.useFindAll, financialStatementsRevisionClientDetailsQueryService.useFindOne, useValidateToken];
});
_c = FinancialStatementsPublicPage;
const useValidateToken = (codigoEnvio, tokenEnvio) => {
  _s2();
  return useMutation(() => financialStatementsRevisionClientTokenService.validateToken(codigoEnvio, tokenEnvio));
};
_s2(useValidateToken, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
  return [useMutation];
});
export default FinancialStatementsPublicPage;
var _c;
$RefreshReg$(_c, "FinancialStatementsPublicPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPublicPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERNOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUROLFNBQWFBLFdBQVdDLGdCQUFnQjtBQUN4QyxTQUFTQyxTQUFTQyxZQUFZQyxTQUFTQyxlQUFlQyxpQkFBaUI7QUFDdkUsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsNENBQTRDO0FBQ3JELFNBQVNDLFdBQVdDLHVCQUF1QjtBQUMzQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUNBQWlDQyxzREFBc0RDLCtDQUErQ0MsNERBQTREO0FBQzNNLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQ0FBc0NDLDBDQUEwQ0Msa0NBQWtDQyxxQ0FBcUM7QUFHaEssTUFBTUMsZ0NBQW9DQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVlDO0FBQUFBLElBQVVDO0FBQUFBLElBQVFDO0FBQUFBLEVBQVEsSUFBSW5CLFNBQVM7QUFDM0QsUUFBTSxDQUFDb0IsWUFBWSxJQUFJakIsZ0JBQWdCO0FBQ3ZDLFFBQU07QUFBQSxJQUFFa0I7QUFBQUEsSUFBU0M7QUFBQUEsRUFBWSxJQUFJcEIsVUFBVTtBQUMzQyxRQUFNcUIsYUFBYUgsYUFBYUksSUFBSSxZQUFZO0FBQ2hELFFBQU1DLGNBQWNMLGFBQWFJLElBQUksYUFBYTtBQUNsRCxRQUFNLENBQUNFLGlCQUFpQkMsa0JBQWtCLElBQUlsQyxTQUFpQjtBQUUvRCxRQUFNLENBQ0ptQywwQkFDQTtBQUFBLElBQUVDLFNBQVNDO0FBQUFBLElBQTJCQyxVQUFVQztBQUFBQSxFQUF3QixDQUFDLElBQ3ZFNUIsV0FBVyxJQUFJO0FBRW5CLFFBQU0sQ0FBQzZCLHlCQUF5QkMsMEJBQTBCLElBQUl6QyxTQUEwQztBQUV4RyxXQUFTMEMsY0FBZUMsU0FBMEM7QUFDaEVGLCtCQUEyQkUsT0FBTztBQUFBLEVBQ3BDO0FBRUEsV0FBU0MsZ0NBQWlDQyxTQUFrQjtBQUMxRCxRQUFJQSxTQUFTO0FBQ1hSLGdDQUEwQjtBQUFBLElBQzVCLE9BQU87QUFDTEUsOEJBQXdCO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBRUEsUUFBTTtBQUFBLElBQUVPLE1BQU1DO0FBQUFBLElBQW9CQztBQUFBQSxFQUFVLElBQUlwQyxnQ0FBZ0NxQyxXQUFXckIsU0FBbUJDLFdBQXFCO0FBQ25JLFFBQU07QUFBQSxJQUFFaUIsTUFBTUk7QUFBQUEsSUFBVUYsV0FBV0c7QUFBQUEsRUFBa0IsSUFBSXBDLHFEQUFxRHFDLFdBQVduQixlQUFlO0FBQ3hJLFFBQU07QUFBQSxJQUFFYSxNQUFNTztBQUFBQSxJQUFTTCxXQUFXTTtBQUFBQSxFQUFpQixJQUFJekMscURBQXFEb0MsV0FBV2hCLGVBQXlCO0FBRWhKLFFBQU07QUFBQSxJQUFFc0IsYUFBYUM7QUFBQUEsSUFBZUM7QUFBQUEsRUFBUSxJQUFJQyxpQkFBaUIxQixhQUF1QkYsVUFBb0I7QUFFNUcsaUJBQWU2QixxQkFBc0I7QUFDbkMsVUFBTTtBQUFBLE1BQUViLE1BQU07QUFBQSxRQUFFYztBQUFBQSxNQUFNO0FBQUEsSUFBRSxJQUFJLE1BQU1KLGNBQWM7QUFDaER0Qix1QkFBbUIwQixLQUFLO0FBQUEsRUFDMUI7QUFFQTdELFlBQVUsTUFBTTtBQUNkNEQsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxFQUFFO0FBRUw1RCxZQUFVLE1BQU07QUFDZCxRQUFJbUQsVUFBVTtBQUNaUixvQkFBY1EsU0FBUyxDQUFDLENBQUM7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYixNQUFJTyxXQUFXLENBQUNQLFlBQVksQ0FBQ0csU0FBUztBQUNwQyxXQUNFLHVCQUFDLDhDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxFQUU3QyxXQUFXTCxhQUFhRyxxQkFBcUJHLGtCQUFrQjtBQUM3RCxXQUFPLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLEVBQ3ZCO0FBRUEsU0FDRSx1QkFBQyxxQ0FBcUMsVUFBckMsRUFDQyxPQUFPO0FBQUEsSUFDTFA7QUFBQUEsSUFDQVo7QUFBQUEsSUFDQVM7QUFBQUEsSUFDQUo7QUFBQUEsSUFDQUU7QUFBQUEsSUFDQVQ7QUFBQUEsRUFDRixHQUVBLGlDQUFDLFdBQ0MsYUFBYSxNQUFNLHVCQUFDLGNBQ2xCO0FBQUEsMkJBQUMsV0FBUSxlQUFjLFVBQVMsS0FBS1AsUUFBUW1DLElBQzNDO0FBQUEsNkJBQUMsYUFBVSx1Q0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDakNyQiwyQkFDQyx1QkFBQyxpQ0FDQyxTQUFTQSx3QkFBd0JzQixVQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQzBDO0FBQUEsU0FKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxRQUFLLFFBQVE7QUFBQSxNQUNaQyxNQUFNO0FBQUEsUUFDSnhDLFlBQVlBLFdBQVd5QztBQUFBQSxRQUN2QnhDLFVBQVVBLFNBQVN5QztBQUFBQSxRQUNuQkMsT0FBT3pDLE9BQU8wQyxLQUFLLEdBQUc7QUFBQSxNQUN4QjtBQUFBLElBQ0YsR0FBRTtBQUFBO0FBQUEsTUFDUWQsU0FBU1AsS0FBS3NCLFNBQVNDO0FBQUFBLE1BQWU7QUFBQSxNQUFJaEIsU0FBU1AsS0FBS3NCLFNBQVNFO0FBQUFBLE1BQVU7QUFBQSxNQUFJakIsU0FBU1AsS0FBS3lCLFFBQVFDO0FBQUFBLFNBUC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BakJpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JuQixHQUVBLGdCQUFnQix1QkFBQywwQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDLEdBRXJELGlDQUFDLHNDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUMsS0F2Qm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkEsS0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUNsRCxHQTlGS0QsK0JBQWlDO0FBQUEsVUFDYWQsVUFDM0JHLGlCQUNVRCxXQVE3QkUsWUFnQjRDQyxnQ0FBZ0NxQyxZQUN2QmxDLHFEQUFxRHFDLFlBQ3ZEdkMscURBQXFEb0MsWUFFNURTLGdCQUFnQjtBQUFBO0FBQUFlLEtBL0I1RHBEO0FBZ0dOLE1BQU1xQyxtQkFBbUJBLENBQUMxQixhQUFxQkYsZUFBdUI7QUFBQTRDLE1BQUE7QUFDcEUsU0FBTzFELFlBQVksTUFDakJGLDhDQUE4QzBDLGNBQWN4QixhQUF1QkYsVUFBVSxDQUMvRjtBQUNGO0FBQUM0QyxJQUpLaEIsa0JBQWdCO0FBQUEsVUFDYjFDLFdBQVc7QUFBQTtBQUtwQixlQUFlSztBQUE2QixJQUFBb0Q7QUFBQUUsYUFBQUYsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQXBwUGFnZSIsIkZsZXhDb2x1bW4iLCJGbGV4Um93IiwiTG9hZGluZ1NjcmVlbiIsIlBhZ2VUaXRsZSIsIlRleHQiLCJ1c2VUaGVtZSIsIkZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlQ29udGV4dCIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsInVzZUJvb2xlYW4iLCJmaW5hbmNpYWxTdGF0ZW1lbnRzUXVlcnlTZXJ2aWNlIiwiZmluYW5jaWFsU3RhdGVtZW50c1JldmlzaW9uQ2xpZW50RGV0YWlsc1F1ZXJ5U2VydmljZSIsImZpbmFuY2lhbFN0YXRlbWVudHNSZXZpc2lvbkNsaWVudFRva2VuU2VydmljZSIsImZpbmFuY2lhbFN0YXRlbWVudHNSZXZpc2lvbkNsaWVudFZlcnNpb25RdWVyeVNlcnZpY2UiLCJ1c2VNdXRhdGlvbiIsIkZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlQWN0aW9ucyIsIkZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlRXJyb3JTY3JlZW4iLCJGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljU2VjdGlvbiIsIkZpbmFuY2lhbFN0YXRlbWVudHNWZXJzaW9uVGFnIiwiRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2UiLCJfcyIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImNvbG9ycyIsInNwYWNpbmciLCJzZWFyY2hQYXJhbXMiLCJhdWRpdElkIiwiZmluYW5jaWFsSWQiLCJ0b2tlbkVudmlvIiwiZ2V0IiwiY29kaWdvRW52aW8iLCJ2YWxpZGF0aW9uVG9rZW4iLCJzZXRWYWxpZGF0aW9uVG9rZW4iLCJpc1Zpc2libGVGaWxlQW5ub3RhdGlvbnMiLCJzZXRUcnVlIiwic2V0VmlzaWJsZUZpbGVBbm5vdGF0aW9ucyIsInNldEZhbHNlIiwic2V0RmFsc2VGaWxlQW5ub3RhdGlvbnMiLCJmaW5hbmNpYWxDdXJyZW50VmVyc2lvbiIsInNldGZpbmFuY2lhbEN1cnJlbnRWZXJzaW9uIiwiY2hhbmdlVmVyc2lvbiIsInZlcnNpb24iLCJjaGFuZ2VGaWxlQW5ub3RhdGlvbnNWaXNpYmlsaXR5IiwidmlzaWJsZSIsImRhdGEiLCJmaW5hbmNpYWxTdGF0ZW1lbnQiLCJpc0xvYWRpbmciLCJ1c2VGaW5kT25lIiwidmVyc2lvbnMiLCJpc0xvYWRpbmdWZXJzaW9ucyIsInVzZUZpbmRBbGwiLCJkZXRhaWxzIiwiaXNMb2FkaW5nRGV0YWlscyIsIm11dGF0ZUFzeW5jIiwidmFsaWRhdGVUb2tlbiIsImlzRXJyb3IiLCJ1c2VWYWxpZGF0ZVRva2VuIiwiZ2V0VmFsaWRhdGlvblRva2VuIiwidG9rZW4iLCJtZCIsInZlcnNhbyIsInJvb3QiLCJyZWd1bGFyIiwiaDQiLCJjb2xvciIsImdyYXkiLCJjb250cmF0byIsIm51bWVyb1Byb3Bvc3RhIiwiZXhlcmNpY2lvIiwiZW1wcmVzYSIsInJhemFvU29jaWFsIiwiX2MiLCJfczIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljUGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2ZpbmFuY2lhbFN0YXRlbWVudHMvcGFnZXMvRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEFwcFBhZ2UsIEZsZXhDb2x1bW4sIEZsZXhSb3csIExvYWRpbmdTY3JlZW4sIFBhZ2VUaXRsZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXG5pbXBvcnQgeyBGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljUGFnZUNvbnRleHQgfSBmcm9tICcuLi9jb250ZXh0cy9GaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljUGFnZUNvbnRleHQnXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VCb29sZWFuIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWhvb2tzJ1xuaW1wb3J0IHsgZmluYW5jaWFsU3RhdGVtZW50c1F1ZXJ5U2VydmljZSwgZmluYW5jaWFsU3RhdGVtZW50c1JldmlzaW9uQ2xpZW50RGV0YWlsc1F1ZXJ5U2VydmljZSwgZmluYW5jaWFsU3RhdGVtZW50c1JldmlzaW9uQ2xpZW50VG9rZW5TZXJ2aWNlLCBmaW5hbmNpYWxTdGF0ZW1lbnRzUmV2aXNpb25DbGllbnRWZXJzaW9uUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlQWN0aW9ucywgRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VFcnJvclNjcmVlbiwgRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1NlY3Rpb24sIEZpbmFuY2lhbFN0YXRlbWVudHNWZXJzaW9uVGFnIH0gZnJvbSAnLi4vY29tcG9uZW50cydcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudFZlcnNpb25DbGllbnQgfSBmcm9tICdAZG9tYWluL0ZpbmFuY2lhbFN0YXRlbWVudCdcblxuY29uc3QgRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2U6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IGZvbnRXZWlnaHQsIGZvbnRTaXplLCBjb2xvcnMsIHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxuICBjb25zdCB7IGF1ZGl0SWQsIGZpbmFuY2lhbElkIH0gPSB1c2VQYXJhbXMoKVxuICBjb25zdCB0b2tlbkVudmlvID0gc2VhcmNoUGFyYW1zLmdldCgndG9rZW5FbnZpbycpXG4gIGNvbnN0IGNvZGlnb0VudmlvID0gc2VhcmNoUGFyYW1zLmdldCgnY29kaWdvRW52aW8nKVxuICBjb25zdCBbdmFsaWRhdGlvblRva2VuLCBzZXRWYWxpZGF0aW9uVG9rZW5dID0gdXNlU3RhdGU8c3RyaW5nPigpXG5cbiAgY29uc3QgW1xuICAgIGlzVmlzaWJsZUZpbGVBbm5vdGF0aW9ucyxcbiAgICB7IHNldFRydWU6IHNldFZpc2libGVGaWxlQW5ub3RhdGlvbnMsIHNldEZhbHNlOiBzZXRGYWxzZUZpbGVBbm5vdGF0aW9ucyB9LFxuICBdID0gdXNlQm9vbGVhbih0cnVlKVxuXG4gIGNvbnN0IFtmaW5hbmNpYWxDdXJyZW50VmVyc2lvbiwgc2V0ZmluYW5jaWFsQ3VycmVudFZlcnNpb25dID0gdXNlU3RhdGU8RmluYW5jaWFsU3RhdGVtZW50VmVyc2lvbkNsaWVudD4oKVxuXG4gIGZ1bmN0aW9uIGNoYW5nZVZlcnNpb24gKHZlcnNpb246IEZpbmFuY2lhbFN0YXRlbWVudFZlcnNpb25DbGllbnQpIHtcbiAgICBzZXRmaW5hbmNpYWxDdXJyZW50VmVyc2lvbih2ZXJzaW9uKVxuICB9XG5cbiAgZnVuY3Rpb24gY2hhbmdlRmlsZUFubm90YXRpb25zVmlzaWJpbGl0eSAodmlzaWJsZTogYm9vbGVhbikge1xuICAgIGlmICh2aXNpYmxlKSB7XG4gICAgICBzZXRWaXNpYmxlRmlsZUFubm90YXRpb25zKClcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0RmFsc2VGaWxlQW5ub3RhdGlvbnMoKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHsgZGF0YTogZmluYW5jaWFsU3RhdGVtZW50LCBpc0xvYWRpbmcgfSA9IGZpbmFuY2lhbFN0YXRlbWVudHNRdWVyeVNlcnZpY2UudXNlRmluZE9uZShhdWRpdElkIGFzIHN0cmluZywgZmluYW5jaWFsSWQgYXMgc3RyaW5nKVxuICBjb25zdCB7IGRhdGE6IHZlcnNpb25zLCBpc0xvYWRpbmc6IGlzTG9hZGluZ1ZlcnNpb25zIH0gPSBmaW5hbmNpYWxTdGF0ZW1lbnRzUmV2aXNpb25DbGllbnRWZXJzaW9uUXVlcnlTZXJ2aWNlLnVzZUZpbmRBbGwodmFsaWRhdGlvblRva2VuKVxuICBjb25zdCB7IGRhdGE6IGRldGFpbHMsIGlzTG9hZGluZzogaXNMb2FkaW5nRGV0YWlscyB9ID0gZmluYW5jaWFsU3RhdGVtZW50c1JldmlzaW9uQ2xpZW50RGV0YWlsc1F1ZXJ5U2VydmljZS51c2VGaW5kT25lKHZhbGlkYXRpb25Ub2tlbiBhcyBzdHJpbmcpXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogdmFsaWRhdGVUb2tlbiwgaXNFcnJvciB9ID0gdXNlVmFsaWRhdGVUb2tlbihjb2RpZ29FbnZpbyBhcyBzdHJpbmcsIHRva2VuRW52aW8gYXMgc3RyaW5nKVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFZhbGlkYXRpb25Ub2tlbiAoKSB7XG4gICAgY29uc3QgeyBkYXRhOiB7IHRva2VuIH0gfSA9IGF3YWl0IHZhbGlkYXRlVG9rZW4oKVxuICAgIHNldFZhbGlkYXRpb25Ub2tlbih0b2tlbilcbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZ2V0VmFsaWRhdGlvblRva2VuKClcbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodmVyc2lvbnMpIHtcbiAgICAgIGNoYW5nZVZlcnNpb24odmVyc2lvbnNbMF0pXG4gICAgfVxuICB9LCBbdmVyc2lvbnNdKVxuXG4gIGlmIChpc0Vycm9yIHx8ICF2ZXJzaW9ucyB8fCAhZGV0YWlscykge1xuICAgIHJldHVybiAoXG4gICAgICA8RmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VFcnJvclNjcmVlbiAvPlxuICAgIClcbiAgfSBlbHNlIGlmIChpc0xvYWRpbmcgfHwgaXNMb2FkaW5nVmVyc2lvbnMgfHwgaXNMb2FkaW5nRGV0YWlscykge1xuICAgIHJldHVybiA8TG9hZGluZ1NjcmVlbiAvPlxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8RmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VDb250ZXh0LlByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICBmaW5hbmNpYWxTdGF0ZW1lbnQsXG4gICAgICAgIGlzVmlzaWJsZUZpbGVBbm5vdGF0aW9ucyxcbiAgICAgICAgY2hhbmdlRmlsZUFubm90YXRpb25zVmlzaWJpbGl0eSxcbiAgICAgICAgZmluYW5jaWFsQ3VycmVudFZlcnNpb246IGZpbmFuY2lhbEN1cnJlbnRWZXJzaW9uLFxuICAgICAgICBjaGFuZ2VWZXJzaW9uLFxuICAgICAgICB2YWxpZGF0aW9uVG9rZW46IHZhbGlkYXRpb25Ub2tlbixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPEFwcFBhZ2VcbiAgICAgICAgcmVuZGVyVGl0bGU9eygpID0+IDxGbGV4Q29sdW1uPlxuICAgICAgICAgIDxGbGV4Um93IHZlcnRpY2FsQWxpZ249J2NlbnRlcicgZ2FwPXtzcGFjaW5nLm1kfSA+XG4gICAgICAgICAgICA8UGFnZVRpdGxlPkRlbW9uc3RyYcOnw6NvIGZpbmFuY2VpcmE8L1BhZ2VUaXRsZT5cbiAgICAgICAgICAgIHtmaW5hbmNpYWxDdXJyZW50VmVyc2lvbiAmJiAoXG4gICAgICAgICAgICAgIDxGaW5hbmNpYWxTdGF0ZW1lbnRzVmVyc2lvblRhZ1xuICAgICAgICAgICAgICAgIHZlcnNpb249e2ZpbmFuY2lhbEN1cnJlbnRWZXJzaW9uLnZlcnNhb31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9GbGV4Um93PlxuICAgICAgICAgIDxUZXh0IHN0eWxlcz17e1xuICAgICAgICAgICAgcm9vdDoge1xuICAgICAgICAgICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnJlZ3VsYXIsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5oNCxcbiAgICAgICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzQwMF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH19PlxuICAgICAgICAgIENvbnRyYXRvIHtkZXRhaWxzPy5kYXRhLmNvbnRyYXRvLm51bWVyb1Byb3Bvc3RhfSAtIHtkZXRhaWxzPy5kYXRhLmNvbnRyYXRvLmV4ZXJjaWNpb30gLSB7ZGV0YWlscz8uZGF0YS5lbXByZXNhLnJhemFvU29jaWFsfVxuICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAgICB9XG4gICAgICAgIHRvcFJpZ2h0Q29ybmVyPXs8RmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VBY3Rpb25zLz59XG4gICAgICA+XG4gICAgICAgIDxGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljU2VjdGlvbiAvPlxuICAgICAgPC9BcHBQYWdlPlxuICAgIDwvRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VDb250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmNvbnN0IHVzZVZhbGlkYXRlVG9rZW4gPSAoY29kaWdvRW52aW86IHN0cmluZywgdG9rZW5FbnZpbzogc3RyaW5nKSA9PiB7XG4gIHJldHVybiB1c2VNdXRhdGlvbigoKSA9PlxuICAgIGZpbmFuY2lhbFN0YXRlbWVudHNSZXZpc2lvbkNsaWVudFRva2VuU2VydmljZS52YWxpZGF0ZVRva2VuKGNvZGlnb0VudmlvIGFzIHN0cmluZywgdG9rZW5FbnZpbyksXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2VcbiJdfQ==