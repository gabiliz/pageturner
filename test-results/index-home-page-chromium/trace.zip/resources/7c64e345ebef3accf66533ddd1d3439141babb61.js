import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/charts/SingleLineChart.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexRow } from "/src/shared/components/FlexBox/index.ts";
const SingleLineChart = ({
  colors,
  values,
  barNames
}) => {
  _s();
  const theme = useTheme();
  const styles = useStyles();
  const total = values.reduce((a, b) => a + b);
  const percentages = values.map((value) => value / total * 100);
  const initialPercentages = percentages.map((_elem, index) => percentages.slice(0, index + 1).reduce((a, b) => a + b));
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.progressBar, children: percentages.map((value, index) => /* @__PURE__ */ jsxDEV("div", { className: styles.progressBarIndicator, style: {
      left: index === 0 ? "0" : `${initialPercentages[index - 1].toFixed(2)}%`,
      width: `${value.toFixed(2)}%`,
      backgroundColor: colors?.[index],
      display: "flex",
      justifyContent: "center",
      color: theme.colors.white,
      fontWeight: 600
    }, children: values[index] > 0 ? values[index] : "" }, index * Math.random() + value, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
      lineNumber: 25,
      columnNumber: 42
    }, this)) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
      lineNumber: 24,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "center", gap: 12, children: barNames.map((name, index) => /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 4, children: [
      /* @__PURE__ */ jsxDEV("div", { className: styles.circle, style: {
        backgroundColor: colors?.[index]
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
        lineNumber: 39,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.text, children: name }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
        lineNumber: 42,
        columnNumber: 11
      }, this)
    ] }, index * Math.random() + name, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
      lineNumber: 38,
      columnNumber: 38
    }, this)) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
      lineNumber: 37,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(SingleLineChart, "1ow4aDbpYgemacIJ4Ivn0I6fqC0=", false, function() {
  return [useTheme, useStyles];
});
_c = SingleLineChart;
const useStyles = () => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    progressBar: {
      height: "1.5rem",
      border: `1px solid ${theme.colors.gray[800]}`,
      borderRadius: 4,
      position: "relative"
    },
    progressBarIndicator: {
      height: "100%",
      position: "absolute",
      top: "0rem",
      left: "0rem"
    },
    circle: {
      display: "inline-block",
      paddingLeft: theme.spacing.xs,
      width: 8,
      height: 8,
      borderRadius: "50%"
    },
    text: {
      color: theme.colors.gray[600]
    }
  });
};
_s2(useStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default SingleLineChart;
var _c;
$RefreshReg$(_c, "SingleLineChart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SingleLineChart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0IwQzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCMUMsU0FBU0Esc0JBQXNCO0FBRS9CLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZQyxlQUFlO0FBT3BDLE1BQU1DLGtCQUE0Q0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVFDO0FBQVMsTUFBTTtBQUFBQyxLQUFBO0FBQ2xGLFFBQU1DLFFBQVFSLFNBQVM7QUFDdkIsUUFBTVMsU0FBU0MsVUFBVTtBQUN6QixRQUFNQyxRQUFRTixPQUFPTyxPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlDLENBQUM7QUFDM0MsUUFBTUMsY0FBY1YsT0FBT1csSUFBSUMsV0FBU0EsUUFBUU4sUUFBUSxHQUFLO0FBQzdELFFBQU1PLHFCQUFxQkgsWUFBWUMsSUFBSSxDQUFDRyxPQUFPQyxVQUFVTCxZQUFZTSxNQUFNLEdBQUdELFFBQVEsQ0FBQyxFQUFFUixPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlDLENBQUMsQ0FBQztBQUVwSCxTQUFPLHVCQUFDLGNBQVcsS0FBSyxJQUN0QjtBQUFBLDJCQUFDLFNBQ0MsV0FBV0wsT0FBT2EsYUFHaEJQLHNCQUFZQyxJQUFJLENBQUNDLE9BQU9HLFVBQVUsdUJBQUMsU0FFakMsV0FBV1gsT0FBT2Msc0JBQ2xCLE9BQ0U7QUFBQSxNQUNFQyxNQUFNSixVQUFVLElBQUksTUFBTyxHQUFFRixtQkFBbUJFLFFBQVEsQ0FBQyxFQUFFSyxRQUFRLENBQUM7QUFBQSxNQUNwRUMsT0FBUSxHQUFFVCxNQUFNUSxRQUFRLENBQUM7QUFBQSxNQUN6QkUsaUJBQWlCdkIsU0FBU2dCLEtBQUs7QUFBQSxNQUMvQlEsU0FBUztBQUFBLE1BQ1RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxPQUFPdEIsTUFBTUosT0FBTzJCO0FBQUFBLE1BQ3BCQyxZQUFZO0FBQUEsSUFDZCxHQUdEM0IsaUJBQU9lLEtBQUssSUFBSSxJQUFJZixPQUFPZSxLQUFLLElBQUksTUFkL0JBLFFBQVFhLEtBQUtDLE9BQU8sSUFBS2pCLE9BREM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCbEMsQ0FBTSxLQXBCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFDQSx1QkFBQyxXQUFRLGlCQUFnQixVQUFTLEtBQUssSUFDcENYLG1CQUFTVSxJQUNSLENBQUNtQixNQUFNZixVQUFVLHVCQUFDLFdBQVEsZUFBYyxVQUFTLEtBQUssR0FDcEQ7QUFBQSw2QkFBQyxTQUFJLFdBQVdYLE9BQU8yQixRQUFRLE9BQU87QUFBQSxRQUFFVCxpQkFBaUJ2QixTQUFTZ0IsS0FBSztBQUFBLE1BQUUsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQzVFLHVCQUFDLFNBQUksV0FBV1gsT0FBTzRCLE1BQU9GLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsU0FGMEJmLFFBQVFhLEtBQUtDLE9BQU8sSUFBS0MsTUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdqQixDQUNGLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0EvQks7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDUDtBQUNGO0FBQUM1QixHQXhDS0osaUJBQXlDO0FBQUEsVUFDL0JILFVBQ0NVLFNBQVM7QUFBQTtBQUFBNEIsS0FGcEJuQztBQTBDTixNQUFNTyxZQUFZQSxNQUFNO0FBQUE2QixNQUFBO0FBQ3RCLFFBQU0vQixRQUFRUixTQUFTO0FBRXZCLFNBQU9ELGVBQWU7QUFBQSxJQUNwQnVCLGFBQWE7QUFBQSxNQUNYa0IsUUFBUTtBQUFBLE1BQ1JDLFFBQVMsYUFBWWpDLE1BQU1KLE9BQU9zQyxLQUFLLEdBQUc7QUFBQSxNQUMxQ0MsY0FBYztBQUFBLE1BQ2RDLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQXJCLHNCQUFzQjtBQUFBLE1BQ3BCaUIsUUFBUTtBQUFBLE1BQ1JJLFVBQVU7QUFBQSxNQUNWQyxLQUFLO0FBQUEsTUFDTHJCLE1BQU07QUFBQSxJQUNSO0FBQUEsSUFDQVksUUFBUTtBQUFBLE1BQ05SLFNBQVM7QUFBQSxNQUNUa0IsYUFBYXRDLE1BQU11QyxRQUFRQztBQUFBQSxNQUMzQnRCLE9BQU87QUFBQSxNQUNQYyxRQUFRO0FBQUEsTUFDUkcsY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQU4sTUFBTTtBQUFBLE1BQ0pQLE9BQU90QixNQUFNSixPQUFPc0MsS0FBSyxHQUFHO0FBQUEsSUFDOUI7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDSCxJQTNCSzdCLFdBQVM7QUFBQSxVQUNDVixRQUFRO0FBQUE7QUE0QnhCLGVBQWVHO0FBQWUsSUFBQW1DO0FBQUFXLGFBQUFYLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIkZsZXhSb3ciLCJTaW5nbGVMaW5lQ2hhcnQiLCJjb2xvcnMiLCJ2YWx1ZXMiLCJiYXJOYW1lcyIsIl9zIiwidGhlbWUiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJ0b3RhbCIsInJlZHVjZSIsImEiLCJiIiwicGVyY2VudGFnZXMiLCJtYXAiLCJ2YWx1ZSIsImluaXRpYWxQZXJjZW50YWdlcyIsIl9lbGVtIiwiaW5kZXgiLCJzbGljZSIsInByb2dyZXNzQmFyIiwicHJvZ3Jlc3NCYXJJbmRpY2F0b3IiLCJsZWZ0IiwidG9GaXhlZCIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJ3aGl0ZSIsImZvbnRXZWlnaHQiLCJNYXRoIiwicmFuZG9tIiwibmFtZSIsImNpcmNsZSIsInRleHQiLCJfYyIsIl9zMiIsImhlaWdodCIsImJvcmRlciIsImdyYXkiLCJib3JkZXJSYWRpdXMiLCJwb3NpdGlvbiIsInRvcCIsInBhZGRpbmdMZWZ0Iiwic3BhY2luZyIsInhzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2luZ2xlTGluZUNoYXJ0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2NoYXJ0cy9TaW5nbGVMaW5lQ2hhcnQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXHJcbmltcG9ydCB7IEZsZXhDb2x1bW4sIEZsZXhSb3cgfSBmcm9tICcuLi9GbGV4Qm94J1xyXG5cclxuaW50ZXJmYWNlIFNpbmdsZUxpbmVDaGFydFByb3BzIHtcclxuICB2YWx1ZXM6IG51bWJlcltdXHJcbiAgY29sb3JzPzogc3RyaW5nW11cclxuICBiYXJOYW1lczogc3RyaW5nW11cclxufVxyXG5jb25zdCBTaW5nbGVMaW5lQ2hhcnQ6IEZDPFNpbmdsZUxpbmVDaGFydFByb3BzPiA9ICh7IGNvbG9ycywgdmFsdWVzLCBiYXJOYW1lcyB9KSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuICBjb25zdCB0b3RhbCA9IHZhbHVlcy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiKVxyXG4gIGNvbnN0IHBlcmNlbnRhZ2VzID0gdmFsdWVzLm1hcCh2YWx1ZSA9PiB2YWx1ZSAvIHRvdGFsICogMTAwLjApXHJcbiAgY29uc3QgaW5pdGlhbFBlcmNlbnRhZ2VzID0gcGVyY2VudGFnZXMubWFwKChfZWxlbSwgaW5kZXgpID0+IHBlcmNlbnRhZ2VzLnNsaWNlKDAsIGluZGV4ICsgMSkucmVkdWNlKChhLCBiKSA9PiBhICsgYikpXHJcblxyXG4gIHJldHVybiA8RmxleENvbHVtbiBnYXA9ezEyfT5cclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPXtzdHlsZXMucHJvZ3Jlc3NCYXJ9XHJcbiAgICA+XHJcbiAgICAgIHtcclxuICAgICAgICBwZXJjZW50YWdlcy5tYXAoKHZhbHVlLCBpbmRleCkgPT4gPGRpdlxyXG4gICAgICAgICAga2V5PXsoaW5kZXggKiBNYXRoLnJhbmRvbSgpKSArIHZhbHVlfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMucHJvZ3Jlc3NCYXJJbmRpY2F0b3J9XHJcbiAgICAgICAgICBzdHlsZT17XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBsZWZ0OiBpbmRleCA9PT0gMCA/ICcwJyA6IGAke2luaXRpYWxQZXJjZW50YWdlc1tpbmRleCAtIDFdLnRvRml4ZWQoMil9JWAsXHJcbiAgICAgICAgICAgICAgd2lkdGg6IGAke3ZhbHVlLnRvRml4ZWQoMil9JWAsXHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnM/LltpbmRleF0sXHJcbiAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICBjb2xvcjogdGhlbWUuY29sb3JzLndoaXRlLFxyXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt2YWx1ZXNbaW5kZXhdID4gMCA/IHZhbHVlc1tpbmRleF0gOiAnJ31cclxuICAgICAgICA8L2Rpdj4pXHJcbiAgICAgIH1cclxuICAgIDwvZGl2PlxyXG4gICAgPEZsZXhSb3cgaG9yaXpvbnRhbEFsaWduPSdjZW50ZXInIGdhcD17MTJ9PlxyXG4gICAgICB7YmFyTmFtZXMubWFwKFxyXG4gICAgICAgIChuYW1lLCBpbmRleCkgPT4gPEZsZXhSb3cgdmVydGljYWxBbGlnbj0nY2VudGVyJyBnYXA9ezR9IGtleT17KGluZGV4ICogTWF0aC5yYW5kb20oKSkgKyBuYW1lfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2lyY2xlfSBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycz8uW2luZGV4XSB9fT48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudGV4dH0+e25hbWV9PC9kaXY+XHJcbiAgICAgICAgPC9GbGV4Um93PixcclxuICAgICAgKX1cclxuICAgIDwvRmxleFJvdz5cclxuICA8L0ZsZXhDb2x1bW4+XHJcbn1cclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcclxuXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIHByb2dyZXNzQmFyOiB7XHJcbiAgICAgIGhlaWdodDogJzEuNXJlbScsXHJcbiAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke3RoZW1lLmNvbG9ycy5ncmF5WzgwMF19YCxcclxuICAgICAgYm9yZGVyUmFkaXVzOiA0LFxyXG4gICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgIH0sXHJcbiAgICBwcm9ncmVzc0JhckluZGljYXRvcjoge1xyXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgIHRvcDogJzByZW0nLFxyXG4gICAgICBsZWZ0OiAnMHJlbScsXHJcbiAgICB9LFxyXG4gICAgY2lyY2xlOiB7XHJcbiAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxyXG4gICAgICBwYWRkaW5nTGVmdDogdGhlbWUuc3BhY2luZy54cyxcclxuICAgICAgd2lkdGg6IDgsXHJcbiAgICAgIGhlaWdodDogOCxcclxuICAgICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcclxuICAgIH0sXHJcbiAgICB0ZXh0OiB7XHJcbiAgICAgIGNvbG9yOiB0aGVtZS5jb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaW5nbGVMaW5lQ2hhcnRcclxuIl19