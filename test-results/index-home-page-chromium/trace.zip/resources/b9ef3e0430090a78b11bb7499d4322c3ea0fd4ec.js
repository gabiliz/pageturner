import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/affirmation/AffirmationList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Label } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport4_react["useMemo"];
import { Tag, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { AffirmationRecord, AffirmationDescriptionRecord } from "/src/shared/record/AffirmationRecord.ts";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
import FlexItem from "/src/shared/components/FlexBox/FlexItem.tsx";
const AffirmationList = ({
  disabledClick = false,
  justActiveAffirmations = false,
  disabledBorder = false,
  ...props
}) => {
  _s();
  const colors = useThemeColors();
  const {
    affirmations,
    label,
    activeColor,
    activeBackgroundColor,
    onClick,
    disabledBackgroundColor,
    disabledBorderColor
  } = props;
  const sortedAffirmations = useMemo(() => {
    return affirmations.sort((a, b) => a.afirmacao > b.afirmacao ? 1 : -1);
  }, [affirmations]);
  return /* @__PURE__ */ jsxDEV(FlexRow, { gap: 4, children: /* @__PURE__ */ jsxDEV(FlexItem, { children: [
    label && /* @__PURE__ */ jsxDEV(Label, { styles: props.labelStyles, children: props.label }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
      lineNumber: 45,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: 4, children: sortedAffirmations?.map((affirmation) => (justActiveAffirmations && affirmation.ativo || !justActiveAffirmations) && /* @__PURE__ */ jsxDEV(TooltipHost, { content: AffirmationDescriptionRecord[affirmation.afirmacao], children: /* @__PURE__ */ jsxDEV(Tag, { text: AffirmationRecord[affirmation.afirmacao], backgroundColor: affirmation.ativo ? activeBackgroundColor || colors.purple[500] : disabledBackgroundColor || colors.gray[300], border: !affirmation.ativo && !disabledBorder ? `solid 2px ${disabledBorderColor}` : disabledBorder ? "none" : `solid 2px ${activeBackgroundColor}`, color: affirmation.ativo ? activeColor || colors.white : colors.black, padding: !disabledBorder ? "1px 6px" : void 0, onClick: !disabledClick && onClick ? () => onClick(affirmation) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
      lineNumber: 50,
      columnNumber: 17
    }, this) }, affirmation.afirmacao, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
      lineNumber: 49,
      columnNumber: 127
    }, this)) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
    lineNumber: 44,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_s(AffirmationList, "elx2+BHZfrsXduOKOGF3Rk1CCVA=", false, function() {
  return [useThemeColors];
});
_c = AffirmationList;
export default AffirmationList;
var _c;
$RefreshReg$(_c, "AffirmationList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/affirmation/AffirmationList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NrQjs7Ozs7Ozs7Ozs7Ozs7OztBQXBDbEIsU0FBdUJBLGFBQWE7QUFDcEMsU0FBYUMsZUFBZTtBQUM1QixTQUFTQyxLQUFLQyxtQkFBbUI7QUFFakMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQkMsb0NBQW9DO0FBQ2hFLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsY0FBYztBQWdCckIsTUFBTUMsa0JBQTRDQSxDQUFDO0FBQUEsRUFBRUMsZ0JBQWdCO0FBQUEsRUFBT0MseUJBQXlCO0FBQUEsRUFBT0MsaUJBQWlCO0FBQUEsRUFBTyxHQUFHQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUNqSixRQUFNQyxTQUFTWCxlQUFlO0FBQzlCLFFBQU07QUFBQSxJQUFFWTtBQUFBQSxJQUFjQztBQUFBQSxJQUFPQztBQUFBQSxJQUFhQztBQUFBQSxJQUF1QkM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBeUJDO0FBQUFBLEVBQW9CLElBQUlUO0FBRTNILFFBQU1VLHFCQUFxQnRCLFFBQVEsTUFBTTtBQUN2QyxXQUFPZSxhQUFhUSxLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUVFLFlBQVlELEVBQUVDLFlBQVksSUFBSSxFQUFFO0FBQUEsRUFDdkUsR0FBRyxDQUFDWCxZQUFZLENBQUM7QUFFakIsU0FDRSx1QkFBQyxXQUNDLEtBQU0sR0FFTixpQ0FBQyxZQUNFQztBQUFBQSxhQUFTLHVCQUFDLFNBQ1QsUUFBUUosTUFBTWUsYUFFYmYsZ0JBQU1JLFNBSEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlWO0FBQUEsSUFDQSx1QkFBQyxXQUNDLEtBQU0sR0FFTE0sOEJBQW9CTSxJQUFJQyxrQkFDckJuQiwwQkFBMEJtQixZQUFZQyxTQUFVLENBQUNwQiwyQkFDakQsdUJBQUMsZUFFQyxTQUFTTCw2QkFBNkJ3QixZQUFZSCxTQUFTLEdBRTNELGlDQUFDLE9BQ0MsTUFBTXRCLGtCQUFrQnlCLFlBQVlILFNBQVMsR0FDN0MsaUJBQ0VHLFlBQVlDLFFBQ1JaLHlCQUF5QkosT0FBT2lCLE9BQU8sR0FBRyxJQUMxQ1gsMkJBQTJCTixPQUFPa0IsS0FBSyxHQUFHLEdBRWhELFFBQVMsQ0FBQ0gsWUFBWUMsU0FBUyxDQUFDbkIsaUJBQzNCLGFBQVlVLHdCQUNaVixpQkFBa0IsU0FBVSxhQUFZTyx5QkFFN0MsT0FDRVcsWUFBWUMsUUFDUmIsZUFBZUgsT0FBT21CLFFBQ3RCbkIsT0FBT29CLE9BRWIsU0FBUyxDQUFDdkIsaUJBQWlCLFlBQVl3QixRQUN2QyxTQUFTLENBQUMxQixpQkFBaUJVLFVBQVUsTUFBTUEsUUFBUVUsV0FBVyxJQUFJTSxVQWpCcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCOEUsS0FwQnpFTixZQUFZSCxXQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBLENBRUosS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBDQTtBQUVKO0FBQUNiLEdBckRLTCxpQkFBeUM7QUFBQSxVQUM5QkwsY0FBYztBQUFBO0FBQUFpQyxLQUR6QjVCO0FBdUROLGVBQWVBO0FBQWUsSUFBQTRCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMYWJlbCIsInVzZU1lbW8iLCJUYWciLCJUb29sdGlwSG9zdCIsInVzZVRoZW1lQ29sb3JzIiwiQWZmaXJtYXRpb25SZWNvcmQiLCJBZmZpcm1hdGlvbkRlc2NyaXB0aW9uUmVjb3JkIiwiRmxleFJvdyIsIkZsZXhJdGVtIiwiQWZmaXJtYXRpb25MaXN0IiwiZGlzYWJsZWRDbGljayIsImp1c3RBY3RpdmVBZmZpcm1hdGlvbnMiLCJkaXNhYmxlZEJvcmRlciIsInByb3BzIiwiX3MiLCJjb2xvcnMiLCJhZmZpcm1hdGlvbnMiLCJsYWJlbCIsImFjdGl2ZUNvbG9yIiwiYWN0aXZlQmFja2dyb3VuZENvbG9yIiwib25DbGljayIsImRpc2FibGVkQmFja2dyb3VuZENvbG9yIiwiZGlzYWJsZWRCb3JkZXJDb2xvciIsInNvcnRlZEFmZmlybWF0aW9ucyIsInNvcnQiLCJhIiwiYiIsImFmaXJtYWNhbyIsImxhYmVsU3R5bGVzIiwibWFwIiwiYWZmaXJtYXRpb24iLCJhdGl2byIsInB1cnBsZSIsImdyYXkiLCJ3aGl0ZSIsImJsYWNrIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBZmZpcm1hdGlvbkxpc3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvYWZmaXJtYXRpb24vQWZmaXJtYXRpb25MaXN0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElMYWJlbFN0eWxlcywgTGFiZWwgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVGFnLCBUb29sdGlwSG9zdCB9IGZyb20gJy4uJ1xuaW1wb3J0IEFmZmlybWF0aW9ucyBmcm9tICcuLi8uLi8uLi9kb21haW4vQWZmaXJtYXRpb25zJ1xuaW1wb3J0IHsgdXNlVGhlbWVDb2xvcnMgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEFmZmlybWF0aW9uUmVjb3JkLCBBZmZpcm1hdGlvbkRlc2NyaXB0aW9uUmVjb3JkIH0gZnJvbSAnLi4vLi4vcmVjb3JkL0FmZmlybWF0aW9uUmVjb3JkJ1xuaW1wb3J0IEZsZXhSb3cgZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhSb3cnXG5pbXBvcnQgRmxleEl0ZW0gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhJdGVtJ1xuXG5pbnRlcmZhY2UgQWZmaXJtYXRpb25MaXN0UHJvcHMge1xuICBhZmZpcm1hdGlvbnM6IEFycmF5PEFmZmlybWF0aW9ucz5cbiAganVzdEFjdGl2ZUFmZmlybWF0aW9ucz86IGJvb2xlYW5cbiAgbGFiZWw/OiBzdHJpbmdcbiAgbGFiZWxTdHlsZXM/OiBJTGFiZWxTdHlsZXNcbiAgYWN0aXZlQ29sb3I/OiBzdHJpbmdcbiAgYWN0aXZlQmFja2dyb3VuZENvbG9yPzogc3RyaW5nXG4gIGRpc2FibGVkQmFja2dyb3VuZENvbG9yPzogc3RyaW5nXG4gIGRpc2FibGVkQm9yZGVyQ29sb3I/OiBzdHJpbmdcbiAgb25DbGljaz86IChhZmZpcm1hdGlvbjogQWZmaXJtYXRpb25zKSA9PiB2b2lkXG4gIGRpc2FibGVkQm9yZGVyPzogYm9vbGVhblxuICBkaXNhYmxlZENsaWNrPzogYm9vbGVhblxufVxuXG5jb25zdCBBZmZpcm1hdGlvbkxpc3Q6IEZDPEFmZmlybWF0aW9uTGlzdFByb3BzPiA9ICh7IGRpc2FibGVkQ2xpY2sgPSBmYWxzZSwganVzdEFjdGl2ZUFmZmlybWF0aW9ucyA9IGZhbHNlLCBkaXNhYmxlZEJvcmRlciA9IGZhbHNlLCAuLi5wcm9wcyB9KSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgY29uc3QgeyBhZmZpcm1hdGlvbnMsIGxhYmVsLCBhY3RpdmVDb2xvciwgYWN0aXZlQmFja2dyb3VuZENvbG9yLCBvbkNsaWNrLCBkaXNhYmxlZEJhY2tncm91bmRDb2xvciwgZGlzYWJsZWRCb3JkZXJDb2xvciB9ID0gcHJvcHNcblxuICBjb25zdCBzb3J0ZWRBZmZpcm1hdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gYWZmaXJtYXRpb25zLnNvcnQoKGEsIGIpID0+IGEuYWZpcm1hY2FvID4gYi5hZmlybWFjYW8gPyAxIDogLTEpXG4gIH0sIFthZmZpcm1hdGlvbnNdKVxuXG4gIHJldHVybiAoXG4gICAgPEZsZXhSb3dcbiAgICAgIGdhcD17IDQgfVxuICAgID5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAge2xhYmVsICYmIDxMYWJlbFxuICAgICAgICAgIHN0eWxlcz17cHJvcHMubGFiZWxTdHlsZXN9XG4gICAgICAgID5cbiAgICAgICAgICB7cHJvcHMubGFiZWx9XG4gICAgICAgIDwvTGFiZWw+fVxuICAgICAgICA8RmxleFJvd1xuICAgICAgICAgIGdhcD17IDQgfVxuICAgICAgICA+XG4gICAgICAgICAge3NvcnRlZEFmZmlybWF0aW9ucz8ubWFwKGFmZmlybWF0aW9uID0+XG4gICAgICAgICAgICAoKGp1c3RBY3RpdmVBZmZpcm1hdGlvbnMgJiYgYWZmaXJtYXRpb24uYXRpdm8pIHx8ICFqdXN0QWN0aXZlQWZmaXJtYXRpb25zKSAmJiAoXG4gICAgICAgICAgICAgIDxUb29sdGlwSG9zdFxuICAgICAgICAgICAgICAgIGtleT17YWZmaXJtYXRpb24uYWZpcm1hY2FvfVxuICAgICAgICAgICAgICAgIGNvbnRlbnQ9e0FmZmlybWF0aW9uRGVzY3JpcHRpb25SZWNvcmRbYWZmaXJtYXRpb24uYWZpcm1hY2FvXX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxUYWdcbiAgICAgICAgICAgICAgICAgIHRleHQ9e0FmZmlybWF0aW9uUmVjb3JkW2FmZmlybWF0aW9uLmFmaXJtYWNhb119XG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I9e1xuICAgICAgICAgICAgICAgICAgICBhZmZpcm1hdGlvbi5hdGl2b1xuICAgICAgICAgICAgICAgICAgICAgID8gYWN0aXZlQmFja2dyb3VuZENvbG9yIHx8IGNvbG9ycy5wdXJwbGVbNTAwXVxuICAgICAgICAgICAgICAgICAgICAgIDogZGlzYWJsZWRCYWNrZ3JvdW5kQ29sb3IgfHwgY29sb3JzLmdyYXlbMzAwXVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgYm9yZGVyPXsoIWFmZmlybWF0aW9uLmF0aXZvICYmICFkaXNhYmxlZEJvcmRlcilcbiAgICAgICAgICAgICAgICAgICAgPyBgc29saWQgMnB4ICR7ZGlzYWJsZWRCb3JkZXJDb2xvcn1gXG4gICAgICAgICAgICAgICAgICAgIDogKGRpc2FibGVkQm9yZGVyKSA/ICdub25lJyA6IGBzb2xpZCAycHggJHthY3RpdmVCYWNrZ3JvdW5kQ29sb3J9YFxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY29sb3I9e1xuICAgICAgICAgICAgICAgICAgICBhZmZpcm1hdGlvbi5hdGl2b1xuICAgICAgICAgICAgICAgICAgICAgID8gYWN0aXZlQ29sb3IgfHwgY29sb3JzLndoaXRlXG4gICAgICAgICAgICAgICAgICAgICAgOiBjb2xvcnMuYmxhY2tcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHBhZGRpbmc9eyFkaXNhYmxlZEJvcmRlciA/ICcxcHggNnB4JyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyFkaXNhYmxlZENsaWNrICYmIG9uQ2xpY2sgPyAoKSA9PiBvbkNsaWNrKGFmZmlybWF0aW9uKSA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L1Rvb2x0aXBIb3N0PlxuICAgICAgICAgICAgKSxcbiAgICAgICAgICApfVxuICAgICAgICA8L0ZsZXhSb3c+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgIDwvRmxleFJvdz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBZmZpcm1hdGlvbkxpc3RcbiJdfQ==