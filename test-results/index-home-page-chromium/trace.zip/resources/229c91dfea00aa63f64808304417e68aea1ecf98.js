import {
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";

// node_modules/@fluentui/react/lib/version.js
setVersion("@fluentui/react", "8.107.1");
//# sourceMappingURL=chunk-F7QKXXXF.js.map
