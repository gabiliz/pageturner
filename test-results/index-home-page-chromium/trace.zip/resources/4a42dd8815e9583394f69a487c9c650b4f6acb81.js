import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/NumberInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/NumberInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import TextField from "/src/shared/components/inputs/TextField.tsx";
const NumberInput = (props) => {
  _s();
  const {
    value = 0,
    onChange,
    maxLength,
    minLength,
    placeholder,
    ...otherProps
  } = props;
  const [maskedValue, setMaskedValue] = useState("0");
  const updateValues = useCallback((newValue) => {
    const value2 = clear(newValue);
    setMaskedValue(value2.toString());
    return value2;
  }, []);
  const handleChange = useCallback((event, newValue) => {
    if (newValue !== void 0) {
      const value2 = updateValues(newValue);
      onChange?.(event, value2);
    }
  }, []);
  useEffect(() => {
    setMaskedValue(value.toString());
  }, [value]);
  return /* @__PURE__ */ jsxDEV(TextField, { value: maskedValue, onChange: handleChange, ...otherProps, maxLength, placeholder, minLength }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/NumberInput.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(NumberInput, "DqRXLu9TtSEqukrfO28jsILD0X4=");
_c = NumberInput;
const clear = (number) => {
  return Number(number.toString().replace(/[^0-9-]/g, ""));
};
export default NumberInput;
var _c;
$RefreshReg$(_c, "NumberInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/NumberInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNJOzs7Ozs7Ozs7Ozs7Ozs7O0FBekNKLFNBQWFBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUVyRCxPQUFPQyxlQUFlO0FBT3RCLE1BQU1DLGNBQXFDQyxXQUFVO0FBQUFDLEtBQUE7QUFDbkQsUUFBTTtBQUFBLElBQ0pDLFFBQVE7QUFBQSxJQUNSQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBLEdBQUdDO0FBQUFBLEVBQ0wsSUFBSVA7QUFFSixRQUFNLENBQUNRLGFBQWFDLGNBQWMsSUFBSWQsU0FBUyxHQUFHO0FBRWxELFFBQU1lLGVBQWViLFlBQVksQ0FBQ2MsYUFBcUI7QUFDckQsVUFBTVQsU0FBUVUsTUFBTUQsUUFBUTtBQUU1QkYsbUJBQWVQLE9BQU1XLFNBQVMsQ0FBQztBQUUvQixXQUFPWDtBQUFBQSxFQUNULEdBQUcsRUFBRTtBQUVMLFFBQU1ZLGVBQWVqQixZQUFZLENBQUNrQixPQUFnQkosYUFBc0I7QUFDdEUsUUFBSUEsYUFBYUssUUFBVztBQUMxQixZQUFNZCxTQUFRUSxhQUFhQyxRQUFRO0FBQ25DUixpQkFBV1ksT0FBT2IsTUFBSztBQUFBLElBQ3pCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTE4sWUFBVSxNQUFNO0FBQ2RhLG1CQUFlUCxNQUFNVyxTQUFTLENBQUM7QUFBQSxFQUNqQyxHQUFHLENBQUNYLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsYUFDQyxPQUFPTSxhQUNQLFVBQVVNLGNBQ1YsR0FBSVAsWUFDSixXQUNBLGFBQ0EsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTXVCO0FBRzNCO0FBQUNOLEdBekNLRixhQUFpQztBQUFBa0IsS0FBakNsQjtBQTJDTixNQUFNYSxRQUFRQSxDQUFDTSxXQUFtQjtBQUNoQyxTQUFPQyxPQUFPRCxPQUFPTCxTQUFTLEVBQUVPLFFBQVEsWUFBWSxFQUFFLENBQUM7QUFDekQ7QUFFQSxlQUFlckI7QUFBVyxJQUFBa0I7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJUZXh0RmllbGQiLCJOdW1iZXJJbnB1dCIsInByb3BzIiwiX3MiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwibWF4TGVuZ3RoIiwibWluTGVuZ3RoIiwicGxhY2Vob2xkZXIiLCJvdGhlclByb3BzIiwibWFza2VkVmFsdWUiLCJzZXRNYXNrZWRWYWx1ZSIsInVwZGF0ZVZhbHVlcyIsIm5ld1ZhbHVlIiwiY2xlYXIiLCJ0b1N0cmluZyIsImhhbmRsZUNoYW5nZSIsImV2ZW50IiwidW5kZWZpbmVkIiwiX2MiLCJudW1iZXIiLCJOdW1iZXIiLCJyZXBsYWNlIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTnVtYmVySW5wdXQudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvaW5wdXRzL051bWJlcklucHV0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJVGV4dEZpZWxkUHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCBUZXh0RmllbGQgZnJvbSAnLi9UZXh0RmllbGQnXHJcblxyXG5pbnRlcmZhY2UgTnVtYmVySW5wdXRQcm9wcyBleHRlbmRzIE9taXQ8SVRleHRGaWVsZFByb3BzLCAndmFsdWUnIHwgJ29uQ2hhbmdlJz4ge1xyXG4gIHZhbHVlPzogbnVtYmVyXHJcbiAgb25DaGFuZ2U/OiAoXzogdW5rbm93biwgdmFsdWU/OiBudW1iZXIpID0+IHZvaWRcclxufVxyXG5cclxuY29uc3QgTnVtYmVySW5wdXQ6IEZDPE51bWJlcklucHV0UHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qge1xyXG4gICAgdmFsdWUgPSAwLFxyXG4gICAgb25DaGFuZ2UsXHJcbiAgICBtYXhMZW5ndGgsXHJcbiAgICBtaW5MZW5ndGgsXHJcbiAgICBwbGFjZWhvbGRlcixcclxuICAgIC4uLm90aGVyUHJvcHNcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgW21hc2tlZFZhbHVlLCBzZXRNYXNrZWRWYWx1ZV0gPSB1c2VTdGF0ZSgnMCcpXHJcblxyXG4gIGNvbnN0IHVwZGF0ZVZhbHVlcyA9IHVzZUNhbGxiYWNrKChuZXdWYWx1ZTogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IGNsZWFyKG5ld1ZhbHVlKVxyXG5cclxuICAgIHNldE1hc2tlZFZhbHVlKHZhbHVlLnRvU3RyaW5nKCkpXHJcblxyXG4gICAgcmV0dXJuIHZhbHVlXHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IHVzZUNhbGxiYWNrKChldmVudDogdW5rbm93biwgbmV3VmFsdWU/OiBzdHJpbmcpID0+IHtcclxuICAgIGlmIChuZXdWYWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGNvbnN0IHZhbHVlID0gdXBkYXRlVmFsdWVzKG5ld1ZhbHVlKVxyXG4gICAgICBvbkNoYW5nZT8uKGV2ZW50LCB2YWx1ZSlcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldE1hc2tlZFZhbHVlKHZhbHVlLnRvU3RyaW5nKCkpXHJcbiAgfSwgW3ZhbHVlXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxUZXh0RmllbGRcclxuICAgICAgdmFsdWU9e21hc2tlZFZhbHVlfVxyXG4gICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICB7Li4ub3RoZXJQcm9wc31cclxuICAgICAgbWF4TGVuZ3RoPXttYXhMZW5ndGh9XHJcbiAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cclxuICAgICAgbWluTGVuZ3RoPXttaW5MZW5ndGh9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgY2xlYXIgPSAobnVtYmVyOiBzdHJpbmcpID0+IHtcclxuICByZXR1cm4gTnVtYmVyKG51bWJlci50b1N0cmluZygpLnJlcGxhY2UoL1teMC05LV0vZywgJycpKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOdW1iZXJJbnB1dFxyXG4iXX0=