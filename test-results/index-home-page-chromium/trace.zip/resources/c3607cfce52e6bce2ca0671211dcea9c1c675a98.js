import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/modules/AppModuleTitle.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/AppModuleTitle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/theme.ts";
const AppModuleTitle = (props) => {
  _s();
  const {
    title
  } = props;
  const {
    spacing,
    colors
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(Text, { block: true, variant: "xLarge", styles: {
    root: {
      maxWidth: 150,
      color: colors.purple[800],
      marginTop: spacing.xxl,
      marginLeft: spacing.lg,
      marginBottom: spacing.md
    }
  }, children: title ?? "Martinelli Auditores" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/AppModuleTitle.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_s(AppModuleTitle, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
_c = AppModuleTitle;
export default AppModuleTitle;
var _c;
$RefreshReg$(_c, "AppModuleTitle");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/AppModuleTitle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkSixTQUFTQSxZQUFZO0FBRXJCLFNBQVNDLGdCQUFnQjtBQU16QixNQUFNQyxpQkFBMkNDLFdBQVU7QUFBQUMsS0FBQTtBQUN6RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJRjtBQUVsQixRQUFNO0FBQUEsSUFBRUc7QUFBQUEsSUFBU0M7QUFBQUEsRUFBTyxJQUFJTixTQUFTO0FBRXJDLFNBQ0UsdUJBQUMsUUFDQyxPQUFLLE1BQ0wsU0FBUSxVQUNSLFFBQVE7QUFBQSxJQUNOTyxNQUFNO0FBQUEsTUFDSkMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU9ILE9BQU9JLE9BQU8sR0FBRztBQUFBLE1BQ3hCQyxXQUFXTixRQUFRTztBQUFBQSxNQUNuQkMsWUFBWVIsUUFBUVM7QUFBQUEsTUFDcEJDLGNBQWNWLFFBQVFXO0FBQUFBLElBQ3hCO0FBQUEsRUFDRixHQUNFWixtQkFBUywwQkFaYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFSjtBQUFDRCxHQXJCS0YsZ0JBQXVDO0FBQUEsVUFHZkQsUUFBUTtBQUFBO0FBQUFpQixLQUhoQ2hCO0FBdUJOLGVBQWVBO0FBQWMsSUFBQWdCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUZXh0IiwidXNlVGhlbWUiLCJBcHBNb2R1bGVUaXRsZSIsInByb3BzIiwiX3MiLCJ0aXRsZSIsInNwYWNpbmciLCJjb2xvcnMiLCJyb290IiwibWF4V2lkdGgiLCJjb2xvciIsInB1cnBsZSIsIm1hcmdpblRvcCIsInh4bCIsIm1hcmdpbkxlZnQiLCJsZyIsIm1hcmdpbkJvdHRvbSIsIm1kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHBNb2R1bGVUaXRsZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9tb2R1bGVzL0FwcE1vZHVsZVRpdGxlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcy90aGVtZSdcblxuaW50ZXJmYWNlIEFwcE1vZHVsZVRpdGxlUHJvcHMge1xuICB0aXRsZT86IHN0cmluZ1xufVxuXG5jb25zdCBBcHBNb2R1bGVUaXRsZTogRkM8QXBwTW9kdWxlVGl0bGVQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyB0aXRsZSB9ID0gcHJvcHNcblxuICBjb25zdCB7IHNwYWNpbmcsIGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiAoXG4gICAgPFRleHRcbiAgICAgIGJsb2NrXG4gICAgICB2YXJpYW50PVwieExhcmdlXCJcbiAgICAgIHN0eWxlcz17e1xuICAgICAgICByb290OiB7XG4gICAgICAgICAgbWF4V2lkdGg6IDE1MCxcbiAgICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxuICAgICAgICAgIG1hcmdpblRvcDogc3BhY2luZy54eGwsXG4gICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcbiAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXG4gICAgICAgIH0sXG4gICAgICB9fT5cbiAgICAgIHsgdGl0bGUgPz8gJ01hcnRpbmVsbGkgQXVkaXRvcmVzJ31cbiAgICA8L1RleHQ+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwTW9kdWxlVGl0bGVcbiJdfQ==