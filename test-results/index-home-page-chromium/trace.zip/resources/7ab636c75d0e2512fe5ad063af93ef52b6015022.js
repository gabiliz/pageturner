import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dialog/ConfirmDialog.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Dialog, DialogType, DialogFooter, useTheme as useThemeFluent } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { DangerButton, PrimaryButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
const ConfirmDialog = (props) => {
  _s();
  const {
    title,
    description,
    actions,
    hidden = true,
    onDismiss,
    isBlocking = false,
    acceptLabel,
    rejectLabel,
    onAccept,
    onReject,
    style = "default"
  } = props;
  const theme = useThemeFluent();
  const handleDismiss = useCallback(() => {
    if (onDismiss) {
      onDismiss();
    }
  }, [onDismiss]);
  const OkButton = useMemo(() => {
    switch (style) {
      case "danger":
        return DangerButton;
      default:
        return PrimaryButton;
    }
  }, [style]);
  return /* @__PURE__ */ jsxDEV(
    Dialog,
    {
      hidden,
      onDismiss: handleDismiss,
      dialogContentProps: {
        type: DialogType.normal,
        title,
        subText: description
      },
      modalProps: {
        isBlocking
      },
      theme,
      children: /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        actions?.(props),
        !actions && [/* @__PURE__ */ jsxDEV(DefaultButton, { onClick: () => {
          onDismiss?.();
          onReject?.();
        }, children: rejectLabel ?? "Cancelar" }, "cancel", false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx",
          lineNumber: 57,
          columnNumber: 23
        }, this), /* @__PURE__ */ jsxDEV(OkButton, { onClick: () => {
          onDismiss?.();
          onAccept?.();
        }, children: acceptLabel ?? "OK" }, "ok", false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx",
          lineNumber: 62,
          columnNumber: 29
        }, this)]
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx",
        lineNumber: 55,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx",
      lineNumber: 47,
      columnNumber: 10
    },
    this
  );
};
_s(ConfirmDialog, "TgSFDt6MpGu/KHN/nS3DFuZ9PGo=", false, function() {
  return [useThemeFluent];
});
_c = ConfirmDialog;
export default ConfirmDialog;
var _c;
$RefreshReg$(_c, "ConfirmDialog");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVVOzs7Ozs7Ozs7Ozs7Ozs7O0FBakVWLFNBQTJCQSxhQUFhQyxlQUFlO0FBQ3ZELFNBQVNDLFFBQVFDLFlBQVlDLGNBQWNDLFlBQVlDLHNCQUFzQjtBQUM3RSxTQUFTQyxjQUFjQyxlQUFlQyxxQkFBcUI7QUFnQjNELE1BQU1DLGdCQUF3Q0EsQ0FBQ0MsVUFBOEI7QUFBQUMsS0FBQTtBQUMzRSxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsU0FBUztBQUFBLElBQ1RDO0FBQUFBLElBQ0FDLGFBQWE7QUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxRQUFRO0FBQUEsRUFDVixJQUFJWjtBQUVKLFFBQU1hLFFBQVFsQixlQUFlO0FBRTdCLFFBQU1tQixnQkFBZ0J6QixZQUFZLE1BQU07QUFDdEMsUUFBSWlCLFdBQVc7QUFDYkEsZ0JBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRixHQUFHLENBQUNBLFNBQVMsQ0FBQztBQUVkLFFBQU1TLFdBQVd6QixRQUFRLE1BQU07QUFDN0IsWUFBUXNCLE9BQUs7QUFBQSxNQUNYLEtBQUs7QUFDSCxlQUFPaEI7QUFBQUEsTUFDVDtBQUNFLGVBQU9DO0FBQUFBLElBQ1g7QUFBQSxFQUNGLEdBQUcsQ0FBQ2UsS0FBSyxDQUFDO0FBRVYsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdFO0FBQUFBLE1BQ1gsb0JBQW9CO0FBQUEsUUFDbEJFLE1BQU14QixXQUFXeUI7QUFBQUEsUUFDakJmO0FBQUFBLFFBQ0FnQixTQUFTZjtBQUFBQSxNQUNYO0FBQUEsTUFDQSxZQUFZO0FBQUEsUUFBRUk7QUFBQUEsTUFBVztBQUFBLE1BQ3pCO0FBQUEsTUFFQSxpQ0FBQyxnQkFDRUg7QUFBQUEsa0JBQVVKLEtBQUs7QUFBQSxRQUNmLENBQUNJLFdBQVcsQ0FDWCx1QkFBQyxpQkFFQyxTQUFTLE1BQU07QUFDYkUsc0JBQVk7QUFDWksscUJBQVc7QUFBQSxRQUNiLEdBRUNGLHlCQUFlLGNBTlosVUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsR0FDQSx1QkFBQyxZQUVDLFNBQVMsTUFBTTtBQUNiSCxzQkFBWTtBQUNaSSxxQkFBVztBQUFBLFFBQ2IsR0FFQ0YseUJBQWUsUUFOWixNQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxDQUFXO0FBQUEsV0FwQmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBO0FBQUEsSUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0NBO0FBRUo7QUFBQ1AsR0FyRUtGLGVBQXFDO0FBQUEsVUFlM0JKLGNBQWM7QUFBQTtBQUFBd0IsS0FmeEJwQjtBQXVFTixlQUFlQTtBQUFhLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VNZW1vIiwiRGlhbG9nIiwiRGlhbG9nVHlwZSIsIkRpYWxvZ0Zvb3RlciIsInVzZVRoZW1lIiwidXNlVGhlbWVGbHVlbnQiLCJEYW5nZXJCdXR0b24iLCJQcmltYXJ5QnV0dG9uIiwiRGVmYXVsdEJ1dHRvbiIsIkNvbmZpcm1EaWFsb2ciLCJwcm9wcyIsIl9zIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImFjdGlvbnMiLCJoaWRkZW4iLCJvbkRpc21pc3MiLCJpc0Jsb2NraW5nIiwiYWNjZXB0TGFiZWwiLCJyZWplY3RMYWJlbCIsIm9uQWNjZXB0Iiwib25SZWplY3QiLCJzdHlsZSIsInRoZW1lIiwiaGFuZGxlRGlzbWlzcyIsIk9rQnV0dG9uIiwidHlwZSIsIm5vcm1hbCIsInN1YlRleHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbmZpcm1EaWFsb2cudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL0NvbmZpcm1EaWFsb2cudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIFJlYWN0RWxlbWVudCwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nVHlwZSwgRGlhbG9nRm9vdGVyLCB1c2VUaGVtZSBhcyB1c2VUaGVtZUZsdWVudCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IERhbmdlckJ1dHRvbiwgUHJpbWFyeUJ1dHRvbiwgRGVmYXVsdEJ1dHRvbiB9IGZyb20gJy4uJ1xuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpcm1EaWFsb2dQcm9wcyB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmdcbiAgYWN0aW9ucz86IChwcm9wczogQ29uZmlybURpYWxvZ1Byb3BzKSA9PiBSZWFjdEVsZW1lbnRbXVxuICBoaWRkZW4/OiBib29sZWFuXG4gIG9uRGlzbWlzcz86ICgpID0+IHZvaWRcbiAgb25BY2NlcHQ/OiAoKSA9PiB2b2lkXG4gIG9uUmVqZWN0PzogKCkgPT4gdm9pZFxuICBhY2NlcHRMYWJlbD86IHN0cmluZ1xuICByZWplY3RMYWJlbD86IHN0cmluZ1xuICBpc0Jsb2NraW5nPzogYm9vbGVhblxuICBzdHlsZT86ICdkZWZhdWx0J3wnZGFuZ2VyJ1xufVxuXG5jb25zdCBDb25maXJtRGlhbG9nOiBGQzxDb25maXJtRGlhbG9nUHJvcHM+ID0gKHByb3BzOiBDb25maXJtRGlhbG9nUHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIHRpdGxlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGFjdGlvbnMsXG4gICAgaGlkZGVuID0gdHJ1ZSxcbiAgICBvbkRpc21pc3MsXG4gICAgaXNCbG9ja2luZyA9IGZhbHNlLFxuICAgIGFjY2VwdExhYmVsLFxuICAgIHJlamVjdExhYmVsLFxuICAgIG9uQWNjZXB0LFxuICAgIG9uUmVqZWN0LFxuICAgIHN0eWxlID0gJ2RlZmF1bHQnLFxuICB9ID0gcHJvcHNcblxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lRmx1ZW50KClcblxuICBjb25zdCBoYW5kbGVEaXNtaXNzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChvbkRpc21pc3MpIHtcbiAgICAgIG9uRGlzbWlzcygpXG4gICAgfVxuICB9LCBbb25EaXNtaXNzXSlcblxuICBjb25zdCBPa0J1dHRvbiA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHN3aXRjaCAoc3R5bGUpIHtcbiAgICAgIGNhc2UgJ2Rhbmdlcic6XG4gICAgICAgIHJldHVybiBEYW5nZXJCdXR0b25cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiBQcmltYXJ5QnV0dG9uXG4gICAgfVxuICB9LCBbc3R5bGVdKVxuXG4gIHJldHVybiAoXG4gICAgPERpYWxvZyAvLyB0b2RvIGNvbXBvbmVudGUgcHJvcHJpb1xuICAgICAgaGlkZGVuPXtoaWRkZW59XG4gICAgICBvbkRpc21pc3M9e2hhbmRsZURpc21pc3N9XG4gICAgICBkaWFsb2dDb250ZW50UHJvcHM9e3tcbiAgICAgICAgdHlwZTogRGlhbG9nVHlwZS5ub3JtYWwsXG4gICAgICAgIHRpdGxlLFxuICAgICAgICBzdWJUZXh0OiBkZXNjcmlwdGlvbixcbiAgICAgIH19XG4gICAgICBtb2RhbFByb3BzPXt7IGlzQmxvY2tpbmcgfX1cbiAgICAgIHRoZW1lPXt0aGVtZX1cbiAgICA+XG4gICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICB7YWN0aW9ucz8uKHByb3BzKX1cbiAgICAgICAgeyFhY3Rpb25zICYmIFtcbiAgICAgICAgICA8RGVmYXVsdEJ1dHRvblxuICAgICAgICAgICAga2V5PVwiY2FuY2VsXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgb25EaXNtaXNzPy4oKVxuICAgICAgICAgICAgICBvblJlamVjdD8uKClcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3JlamVjdExhYmVsID8/ICdDYW5jZWxhcid9XG4gICAgICAgICAgPC9EZWZhdWx0QnV0dG9uPixcbiAgICAgICAgICA8T2tCdXR0b25cbiAgICAgICAgICAgIGtleT1cIm9rXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgb25EaXNtaXNzPy4oKVxuICAgICAgICAgICAgICBvbkFjY2VwdD8uKClcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2FjY2VwdExhYmVsID8/ICdPSyd9XG4gICAgICAgICAgPC9Pa0J1dHRvbj4sXG4gICAgICAgIF19XG4gICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICA8L0RpYWxvZz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb25maXJtRGlhbG9nXG4iXX0=