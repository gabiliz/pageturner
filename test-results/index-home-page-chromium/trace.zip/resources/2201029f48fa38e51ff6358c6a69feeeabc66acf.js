import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/CommandButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/CommandButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { CommandButton as FluentCommandButton, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { Spinner } from "/src/shared/components/spinner/index.ts";
const LOADING_WIDTH = 80;
const CommandButton = ({
  isLargeSize = false,
  text,
  width,
  isLoading,
  children,
  disabled,
  ...props
}) => {
  _s();
  const styles = useStyles(isLargeSize, isLoading, width);
  return /* @__PURE__ */ jsxDEV(FluentCommandButton, { size: 2, className: styles.secondaryButton, text: isLoading ? void 0 : text, disabled: isLoading ? true : disabled, width: isLoading ? LOADING_WIDTH : width, ...props, children: isLoading ? /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/CommandButton.tsx",
    lineNumber: 24,
    columnNumber: 20
  }, this) : children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/CommandButton.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(CommandButton, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = CommandButton;
const useStyles = (isLargeSize, isLoading, width) => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = mergeStyleSets({
    secondaryButton: {
      display: "flex",
      width: isLoading ? LOADING_WIDTH : width,
      alignItems: "center",
      justifyContent: "center",
      color: colors.purple[600],
      borderColor: colors.purple[600],
      borderRadius: 2,
      height: 32,
      fontSize: 14,
      lineHeight: 20,
      fontWeight: 600,
      padding: isLargeSize ? "0 20px" : void 0,
      transition: "color .1s, background-color .1s, border-color .1s",
      "&.is-disabled": {
        opacity: 0.5
      },
      selectors: {
        ":hover": {
          color: colors.purple[500],
          borderColor: colors.purple[500],
          ":not(.is-disabled) .ms-Button-icon": {
            color: colors.purple[500]
          }
        },
        ":active": {
          color: colors.purple[800],
          borderColor: colors.purple[800],
          ":not(.is-disabled) .ms-Button-icon": {
            color: colors.purple[800]
          }
        },
        ":not(.is-disabled) .ms-Button-icon": {
          color: colors.purple[600]
        }
      }
    }
  });
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default CommandButton;
var _c;
$RefreshReg$(_c, "CommandButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/CommandButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NtQjs7Ozs7Ozs7Ozs7Ozs7OztBQS9CbkIsU0FBU0EsaUJBQWlCQyxxQkFBbUNDLHNCQUFzQjtBQUNuRixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZUFBZTtBQU94QixNQUFNQyxnQkFBZ0I7QUFFdEIsTUFBTUwsZ0JBQXlDQSxDQUFDO0FBQUEsRUFDOUNNLGNBQWM7QUFBQSxFQUNkQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBLEdBQUdDO0FBQ0wsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsU0FBU0MsVUFBVVQsYUFBYUcsV0FBV0QsS0FBSztBQUV0RCxTQUNFLHVCQUFDLHVCQUNDLE1BQU0sR0FDTixXQUFXTSxPQUFPRSxpQkFDbEIsTUFBTVAsWUFBWVEsU0FBWVYsTUFDOUIsVUFBVUUsWUFBWSxPQUFPRSxVQUM3QixPQUFPRixZQUFZSixnQkFBZ0JHLE9BQ25DLEdBQUlJLE9BRUhILHNCQUFZLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFRLElBQU1DLFlBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNHLEdBdkJLYixlQUFzQztBQUFBLFVBUzNCZSxTQUFTO0FBQUE7QUFBQUcsS0FUcEJsQjtBQXlCTixNQUFNZSxZQUFZQSxDQUNoQlQsYUFDQUcsV0FDQUQsVUFDRztBQUFBVyxNQUFBO0FBQ0gsUUFBTUMsU0FBU2pCLGVBQWU7QUFDOUIsUUFBTWtCLGVBQWVuQixlQUFlO0FBQUEsSUFDbENjLGlCQUFpQjtBQUFBLE1BQ2ZNLFNBQVM7QUFBQSxNQUNUZCxPQUFPQyxZQUFZSixnQkFBZ0JHO0FBQUFBLE1BQ25DZSxZQUFZO0FBQUEsTUFDWkMsZ0JBQWdCO0FBQUEsTUFDaEJDLE9BQU9MLE9BQU9NLE9BQU8sR0FBRztBQUFBLE1BQ3hCQyxhQUFhUCxPQUFPTSxPQUFPLEdBQUc7QUFBQSxNQUM5QkUsY0FBYztBQUFBLE1BQ2RDLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLFlBQVk7QUFBQSxNQUNaQyxTQUFTM0IsY0FBYyxXQUFXVztBQUFBQSxNQUNsQ2lCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLFFBQ2ZDLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQUMsV0FBVztBQUFBLFFBQ1QsVUFBVTtBQUFBLFVBQ1JYLE9BQU9MLE9BQU9NLE9BQU8sR0FBRztBQUFBLFVBQ3hCQyxhQUFhUCxPQUFPTSxPQUFPLEdBQUc7QUFBQSxVQUM5QixzQ0FBc0M7QUFBQSxZQUNwQ0QsT0FBT0wsT0FBT00sT0FBTyxHQUFHO0FBQUEsVUFDMUI7QUFBQSxRQUNGO0FBQUEsUUFDQSxXQUFXO0FBQUEsVUFDVEQsT0FBT0wsT0FBT00sT0FBTyxHQUFHO0FBQUEsVUFDeEJDLGFBQWFQLE9BQU9NLE9BQU8sR0FBRztBQUFBLFVBQzlCLHNDQUFzQztBQUFBLFlBQ3BDRCxPQUFPTCxPQUFPTSxPQUFPLEdBQUc7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFBQSxRQUNBLHNDQUFzQztBQUFBLFVBQ3BDRCxPQUFPTCxPQUFPTSxPQUFPLEdBQUc7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBT0w7QUFDVDtBQUFDRixJQS9DS0osV0FBUztBQUFBLFVBS0VaLGNBQWM7QUFBQTtBQTRDL0IsZUFBZUg7QUFBYSxJQUFBa0I7QUFBQW1CLGFBQUFuQixJQUFBIiwibmFtZXMiOlsiQ29tbWFuZEJ1dHRvbiIsIkZsdWVudENvbW1hbmRCdXR0b24iLCJtZXJnZVN0eWxlU2V0cyIsInVzZVRoZW1lQ29sb3JzIiwiU3Bpbm5lciIsIkxPQURJTkdfV0lEVEgiLCJpc0xhcmdlU2l6ZSIsInRleHQiLCJ3aWR0aCIsImlzTG9hZGluZyIsImNoaWxkcmVuIiwiZGlzYWJsZWQiLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwic2Vjb25kYXJ5QnV0dG9uIiwidW5kZWZpbmVkIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJhY3Rpb25TdHlsZXMiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJwdXJwbGUiLCJib3JkZXJDb2xvciIsImJvcmRlclJhZGl1cyIsImhlaWdodCIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImZvbnRXZWlnaHQiLCJwYWRkaW5nIiwidHJhbnNpdGlvbiIsIm9wYWNpdHkiLCJzZWxlY3RvcnMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb21tYW5kQnV0dG9uLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbnMvQ29tbWFuZEJ1dHRvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQ29tbWFuZEJ1dHRvbiBhcyBGbHVlbnRDb21tYW5kQnV0dG9uLCBJQnV0dG9uUHJvcHMsIG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWVDb2xvcnMgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICcuLi9zcGlubmVyJ1xuXG5pbnRlcmZhY2UgSUNvbW1hbmRCdXR0b25Qcm9wcyBleHRlbmRzIElCdXR0b25Qcm9wcyB7XG4gIGlzTGFyZ2VTaXplPzogYm9vbGVhblxuICBpc0xvYWRpbmc/OiBib29sZWFuXG59XG5cbmNvbnN0IExPQURJTkdfV0lEVEggPSA4MFxuXG5jb25zdCBDb21tYW5kQnV0dG9uOiBGQzxJQ29tbWFuZEJ1dHRvblByb3BzPiA9ICh7XG4gIGlzTGFyZ2VTaXplID0gZmFsc2UsXG4gIHRleHQsXG4gIHdpZHRoLFxuICBpc0xvYWRpbmcsXG4gIGNoaWxkcmVuLFxuICBkaXNhYmxlZCxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKGlzTGFyZ2VTaXplLCBpc0xvYWRpbmcsIHdpZHRoKVxuXG4gIHJldHVybiAoXG4gICAgPEZsdWVudENvbW1hbmRCdXR0b25cbiAgICAgIHNpemU9ezJ9XG4gICAgICBjbGFzc05hbWU9e3N0eWxlcy5zZWNvbmRhcnlCdXR0b259XG4gICAgICB0ZXh0PXtpc0xvYWRpbmcgPyB1bmRlZmluZWQgOiB0ZXh0fVxuICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZyA/IHRydWUgOiBkaXNhYmxlZH1cbiAgICAgIHdpZHRoPXtpc0xvYWRpbmcgPyBMT0FESU5HX1dJRFRIIDogd2lkdGh9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge2lzTG9hZGluZyA/IDxTcGlubmVyIC8+IDogY2hpbGRyZW59XG4gICAgPC9GbHVlbnRDb21tYW5kQnV0dG9uPlxuICApXG59XG5cbmNvbnN0IHVzZVN0eWxlcyA9IChcbiAgaXNMYXJnZVNpemU6IGJvb2xlYW4sXG4gIGlzTG9hZGluZz86IGJvb2xlYW4sXG4gIHdpZHRoPzogc3RyaW5nIHwgbnVtYmVyLFxuKSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgY29uc3QgYWN0aW9uU3R5bGVzID0gbWVyZ2VTdHlsZVNldHMoe1xuICAgIHNlY29uZGFyeUJ1dHRvbjoge1xuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgd2lkdGg6IGlzTG9hZGluZyA/IExPQURJTkdfV0lEVEggOiB3aWR0aCxcbiAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgICAgY29sb3I6IGNvbG9ycy5wdXJwbGVbNjAwXSxcbiAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXG4gICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICBoZWlnaHQ6IDMyLFxuICAgICAgZm9udFNpemU6IDE0LFxuICAgICAgbGluZUhlaWdodDogMjAsXG4gICAgICBmb250V2VpZ2h0OiA2MDAsXG4gICAgICBwYWRkaW5nOiBpc0xhcmdlU2l6ZSA/ICcwIDIwcHgnIDogdW5kZWZpbmVkLFxuICAgICAgdHJhbnNpdGlvbjogJ2NvbG9yIC4xcywgYmFja2dyb3VuZC1jb2xvciAuMXMsIGJvcmRlci1jb2xvciAuMXMnLFxuICAgICAgJyYuaXMtZGlzYWJsZWQnOiB7XG4gICAgICAgIG9wYWNpdHk6IDAuNSxcbiAgICAgIH0sXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxuICAgICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXG4gICAgICAgICAgJzpub3QoLmlzLWRpc2FibGVkKSAubXMtQnV0dG9uLWljb24nOiB7XG4gICAgICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgICc6YWN0aXZlJzoge1xuICAgICAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5wdXJwbGVbODAwXSxcbiAgICAgICAgICAnOm5vdCguaXMtZGlzYWJsZWQpIC5tcy1CdXR0b24taWNvbic6IHtcbiAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgJzpub3QoLmlzLWRpc2FibGVkKSAubXMtQnV0dG9uLWljb24nOiB7XG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5wdXJwbGVbNjAwXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcblxuICByZXR1cm4gYWN0aW9uU3R5bGVzXG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbW1hbmRCdXR0b25cbiJdfQ==