import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditPlanningSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPlanningSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { AuditApprovalSituationEnum } from "/src/modules/audit/audits/enums/index.ts";
const AuditPlanningSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const [selectedKey, setSelectedKey] = useState("parameters");
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/planning`;
  const isDisabledTabs = useMemo(() => {
    switch (audit?.situacaoAprovacao) {
      case AuditApprovalSituationEnum.PENDING:
      case AuditApprovalSituationEnum.IN_PROGRESS:
        return true;
    }
    return audit?.situacao === AuditSituationEnum.Cancelado;
  }, [audit?.situacao, audit?.situacaoAprovacao]);
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: isDisabledTabs,
      icon: "Settings",
      key: "parameters",
      title: "Parâmetros",
      name: "Parâmetros",
      permission: "AuditoriaRevisaoAnalitica",
      url: `${path}/parameters`
    }, {
      disabled: isDisabledTabs,
      icon: "Calculator",
      key: "materiality",
      title: "Materialidade",
      permission: "AuditoriaRevisaoAnalitica",
      name: "Materialidade",
      url: `${path}/materiality`
    }, {
      disabled: isDisabledTabs || disableTabs,
      icon: "Table",
      key: "analytical-revision",
      title: `Revisão analítica${disableTabs ? " - Selecione parâmetros ou aguarde processamento" : ""}`,
      name: "Revisão analítica",
      permission: "AuditoriaRevisaoAnalitica",
      url: `${path}/analytical-revision`
    }, {
      disabled: isDisabledTabs,
      icon: "Contact",
      key: "auditors",
      name: "Auditores",
      title: "Auditores",
      permission: "AuditoriaAuditor",
      url: `${path}/auditors`
    }, {
      disabled: isDisabledTabs,
      icon: "Flow",
      key: "approval-flow",
      name: "Fluxo de aprovação",
      title: "Fluxo de aprovação",
      permission: "AuditoriaAuditor",
      url: `${path}/approval-flow`
    }, {
      disabled: isDisabledTabs,
      icon: "FabricFolder",
      key: "documents",
      name: "Documentos",
      title: "Documentos",
      permission: "Auditoria",
      url: `${path}/documents`
    }, {
      disabled: isDisabledTabs,
      icon: "Warning",
      name: "Avaliação de risco",
      isExpanded: isGroupExpanded,
      permission: "AuditoriaFormulario",
      url: "",
      links: [{
        disabled: isDisabledTabs,
        icon: "GoToDashboard",
        key: "dashboard",
        name: "Dashboard de riscos",
        title: "Dashboard de riscos",
        permission: "AuditoriaFormulario",
        url: `${path}/dashboard`
      }, {
        disabled: isDisabledTabs,
        icon: "Send",
        key: "risk-form",
        name: "Envio de formulários",
        title: "Envio de formulários",
        permission: "AuditoriaFormulario",
        url: `${path}/risk-form`
      }]
    }, {
      disabled: isDisabledTabs,
      icon: "CalendarAgenda",
      key: "visit-scheduler",
      name: "Programação de visitas",
      title: "Programação de visitas",
      permission: "Auditoria",
      url: `${path}/visit-scheduler`
    }, {
      disabled: isDisabledTabs,
      icon: "FieldRequired",
      key: "test-distribution",
      name: "Distribuição de testes",
      title: "Distribuição de testes",
      permission: "Auditoria",
      url: `${path}/test-distribution`
    }]
  }], [disableTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  const verifyIsActiveMenuItem = useCallback((links, localPathname) => {
    let selected;
    links.forEach((link) => {
      if (typeof link.key === "string" && localPathname.includes(link.key)) {
        selected = link.key;
      }
      if (link.links && link.links?.length > 0 && !selected) {
        selected = verifyIsActiveMenuItem(link.links, localPathname);
      }
    });
    return selected;
  }, []);
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  useEffect(() => {
    const selected = verifyIsActiveMenuItem(navLinkGroups[0].links, pathname);
    if (selected)
      setSelectedKey(selected);
  }, [pathname, navLinkGroups]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Planejamento", hasErrorWhenDisabled: audit?.situacaoAprovacao === AuditApprovalSituationEnum.ERROR, subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPlanningSideMenu.tsx",
    lineNumber: 175,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPlanningSideMenu.tsx",
    lineNumber: 174,
    columnNumber: 136
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, goBack: () => navigate(`/audit/audits/${auditId}/control-panel/dashboard`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPlanningSideMenu.tsx",
    lineNumber: 174,
    columnNumber: 10
  }, this);
};
_s(AuditPlanningSideMenu, "XCKbfvr6ju07k5HjvtnT4m31b70=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditPlanningSideMenu;
export default AuditPlanningSideMenu;
var _c;
$RefreshReg$(_c, "AuditPlanningSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPlanningSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK01VOzs7Ozs7Ozs7Ozs7Ozs7O0FBL01WLFNBQXlCQSxhQUFhQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFMUUsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLGtDQUFrQztBQUUzQyxNQUFNQyx3QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFjLElBQUliLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSVosU0FBUztBQUMzRCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBa0IsS0FBSztBQUNyRSxRQUFNLENBQUMwQixhQUFhQyxjQUFjLElBQUkzQixTQUFpQixZQUFZO0FBRW5FLFFBQU07QUFBQSxJQUFFNEIsSUFBSUM7QUFBQUEsRUFBUSxJQUFJMUIsVUFBVTtBQUVsQyxRQUFNO0FBQUEsSUFBRTJCLE1BQU1DO0FBQUFBLEVBQU0sSUFBSXhCLGtCQUFrQnlCLFdBQVdILE9BQWlCO0FBRXRFLFFBQU1JLE9BQVEsaUJBQWdCSjtBQUU5QixRQUFNSyxpQkFBaUJuQyxRQUFRLE1BQU07QUFDbkMsWUFBUWdDLE9BQU9JLG1CQUFpQjtBQUFBLE1BQzlCLEtBQUt2QiwyQkFBMkJ3QjtBQUFBQSxNQUNoQyxLQUFLeEIsMkJBQTJCeUI7QUFDOUIsZUFBTztBQUFBLElBQ1g7QUFFQSxXQUFPTixPQUFPTyxhQUFhM0IsbUJBQW1CNEI7QUFBQUEsRUFDaEQsR0FBRyxDQUFDUixPQUFPTyxVQUFVUCxPQUFPSSxpQkFBaUIsQ0FBQztBQUM5QyxRQUFNSyxnQkFBaUN6QyxRQUFRLE1BQU0sQ0FDbkQ7QUFBQSxJQUNFMEMsT0FBTyxDQUNMO0FBQUEsTUFDRUMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BFLFlBQVk7QUFBQSxNQUNaRCxNQUFNO0FBQUEsTUFDTkUsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUixrQkFBa0JaO0FBQUFBLE1BQzVCcUIsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFRLG9CQUNOdkIsY0FDSSxxREFDQTtBQUFBLE1BRU53QixNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMRSxNQUFNO0FBQUEsTUFDTkQsT0FBTztBQUFBLE1BQ1BFLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEUsTUFBTTtBQUFBLE1BQ05ELE9BQU87QUFBQSxNQUNQRSxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xFLE1BQU07QUFBQSxNQUNORCxPQUFPO0FBQUEsTUFDUEUsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05HLE1BQU07QUFBQSxNQUNORyxZQUFZekI7QUFBQUEsTUFDWnVCLFlBQVk7QUFBQSxNQUNaQyxLQUFLO0FBQUEsTUFDTFAsT0FBTyxDQUNMO0FBQUEsUUFDRUMsVUFBVVI7QUFBQUEsUUFDVlMsTUFBTTtBQUFBLFFBQ05DLEtBQUs7QUFBQSxRQUNMRSxNQUFNO0FBQUEsUUFDTkQsT0FBTztBQUFBLFFBQ1BFLFlBQVk7QUFBQSxRQUNaQyxLQUFNLEdBQUVmO0FBQUFBLE1BQ1YsR0FDQTtBQUFBLFFBQ0VTLFVBQVVSO0FBQUFBLFFBQ1ZTLE1BQU07QUFBQSxRQUNOQyxLQUFLO0FBQUEsUUFDTEUsTUFBTTtBQUFBLFFBQ05ELE9BQU87QUFBQSxRQUNQRSxZQUFZO0FBQUEsUUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxNQUNWLENBQUM7QUFBQSxJQUVMLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xFLE1BQU07QUFBQSxNQUNORCxPQUFPO0FBQUEsTUFDUEUsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMRSxNQUFNO0FBQUEsTUFDTkQsT0FBTztBQUFBLE1BQ1BFLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsQ0FBQztBQUFBLEVBRUwsQ0FBQyxHQUNBLENBQUNYLGFBQWFFLGVBQWUsQ0FBQztBQUVqQyxRQUFNMEIsZ0JBQWdCbkQsUUFBUSxNQUFNO0FBQ2xDLFVBQU1vRCxnQkFBaUMsQ0FBQyxHQUFHWCxhQUFhO0FBQ3hEVyxrQkFBY0MsUUFBUSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3RDSCxvQkFBY0csS0FBSyxFQUFFYixRQUFRWSxNQUFNWixNQUFNYyxPQUFPQyxhQUFXdkMsY0FBY3VDLFFBQVFULFlBQTRCLFlBQVksQ0FBQztBQUFBLElBQzVILENBQUM7QUFDRCxXQUFPSTtBQUFBQSxFQUNULEdBQUcsQ0FBQ1gsYUFBYSxDQUFDO0FBRWxCLFFBQU1pQixjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQixVQUFJRixLQUFLbEIsT0FBTztBQUNkaEIsMkJBQW1CLENBQUNELGVBQWU7QUFBQSxNQUNyQyxPQUFPO0FBQ0xULGlCQUFTNEMsS0FBS1gsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNYyx5QkFBeUJqRSxZQUFZLENBQUM0QyxPQUFtQnNCLGtCQUE4QztBQUMzRyxRQUFJQztBQUVKdkIsVUFBTVcsUUFBUWEsVUFBUTtBQUNwQixVQUFJLE9BQU9BLEtBQUtyQixRQUFRLFlBQVltQixjQUFjRyxTQUFTRCxLQUFLckIsR0FBRyxHQUFHO0FBQ3BFb0IsbUJBQVdDLEtBQUtyQjtBQUFBQSxNQUNsQjtBQUVBLFVBQUlxQixLQUFLeEIsU0FBU3dCLEtBQUt4QixPQUFPMEIsU0FBUyxLQUFLLENBQUNILFVBQVU7QUFDckRBLG1CQUFXRix1QkFBdUJHLEtBQUt4QixPQUFPc0IsYUFBYTtBQUFBLE1BQzdEO0FBQUEsSUFDRixDQUFDO0FBRUQsV0FBT0M7QUFBQUEsRUFDVCxHQUFHLEVBQUU7QUFFTGxFLFlBQVUsTUFBTTtBQUNkLFVBQU1zRSxrQkFBa0JyQyxPQUFPc0MsU0FBU0MsS0FBS0MsYUFBV0EsUUFBUUMscUJBQXFCLElBQUksRUFBRTtBQUMzRmpELG1CQUFlNkMsbUJBQW1CckMsT0FBT08sYUFBYSxDQUFDO0FBQUEsRUFDekQsR0FBRyxDQUFDUCxLQUFLLENBQUM7QUFFVmpDLFlBQVUsTUFBTTtBQUNkLFVBQU1rRSxXQUFXRix1QkFBdUJ0QixjQUFjLENBQUMsRUFBRUMsT0FBT3pCLFFBQVE7QUFDeEUsUUFBSWdEO0FBQVVyQyxxQkFBZXFDLFFBQVE7QUFBQSxFQUN2QyxHQUFHLENBQUNoRCxVQUFVd0IsYUFBYSxDQUFDO0FBRTVCLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLGdCQUNOLHNCQUFzQlQsT0FBT0ksc0JBQXNCdkIsMkJBQTJCNkQsT0FDOUUsVUFDRSx1QkFBQyxRQUNDLE1BQ0csa0JBQWlCMUMsT0FBTzJDLFVBQVVDLHVCQUNqQzVDLE9BQU8yQyxVQUFVRSxzQkFDWixHQUFFN0MsT0FBTzJDLFNBQVNFLG1DQUFtQzdDLE9BQU8yQyxVQUFVRyxtQkFDdkU5QyxPQUFPMkMsVUFBVTlDLE1BR3pCLFFBQU8sU0FFUCxpQ0FBQyxRQUNDLFFBQVE7QUFBQSxJQUNOa0QsTUFBTTtBQUFBLE1BQ0pDLE9BQU83RCxPQUFPOEQsS0FBSyxHQUFHO0FBQUEsTUFDdEI1RCxZQUFZQSxXQUFXNkQ7QUFBQUEsTUFDdkI1RCxVQUFVQSxTQUFTNkQ7QUFBQUEsTUFDbkJDLHFCQUFxQmpFLE9BQU84RCxLQUFLLEdBQUc7QUFBQSxNQUNwQ0ksWUFBWWpFLFFBQVFrRTtBQUFBQSxNQUNwQkMsVUFBVTtBQUFBLE1BQ1ZDLGNBQWNwRSxRQUFRcUU7QUFBQUEsTUFDdEIsV0FBVztBQUFBLFFBQ1RMLHFCQUFxQmpFLE9BQU84RCxLQUFLLEdBQUc7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsT0FBSyxNQUVKakQ7QUFBQUEsV0FBTzJDLFVBQVVlO0FBQUFBLElBQWE7QUFBQSxJQUFJakYscUJBQXFCdUIsT0FBTzJDLFVBQVVHLGNBQXdCO0FBQUEsT0FqQm5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQSxHQUVGLFFBQVEzQixlQUNSLGFBQWFPLGFBQ2IsYUFDQSxRQUFRLE1BQU0xQyxTQUFVLGlCQUFnQmMsaUNBQWlDLEtBdEMzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0M2RTtBQUdqRjtBQUFDZixHQTlOS0QsdUJBQXlCO0FBQUEsVUFDWlgsYUFDSUQsYUFDS0csZ0JBQ3dCSyxVQUsxQk4sV0FFQUksa0JBQWtCeUIsVUFBVTtBQUFBO0FBQUEwRCxLQVhoRDdFO0FBZ09OLGVBQWVBO0FBQXFCLElBQUE2RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlUGVybWlzc2lvbnMiLCJMaW5rIiwiU2lkZU1lbnUiLCJhdWRpdFF1ZXJ5U2VydmljZSIsImZvcm1hdFByb3Bvc2FsTnVtYmVyIiwidXNlVGhlbWUiLCJUZXh0IiwiQXVkaXRTaXR1YXRpb25FbnVtIiwiQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0iLCJBdWRpdFBsYW5uaW5nU2lkZU1lbnUiLCJfcyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJoYXNQZXJtaXNzaW9uIiwiY29sb3JzIiwic3BhY2luZyIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImRpc2FibGVUYWJzIiwic2V0RGlzYWJsZVRhYnMiLCJpc0dyb3VwRXhwYW5kZWQiLCJzZXRJc0dyb3VwRXhwYW5kZWQiLCJzZWxlY3RlZEtleSIsInNldFNlbGVjdGVkS2V5IiwiaWQiLCJhdWRpdElkIiwiZGF0YSIsImF1ZGl0IiwidXNlRmluZE9uZSIsInBhdGgiLCJpc0Rpc2FibGVkVGFicyIsInNpdHVhY2FvQXByb3ZhY2FvIiwiUEVORElORyIsIklOX1BST0dSRVNTIiwic2l0dWFjYW8iLCJDYW5jZWxhZG8iLCJuYXZMaW5rR3JvdXBzIiwibGlua3MiLCJkaXNhYmxlZCIsImljb24iLCJrZXkiLCJ0aXRsZSIsIm5hbWUiLCJwZXJtaXNzaW9uIiwidXJsIiwiaXNFeHBhbmRlZCIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXJlZEdyb3VwIiwiZm9yRWFjaCIsImdyb3VwIiwiaW5kZXgiLCJmaWx0ZXIiLCJuYXZMaW5rIiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsInZlcmlmeUlzQWN0aXZlTWVudUl0ZW0iLCJsb2NhbFBhdGhuYW1lIiwic2VsZWN0ZWQiLCJsaW5rIiwiaW5jbHVkZXMiLCJsZW5ndGgiLCJ2ZXJpZnlTaXR1YXRpb24iLCJlbXByZXNhcyIsInNvbWUiLCJlbXByZXNhIiwic2l0dWFjYW9SZXZpc2FvIiwiRVJST1IiLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsInJvb3QiLCJjb2xvciIsImdyYXkiLCJzZW1pYm9sZCIsInAxNCIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJtYXJnaW5MZWZ0IiwibGciLCJtYXhXaWR0aCIsIm1hcmdpbkJvdHRvbSIsIm1kIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdFBsYW5uaW5nU2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzL0F1ZGl0UGxhbm5pbmdTaWRlTWVudS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgTW91c2VFdmVudCwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSU5hdkxpbmtHcm91cCwgSU5hdkxpbmsgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QvbGliL05hdidcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBzZXJ2aWNlQ29kZXMsIHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vYXV0aC9ob29rcy9wZXJtaXNzaW9ucydcclxuaW1wb3J0IHsgTGluaywgU2lkZU1lbnUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9hdWRpdHMvc2VydmljZXMnXHJcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgQXVkaXRTaXR1YXRpb25FbnVtIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2VudW1zL0F1ZGl0U2l0dWF0aW9uRW51bSdcclxuaW1wb3J0IHsgQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0gfSBmcm9tICcuLi9hdWRpdHMvZW51bXMnXHJcblxyXG5jb25zdCBBdWRpdFBsYW5uaW5nU2lkZU1lbnU6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcclxuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZywgZm9udFdlaWdodCwgZm9udFNpemUgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBbZGlzYWJsZVRhYnMsIHNldERpc2FibGVUYWJzXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtpc0dyb3VwRXhwYW5kZWQsIHNldElzR3JvdXBFeHBhbmRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSlcclxuICBjb25zdCBbc2VsZWN0ZWRLZXksIHNldFNlbGVjdGVkS2V5XSA9IHVzZVN0YXRlPHN0cmluZz4oJ3BhcmFtZXRlcnMnKVxyXG5cclxuICBjb25zdCB7IGlkOiBhdWRpdElkIH0gPSB1c2VQYXJhbXMoKVxyXG5cclxuICBjb25zdCB7IGRhdGE6IGF1ZGl0IH0gPSBhdWRpdFF1ZXJ5U2VydmljZS51c2VGaW5kT25lKGF1ZGl0SWQgYXMgc3RyaW5nKVxyXG5cclxuICBjb25zdCBwYXRoID0gYC9hdWRpdC9hdWRpdHMvJHthdWRpdElkfS9jb250cm9sLXBhbmVsL3BsYW5uaW5nYFxyXG5cclxuICBjb25zdCBpc0Rpc2FibGVkVGFicyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgc3dpdGNoIChhdWRpdD8uc2l0dWFjYW9BcHJvdmFjYW8pIHtcclxuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5QRU5ESU5HOlxyXG4gICAgICBjYXNlIEF1ZGl0QXBwcm92YWxTaXR1YXRpb25FbnVtLklOX1BST0dSRVNTOlxyXG4gICAgICAgIHJldHVybiB0cnVlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkb1xyXG4gIH0sIFthdWRpdD8uc2l0dWFjYW8sIGF1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhb10pXHJcbiAgY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdID0gdXNlTWVtbygoKSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIGxpbmtzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ1NldHRpbmdzJyxcclxuICAgICAgICAgIGtleTogJ3BhcmFtZXRlcnMnLFxyXG4gICAgICAgICAgdGl0bGU6ICdQYXLDom1ldHJvcycsXHJcbiAgICAgICAgICBuYW1lOiAnUGFyw6JtZXRyb3MnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYVJldmlzYW9BbmFsaXRpY2EnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9wYXJhbWV0ZXJzYCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcclxuICAgICAgICAgIGljb246ICdDYWxjdWxhdG9yJyxcclxuICAgICAgICAgIGtleTogJ21hdGVyaWFsaXR5JyxcclxuICAgICAgICAgIHRpdGxlOiAnTWF0ZXJpYWxpZGFkZScsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhUmV2aXNhb0FuYWxpdGljYScsXHJcbiAgICAgICAgICBuYW1lOiAnTWF0ZXJpYWxpZGFkZScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L21hdGVyaWFsaXR5YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyB8fCBkaXNhYmxlVGFicyxcclxuICAgICAgICAgIGljb246ICdUYWJsZScsXHJcbiAgICAgICAgICBrZXk6ICdhbmFseXRpY2FsLXJldmlzaW9uJyxcclxuICAgICAgICAgIHRpdGxlOiBgUmV2aXPDo28gYW5hbMOtdGljYSR7XHJcbiAgICAgICAgICAgIGRpc2FibGVUYWJzXHJcbiAgICAgICAgICAgICAgPyAnIC0gU2VsZWNpb25lIHBhcsOibWV0cm9zIG91IGFndWFyZGUgcHJvY2Vzc2FtZW50bydcclxuICAgICAgICAgICAgICA6ICcnXHJcbiAgICAgICAgICB9YCxcclxuICAgICAgICAgIG5hbWU6ICdSZXZpc8OjbyBhbmFsw610aWNhJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWFSZXZpc2FvQW5hbGl0aWNhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vYW5hbHl0aWNhbC1yZXZpc2lvbmAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBpY29uOiAnQ29udGFjdCcsXHJcbiAgICAgICAgICBrZXk6ICdhdWRpdG9ycycsXHJcbiAgICAgICAgICBuYW1lOiAnQXVkaXRvcmVzJyxcclxuICAgICAgICAgIHRpdGxlOiAnQXVkaXRvcmVzJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWFBdWRpdG9yJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vYXVkaXRvcnNgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ0Zsb3cnLFxyXG4gICAgICAgICAga2V5OiAnYXBwcm92YWwtZmxvdycsXHJcbiAgICAgICAgICBuYW1lOiAnRmx1eG8gZGUgYXByb3Zhw6fDo28nLFxyXG4gICAgICAgICAgdGl0bGU6ICdGbHV4byBkZSBhcHJvdmHDp8OjbycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhQXVkaXRvcicsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2FwcHJvdmFsLWZsb3dgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ0ZhYnJpY0ZvbGRlcicsXHJcbiAgICAgICAgICBrZXk6ICdkb2N1bWVudHMnLFxyXG4gICAgICAgICAgbmFtZTogJ0RvY3VtZW50b3MnLFxyXG4gICAgICAgICAgdGl0bGU6ICdEb2N1bWVudG9zJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9kb2N1bWVudHNgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ1dhcm5pbmcnLFxyXG4gICAgICAgICAgbmFtZTogJ0F2YWxpYcOnw6NvIGRlIHJpc2NvJyxcclxuICAgICAgICAgIGlzRXhwYW5kZWQ6IGlzR3JvdXBFeHBhbmRlZCxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWFGb3JtdWxhcmlvJyxcclxuICAgICAgICAgIHVybDogJycsXHJcbiAgICAgICAgICBsaW5rczogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgICAgIGljb246ICdHb1RvRGFzaGJvYXJkJyxcclxuICAgICAgICAgICAgICBrZXk6ICdkYXNoYm9hcmQnLFxyXG4gICAgICAgICAgICAgIG5hbWU6ICdEYXNoYm9hcmQgZGUgcmlzY29zJyxcclxuICAgICAgICAgICAgICB0aXRsZTogJ0Rhc2hib2FyZCBkZSByaXNjb3MnLFxyXG4gICAgICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWFGb3JtdWxhcmlvJyxcclxuICAgICAgICAgICAgICB1cmw6IGAke3BhdGh9L2Rhc2hib2FyZGAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICAgICAgaWNvbjogJ1NlbmQnLFxyXG4gICAgICAgICAgICAgIGtleTogJ3Jpc2stZm9ybScsXHJcbiAgICAgICAgICAgICAgbmFtZTogJ0VudmlvIGRlIGZvcm11bMOhcmlvcycsXHJcbiAgICAgICAgICAgICAgdGl0bGU6ICdFbnZpbyBkZSBmb3JtdWzDoXJpb3MnLFxyXG4gICAgICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWFGb3JtdWxhcmlvJyxcclxuICAgICAgICAgICAgICB1cmw6IGAke3BhdGh9L3Jpc2stZm9ybWAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ0NhbGVuZGFyQWdlbmRhJyxcclxuICAgICAgICAgIGtleTogJ3Zpc2l0LXNjaGVkdWxlcicsXHJcbiAgICAgICAgICBuYW1lOiAnUHJvZ3JhbWHDp8OjbyBkZSB2aXNpdGFzJyxcclxuICAgICAgICAgIHRpdGxlOiAnUHJvZ3JhbWHDp8OjbyBkZSB2aXNpdGFzJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS92aXNpdC1zY2hlZHVsZXJgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAgaWNvbjogJ0ZpZWxkUmVxdWlyZWQnLFxyXG4gICAgICAgICAga2V5OiAndGVzdC1kaXN0cmlidXRpb24nLFxyXG4gICAgICAgICAgbmFtZTogJ0Rpc3RyaWJ1acOnw6NvIGRlIHRlc3RlcycsXHJcbiAgICAgICAgICB0aXRsZTogJ0Rpc3RyaWJ1acOnw6NvIGRlIHRlc3RlcycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vdGVzdC1kaXN0cmlidXRpb25gLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gIF0sIFtkaXNhYmxlVGFicywgaXNHcm91cEV4cGFuZGVkXSlcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbk5hdiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gWy4uLm5hdkxpbmtHcm91cHNdXHJcbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyb3VwLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5wZXJtaXNzaW9uIGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInKSlcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZmlsdGVyZWRHcm91cFxyXG4gIH0sIFtuYXZMaW5rR3JvdXBzXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoZXY/OiBNb3VzZUV2ZW50LCBpdGVtPzogSU5hdkxpbmspID0+IHtcclxuICAgIGlmIChldiAhPT0gdW5kZWZpbmVkICYmIGl0ZW0gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgIGlmIChpdGVtLmxpbmtzKSB7XHJcbiAgICAgICAgc2V0SXNHcm91cEV4cGFuZGVkKCFpc0dyb3VwRXhwYW5kZWQpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHZlcmlmeUlzQWN0aXZlTWVudUl0ZW0gPSB1c2VDYWxsYmFjaygobGlua3M6IElOYXZMaW5rW10sIGxvY2FsUGF0aG5hbWU6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCA9PiB7XHJcbiAgICBsZXQgc2VsZWN0ZWQ6IHN0cmluZyB8IHVuZGVmaW5lZFxyXG5cclxuICAgIGxpbmtzLmZvckVhY2gobGluayA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgbGluay5rZXkgPT09ICdzdHJpbmcnICYmIGxvY2FsUGF0aG5hbWUuaW5jbHVkZXMobGluay5rZXkpKSB7XHJcbiAgICAgICAgc2VsZWN0ZWQgPSBsaW5rLmtleSBhcyBzdHJpbmdcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGxpbmsubGlua3MgJiYgbGluay5saW5rcz8ubGVuZ3RoID4gMCAmJiAhc2VsZWN0ZWQpIHtcclxuICAgICAgICBzZWxlY3RlZCA9IHZlcmlmeUlzQWN0aXZlTWVudUl0ZW0obGluay5saW5rcywgbG9jYWxQYXRobmFtZSkgYXMgc3RyaW5nXHJcbiAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHNlbGVjdGVkXHJcbiAgfSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB2ZXJpZnlTaXR1YXRpb24gPSBhdWRpdD8uZW1wcmVzYXMuc29tZShlbXByZXNhID0+IGVtcHJlc2Euc2l0dWFjYW9SZXZpc2FvID09PSAoMCB8IDEpKSBhcyBib29sZWFuXHJcbiAgICBzZXREaXNhYmxlVGFicyh2ZXJpZnlTaXR1YXRpb24gfHwgYXVkaXQ/LnNpdHVhY2FvID09PSAwKVxyXG4gIH0sIFthdWRpdF0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZCA9IHZlcmlmeUlzQWN0aXZlTWVudUl0ZW0obmF2TGlua0dyb3Vwc1swXS5saW5rcywgcGF0aG5hbWUpXHJcbiAgICBpZiAoc2VsZWN0ZWQpIHNldFNlbGVjdGVkS2V5KHNlbGVjdGVkKVxyXG4gIH0sIFtwYXRobmFtZSwgbmF2TGlua0dyb3Vwc10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U2lkZU1lbnVcclxuICAgICAgdGl0bGU9J1BsYW5lamFtZW50bydcclxuICAgICAgaGFzRXJyb3JXaGVuRGlzYWJsZWQ9e2F1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhbyA9PT0gQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0uRVJST1J9XHJcbiAgICAgIHN1YnRpdGxlPXtcclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17XHJcbiAgICAgICAgICAgIGAvYWRtaW4vY2xpZW50cy8ke2F1ZGl0Py5jb250cmF0bz8uY2xpZW50ZUlkfS9jb250cmFjdHMvJHtcclxuICAgICAgICAgICAgICBhdWRpdD8uY29udHJhdG8/LmNvbnRyYXRvUHJpbmNpcGFsSWRcclxuICAgICAgICAgICAgICAgID8gYCR7YXVkaXQ/LmNvbnRyYXRvLmNvbnRyYXRvUHJpbmNpcGFsSWR9P3N1YmNvbnRyYWN0PSR7YXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YX1gXHJcbiAgICAgICAgICAgICAgICA6IGF1ZGl0Py5jb250cmF0bz8uaWRcclxuICAgICAgICAgICAgfWBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRhcmdldD1cImJsYW5rXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxyXG4gICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IHNwYWNpbmcubGcsXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogMjAwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLm1kLFxyXG4gICAgICAgICAgICAgICAgJzo6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthdWRpdD8uY29udHJhdG8/Lm5vbWVGYW50YXNpYX0gLSB7Zm9ybWF0UHJvcG9zYWxOdW1iZXIoYXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YSBhcyBzdHJpbmcpfVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgfVxyXG4gICAgICBncm91cHM9e3Blcm1pc3Npb25OYXZ9XHJcbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cclxuICAgICAgc2VsZWN0ZWRLZXk9e3NlbGVjdGVkS2V5fVxyXG4gICAgICBnb0JhY2s9eygpID0+IG5hdmlnYXRlKGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC9kYXNoYm9hcmRgKX1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWRpdFBsYW5uaW5nU2lkZU1lbnVcclxuIl19