import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
const navLinkGroups = [{
  links: [{
    icon: "BulletedList",
    key: "audits",
    permission: "Auditoria",
    name: "Projetos",
    url: "/audit/audits"
  }]
}];
const AuditSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const registrationNavLink = useMemo(() => [{
    links: [{
      icon: "AddNotes",
      name: "Cadastros",
      isExpanded: isGroupExpanded,
      url: "",
      links: [{
        icon: "AddToShoppingList",
        name: "Formulário de risco",
        key: "risk-form",
        permission: "FormularioRisco",
        url: "/audit/risk-form"
      }, {
        icon: "AppIconDefaultAdd",
        name: "Testes de auditoria",
        key: "tests",
        permission: "CadastroTeste",
        url: "/audit/tests"
      }, {
        icon: "Org",
        name: "Fluxos de trabalho",
        key: "workflows",
        permission: "CadastroTeste",
        url: "/audit/workflows"
      }]
    }]
  }], [isGroupExpanded]);
  const permissions = useMemo(() => {
    return hasPermission("FormularioRisco", "Visualizar") || hasPermission("CadastroTeste", "Visualizar");
  }, []);
  const permissionNav = useMemo(() => {
    const filteredGroup = !permissions ? [...navLinkGroups] : [...navLinkGroups, ...registrationNavLink];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [registrationNavLink, permissions]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = useCallback((ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  }, [isGroupExpanded]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Projetos", groups: permissionNav, onLinkClick: handleClick, selectedKey }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditSideMenu.tsx",
    lineNumber: 75,
    columnNumber: 10
  }, this);
};
_s(AuditSideMenu, "2Iwu0jA5Rf88dYSM6KHkcksPHUw=", false, function() {
  return [useNavigate, useLocation, usePermissions];
});
_c = AuditSideMenu;
export default AuditSideMenu;
var _c;
$RefreshReg$(_c, "AuditSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZJOzs7Ozs7Ozs7Ozs7Ozs7O0FBM0ZKLFNBQXlCQSxhQUFhQyxTQUFTQyxnQkFBZ0I7QUFFL0QsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGdDQUFnQztBQUV2QyxNQUFNQyxnQkFBaUMsQ0FDckM7QUFBQSxFQUNFQyxPQUFPLENBQ0w7QUFBQSxJQUNFQyxNQUFNO0FBQUEsSUFDTkMsS0FBSztBQUFBLElBQ0xDLFlBQVk7QUFBQSxJQUNaQyxNQUFNO0FBQUEsSUFDTkMsS0FBSztBQUFBLEVBQ1AsQ0FBQztBQUVMLENBQUM7QUFHSCxNQUFNQyxnQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QixRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFjLElBQUlkLGVBQWU7QUFDekMsUUFBTSxDQUFDZSxpQkFBaUJDLGtCQUFrQixJQUFJbkIsU0FBa0IsS0FBSztBQUVyRSxRQUFNb0Isc0JBQXVDckIsUUFBUSxNQUFNLENBQ3pEO0FBQUEsSUFDRVEsT0FBTyxDQUNMO0FBQUEsTUFDRUMsTUFBTTtBQUFBLE1BQ05HLE1BQU07QUFBQSxNQUNOVSxZQUFZSDtBQUFBQSxNQUNaTixLQUFLO0FBQUEsTUFDTEwsT0FBTyxDQUNMO0FBQUEsUUFDRUMsTUFBTTtBQUFBLFFBQ05HLE1BQU07QUFBQSxRQUNORixLQUFLO0FBQUEsUUFDTEMsWUFBWTtBQUFBLFFBQ1pFLEtBQUs7QUFBQSxNQUNQLEdBQ0E7QUFBQSxRQUNFSixNQUFNO0FBQUEsUUFDTkcsTUFBTTtBQUFBLFFBQ05GLEtBQUs7QUFBQSxRQUNMQyxZQUFZO0FBQUEsUUFDWkUsS0FBSztBQUFBLE1BQ1AsR0FDQTtBQUFBLFFBQ0VKLE1BQU07QUFBQSxRQUNORyxNQUFNO0FBQUEsUUFDTkYsS0FBSztBQUFBLFFBQ0xDLFlBQVk7QUFBQSxRQUNaRSxLQUFLO0FBQUEsTUFDUCxDQUFDO0FBQUEsSUFFTCxDQUFDO0FBQUEsRUFFTCxDQUFDLEdBQ0EsQ0FBQ00sZUFBZSxDQUFDO0FBRXBCLFFBQU1JLGNBQWN2QixRQUFRLE1BQU07QUFDaEMsV0FBT2tCLGNBQWMsbUJBQW1CLFlBQVksS0FBS0EsY0FBYyxpQkFBaUIsWUFBWTtBQUFBLEVBQ3RHLEdBQUcsRUFBRTtBQUVMLFFBQU1NLGdCQUFnQnhCLFFBQVEsTUFBTTtBQUNsQyxVQUFNeUIsZ0JBQWlDLENBQUNGLGNBQWMsQ0FBQyxHQUFHaEIsYUFBYSxJQUFJLENBQUMsR0FBR0EsZUFBZSxHQUFHYyxtQkFBbUI7QUFDcEhJLGtCQUFjQyxRQUFRLENBQUNDLE9BQU9DLFVBQVU7QUFDdENILG9CQUFjRyxLQUFLLEVBQUVwQixRQUFRbUIsTUFBTW5CLE1BQU1xQixPQUFPQyxhQUFXWixjQUFjWSxRQUFRbkIsWUFBNEIsWUFBWSxDQUFDO0FBQUEsSUFDNUgsQ0FBQztBQUNELFdBQU9jO0FBQUFBLEVBQ1QsR0FBRyxDQUFDSixxQkFBcUJFLFdBQVcsQ0FBQztBQUVyQyxRQUFNUSxjQUFjL0IsUUFBUSxNQUMxQk0sMkJBQTJCVyxVQUFVTyxhQUFhLEdBQ2xELENBQUNQLFVBQVVPLGFBQWEsQ0FBQztBQUUzQixRQUFNUSxjQUFjakMsWUFBWSxDQUFDa0MsSUFBaUJDLFNBQW9CO0FBQ3BFLFFBQUlELE9BQU9FLFVBQWFELFNBQVNDLFFBQVc7QUFDMUNGLFNBQUdHLGVBQWU7QUFDbEIsVUFBSUYsS0FBSzFCLE9BQU87QUFDZFksMkJBQW1CLENBQUNELGVBQWU7QUFBQSxNQUNyQyxPQUFPO0FBQ0xILGlCQUFTa0IsS0FBS3JCLEdBQUc7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sZUFBZSxDQUFDO0FBRXBCLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLFlBQ04sUUFBU0ssZUFDVCxhQUFhUSxhQUNiLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUkyQjtBQUcvQjtBQUFDakIsR0E3RUtELGVBQWlCO0FBQUEsVUFDSlgsYUFDSUQsYUFDS0UsY0FBYztBQUFBO0FBQUFpQyxLQUhwQ3ZCO0FBK0VOLGVBQWVBO0FBQWEsSUFBQXVCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQZXJtaXNzaW9ucyIsIlNpZGVNZW51IiwiZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MiLCJuYXZMaW5rR3JvdXBzIiwibGlua3MiLCJpY29uIiwia2V5IiwicGVybWlzc2lvbiIsIm5hbWUiLCJ1cmwiLCJBdWRpdFNpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwiaGFzUGVybWlzc2lvbiIsImlzR3JvdXBFeHBhbmRlZCIsInNldElzR3JvdXBFeHBhbmRlZCIsInJlZ2lzdHJhdGlvbk5hdkxpbmsiLCJpc0V4cGFuZGVkIiwicGVybWlzc2lvbnMiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXVkaXRTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRTaWRlTWVudS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgTW91c2VFdmVudCwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElOYXZMaW5rR3JvdXAsIElOYXZMaW5rIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9OYXYnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHNlcnZpY2VDb2RlcywgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xyXG5pbXBvcnQgeyBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MgZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzL2dldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzJ1xyXG5cclxuY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdID0gW1xyXG4gIHtcclxuICAgIGxpbmtzOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpY29uOiAnQnVsbGV0ZWRMaXN0JyxcclxuICAgICAgICBrZXk6ICdhdWRpdHMnLFxyXG4gICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgIG5hbWU6ICdQcm9qZXRvcycsXHJcbiAgICAgICAgdXJsOiAnL2F1ZGl0L2F1ZGl0cycsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcbl1cclxuXHJcbmNvbnN0IEF1ZGl0U2lkZU1lbnU6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcclxuICBjb25zdCBbaXNHcm91cEV4cGFuZGVkLCBzZXRJc0dyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXHJcblxyXG4gIGNvbnN0IHJlZ2lzdHJhdGlvbk5hdkxpbms6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGljb246ICdBZGROb3RlcycsXHJcbiAgICAgICAgICBuYW1lOiAnQ2FkYXN0cm9zJyxcclxuICAgICAgICAgIGlzRXhwYW5kZWQ6IGlzR3JvdXBFeHBhbmRlZCxcclxuICAgICAgICAgIHVybDogJycsXHJcbiAgICAgICAgICBsaW5rczogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgaWNvbjogJ0FkZFRvU2hvcHBpbmdMaXN0JyxcclxuICAgICAgICAgICAgICBuYW1lOiAnRm9ybXVsw6FyaW8gZGUgcmlzY28nLFxyXG4gICAgICAgICAgICAgIGtleTogJ3Jpc2stZm9ybScsXHJcbiAgICAgICAgICAgICAgcGVybWlzc2lvbjogJ0Zvcm11bGFyaW9SaXNjbycsXHJcbiAgICAgICAgICAgICAgdXJsOiAnL2F1ZGl0L3Jpc2stZm9ybScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpY29uOiAnQXBwSWNvbkRlZmF1bHRBZGQnLFxyXG4gICAgICAgICAgICAgIG5hbWU6ICdUZXN0ZXMgZGUgYXVkaXRvcmlhJyxcclxuICAgICAgICAgICAgICBrZXk6ICd0ZXN0cycsXHJcbiAgICAgICAgICAgICAgcGVybWlzc2lvbjogJ0NhZGFzdHJvVGVzdGUnLFxyXG4gICAgICAgICAgICAgIHVybDogJy9hdWRpdC90ZXN0cycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpY29uOiAnT3JnJyxcclxuICAgICAgICAgICAgICBuYW1lOiAnRmx1eG9zIGRlIHRyYWJhbGhvJyxcclxuICAgICAgICAgICAgICBrZXk6ICd3b3JrZmxvd3MnLFxyXG4gICAgICAgICAgICAgIHBlcm1pc3Npb246ICdDYWRhc3Ryb1Rlc3RlJyxcclxuICAgICAgICAgICAgICB1cmw6ICcvYXVkaXQvd29ya2Zsb3dzJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgXSwgW2lzR3JvdXBFeHBhbmRlZF0pXHJcblxyXG4gIGNvbnN0IHBlcm1pc3Npb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gaGFzUGVybWlzc2lvbignRm9ybXVsYXJpb1Jpc2NvJywgJ1Zpc3VhbGl6YXInKSB8fCBoYXNQZXJtaXNzaW9uKCdDYWRhc3Ryb1Rlc3RlJywgJ1Zpc3VhbGl6YXInKVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZEdyb3VwOiBJTmF2TGlua0dyb3VwW10gPSAhcGVybWlzc2lvbnMgPyBbLi4ubmF2TGlua0dyb3Vwc10gOiBbLi4ubmF2TGlua0dyb3VwcywgLi4ucmVnaXN0cmF0aW9uTmF2TGlua11cclxuICAgIGZpbHRlcmVkR3JvdXAuZm9yRWFjaCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgIGZpbHRlcmVkR3JvdXBbaW5kZXhdLmxpbmtzID0gZ3JvdXAubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gaGFzUGVybWlzc2lvbihuYXZMaW5rLnBlcm1pc3Npb24gYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicpKVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmaWx0ZXJlZEdyb3VwXHJcbiAgfSwgW3JlZ2lzdHJhdGlvbk5hdkxpbmssIHBlcm1pc3Npb25zXSlcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRLZXkgPSB1c2VNZW1vKCgpID0+XHJcbiAgICBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyhwYXRobmFtZSwgcGVybWlzc2lvbk5hdilcclxuICAsIFtwYXRobmFtZSwgcGVybWlzc2lvbk5hdl0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gdXNlQ2FsbGJhY2soKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XHJcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxyXG4gICAgICBpZiAoaXRlbS5saW5rcykge1xyXG4gICAgICAgIHNldElzR3JvdXBFeHBhbmRlZCghaXNHcm91cEV4cGFuZGVkKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW2lzR3JvdXBFeHBhbmRlZF0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U2lkZU1lbnVcclxuICAgICAgdGl0bGU9J1Byb2pldG9zJ1xyXG4gICAgICBncm91cHM9eyBwZXJtaXNzaW9uTmF2IH1cclxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBzZWxlY3RlZEtleT17c2VsZWN0ZWRLZXl9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRTaWRlTWVudVxyXG4iXX0=