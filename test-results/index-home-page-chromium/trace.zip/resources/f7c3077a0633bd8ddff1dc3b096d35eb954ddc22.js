import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/fiscal/components/FiscalSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/fiscal/components/FiscalSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { fiscalLinks } from "/src/modules/fiscal/components/index.ts?t=1701096626433";
import { SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
const FiscalSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const [selectedKey, setSelectedKey] = useState("TipoProjeto");
  useEffect(() => {
    if (pathname.includes("/fiscal/project-types")) {
      setSelectedKey("TipoProjeto");
    }
    if (pathname.includes("/fiscal/config-rules")) {
      setSelectedKey("FiscalRegra");
    }
    if (pathname.includes("/fiscal/projects")) {
      setSelectedKey("Projeto");
    }
  }, [pathname]);
  const permissionNav = useMemo(() => {
    return fiscalLinks[0].links.filter((navLink) => hasPermission(navLink.key, "Visualizar"));
  }, []);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(item.url);
      setSelectedKey(item.key);
    }
  };
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Fiscal", groups: [{
    links: permissionNav
  }], onLinkClick: handleClick, selectedKey }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/fiscal/components/FiscalSideMenu.tsx",
    lineNumber: 39,
    columnNumber: 10
  }, this);
};
_s(FiscalSideMenu, "MeURx/CQ/EtiYyfxmiijdR5SyCE=", false, function() {
  return [useNavigate, useLocation, usePermissions];
});
_c = FiscalSideMenu;
export default FiscalSideMenu;
var _c;
$RefreshReg$(_c, "FiscalSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/fiscal/components/FiscalSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NJOzs7Ozs7Ozs7Ozs7Ozs7O0FBdENKLFNBQXlCQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFN0QsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxpQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxXQUFXTixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFTztBQUFBQSxFQUFTLElBQUlSLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVTO0FBQUFBLEVBQWMsSUFBSVAsZUFBZTtBQUV6QyxRQUFNLENBQUNRLGFBQWFDLGNBQWMsSUFBSVosU0FBaUIsYUFBYTtBQUVwRUYsWUFBVSxNQUFNO0FBQ2QsUUFBSVcsU0FBU0ksU0FBUyx1QkFBdUIsR0FBRztBQUM5Q0QscUJBQWUsYUFBYTtBQUFBLElBQzlCO0FBQ0EsUUFBSUgsU0FBU0ksU0FBUyxzQkFBc0IsR0FBRztBQUM3Q0QscUJBQWUsYUFBYTtBQUFBLElBQzlCO0FBQ0EsUUFBSUgsU0FBU0ksU0FBUyxrQkFBa0IsR0FBRztBQUN6Q0QscUJBQWUsU0FBUztBQUFBLElBQzFCO0FBQUEsRUFDRixHQUFHLENBQUNILFFBQVEsQ0FBQztBQUViLFFBQU1LLGdCQUFnQmYsUUFBUSxNQUFNO0FBQ2xDLFdBQU9LLFlBQVksQ0FBQyxFQUFFVyxNQUFNQyxPQUFPQyxhQUFXUCxjQUFjTyxRQUFRQyxLQUFxQixZQUFZLENBQUM7QUFBQSxFQUN4RyxHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQmYsZUFBU2EsS0FBS0csR0FBRztBQUNqQloscUJBQWVTLEtBQUtILEdBQWE7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDQSxTQUNFLHVCQUFDLFlBQ0MsT0FBTSxVQUNOLFFBQVEsQ0FBQztBQUFBLElBQUVILE9BQU9EO0FBQUFBLEVBQWMsQ0FBQyxHQUNqQyxhQUFhSyxhQUNiLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUkyQjtBQUcvQjtBQUFDWixHQXRDS0QsZ0JBQWtCO0FBQUEsVUFDTEosYUFDSUQsYUFDS0UsY0FBYztBQUFBO0FBQUFzQixLQUhwQ25CO0FBd0NOLGVBQWVBO0FBQWMsSUFBQW1CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGVybWlzc2lvbnMiLCJmaXNjYWxMaW5rcyIsIlNpZGVNZW51IiwiRmlzY2FsU2lkZU1lbnUiLCJfcyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJoYXNQZXJtaXNzaW9uIiwic2VsZWN0ZWRLZXkiLCJzZXRTZWxlY3RlZEtleSIsImluY2x1ZGVzIiwicGVybWlzc2lvbk5hdiIsImxpbmtzIiwiZmlsdGVyIiwibmF2TGluayIsImtleSIsImhhbmRsZUNsaWNrIiwiZXYiLCJpdGVtIiwidW5kZWZpbmVkIiwicHJldmVudERlZmF1bHQiLCJ1cmwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZpc2NhbFNpZGVNZW51LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvZmlzY2FsL2NvbXBvbmVudHMvRmlzY2FsU2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IElOYXZMaW5rIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9OYXYnXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXG5pbXBvcnQgeyBmaXNjYWxMaW5rcyB9IGZyb20gJy4nXG5pbXBvcnQgeyBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5jb25zdCBGaXNjYWxTaWRlTWVudTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IHsgaGFzUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKVxuXG4gIGNvbnN0IFtzZWxlY3RlZEtleSwgc2V0U2VsZWN0ZWRLZXldID0gdXNlU3RhdGU8c3RyaW5nPignVGlwb1Byb2pldG8nKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHBhdGhuYW1lLmluY2x1ZGVzKCcvZmlzY2FsL3Byb2plY3QtdHlwZXMnKSkge1xuICAgICAgc2V0U2VsZWN0ZWRLZXkoJ1RpcG9Qcm9qZXRvJylcbiAgICB9XG4gICAgaWYgKHBhdGhuYW1lLmluY2x1ZGVzKCcvZmlzY2FsL2NvbmZpZy1ydWxlcycpKSB7XG4gICAgICBzZXRTZWxlY3RlZEtleSgnRmlzY2FsUmVncmEnKVxuICAgIH1cbiAgICBpZiAocGF0aG5hbWUuaW5jbHVkZXMoJy9maXNjYWwvcHJvamVjdHMnKSkge1xuICAgICAgc2V0U2VsZWN0ZWRLZXkoJ1Byb2pldG8nKVxuICAgIH1cbiAgfSwgW3BhdGhuYW1lXSlcblxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGZpc2NhbExpbmtzWzBdLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5rZXkgYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicpKVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVDbGljayA9IChldj86IE1vdXNlRXZlbnQsIGl0ZW0/OiBJTmF2TGluaykgPT4ge1xuICAgIGlmIChldiAhPT0gdW5kZWZpbmVkICYmIGl0ZW0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxuICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXG4gICAgICBzZXRTZWxlY3RlZEtleShpdGVtLmtleSBhcyBzdHJpbmcpXG4gICAgfVxuICB9XG4gIHJldHVybiAoXG4gICAgPFNpZGVNZW51XG4gICAgICB0aXRsZT0nRmlzY2FsJ1xuICAgICAgZ3JvdXBzPXtbeyBsaW5rczogcGVybWlzc2lvbk5hdiB9XX1cbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgIHNlbGVjdGVkS2V5PXtzZWxlY3RlZEtleX1cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEZpc2NhbFNpZGVNZW51XG4iXX0=