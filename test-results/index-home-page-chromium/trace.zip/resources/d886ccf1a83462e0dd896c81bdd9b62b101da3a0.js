import styled, { css } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
const DataGridControlSection = styled.main`
  display: flex;
  flex-direction: column;
  position: relative;
  gap: ${(props) => props.theme.spacing.lg};
  width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
`;
const DataGridPagination = css`
  .e-grid .e-pager {

  div.e-parentmsgbar {
    font-size: ${(props) => props.theme.fontSize.p14};
    font-weight: ${(props) => props.theme.fontWeight.regular};
    order: 0
  }

  .e-pagesizes {
    display: flex;
    align-items: center;
    order: 1;
    gap: ${(props) => props.theme.spacing.md};

    .e-pagerconstant {
      font-size: ${(props) => props.theme.fontSize.p14};
      font-weight: ${(props) => props.theme.fontWeight.regular};
    }

    > div {
      margin: 0;
    }

    .e-pagerdropdown {
      order: 1;
      height: auto;
    }
  }

  .e-pagercontainer {
    display: flex;
    float: right;
    order: 2
  }

  .e-numericitem {
    border: none;
    text-decoration: none;
    font-size: ${(props) => props.theme.fontSize.p14};
  }
  .e-numericitem.e-spacing, .e-numericitem.e-spacing:hover {
    padding: ${(props) => props.theme.spacing.sm};
  }

  .e-currentitem {
    color: ${(props) => props.theme.colors.white};
    font-weight: ${(props) => props.theme.fontWeight.bold};
    background-color: ${(props) => props.theme.colors.purple[600]};
    border: none;
  }
}
`;
const DataGridPaginationHidden = css`
  .e-grid .e-pager {
  display: none;
  }
`;
const DataGridContainer = styled.div`
    width: 100%;

    ${(props) => props.hasUrl ? DataGridPagination : DataGridPaginationHidden}

    ${(props) => props.isDetailingMode && css`
      .e-gridcontent, .e-gridheader {
        .e-checkbox-wrapper {
          pointer-events: none;

          .e-frame {
            &.e-uncheck.e-icons:not(.e-btn-icon) {
              border-color: ${(props2) => props2.theme.colors.gray[300]};
              background-color: ${(props2) => props2.theme.colors.gray[200]};

              color: ${(props2) => props2.theme.colors.gray[400]};
            }

            &.e-check.e-icons:not(.e-btn-icon) {
              opacity: 0.7;
            }
          }
        }
      }
    `}

    .e-grid {
      .e-gridheader {
        tr th:first-child {
          padding-left: ${({ theme }) => theme.spacing.xs};
        }
        .e-headercell .e-headercelldiv.e-headerchkcelldiv {
          margin-bottom: 0;
        }

        .e-checkbox-wrapper {
          /* display: none; */
        }
      }

      .e-checkbox-wrapper .e-frame.e-check, .e-css.e-checkbox-wrapper .e-frame.e-check {
        border-color: ${(props) => props.theme.colors.purple[500]};
        background-color: ${(props) => props.theme.colors.purple[500]};

        color: ${(props) => props.theme.colors.white};
      }


      .e-gridheader th.e-laststackcell {
        border: none;
      }

      .e-moveableheader {
        background-color: ${({ theme }) => theme.colors.gray[200]};
      }

      .e-headercell {
        background-color: ${({ theme }) => theme.colors.gray[200]};
        border: none;

        .e-rhandler {
          border-color: transparent;
          transition: color .3s;

          :hover {
            border-color: ${({ theme }) => theme.colors.gray[300]}
          }
        }
      }

      .e-focused:not(.e-menu-item) {
        box-shadow: 0 0 0 1px ${(props) => props.theme.colors.purple[300]} inset
      }

      .e-fixedfreeze.e-freezeleftborder {
        border-left-color: transparent;
        border-left: none;
      }

      .e-frozenheader.e-frozen-right-header > .e-table,
      .e-frozencontent.e-frozen-right-content > .e-table
       {
        border-left-color: transparent;
        border-left: none;
      }

      .e-frozenscrollbar {
        display: none;
      }


      &.e-default .e-grouptopleftcell {
        border-color: transparent;
      }

      .e-content {
        ${(props) => {
  if (props.groupErrors && props.groupErrors?.length > 0) {
    const allGroupErrors = props.groupErrors.map((error) => css`
          td[ej-mappingvalue=\"${error.normalize()}\"] + td {
            border: 1px solid ${({ theme }) => theme.colors.red[500]};
          }
        `);
    return allGroupErrors;
  }
}}
      }

      .e-rowcell {
            line-height: 14px;
            padding: 4px;
      }
      .e-row {
        height: 45px;
      }

      ${(props) => props.compact && css`
        .e-row {
          height: 40px;
        }
      `}

      .e-groupcaption,
      .e-indentcell,
      .e-recordplusexpand,
      .e-recordpluscollaps,
      .e-groupcaption,
      .e-indentcell,
      .e-recordplusexpand,
      .e-recordpluscollapse {
        background-color: transparent;
      }

      .e-input-group:active:hover:not(.e-success):not(.e-warning):not(.e-error):not(.e-disabled),
      .e-input-group.e-control-wrapper:active:hover:not(.e-success):not(.e-warning):not(.e-error):not(.e-disabled),
      .e-input-group.e-input-focus:not(.e-success):not(.e-warning):not(.e-error),
      .e-input-group.e-control-wrapper.e-input-focus:not(.e-success):not(.e-warning):not(.e-error),
      .e-input-group:not(.e-disabled):active:not(.e-success):not(.e-warning):not(.e-error),
      .e-input-group.e-control-wrapper:not(.e-disabled):active:not(.e-success):not(.e-warning):not(.e-error) {
        border-color: ${(props) => props.theme.colors.blue[300]};
        box-shadow: 0 0 0 1px ${(props) => props.theme.colors.blue[300]}
      }

      .e-input-group.e-control-wrapper.e-input-focus:not(.e-success):not(.e-warning):not(.e-error):hover {
        border-color: ${(props) => props.theme.colors.blue[300]};
      }

      .e-icons:not(.e-btn-icon) {
        color: ${(props) => props.theme.colors.gray[800]};
        font-size: ${(props) => props.theme.fontSize.p14};
      }

      .e-command-button {
        border: none;
        border-radius: 2px;
        background: transparent;

        &:active {
          background-color: ${(props) => props.theme.colors.gray[30]}
        }
      }


      .e-footer-content {
        .e-btn.e-primary.e-flat:not([DISABLED]) {
          background-color: ${(props) => props.theme.colors.purple[600]};
          border-color: ${(props) => props.theme.colors.purple[600]};

          :active {
            background-color: ${(props) => props.theme.colors.purple[800]};
            border-color: ${(props) => props.theme.colors.purple[800]};
          }
        }
      }
    }
`;
const SearchContainer = styled.div`
  display: flex;
  flex-flow: row wrap;
  justify-content: space-between;
`;
export {
  SearchContainer,
  DataGridContainer,
  DataGridControlSection
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkRhdGFHcmlkLnN0eWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQsIHsgY3NzIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXG5cbmludGVyZmFjZSBDb250YWluZXJQcm9wcyB7XG4gIGlzRGV0YWlsaW5nTW9kZT86IGJvb2xlYW5cbiAgY29tcGFjdD86IGJvb2xlYW5cbiAgaGFzVXJsPzogYm9vbGVhblxuICBncm91cEVycm9ycz86IHN0cmluZ1tdXG59XG5cbmNvbnN0IERhdGFHcmlkQ29udHJvbFNlY3Rpb24gPSBzdHlsZWQubWFpbmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBnYXA6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy5sZ307XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG5gXG5cbmNvbnN0IERhdGFHcmlkUGFnaW5hdGlvbiA9IGNzc2BcbiAgLmUtZ3JpZCAuZS1wYWdlciB7XG5cbiAgZGl2LmUtcGFyZW50bXNnYmFyIHtcbiAgICBmb250LXNpemU6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuZm9udFNpemUucDE0fTtcbiAgICBmb250LXdlaWdodDogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250V2VpZ2h0LnJlZ3VsYXJ9O1xuICAgIG9yZGVyOiAwXG4gIH1cblxuICAuZS1wYWdlc2l6ZXMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBvcmRlcjogMTtcbiAgICBnYXA6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy5tZH07XG5cbiAgICAuZS1wYWdlcmNvbnN0YW50IHtcbiAgICAgIGZvbnQtc2l6ZTogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250U2l6ZS5wMTR9O1xuICAgICAgZm9udC13ZWlnaHQ6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuZm9udFdlaWdodC5yZWd1bGFyfTtcbiAgICB9XG5cbiAgICA+IGRpdiB7XG4gICAgICBtYXJnaW46IDA7XG4gICAgfVxuXG4gICAgLmUtcGFnZXJkcm9wZG93biB7XG4gICAgICBvcmRlcjogMTtcbiAgICAgIGhlaWdodDogYXV0bztcbiAgICB9XG4gIH1cblxuICAuZS1wYWdlcmNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgb3JkZXI6IDJcbiAgfVxuXG4gIC5lLW51bWVyaWNpdGVtIHtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICAgIGZvbnQtc2l6ZTogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250U2l6ZS5wMTR9O1xuICB9XG4gIC5lLW51bWVyaWNpdGVtLmUtc3BhY2luZywgLmUtbnVtZXJpY2l0ZW0uZS1zcGFjaW5nOmhvdmVyIHtcbiAgICBwYWRkaW5nOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcuc219O1xuICB9XG5cbiAgLmUtY3VycmVudGl0ZW0ge1xuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy53aGl0ZX07XG4gICAgZm9udC13ZWlnaHQ6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuZm9udFdlaWdodC5ib2xkfTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNjAwXX07XG4gICAgYm9yZGVyOiBub25lO1xuICB9XG59XG5gXG5jb25zdCBEYXRhR3JpZFBhZ2luYXRpb25IaWRkZW4gPSBjc3NgXG4gIC5lLWdyaWQgLmUtcGFnZXIge1xuICBkaXNwbGF5OiBub25lO1xuICB9XG5gXG5cbmNvbnN0IERhdGFHcmlkQ29udGFpbmVyID0gc3R5bGVkLmRpdjxDb250YWluZXJQcm9wcz5gXG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICAke3Byb3BzID0+IHByb3BzLmhhc1VybCA/IERhdGFHcmlkUGFnaW5hdGlvbiA6IERhdGFHcmlkUGFnaW5hdGlvbkhpZGRlbn1cblxuICAgICR7cHJvcHMgPT4gcHJvcHMuaXNEZXRhaWxpbmdNb2RlICYmIGNzc2BcbiAgICAgIC5lLWdyaWRjb250ZW50LCAuZS1ncmlkaGVhZGVyIHtcbiAgICAgICAgLmUtY2hlY2tib3gtd3JhcHBlciB7XG4gICAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG5cbiAgICAgICAgICAuZS1mcmFtZSB7XG4gICAgICAgICAgICAmLmUtdW5jaGVjay5lLWljb25zOm5vdCguZS1idG4taWNvbikge1xuICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbMzAwXX07XG4gICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbMjAwXX07XG5cbiAgICAgICAgICAgICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbNDAwXX07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYuZS1jaGVjay5lLWljb25zOm5vdCguZS1idG4taWNvbikge1xuICAgICAgICAgICAgICBvcGFjaXR5OiAwLjc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgYH1cblxuICAgIC5lLWdyaWQge1xuICAgICAgLmUtZ3JpZGhlYWRlciB7XG4gICAgICAgIHRyIHRoOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICBwYWRkaW5nLWxlZnQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuc3BhY2luZy54c307XG4gICAgICAgIH1cbiAgICAgICAgLmUtaGVhZGVyY2VsbCAuZS1oZWFkZXJjZWxsZGl2LmUtaGVhZGVyY2hrY2VsbGRpdiB7XG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5lLWNoZWNrYm94LXdyYXBwZXIge1xuICAgICAgICAgIC8qIGRpc3BsYXk6IG5vbmU7ICovXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLmUtY2hlY2tib3gtd3JhcHBlciAuZS1mcmFtZS5lLWNoZWNrLCAuZS1jc3MuZS1jaGVja2JveC13cmFwcGVyIC5lLWZyYW1lLmUtY2hlY2sge1xuICAgICAgICBib3JkZXItY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs1MDBdfTtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzUwMF19O1xuXG4gICAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy53aGl0ZX07XG4gICAgICB9XG5cblxuICAgICAgLmUtZ3JpZGhlYWRlciB0aC5lLWxhc3RzdGFja2NlbGwge1xuICAgICAgICBib3JkZXI6IG5vbmU7XG4gICAgICB9XG5cbiAgICAgIC5lLW1vdmVhYmxlaGVhZGVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZ3JheVsyMDBdfTtcbiAgICAgIH1cblxuICAgICAgLmUtaGVhZGVyY2VsbCB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLmdyYXlbMjAwXX07XG4gICAgICAgIGJvcmRlcjogbm9uZTtcblxuICAgICAgICAuZS1yaGFuZGxlciB7XG4gICAgICAgICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgICAgICB0cmFuc2l0aW9uOiBjb2xvciAuM3M7XG5cbiAgICAgICAgICA6aG92ZXIge1xuICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5ncmF5WzMwMF19XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC5lLWZvY3VzZWQ6bm90KC5lLW1lbnUtaXRlbSkge1xuICAgICAgICBib3gtc2hhZG93OiAwIDAgMCAxcHggJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzMwMF19IGluc2V0XG4gICAgICB9XG5cbiAgICAgIC5lLWZpeGVkZnJlZXplLmUtZnJlZXplbGVmdGJvcmRlciB7XG4gICAgICAgIGJvcmRlci1sZWZ0LWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgICAgYm9yZGVyLWxlZnQ6IG5vbmU7XG4gICAgICB9XG5cbiAgICAgIC5lLWZyb3plbmhlYWRlci5lLWZyb3plbi1yaWdodC1oZWFkZXIgPiAuZS10YWJsZSxcbiAgICAgIC5lLWZyb3plbmNvbnRlbnQuZS1mcm96ZW4tcmlnaHQtY29udGVudCA+IC5lLXRhYmxlXG4gICAgICAge1xuICAgICAgICBib3JkZXItbGVmdC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgIGJvcmRlci1sZWZ0OiBub25lO1xuICAgICAgfVxuXG4gICAgICAuZS1mcm96ZW5zY3JvbGxiYXIge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgfVxuXG5cbiAgICAgICYuZS1kZWZhdWx0IC5lLWdyb3VwdG9wbGVmdGNlbGwge1xuICAgICAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgfVxuXG4gICAgICAuZS1jb250ZW50IHtcbiAgICAgICAgJHtwcm9wcyA9PiB7XG4gICAgaWYgKHByb3BzLmdyb3VwRXJyb3JzICYmIHByb3BzLmdyb3VwRXJyb3JzPy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBhbGxHcm91cEVycm9ycyA9IHByb3BzLmdyb3VwRXJyb3JzLm1hcChlcnJvciA9PiAoXG4gICAgICAgIGNzc2BcbiAgICAgICAgICB0ZFtlai1tYXBwaW5ndmFsdWU9XFxcIiR7ZXJyb3Iubm9ybWFsaXplKCl9XFxcIl0gKyB0ZCB7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmNvbG9ycy5yZWRbNTAwXX07XG4gICAgICAgICAgfVxuICAgICAgICBgXG4gICAgICApKVxuXG4gICAgICByZXR1cm4gYWxsR3JvdXBFcnJvcnNcbiAgICB9XG4gIH1cblxufVxuICAgICAgfVxuXG4gICAgICAuZS1yb3djZWxsIHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxNHB4O1xuICAgICAgICAgICAgcGFkZGluZzogNHB4O1xuICAgICAgfVxuICAgICAgLmUtcm93IHtcbiAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgfVxuXG4gICAgICAke3Byb3BzID0+IHByb3BzLmNvbXBhY3QgJiYgY3NzYFxuICAgICAgICAuZS1yb3cge1xuICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgfVxuICAgICAgYH1cblxuICAgICAgLmUtZ3JvdXBjYXB0aW9uLFxuICAgICAgLmUtaW5kZW50Y2VsbCxcbiAgICAgIC5lLXJlY29yZHBsdXNleHBhbmQsXG4gICAgICAuZS1yZWNvcmRwbHVzY29sbGFwcyxcbiAgICAgIC5lLWdyb3VwY2FwdGlvbixcbiAgICAgIC5lLWluZGVudGNlbGwsXG4gICAgICAuZS1yZWNvcmRwbHVzZXhwYW5kLFxuICAgICAgLmUtcmVjb3JkcGx1c2NvbGxhcHNlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICB9XG5cbiAgICAgIC5lLWlucHV0LWdyb3VwOmFjdGl2ZTpob3Zlcjpub3QoLmUtc3VjY2Vzcyk6bm90KC5lLXdhcm5pbmcpOm5vdCguZS1lcnJvcik6bm90KC5lLWRpc2FibGVkKSxcbiAgICAgIC5lLWlucHV0LWdyb3VwLmUtY29udHJvbC13cmFwcGVyOmFjdGl2ZTpob3Zlcjpub3QoLmUtc3VjY2Vzcyk6bm90KC5lLXdhcm5pbmcpOm5vdCguZS1lcnJvcik6bm90KC5lLWRpc2FibGVkKSxcbiAgICAgIC5lLWlucHV0LWdyb3VwLmUtaW5wdXQtZm9jdXM6bm90KC5lLXN1Y2Nlc3MpOm5vdCguZS13YXJuaW5nKTpub3QoLmUtZXJyb3IpLFxuICAgICAgLmUtaW5wdXQtZ3JvdXAuZS1jb250cm9sLXdyYXBwZXIuZS1pbnB1dC1mb2N1czpub3QoLmUtc3VjY2Vzcyk6bm90KC5lLXdhcm5pbmcpOm5vdCguZS1lcnJvciksXG4gICAgICAuZS1pbnB1dC1ncm91cDpub3QoLmUtZGlzYWJsZWQpOmFjdGl2ZTpub3QoLmUtc3VjY2Vzcyk6bm90KC5lLXdhcm5pbmcpOm5vdCguZS1lcnJvciksXG4gICAgICAuZS1pbnB1dC1ncm91cC5lLWNvbnRyb2wtd3JhcHBlcjpub3QoLmUtZGlzYWJsZWQpOmFjdGl2ZTpub3QoLmUtc3VjY2Vzcyk6bm90KC5lLXdhcm5pbmcpOm5vdCguZS1lcnJvcikge1xuICAgICAgICBib3JkZXItY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmJsdWVbMzAwXX07XG4gICAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDFweCAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5ibHVlWzMwMF19XG4gICAgICB9XG5cbiAgICAgIC5lLWlucHV0LWdyb3VwLmUtY29udHJvbC13cmFwcGVyLmUtaW5wdXQtZm9jdXM6bm90KC5lLXN1Y2Nlc3MpOm5vdCguZS13YXJuaW5nKTpub3QoLmUtZXJyb3IpOmhvdmVyIHtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5ibHVlWzMwMF19O1xuICAgICAgfVxuXG4gICAgICAuZS1pY29uczpub3QoLmUtYnRuLWljb24pIHtcbiAgICAgICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbODAwXX07XG4gICAgICAgIGZvbnQtc2l6ZTogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250U2l6ZS5wMTR9O1xuICAgICAgfVxuXG4gICAgICAuZS1jb21tYW5kLWJ1dHRvbiB7XG4gICAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcblxuICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMuZ3JheVszMF19XG4gICAgICAgIH1cbiAgICAgIH1cblxuXG4gICAgICAuZS1mb290ZXItY29udGVudCB7XG4gICAgICAgIC5lLWJ0bi5lLXByaW1hcnkuZS1mbGF0Om5vdChbRElTQUJMRURdKSB7XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzYwMF19O1xuICAgICAgICAgIGJvcmRlci1jb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzYwMF19O1xuXG4gICAgICAgICAgOmFjdGl2ZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbODAwXX07XG4gICAgICAgICAgICBib3JkZXItY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs4MDBdfTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5gXG5cbmNvbnN0IFNlYXJjaENvbnRhaW5lciA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogcm93IHdyYXA7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbmBcblxuZXhwb3J0IHtcbiAgU2VhcmNoQ29udGFpbmVyLFxuICBEYXRhR3JpZENvbnRhaW5lcixcbiAgRGF0YUdyaWRDb250cm9sU2VjdGlvbixcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxVQUFVLFdBQVc7QUFTNUIsTUFBTSx5QkFBeUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSTdCLFdBQVMsTUFBTSxNQUFNLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU10QyxNQUFNLHFCQUFxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlWLFdBQVMsTUFBTSxNQUFNLFNBQVM7QUFBQSxtQkFDNUIsV0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FReEMsV0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBO0FBQUE7QUFBQSxtQkFHckIsV0FBUyxNQUFNLE1BQU0sU0FBUztBQUFBLHFCQUM1QixXQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JwQyxXQUFTLE1BQU0sTUFBTSxTQUFTO0FBQUE7QUFBQTtBQUFBLGVBR2hDLFdBQVMsTUFBTSxNQUFNLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUkvQixXQUFTLE1BQU0sTUFBTSxPQUFPO0FBQUEsbUJBQ3RCLFdBQVMsTUFBTSxNQUFNLFdBQVc7QUFBQSx3QkFDM0IsV0FBUyxNQUFNLE1BQU0sT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUs5RCxNQUFNLDJCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTWpDLE1BQU0sb0JBQW9CLE9BQU87QUFBQTtBQUFBO0FBQUEsTUFHM0IsV0FBUyxNQUFNLFNBQVMscUJBQXFCO0FBQUE7QUFBQSxNQUU3QyxXQUFTLE1BQU0sbUJBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBT1YsQ0FBQUEsV0FBU0EsT0FBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUEsa0NBQ2hDLENBQUFBLFdBQVNBLE9BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUEsdUJBRS9DLENBQUFBLFdBQVNBLE9BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBY2pDLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVkvQixXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBLDRCQUNsQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUEsaUJBRWpELFdBQVMsTUFBTSxNQUFNLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBU2pCLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUlwQyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVFwQyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBTWhDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF5QjVELFdBQVM7QUFDZixNQUFJLE1BQU0sZUFBZSxNQUFNLGFBQWEsU0FBUyxHQUFHO0FBQ3RELFVBQU0saUJBQWlCLE1BQU0sWUFBWSxJQUFJLFdBQzNDO0FBQUEsaUNBQ3lCLE1BQU0sVUFBVTtBQUFBLGdDQUNqQixDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJLEdBQUc7QUFBQTtBQUFBLFNBRzVEO0FBRUQsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhTSxXQUFTLE1BQU0sV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBdUJWLFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUEsZ0NBQzVCLFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSTVDLFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSTNDLFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUEscUJBQ2hDLFdBQVMsTUFBTSxNQUFNLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBU3JCLFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBT25DLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUEsMEJBQzFDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBLGdDQUdoQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBLDRCQUMxQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFPbEUsTUFBTSxrQkFBa0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTS9CO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7IiwibmFtZXMiOlsicHJvcHMiXX0=