import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileName.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileName.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { profileQueryService } from "/src/modules/admin/profiles/services/index.ts";
const ProfileName = ({
  id
}) => {
  _s();
  const {
    data
  } = profileQueryService.useFindOne(id);
  return /* @__PURE__ */ jsxDEV("span", { children: data?.nome }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileName.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(ProfileName, "SPUSTaH9utC8vSSrVPbkM6DBdis=", false, function() {
  return [profileQueryService.useFindOne];
});
_c = ProfileName;
export default ProfileName;
var _c;
$RefreshReg$(_c, "ProfileName");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileName.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFKVCxTQUFTQSwyQkFBMkI7QUFFcEMsTUFBTUMsY0FBZ0NBLENBQUM7QUFBQSxFQUFFQztBQUFHLE1BQU07QUFBQUMsS0FBQTtBQUNoRCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBSyxJQUFJSixvQkFBb0JLLFdBQVdILEVBQUU7QUFDbEQsU0FBTyx1QkFBQyxVQUFNRSxnQkFBTUUsUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWtCO0FBQzNCO0FBQUNILEdBSEtGLGFBQTZCO0FBQUEsVUFDaEJELG9CQUFvQkssVUFBVTtBQUFBO0FBQUFFLEtBRDNDTjtBQUtOLGVBQWVBO0FBQVcsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInByb2ZpbGVRdWVyeVNlcnZpY2UiLCJQcm9maWxlTmFtZSIsImlkIiwiX3MiLCJkYXRhIiwidXNlRmluZE9uZSIsIm5vbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2ZpbGVOYW1lLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vcHJvZmlsZXMvY29tcG9uZW50cy9Qcm9maWxlTmFtZS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgcHJvZmlsZVF1ZXJ5U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xuXG5jb25zdCBQcm9maWxlTmFtZTogRkM8e2lkOiBzdHJpbmd9PiA9ICh7IGlkIH0pID0+IHtcbiAgY29uc3QgeyBkYXRhIH0gPSBwcm9maWxlUXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoaWQpXG4gIHJldHVybiA8c3Bhbj57ZGF0YT8ubm9tZX08L3NwYW4+XG59XG5cbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVOYW1lXG4iXX0=