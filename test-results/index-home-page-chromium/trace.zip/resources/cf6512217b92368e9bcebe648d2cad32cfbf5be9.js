import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dialog/ConfirmRedefineUser.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmRedefineUser.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { PrimaryButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import ConfirmDialog from "/src/shared/components/dialog/ConfirmDialog.tsx?t=1701096626433";
const ConfirmRedefineUser = (props) => {
  const {
    hidden,
    onDismiss,
    onConfirm,
    title,
    description
  } = props;
  return /* @__PURE__ */ jsxDEV(ConfirmDialog, { hidden, onDismiss, title, description, actions: () => [/* @__PURE__ */ jsxDEV(DefaultButton, { onClick: onDismiss, children: "Cancelar" }, "cancel", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmRedefineUser.tsx",
    lineNumber: 19,
    columnNumber: 119
  }, this), /* @__PURE__ */ jsxDEV(PrimaryButton, { onClick: onConfirm, children: "Confirmar" }, "confirm", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmRedefineUser.tsx",
    lineNumber: 21,
    columnNumber: 27
  }, this)] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmRedefineUser.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_c = ConfirmRedefineUser;
export default ConfirmRedefineUser;
var _c;
$RefreshReg$(_c, "ConfirmRedefineUser");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmRedefineUser.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRO0FBdEJSLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGVBQWVDLHFCQUFxQjtBQUM3QyxPQUFPQyxtQkFBbUI7QUFVMUIsTUFBTUMsc0JBQXFEQyxXQUFVO0FBQ25FLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFRQztBQUFBQSxJQUFXQztBQUFBQSxJQUFXQztBQUFBQSxJQUFPQztBQUFBQSxFQUFZLElBQUlMO0FBRTdELFNBQ0UsdUJBQUMsaUJBQ0MsUUFDQSxXQUNBLE9BQ0EsYUFDQSxTQUFTLE1BQU0sQ0FDYix1QkFBQyxpQkFFQyxTQUFTRSxXQUFVLHdCQURmLFVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBLEdBQ0EsdUJBQUMsaUJBRUMsU0FBU0MsV0FBVSx5QkFEZixXQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxDQUFnQixLQWpCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCSTtBQUdSO0FBQUNHLEtBekJLUDtBQTJCTixlQUFlQTtBQUFtQixJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUHJpbWFyeUJ1dHRvbiIsIkRlZmF1bHRCdXR0b24iLCJDb25maXJtRGlhbG9nIiwiQ29uZmlybVJlZGVmaW5lVXNlciIsInByb3BzIiwiaGlkZGVuIiwib25EaXNtaXNzIiwib25Db25maXJtIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29uZmlybVJlZGVmaW5lVXNlci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kaWFsb2cvQ29uZmlybVJlZGVmaW5lVXNlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUHJpbWFyeUJ1dHRvbiwgRGVmYXVsdEJ1dHRvbiB9IGZyb20gJy4uJ1xuaW1wb3J0IENvbmZpcm1EaWFsb2cgZnJvbSAnLi9Db25maXJtRGlhbG9nJ1xuXG5pbnRlcmZhY2UgQ29uZmlybVJlZGVmaW5lVXNlclByb3BzIHtcbiAgaGlkZGVuPzogYm9vbGVhblxuICB0aXRsZTogc3RyaW5nXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmdcbiAgb25EaXNtaXNzPzogKCkgPT4gdm9pZFxuICBvbkNvbmZpcm0/OiAoKSA9PiB2b2lkXG59XG5cbmNvbnN0IENvbmZpcm1SZWRlZmluZVVzZXI6IEZDPENvbmZpcm1SZWRlZmluZVVzZXJQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBoaWRkZW4sIG9uRGlzbWlzcywgb25Db25maXJtLCB0aXRsZSwgZGVzY3JpcHRpb24gfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8Q29uZmlybURpYWxvZ1xuICAgICAgaGlkZGVuPXtoaWRkZW59XG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cbiAgICAgIHRpdGxlPXt0aXRsZX1cbiAgICAgIGRlc2NyaXB0aW9uPXtkZXNjcmlwdGlvbn1cbiAgICAgIGFjdGlvbnM9eygpID0+IFtcbiAgICAgICAgPERlZmF1bHRCdXR0b25cbiAgICAgICAgICBrZXk9XCJjYW5jZWxcIlxuICAgICAgICAgIG9uQ2xpY2s9e29uRGlzbWlzc31cbiAgICAgICAgPlxuICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgIDwvRGVmYXVsdEJ1dHRvbj4sXG4gICAgICAgIDxQcmltYXJ5QnV0dG9uXG4gICAgICAgICAga2V5PVwiY29uZmlybVwiXG4gICAgICAgICAgb25DbGljaz17b25Db25maXJtfVxuICAgICAgICA+XG4gICAgICAgICAgQ29uZmlybWFyXG4gICAgICAgIDwvUHJpbWFyeUJ1dHRvbj4sXG4gICAgICBdfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ29uZmlybVJlZGVmaW5lVXNlclxuIl19