import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/IconButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/IconButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { DirectionalHint, IconButton as FluentIconButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { TooltipHost } from "/src/shared/components/tooltip/index.ts";
const IconButton = ({
  styles,
  hint,
  hintDirection,
  ...props
}) => {
  _s();
  const defaultStyles = useStyles();
  if (!hint) {
    return /* @__PURE__ */ jsxDEV(FluentIconButton, { styles: {
      ...defaultStyles,
      ...styles
    }, ...props }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/IconButton.tsx",
      lineNumber: 21,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(TooltipHost, { className: props.hintClassName, content: hint, directionalHint: hintDirection ?? DirectionalHint.topCenter, children: /* @__PURE__ */ jsxDEV(FluentIconButton, { styles: {
    ...defaultStyles,
    ...styles
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/IconButton.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/IconButton.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(IconButton, "uYP+0krwh/eAi1AE4qCuajrhuk4=", false, function() {
  return [useStyles];
});
_c = IconButton;
const useStyles = () => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = {
    icon: {
      color: colors.gray[600]
      // borderColor: colors.gray[500],
      // backgroundColor: colors.gray[200],
    },
    rootHovered: {
      color: colors.gray[600],
      // borderColor: colors.gray[500],
      backgroundColor: "transparent"
    },
    rootPressed: {
      color: colors.gray[600],
      // borderColor: colors.gray[500],
      backgroundColor: "transparent"
    }
  };
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default IconButton;
var _c;
$RefreshReg$(_c, "IconButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/IconButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFkTixTQUFTQSxpQkFBOENDLGNBQWNDLHdCQUF3QjtBQUM3RixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsbUJBQW1CO0FBUTVCLE1BQU1ILGFBQW1DQSxDQUFDO0FBQUEsRUFBRUk7QUFBQUEsRUFBUUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBZSxHQUFHQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUN0RixRQUFNQyxnQkFBZ0JDLFVBQVU7QUFDaEMsTUFBSSxDQUFDTCxNQUFNO0FBQ1QsV0FDRSx1QkFBQyxvQkFDQyxRQUFRO0FBQUEsTUFDTixHQUFHSTtBQUFBQSxNQUNILEdBQUdMO0FBQUFBLElBQ0wsR0FDQSxHQUFJRyxTQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLWTtBQUFBLEVBR2hCO0FBRUEsU0FDRSx1QkFBQyxlQUFZLFdBQVdBLE1BQU1JLGVBQWUsU0FBU04sTUFBTSxpQkFBaUJDLGlCQUFpQlAsZ0JBQWdCYSxXQUM1RyxpQ0FBQyxvQkFDQyxRQUFRO0FBQUEsSUFDTixHQUFHSDtBQUFBQSxJQUNILEdBQUdMO0FBQUFBLEVBQ0wsR0FDQSxHQUFJRyxTQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLWSxLQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUNDLEdBekJLUixZQUFnQztBQUFBLFVBQ2RVLFNBQVM7QUFBQTtBQUFBRyxLQUQzQmI7QUEyQk4sTUFBTVUsWUFBWUEsTUFBTTtBQUFBSSxNQUFBO0FBQ3RCLFFBQU1DLFNBQVNiLGVBQWU7QUFDOUIsUUFBTWMsZUFBOEI7QUFBQSxJQUNsQ0MsTUFBTTtBQUFBLE1BQ0pDLE9BQU9ILE9BQU9JLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQSxJQUd4QjtBQUFBLElBQ0FDLGFBQWE7QUFBQSxNQUNYRixPQUFPSCxPQUFPSSxLQUFLLEdBQUc7QUFBQTtBQUFBLE1BRXRCRSxpQkFBaUI7QUFBQSxJQUNuQjtBQUFBLElBQ0FDLGFBQWE7QUFBQSxNQUNYSixPQUFPSCxPQUFPSSxLQUFLLEdBQUc7QUFBQTtBQUFBLE1BRXRCRSxpQkFBaUI7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUFPTDtBQUNUO0FBQUNGLElBckJLSixXQUFTO0FBQUEsVUFDRVIsY0FBYztBQUFBO0FBc0IvQixlQUFlRjtBQUFVLElBQUFhO0FBQUFVLGFBQUFWLElBQUEiLCJuYW1lcyI6WyJEaXJlY3Rpb25hbEhpbnQiLCJJY29uQnV0dG9uIiwiRmx1ZW50SWNvbkJ1dHRvbiIsInVzZVRoZW1lQ29sb3JzIiwiVG9vbHRpcEhvc3QiLCJzdHlsZXMiLCJoaW50IiwiaGludERpcmVjdGlvbiIsInByb3BzIiwiX3MiLCJkZWZhdWx0U3R5bGVzIiwidXNlU3R5bGVzIiwiaGludENsYXNzTmFtZSIsInRvcENlbnRlciIsIl9jIiwiX3MyIiwiY29sb3JzIiwiYWN0aW9uU3R5bGVzIiwiaWNvbiIsImNvbG9yIiwiZ3JheSIsInJvb3RIb3ZlcmVkIiwiYmFja2dyb3VuZENvbG9yIiwicm9vdFByZXNzZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJY29uQnV0dG9uLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbnMvSWNvbkJ1dHRvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgUmVhY3RFbGVtZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBEaXJlY3Rpb25hbEhpbnQsIElCdXR0b25Qcm9wcywgSUJ1dHRvblN0eWxlcywgSWNvbkJ1dHRvbiBhcyBGbHVlbnRJY29uQnV0dG9uIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWVDb2xvcnMgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IFRvb2x0aXBIb3N0IH0gZnJvbSAnLi4vdG9vbHRpcCdcblxuaW50ZXJmYWNlIElJY29uQnV0dG9uUHJvcHMgZXh0ZW5kcyBJQnV0dG9uUHJvcHMge1xuICBoaW50Pzogc3RyaW5nfFJlYWN0RWxlbWVudFxuICBoaW50Q2xhc3NOYW1lPzogc3RyaW5nXG4gIGhpbnREaXJlY3Rpb24/OiBEaXJlY3Rpb25hbEhpbnRcbn1cblxuY29uc3QgSWNvbkJ1dHRvbjogRkM8SUljb25CdXR0b25Qcm9wcz4gPSAoeyBzdHlsZXMsIGhpbnQsIGhpbnREaXJlY3Rpb24sIC4uLnByb3BzIH0pID0+IHtcbiAgY29uc3QgZGVmYXVsdFN0eWxlcyA9IHVzZVN0eWxlcygpXG4gIGlmICghaGludCkge1xuICAgIHJldHVybiAoXG4gICAgICA8Rmx1ZW50SWNvbkJ1dHRvblxuICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAuLi5kZWZhdWx0U3R5bGVzLFxuICAgICAgICAgIC4uLnN0eWxlcyxcbiAgICAgICAgfX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgLz5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxUb29sdGlwSG9zdCBjbGFzc05hbWU9e3Byb3BzLmhpbnRDbGFzc05hbWV9IGNvbnRlbnQ9e2hpbnR9IGRpcmVjdGlvbmFsSGludD17aGludERpcmVjdGlvbiA/PyBEaXJlY3Rpb25hbEhpbnQudG9wQ2VudGVyfT5cbiAgICAgIDxGbHVlbnRJY29uQnV0dG9uXG4gICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgIC4uLmRlZmF1bHRTdHlsZXMsXG4gICAgICAgICAgLi4uc3R5bGVzLFxuICAgICAgICB9fVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgIDwvVG9vbHRpcEhvc3Q+XG4gIClcbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xuICBjb25zdCBjb2xvcnMgPSB1c2VUaGVtZUNvbG9ycygpXG4gIGNvbnN0IGFjdGlvblN0eWxlczogSUJ1dHRvblN0eWxlcyA9IHtcbiAgICBpY29uOiB7XG4gICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcbiAgICAgIC8vIGJvcmRlckNvbG9yOiBjb2xvcnMuZ3JheVs1MDBdLFxuICAgICAgLy8gYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuZ3JheVsyMDBdLFxuICAgIH0sXG4gICAgcm9vdEhvdmVyZWQ6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgLy8gYm9yZGVyQ29sb3I6IGNvbG9ycy5ncmF5WzUwMF0sXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgfSxcbiAgICByb290UHJlc3NlZDoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXG4gICAgICAvLyBib3JkZXJDb2xvcjogY29sb3JzLmdyYXlbNTAwXSxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcbiAgICB9LFxuICB9XG5cbiAgcmV0dXJuIGFjdGlvblN0eWxlc1xufVxuXG5leHBvcnQgZGVmYXVsdCBJY29uQnV0dG9uXG4iXX0=