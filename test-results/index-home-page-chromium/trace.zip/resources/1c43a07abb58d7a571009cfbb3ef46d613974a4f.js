import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/SearchBox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/SearchBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { SearchBox as Search } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const SearchBox = (props) => {
  _s();
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV(Search, { iconProps: {
    styles: {
      root: {
        fontSize: "16px"
      }
    }
  }, ...props, styles }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/SearchBox.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_s(SearchBox, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = SearchBox;
export default SearchBox;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  const searchBoxStyles = {
    root: {
      ":hover": {
        borderColor: colors.blue[300],
        ".ms-SearchBox-iconContainer": {
          color: colors.purple[300]
        }
      },
      "&.ms-SearchBox.is-active::after": {
        border: `solid 2px ${colors.blue[300]}`,
        borderRadius: "2px"
      }
    },
    iconContainer: {
      color: colors.purple[300]
    },
    field: {
      borderRadius: "2px",
      ".ms-SearchBox::after": {
        border: `solid 2px ${colors.blue[300]}`,
        borderRadius: "2px"
      }
    }
  };
  return searchBoxStyles;
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
var _c;
$RefreshReg$(_c, "SearchBox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/SearchBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQSixTQUE0Q0EsYUFBYUMsY0FBYztBQUV2RSxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUYsWUFBa0NHLFdBQVU7QUFBQUMsS0FBQTtBQUNoRCxRQUFNQyxTQUFTQyxVQUFVO0FBQ3pCLFNBQ0UsdUJBQUMsVUFDQyxXQUFXO0FBQUEsSUFDVEQsUUFBUTtBQUFBLE1BQ05FLE1BQU07QUFBQSxRQUNKQyxVQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsR0FBSUwsT0FDSixVQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTaUI7QUFHckI7QUFBQ0MsR0FmS0osV0FBOEI7QUFBQSxVQUNuQk0sU0FBUztBQUFBO0FBQUFHLEtBRHBCVDtBQWlCTixlQUFlQTtBQUVmLE1BQU1NLFlBQVlBLE1BQU07QUFBQUksTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJVCxTQUFTO0FBQzVCLFFBQU1VLGtCQUE2QztBQUFBLElBQ2pETCxNQUFNO0FBQUEsTUFDSixVQUFVO0FBQUEsUUFDUk0sYUFBYUYsT0FBT0csS0FBSyxHQUFHO0FBQUEsUUFDNUIsK0JBQStCO0FBQUEsVUFDN0JDLE9BQU9KLE9BQU9LLE9BQU8sR0FBRztBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsbUNBQW1DO0FBQUEsUUFDakNDLFFBQVMsYUFBWU4sT0FBT0csS0FBSyxHQUFHO0FBQUEsUUFDcENJLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBQyxlQUFlO0FBQUEsTUFDYkosT0FBT0osT0FBT0ssT0FBTyxHQUFHO0FBQUEsSUFDMUI7QUFBQSxJQUNBSSxPQUFPO0FBQUEsTUFDTEYsY0FBYztBQUFBLE1BQ2Qsd0JBQXdCO0FBQUEsUUFDdEJELFFBQVMsYUFBWU4sT0FBT0csS0FBSyxHQUFHO0FBQUEsUUFDcENJLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBT047QUFDVDtBQUFDRixJQTNCS0osV0FBUztBQUFBLFVBQ01KLFFBQVE7QUFBQTtBQUFBLElBQUFPO0FBQUFZLGFBQUFaLElBQUEiLCJuYW1lcyI6WyJTZWFyY2hCb3giLCJTZWFyY2giLCJ1c2VUaGVtZSIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJyb290IiwiZm9udFNpemUiLCJfYyIsIl9zMiIsImNvbG9ycyIsInNlYXJjaEJveFN0eWxlcyIsImJvcmRlckNvbG9yIiwiYmx1ZSIsImNvbG9yIiwicHVycGxlIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwiaWNvbkNvbnRhaW5lciIsImZpZWxkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2VhcmNoQm94LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2lucHV0cy9TZWFyY2hCb3gudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVNlYXJjaEJveFByb3BzLCBJU2VhcmNoQm94U3R5bGVzLCBTZWFyY2hCb3ggYXMgU2VhcmNoIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xyXG5cclxuY29uc3QgU2VhcmNoQm94OiBGQzxJU2VhcmNoQm94UHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuICByZXR1cm4gKFxyXG4gICAgPFNlYXJjaFxyXG4gICAgICBpY29uUHJvcHM9e3tcclxuICAgICAgICBzdHlsZXM6IHtcclxuICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgZm9udFNpemU6ICcxNnB4JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgICBzdHlsZXM9e3N0eWxlc31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hCb3hcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IHNlYXJjaEJveFN0eWxlczogUGFydGlhbDxJU2VhcmNoQm94U3R5bGVzPiA9IHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgJzpob3Zlcic6IHtcclxuICAgICAgICBib3JkZXJDb2xvcjogY29sb3JzLmJsdWVbMzAwXSxcclxuICAgICAgICAnLm1zLVNlYXJjaEJveC1pY29uQ29udGFpbmVyJzoge1xyXG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5wdXJwbGVbMzAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICAnJi5tcy1TZWFyY2hCb3guaXMtYWN0aXZlOjphZnRlcic6IHtcclxuICAgICAgICBib3JkZXI6IGBzb2xpZCAycHggJHtjb2xvcnMuYmx1ZVszMDBdfWAsXHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnMnB4JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBpY29uQ29udGFpbmVyOiB7XHJcbiAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzMwMF0sXHJcbiAgICB9LFxyXG4gICAgZmllbGQ6IHtcclxuICAgICAgYm9yZGVyUmFkaXVzOiAnMnB4JyxcclxuICAgICAgJy5tcy1TZWFyY2hCb3g6OmFmdGVyJzoge1xyXG4gICAgICAgIGJvcmRlcjogYHNvbGlkIDJweCAke2NvbG9ycy5ibHVlWzMwMF19YCxcclxuICAgICAgICBib3JkZXJSYWRpdXM6ICcycHgnLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9XHJcbiAgcmV0dXJuIHNlYXJjaEJveFN0eWxlc1xyXG59XHJcbiJdfQ==