import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataGrid.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { getValue } from "/node_modules/.vite/deps/@syncfusion_ej2-base.js?v=9f90a7ff";
import { Inject, GridComponent } from "/node_modules/.vite/deps/@syncfusion_ej2-react-grids.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useMemo = __vite__cjsImport5_react["useMemo"]; const useRef = __vite__cjsImport5_react["useRef"]; const useState = __vite__cjsImport5_react["useState"];
import { DataGridContainer, DataGridControlSection, SearchContainer } from "/src/shared/components/datatable/DataGrid.style.ts";
import DataTableSearch from "/src/shared/components/datatable/DataTableSearch.tsx?t=1701096626433";
import { debounce } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { IconButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import { useTheme } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { DirectionalHint } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { LoadingScreen } from "/src/shared/components/loadingScreen/index.ts?t=1701096626433";
import DataTablePagination from "/src/shared/components/datatable/DataTablePagination.tsx";
import DataTableEmptyState from "/src/shared/components/datatable/DataTableEmptyState.tsx";
import { FlexRow } from "/src/shared/components/FlexBox/index.ts";
import DataTableFilterGroups from "/src/shared/components/datatable/DataTableFilterGroups.tsx?t=1701096626433";
import { buildGridServices, buildGridToolbar } from "/src/shared/components/datatable/utils.ts";
import { DataManagerAdaptor } from "/src/shared/api/DataManagerAdaptor.ts";
import { DataManager } from "/node_modules/.vite/deps/@syncfusion_ej2-data_src.js?v=9f90a7ff";
const pageSettings = {
  pageCount: 5,
  pageSizes: [12, 25, 50]
};
const COMMAND_COLUMN_FIELD = "#_menu";
const MIN_WIDTH_COLUMN = 170;
function DataGrid(props) {
  _s();
  const gridRef = useRef(null);
  const {
    items,
    paginated,
    resizeable,
    groupable,
    freezable,
    aggregate,
    editSettings,
    groupSettings,
    columns,
    singleActions,
    aggregates,
    sortConfig,
    itemsCount,
    onPageChange,
    onSortChange,
    onSearchTextChange,
    compact = true,
    onRowChanged,
    groupErrors,
    menuOptions,
    renderActions,
    hiddenMenu,
    loading,
    customPageOptions,
    onFilterGroupChange,
    selection,
    onSelection,
    hasSelection,
    autoFitColumns,
    onMenuOpened,
    onMenuDismissed,
    isFilterable,
    showColumnChooser,
    hasSearch,
    onLastSelection,
    height = void 0,
    query,
    dataUrl,
    searchSettings,
    isDetailingMode
  } = props;
  const theme = useTheme();
  const [itemsCountCache, setItemsCountCache] = useState(0);
  const [pageSizeCache, setPageSizeCache] = useState(0);
  const hasFilter = useMemo(() => {
    return !!columns && columns.some((column) => column.filterOptions?.isGroupMode);
  }, [columns, items]);
  const sortSettings = useMemo(() => {
    if (!sortConfig)
      return void 0;
    return {
      allowUnsort: false,
      columns: [{
        field: sortConfig?.field,
        direction: sortConfig?.descending ? "Descending" : "Ascending"
      }]
    };
  }, [sortConfig]);
  const selectionSettings = {
    mode: "Row",
    persistSelection: false,
    checkboxMode: "Default",
    type: "Multiple",
    checkboxOnly: true
  };
  const filterSettings = {
    type: "Excel"
  };
  const editable = editSettings !== void 0;
  const sortable = sortSettings !== void 0;
  const searchable = !!onSearchTextChange;
  const hasMenuItems = menuOptions && menuOptions?.length !== 0 || singleActions && singleActions?.length !== 0;
  const frozenable = freezable || hasMenuItems;
  const dataManager = new DataManager({
    url: dataUrl ?? "",
    adaptor: new DataManagerAdaptor(),
    crossDomain: true,
    timeTillExpiration: 6e4
  });
  const getDataSource = useCallback(() => {
    let dataSource;
    if (itemsCount) {
      dataSource = {
        result: items,
        count: itemsCount
      };
    } else {
      dataSource = items || [];
    }
    return dataSource;
  }, [items, itemsCount]);
  const handlePageChange = useCallback((state) => {
    const config = {
      itemsSkipped: state.skip,
      pageSize: state.take
    };
    if (onPageChange) {
      onPageChange(config);
    }
  }, [onPageChange]);
  const handleSortChange = useCallback((action) => {
    const config = {
      descending: action.direction === "Descending",
      field: action.columnName
    };
    if (onSortChange) {
      onSortChange(config);
    }
  }, [onSortChange, sortSettings]);
  const handleStateChange = useCallback((state) => {
    switch (state.action?.requestType) {
      case "refresh": {
        gridRef.current?.hideSpinner();
        break;
      }
      case "paging":
        handlePageChange(state);
        break;
      case "sorting":
        handleSortChange(state?.action);
        break;
    }
  }, [handlePageChange, handleSortChange]);
  const handleActionBegin = useCallback((args) => {
    switch (args.requestType) {
      case "beginEdit":
        if (getValue("isEmpty", args.rowData) === true) {
          args.cancel = true;
        }
        break;
    }
  }, []);
  const handleActionComplete = useCallback((state) => {
    const {
      data,
      ...options
    } = state;
    switch (state.action) {
      case "edit":
        if (data && onRowChanged) {
          onRowChanged(data, options);
        }
        break;
    }
  }, [onRowChanged]);
  const selected = useCallback((args) => {
    if (!args.isInteracted)
      return;
    const allSelected = gridRef.current?.getSelectedRecords();
    onSelection?.(allSelected);
    const data = Array.isArray(args.data) ? args.data : [args.data];
    onLastSelection?.(data, true, args.isHeaderCheckboxClicked);
  }, [onLastSelection, onSelection]);
  const deselected = useCallback((args) => {
    if (!args.isInteracted)
      return;
    const allSelected = gridRef.current?.getSelectedRecords();
    onSelection?.(allSelected);
    const data = Array.isArray(args.data) ? args.data : [args.data];
    onLastSelection?.(data, false, args.isHeaderCheckboxClicked);
  }, [onLastSelection, onSelection]);
  const renderMenuOptions = (args, menuOptions2) => {
    const changeMenuOpened = () => {
      if (onMenuOpened)
        onMenuOpened(args);
    };
    const changeMenuDismissed = () => {
      if (onMenuDismissed)
        onMenuDismissed(args);
    };
    const menuProps = (item) => ({
      items: menuOptions2?.(item) ?? [],
      directionalHint: DirectionalHint.bottomRightEdge,
      onMenuOpened: changeMenuOpened,
      onMenuDismissed: changeMenuDismissed
    });
    return /* @__PURE__ */ jsxDEV(IconButton, { menuProps: menuProps(args), ariaDescription: "Opções", onRenderMenuIcon: () => /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 248,
      columnNumber: 112
    }, this), iconProps: {
      iconName: "More",
      color: theme.colors.primary
    }, styles: {
      rootHovered: {
        backgroundColor: theme.colors.gray[300]
      }
    } }, "menu", false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 248,
      columnNumber: 12
    }, this);
  };
  const renderActionButtons = useCallback((args) => {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      menuOptions !== void 0 && menuOptions.length > 0 && renderMenuOptions(args, menuOptions),
      !!singleActions && singleActions.map((action) => {
        if (action.onHiddenButtonWhen !== void 0 && action.onHiddenButtonWhen(args))
          return /* @__PURE__ */ jsxDEV("div", {}, action.type, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
            lineNumber: 261,
            columnNumber: 96
          }, this);
        if (!editSettings?.allowDeleting)
          return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
            lineNumber: 262,
            columnNumber: 50
          }, this);
        return /* @__PURE__ */ jsxDEV(IconButton, { ariaDescription: action.type === "edit" ? "Alterar" : "Excluir", iconProps: {
          iconName: action.type === "edit" ? "pen" : "trash",
          color: theme.colors.primary
        }, styles: {
          rootHovered: {
            backgroundColor: theme.colors.gray[300]
          }
        }, hint: action?.description, onClick: () => action.onClick(args) }, action.type, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
          lineNumber: 263,
          columnNumber: 16
        }, this);
      })
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 258,
      columnNumber: 12
    }, this);
  }, [singleActions, editSettings, menuOptions, renderMenuOptions]);
  const commandColumn = useMemo(() => {
    if (!renderActionButtons || !hasMenuItems)
      return void 0;
    const commandColumn2 = {
      field: COMMAND_COLUMN_FIELD,
      headerText: "",
      width: "40px",
      showInColumnChooser: false,
      allowEditing: false,
      allowResizing: false,
      allowSorting: false,
      allowFiltering: false,
      allowReordering: false,
      editTemplate: renderActionButtons,
      allowGrouping: false,
      allowSearching: false,
      template: renderActionButtons,
      freeze: !singleActions ? "Fixed" : void 0,
      // mudar validação, encontrar limitação da tabela
      textAlign: "Right"
    };
    return commandColumn2;
  }, [renderActionButtons, singleActions, hasMenuItems]);
  const selectionColumn = useMemo(() => {
    if (!hasSelection)
      return;
    const selectionColumn2 = {
      type: "checkbox",
      width: 50,
      showInColumnChooser: false,
      allowEditing: false,
      allowResizing: false,
      allowSorting: false,
      allowFiltering: false,
      allowReordering: false,
      allowSearching: false,
      allowGrouping: false
    };
    return selectionColumn2;
  }, [hasSelection]);
  const columnsFormatted = useMemo(() => {
    if (!columns)
      return void 0;
    const formattedColumns = [];
    if (selectionColumn) {
      formattedColumns.push(selectionColumn);
    }
    formattedColumns.push(...convertColumnsToFormat(columns));
    if (commandColumn) {
      formattedColumns.push(commandColumn);
    }
    formattedColumns.push();
    return formattedColumns;
  }, [columns, commandColumn, selectionColumn]);
  const getSelectionIndexes = useCallback(() => {
    if (gridRef.current && selection !== void 0) {
      const rowIndexes = [];
      const currentData = gridRef.current?.currentViewData;
      currentData.forEach((row, index) => {
        if (selection?.some((select) => select.id === row.id)) {
          rowIndexes.push(index);
        }
      });
      const hasData = gridRef.current.getRows() && gridRef.current.getRows().length > 0;
      if (hasData) {
        gridRef.current.clearRowSelection();
        gridRef.current.selectRows(rowIndexes);
      }
    }
  }, [selection]);
  const dataBound = useCallback(() => {
    getSelectionIndexes();
    if (autoFitColumns)
      gridRef.current?.autoFitColumns([]);
  }, [autoFitColumns, getSelectionIndexes]);
  useEffect(() => {
    if (items) {
      setPageSizeCache(items.length);
    }
  }, [items]);
  useEffect(() => {
    if (itemsCount) {
      setItemsCountCache(itemsCount);
    }
  }, [itemsCount]);
  return /* @__PURE__ */ jsxDEV(DataGridControlSection, { children: [
    searchable && getDataSource() && /* @__PURE__ */ jsxDEV(SearchContainer, { children: [
      !hiddenMenu && /* @__PURE__ */ jsxDEV(FlexRow, { styles: {
        flexGrow: 1
      }, gap: theme.spacing.lg, children: renderActions?.() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
        lineNumber: 357,
        columnNumber: 27
      }, this),
      /* @__PURE__ */ jsxDEV(DataTableSearch, { onChange: debounce(onSearchTextChange, 300) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
        lineNumber: 362,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 356,
      columnNumber: 41
    }, this),
    hasFilter && onFilterGroupChange && columns && /* @__PURE__ */ jsxDEV(DataTableFilterGroups, { columns, onQueryChange: onFilterGroupChange }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 364,
      columnNumber: 55
    }, this),
    /* @__PURE__ */ jsxDEV(DataGridContainer, { isDetailingMode, compact, groupErrors, hasUrl: !!dataUrl, children: [
      loading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
        lineNumber: 366,
        columnNumber: 21
      }, this),
      !loading && (items && items.length > 0 || dataUrl) && /* @__PURE__ */ jsxDEV(
        GridComponent,
        {
          locale: "pt-BR",
          dataSource: dataUrl ? dataManager : getDataSource(),
          toolbar: buildGridToolbar(showColumnChooser, hasSearch),
          dataBound,
          aggregates,
          height,
          query,
          columns: columnsFormatted,
          allowPaging: paginated,
          editSettings,
          pageSettings,
          sortSettings,
          allowGrouping: groupable,
          groupSettings,
          allowResizing: resizeable,
          allowFiltering: isFilterable,
          filterSettings,
          allowSorting: sortable,
          selectionSettings,
          dataStateChange: handleStateChange,
          actionComplete: handleActionComplete,
          actionBegin: handleActionBegin,
          rowSelected: selected,
          rowDeselected: deselected,
          resizeSettings: {
            mode: "Normal"
          },
          showColumnChooser,
          ref: gridRef,
          searchSettings,
          children: /* @__PURE__ */ jsxDEV(Inject, { services: buildGridServices(paginated, resizeable, groupable, aggregate, editable, sortable, hasMenuItems, frozenable, isFilterable, showColumnChooser) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
            lineNumber: 374,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
          lineNumber: 367,
          columnNumber: 64
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 365,
      columnNumber: 7
    }, this),
    !loading && items && items.length === 0 && /* @__PURE__ */ jsxDEV(DataTableEmptyState, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 377,
      columnNumber: 51
    }, this),
    !dataUrl && paginated && onPageChange && /* @__PURE__ */ jsxDEV(DataTablePagination, { pageItemsCount: pageSizeCache, totalItemsCount: itemsCountCache, onPageChange, customPageOptions }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
      lineNumber: 378,
      columnNumber: 49
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx",
    lineNumber: 355,
    columnNumber: 10
  }, this);
}
_s(DataGrid, "z/e/OxUZb0JcPl6r0ACIiWb5PtA=", false, function() {
  return [useTheme];
});
_c = DataGrid;
function convertColumnsToFormat(columns) {
  return columns.map((column) => {
    const isPrimaryKey = column.field === "id";
    const isColumnVisible = column.visible !== void 0 ? column.visible : column.blockShowing ? false : true;
    const translatedColumn = {
      allowSorting: column.sortable || false,
      allowEditing: column.allowEditing || false,
      allowResizing: column.allowResizing || false,
      allowFiltering: column.filterable || false,
      // allowReordering: false,
      clipMode: "EllipsisWithTooltip",
      headerText: column.header,
      field: column.field,
      type: column.type,
      template: column.format,
      maxWidth: column.maxWidth,
      minWidth: column.minWidth || MIN_WIDTH_COLUMN,
      isPrimaryKey: column.isPrimaryKey || isPrimaryKey,
      width: column.width || column.minWidth || MIN_WIDTH_COLUMN,
      visible: isColumnVisible,
      format: column.formatConfig,
      columns: column.columns ? convertColumnsToFormat(column.columns) : void 0,
      editType: column.editType,
      textAlign: column.center ? "Center" : column.textAlign,
      validationRules: column.validationRules,
      edit: column.edit,
      foreignKeyValue: column.foreignKeyValue,
      foreignKeyField: column.foreignKeyField,
      dataSource: column.dataSource,
      filter: column.filter || {},
      filterTemplate: column.filterTemplate,
      filterBarTemplate: column.filterBarTemplate
    };
    return translatedColumn;
  });
}
export default DataGrid;
var _c;
$RefreshReg$(_c, "DataGrid");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataGrid.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaVNnQzs7Ozs7Ozs7Ozs7Ozs7OztBQWpTaEMsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQ0VDLFFBR0FDLHFCQWFLO0FBQ1AsU0FBa0NDLGFBQWFDLFdBQVdDLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUUzRixTQUFTQyxtQkFBbUJDLHdCQUF3QkMsdUJBQXVCO0FBRTNFLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBbUY7QUFDNUYsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyx5QkFBeUI7QUFDaEMsU0FBU0MsZUFBZTtBQUV4QixPQUFPQywyQkFBMkI7QUFDbEMsU0FBU0MsbUJBQW1CQyx3QkFBd0I7QUFDcEQsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLG1CQUEwQjtBQStDbkMsTUFBTUMsZUFBa0M7QUFBQSxFQUN0Q0MsV0FBVztBQUFBLEVBQ1hDLFdBQVcsQ0FBQyxJQUFJLElBQUksRUFBRTtBQUN4QjtBQUNBLE1BQU1DLHVCQUF1QjtBQUM3QixNQUFNQyxtQkFBbUI7QUFFekIsU0FBU0MsU0FBNEJDLE9BQXNDO0FBQUFDLEtBQUE7QUFDekUsUUFBTUMsVUFBVTNCLE9BQXNCLElBQUk7QUFFMUMsUUFBTTtBQUFBLElBQ0o0QjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxVQUFVO0FBQUEsSUFDVkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsU0FBU0M7QUFBQUEsSUFDVEM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJM0M7QUFFSixRQUFNNEMsUUFBUTdELFNBQVM7QUFFdkIsUUFBTSxDQUFDOEQsaUJBQWlCQyxrQkFBa0IsSUFBSXRFLFNBQVMsQ0FBQztBQUN4RCxRQUFNLENBQUN1RSxlQUFlQyxnQkFBZ0IsSUFBSXhFLFNBQVMsQ0FBQztBQUNwRCxRQUFNeUUsWUFBWTNFLFFBQVEsTUFBTTtBQUM5QixXQUFPLENBQUMsQ0FBQ3FDLFdBQVdBLFFBQVF1QyxLQUFLQyxZQUFVQSxPQUFPQyxlQUFlQyxXQUFXO0FBQUEsRUFDOUUsR0FBRyxDQUFDMUMsU0FBU1IsS0FBSyxDQUFDO0FBRW5CLFFBQU1tRCxlQUFlaEYsUUFBUSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ3dDO0FBQVksYUFBT3lCO0FBQ3hCLFdBQU87QUFBQSxNQUNMZ0IsYUFBYTtBQUFBLE1BQ2I1QyxTQUFTLENBQUM7QUFBQSxRQUFFNkMsT0FBTzFDLFlBQVkwQztBQUFBQSxRQUFPQyxXQUFXM0MsWUFBWTRDLGFBQWEsZUFBZTtBQUFBLE1BQVksQ0FBQztBQUFBLElBQ3hHO0FBQUEsRUFDRixHQUFHLENBQUM1QyxVQUFVLENBQUM7QUFFZixRQUFNNkMsb0JBQTRDO0FBQUEsSUFDaERDLE1BQU07QUFBQSxJQUNOQyxrQkFBa0I7QUFBQSxJQUNsQkMsY0FBYztBQUFBLElBQ2RDLE1BQU07QUFBQSxJQUNOQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxRQUFNQyxpQkFBc0M7QUFBQSxJQUMxQ0YsTUFBTTtBQUFBLEVBQ1I7QUFFQSxRQUFNRyxXQUFXekQsaUJBQWlCOEI7QUFDbEMsUUFBTTRCLFdBQVdiLGlCQUFpQmY7QUFDbEMsUUFBTTZCLGFBQWEsQ0FBQyxDQUFDbEQ7QUFDckIsUUFBTW1ELGVBQWdCL0MsZUFBZUEsYUFBYWdELFdBQVcsS0FDNUQxRCxpQkFBaUJBLGVBQWUwRCxXQUFXO0FBQzVDLFFBQU1DLGFBQWFoRSxhQUFhOEQ7QUFFaEMsUUFBTUcsY0FBYyxJQUFJL0UsWUFBWTtBQUFBLElBQ2xDZ0YsS0FBS2hDLFdBQVc7QUFBQSxJQUNoQmlDLFNBQVMsSUFBSWxGLG1CQUFtQjtBQUFBLElBQ2hDbUYsYUFBYTtBQUFBLElBQ2JDLG9CQUFvQjtBQUFBLEVBQ3RCLENBQUM7QUFFRCxRQUFNQyxnQkFBZ0J6RyxZQUFZLE1BQXNDO0FBQ3RFLFFBQUkwRztBQUNKLFFBQUkvRCxZQUFZO0FBQ2QrRCxtQkFBYTtBQUFBLFFBQ1hDLFFBQVE1RTtBQUFBQSxRQUNSNkUsT0FBT2pFO0FBQUFBLE1BQ1Q7QUFBQSxJQUNGLE9BQU87QUFDTCtELG1CQUFhM0UsU0FBUztBQUFBLElBQ3hCO0FBRUEsV0FBTzJFO0FBQUFBLEVBQ1QsR0FBRyxDQUFDM0UsT0FBT1ksVUFBVSxDQUFDO0FBRXRCLFFBQU1rRSxtQkFBbUI3RyxZQUFZLENBQUM4RyxVQUFvQztBQUN4RSxVQUFNQyxTQUFTO0FBQUEsTUFDYkMsY0FBY0YsTUFBTUc7QUFBQUEsTUFDcEJDLFVBQVVKLE1BQU1LO0FBQUFBLElBQ2xCO0FBQ0EsUUFBSXZFLGNBQWM7QUFDaEJBLG1CQUFhbUUsTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUNuRSxZQUFZLENBQUM7QUFFakIsUUFBTXdFLG1CQUFtQnBILFlBQVksQ0FBQ3FILFdBQTBCO0FBQzlELFVBQU1OLFNBQThCO0FBQUEsTUFDbEN6QixZQUFZK0IsT0FBT2hDLGNBQWM7QUFBQSxNQUNqQ0QsT0FBT2lDLE9BQU9DO0FBQUFBLElBQ2hCO0FBRUEsUUFBSXpFLGNBQWM7QUFDaEJBLG1CQUFha0UsTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUNsRSxjQUFjcUMsWUFBWSxDQUFDO0FBRS9CLFFBQU1xQyxvQkFBb0J2SCxZQUFZLENBQUM4RyxVQUFvQztBQUN6RSxZQUFRQSxNQUFNTyxRQUFRRyxhQUFXO0FBQUEsTUFDL0IsS0FBSyxXQUFXO0FBQ2QxRixnQkFBUTJGLFNBQVNDLFlBQVk7QUFDN0I7QUFBQSxNQUNGO0FBQUEsTUFDQSxLQUFLO0FBQ0hiLHlCQUFpQkMsS0FBSztBQUN0QjtBQUFBLE1BQ0YsS0FBSztBQUNITSx5QkFBaUJOLE9BQU9PLE1BQXVCO0FBQy9DO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDUixrQkFBa0JPLGdCQUFnQixDQUFDO0FBRXZDLFFBQU1PLG9CQUFvQjNILFlBQVksQ0FBQzRILFNBQXFDO0FBQzFFLFlBQVFBLEtBQUtKLGFBQVc7QUFBQSxNQUN0QixLQUFLO0FBQ0gsWUFBSTNILFNBQVMsV0FBVytILEtBQUtDLE9BQU8sTUFBTSxNQUFNO0FBQzlDRCxlQUFLRSxTQUFTO0FBQUEsUUFDaEI7QUFDQTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLHVCQUF1Qi9ILFlBQVksQ0FBQzhHLFVBQXNDO0FBQzlFLFVBQU07QUFBQSxNQUFFa0I7QUFBQUEsTUFBTSxHQUFHQztBQUFBQSxJQUFRLElBQUluQjtBQUU3QixZQUFRQSxNQUFNTyxRQUFNO0FBQUEsTUFDbEIsS0FBSztBQUNILFlBQUlXLFFBQVFoRixjQUFjO0FBQ3hCQSx1QkFBYWdGLE1BQU1DLE9BQU87QUFBQSxRQUM1QjtBQUNBO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDakYsWUFBWSxDQUFDO0FBRWpCLFFBQU1rRixXQUFXbEksWUFBWSxDQUFDNEgsU0FBNkI7QUFDekQsUUFBSSxDQUFDQSxLQUFLTztBQUFjO0FBRXhCLFVBQU1DLGNBQWN0RyxRQUFRMkYsU0FBU1ksbUJBQW1CO0FBQ3hENUUsa0JBQWMyRSxXQUFXO0FBRXpCLFVBQU1KLE9BQVlNLE1BQU1DLFFBQVFYLEtBQUtJLElBQUksSUFBSUosS0FBS0ksT0FBYyxDQUFDSixLQUFLSSxJQUFTO0FBQy9FL0Qsc0JBQWtCK0QsTUFBTSxNQUFNSixLQUFLWSx1QkFBdUI7QUFBQSxFQUM1RCxHQUFHLENBQUN2RSxpQkFBaUJSLFdBQVcsQ0FBQztBQUVqQyxRQUFNZ0YsYUFBYXpJLFlBQVksQ0FBQzRILFNBQStCO0FBQzdELFFBQUksQ0FBQ0EsS0FBS087QUFBYztBQUV4QixVQUFNQyxjQUFjdEcsUUFBUTJGLFNBQVNZLG1CQUFtQjtBQUN4RDVFLGtCQUFjMkUsV0FBVztBQUV6QixVQUFNSixPQUFZTSxNQUFNQyxRQUFRWCxLQUFLSSxJQUFJLElBQUlKLEtBQUtJLE9BQWMsQ0FBQ0osS0FBS0ksSUFBUztBQUMvRS9ELHNCQUFrQitELE1BQU0sT0FBT0osS0FBS1ksdUJBQXVCO0FBQUEsRUFDN0QsR0FBRyxDQUFDdkUsaUJBQWlCUixXQUFXLENBQUM7QUFFakMsUUFBTWlGLG9CQUFvQkEsQ0FBQ2QsTUFBK0IxRSxpQkFBa0U7QUFDMUgsVUFBTXlGLG1CQUFtQkEsTUFBTTtBQUM3QixVQUFJL0U7QUFBY0EscUJBQWFnRSxJQUFJO0FBQUEsSUFDckM7QUFDQSxVQUFNZ0Isc0JBQXNCQSxNQUFNO0FBQ2hDLFVBQUkvRTtBQUFpQkEsd0JBQWdCK0QsSUFBSTtBQUFBLElBQzNDO0FBQ0EsVUFBTWlCLFlBQVlBLENBQUNDLFVBQW1DO0FBQUEsTUFDcEQvRyxPQUFPbUIsZUFBYzRGLElBQUksS0FBSztBQUFBLE1BQzlCQyxpQkFBaUJuSSxnQkFBZ0JvSTtBQUFBQSxNQUNqQ3BGLGNBQWMrRTtBQUFBQSxNQUNkOUUsaUJBQWlCK0U7QUFBQUEsSUFDbkI7QUFFQSxXQUNFLHVCQUFDLGNBQ0MsV0FBV0MsVUFBVWpCLElBQUksR0FFekIsaUJBQWdCLFVBQ2hCLGtCQUFrQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRSxHQUMxQixXQUFXO0FBQUEsTUFDVHFCLFVBQVU7QUFBQSxNQUNWQyxPQUFPMUUsTUFBTTJFLE9BQU9DO0FBQUFBLElBQ3RCLEdBQ0EsUUFBUTtBQUFBLE1BQ05DLGFBQWE7QUFBQSxRQUNYQyxpQkFBaUI5RSxNQUFNMkUsT0FBT0ksS0FBSyxHQUFHO0FBQUEsTUFDeEM7QUFBQSxJQUNGLEtBWEksUUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUk7QUFBQSxFQUdSO0FBRUEsUUFBTUMsc0JBQXNCeEosWUFBWSxDQUFDNEgsU0FBa0M7QUFDekUsV0FDRSxtQ0FDRzFFO0FBQUFBLHNCQUFnQmlCLFVBQWFqQixZQUFZZ0QsU0FBUyxLQUNuRHdDLGtCQUFrQmQsTUFBTTFFLFdBQVc7QUFBQSxNQUVsQyxDQUFDLENBQUNWLGlCQUFpQkEsY0FBY2lILElBQUlwQyxZQUFVO0FBQzlDLFlBQUlBLE9BQU9xQyx1QkFBdUJ2RixVQUFha0QsT0FBT3FDLG1CQUFtQjlCLElBQUk7QUFBRyxpQkFBTyx1QkFBQyxXQUFTUCxPQUFPMUIsTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFDOUcsWUFBSSxDQUFDdEQsY0FBY3NIO0FBQWUsaUJBQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRTtBQUUzQyxlQUNFLHVCQUFDLGNBRUMsaUJBQWlCdEMsT0FBTzFCLFNBQVMsU0FBUyxZQUFZLFdBQ3RELFdBQVc7QUFBQSxVQUNUc0QsVUFBVTVCLE9BQU8xQixTQUFTLFNBQVMsUUFBUTtBQUFBLFVBQzNDdUQsT0FBTzFFLE1BQU0yRSxPQUFPQztBQUFBQSxRQUN0QixHQUNBLFFBQVE7QUFBQSxVQUNOQyxhQUFhO0FBQUEsWUFDWEMsaUJBQWlCOUUsTUFBTTJFLE9BQU9JLEtBQUssR0FBRztBQUFBLFVBQ3hDO0FBQUEsUUFDRixHQUNBLE1BQU1sQyxRQUFRdUMsYUFDZCxTQUFTLE1BQU12QyxPQUFPd0MsUUFBUWpDLElBQUksS0FaN0JQLE9BQU8xQixNQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhc0M7QUFBQSxNQUcxQyxDQUFDO0FBQUEsU0F6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLEVBRUosR0FBRyxDQUFDbkQsZUFBZUgsY0FBY2EsYUFBYXdGLGlCQUFpQixDQUFDO0FBRWhFLFFBQU1vQixnQkFBaUQ1SixRQUFRLE1BQU07QUFDbkUsUUFBSSxDQUFDc0osdUJBQXVCLENBQUN2RDtBQUFjLGFBQU85QjtBQUVsRCxVQUFNMkYsaUJBQXFDO0FBQUEsTUFDekMxRSxPQUFPM0Q7QUFBQUEsTUFDUHNJLFlBQVk7QUFBQSxNQUNaQyxPQUFPO0FBQUEsTUFDUEMscUJBQXFCO0FBQUEsTUFDckJDLGNBQWM7QUFBQSxNQUNkQyxlQUFlO0FBQUEsTUFDZkMsY0FBYztBQUFBLE1BQ2RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxpQkFBaUI7QUFBQSxNQUNqQkMsY0FBY2Y7QUFBQUEsTUFDZGdCLGVBQWU7QUFBQSxNQUNmQyxnQkFBZ0I7QUFBQSxNQUNoQkMsVUFBVWxCO0FBQUFBLE1BQ1ZtQixRQUFRLENBQUNuSSxnQkFBZ0IsVUFBVTJCO0FBQUFBO0FBQUFBLE1BQ25DeUcsV0FBVztBQUFBLElBQ2I7QUFFQSxXQUFPZDtBQUFBQSxFQUNULEdBQUcsQ0FBQ04scUJBQXFCaEgsZUFBZXlELFlBQVksQ0FBQztBQUVyRCxRQUFNNEUsa0JBQW1EM0ssUUFBUSxNQUFNO0FBQ3JFLFFBQUksQ0FBQ3dEO0FBQWM7QUFFbkIsVUFBTW1ILG1CQUF1QztBQUFBLE1BQzNDbEYsTUFBTTtBQUFBLE1BQ05xRSxPQUFPO0FBQUEsTUFDUEMscUJBQXFCO0FBQUEsTUFDckJDLGNBQWM7QUFBQSxNQUNkQyxlQUFlO0FBQUEsTUFDZkMsY0FBYztBQUFBLE1BQ2RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxpQkFBaUI7QUFBQSxNQUNqQkcsZ0JBQWdCO0FBQUEsTUFDaEJELGVBQWU7QUFBQSxJQUNqQjtBQUVBLFdBQU9LO0FBQUFBLEVBQ1QsR0FBRyxDQUFDbkgsWUFBWSxDQUFDO0FBRWpCLFFBQU1vSCxtQkFBc0Q1SyxRQUFRLE1BQU07QUFDeEUsUUFBSSxDQUFDcUM7QUFBUyxhQUFPNEI7QUFDckIsVUFBTTRHLG1CQUEwQztBQUVoRCxRQUFJRixpQkFBaUI7QUFDbkJFLHVCQUFpQkMsS0FBS0gsZUFBZTtBQUFBLElBQ3ZDO0FBRUFFLHFCQUFpQkMsS0FBSyxHQUFHQyx1QkFBdUIxSSxPQUFPLENBQUM7QUFFeEQsUUFBSXVILGVBQWU7QUFDakJpQix1QkFBaUJDLEtBQUtsQixhQUFhO0FBQUEsSUFDckM7QUFFQWlCLHFCQUFpQkMsS0FBSztBQUN0QixXQUFPRDtBQUFBQSxFQUNULEdBQUcsQ0FBQ3hJLFNBQVN1SCxlQUFlZSxlQUFlLENBQUM7QUFFNUMsUUFBTUssc0JBQXNCbEwsWUFBWSxNQUFNO0FBQzVDLFFBQUk4QixRQUFRMkYsV0FBV2pFLGNBQWNXLFFBQVc7QUFDOUMsWUFBTWdILGFBQXVCO0FBQzdCLFlBQU1DLGNBQWN0SixRQUFRMkYsU0FBUzREO0FBQ3JDRCxrQkFBWUUsUUFBUSxDQUFDQyxLQUFLQyxVQUFVO0FBQ2xDLFlBQUloSSxXQUFXc0IsS0FBSzJHLFlBQVVBLE9BQU9DLE9BQU9ILElBQUlHLEVBQUUsR0FBRztBQUNuRFAscUJBQVdILEtBQUtRLEtBQUs7QUFBQSxRQUN2QjtBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU1HLFVBQVU3SixRQUFRMkYsUUFBUW1FLFFBQVEsS0FBSzlKLFFBQVEyRixRQUFRbUUsUUFBUSxFQUFFMUYsU0FBUztBQUVoRixVQUFJeUYsU0FBUztBQUNYN0osZ0JBQVEyRixRQUFRb0Usa0JBQWtCO0FBQ2xDL0osZ0JBQVEyRixRQUFRcUUsV0FBV1gsVUFBVTtBQUFBLE1BQ3ZDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDM0gsU0FBUyxDQUFDO0FBRWQsUUFBTXVJLFlBQVkvTCxZQUFZLE1BQU07QUFDbENrTCx3QkFBb0I7QUFFcEIsUUFBSXZIO0FBQWdCN0IsY0FBUTJGLFNBQVM5RCxlQUFlLEVBQUU7QUFBQSxFQUN4RCxHQUFHLENBQUNBLGdCQUFnQnVILG1CQUFtQixDQUFDO0FBRXhDakwsWUFBVSxNQUFNO0FBQ2QsUUFBSThCLE9BQU87QUFDVDZDLHVCQUFpQjdDLE1BQU1tRSxNQUFNO0FBQUEsSUFDL0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ25FLEtBQUssQ0FBQztBQUVWOUIsWUFBVSxNQUFNO0FBQ2QsUUFBSTBDLFlBQVk7QUFDZCtCLHlCQUFtQi9CLFVBQVU7QUFBQSxJQUMvQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxVQUFVLENBQUM7QUFFZixTQUNFLHVCQUFDLDBCQUNFcUQ7QUFBQUEsa0JBQWNTLGNBQWMsS0FDM0IsdUJBQUMsbUJBQ0U7QUFBQSxPQUFDckQsY0FBYyx1QkFBQyxXQUNmLFFBQVE7QUFBQSxRQUFFNEksVUFBVTtBQUFBLE1BQUUsR0FDdEIsS0FBS3hILE1BQU15SCxRQUFRQyxJQUVsQi9JLDBCQUFnQixLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLaEI7QUFBQSxNQUNBLHVCQUFDLG1CQUFnQixVQUFVMUMsU0FBU3FDLG9CQUFvQixHQUFHLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxTQVAvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVEK0IsYUFBYXRCLHVCQUF1QmhCLFdBQ25DLHVCQUFDLHlCQUNDLFNBQ0EsZUFBZWdCLHVCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFDO0FBQUEsSUFHdkMsdUJBQUMscUJBQ0MsaUJBQ0EsU0FDQSxhQUNBLFFBQVEsQ0FBQyxDQUFDYyxTQUVUaEI7QUFBQUEsaUJBQ0MsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFFZixDQUFDQSxZQUFhdEIsU0FBU0EsTUFBTW1FLFNBQVMsS0FBTTdCLFlBQVk7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUN4RCxRQUFPO0FBQUEsVUFDUCxZQUFZQSxVQUFVK0IsY0FBY0ssY0FBYztBQUFBLFVBQ2xELFNBQVN0RixpQkFBaUI0QyxtQkFBbUJDLFNBQVM7QUFBQSxVQUN0RDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUzhHO0FBQUFBLFVBQ1QsYUFBYTlJO0FBQUFBLFVBQ2I7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsZUFBZUU7QUFBQUEsVUFDZjtBQUFBLFVBQ0EsZUFBZUQ7QUFBQUEsVUFDZixnQkFBZ0I2QjtBQUFBQSxVQUNoQjtBQUFBLFVBQ0EsY0FBY2lDO0FBQUFBLFVBQ2Q7QUFBQSxVQUNBLGlCQUFpQndCO0FBQUFBLFVBQ2pCLGdCQUFnQlE7QUFBQUEsVUFDaEIsYUFBYUo7QUFBQUEsVUFDYixhQUFhTztBQUFBQSxVQUNiLGVBQWVPO0FBQUFBLFVBQ2YsZ0JBQWdCO0FBQUEsWUFBRWpELE1BQU07QUFBQSxVQUFTO0FBQUEsVUFDakM7QUFBQSxVQUNBLEtBQUsxRDtBQUFBQSxVQUNMO0FBQUEsVUFLQSxpQ0FBQyxVQUFPLFVBQ05aLGtCQUNFYyxXQUNBQyxZQUNBQyxXQUNBRSxXQUNBMEQsVUFDQUMsVUFDQUUsY0FDQUUsWUFDQXJDLGNBQ0FDLGlCQUNGLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQztBQUFBO0FBQUEsUUE5Q3NEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQStDekQ7QUFBQSxTQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsSUFDQyxDQUFDVixXQUFXdEIsU0FBU0EsTUFBTW1FLFdBQVcsS0FDckMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQjtBQUFBLElBRXJCLENBQUM3QixXQUFXckMsYUFBYVksZ0JBQWdCLHVCQUFDLHVCQUN6QyxnQkFBZ0IrQixlQUNoQixpQkFBaUJGLGlCQUNqQixjQUNBLHFCQUp3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUg7QUFBQSxPQXBGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNGQTtBQUVKO0FBQUM1QyxHQWhiUUYsVUFBUTtBQUFBLFVBOENEaEIsUUFBUTtBQUFBO0FBQUF3TCxLQTlDZnhLO0FBa2JULFNBQVNzSix1QkFBMEMxSSxTQUFrRDtBQUNuRyxTQUFPQSxRQUFRa0gsSUFBSTFFLFlBQVU7QUFDM0IsVUFBTXFILGVBQWVySCxPQUFPSyxVQUFVO0FBQ3RDLFVBQU1pSCxrQkFBa0J0SCxPQUFPdUgsWUFBWW5JLFNBQ3ZDWSxPQUFPdUgsVUFDUHZILE9BQU93SCxlQUFlLFFBQVE7QUFFbEMsVUFBTUMsbUJBQXdDO0FBQUEsTUFDNUNwQyxjQUFjckYsT0FBT2dCLFlBQVk7QUFBQSxNQUNqQ21FLGNBQWNuRixPQUFPbUYsZ0JBQWdCO0FBQUEsTUFDckNDLGVBQWVwRixPQUFPb0YsaUJBQWlCO0FBQUEsTUFDdkNFLGdCQUFnQnRGLE9BQU8wSCxjQUFjO0FBQUE7QUFBQSxNQUVyQ0MsVUFBVTtBQUFBLE1BQ1YzQyxZQUFZaEYsT0FBTzRIO0FBQUFBLE1BQ25CdkgsT0FBT0wsT0FBT0s7QUFBQUEsTUFDZE8sTUFBTVosT0FBT1k7QUFBQUEsTUFDYitFLFVBQVUzRixPQUFPNkg7QUFBQUEsTUFDakJDLFVBQVU5SCxPQUFPOEg7QUFBQUEsTUFDakJDLFVBQVUvSCxPQUFPK0gsWUFBWXBMO0FBQUFBLE1BQzdCMEssY0FBY3JILE9BQU9xSCxnQkFBZ0JBO0FBQUFBLE1BQ3JDcEMsT0FBT2pGLE9BQU9pRixTQUFTakYsT0FBTytILFlBQVlwTDtBQUFBQSxNQUMxQzRLLFNBQVNEO0FBQUFBLE1BQ1RPLFFBQVE3SCxPQUFPZ0k7QUFBQUEsTUFDZnhLLFNBQVN3QyxPQUFPeEMsVUFBVTBJLHVCQUF1QmxHLE9BQU94QyxPQUFPLElBQUk0QjtBQUFBQSxNQUNuRTZJLFVBQVVqSSxPQUFPaUk7QUFBQUEsTUFDakJwQyxXQUFXN0YsT0FBT2tJLFNBQVMsV0FBV2xJLE9BQU82RjtBQUFBQSxNQUM3Q3NDLGlCQUFpQm5JLE9BQU9tSTtBQUFBQSxNQUN4QkMsTUFBTXBJLE9BQU9vSTtBQUFBQSxNQUNiQyxpQkFBaUJySSxPQUFPcUk7QUFBQUEsTUFDeEJDLGlCQUFpQnRJLE9BQU9zSTtBQUFBQSxNQUN4QjNHLFlBQVkzQixPQUFPMkI7QUFBQUEsTUFDbkI0RyxRQUFRdkksT0FBT3VJLFVBQVUsQ0FBQztBQUFBLE1BQzFCQyxnQkFBZ0J4SSxPQUFPd0k7QUFBQUEsTUFDdkJDLG1CQUFtQnpJLE9BQU95STtBQUFBQSxJQUM1QjtBQUNBLFdBQU9oQjtBQUFBQSxFQUNULENBQUM7QUFDSDtBQUVBLGVBQWU3SztBQUFRLElBQUF3SztBQUFBc0IsYUFBQXRCLElBQUEiLCJuYW1lcyI6WyJnZXRWYWx1ZSIsIkluamVjdCIsIkdyaWRDb21wb25lbnQiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIkRhdGFHcmlkQ29udGFpbmVyIiwiRGF0YUdyaWRDb250cm9sU2VjdGlvbiIsIlNlYXJjaENvbnRhaW5lciIsIkRhdGFUYWJsZVNlYXJjaCIsImRlYm91bmNlIiwiSWNvbkJ1dHRvbiIsInVzZVRoZW1lIiwiRGlyZWN0aW9uYWxIaW50IiwiTG9hZGluZ1NjcmVlbiIsIkRhdGFUYWJsZVBhZ2luYXRpb24iLCJEYXRhVGFibGVFbXB0eVN0YXRlIiwiRmxleFJvdyIsIkRhdGFUYWJsZUZpbHRlckdyb3VwcyIsImJ1aWxkR3JpZFNlcnZpY2VzIiwiYnVpbGRHcmlkVG9vbGJhciIsIkRhdGFNYW5hZ2VyQWRhcHRvciIsIkRhdGFNYW5hZ2VyIiwicGFnZVNldHRpbmdzIiwicGFnZUNvdW50IiwicGFnZVNpemVzIiwiQ09NTUFORF9DT0xVTU5fRklFTEQiLCJNSU5fV0lEVEhfQ09MVU1OIiwiRGF0YUdyaWQiLCJwcm9wcyIsIl9zIiwiZ3JpZFJlZiIsIml0ZW1zIiwicGFnaW5hdGVkIiwicmVzaXplYWJsZSIsImdyb3VwYWJsZSIsImZyZWV6YWJsZSIsImFnZ3JlZ2F0ZSIsImVkaXRTZXR0aW5ncyIsImdyb3VwU2V0dGluZ3MiLCJjb2x1bW5zIiwic2luZ2xlQWN0aW9ucyIsImFnZ3JlZ2F0ZXMiLCJzb3J0Q29uZmlnIiwiaXRlbXNDb3VudCIsIm9uUGFnZUNoYW5nZSIsIm9uU29ydENoYW5nZSIsIm9uU2VhcmNoVGV4dENoYW5nZSIsImNvbXBhY3QiLCJvblJvd0NoYW5nZWQiLCJncm91cEVycm9ycyIsIm1lbnVPcHRpb25zIiwicmVuZGVyQWN0aW9ucyIsImhpZGRlbk1lbnUiLCJsb2FkaW5nIiwiY3VzdG9tUGFnZU9wdGlvbnMiLCJvbkZpbHRlckdyb3VwQ2hhbmdlIiwic2VsZWN0aW9uIiwib25TZWxlY3Rpb24iLCJoYXNTZWxlY3Rpb24iLCJhdXRvRml0Q29sdW1ucyIsIm9uTWVudU9wZW5lZCIsIm9uTWVudURpc21pc3NlZCIsImlzRmlsdGVyYWJsZSIsInNob3dDb2x1bW5DaG9vc2VyIiwiaGFzU2VhcmNoIiwib25MYXN0U2VsZWN0aW9uIiwiaGVpZ2h0IiwidW5kZWZpbmVkIiwicXVlcnkiLCJkYXRhVXJsIiwic2VhcmNoU2V0dGluZ3MiLCJpc0RldGFpbGluZ01vZGUiLCJ0aGVtZSIsIml0ZW1zQ291bnRDYWNoZSIsInNldEl0ZW1zQ291bnRDYWNoZSIsInBhZ2VTaXplQ2FjaGUiLCJzZXRQYWdlU2l6ZUNhY2hlIiwiaGFzRmlsdGVyIiwic29tZSIsImNvbHVtbiIsImZpbHRlck9wdGlvbnMiLCJpc0dyb3VwTW9kZSIsInNvcnRTZXR0aW5ncyIsImFsbG93VW5zb3J0IiwiZmllbGQiLCJkaXJlY3Rpb24iLCJkZXNjZW5kaW5nIiwic2VsZWN0aW9uU2V0dGluZ3MiLCJtb2RlIiwicGVyc2lzdFNlbGVjdGlvbiIsImNoZWNrYm94TW9kZSIsInR5cGUiLCJjaGVja2JveE9ubHkiLCJmaWx0ZXJTZXR0aW5ncyIsImVkaXRhYmxlIiwic29ydGFibGUiLCJzZWFyY2hhYmxlIiwiaGFzTWVudUl0ZW1zIiwibGVuZ3RoIiwiZnJvemVuYWJsZSIsImRhdGFNYW5hZ2VyIiwidXJsIiwiYWRhcHRvciIsImNyb3NzRG9tYWluIiwidGltZVRpbGxFeHBpcmF0aW9uIiwiZ2V0RGF0YVNvdXJjZSIsImRhdGFTb3VyY2UiLCJyZXN1bHQiLCJjb3VudCIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJzdGF0ZSIsImNvbmZpZyIsIml0ZW1zU2tpcHBlZCIsInNraXAiLCJwYWdlU2l6ZSIsInRha2UiLCJoYW5kbGVTb3J0Q2hhbmdlIiwiYWN0aW9uIiwiY29sdW1uTmFtZSIsImhhbmRsZVN0YXRlQ2hhbmdlIiwicmVxdWVzdFR5cGUiLCJjdXJyZW50IiwiaGlkZVNwaW5uZXIiLCJoYW5kbGVBY3Rpb25CZWdpbiIsImFyZ3MiLCJyb3dEYXRhIiwiY2FuY2VsIiwiaGFuZGxlQWN0aW9uQ29tcGxldGUiLCJkYXRhIiwib3B0aW9ucyIsInNlbGVjdGVkIiwiaXNJbnRlcmFjdGVkIiwiYWxsU2VsZWN0ZWQiLCJnZXRTZWxlY3RlZFJlY29yZHMiLCJBcnJheSIsImlzQXJyYXkiLCJpc0hlYWRlckNoZWNrYm94Q2xpY2tlZCIsImRlc2VsZWN0ZWQiLCJyZW5kZXJNZW51T3B0aW9ucyIsImNoYW5nZU1lbnVPcGVuZWQiLCJjaGFuZ2VNZW51RGlzbWlzc2VkIiwibWVudVByb3BzIiwiaXRlbSIsImRpcmVjdGlvbmFsSGludCIsImJvdHRvbVJpZ2h0RWRnZSIsImljb25OYW1lIiwiY29sb3IiLCJjb2xvcnMiLCJwcmltYXJ5Iiwicm9vdEhvdmVyZWQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJncmF5IiwicmVuZGVyQWN0aW9uQnV0dG9ucyIsIm1hcCIsIm9uSGlkZGVuQnV0dG9uV2hlbiIsImFsbG93RGVsZXRpbmciLCJkZXNjcmlwdGlvbiIsIm9uQ2xpY2siLCJjb21tYW5kQ29sdW1uIiwiaGVhZGVyVGV4dCIsIndpZHRoIiwic2hvd0luQ29sdW1uQ2hvb3NlciIsImFsbG93RWRpdGluZyIsImFsbG93UmVzaXppbmciLCJhbGxvd1NvcnRpbmciLCJhbGxvd0ZpbHRlcmluZyIsImFsbG93UmVvcmRlcmluZyIsImVkaXRUZW1wbGF0ZSIsImFsbG93R3JvdXBpbmciLCJhbGxvd1NlYXJjaGluZyIsInRlbXBsYXRlIiwiZnJlZXplIiwidGV4dEFsaWduIiwic2VsZWN0aW9uQ29sdW1uIiwiY29sdW1uc0Zvcm1hdHRlZCIsImZvcm1hdHRlZENvbHVtbnMiLCJwdXNoIiwiY29udmVydENvbHVtbnNUb0Zvcm1hdCIsImdldFNlbGVjdGlvbkluZGV4ZXMiLCJyb3dJbmRleGVzIiwiY3VycmVudERhdGEiLCJjdXJyZW50Vmlld0RhdGEiLCJmb3JFYWNoIiwicm93IiwiaW5kZXgiLCJzZWxlY3QiLCJpZCIsImhhc0RhdGEiLCJnZXRSb3dzIiwiY2xlYXJSb3dTZWxlY3Rpb24iLCJzZWxlY3RSb3dzIiwiZGF0YUJvdW5kIiwiZmxleEdyb3ciLCJzcGFjaW5nIiwibGciLCJfYyIsImlzUHJpbWFyeUtleSIsImlzQ29sdW1uVmlzaWJsZSIsInZpc2libGUiLCJibG9ja1Nob3dpbmciLCJ0cmFuc2xhdGVkQ29sdW1uIiwiZmlsdGVyYWJsZSIsImNsaXBNb2RlIiwiaGVhZGVyIiwiZm9ybWF0IiwibWF4V2lkdGgiLCJtaW5XaWR0aCIsImZvcm1hdENvbmZpZyIsImVkaXRUeXBlIiwiY2VudGVyIiwidmFsaWRhdGlvblJ1bGVzIiwiZWRpdCIsImZvcmVpZ25LZXlWYWx1ZSIsImZvcmVpZ25LZXlGaWVsZCIsImZpbHRlciIsImZpbHRlclRlbXBsYXRlIiwiZmlsdGVyQmFyVGVtcGxhdGUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhR3JpZC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kYXRhdGFibGUvRGF0YUdyaWQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0VmFsdWUgfSBmcm9tICdAc3luY2Z1c2lvbi9lajItYmFzZSdcclxuaW1wb3J0IHtcclxuICBJbmplY3QsXHJcbiAgR3JvdXBTZXR0aW5nc01vZGVsLFxyXG4gIEVkaXRTZXR0aW5nc01vZGVsLFxyXG4gIEdyaWRDb21wb25lbnQsXHJcbiAgUGFnZVNldHRpbmdzTW9kZWwsXHJcbiAgRGF0YVN0YXRlQ2hhbmdlRXZlbnRBcmdzLFxyXG4gIFNvcnRTZXR0aW5nc01vZGVsLFxyXG4gIEFnZ3JlZ2F0ZVJvd01vZGVsLFxyXG4gIFNvcnRFdmVudEFyZ3MsXHJcbiAgU2VsZWN0aW9uU2V0dGluZ3NNb2RlbCxcclxuICBHcmlkQ29sdW1uTW9kZWwsXHJcbiAgUm93U2VsZWN0RXZlbnRBcmdzLFxyXG4gIFJvd0Rlc2VsZWN0RXZlbnRBcmdzLFxyXG4gIERhdGFSZXN1bHQsXHJcbiAgRmlsdGVyU2V0dGluZ3NNb2RlbCxcclxuICBTZWFyY2hTZXR0aW5nc01vZGVsLFxyXG59IGZyb20gJ0BzeW5jZnVzaW9uL2VqMi1yZWFjdC1ncmlkcydcclxuaW1wb3J0IHsgUmVhY3RFbGVtZW50LCBSZWFjdE5vZGUsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEVudGl0eSBmcm9tICcuLi8uLi8uLi9kb21haW4vRW50aXR5J1xyXG5pbXBvcnQgeyBEYXRhR3JpZENvbnRhaW5lciwgRGF0YUdyaWRDb250cm9sU2VjdGlvbiwgU2VhcmNoQ29udGFpbmVyIH0gZnJvbSAnLi9EYXRhR3JpZC5zdHlsZSdcclxuaW1wb3J0IHsgQ29sdW1uVGVtcGxhdGVQcm9wcywgRGF0YUdyaWRBY3Rpb25FdmVudEFyZ3MsIERhdGFHcmlkQ29sdW1uTW9kZWwsIERhdGFHcmlkU2luZ2xlQWN0aW9uTW9kZWwsIERhdGFUYWJsZUNvbHVtbiwgRGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZywgRGF0YVRhYmxlU29ydENvbmZpZywgT25Sb3dDaGFuZ2VkT3B0aW9ucyB9IGZyb20gJy4vdHlwZXMnXHJcbmltcG9ydCBEYXRhVGFibGVTZWFyY2ggZnJvbSAnLi9EYXRhVGFibGVTZWFyY2gnXHJcbmltcG9ydCB7IGRlYm91bmNlIH0gZnJvbSAnbG9kYXNoLWVzJ1xyXG5pbXBvcnQgeyBJY29uQnV0dG9uIH0gZnJvbSAnLi4vYnV0dG9ucydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IHsgRGlyZWN0aW9uYWxIaW50LCBJQ29tYm9Cb3hPcHRpb24sIElDb250ZXh0dWFsTWVudUl0ZW0sIElDb250ZXh0dWFsTWVudVByb3BzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnLi4vbG9hZGluZ1NjcmVlbidcclxuaW1wb3J0IERhdGFUYWJsZVBhZ2luYXRpb24gZnJvbSAnLi9EYXRhVGFibGVQYWdpbmF0aW9uJ1xyXG5pbXBvcnQgRGF0YVRhYmxlRW1wdHlTdGF0ZSBmcm9tICcuL0RhdGFUYWJsZUVtcHR5U3RhdGUnXHJcbmltcG9ydCB7IEZsZXhSb3cgfSBmcm9tICcuLi9GbGV4Qm94J1xyXG5pbXBvcnQgeyBJRmlsdGVyR3JvdXAgfSBmcm9tICcuLi9maWx0ZXIvdHlwZXMnXHJcbmltcG9ydCBEYXRhVGFibGVGaWx0ZXJHcm91cHMgZnJvbSAnLi9EYXRhVGFibGVGaWx0ZXJHcm91cHMnXHJcbmltcG9ydCB7IGJ1aWxkR3JpZFNlcnZpY2VzLCBidWlsZEdyaWRUb29sYmFyIH0gZnJvbSAnLi91dGlscydcclxuaW1wb3J0IHsgRGF0YU1hbmFnZXJBZGFwdG9yIH0gZnJvbSAnLi4vLi4vYXBpL0RhdGFNYW5hZ2VyQWRhcHRvcidcclxuaW1wb3J0IHsgRGF0YU1hbmFnZXIsIFF1ZXJ5IH0gZnJvbSAnQHN5bmNmdXNpb24vZWoyLWRhdGEvc3JjJ1xyXG5cclxuaW50ZXJmYWNlIERhdGFHcmlkUHJvcHM8VCBleHRlbmRzIEVudGl0eT57XHJcbiAgaXRlbXM/OiBUW11cclxuICBjb2x1bW5zPzogRGF0YVRhYmxlQ29sdW1uPFQ+W11cclxuICBwYWdpbmF0ZWQ/OiBib29sZWFuXHJcbiAgcmVzaXplYWJsZT86IGJvb2xlYW5cclxuICBncm91cGFibGU/OiBib29sZWFuXHJcbiAgYWdncmVnYXRlPzogYm9vbGVhblxyXG4gIGZyZWV6YWJsZT86IGJvb2xlYW5cclxuICBzaW5nbGVBY3Rpb25zPzogRGF0YUdyaWRTaW5nbGVBY3Rpb25Nb2RlbDxUPltdXHJcbiAgYWdncmVnYXRlcz86IEFnZ3JlZ2F0ZVJvd01vZGVsW11cclxuICBlZGl0U2V0dGluZ3M/OiBFZGl0U2V0dGluZ3NNb2RlbFxyXG4gIGdyb3VwU2V0dGluZ3M/OiBHcm91cFNldHRpbmdzTW9kZWxcclxuICBpdGVtc0NvdW50PzogbnVtYmVyXHJcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGVcclxuICBvblBhZ2VDaGFuZ2U/OiAoY29uZmlnOiBEYXRhVGFibGVQYWdpbmF0aW9uQ29uZmlnKSA9PiB2b2lkXHJcbiAgc29ydENvbmZpZz86IERhdGFUYWJsZVNvcnRDb25maWdcclxuICBvblNvcnRDaGFuZ2U/OiAoY29uZmlnOiBEYXRhVGFibGVTb3J0Q29uZmlnKSA9PiB2b2lkXHJcbiAgbG9hZGluZz86IGJvb2xlYW5cclxuICBvblNlYXJjaFRleHRDaGFuZ2U/OiAodGV4dDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgY29tcGFjdD86IGJvb2xlYW5cclxuICBvblJvd0NoYW5nZWQ/OiAoZGF0YTogVCwgb3B0aW9ucz86IE9uUm93Q2hhbmdlZE9wdGlvbnM8VD4pID0+IHZvaWRcclxuICByb3dUZW1wbGF0ZT86IChwcm9wczogdW5rbm93bikgPT4gdW5rbm93bjtcclxuICBncm91cEVycm9ycz86IHN0cmluZ1tdXHJcbiAgbWVudU9wdGlvbnM/OiAoaXRlbTogVCkgPT4gSUNvbnRleHR1YWxNZW51SXRlbVtdXHJcbiAgY3VzdG9tUGFnZU9wdGlvbnM/OiBJQ29tYm9Cb3hPcHRpb25bXVxyXG4gIHJlbmRlckFjdGlvbnM/OiAoKSA9PiBSZWFjdEVsZW1lbnRcclxuICBoaWRkZW5NZW51PzogYm9vbGVhblxyXG4gIG9uRmlsdGVyR3JvdXBDaGFuZ2U/OiAoZmlsdGVyR3JvdXBzOiBJRmlsdGVyR3JvdXBbXSkgPT4gdm9pZFxyXG4gIGhhc1NlbGVjdGlvbj86IGJvb2xlYW5cclxuICBzZWxlY3Rpb24/OiBUW11cclxuICBvblNlbGVjdGlvbj86IChzZWxlY3Rpb246IFRbXSkgPT4gdm9pZFxyXG4gIG9uTGFzdFNlbGVjdGlvbj86IChpdGVtOiBUW10sIGlzU2VsZWN0ZWQ/OiBib29sZWFuLCBpc0hlYWRlckNsaWNrPzogYm9vbGVhbikgPT4gdm9pZFxyXG4gIGF1dG9GaXRDb2x1bW5zPzogYm9vbGVhblxyXG4gIG9uTWVudU9wZW5lZD86IChpdGVtOiBUKSA9PiB2b2lkXHJcbiAgb25NZW51RGlzbWlzc2VkPzogKGl0ZW0/OiBUKSA9PiB2b2lkXHJcbiAgaXNGaWx0ZXJhYmxlPzogYm9vbGVhblxyXG4gIHNob3dDb2x1bW5DaG9vc2VyPzogYm9vbGVhblxyXG4gIGhhc1NlYXJjaD86IGJvb2xlYW5cclxuICBkYXRhVXJsPzogc3RyaW5nXHJcbiAgaGVpZ2h0PzogbnVtYmVyXHJcbiAgcXVlcnk/OiBRdWVyeVxyXG4gIHNlYXJjaFNldHRpbmdzPzogU2VhcmNoU2V0dGluZ3NNb2RlbFxyXG4gIGlzRGV0YWlsaW5nTW9kZT86IGJvb2xlYW5cclxufVxyXG5cclxuY29uc3QgcGFnZVNldHRpbmdzOiBQYWdlU2V0dGluZ3NNb2RlbCA9IHtcclxuICBwYWdlQ291bnQ6IDUsXHJcbiAgcGFnZVNpemVzOiBbMTIsIDI1LCA1MF0sXHJcbn1cclxuY29uc3QgQ09NTUFORF9DT0xVTU5fRklFTEQgPSAnI19tZW51J1xyXG5jb25zdCBNSU5fV0lEVEhfQ09MVU1OID0gMTcwXHJcblxyXG5mdW5jdGlvbiBEYXRhR3JpZDxUIGV4dGVuZHMgRW50aXR5PiAocHJvcHM6RGF0YUdyaWRQcm9wczxUPik6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgZ3JpZFJlZiA9IHVzZVJlZjxHcmlkQ29tcG9uZW50PihudWxsKVxyXG5cclxuICBjb25zdCB7XHJcbiAgICBpdGVtcyxcclxuICAgIHBhZ2luYXRlZCxcclxuICAgIHJlc2l6ZWFibGUsXHJcbiAgICBncm91cGFibGUsXHJcbiAgICBmcmVlemFibGUsXHJcbiAgICBhZ2dyZWdhdGUsXHJcbiAgICBlZGl0U2V0dGluZ3MsXHJcbiAgICBncm91cFNldHRpbmdzLFxyXG4gICAgY29sdW1ucyxcclxuICAgIHNpbmdsZUFjdGlvbnMsXHJcbiAgICBhZ2dyZWdhdGVzLFxyXG4gICAgc29ydENvbmZpZyxcclxuICAgIGl0ZW1zQ291bnQsXHJcbiAgICBvblBhZ2VDaGFuZ2UsXHJcbiAgICBvblNvcnRDaGFuZ2UsXHJcbiAgICBvblNlYXJjaFRleHRDaGFuZ2UsXHJcbiAgICBjb21wYWN0ID0gdHJ1ZSxcclxuICAgIG9uUm93Q2hhbmdlZCxcclxuICAgIGdyb3VwRXJyb3JzLFxyXG4gICAgbWVudU9wdGlvbnMsXHJcbiAgICByZW5kZXJBY3Rpb25zLFxyXG4gICAgaGlkZGVuTWVudSxcclxuICAgIGxvYWRpbmcsXHJcbiAgICBjdXN0b21QYWdlT3B0aW9ucyxcclxuICAgIG9uRmlsdGVyR3JvdXBDaGFuZ2UsXHJcbiAgICBzZWxlY3Rpb24sXHJcbiAgICBvblNlbGVjdGlvbixcclxuICAgIGhhc1NlbGVjdGlvbixcclxuICAgIGF1dG9GaXRDb2x1bW5zLFxyXG4gICAgb25NZW51T3BlbmVkLFxyXG4gICAgb25NZW51RGlzbWlzc2VkLFxyXG4gICAgaXNGaWx0ZXJhYmxlLFxyXG4gICAgc2hvd0NvbHVtbkNob29zZXIsXHJcbiAgICBoYXNTZWFyY2gsXHJcbiAgICBvbkxhc3RTZWxlY3Rpb24sXHJcbiAgICBoZWlnaHQgPSB1bmRlZmluZWQsXHJcbiAgICBxdWVyeSxcclxuICAgIGRhdGFVcmwsXHJcbiAgICBzZWFyY2hTZXR0aW5ncyxcclxuICAgIGlzRGV0YWlsaW5nTW9kZSxcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcblxyXG4gIGNvbnN0IFtpdGVtc0NvdW50Q2FjaGUsIHNldEl0ZW1zQ291bnRDYWNoZV0gPSB1c2VTdGF0ZSgwKVxyXG4gIGNvbnN0IFtwYWdlU2l6ZUNhY2hlLCBzZXRQYWdlU2l6ZUNhY2hlXSA9IHVzZVN0YXRlKDApXHJcbiAgY29uc3QgaGFzRmlsdGVyID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gISFjb2x1bW5zICYmIGNvbHVtbnMuc29tZShjb2x1bW4gPT4gY29sdW1uLmZpbHRlck9wdGlvbnM/LmlzR3JvdXBNb2RlKVxyXG4gIH0sIFtjb2x1bW5zLCBpdGVtc10pXHJcblxyXG4gIGNvbnN0IHNvcnRTZXR0aW5ncyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFzb3J0Q29uZmlnKSByZXR1cm4gdW5kZWZpbmVkXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBhbGxvd1Vuc29ydDogZmFsc2UsXHJcbiAgICAgIGNvbHVtbnM6IFt7IGZpZWxkOiBzb3J0Q29uZmlnPy5maWVsZCwgZGlyZWN0aW9uOiBzb3J0Q29uZmlnPy5kZXNjZW5kaW5nID8gJ0Rlc2NlbmRpbmcnIDogJ0FzY2VuZGluZycgfV0sXHJcbiAgICB9IGFzIFNvcnRTZXR0aW5nc01vZGVsXHJcbiAgfSwgW3NvcnRDb25maWddKVxyXG5cclxuICBjb25zdCBzZWxlY3Rpb25TZXR0aW5nczogU2VsZWN0aW9uU2V0dGluZ3NNb2RlbCA9IHtcclxuICAgIG1vZGU6ICdSb3cnLFxyXG4gICAgcGVyc2lzdFNlbGVjdGlvbjogZmFsc2UsXHJcbiAgICBjaGVja2JveE1vZGU6ICdEZWZhdWx0JyxcclxuICAgIHR5cGU6ICdNdWx0aXBsZScsXHJcbiAgICBjaGVja2JveE9ubHk6IHRydWUsXHJcbiAgfVxyXG5cclxuICBjb25zdCBmaWx0ZXJTZXR0aW5nczogRmlsdGVyU2V0dGluZ3NNb2RlbCA9IHtcclxuICAgIHR5cGU6ICdFeGNlbCcsXHJcbiAgfVxyXG5cclxuICBjb25zdCBlZGl0YWJsZSA9IGVkaXRTZXR0aW5ncyAhPT0gdW5kZWZpbmVkXHJcbiAgY29uc3Qgc29ydGFibGUgPSBzb3J0U2V0dGluZ3MgIT09IHVuZGVmaW5lZFxyXG4gIGNvbnN0IHNlYXJjaGFibGUgPSAhIW9uU2VhcmNoVGV4dENoYW5nZVxyXG4gIGNvbnN0IGhhc01lbnVJdGVtcyA9IChtZW51T3B0aW9ucyAmJiBtZW51T3B0aW9ucz8ubGVuZ3RoICE9PSAwKSB8fFxyXG4gIChzaW5nbGVBY3Rpb25zICYmIHNpbmdsZUFjdGlvbnM/Lmxlbmd0aCAhPT0gMClcclxuICBjb25zdCBmcm96ZW5hYmxlID0gZnJlZXphYmxlIHx8IGhhc01lbnVJdGVtc1xyXG5cclxuICBjb25zdCBkYXRhTWFuYWdlciA9IG5ldyBEYXRhTWFuYWdlcih7XHJcbiAgICB1cmw6IGRhdGFVcmwgPz8gJycsXHJcbiAgICBhZGFwdG9yOiBuZXcgRGF0YU1hbmFnZXJBZGFwdG9yKCksXHJcbiAgICBjcm9zc0RvbWFpbjogdHJ1ZSxcclxuICAgIHRpbWVUaWxsRXhwaXJhdGlvbjogNjAwMDAsXHJcbiAgfSlcclxuXHJcbiAgY29uc3QgZ2V0RGF0YVNvdXJjZSA9IHVzZUNhbGxiYWNrKCgpOiBEYXRhUmVzdWx0IHwgVFtdIHwgRGF0YU1hbmFnZXIgPT4ge1xyXG4gICAgbGV0IGRhdGFTb3VyY2U6IERhdGFSZXN1bHQgfCBUW11cclxuICAgIGlmIChpdGVtc0NvdW50KSB7XHJcbiAgICAgIGRhdGFTb3VyY2UgPSB7XHJcbiAgICAgICAgcmVzdWx0OiBpdGVtcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdLFxyXG4gICAgICAgIGNvdW50OiBpdGVtc0NvdW50LFxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkYXRhU291cmNlID0gaXRlbXMgfHwgW11cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZGF0YVNvdXJjZVxyXG4gIH0sIFtpdGVtcywgaXRlbXNDb3VudF0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSB1c2VDYWxsYmFjaygoc3RhdGU6IERhdGFTdGF0ZUNoYW5nZUV2ZW50QXJncykgPT4ge1xyXG4gICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICBpdGVtc1NraXBwZWQ6IHN0YXRlLnNraXAgYXMgbnVtYmVyLFxyXG4gICAgICBwYWdlU2l6ZTogc3RhdGUudGFrZSBhcyBudW1iZXIsXHJcbiAgICB9XHJcbiAgICBpZiAob25QYWdlQ2hhbmdlKSB7XHJcbiAgICAgIG9uUGFnZUNoYW5nZShjb25maWcpXHJcbiAgICB9XHJcbiAgfSwgW29uUGFnZUNoYW5nZV0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZVNvcnRDaGFuZ2UgPSB1c2VDYWxsYmFjaygoYWN0aW9uOiBTb3J0RXZlbnRBcmdzKSA9PiB7XHJcbiAgICBjb25zdCBjb25maWc6IERhdGFUYWJsZVNvcnRDb25maWcgPSB7XHJcbiAgICAgIGRlc2NlbmRpbmc6IGFjdGlvbi5kaXJlY3Rpb24gPT09ICdEZXNjZW5kaW5nJyxcclxuICAgICAgZmllbGQ6IGFjdGlvbi5jb2x1bW5OYW1lIGFzIHN0cmluZyxcclxuICAgIH1cclxuXHJcbiAgICBpZiAob25Tb3J0Q2hhbmdlKSB7XHJcbiAgICAgIG9uU29ydENoYW5nZShjb25maWcpXHJcbiAgICB9XHJcbiAgfSwgW29uU29ydENoYW5nZSwgc29ydFNldHRpbmdzXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlU3RhdGVDaGFuZ2UgPSB1c2VDYWxsYmFjaygoc3RhdGU6IERhdGFTdGF0ZUNoYW5nZUV2ZW50QXJncykgPT4ge1xyXG4gICAgc3dpdGNoIChzdGF0ZS5hY3Rpb24/LnJlcXVlc3RUeXBlKSB7XHJcbiAgICAgIGNhc2UgJ3JlZnJlc2gnOiB7XHJcbiAgICAgICAgZ3JpZFJlZi5jdXJyZW50Py5oaWRlU3Bpbm5lcigpXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgICBjYXNlICdwYWdpbmcnOlxyXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2Uoc3RhdGUpXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAnc29ydGluZyc6XHJcbiAgICAgICAgaGFuZGxlU29ydENoYW5nZShzdGF0ZT8uYWN0aW9uIGFzIFNvcnRFdmVudEFyZ3MpXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuICB9LCBbaGFuZGxlUGFnZUNoYW5nZSwgaGFuZGxlU29ydENoYW5nZV0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUFjdGlvbkJlZ2luID0gdXNlQ2FsbGJhY2soKGFyZ3M6IERhdGFHcmlkQWN0aW9uRXZlbnRBcmdzPFQ+KSA9PiB7XHJcbiAgICBzd2l0Y2ggKGFyZ3MucmVxdWVzdFR5cGUpIHtcclxuICAgICAgY2FzZSAnYmVnaW5FZGl0JzpcclxuICAgICAgICBpZiAoZ2V0VmFsdWUoJ2lzRW1wdHknLCBhcmdzLnJvd0RhdGEpID09PSB0cnVlKSB7XHJcbiAgICAgICAgICBhcmdzLmNhbmNlbCA9IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQWN0aW9uQ29tcGxldGUgPSB1c2VDYWxsYmFjaygoc3RhdGU6IERhdGFHcmlkQWN0aW9uRXZlbnRBcmdzPFQ+KSA9PiB7XHJcbiAgICBjb25zdCB7IGRhdGEsIC4uLm9wdGlvbnMgfSA9IHN0YXRlXHJcblxyXG4gICAgc3dpdGNoIChzdGF0ZS5hY3Rpb24pIHtcclxuICAgICAgY2FzZSAnZWRpdCc6XHJcbiAgICAgICAgaWYgKGRhdGEgJiYgb25Sb3dDaGFuZ2VkKSB7XHJcbiAgICAgICAgICBvblJvd0NoYW5nZWQoZGF0YSwgb3B0aW9ucylcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuICB9LCBbb25Sb3dDaGFuZ2VkXSlcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWQgPSB1c2VDYWxsYmFjaygoYXJnczogUm93U2VsZWN0RXZlbnRBcmdzKSA9PiB7XHJcbiAgICBpZiAoIWFyZ3MuaXNJbnRlcmFjdGVkKSByZXR1cm5cclxuXHJcbiAgICBjb25zdCBhbGxTZWxlY3RlZCA9IGdyaWRSZWYuY3VycmVudD8uZ2V0U2VsZWN0ZWRSZWNvcmRzKCkgYXMgVFtdXHJcbiAgICBvblNlbGVjdGlvbj8uKGFsbFNlbGVjdGVkKVxyXG5cclxuICAgIGNvbnN0IGRhdGE6IFRbXSA9IEFycmF5LmlzQXJyYXkoYXJncy5kYXRhKSA/IGFyZ3MuZGF0YSBhcyBUW10gOiBbYXJncy5kYXRhIGFzIFRdXHJcbiAgICBvbkxhc3RTZWxlY3Rpb24/LihkYXRhLCB0cnVlLCBhcmdzLmlzSGVhZGVyQ2hlY2tib3hDbGlja2VkKVxyXG4gIH0sIFtvbkxhc3RTZWxlY3Rpb24sIG9uU2VsZWN0aW9uXSlcclxuXHJcbiAgY29uc3QgZGVzZWxlY3RlZCA9IHVzZUNhbGxiYWNrKChhcmdzOiBSb3dEZXNlbGVjdEV2ZW50QXJncykgPT4ge1xyXG4gICAgaWYgKCFhcmdzLmlzSW50ZXJhY3RlZCkgcmV0dXJuXHJcblxyXG4gICAgY29uc3QgYWxsU2VsZWN0ZWQgPSBncmlkUmVmLmN1cnJlbnQ/LmdldFNlbGVjdGVkUmVjb3JkcygpIGFzIFRbXVxyXG4gICAgb25TZWxlY3Rpb24/LihhbGxTZWxlY3RlZClcclxuXHJcbiAgICBjb25zdCBkYXRhOiBUW10gPSBBcnJheS5pc0FycmF5KGFyZ3MuZGF0YSkgPyBhcmdzLmRhdGEgYXMgVFtdIDogW2FyZ3MuZGF0YSBhcyBUXVxyXG4gICAgb25MYXN0U2VsZWN0aW9uPy4oZGF0YSwgZmFsc2UsIGFyZ3MuaXNIZWFkZXJDaGVja2JveENsaWNrZWQpXHJcbiAgfSwgW29uTGFzdFNlbGVjdGlvbiwgb25TZWxlY3Rpb25dKVxyXG5cclxuICBjb25zdCByZW5kZXJNZW51T3B0aW9ucyA9IChhcmdzOiBDb2x1bW5UZW1wbGF0ZVByb3BzICYgVCwgbWVudU9wdGlvbnM6ICgoaXRlbTogVCkgPT4gSUNvbnRleHR1YWxNZW51SXRlbVtdKSB8IHVuZGVmaW5lZCkgPT4ge1xyXG4gICAgY29uc3QgY2hhbmdlTWVudU9wZW5lZCA9ICgpID0+IHtcclxuICAgICAgaWYgKG9uTWVudU9wZW5lZCkgb25NZW51T3BlbmVkKGFyZ3MpXHJcbiAgICB9XHJcbiAgICBjb25zdCBjaGFuZ2VNZW51RGlzbWlzc2VkID0gKCkgPT4ge1xyXG4gICAgICBpZiAob25NZW51RGlzbWlzc2VkKSBvbk1lbnVEaXNtaXNzZWQoYXJncylcclxuICAgIH1cclxuICAgIGNvbnN0IG1lbnVQcm9wcyA9IChpdGVtOiBUKTogSUNvbnRleHR1YWxNZW51UHJvcHMgPT4gKHtcclxuICAgICAgaXRlbXM6IG1lbnVPcHRpb25zPy4oaXRlbSkgPz8gW10sXHJcbiAgICAgIGRpcmVjdGlvbmFsSGludDogRGlyZWN0aW9uYWxIaW50LmJvdHRvbVJpZ2h0RWRnZSxcclxuICAgICAgb25NZW51T3BlbmVkOiBjaGFuZ2VNZW51T3BlbmVkLFxyXG4gICAgICBvbk1lbnVEaXNtaXNzZWQ6IGNoYW5nZU1lbnVEaXNtaXNzZWQsXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgbWVudVByb3BzPXttZW51UHJvcHMoYXJncyl9XHJcbiAgICAgICAga2V5PSdtZW51J1xyXG4gICAgICAgIGFyaWFEZXNjcmlwdGlvbj0nT3DDp8O1ZXMnXHJcbiAgICAgICAgb25SZW5kZXJNZW51SWNvbj17KCkgPT4gPD48Lz59XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ01vcmUnLFxyXG4gICAgICAgICAgY29sb3I6IHRoZW1lLmNvbG9ycy5wcmltYXJ5LFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICByb290SG92ZXJlZDoge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbG9ycy5ncmF5WzMwMF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjb25zdCByZW5kZXJBY3Rpb25CdXR0b25zID0gdXNlQ2FsbGJhY2soKGFyZ3M6IENvbHVtblRlbXBsYXRlUHJvcHMgJiBUKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIHttZW51T3B0aW9ucyAhPT0gdW5kZWZpbmVkICYmIG1lbnVPcHRpb25zLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICByZW5kZXJNZW51T3B0aW9ucyhhcmdzLCBtZW51T3B0aW9ucylcclxuICAgICAgICB9XHJcbiAgICAgICAgeyEhc2luZ2xlQWN0aW9ucyAmJiBzaW5nbGVBY3Rpb25zLm1hcChhY3Rpb24gPT4ge1xyXG4gICAgICAgICAgaWYgKGFjdGlvbi5vbkhpZGRlbkJ1dHRvbldoZW4gIT09IHVuZGVmaW5lZCAmJiBhY3Rpb24ub25IaWRkZW5CdXR0b25XaGVuKGFyZ3MpKSByZXR1cm4gPGRpdiBrZXk9e2FjdGlvbi50eXBlfT48L2Rpdj5cclxuICAgICAgICAgIGlmICghZWRpdFNldHRpbmdzPy5hbGxvd0RlbGV0aW5nKSByZXR1cm4gPD48Lz5cclxuXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICAgIGtleT17YWN0aW9uLnR5cGV9XHJcbiAgICAgICAgICAgICAgYXJpYURlc2NyaXB0aW9uPXthY3Rpb24udHlwZSA9PT0gJ2VkaXQnID8gJ0FsdGVyYXInIDogJ0V4Y2x1aXInfVxyXG4gICAgICAgICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgICAgICAgaWNvbk5hbWU6IGFjdGlvbi50eXBlID09PSAnZWRpdCcgPyAncGVuJyA6ICd0cmFzaCcsXHJcbiAgICAgICAgICAgICAgICBjb2xvcjogdGhlbWUuY29sb3JzLnByaW1hcnksXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgIHJvb3RIb3ZlcmVkOiB7XHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbMzAwXSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBoaW50PXthY3Rpb24/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFjdGlvbi5vbkNsaWNrKGFyZ3MpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH0pfVxyXG4gICAgICA8Lz5cclxuICAgIClcclxuICB9LCBbc2luZ2xlQWN0aW9ucywgZWRpdFNldHRpbmdzLCBtZW51T3B0aW9ucywgcmVuZGVyTWVudU9wdGlvbnNdKVxyXG5cclxuICBjb25zdCBjb21tYW5kQ29sdW1uOiBEYXRhR3JpZENvbHVtbk1vZGVsIHwgdW5kZWZpbmVkID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIXJlbmRlckFjdGlvbkJ1dHRvbnMgfHwgIWhhc01lbnVJdGVtcykgcmV0dXJuIHVuZGVmaW5lZFxyXG5cclxuICAgIGNvbnN0IGNvbW1hbmRDb2x1bW46IERhdGFHcmlkQ29sdW1uTW9kZWwgPSB7XHJcbiAgICAgIGZpZWxkOiBDT01NQU5EX0NPTFVNTl9GSUVMRCxcclxuICAgICAgaGVhZGVyVGV4dDogJycsXHJcbiAgICAgIHdpZHRoOiAnNDBweCcsXHJcbiAgICAgIHNob3dJbkNvbHVtbkNob29zZXI6IGZhbHNlLFxyXG4gICAgICBhbGxvd0VkaXRpbmc6IGZhbHNlLFxyXG4gICAgICBhbGxvd1Jlc2l6aW5nOiBmYWxzZSxcclxuICAgICAgYWxsb3dTb3J0aW5nOiBmYWxzZSxcclxuICAgICAgYWxsb3dGaWx0ZXJpbmc6IGZhbHNlLFxyXG4gICAgICBhbGxvd1Jlb3JkZXJpbmc6IGZhbHNlLFxyXG4gICAgICBlZGl0VGVtcGxhdGU6IHJlbmRlckFjdGlvbkJ1dHRvbnMsXHJcbiAgICAgIGFsbG93R3JvdXBpbmc6IGZhbHNlLFxyXG4gICAgICBhbGxvd1NlYXJjaGluZzogZmFsc2UsXHJcbiAgICAgIHRlbXBsYXRlOiByZW5kZXJBY3Rpb25CdXR0b25zLFxyXG4gICAgICBmcmVlemU6ICFzaW5nbGVBY3Rpb25zID8gJ0ZpeGVkJyA6IHVuZGVmaW5lZCwgLy8gbXVkYXIgdmFsaWRhw6fDo28sIGVuY29udHJhciBsaW1pdGHDp8OjbyBkYSB0YWJlbGFcclxuICAgICAgdGV4dEFsaWduOiAnUmlnaHQnLFxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjb21tYW5kQ29sdW1uXHJcbiAgfSwgW3JlbmRlckFjdGlvbkJ1dHRvbnMsIHNpbmdsZUFjdGlvbnMsIGhhc01lbnVJdGVtc10pXHJcblxyXG4gIGNvbnN0IHNlbGVjdGlvbkNvbHVtbjogRGF0YUdyaWRDb2x1bW5Nb2RlbCB8IHVuZGVmaW5lZCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFoYXNTZWxlY3Rpb24pIHJldHVyblxyXG5cclxuICAgIGNvbnN0IHNlbGVjdGlvbkNvbHVtbjogRGF0YUdyaWRDb2x1bW5Nb2RlbCA9IHtcclxuICAgICAgdHlwZTogJ2NoZWNrYm94JyxcclxuICAgICAgd2lkdGg6IDUwLFxyXG4gICAgICBzaG93SW5Db2x1bW5DaG9vc2VyOiBmYWxzZSxcclxuICAgICAgYWxsb3dFZGl0aW5nOiBmYWxzZSxcclxuICAgICAgYWxsb3dSZXNpemluZzogZmFsc2UsXHJcbiAgICAgIGFsbG93U29ydGluZzogZmFsc2UsXHJcbiAgICAgIGFsbG93RmlsdGVyaW5nOiBmYWxzZSxcclxuICAgICAgYWxsb3dSZW9yZGVyaW5nOiBmYWxzZSxcclxuICAgICAgYWxsb3dTZWFyY2hpbmc6IGZhbHNlLFxyXG4gICAgICBhbGxvd0dyb3VwaW5nOiBmYWxzZSxcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gc2VsZWN0aW9uQ29sdW1uXHJcbiAgfSwgW2hhc1NlbGVjdGlvbl0pXHJcblxyXG4gIGNvbnN0IGNvbHVtbnNGb3JtYXR0ZWQ6IERhdGFHcmlkQ29sdW1uTW9kZWxbXSB8IHVuZGVmaW5lZCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFjb2x1bW5zKSByZXR1cm4gdW5kZWZpbmVkXHJcbiAgICBjb25zdCBmb3JtYXR0ZWRDb2x1bW5zOiBEYXRhR3JpZENvbHVtbk1vZGVsW10gPSBbXVxyXG5cclxuICAgIGlmIChzZWxlY3Rpb25Db2x1bW4pIHtcclxuICAgICAgZm9ybWF0dGVkQ29sdW1ucy5wdXNoKHNlbGVjdGlvbkNvbHVtbilcclxuICAgIH1cclxuXHJcbiAgICBmb3JtYXR0ZWRDb2x1bW5zLnB1c2goLi4uY29udmVydENvbHVtbnNUb0Zvcm1hdChjb2x1bW5zKSlcclxuXHJcbiAgICBpZiAoY29tbWFuZENvbHVtbikge1xyXG4gICAgICBmb3JtYXR0ZWRDb2x1bW5zLnB1c2goY29tbWFuZENvbHVtbilcclxuICAgIH1cclxuXHJcbiAgICBmb3JtYXR0ZWRDb2x1bW5zLnB1c2goKVxyXG4gICAgcmV0dXJuIGZvcm1hdHRlZENvbHVtbnNcclxuICB9LCBbY29sdW1ucywgY29tbWFuZENvbHVtbiwgc2VsZWN0aW9uQ29sdW1uXSlcclxuXHJcbiAgY29uc3QgZ2V0U2VsZWN0aW9uSW5kZXhlcyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmIChncmlkUmVmLmN1cnJlbnQgJiYgc2VsZWN0aW9uICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgY29uc3Qgcm93SW5kZXhlczogbnVtYmVyW10gPSBbXVxyXG4gICAgICBjb25zdCBjdXJyZW50RGF0YSA9IGdyaWRSZWYuY3VycmVudD8uY3VycmVudFZpZXdEYXRhIGFzIFRbXVxyXG4gICAgICBjdXJyZW50RGF0YS5mb3JFYWNoKChyb3csIGluZGV4KSA9PiB7XHJcbiAgICAgICAgaWYgKHNlbGVjdGlvbj8uc29tZShzZWxlY3QgPT4gc2VsZWN0LmlkID09PSByb3cuaWQpKSB7XHJcbiAgICAgICAgICByb3dJbmRleGVzLnB1c2goaW5kZXgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgY29uc3QgaGFzRGF0YSA9IGdyaWRSZWYuY3VycmVudC5nZXRSb3dzKCkgJiYgZ3JpZFJlZi5jdXJyZW50LmdldFJvd3MoKS5sZW5ndGggPiAwXHJcblxyXG4gICAgICBpZiAoaGFzRGF0YSkge1xyXG4gICAgICAgIGdyaWRSZWYuY3VycmVudC5jbGVhclJvd1NlbGVjdGlvbigpXHJcbiAgICAgICAgZ3JpZFJlZi5jdXJyZW50LnNlbGVjdFJvd3Mocm93SW5kZXhlcylcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3Rpb25dKVxyXG5cclxuICBjb25zdCBkYXRhQm91bmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBnZXRTZWxlY3Rpb25JbmRleGVzKClcclxuXHJcbiAgICBpZiAoYXV0b0ZpdENvbHVtbnMpIGdyaWRSZWYuY3VycmVudD8uYXV0b0ZpdENvbHVtbnMoW10pXHJcbiAgfSwgW2F1dG9GaXRDb2x1bW5zLCBnZXRTZWxlY3Rpb25JbmRleGVzXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpdGVtcykge1xyXG4gICAgICBzZXRQYWdlU2l6ZUNhY2hlKGl0ZW1zLmxlbmd0aClcclxuICAgIH1cclxuICB9LCBbaXRlbXNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGl0ZW1zQ291bnQpIHtcclxuICAgICAgc2V0SXRlbXNDb3VudENhY2hlKGl0ZW1zQ291bnQpXHJcbiAgICB9XHJcbiAgfSwgW2l0ZW1zQ291bnRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPERhdGFHcmlkQ29udHJvbFNlY3Rpb24+XHJcbiAgICAgIHtzZWFyY2hhYmxlICYmIGdldERhdGFTb3VyY2UoKSAmJiAoXHJcbiAgICAgICAgPFNlYXJjaENvbnRhaW5lcj5cclxuICAgICAgICAgIHshaGlkZGVuTWVudSAmJiA8RmxleFJvd1xyXG4gICAgICAgICAgICBzdHlsZXM9e3sgZmxleEdyb3c6IDEgfX1cclxuICAgICAgICAgICAgZ2FwPXt0aGVtZS5zcGFjaW5nLmxnfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7cmVuZGVyQWN0aW9ucz8uKCl9XHJcbiAgICAgICAgICA8L0ZsZXhSb3c+fVxyXG4gICAgICAgICAgPERhdGFUYWJsZVNlYXJjaCBvbkNoYW5nZT17ZGVib3VuY2Uob25TZWFyY2hUZXh0Q2hhbmdlLCAzMDApfSAvPlxyXG4gICAgICAgIDwvU2VhcmNoQ29udGFpbmVyPlxyXG4gICAgICApfVxyXG4gICAgICB7aGFzRmlsdGVyICYmIG9uRmlsdGVyR3JvdXBDaGFuZ2UgJiYgY29sdW1ucyAmJlxyXG4gICAgICAgIDxEYXRhVGFibGVGaWx0ZXJHcm91cHNcclxuICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICBvblF1ZXJ5Q2hhbmdlPXtvbkZpbHRlckdyb3VwQ2hhbmdlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIH1cclxuICAgICAgPERhdGFHcmlkQ29udGFpbmVyXHJcbiAgICAgICAgaXNEZXRhaWxpbmdNb2RlPXtpc0RldGFpbGluZ01vZGV9XHJcbiAgICAgICAgY29tcGFjdD17Y29tcGFjdH1cclxuICAgICAgICBncm91cEVycm9ycz17Z3JvdXBFcnJvcnN9XHJcbiAgICAgICAgaGFzVXJsPXshIWRhdGFVcmx9XHJcbiAgICAgID5cclxuICAgICAgICB7bG9hZGluZyAmJlxyXG4gICAgICAgICAgPExvYWRpbmdTY3JlZW4gLz5cclxuICAgICAgICB9XHJcbiAgICAgICAgeyFsb2FkaW5nICYmICgoaXRlbXMgJiYgaXRlbXMubGVuZ3RoID4gMCkgfHwgZGF0YVVybCkgJiYgPEdyaWRDb21wb25lbnRcclxuICAgICAgICAgIGxvY2FsZT0ncHQtQlInXHJcbiAgICAgICAgICBkYXRhU291cmNlPXtkYXRhVXJsID8gZGF0YU1hbmFnZXIgOiBnZXREYXRhU291cmNlKCl9XHJcbiAgICAgICAgICB0b29sYmFyPXtidWlsZEdyaWRUb29sYmFyKHNob3dDb2x1bW5DaG9vc2VyLCBoYXNTZWFyY2gpfVxyXG4gICAgICAgICAgZGF0YUJvdW5kPXtkYXRhQm91bmR9XHJcbiAgICAgICAgICBhZ2dyZWdhdGVzPXthZ2dyZWdhdGVzfVxyXG4gICAgICAgICAgaGVpZ2h0PXtoZWlnaHR9XHJcbiAgICAgICAgICBxdWVyeT17cXVlcnl9XHJcbiAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zRm9ybWF0dGVkfVxyXG4gICAgICAgICAgYWxsb3dQYWdpbmc9e3BhZ2luYXRlZH1cclxuICAgICAgICAgIGVkaXRTZXR0aW5ncz17ZWRpdFNldHRpbmdzfVxyXG4gICAgICAgICAgcGFnZVNldHRpbmdzPXtwYWdlU2V0dGluZ3N9XHJcbiAgICAgICAgICBzb3J0U2V0dGluZ3M9e3NvcnRTZXR0aW5nc31cclxuICAgICAgICAgIGFsbG93R3JvdXBpbmc9e2dyb3VwYWJsZX1cclxuICAgICAgICAgIGdyb3VwU2V0dGluZ3M9e2dyb3VwU2V0dGluZ3N9XHJcbiAgICAgICAgICBhbGxvd1Jlc2l6aW5nPXtyZXNpemVhYmxlfVxyXG4gICAgICAgICAgYWxsb3dGaWx0ZXJpbmc9e2lzRmlsdGVyYWJsZX1cclxuICAgICAgICAgIGZpbHRlclNldHRpbmdzPXtmaWx0ZXJTZXR0aW5nc31cclxuICAgICAgICAgIGFsbG93U29ydGluZz17c29ydGFibGV9XHJcbiAgICAgICAgICBzZWxlY3Rpb25TZXR0aW5ncz17c2VsZWN0aW9uU2V0dGluZ3N9XHJcbiAgICAgICAgICBkYXRhU3RhdGVDaGFuZ2U9e2hhbmRsZVN0YXRlQ2hhbmdlfVxyXG4gICAgICAgICAgYWN0aW9uQ29tcGxldGU9e2hhbmRsZUFjdGlvbkNvbXBsZXRlfVxyXG4gICAgICAgICAgYWN0aW9uQmVnaW49e2hhbmRsZUFjdGlvbkJlZ2lufVxyXG4gICAgICAgICAgcm93U2VsZWN0ZWQ9e3NlbGVjdGVkfVxyXG4gICAgICAgICAgcm93RGVzZWxlY3RlZD17ZGVzZWxlY3RlZH1cclxuICAgICAgICAgIHJlc2l6ZVNldHRpbmdzPXt7IG1vZGU6ICdOb3JtYWwnIH19XHJcbiAgICAgICAgICBzaG93Q29sdW1uQ2hvb3Nlcj17c2hvd0NvbHVtbkNob29zZXJ9XHJcbiAgICAgICAgICByZWY9e2dyaWRSZWZ9XHJcbiAgICAgICAgICBzZWFyY2hTZXR0aW5ncz17c2VhcmNoU2V0dGluZ3N9XHJcbiAgICAgICAgICAvLyBlbmFibGVQZXJzaXN0ZW5jZT17dHJ1ZX1cclxuICAgICAgICAgIC8vIHBhZ2VyVGVtcGxhdGU9eygpID0+IDw+PC8+fVxyXG4gICAgICAgID5cclxuXHJcbiAgICAgICAgICA8SW5qZWN0IHNlcnZpY2VzPXtcclxuICAgICAgICAgICAgYnVpbGRHcmlkU2VydmljZXMoXHJcbiAgICAgICAgICAgICAgcGFnaW5hdGVkLFxyXG4gICAgICAgICAgICAgIHJlc2l6ZWFibGUsXHJcbiAgICAgICAgICAgICAgZ3JvdXBhYmxlLFxyXG4gICAgICAgICAgICAgIGFnZ3JlZ2F0ZSxcclxuICAgICAgICAgICAgICBlZGl0YWJsZSxcclxuICAgICAgICAgICAgICBzb3J0YWJsZSxcclxuICAgICAgICAgICAgICBoYXNNZW51SXRlbXMsXHJcbiAgICAgICAgICAgICAgZnJvemVuYWJsZSxcclxuICAgICAgICAgICAgICBpc0ZpbHRlcmFibGUsXHJcbiAgICAgICAgICAgICAgc2hvd0NvbHVtbkNob29zZXIsXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgIH0vPlxyXG4gICAgICAgIDwvR3JpZENvbXBvbmVudD5cclxuICAgICAgICB9XHJcbiAgICAgIDwvRGF0YUdyaWRDb250YWluZXI+XHJcbiAgICAgIHshbG9hZGluZyAmJiBpdGVtcyAmJiBpdGVtcy5sZW5ndGggPT09IDAgJiZcclxuICAgICAgICA8RGF0YVRhYmxlRW1wdHlTdGF0ZSAvPlxyXG4gICAgICB9XHJcbiAgICAgIHshZGF0YVVybCAmJiBwYWdpbmF0ZWQgJiYgb25QYWdlQ2hhbmdlICYmIDxEYXRhVGFibGVQYWdpbmF0aW9uXHJcbiAgICAgICAgcGFnZUl0ZW1zQ291bnQ9e3BhZ2VTaXplQ2FjaGV9XHJcbiAgICAgICAgdG90YWxJdGVtc0NvdW50PXtpdGVtc0NvdW50Q2FjaGV9XHJcbiAgICAgICAgb25QYWdlQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9XHJcbiAgICAgICAgY3VzdG9tUGFnZU9wdGlvbnM9e2N1c3RvbVBhZ2VPcHRpb25zfVxyXG4gICAgICAvPn1cclxuICAgIDwvRGF0YUdyaWRDb250cm9sU2VjdGlvbj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNvbnZlcnRDb2x1bW5zVG9Gb3JtYXQ8VCBleHRlbmRzIEVudGl0eT4gKGNvbHVtbnM6IERhdGFUYWJsZUNvbHVtbjxUPltdKTogR3JpZENvbHVtbk1vZGVsW10ge1xyXG4gIHJldHVybiBjb2x1bW5zLm1hcChjb2x1bW4gPT4ge1xyXG4gICAgY29uc3QgaXNQcmltYXJ5S2V5ID0gY29sdW1uLmZpZWxkID09PSAnaWQnXHJcbiAgICBjb25zdCBpc0NvbHVtblZpc2libGUgPSBjb2x1bW4udmlzaWJsZSAhPT0gdW5kZWZpbmVkXHJcbiAgICAgID8gY29sdW1uLnZpc2libGVcclxuICAgICAgOiBjb2x1bW4uYmxvY2tTaG93aW5nID8gZmFsc2UgOiB0cnVlIHx8IHRydWVcclxuXHJcbiAgICBjb25zdCB0cmFuc2xhdGVkQ29sdW1uOiBEYXRhR3JpZENvbHVtbk1vZGVsID0ge1xyXG4gICAgICBhbGxvd1NvcnRpbmc6IGNvbHVtbi5zb3J0YWJsZSB8fCBmYWxzZSxcclxuICAgICAgYWxsb3dFZGl0aW5nOiBjb2x1bW4uYWxsb3dFZGl0aW5nIHx8IGZhbHNlLFxyXG4gICAgICBhbGxvd1Jlc2l6aW5nOiBjb2x1bW4uYWxsb3dSZXNpemluZyB8fCBmYWxzZSxcclxuICAgICAgYWxsb3dGaWx0ZXJpbmc6IGNvbHVtbi5maWx0ZXJhYmxlIHx8IGZhbHNlLFxyXG4gICAgICAvLyBhbGxvd1Jlb3JkZXJpbmc6IGZhbHNlLFxyXG4gICAgICBjbGlwTW9kZTogJ0VsbGlwc2lzV2l0aFRvb2x0aXAnLFxyXG4gICAgICBoZWFkZXJUZXh0OiBjb2x1bW4uaGVhZGVyLFxyXG4gICAgICBmaWVsZDogY29sdW1uLmZpZWxkIGFzIHN0cmluZyxcclxuICAgICAgdHlwZTogY29sdW1uLnR5cGUsXHJcbiAgICAgIHRlbXBsYXRlOiBjb2x1bW4uZm9ybWF0LFxyXG4gICAgICBtYXhXaWR0aDogY29sdW1uLm1heFdpZHRoLFxyXG4gICAgICBtaW5XaWR0aDogY29sdW1uLm1pbldpZHRoIHx8IE1JTl9XSURUSF9DT0xVTU4sXHJcbiAgICAgIGlzUHJpbWFyeUtleTogY29sdW1uLmlzUHJpbWFyeUtleSB8fCBpc1ByaW1hcnlLZXksXHJcbiAgICAgIHdpZHRoOiBjb2x1bW4ud2lkdGggfHwgY29sdW1uLm1pbldpZHRoIHx8IE1JTl9XSURUSF9DT0xVTU4sXHJcbiAgICAgIHZpc2libGU6IGlzQ29sdW1uVmlzaWJsZSxcclxuICAgICAgZm9ybWF0OiBjb2x1bW4uZm9ybWF0Q29uZmlnLFxyXG4gICAgICBjb2x1bW5zOiBjb2x1bW4uY29sdW1ucyA/IGNvbnZlcnRDb2x1bW5zVG9Gb3JtYXQoY29sdW1uLmNvbHVtbnMpIDogdW5kZWZpbmVkLFxyXG4gICAgICBlZGl0VHlwZTogY29sdW1uLmVkaXRUeXBlLFxyXG4gICAgICB0ZXh0QWxpZ246IGNvbHVtbi5jZW50ZXIgPyAnQ2VudGVyJyA6IGNvbHVtbi50ZXh0QWxpZ24sXHJcbiAgICAgIHZhbGlkYXRpb25SdWxlczogY29sdW1uLnZhbGlkYXRpb25SdWxlcyxcclxuICAgICAgZWRpdDogY29sdW1uLmVkaXQsXHJcbiAgICAgIGZvcmVpZ25LZXlWYWx1ZTogY29sdW1uLmZvcmVpZ25LZXlWYWx1ZSxcclxuICAgICAgZm9yZWlnbktleUZpZWxkOiBjb2x1bW4uZm9yZWlnbktleUZpZWxkLFxyXG4gICAgICBkYXRhU291cmNlOiBjb2x1bW4uZGF0YVNvdXJjZSxcclxuICAgICAgZmlsdGVyOiBjb2x1bW4uZmlsdGVyIHx8IHt9LFxyXG4gICAgICBmaWx0ZXJUZW1wbGF0ZTogY29sdW1uLmZpbHRlclRlbXBsYXRlLFxyXG4gICAgICBmaWx0ZXJCYXJUZW1wbGF0ZTogY29sdW1uLmZpbHRlckJhclRlbXBsYXRlLFxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRyYW5zbGF0ZWRDb2x1bW5cclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXRhR3JpZFxyXG4iXX0=