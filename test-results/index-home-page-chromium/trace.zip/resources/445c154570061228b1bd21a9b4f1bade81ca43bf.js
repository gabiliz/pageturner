import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTablePagination.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useTheme as useThemeFluent, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { Pagination } from "/node_modules/.vite/deps/@uifabric_experiments.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
const options = [{
  key: 12,
  text: "12"
}, {
  key: 25,
  text: "25"
}, {
  key: 50,
  text: "50"
}];
const DataTablePagination = (props) => {
  _s();
  const {
    pageItemsCount,
    totalItemsCount,
    onPageChange,
    customPageOptions
  } = props;
  const {
    spacing
  } = useTheme();
  const theme = useThemeFluent();
  const [pageSize, setPageSize] = useState(customPageOptions ? customPageOptions[0].key : options[0].key);
  const pageStyles = useStyles();
  const [currentPage, setCurrentPage] = useState(0);
  const [pagesCount, setPagesCount] = useState(1);
  useEffect(() => {
    setPagesCount(Math.ceil(totalItemsCount / pageSize) || 1);
  }, [totalItemsCount, pageSize]);
  useEffect(() => {
    setCurrentPage(0);
  }, [pageSize]);
  useEffect(() => {
    onPageChange({
      itemsSkipped: currentPage * pageSize,
      pageSize
    });
  }, [currentPage, onPageChange, pageSize]);
  return /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", verticalAlign: "center", children: [
    /* @__PURE__ */ jsxDEV(Text, { children: [
      "Exibindo ",
      pageItemsCount,
      " de ",
      totalItemsCount,
      " resultados"
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", horizontalAlign: "center", gap: spacing.xl, children: [
      /* @__PURE__ */ jsxDEV(Text, { children: "Resultados por página" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ComboBox, { defaultSelectedKey: customPageOptions ? customPageOptions[0].key : options[0].key, options: customPageOptions || options, styles: {
        root: {
          maxWidth: 70
        }
      }, onChange: (_, option) => setPageSize(option?.key) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          selectedPageIndex: currentPage,
          pageCount: pagesCount,
          onPageChange: setCurrentPage,
          theme,
          format: "buttons",
          nextPageIconProps: {
            iconName: "ChevronRight"
          },
          previousPageIconProps: {
            iconName: "ChevronLeft"
          },
          styles: pageStyles
        },
        void 0,
        false,
        {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
          lineNumber: 63,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx",
    lineNumber: 54,
    columnNumber: 10
  }, this);
};
_s(DataTablePagination, "/Rul7DV8SUTewnnWR9Pv+PCIDNo=", false, function() {
  return [useTheme, useThemeFluent, useStyles];
});
_c = DataTablePagination;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return {
    root: {
      "& > div": {
        display: "flex",
        alignItems: "center",
        height: 12
      },
      ".ms-Pagination-pageNumber": {
        height: 10,
        padding: "0px 0px",
        minHeight: "24px",
        minWidth: "24px",
        margin: "6px"
      },
      ".ms-Pagination-pageNumber[aria-selected=true]": {
        backgroundColor: colors.purple[600],
        textDecoration: "none",
        padding: "0px 0px",
        minHeight: "24px",
        minWidth: "24px",
        margin: "6px",
        "> span": {
          color: colors.white,
          textDecoration: "none"
        },
        ":hover": {
          backgroundColor: colors.purple[600]
        }
      }
    }
  };
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default DataTablePagination;
var _c;
$RefreshReg$(_c, "DataTablePagination");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTablePagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRNOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0ROLFNBQ0VBLFVBQ0FDLGlCQUVLO0FBQ1AsU0FDRUMsWUFBWUMsZ0JBQ1pDLFlBRUs7QUFDUCxTQUE0QkMsa0JBQWtCO0FBRTlDLFNBQVNILGdCQUFnQjtBQUN6QixTQUFTSSxnQkFBZ0I7QUFDekIsT0FBT0MsYUFBYTtBQVNwQixNQUFNQyxVQUE2QixDQUNqQztBQUFBLEVBQUVDLEtBQUs7QUFBQSxFQUFJQyxNQUFNO0FBQUssR0FDdEI7QUFBQSxFQUFFRCxLQUFLO0FBQUEsRUFBSUMsTUFBTTtBQUFLLEdBQ3RCO0FBQUEsRUFBRUQsS0FBSztBQUFBLEVBQUlDLE1BQU07QUFBSyxDQUFDO0FBR3pCLE1BQU1DLHNCQUFvREEsQ0FBQ0MsVUFBb0M7QUFBQUMsS0FBQTtBQUM3RixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBZ0JDO0FBQUFBLElBQWlCQztBQUFBQSxJQUFjQztBQUFBQSxFQUFrQixJQUFJTDtBQUM3RSxRQUFNO0FBQUEsSUFBRU07QUFBQUEsRUFBUSxJQUFJaEIsU0FBUztBQUM3QixRQUFNaUIsUUFBUWhCLGVBQWU7QUFDN0IsUUFBTSxDQUFDaUIsVUFBVUMsV0FBVyxJQUFJckIsU0FBU2lCLG9CQUNyQ0Esa0JBQWtCLENBQUMsRUFBRVIsTUFDckJELFFBQVEsQ0FBQyxFQUFFQyxHQUNmO0FBQ0EsUUFBTWEsYUFBYUMsVUFBVTtBQUM3QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXpCLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLENBQUM7QUFFOUNDLFlBQVUsTUFBTTtBQUNkMEIsa0JBQWNDLEtBQUtDLEtBQUtkLGtCQUFrQkssUUFBUSxLQUFLLENBQUM7QUFBQSxFQUMxRCxHQUFHLENBQUNMLGlCQUFpQkssUUFBUSxDQUFDO0FBRTlCbkIsWUFBVSxNQUFNO0FBQ2R3QixtQkFBZSxDQUFDO0FBQUEsRUFDbEIsR0FBRyxDQUFDTCxRQUFRLENBQUM7QUFFYm5CLFlBQVUsTUFBTTtBQUNkZSxpQkFBYTtBQUFBLE1BQ1hjLGNBQWNOLGNBQWNKO0FBQUFBLE1BQzVCQTtBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ0ksYUFBYVIsY0FBY0ksUUFBUSxDQUFDO0FBRXhDLFNBQ0UsdUJBQUMsV0FDQyxpQkFBZ0IsaUJBQ2hCLGVBQWMsVUFFZDtBQUFBLDJCQUFDLFFBQUs7QUFBQTtBQUFBLE1BQVVOO0FBQUFBLE1BQWU7QUFBQSxNQUFLQztBQUFBQSxNQUFnQjtBQUFBLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Q7QUFBQSxJQUMvRCx1QkFBQyxXQUNDLGVBQWMsVUFDZCxpQkFBZ0IsVUFDaEIsS0FBTUcsUUFBUWEsSUFFZDtBQUFBLDZCQUFDLFFBQUsscUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLE1BQzNCLHVCQUFDLFlBQ0Msb0JBQW9CZCxvQkFDaEJBLGtCQUFrQixDQUFDLEVBQUVSLE1BQ3JCRCxRQUFRLENBQUMsRUFBRUMsS0FFZixTQUFTUSxxQkFBcUJULFNBQzlCLFFBQVE7QUFBQSxRQUNOd0IsTUFBTTtBQUFBLFVBQ0pDLFVBQVU7QUFBQSxRQUNaO0FBQUEsTUFDRixHQUNBLFVBQVUsQ0FBQ0MsR0FBR0MsV0FBV2QsWUFBWWMsUUFBUTFCLEdBQWEsS0FYNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVc4RDtBQUFBLE1BRTlEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxtQkFBbUJlO0FBQUFBLFVBQ25CLFdBQVdFO0FBQUFBLFVBQ1gsY0FBY0Q7QUFBQUEsVUFDZDtBQUFBLFVBQ0EsUUFBTztBQUFBLFVBQ1AsbUJBQW1CO0FBQUEsWUFDakJXLFVBQVU7QUFBQSxVQUNaO0FBQUEsVUFDQSx1QkFBdUI7QUFBQSxZQUNyQkEsVUFBVTtBQUFBLFVBQ1o7QUFBQSxVQUNBLFFBQVFkO0FBQUFBO0FBQUFBLFFBWlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWXFCO0FBQUEsU0EvQnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0E7QUFBQSxPQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBQ1QsR0FyRUtGLHFCQUFpRDtBQUFBLFVBRWpDVCxVQUNOQyxnQkFLS29CLFNBQVM7QUFBQTtBQUFBYyxLQVJ4QjFCO0FBdUVOLE1BQU1ZLFlBQVlBLE1BQU07QUFBQWUsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJckMsU0FBUztBQUM1QixTQUFPO0FBQUEsSUFDTDhCLE1BQU07QUFBQSxNQUNKLFdBQVc7QUFBQSxRQUNUUSxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLFFBQVE7QUFBQSxNQUNWO0FBQUEsTUFDQSw2QkFBNkI7QUFBQSxRQUMzQkEsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVE7QUFBQSxNQUNWO0FBQUEsTUFDQSxpREFBaUQ7QUFBQSxRQUMvQ0MsaUJBQWlCUixPQUFPUyxPQUFPLEdBQUc7QUFBQSxRQUNsQ0MsZ0JBQWdCO0FBQUEsUUFDaEJOLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVE7QUFBQSxRQUNSLFVBQVU7QUFBQSxVQUNSSSxPQUFPWCxPQUFPWTtBQUFBQSxVQUNkRixnQkFBZ0I7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsVUFBVTtBQUFBLFVBQ1JGLGlCQUFpQlIsT0FBT1MsT0FBTyxHQUFHO0FBQUEsUUFDcEM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUFDVixJQWpDS2YsV0FBUztBQUFBLFVBQ01yQixRQUFRO0FBQUE7QUFrQzdCLGVBQWVTO0FBQW1CLElBQUEwQjtBQUFBZSxhQUFBZixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VUaGVtZSIsInVzZVRoZW1lRmx1ZW50IiwiVGV4dCIsIlBhZ2luYXRpb24iLCJDb21ib0JveCIsIkZsZXhSb3ciLCJvcHRpb25zIiwia2V5IiwidGV4dCIsIkRhdGFUYWJsZVBhZ2luYXRpb24iLCJwcm9wcyIsIl9zIiwicGFnZUl0ZW1zQ291bnQiLCJ0b3RhbEl0ZW1zQ291bnQiLCJvblBhZ2VDaGFuZ2UiLCJjdXN0b21QYWdlT3B0aW9ucyIsInNwYWNpbmciLCJ0aGVtZSIsInBhZ2VTaXplIiwic2V0UGFnZVNpemUiLCJwYWdlU3R5bGVzIiwidXNlU3R5bGVzIiwiY3VycmVudFBhZ2UiLCJzZXRDdXJyZW50UGFnZSIsInBhZ2VzQ291bnQiLCJzZXRQYWdlc0NvdW50IiwiTWF0aCIsImNlaWwiLCJpdGVtc1NraXBwZWQiLCJ4bCIsInJvb3QiLCJtYXhXaWR0aCIsIl8iLCJvcHRpb24iLCJpY29uTmFtZSIsIl9jIiwiX3MyIiwiY29sb3JzIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJoZWlnaHQiLCJwYWRkaW5nIiwibWluSGVpZ2h0IiwibWluV2lkdGgiLCJtYXJnaW4iLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJ0ZXh0RGVjb3JhdGlvbiIsImNvbG9yIiwid2hpdGUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGVQYWdpbmF0aW9uLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2RhdGF0YWJsZS9EYXRhVGFibGVQYWdpbmF0aW9uLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgdXNlU3RhdGUsXHJcbiAgdXNlRWZmZWN0LFxyXG4gIEZDLFxyXG59IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQge1xyXG4gIHVzZVRoZW1lIGFzIHVzZVRoZW1lRmx1ZW50LFxyXG4gIFRleHQsXHJcbiAgSUNvbWJvQm94T3B0aW9uLFxyXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgSVBhZ2luYXRpb25TdHlsZXMsIFBhZ2luYXRpb24gfSBmcm9tICdAdWlmYWJyaWMvZXhwZXJpbWVudHMnXHJcbmltcG9ydCB7IERhdGFUYWJsZVBhZ2luYXRpb25Db25maWcgfSBmcm9tICcuL3R5cGVzJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xyXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uL2NvbWJvQm94J1xyXG5pbXBvcnQgRmxleFJvdyBmcm9tICcuLy4uL0ZsZXhCb3gvRmxleFJvdydcclxuXHJcbmludGVyZmFjZSBEYXRhVGFibGVQYWdpbmF0aW9uUHJvcHMge1xyXG4gIHBhZ2VJdGVtc0NvdW50OiBudW1iZXJcclxuICB0b3RhbEl0ZW1zQ291bnQ6IG51bWJlclxyXG4gIG9uUGFnZUNoYW5nZTogKGNvbmZpZzogRGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZykgPT4gdm9pZFxyXG4gIGN1c3RvbVBhZ2VPcHRpb25zPzogSUNvbWJvQm94T3B0aW9uW11cclxufVxyXG5cclxuY29uc3Qgb3B0aW9uczogSUNvbWJvQm94T3B0aW9uW10gPSBbXHJcbiAgeyBrZXk6IDEyLCB0ZXh0OiAnMTInIH0sXHJcbiAgeyBrZXk6IDI1LCB0ZXh0OiAnMjUnIH0sXHJcbiAgeyBrZXk6IDUwLCB0ZXh0OiAnNTAnIH0sXHJcbl1cclxuXHJcbmNvbnN0IERhdGFUYWJsZVBhZ2luYXRpb246IEZDPERhdGFUYWJsZVBhZ2luYXRpb25Qcm9wcz4gPSAocHJvcHM6IERhdGFUYWJsZVBhZ2luYXRpb25Qcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgcGFnZUl0ZW1zQ291bnQsIHRvdGFsSXRlbXNDb3VudCwgb25QYWdlQ2hhbmdlLCBjdXN0b21QYWdlT3B0aW9ucyB9ID0gcHJvcHNcclxuICBjb25zdCB7IHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lRmx1ZW50KClcclxuICBjb25zdCBbcGFnZVNpemUsIHNldFBhZ2VTaXplXSA9IHVzZVN0YXRlKGN1c3RvbVBhZ2VPcHRpb25zXHJcbiAgICA/IGN1c3RvbVBhZ2VPcHRpb25zWzBdLmtleSBhcyBudW1iZXJcclxuICAgIDogb3B0aW9uc1swXS5rZXkgYXMgbnVtYmVyLFxyXG4gIClcclxuICBjb25zdCBwYWdlU3R5bGVzID0gdXNlU3R5bGVzKClcclxuICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKDApXHJcbiAgY29uc3QgW3BhZ2VzQ291bnQsIHNldFBhZ2VzQ291bnRdID0gdXNlU3RhdGUoMSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFBhZ2VzQ291bnQoTWF0aC5jZWlsKHRvdGFsSXRlbXNDb3VudCAvIHBhZ2VTaXplKSB8fCAxKVxyXG4gIH0sIFt0b3RhbEl0ZW1zQ291bnQsIHBhZ2VTaXplXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldEN1cnJlbnRQYWdlKDApXHJcbiAgfSwgW3BhZ2VTaXplXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIG9uUGFnZUNoYW5nZSh7XHJcbiAgICAgIGl0ZW1zU2tpcHBlZDogY3VycmVudFBhZ2UgKiBwYWdlU2l6ZSxcclxuICAgICAgcGFnZVNpemUsXHJcbiAgICB9KVxyXG4gIH0sIFtjdXJyZW50UGFnZSwgb25QYWdlQ2hhbmdlLCBwYWdlU2l6ZV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmxleFJvd1xyXG4gICAgICBob3Jpem9udGFsQWxpZ249XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgdmVydGljYWxBbGlnbj1cImNlbnRlclwiXHJcbiAgICA+XHJcbiAgICAgIDxUZXh0PkV4aWJpbmRvIHtwYWdlSXRlbXNDb3VudH0gZGUge3RvdGFsSXRlbXNDb3VudH0gcmVzdWx0YWRvczwvVGV4dD5cclxuICAgICAgPEZsZXhSb3dcclxuICAgICAgICB2ZXJ0aWNhbEFsaWduPVwiY2VudGVyXCJcclxuICAgICAgICBob3Jpem9udGFsQWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAgIGdhcD17IHNwYWNpbmcueGwgfVxyXG4gICAgICA+XHJcbiAgICAgICAgPFRleHQ+UmVzdWx0YWRvcyBwb3IgcMOhZ2luYTwvVGV4dD5cclxuICAgICAgICA8Q29tYm9Cb3hcclxuICAgICAgICAgIGRlZmF1bHRTZWxlY3RlZEtleT17Y3VzdG9tUGFnZU9wdGlvbnNcclxuICAgICAgICAgICAgPyBjdXN0b21QYWdlT3B0aW9uc1swXS5rZXlcclxuICAgICAgICAgICAgOiBvcHRpb25zWzBdLmtleVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb3B0aW9ucz17Y3VzdG9tUGFnZU9wdGlvbnMgfHwgb3B0aW9uc31cclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgbWF4V2lkdGg6IDcwLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoXywgb3B0aW9uKSA9PiBzZXRQYWdlU2l6ZShvcHRpb24/LmtleSBhcyBudW1iZXIpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFBhZ2luYXRpb25cclxuICAgICAgICAgIHNlbGVjdGVkUGFnZUluZGV4PXtjdXJyZW50UGFnZX1cclxuICAgICAgICAgIHBhZ2VDb3VudD17cGFnZXNDb3VudH1cclxuICAgICAgICAgIG9uUGFnZUNoYW5nZT17c2V0Q3VycmVudFBhZ2V9XHJcbiAgICAgICAgICB0aGVtZT17dGhlbWV9IC8vIHRvZG8gY29tcG9uZW50ZSBwYWdpbmF0aW9uIHByw7NwcmlvXHJcbiAgICAgICAgICBmb3JtYXQ9J2J1dHRvbnMnXHJcbiAgICAgICAgICBuZXh0UGFnZUljb25Qcm9wcz17e1xyXG4gICAgICAgICAgICBpY29uTmFtZTogJ0NoZXZyb25SaWdodCcsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgcHJldmlvdXNQYWdlSWNvblByb3BzPXt7XHJcbiAgICAgICAgICAgIGljb25OYW1lOiAnQ2hldnJvbkxlZnQnLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIHN0eWxlcz17cGFnZVN0eWxlc31cclxuICAgICAgICAvPlxyXG4gICAgICA8L0ZsZXhSb3c+XHJcbiAgICA8L0ZsZXhSb3c+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICByZXR1cm4ge1xyXG4gICAgcm9vdDoge1xyXG4gICAgICAnJiA+IGRpdic6IHtcclxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgICAgaGVpZ2h0OiAxMixcclxuICAgICAgfSxcclxuICAgICAgJy5tcy1QYWdpbmF0aW9uLXBhZ2VOdW1iZXInOiB7XHJcbiAgICAgICAgaGVpZ2h0OiAxMCxcclxuICAgICAgICBwYWRkaW5nOiAnMHB4IDBweCcsXHJcbiAgICAgICAgbWluSGVpZ2h0OiAnMjRweCcsXHJcbiAgICAgICAgbWluV2lkdGg6ICcyNHB4JyxcclxuICAgICAgICBtYXJnaW46ICc2cHgnLFxyXG4gICAgICB9LFxyXG4gICAgICAnLm1zLVBhZ2luYXRpb24tcGFnZU51bWJlclthcmlhLXNlbGVjdGVkPXRydWVdJzoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs2MDBdLFxyXG4gICAgICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXHJcbiAgICAgICAgcGFkZGluZzogJzBweCAwcHgnLFxyXG4gICAgICAgIG1pbkhlaWdodDogJzI0cHgnLFxyXG4gICAgICAgIG1pbldpZHRoOiAnMjRweCcsXHJcbiAgICAgICAgbWFyZ2luOiAnNnB4JyxcclxuICAgICAgICAnPiBzcGFuJzoge1xyXG4gICAgICAgICAgY29sb3I6IGNvbG9ycy53aGl0ZSxcclxuICAgICAgICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnOmhvdmVyJzoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSBhcyBQYXJ0aWFsPElQYWdpbmF0aW9uU3R5bGVzPlxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXRhVGFibGVQYWdpbmF0aW9uXHJcbiJdfQ==