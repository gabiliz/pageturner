import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dialog/DialogsLayer.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/DialogsLayer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { ConfirmDialog } from "/src/shared/components/dialog/index.ts?t=1701096626433";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
const DialogsLayer = () => {
  _s();
  const {
    dialogProps,
    closeDialog
  } = useDialogs();
  if (dialogProps)
    return /* @__PURE__ */ jsxDEV(ConfirmDialog, { ...dialogProps, onDismiss: closeDialog }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/DialogsLayer.tsx",
      lineNumber: 11,
      columnNumber: 27
    }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/DialogsLayer.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(DialogsLayer, "NqaFXlmQsJXKV6TbpVK/yNjuIG4=", false, function() {
  return [useDialogs];
});
_c = DialogsLayer;
export default DialogsLayer;
var _c;
$RefreshReg$(_c, "DialogsLayer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/DialogsLayer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTzBCLFNBRWpCLFVBRmlCOzs7Ozs7Ozs7Ozs7Ozs7O0FBTjFCLFNBQVNBLHFCQUFxQjtBQUM5QixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsZUFBbUJBLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBYUM7QUFBQUEsRUFBWSxJQUFJSixXQUFXO0FBRWhELE1BQUlHO0FBQWEsV0FBTyx1QkFBQyxpQkFBYyxHQUFJQSxhQUFhLFdBQVdDLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFFL0UsU0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUU7QUFDWDtBQUFDRixHQU5LRCxjQUFnQjtBQUFBLFVBQ2lCRCxVQUFVO0FBQUE7QUFBQUssS0FEM0NKO0FBUU4sZUFBZUE7QUFBWSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29uZmlybURpYWxvZyIsInVzZURpYWxvZ3MiLCJEaWFsb2dzTGF5ZXIiLCJfcyIsImRpYWxvZ1Byb3BzIiwiY2xvc2VEaWFsb2ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRpYWxvZ3NMYXllci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kaWFsb2cvRGlhbG9nc0xheWVyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDb25maXJtRGlhbG9nIH0gZnJvbSAnLidcbmltcG9ydCB7IHVzZURpYWxvZ3MgfSBmcm9tICcuLi8uLi9zdG9yZS9kaWFsb2dzL2RpYWxvZ3MnXG5cbmNvbnN0IERpYWxvZ3NMYXllcjogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgZGlhbG9nUHJvcHMsIGNsb3NlRGlhbG9nIH0gPSB1c2VEaWFsb2dzKClcblxuICBpZiAoZGlhbG9nUHJvcHMpIHJldHVybiA8Q29uZmlybURpYWxvZyB7Li4uZGlhbG9nUHJvcHN9IG9uRGlzbWlzcz17Y2xvc2VEaWFsb2d9IC8+XG5cbiAgcmV0dXJuIDw+PC8+XG59XG5cbmV4cG9ydCBkZWZhdWx0IERpYWxvZ3NMYXllclxuIl19