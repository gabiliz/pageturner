import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditsList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { DirectionalHint } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { ErrorBoundary } from "/node_modules/.vite/deps/react-error-boundary.js?v=9f90a7ff";
import { DataTableInt, ErrorScreen, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService as service } from "/src/modules/audit/audits/services/index.ts";
import { AcceptTermsModal } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
import { AuditHistoryModal, AuditsSituation } from "/src/modules/audit/audits/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { formatProposalNumber, buildQueryFilterDefault } from "/src/shared/utils/index.ts";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { ContractTypeRecord } from "/src/shared/record/index.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditsList = () => {
  _s();
  const {
    currentAccount: {
      value: currentUser
    }
  } = useAuth();
  const {
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  const [paginationConfig, setPaginationConfig] = useState({
    itemsSkipped: 0,
    pageSize: 10
  });
  const [sortConfig, setSortConfig] = useState({
    field: "contrato.cliente.nomeFantasia",
    descending: false
  });
  const [filter, setFilter] = useState();
  const [
    auditToShowHistory
    /* , setAuditToShowHistory */
  ] = useState("");
  const currentURL = window.location.href;
  const filterData = useCallback((value) => {
    setFilter(buildQueryFilterDefault(columns, value));
  }, [setFilter, columns, filter]);
  const {
    isLoading,
    error,
    data
  } = service.useFindAllPaginated({
    $skip: paginationConfig.itemsSkipped,
    $top: paginationConfig.pageSize,
    $filter: `situacao ne ${AuditSituationEnum.Cancelado} ${filter ? `and (${filter})` : ""}`,
    $orderby: `${sortConfig.field?.replaceAll(".", "/")} ${sortConfig.descending ? "desc" : "asc"}`
  });
  const [termsAcceptanceModal, {
    setTrue: showTermsAcceptance,
    setFalse: hideTermsAcceptance
  }] = useBoolean(false);
  const [historyModal, {
    // setTrue: showHistory,
    setFalse: hideHistory
  }] = useBoolean(false);
  const [selectedAudit, setSelectedAudit] = useState();
  function goToControlPanel(audit) {
    window.open(`${currentURL}/${audit.id}/control-panel/dashboard`);
  }
  function handleAcceptTerms(acceptedAudit) {
    goToControlPanel(acceptedAudit);
    hideTermsAcceptance();
  }
  function handleRejectTerms() {
    service.invalidateQueries();
    hideTermsAcceptance();
  }
  const menuOptions = useCallback((audit) => [
    {
      type: "single",
      key: "control",
      text: "Detalhar",
      onClick: () => {
        const userAuditor = audit.auditores.find(({
          usuarioId
        }) => usuarioId === currentUser?.id);
        if (!currentUser?.administrator && userAuditor?.situacao === 0 || currentUser?.administrator && userAuditor && userAuditor?.situacao === 0) {
          setSelectedAudit(audit);
          showTermsAcceptance();
          return;
        }
        goToControlPanel(audit);
      }
    }
    // {
    //   key: 'history',
    //   text: 'Histórico',
    //   onClick: () => openHistory(audit),
    // },
  ], [currentUser]);
  useEffect(() => {
    setGlobalLoading(isLoading);
  }, [isLoading]);
  if (error)
    return /* @__PURE__ */ jsxDEV(ErrorScreen, { error }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
      lineNumber: 102,
      columnNumber: 21
    }, this);
  return /* @__PURE__ */ jsxDEV(ErrorBoundary, { fallbackRender: ({
    error: error2
  }) => /* @__PURE__ */ jsxDEV(ErrorScreen, { error: error2 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
    lineNumber: 105,
    columnNumber: 9
  }, this), children: [
    /* @__PURE__ */ jsxDEV(DataTableInt, { items: data?.value, itemsCount: data?.["@odata.count"], columns, paginated: true, onPageChange: setPaginationConfig, sortConfig, onSortChange: setSortConfig, loading: isLoading, hasSearch: true, onSearchTextChange: filterData, hasControlsColumn: true, menuOptions, hasSelection: false }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    selectedAudit && termsAcceptanceModal && /* @__PURE__ */ jsxDEV(AcceptTermsModal, { contractId: selectedAudit.contrato?.id, isOpen: termsAcceptanceModal, onDismiss: hideTermsAcceptance, onReject: handleRejectTerms, onAccept: () => handleAcceptTerms(selectedAudit) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
      lineNumber: 122,
      columnNumber: 49
    }, this),
    historyModal && /* @__PURE__ */ jsxDEV(AuditHistoryModal, { isOpen: historyModal, onDismiss: hideHistory, auditId: auditToShowHistory }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
      lineNumber: 123,
      columnNumber: 24
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
    lineNumber: 103,
    columnNumber: 10
  }, this);
};
_s(AuditsList, "DG8d2BIhSBiRREvxvBo/kKK9WFk=", false, function() {
  return [useAuth, service.useFindAllPaginated, useBoolean, useBoolean];
});
_c = AuditsList;
const columns = [{
  header: "Cliente",
  field: "contrato.cliente.nomeFantasia",
  filterable: true,
  type: "string",
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  }
}, {
  header: "Contrato",
  field: "contrato.numeroProposta",
  filterable: true,
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default",
    replace: (value) => value.replaceAll("-", "")
  },
  type: "string",
  format: (item) => formatProposalNumber(item.contrato?.numeroProposta)
}, {
  header: "CNPJ",
  field: "contrato.empresas",
  type: "string",
  filterOptions: {
    queryType: "listCnpjInContract",
    queryMode: "default"
  },
  blockShowing: true,
  filterable: true,
  sortable: true
}, {
  header: "Tipo de contrato",
  field: "contrato.tipoContrato",
  filterable: true,
  sortable: true,
  type: "string",
  format: (item) => ContractTypeRecord[item.contrato?.tipoContrato],
  filterOptions: {
    queryType: "record",
    queryMode: "default",
    record: ContractTypeRecord
  }
}, {
  header: "Exercício",
  field: "contrato.exercicio",
  filterable: true,
  type: "number",
  sortable: true,
  filterOptions: {
    queryType: "number",
    queryMode: "default"
  }
}, {
  header: "Empresa",
  field: "contrato.empresas",
  format: (item) => {
    if (item.contrato?.empresas.length !== 0) {
      const companies = item.contrato?.empresas.map((company) => {
        return company?.empresa?.razaoSocial;
      }).join(", ");
      return /* @__PURE__ */ jsxDEV(TooltipHost, { directionalHint: DirectionalHint.leftCenter, content: companies, children: companies }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
        lineNumber: 193,
        columnNumber: 14
      }, this);
    }
  },
  filterable: true,
  type: "string",
  sortable: true,
  filterOptions: {
    queryType: "listRazaoSocialInContract",
    queryMode: "default"
  }
}, {
  header: "Responsável técnico",
  field: "contrato.responsavelTecnico.nome",
  filterable: true,
  type: "string",
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  }
}, {
  header: "Responsável cliente",
  field: "contrato.responsavelCliente.nome",
  filterable: true,
  type: "string",
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  }
}, {
  header: "Situação",
  field: "situacao",
  format: (item) => {
    if (item.situacao !== void 0) {
      return /* @__PURE__ */ jsxDEV(AuditsSituation, { situation: item.situacao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx",
        lineNumber: 230,
        columnNumber: 14
      }, this);
    }
  }
}];
export default AuditsList;
var _c;
$RefreshReg$(_c, "AuditsList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEhvQjs7Ozs7Ozs7Ozs7Ozs7OztBQTFIcEIsU0FBYUEsYUFBYUMsWUFBWUMsV0FBV0MsZ0JBQWdCO0FBQ2pFLFNBQVNDLHVCQUE0QztBQUNyRCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQTBCQyxjQUE4REMsYUFBYUMsbUJBQW1CO0FBQ3hILFNBQVNDLHFCQUFxQkMsZUFBZTtBQUU3QyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsbUJBQW1CQyx1QkFBdUI7QUFDbkQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxzQkFBc0JDLCtCQUErQjtBQUM5RCxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsMEJBQTBCO0FBRW5DLFNBQVNDLDBCQUEwQjtBQUVuQyxNQUFNQyxhQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU07QUFBQSxJQUFFQyxnQkFBZ0I7QUFBQSxNQUFFQyxPQUFPQztBQUFBQSxJQUFZO0FBQUEsRUFBRSxJQUFJVixRQUFRO0FBQzNELFFBQU07QUFBQSxJQUFFVyxjQUFjQztBQUFBQSxFQUFpQixJQUFJMUIsV0FBV2lCLGtCQUFrQjtBQUN4RSxRQUFNLENBQUNVLGtCQUFrQkMsbUJBQW1CLElBQUkxQixTQUFvQztBQUFBLElBQ2xGMkIsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFFRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSTlCLFNBQThCO0FBQUEsSUFDaEUrQixPQUFPO0FBQUEsSUFDUEMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbEMsU0FBaUI7QUFDN0MsUUFBTTtBQUFBLElBQUNtQztBQUFBQTtBQUFBQSxFQUFrQixJQUFpQ25DLFNBQWlCLEVBQUU7QUFFN0UsUUFBTW9DLGFBQWFDLE9BQU9DLFNBQVNDO0FBRW5DLFFBQU1DLGFBQWEzQyxZQUFZLENBQUN3QixVQUF3QjtBQUN0RGEsY0FBVXBCLHdCQUF3QjJCLFNBQVNwQixLQUFLLENBQUM7QUFBQSxFQUNuRCxHQUFHLENBQUNhLFdBQVdPLFNBQVNSLE1BQU0sQ0FBQztBQUUvQixRQUFNO0FBQUEsSUFBRVM7QUFBQUEsSUFBV0M7QUFBQUEsSUFBT0M7QUFBQUEsRUFBSyxJQUFJcEMsUUFBUXFDLG9CQUFvQjtBQUFBLElBQzdEQyxPQUFPckIsaUJBQWlCRTtBQUFBQSxJQUN4Qm9CLE1BQU10QixpQkFBaUJHO0FBQUFBLElBQ3ZCb0IsU0FBVSxlQUFjL0IsbUJBQW1CZ0MsYUFBYWhCLFNBQVUsUUFBT0EsWUFBWTtBQUFBLElBQ3JGaUIsVUFBVyxHQUFFckIsV0FBV0UsT0FBT29CLFdBQVcsS0FBSyxHQUFHLEtBQUt0QixXQUFXRyxhQUFhLFNBQVM7QUFBQSxFQUMxRixDQUFDO0FBRUQsUUFBTSxDQUNKb0Isc0JBQ0E7QUFBQSxJQUFFQyxTQUFTQztBQUFBQSxJQUFxQkMsVUFBVUM7QUFBQUEsRUFBb0IsQ0FBQyxJQUM3RHRELFdBQVcsS0FBSztBQUVwQixRQUFNLENBQ0p1RCxjQUNBO0FBQUE7QUFBQSxJQUVFRixVQUFVRztBQUFBQSxFQUNaLENBQUMsSUFDQ3hELFdBQVcsS0FBSztBQUVwQixRQUFNLENBQUN5RCxlQUFlQyxnQkFBZ0IsSUFBSTVELFNBQWdCO0FBRTFELFdBQVM2RCxpQkFBa0JDLE9BQWM7QUFDdkN6QixXQUFPMEIsS0FBTSxHQUFFM0IsY0FBYzBCLE1BQU1FLDRCQUE0QjtBQUFBLEVBQ2pFO0FBT0EsV0FBU0Msa0JBQW1CQyxlQUFzQjtBQUNoREwscUJBQWlCSyxhQUFhO0FBQzlCVix3QkFBb0I7QUFBQSxFQUN0QjtBQUVBLFdBQVNXLG9CQUFxQjtBQUM1QjNELFlBQVE0RCxrQkFBa0I7QUFDMUJaLHdCQUFvQjtBQUFBLEVBQ3RCO0FBRUEsUUFBTWEsY0FBY3hFLFlBQ2xCLENBQUNpRSxVQUF3QztBQUFBLElBQ3ZDO0FBQUEsTUFDRVEsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsU0FBU0EsTUFBTTtBQUNiLGNBQU1DLGNBQWNaLE1BQU1hLFVBQVVDLEtBQ2xDLENBQUM7QUFBQSxVQUFFQztBQUFBQSxRQUFVLE1BQU1BLGNBQWN2RCxhQUFhMEMsRUFDaEQ7QUFFQSxZQUVJLENBQUMxQyxhQUFhd0QsaUJBQ2RKLGFBQWFLLGFBQWEsS0FHMUJ6RCxhQUFhd0QsaUJBQ2JKLGVBQ0FBLGFBQWFLLGFBQWEsR0FFNUI7QUFDQW5CLDJCQUFpQkUsS0FBSztBQUN0QlIsOEJBQW9CO0FBQ3BCO0FBQUEsUUFDRjtBQUVBTyx5QkFBaUJDLEtBQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxHQUVGLENBQUN4QyxXQUFXLENBQ2Q7QUFFQXZCLFlBQVUsTUFBTTtBQUNkeUIscUJBQWlCa0IsU0FBUztBQUFBLEVBQzVCLEdBQUcsQ0FBQ0EsU0FBUyxDQUFDO0FBRWQsTUFBSUM7QUFBTyxXQUFPLHVCQUFDLGVBQVksU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBRTVDLFNBQ0UsdUJBQUMsaUJBQ0MsZ0JBQWdCLENBQUM7QUFBQSxJQUFFQTtBQUFBQSxFQUFNLE1BQ3ZCLHVCQUFDLGVBQVksT0FBT0EsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQixHQWlCNUI7QUFBQSwyQkFBQyxnQkFDQyxPQUFPQyxNQUFNdkIsT0FDYixZQUFZdUIsT0FBTyxjQUFjLEdBQ2pDLFNBQ0EsV0FBUyxNQUNULGNBQWNsQixxQkFDZCxZQUNBLGNBQWNJLGVBQ2QsU0FBU1ksV0FDVCxXQUFTLE1BQ1Qsb0JBQW9CRixZQUNwQixtQkFBaUIsTUFDakIsYUFDQSxjQUFjLFNBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0Fhc0I7QUFBQSxJQUdyQm1CLGlCQUFpQlAsd0JBQ2hCLHVCQUFDLG9CQUNDLFlBQVlPLGNBQWNxQixVQUFVaEIsSUFDcEMsUUFBUVosc0JBQ1IsV0FBV0kscUJBQ1gsVUFBVVcsbUJBQ1YsVUFBVSxNQUFNRixrQkFBa0JOLGFBQWEsS0FMakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUttRDtBQUFBLElBR3BERixnQkFDQyx1QkFBQyxxQkFDQyxRQUFRQSxjQUNSLFdBQVdDLGFBQ1gsU0FBU3ZCLHNCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHOEI7QUFBQSxPQWhEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1EQTtBQUVKO0FBQUNoQixHQWxLS0QsWUFBYztBQUFBLFVBQ2lDTixTQXFCaEJKLFFBQVFxQyxxQkFVdkMzQyxZQVFBQSxVQUFVO0FBQUE7QUFBQStFLEtBeENWL0Q7QUFvS04sTUFBTXVCLFVBQW9DLENBQ3hDO0FBQUEsRUFDRXlDLFFBQVE7QUFBQSxFQUNSbkQsT0FBTztBQUFBLEVBQ1BvRCxZQUFZO0FBQUEsRUFDWmIsTUFBTTtBQUFBLEVBQ05jLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQ0YsR0FDQTtBQUFBLEVBQ0VMLFFBQVE7QUFBQSxFQUNSbkQsT0FBTztBQUFBLEVBQ1BvRCxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUFBLEVBQ1ZDLGVBQWU7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFNBQVNBLENBQUNuRSxVQUFpQkEsTUFBTThCLFdBQVcsS0FBSyxFQUFFO0FBQUEsRUFDckQ7QUFBQSxFQUNBbUIsTUFBTTtBQUFBLEVBQ05tQixRQUFRQSxDQUFDQyxTQUFnQjdFLHFCQUFxQjZFLEtBQUtWLFVBQVVXLGNBQXdCO0FBQ3ZGLEdBQ0E7QUFBQSxFQUNFVCxRQUFRO0FBQUEsRUFDUm5ELE9BQU87QUFBQSxFQUNQdUMsTUFBTTtBQUFBLEVBQ05lLGVBQWU7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLEVBQ2I7QUFBQSxFQUNBSyxjQUFjO0FBQUEsRUFDZFQsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUYsUUFBUTtBQUFBLEVBQ1JuRCxPQUFPO0FBQUEsRUFDUG9ELFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVmQsTUFBTTtBQUFBLEVBQ05tQixRQUFRQSxDQUFDQyxTQUFnQjFFLG1CQUFtQjBFLEtBQUtWLFVBQVVhLFlBQWdDO0FBQUEsRUFDM0ZSLGVBQWU7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hPLFFBQVE5RTtBQUFBQSxFQUNWO0FBQ0YsR0FDQTtBQUFBLEVBQ0VrRSxRQUFRO0FBQUEsRUFDUm5ELE9BQU87QUFBQSxFQUNQb0QsWUFBWTtBQUFBLEVBQ1piLE1BQU07QUFBQSxFQUNOYyxVQUFVO0FBQUEsRUFDVkMsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUNGLEdBQ0E7QUFBQSxFQUNFTCxRQUFRO0FBQUEsRUFDUm5ELE9BQU87QUFBQSxFQUNQMEQsUUFBUUEsQ0FBQ0MsU0FBZ0I7QUFDdkIsUUFBSUEsS0FBS1YsVUFBVWUsU0FBU0MsV0FBVyxHQUFHO0FBQ3hDLFlBQU1DLFlBQVlQLEtBQUtWLFVBQVVlLFNBQVNHLElBQUksQ0FBQ0MsWUFBNEI7QUFDekUsZUFBT0EsU0FBU0MsU0FBU0M7QUFBQUEsTUFDM0IsQ0FBQyxFQUFFQyxLQUFLLElBQUk7QUFFWixhQUFPLHVCQUFDLGVBQ04saUJBQWlCckcsZ0JBQWdCc0csWUFDakMsU0FBU04sV0FFUkEsdUJBSkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtQO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBZCxZQUFZO0FBQUEsRUFDWmIsTUFBTTtBQUFBLEVBQ05jLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQ0YsR0FDQTtBQUFBLEVBQ0VMLFFBQVE7QUFBQSxFQUNSbkQsT0FBTztBQUFBLEVBQ1BvRCxZQUFZO0FBQUEsRUFDWmIsTUFBTTtBQUFBLEVBQ05jLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQ0YsR0FDQTtBQUFBLEVBQ0VMLFFBQVE7QUFBQSxFQUNSbkQsT0FBTztBQUFBLEVBQ1BvRCxZQUFZO0FBQUEsRUFDWmIsTUFBTTtBQUFBLEVBQ05jLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQ0YsR0FDQTtBQUFBLEVBQ0VMLFFBQVE7QUFBQSxFQUNSbkQsT0FBTztBQUFBLEVBQ1AwRCxRQUFRQSxDQUFDQyxTQUFnQjtBQUN2QixRQUFJQSxLQUFLWCxhQUFheUIsUUFBVztBQUMvQixhQUFPLHVCQUFDLG1CQUFnQixXQUFXZCxLQUFLWCxZQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUdILGVBQWU3RDtBQUFVLElBQUErRDtBQUFBd0IsYUFBQXhCLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkRpcmVjdGlvbmFsSGludCIsInVzZUJvb2xlYW4iLCJFcnJvckJvdW5kYXJ5IiwiRGF0YVRhYmxlSW50IiwiRXJyb3JTY3JlZW4iLCJUb29sdGlwSG9zdCIsImF1ZGl0UXVlcnlTZXJ2aWNlIiwic2VydmljZSIsIkFjY2VwdFRlcm1zTW9kYWwiLCJBdWRpdEhpc3RvcnlNb2RhbCIsIkF1ZGl0c1NpdHVhdGlvbiIsInVzZUF1dGgiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsImJ1aWxkUXVlcnlGaWx0ZXJEZWZhdWx0IiwiTG9hZGluZ0RhdGFDb250ZXh0IiwiQ29udHJhY3RUeXBlUmVjb3JkIiwiQXVkaXRTaXR1YXRpb25FbnVtIiwiQXVkaXRzTGlzdCIsIl9zIiwiY3VycmVudEFjY291bnQiLCJ2YWx1ZSIsImN1cnJlbnRVc2VyIiwic2V0SXNMb2FkaW5nIiwic2V0R2xvYmFsTG9hZGluZyIsInBhZ2luYXRpb25Db25maWciLCJzZXRQYWdpbmF0aW9uQ29uZmlnIiwiaXRlbXNTa2lwcGVkIiwicGFnZVNpemUiLCJzb3J0Q29uZmlnIiwic2V0U29ydENvbmZpZyIsImZpZWxkIiwiZGVzY2VuZGluZyIsImZpbHRlciIsInNldEZpbHRlciIsImF1ZGl0VG9TaG93SGlzdG9yeSIsImN1cnJlbnRVUkwiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJmaWx0ZXJEYXRhIiwiY29sdW1ucyIsImlzTG9hZGluZyIsImVycm9yIiwiZGF0YSIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCIkc2tpcCIsIiR0b3AiLCIkZmlsdGVyIiwiQ2FuY2VsYWRvIiwiJG9yZGVyYnkiLCJyZXBsYWNlQWxsIiwidGVybXNBY2NlcHRhbmNlTW9kYWwiLCJzZXRUcnVlIiwic2hvd1Rlcm1zQWNjZXB0YW5jZSIsInNldEZhbHNlIiwiaGlkZVRlcm1zQWNjZXB0YW5jZSIsImhpc3RvcnlNb2RhbCIsImhpZGVIaXN0b3J5Iiwic2VsZWN0ZWRBdWRpdCIsInNldFNlbGVjdGVkQXVkaXQiLCJnb1RvQ29udHJvbFBhbmVsIiwiYXVkaXQiLCJvcGVuIiwiaWQiLCJoYW5kbGVBY2NlcHRUZXJtcyIsImFjY2VwdGVkQXVkaXQiLCJoYW5kbGVSZWplY3RUZXJtcyIsImludmFsaWRhdGVRdWVyaWVzIiwibWVudU9wdGlvbnMiLCJ0eXBlIiwia2V5IiwidGV4dCIsIm9uQ2xpY2siLCJ1c2VyQXVkaXRvciIsImF1ZGl0b3JlcyIsImZpbmQiLCJ1c3VhcmlvSWQiLCJhZG1pbmlzdHJhdG9yIiwic2l0dWFjYW8iLCJjb250cmF0byIsIl9jIiwiaGVhZGVyIiwiZmlsdGVyYWJsZSIsInNvcnRhYmxlIiwiZmlsdGVyT3B0aW9ucyIsInF1ZXJ5VHlwZSIsInF1ZXJ5TW9kZSIsInJlcGxhY2UiLCJmb3JtYXQiLCJpdGVtIiwibnVtZXJvUHJvcG9zdGEiLCJibG9ja1Nob3dpbmciLCJ0aXBvQ29udHJhdG8iLCJyZWNvcmQiLCJlbXByZXNhcyIsImxlbmd0aCIsImNvbXBhbmllcyIsIm1hcCIsImNvbXBhbnkiLCJlbXByZXNhIiwicmF6YW9Tb2NpYWwiLCJqb2luIiwibGVmdENlbnRlciIsInVuZGVmaW5lZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0c0xpc3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cy9BdWRpdHNMaXN0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBEaXJlY3Rpb25hbEhpbnQsIElDb250ZXh0dWFsTWVudUl0ZW0gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZUJvb2xlYW4gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtaG9va3MnXHJcbmltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcclxuaW1wb3J0IHsgRGF0YVRhYmxlQ29sdW1uLCBEYXRhVGFibGVJbnQsIERhdGFUYWJsZVBhZ2luYXRpb25Db25maWcsIERhdGFUYWJsZVNvcnRDb25maWcsIEVycm9yU2NyZWVuLCBUb29sdGlwSG9zdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBhdWRpdFF1ZXJ5U2VydmljZSBhcyBzZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcbmltcG9ydCBBdWRpdCBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQXVkaXQnXHJcbmltcG9ydCB7IEFjY2VwdFRlcm1zTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9hZG1pbi9jb250cmFjdHMvY29tcG9uZW50cydcclxuaW1wb3J0IHsgQXVkaXRIaXN0b3J5TW9kYWwsIEF1ZGl0c1NpdHVhdGlvbiB9IGZyb20gJy4nXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9hdXRoL3N0b3JlL2F1dGgnXHJcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyLCBidWlsZFF1ZXJ5RmlsdGVyRGVmYXVsdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgTG9hZGluZ0RhdGFDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbnRleHQvTG9hZGluZ0RhdGFDb250ZXh0J1xyXG5pbXBvcnQgeyBDb250cmFjdFR5cGVSZWNvcmQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvcmVjb3JkJ1xyXG5pbXBvcnQgeyBDb250cmFjdFR5cGVFbnVtIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2VudW1zL0NvbnRyYWN0VHlwZUVudW0nXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcblxyXG5jb25zdCBBdWRpdHNMaXN0OiBGQyA9ICgpID0+IHtcclxuICBjb25zdCB7IGN1cnJlbnRBY2NvdW50OiB7IHZhbHVlOiBjdXJyZW50VXNlciB9IH0gPSB1c2VBdXRoKClcclxuICBjb25zdCB7IHNldElzTG9hZGluZzogc2V0R2xvYmFsTG9hZGluZyB9ID0gdXNlQ29udGV4dChMb2FkaW5nRGF0YUNvbnRleHQpXHJcbiAgY29uc3QgW3BhZ2luYXRpb25Db25maWcsIHNldFBhZ2luYXRpb25Db25maWddID0gdXNlU3RhdGU8RGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZz4oe1xyXG4gICAgaXRlbXNTa2lwcGVkOiAwLFxyXG4gICAgcGFnZVNpemU6IDEwLFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IFtzb3J0Q29uZmlnLCBzZXRTb3J0Q29uZmlnXSA9IHVzZVN0YXRlPERhdGFUYWJsZVNvcnRDb25maWc+KHtcclxuICAgIGZpZWxkOiAnY29udHJhdG8uY2xpZW50ZS5ub21lRmFudGFzaWEnLFxyXG4gICAgZGVzY2VuZGluZzogZmFsc2UsXHJcbiAgfSlcclxuXHJcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oKVxyXG4gIGNvbnN0IFthdWRpdFRvU2hvd0hpc3RvcnkvKiAsIHNldEF1ZGl0VG9TaG93SGlzdG9yeSAqL10gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKVxyXG5cclxuICBjb25zdCBjdXJyZW50VVJMID0gd2luZG93LmxvY2F0aW9uLmhyZWZcclxuXHJcbiAgY29uc3QgZmlsdGVyRGF0YSA9IHVzZUNhbGxiYWNrKCh2YWx1ZTogc3RyaW5nKTogdm9pZCA9PiB7XHJcbiAgICBzZXRGaWx0ZXIoYnVpbGRRdWVyeUZpbHRlckRlZmF1bHQoY29sdW1ucywgdmFsdWUpKVxyXG4gIH0sIFtzZXRGaWx0ZXIsIGNvbHVtbnMsIGZpbHRlcl0pXHJcblxyXG4gIGNvbnN0IHsgaXNMb2FkaW5nLCBlcnJvciwgZGF0YSB9ID0gc2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKHtcclxuICAgICRza2lwOiBwYWdpbmF0aW9uQ29uZmlnLml0ZW1zU2tpcHBlZCxcclxuICAgICR0b3A6IHBhZ2luYXRpb25Db25maWcucGFnZVNpemUsXHJcbiAgICAkZmlsdGVyOiBgc2l0dWFjYW8gbmUgJHtBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvfSAke2ZpbHRlciA/IGBhbmQgKCR7ZmlsdGVyfSlgIDogJyd9YCxcclxuICAgICRvcmRlcmJ5OiBgJHtzb3J0Q29uZmlnLmZpZWxkPy5yZXBsYWNlQWxsKCcuJywgJy8nKX0gJHtzb3J0Q29uZmlnLmRlc2NlbmRpbmcgPyAnZGVzYycgOiAnYXNjJ31gLFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IFtcclxuICAgIHRlcm1zQWNjZXB0YW5jZU1vZGFsLFxyXG4gICAgeyBzZXRUcnVlOiBzaG93VGVybXNBY2NlcHRhbmNlLCBzZXRGYWxzZTogaGlkZVRlcm1zQWNjZXB0YW5jZSB9LFxyXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG5cclxuICBjb25zdCBbXHJcbiAgICBoaXN0b3J5TW9kYWwsXHJcbiAgICB7XHJcbiAgICAgIC8vIHNldFRydWU6IHNob3dIaXN0b3J5LFxyXG4gICAgICBzZXRGYWxzZTogaGlkZUhpc3RvcnksXHJcbiAgICB9LFxyXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRBdWRpdCwgc2V0U2VsZWN0ZWRBdWRpdF0gPSB1c2VTdGF0ZTxBdWRpdD4oKVxyXG5cclxuICBmdW5jdGlvbiBnb1RvQ29udHJvbFBhbmVsIChhdWRpdDogQXVkaXQpIHtcclxuICAgIHdpbmRvdy5vcGVuKGAke2N1cnJlbnRVUkx9LyR7YXVkaXQuaWR9L2NvbnRyb2wtcGFuZWwvZGFzaGJvYXJkYClcclxuICB9XHJcblxyXG4gIC8vIGZ1bmN0aW9uIG9wZW5IaXN0b3J5IChpdGVtOiBBdWRpdCkge1xyXG4gIC8vICAgc2V0QXVkaXRUb1Nob3dIaXN0b3J5KGl0ZW0uaWQgYXMgc3RyaW5nKVxyXG4gIC8vICAgc2hvd0hpc3RvcnkoKVxyXG4gIC8vIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQWNjZXB0VGVybXMgKGFjY2VwdGVkQXVkaXQ6IEF1ZGl0KSB7XHJcbiAgICBnb1RvQ29udHJvbFBhbmVsKGFjY2VwdGVkQXVkaXQpXHJcbiAgICBoaWRlVGVybXNBY2NlcHRhbmNlKClcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZVJlamVjdFRlcm1zICgpIHtcclxuICAgIHNlcnZpY2UuaW52YWxpZGF0ZVF1ZXJpZXMoKVxyXG4gICAgaGlkZVRlcm1zQWNjZXB0YW5jZSgpXHJcbiAgfVxyXG5cclxuICBjb25zdCBtZW51T3B0aW9ucyA9IHVzZUNhbGxiYWNrKFxyXG4gICAgKGF1ZGl0OiBBdWRpdCk6IElDb250ZXh0dWFsTWVudUl0ZW1bXSA9PiBbXHJcbiAgICAgIHtcclxuICAgICAgICB0eXBlOiAnc2luZ2xlJyxcclxuICAgICAgICBrZXk6ICdjb250cm9sJyxcclxuICAgICAgICB0ZXh0OiAnRGV0YWxoYXInLFxyXG4gICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVzZXJBdWRpdG9yID0gYXVkaXQuYXVkaXRvcmVzLmZpbmQoXHJcbiAgICAgICAgICAgICh7IHVzdWFyaW9JZCB9KSA9PiB1c3VhcmlvSWQgPT09IGN1cnJlbnRVc2VyPy5pZCxcclxuICAgICAgICAgIClcclxuXHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICAhY3VycmVudFVzZXI/LmFkbWluaXN0cmF0b3IgJiZcclxuICAgICAgICAgICAgICB1c2VyQXVkaXRvcj8uc2l0dWFjYW8gPT09IDBcclxuICAgICAgICAgICAgKSB8fFxyXG4gICAgICAgICAgICAoXHJcbiAgICAgICAgICAgICAgY3VycmVudFVzZXI/LmFkbWluaXN0cmF0b3IgJiZcclxuICAgICAgICAgICAgICB1c2VyQXVkaXRvciAmJlxyXG4gICAgICAgICAgICAgIHVzZXJBdWRpdG9yPy5zaXR1YWNhbyA9PT0gMFxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRBdWRpdChhdWRpdClcclxuICAgICAgICAgICAgc2hvd1Rlcm1zQWNjZXB0YW5jZSgpXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGdvVG9Db250cm9sUGFuZWwoYXVkaXQpXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgLy8ge1xyXG4gICAgICAvLyAgIGtleTogJ2hpc3RvcnknLFxyXG4gICAgICAvLyAgIHRleHQ6ICdIaXN0w7NyaWNvJyxcclxuICAgICAgLy8gICBvbkNsaWNrOiAoKSA9PiBvcGVuSGlzdG9yeShhdWRpdCksXHJcbiAgICAgIC8vIH0sXHJcbiAgICBdLFxyXG4gICAgW2N1cnJlbnRVc2VyXSxcclxuICApXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRHbG9iYWxMb2FkaW5nKGlzTG9hZGluZylcclxuICB9LCBbaXNMb2FkaW5nXSlcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPEVycm9yU2NyZWVuIGVycm9yPXtlcnJvcn0gLz5cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxFcnJvckJvdW5kYXJ5XHJcbiAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyBlcnJvciB9KSA9PiAoXHJcbiAgICAgICAgPEVycm9yU2NyZWVuIGVycm9yPXtlcnJvcn0gLz5cclxuICAgICAgKX1cclxuICAgID5cclxuICAgICAgey8qIDxEYXRhR3JpZFxyXG4gICAgICAgIGl0ZW1zPXtkYXRhPy52YWx1ZX1cclxuICAgICAgICBpdGVtc0NvdW50PXtkYXRhPy5bJ0BvZGF0YS5jb3VudCddfVxyXG4gICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgcGFnaW5hdGVkXHJcbiAgICAgICAgb25QYWdlQ2hhbmdlPXtzZXRQYWdpbmF0aW9uQ29uZmlnfVxyXG4gICAgICAgIHNvcnRDb25maWc9e3NvcnRDb25maWd9XHJcbiAgICAgICAgb25Tb3J0Q2hhbmdlPXtzZXRTb3J0Q29uZmlnfVxyXG4gICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICBvblNlYXJjaFRleHRDaGFuZ2U9e2ZpbHRlckRhdGF9XHJcbiAgICAgICAgbWVudU9wdGlvbnM9e21lbnVPcHRpb25zfVxyXG4gICAgICAgIHJlc2l6ZWFibGVcclxuICAgICAgICBjb21wYWN0XHJcbiAgICAgIC8+ICovfVxyXG4gICAgICA8RGF0YVRhYmxlSW50XHJcbiAgICAgICAgaXRlbXM9e2RhdGE/LnZhbHVlfVxyXG4gICAgICAgIGl0ZW1zQ291bnQ9e2RhdGE/LlsnQG9kYXRhLmNvdW50J119XHJcbiAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICBwYWdpbmF0ZWRcclxuICAgICAgICBvblBhZ2VDaGFuZ2U9e3NldFBhZ2luYXRpb25Db25maWd9XHJcbiAgICAgICAgc29ydENvbmZpZz17c29ydENvbmZpZ31cclxuICAgICAgICBvblNvcnRDaGFuZ2U9e3NldFNvcnRDb25maWd9XHJcbiAgICAgICAgbG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgIGhhc1NlYXJjaFxyXG4gICAgICAgIG9uU2VhcmNoVGV4dENoYW5nZT17ZmlsdGVyRGF0YX1cclxuICAgICAgICBoYXNDb250cm9sc0NvbHVtblxyXG4gICAgICAgIG1lbnVPcHRpb25zPXttZW51T3B0aW9uc31cclxuICAgICAgICBoYXNTZWxlY3Rpb249e2ZhbHNlfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAge3NlbGVjdGVkQXVkaXQgJiYgdGVybXNBY2NlcHRhbmNlTW9kYWwgJiYgKFxyXG4gICAgICAgIDxBY2NlcHRUZXJtc01vZGFsXHJcbiAgICAgICAgICBjb250cmFjdElkPXtzZWxlY3RlZEF1ZGl0LmNvbnRyYXRvPy5pZCBhcyBzdHJpbmd9XHJcbiAgICAgICAgICBpc09wZW49e3Rlcm1zQWNjZXB0YW5jZU1vZGFsfVxyXG4gICAgICAgICAgb25EaXNtaXNzPXtoaWRlVGVybXNBY2NlcHRhbmNlfVxyXG4gICAgICAgICAgb25SZWplY3Q9e2hhbmRsZVJlamVjdFRlcm1zfVxyXG4gICAgICAgICAgb25BY2NlcHQ9eygpID0+IGhhbmRsZUFjY2VwdFRlcm1zKHNlbGVjdGVkQXVkaXQpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHtoaXN0b3J5TW9kYWwgJiYgKFxyXG4gICAgICAgIDxBdWRpdEhpc3RvcnlNb2RhbFxyXG4gICAgICAgICAgaXNPcGVuPXtoaXN0b3J5TW9kYWx9XHJcbiAgICAgICAgICBvbkRpc21pc3M9e2hpZGVIaXN0b3J5fVxyXG4gICAgICAgICAgYXVkaXRJZD17YXVkaXRUb1Nob3dIaXN0b3J5fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L0Vycm9yQm91bmRhcnk+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBjb2x1bW5zOiBEYXRhVGFibGVDb2x1bW48QXVkaXQ+W10gPSBbXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnQ2xpZW50ZScsXHJcbiAgICBmaWVsZDogJ2NvbnRyYXRvLmNsaWVudGUubm9tZUZhbnRhc2lhJyxcclxuICAgIGZpbHRlcmFibGU6IHRydWUsXHJcbiAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgIHNvcnRhYmxlOiB0cnVlLFxyXG4gICAgZmlsdGVyT3B0aW9uczoge1xyXG4gICAgICBxdWVyeVR5cGU6ICdzdHJpbmcnLFxyXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdDb250cmF0bycsXHJcbiAgICBmaWVsZDogJ2NvbnRyYXRvLm51bWVyb1Byb3Bvc3RhJyxcclxuICAgIGZpbHRlcmFibGU6IHRydWUsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICAgIHJlcGxhY2U6ICh2YWx1ZTpzdHJpbmcpID0+IHZhbHVlLnJlcGxhY2VBbGwoJy0nLCAnJyksXHJcbiAgICB9LFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICBmb3JtYXQ6IChpdGVtOiBBdWRpdCkgPT4gZm9ybWF0UHJvcG9zYWxOdW1iZXIoaXRlbS5jb250cmF0bz8ubnVtZXJvUHJvcG9zdGEgYXMgc3RyaW5nKSxcclxuICB9LFxyXG4gIHtcclxuICAgIGhlYWRlcjogJ0NOUEonLFxyXG4gICAgZmllbGQ6ICdjb250cmF0by5lbXByZXNhcycsXHJcbiAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnbGlzdENucGpJbkNvbnRyYWN0JyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gICAgYmxvY2tTaG93aW5nOiB0cnVlLFxyXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcclxuICAgIHNvcnRhYmxlOiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnVGlwbyBkZSBjb250cmF0bycsXHJcbiAgICBmaWVsZDogJ2NvbnRyYXRvLnRpcG9Db250cmF0bycsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgICB0eXBlOiAnc3RyaW5nJyxcclxuICAgIGZvcm1hdDogKGl0ZW06IEF1ZGl0KSA9PiBDb250cmFjdFR5cGVSZWNvcmRbaXRlbS5jb250cmF0bz8udGlwb0NvbnRyYXRvIGFzIENvbnRyYWN0VHlwZUVudW1dLFxyXG4gICAgZmlsdGVyT3B0aW9uczoge1xyXG4gICAgICBxdWVyeVR5cGU6ICdyZWNvcmQnLFxyXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcclxuICAgICAgcmVjb3JkOiBDb250cmFjdFR5cGVSZWNvcmQsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnRXhlcmPDrWNpbycsXHJcbiAgICBmaWVsZDogJ2NvbnRyYXRvLmV4ZXJjaWNpbycsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgdHlwZTogJ251bWJlcicsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnbnVtYmVyJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnRW1wcmVzYScsXHJcbiAgICBmaWVsZDogJ2NvbnRyYXRvLmVtcHJlc2FzJyxcclxuICAgIGZvcm1hdDogKGl0ZW06IEF1ZGl0KSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLmNvbnRyYXRvPy5lbXByZXNhcy5sZW5ndGggIT09IDApIHtcclxuICAgICAgICBjb25zdCBjb21wYW5pZXMgPSBpdGVtLmNvbnRyYXRvPy5lbXByZXNhcy5tYXAoKGNvbXBhbnk6IFBhcnRpYWw8QXVkaXQ+KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gY29tcGFueT8uZW1wcmVzYT8ucmF6YW9Tb2NpYWxcclxuICAgICAgICB9KS5qb2luKCcsICcpXHJcblxyXG4gICAgICAgIHJldHVybiA8VG9vbHRpcEhvc3RcclxuICAgICAgICAgIGRpcmVjdGlvbmFsSGludD17RGlyZWN0aW9uYWxIaW50LmxlZnRDZW50ZXJ9XHJcbiAgICAgICAgICBjb250ZW50PXtjb21wYW5pZXN9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2NvbXBhbmllc31cclxuICAgICAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcclxuICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgICBmaWx0ZXJPcHRpb25zOiB7XHJcbiAgICAgIHF1ZXJ5VHlwZTogJ2xpc3RSYXphb1NvY2lhbEluQ29udHJhY3QnLFxyXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdSZXNwb25zw6F2ZWwgdMOpY25pY28nLFxyXG4gICAgZmllbGQ6ICdjb250cmF0by5yZXNwb25zYXZlbFRlY25pY28ubm9tZScsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnUmVzcG9uc8OhdmVsIGNsaWVudGUnLFxyXG4gICAgZmllbGQ6ICdjb250cmF0by5yZXNwb25zYXZlbENsaWVudGUubm9tZScsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnU2l0dWHDp8OjbycsXHJcbiAgICBmaWVsZDogJ3NpdHVhY2FvJyxcclxuICAgIGZvcm1hdDogKGl0ZW06IEF1ZGl0KSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnNpdHVhY2FvICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICByZXR1cm4gPEF1ZGl0c1NpdHVhdGlvbiBzaXR1YXRpb249e2l0ZW0uc2l0dWFjYW99IC8+XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgfSxcclxuXVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRzTGlzdFxyXG4iXX0=