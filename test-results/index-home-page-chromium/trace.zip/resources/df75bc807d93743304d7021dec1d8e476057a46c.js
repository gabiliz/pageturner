import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/TestFocusDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TestFocusDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TestFocusEnum } from "/src/shared/enums/TestFocusEnum.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const TestFocusDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Enfoque", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione o enfoque", styles: {
    root: {
      minWidth: 100
    }
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TestFocusDropdown.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = TestFocusDropdown;
const months = [{
  key: TestFocusEnum.CONTABIL,
  text: "Contábil"
}, {
  key: TestFocusEnum.FISCAL,
  text: "Fiscal"
}, {
  key: TestFocusEnum.OPERACIONAL,
  text: "Operacional"
}, {
  key: TestFocusEnum.COMPONENTES,
  text: "Componentes"
}, {
  key: TestFocusEnum.DUE,
  text: "Due diligence"
}];
export default TestFocusDropdown;
var _c;
$RefreshReg$(_c, "TestFocusDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TestFocusDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsb0JBQWtEQyxXQUFVO0FBQ2hFLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLFdBQ04sU0FBU0MsUUFDVCxlQUFlLE1BQ2YsY0FBYSxNQUNiLGFBQVksdUJBQ1osUUFBUTtBQUFBLElBQ05DLE1BQU07QUFBQSxNQUFFQyxVQUFVO0FBQUEsSUFBSTtBQUFBLEVBQ3hCLEdBQ0EsR0FBSUgsU0FUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU1k7QUFHaEI7QUFBQ0ksS0FkS0w7QUFnQk4sTUFBTUUsU0FBNEIsQ0FDaEM7QUFBQSxFQUFFSSxLQUFLUixjQUFjUztBQUFBQSxFQUFVQyxNQUFNO0FBQVcsR0FDaEQ7QUFBQSxFQUFFRixLQUFLUixjQUFjVztBQUFBQSxFQUFRRCxNQUFNO0FBQVMsR0FDNUM7QUFBQSxFQUFFRixLQUFLUixjQUFjWTtBQUFBQSxFQUFhRixNQUFNO0FBQWMsR0FDdEQ7QUFBQSxFQUFFRixLQUFLUixjQUFjYTtBQUFBQSxFQUFhSCxNQUFNO0FBQWMsR0FDdEQ7QUFBQSxFQUFFRixLQUFLUixjQUFjYztBQUFBQSxFQUFLSixNQUFNO0FBQWdCLENBQUM7QUFJbkQsZUFBZVI7QUFBaUIsSUFBQUs7QUFBQVEsYUFBQVIsSUFBQSIsIm5hbWVzIjpbIklDb21ib0JveFByb3BzIiwiVGVzdEZvY3VzRW51bSIsIkNvbWJvQm94IiwiVGVzdEZvY3VzRHJvcGRvd24iLCJwcm9wcyIsIm1vbnRocyIsInJvb3QiLCJtaW5XaWR0aCIsIl9jIiwia2V5IiwiQ09OVEFCSUwiLCJ0ZXh0IiwiRklTQ0FMIiwiT1BFUkFDSU9OQUwiLCJDT01QT05FTlRFUyIsIkRVRSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRlc3RGb2N1c0Ryb3Bkb3duLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2Ryb3Bkb3duc0NvbWJvQm94ZXMvVGVzdEZvY3VzRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBJQ29tYm9Cb3hPcHRpb24sXHJcbiAgSUNvbWJvQm94UHJvcHMsXHJcbn0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBUZXN0Rm9jdXNFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvVGVzdEZvY3VzRW51bSdcclxuaW1wb3J0IHsgQ29tYm9Cb3ggfSBmcm9tICcuLi9jb21ib0JveCdcclxuXHJcbmNvbnN0IFRlc3RGb2N1c0Ryb3Bkb3duOiBGQzxQYXJ0aWFsPElDb21ib0JveFByb3BzPj4gPSAocHJvcHMpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPENvbWJvQm94XHJcbiAgICAgIGxhYmVsPVwiRW5mb3F1ZVwiXHJcbiAgICAgIG9wdGlvbnM9e21vbnRoc31cclxuICAgICAgYWxsb3dGcmVlZm9ybT17dHJ1ZX1cclxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcclxuICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY2lvbmUgbyBlbmZvcXVlXCJcclxuICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgcm9vdDogeyBtaW5XaWR0aDogMTAwIH0sXHJcbiAgICAgIH19XHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCBtb250aHM6IElDb21ib0JveE9wdGlvbltdID0gW1xyXG4gIHsga2V5OiBUZXN0Rm9jdXNFbnVtLkNPTlRBQklMLCB0ZXh0OiAnQ29udMOhYmlsJyB9LFxyXG4gIHsga2V5OiBUZXN0Rm9jdXNFbnVtLkZJU0NBTCwgdGV4dDogJ0Zpc2NhbCcgfSxcclxuICB7IGtleTogVGVzdEZvY3VzRW51bS5PUEVSQUNJT05BTCwgdGV4dDogJ09wZXJhY2lvbmFsJyB9LFxyXG4gIHsga2V5OiBUZXN0Rm9jdXNFbnVtLkNPTVBPTkVOVEVTLCB0ZXh0OiAnQ29tcG9uZW50ZXMnIH0sXHJcbiAgeyBrZXk6IFRlc3RGb2N1c0VudW0uRFVFLCB0ZXh0OiAnRHVlIGRpbGlnZW5jZScgfSxcclxuXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRlc3RGb2N1c0Ryb3Bkb3duXHJcbiJdfQ==