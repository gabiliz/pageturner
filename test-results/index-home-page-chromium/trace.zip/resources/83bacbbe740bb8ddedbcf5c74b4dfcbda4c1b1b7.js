import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/roles/components/RoleEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useFormData } from "/src/shared/hooks/index.ts";
import { FlexColumn, TextField } from "/src/shared/components/index.ts?t=1701096626433";
const emptyRole = {
  nome: "",
  descricao: ""
};
const RoleEditForm = (props) => {
  _s();
  const {
    formData,
    onChange,
    apiError
  } = props;
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange,
    onFieldError
  } = useFormData(formData ?? emptyRole);
  useEffect(() => {
    if (formData) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", required: true, value: localFormData.nome, onChange: onTextChange("nome"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("nome", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleEditForm.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Descrição", required: true, value: localFormData.descricao, onChange: onTextChange("descricao"), multiline: true, rows: 13, resizable: false, maxLength: 255, errorMessage: apiError?.errors?.messages ? onFieldError("descricao", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleEditForm.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleEditForm.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
};
_s(RoleEditForm, "v/498a+4E6gyfrjUT3QsyT0tSTU=", false, function() {
  return [useFormData];
});
_c = RoleEditForm;
export default RoleEditForm;
var _c;
$RefreshReg$(_c, "RoleEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBakNOLFNBQWFBLGlCQUFpQjtBQUc5QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWUMsaUJBQWlCO0FBRXRDLE1BQU1DLFlBQWtCO0FBQUEsRUFDdEJDLE1BQU07QUFBQSxFQUNOQyxXQUFXO0FBQ2I7QUFFQSxNQUFNQyxlQUF5Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3ZELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxFQUFTLElBQUlKO0FBRXpDLFFBQU07QUFBQSxJQUNKRSxVQUFVRztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUloQixZQUFrQlMsWUFBWU4sU0FBUztBQUUzQ0osWUFBVSxNQUFNO0FBQ2QsUUFBSVUsVUFBVTtBQUNaSyx1QkFBaUJMLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYlYsWUFBVSxNQUFNO0FBQ2RXLGVBQVdFLGFBQWE7QUFBQSxFQUMxQixHQUFHLENBQUNBLGFBQWEsQ0FBQztBQUVsQixTQUNFLHVCQUFDLGNBQVcsS0FBTSxJQUNoQjtBQUFBLDJCQUFDLGFBQ0MsT0FBTSxRQUNOLFVBQVEsTUFDUixPQUFPQSxjQUFjUixNQUNyQixVQUFVVyxhQUFhLE1BQU0sR0FDN0IsV0FBVyxLQUNYLGNBQWNKLFVBQVVNLFFBQVFDLFdBQzVCRixhQUFhLFFBQVFMLFVBQVVNLFFBQVFDLFFBQVEsSUFDL0NDLFVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNHO0FBQUEsSUFFSCx1QkFBQyxhQUNDLE9BQU0sYUFDTixVQUFRLE1BQ1IsT0FBT1AsY0FBY1AsV0FDckIsVUFBVVUsYUFBYSxXQUFXLEdBQ2xDLFdBQVMsTUFDVCxNQUFNLElBQ04sV0FBVyxPQUNYLFdBQVcsS0FDWCxjQUFjSixVQUFVTSxRQUFRQyxXQUM1QkYsYUFBYSxhQUFhTCxVQUFVTSxRQUFRQyxRQUFRLElBQ3BEQyxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZRztBQUFBLE9BeEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFDWCxHQWpES0YsY0FBcUM7QUFBQSxVQVFyQ04sV0FBVztBQUFBO0FBQUFvQixLQVJYZDtBQW1ETixlQUFlQTtBQUFZLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VGb3JtRGF0YSIsIkZsZXhDb2x1bW4iLCJUZXh0RmllbGQiLCJlbXB0eVJvbGUiLCJub21lIiwiZGVzY3JpY2FvIiwiUm9sZUVkaXRGb3JtIiwicHJvcHMiLCJfcyIsImZvcm1EYXRhIiwib25DaGFuZ2UiLCJhcGlFcnJvciIsImxvY2FsRm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldExvY2FsRm9ybURhdGEiLCJvblRleHRDaGFuZ2UiLCJvbkZpZWxkRXJyb3IiLCJlcnJvcnMiLCJtZXNzYWdlcyIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUm9sZUVkaXRGb3JtLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vcm9sZXMvY29tcG9uZW50cy9Sb2xlRWRpdEZvcm0udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFJvbGUgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1JvbGUnXG5pbXBvcnQgeyBFZGl0Rm9ybVByb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL0VkaXRGb3JtJ1xuaW1wb3J0IHsgdXNlRm9ybURhdGEgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBUZXh0RmllbGQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcblxuY29uc3QgZW1wdHlSb2xlOiBSb2xlID0ge1xuICBub21lOiAnJyxcbiAgZGVzY3JpY2FvOiAnJyxcbn1cblxuY29uc3QgUm9sZUVkaXRGb3JtOiBGQzxFZGl0Rm9ybVByb3BzPFJvbGU+PiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGZvcm1EYXRhLCBvbkNoYW5nZSwgYXBpRXJyb3IgfSA9IHByb3BzXG5cbiAgY29uc3Qge1xuICAgIGZvcm1EYXRhOiBsb2NhbEZvcm1EYXRhLFxuICAgIHNldEZvcm1EYXRhOiBzZXRMb2NhbEZvcm1EYXRhLFxuICAgIG9uVGV4dENoYW5nZSxcbiAgICBvbkZpZWxkRXJyb3IsXG4gIH0gPSB1c2VGb3JtRGF0YTxSb2xlPihmb3JtRGF0YSA/PyBlbXB0eVJvbGUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZm9ybURhdGEpIHtcbiAgICAgIHNldExvY2FsRm9ybURhdGEoZm9ybURhdGEpXG4gICAgfVxuICB9LCBbZm9ybURhdGFdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb25DaGFuZ2U/Lihsb2NhbEZvcm1EYXRhKVxuICB9LCBbbG9jYWxGb3JtRGF0YV0pXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxuICAgICAgPFRleHRGaWVsZFxuICAgICAgICBsYWJlbD1cIk5vbWVcIlxuICAgICAgICByZXF1aXJlZFxuICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5ub21lfVxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdub21lJyl9XG4gICAgICAgIG1heExlbmd0aD17MTAwfVxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXG4gICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ25vbWUnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcbiAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgICB9XG4gICAgICAvPlxuICAgICAgPFRleHRGaWVsZFxuICAgICAgICBsYWJlbD1cIkRlc2NyacOnw6NvXCJcbiAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEuZGVzY3JpY2FvfVxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdkZXNjcmljYW8nKX1cbiAgICAgICAgbXVsdGlsaW5lXG4gICAgICAgIHJvd3M9ezEzfVxuICAgICAgICByZXNpemFibGU9e2ZhbHNlfVxuICAgICAgICBtYXhMZW5ndGg9ezI1NX1cbiAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xuICAgICAgICAgID8gb25GaWVsZEVycm9yKCdkZXNjcmljYW8nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcbiAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgICB9XG4gICAgICAvPlxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSb2xlRWRpdEZvcm1cbiJdfQ==