import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/modules/SideBarModules.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/SideBarModules.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Nav } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"]; const useMemo = __vite__cjsImport4_react["useMemo"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
const SideBarModules = () => {
  _s();
  const navigate = useNavigate();
  const {
    navStyles,
    adminIconStyles,
    fiscalIconStyles,
    auditorIconStyles,
    monitorIconStyles
  } = useSideBarStyles();
  const {
    module
  } = useParams();
  const {
    hasModule
  } = usePermissions();
  const navLinkGroups = [{
    links: [{
      iconProps: {
        iconName: "CheckList",
        styles: monitorIconStyles()
      },
      key: "backlog-monitor",
      title: "backlog-monitor",
      permission: "backlog-monitor",
      name: "Monitor de pendências",
      url: "/backlog-monitor"
    }, {
      iconProps: {
        iconName: "ContactCard",
        styles: adminIconStyles()
      },
      title: "Administrativo",
      permission: "Administrativo",
      key: "admin",
      name: "Administrativo",
      url: "/admin"
    }, {
      iconProps: {
        iconName: "Money",
        styles: fiscalIconStyles()
      },
      title: "Fiscal",
      permission: "Fiscal",
      key: "fiscal",
      name: "Fiscal",
      url: "/fiscal"
    }, {
      iconProps: {
        iconName: "IssueTracking",
        styles: auditorIconStyles()
      },
      permission: "Auditoria",
      title: "Projetos",
      key: "audit",
      name: "Projetos",
      url: "/audit"
    }]
  }];
  const permissionNav = useMemo(() => {
    return navLinkGroups[0].links.filter((navLink) => navLink.key === "backlog-monitor" || hasModule(navLink.permission));
  }, []);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(item.url);
    }
  };
  return /* @__PURE__ */ jsxDEV(Nav, { groups: [{
    links: permissionNav
  }], styles: navStyles(), onLinkClick: handleClick, selectedKey: module }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/SideBarModules.tsx",
    lineNumber: 77,
    columnNumber: 10
  }, this);
};
_s(SideBarModules, "97le49EioAhAubtHJDQImhjKF0o=", false, function() {
  return [useNavigate, useSideBarStyles, useParams, usePermissions];
});
_c = SideBarModules;
const useSideBarStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  const navStyles = useCallback(() => () => ({
    root: {
      width: "48px",
      height: "100%",
      overflow: "hidden",
      backgroundColor: colors.gray[200],
      ".is-selected .ms-Button-icon": {
        color: colors.blue[300],
        backgroundColor: colors.gray[200]
      }
    },
    linkText: {
      display: "none"
    },
    compositeLink: {
      height: "48px",
      width: "100%"
    },
    link: {
      margin: 0,
      padding: 0,
      backgroundColor: "transparent",
      "& .ms-Button-flexContainer": {
        justifyContent: "center"
      },
      selectors: {
        ":hover .ms-Button-icon": {
          color: colors.blue[300],
          backgroundColor: "transparent"
        },
        ":hover": {
          color: colors.blue[300],
          backgroundColor: "transparent"
        },
        ":focus": {
          backgroundColor: "transparent"
        },
        ":active": {
          backgroundColor: "transparent"
        },
        "::after": {
          borderLeft: `${colors.blue[300]} 2px solid`,
          backgroundColor: "transparent"
        },
        ".is-selected::after": {
          borderLeft: `${colors.blue[300]} 2px solid`,
          color: colors.blue[300]
        }
      }
    }
  }), []);
  const iconStyles = useCallback(() => () => ({
    root: {
      fontSize: "20px",
      height: "20px"
    }
  }), []);
  const monitorIconStyles = useCallback(() => () => ({
    ...iconStyles,
    root: {
      color: colors.primary
    }
  }), []);
  const adminIconStyles = useCallback(() => () => ({
    root: {
      color: colors.blue[600]
    }
  }), []);
  const fiscalIconStyles = useCallback(() => () => ({
    root: {
      color: colors.green[600]
    }
  }), []);
  const auditorIconStyles = useCallback(() => () => ({
    root: {
      color: colors.orange[600]
    }
  }), []);
  return {
    navStyles,
    adminIconStyles,
    fiscalIconStyles,
    auditorIconStyles,
    monitorIconStyles
  };
};
_s2(useSideBarStyles, "sh1q9IiYdxkDUsJerSFL4DrD8Ek=", false, function() {
  return [useTheme];
});
export default SideBarModules;
var _c;
$RefreshReg$(_c, "SideBarModules");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/SideBarModules.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZJOzs7Ozs7Ozs7Ozs7Ozs7O0FBckZKLFNBQTJEQSxXQUFXO0FBQ3RFLFNBQTREQyxhQUFhQyxlQUFlO0FBQ3hGLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZ0JBQWdCO0FBSXpCLE1BQU1DLGlCQUEwQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3BELFFBQU1DLFdBQVdOLFlBQVk7QUFFN0IsUUFBTTtBQUFBLElBQ0pPO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSUMsaUJBQWlCO0FBRXJCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFPLElBQUlaLFVBQVU7QUFFN0IsUUFBTTtBQUFBLElBQUVhO0FBQUFBLEVBQVUsSUFBSVosZUFBZTtBQUVyQyxRQUFNYSxnQkFBaUMsQ0FDckM7QUFBQSxJQUNFQyxPQUFPLENBQ0w7QUFBQSxNQUNFQyxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFSLGtCQUFrQjtBQUFBLE1BQzVCO0FBQUEsTUFDQVMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFYLGdCQUFnQjtBQUFBLE1BQzFCO0FBQUEsTUFDQWEsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaRixLQUFLO0FBQUEsTUFDTEcsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFWLGlCQUFpQjtBQUFBLE1BQzNCO0FBQUEsTUFDQVksT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaRixLQUFLO0FBQUEsTUFDTEcsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFULGtCQUFrQjtBQUFBLE1BQzVCO0FBQUEsTUFDQVksWUFBWTtBQUFBLE1BQ1pELE9BQU87QUFBQSxNQUNQRCxLQUFLO0FBQUEsTUFDTEcsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLENBQUM7QUFBQSxFQUVMLENBQUM7QUFFSCxRQUFNQyxnQkFBZ0IxQixRQUFRLE1BQU07QUFDbEMsV0FBT2dCLGNBQWMsQ0FBQyxFQUFFQyxNQUFNVSxPQUFPQyxhQUFXQSxRQUFRUCxRQUFRLHFCQUFxQk4sVUFBVWEsUUFBUUwsVUFBb0IsQ0FBQztBQUFBLEVBQzlILEdBQUcsRUFBRTtBQUVMLFFBQU1NLGNBQWNBLENBQUNDLElBQTZCQyxTQUFnQztBQUNoRixRQUFJRCxPQUFPRSxVQUFhRCxTQUFTQyxRQUFXO0FBQzFDRixTQUFHRyxlQUFlO0FBQ2xCMUIsZUFBU3dCLEtBQUtOLEdBQUc7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLE9BQ0MsUUFBUSxDQUFDO0FBQUEsSUFBRVIsT0FBT1M7QUFBQUEsRUFBYyxDQUFDLEdBQ2pDLFFBQVFsQixVQUFVLEdBQ2xCLGFBQWFxQixhQUNiLGFBQWFmLFVBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlzQjtBQUcxQjtBQUFDUixHQXBGS0QsZ0JBQXVDO0FBQUEsVUFDMUJKLGFBUWJZLGtCQUVlWCxXQUVHQyxjQUFjO0FBQUE7QUFBQStCLEtBYmhDN0I7QUFzRk4sTUFBTVEsbUJBQW1CQSxNQUFNO0FBQUFzQixNQUFBO0FBQzdCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFPLElBQUloQyxTQUFTO0FBRTVCLFFBQU1JLFlBQVlULFlBQVksTUFBTSxPQUE0QjtBQUFBLElBQzlEc0MsTUFBTTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLGlCQUFpQkwsT0FBT00sS0FBSyxHQUFHO0FBQUEsTUFFaEMsZ0NBQWdDO0FBQUEsUUFDOUJDLE9BQU9QLE9BQU9RLEtBQUssR0FBRztBQUFBLFFBQ3RCSCxpQkFBaUJMLE9BQU9NLEtBQUssR0FBRztBQUFBLE1BQ2xDO0FBQUEsSUFDRjtBQUFBLElBQ0FHLFVBQVU7QUFBQSxNQUNSQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0FDLGVBQWU7QUFBQSxNQUNiUixRQUFRO0FBQUEsTUFDUkQsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBVSxNQUFNO0FBQUEsTUFDSkMsUUFBUTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxNQUNUVCxpQkFBaUI7QUFBQSxNQUNqQiw4QkFBOEI7QUFBQSxRQUM1QlUsZ0JBQWdCO0FBQUEsTUFDbEI7QUFBQSxNQUNBQyxXQUFXO0FBQUEsUUFDVCwwQkFBMEI7QUFBQSxVQUN4QlQsT0FBT1AsT0FBT1EsS0FBSyxHQUFHO0FBQUEsVUFDdEJILGlCQUFpQjtBQUFBLFFBQ25CO0FBQUEsUUFDQSxVQUFVO0FBQUEsVUFDUkUsT0FBT1AsT0FBT1EsS0FBSyxHQUFHO0FBQUEsVUFDdEJILGlCQUFpQjtBQUFBLFFBQ25CO0FBQUEsUUFDQSxVQUFVO0FBQUEsVUFDUkEsaUJBQWlCO0FBQUEsUUFDbkI7QUFBQSxRQUNBLFdBQVc7QUFBQSxVQUNUQSxpQkFBaUI7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsV0FBVztBQUFBLFVBQ1RZLFlBQWEsR0FBRWpCLE9BQU9RLEtBQUssR0FBRztBQUFBLFVBQzlCSCxpQkFBaUI7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsdUJBQXVCO0FBQUEsVUFDckJZLFlBQWEsR0FBRWpCLE9BQU9RLEtBQUssR0FBRztBQUFBLFVBQzlCRCxPQUFPUCxPQUFPUSxLQUFLLEdBQUc7QUFBQSxRQUN4QjtBQUFBLE1BRUY7QUFBQSxJQUNGO0FBQUEsRUFDRixJQUFJLEVBQUU7QUFFTixRQUFNVSxhQUFhdkQsWUFBWSxNQUFNLE9BQTZCO0FBQUEsSUFDaEVzQyxNQUFNO0FBQUEsTUFDSmtCLFVBQVU7QUFBQSxNQUNWaEIsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGLElBQUksRUFBRTtBQUVOLFFBQU0zQixvQkFBb0JiLFlBQVksTUFBTSxPQUE2QjtBQUFBLElBQ3ZFLEdBQUd1RDtBQUFBQSxJQUNIakIsTUFBTTtBQUFBLE1BQ0pNLE9BQU9QLE9BQU9vQjtBQUFBQSxJQUNoQjtBQUFBLEVBQ0YsSUFBSSxFQUFFO0FBRU4sUUFBTS9DLGtCQUFrQlYsWUFBWSxNQUFNLE9BQTZCO0FBQUEsSUFDckVzQyxNQUFNO0FBQUEsTUFDSk0sT0FBT1AsT0FBT1EsS0FBSyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGLElBQUksRUFBRTtBQUVOLFFBQU1sQyxtQkFBbUJYLFlBQVksTUFBTSxPQUE2QjtBQUFBLElBQ3RFc0MsTUFBTTtBQUFBLE1BQ0pNLE9BQU9QLE9BQU9xQixNQUFNLEdBQUc7QUFBQSxJQUN6QjtBQUFBLEVBQ0YsSUFBSSxFQUFFO0FBRU4sUUFBTTlDLG9CQUFvQlosWUFBWSxNQUFNLE9BQTZCO0FBQUEsSUFDdkVzQyxNQUFNO0FBQUEsTUFDSk0sT0FBT1AsT0FBT3NCLE9BQU8sR0FBRztBQUFBLElBQzFCO0FBQUEsRUFDRixJQUFJLEVBQUU7QUFFTixTQUFPO0FBQUEsSUFDTGxEO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0Y7QUFDRjtBQUFDdUIsSUFoR0t0QixrQkFBZ0I7QUFBQSxVQUNEVCxRQUFRO0FBQUE7QUFpRzdCLGVBQWVDO0FBQWMsSUFBQTZCO0FBQUF5QixhQUFBekIsSUFBQSIsIm5hbWVzIjpbIk5hdiIsInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlUGVybWlzc2lvbnMiLCJ1c2VUaGVtZSIsIlNpZGVCYXJNb2R1bGVzIiwiX3MiLCJuYXZpZ2F0ZSIsIm5hdlN0eWxlcyIsImFkbWluSWNvblN0eWxlcyIsImZpc2NhbEljb25TdHlsZXMiLCJhdWRpdG9ySWNvblN0eWxlcyIsIm1vbml0b3JJY29uU3R5bGVzIiwidXNlU2lkZUJhclN0eWxlcyIsIm1vZHVsZSIsImhhc01vZHVsZSIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsImljb25Qcm9wcyIsImljb25OYW1lIiwic3R5bGVzIiwia2V5IiwidGl0bGUiLCJwZXJtaXNzaW9uIiwibmFtZSIsInVybCIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXIiLCJuYXZMaW5rIiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsIl9jIiwiX3MyIiwiY29sb3JzIiwicm9vdCIsIndpZHRoIiwiaGVpZ2h0Iiwib3ZlcmZsb3ciLCJiYWNrZ3JvdW5kQ29sb3IiLCJncmF5IiwiY29sb3IiLCJibHVlIiwibGlua1RleHQiLCJkaXNwbGF5IiwiY29tcG9zaXRlTGluayIsImxpbmsiLCJtYXJnaW4iLCJwYWRkaW5nIiwianVzdGlmeUNvbnRlbnQiLCJzZWxlY3RvcnMiLCJib3JkZXJMZWZ0IiwiaWNvblN0eWxlcyIsImZvbnRTaXplIiwicHJpbWFyeSIsImdyZWVuIiwib3JhbmdlIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2lkZUJhck1vZHVsZXMudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbW9kdWxlcy9TaWRlQmFyTW9kdWxlcy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJSWNvblN0eWxlcywgSU5hdkxpbmssIElOYXZMaW5rR3JvdXAsIElOYXZTdHlsZXMsIE5hdiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDLCBIVE1MQXR0cmlidXRlcywgTW91c2VFdmVudCwgUHJvcHNXaXRoQ2hpbGRyZW4sIHVzZUNhbGxiYWNrLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcblxudHlwZSBTaWRlQmFyTW9kdWxlc1Byb3BzID0gUHJvcHNXaXRoQ2hpbGRyZW48SFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+PlxuXG5jb25zdCBTaWRlQmFyTW9kdWxlczogRkM8U2lkZUJhck1vZHVsZXNQcm9wcz4gPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuXG4gIGNvbnN0IHtcbiAgICBuYXZTdHlsZXMsXG4gICAgYWRtaW5JY29uU3R5bGVzLFxuICAgIGZpc2NhbEljb25TdHlsZXMsXG4gICAgYXVkaXRvckljb25TdHlsZXMsXG4gICAgbW9uaXRvckljb25TdHlsZXMsXG4gIH0gPSB1c2VTaWRlQmFyU3R5bGVzKClcblxuICBjb25zdCB7IG1vZHVsZSB9ID0gdXNlUGFyYW1zKClcblxuICBjb25zdCB7IGhhc01vZHVsZSB9ID0gdXNlUGVybWlzc2lvbnMoKVxuXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IFtcbiAgICB7XG4gICAgICBsaW5rczogW1xuICAgICAgICB7XG4gICAgICAgICAgaWNvblByb3BzOiB7XG4gICAgICAgICAgICBpY29uTmFtZTogJ0NoZWNrTGlzdCcsXG4gICAgICAgICAgICBzdHlsZXM6IG1vbml0b3JJY29uU3R5bGVzKCksXG4gICAgICAgICAgfSxcbiAgICAgICAgICBrZXk6ICdiYWNrbG9nLW1vbml0b3InLFxuICAgICAgICAgIHRpdGxlOiAnYmFja2xvZy1tb25pdG9yJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnYmFja2xvZy1tb25pdG9yJyxcbiAgICAgICAgICBuYW1lOiAnTW9uaXRvciBkZSBwZW5kw6puY2lhcycsXG4gICAgICAgICAgdXJsOiAnL2JhY2tsb2ctbW9uaXRvcicsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBpY29uUHJvcHM6IHtcbiAgICAgICAgICAgIGljb25OYW1lOiAnQ29udGFjdENhcmQnLFxuICAgICAgICAgICAgc3R5bGVzOiBhZG1pbkljb25TdHlsZXMoKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpdGxlOiAnQWRtaW5pc3RyYXRpdm8nLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBZG1pbmlzdHJhdGl2bycsXG4gICAgICAgICAga2V5OiAnYWRtaW4nLFxuICAgICAgICAgIG5hbWU6ICdBZG1pbmlzdHJhdGl2bycsXG4gICAgICAgICAgdXJsOiAnL2FkbWluJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGljb25Qcm9wczoge1xuICAgICAgICAgICAgaWNvbk5hbWU6ICdNb25leScsXG4gICAgICAgICAgICBzdHlsZXM6IGZpc2NhbEljb25TdHlsZXMoKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpdGxlOiAnRmlzY2FsJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnRmlzY2FsJyxcbiAgICAgICAgICBrZXk6ICdmaXNjYWwnLFxuICAgICAgICAgIG5hbWU6ICdGaXNjYWwnLFxuICAgICAgICAgIHVybDogJy9maXNjYWwnLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgaWNvblByb3BzOiB7XG4gICAgICAgICAgICBpY29uTmFtZTogJ0lzc3VlVHJhY2tpbmcnLFxuICAgICAgICAgICAgc3R5bGVzOiBhdWRpdG9ySWNvblN0eWxlcygpLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdGl0bGU6ICdQcm9qZXRvcycsXG4gICAgICAgICAga2V5OiAnYXVkaXQnLFxuICAgICAgICAgIG5hbWU6ICdQcm9qZXRvcycsXG4gICAgICAgICAgdXJsOiAnL2F1ZGl0JyxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSxcbiAgXVxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIG5hdkxpbmtHcm91cHNbMF0ubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gbmF2TGluay5rZXkgPT09ICdiYWNrbG9nLW1vbml0b3InIHx8IGhhc01vZHVsZShuYXZMaW5rLnBlcm1pc3Npb24gYXMgc3RyaW5nKSlcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoZXY/OiBNb3VzZUV2ZW50IHwgdW5kZWZpbmVkLCBpdGVtPzogSU5hdkxpbmsgfCB1bmRlZmluZWQpID0+IHtcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcbiAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPE5hdlxuICAgICAgZ3JvdXBzPXtbeyBsaW5rczogcGVybWlzc2lvbk5hdiB9XX1cbiAgICAgIHN0eWxlcz17bmF2U3R5bGVzKCl9XG4gICAgICBvbkxpbmtDbGljaz17aGFuZGxlQ2xpY2t9XG4gICAgICBzZWxlY3RlZEtleT17bW9kdWxlfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgdXNlU2lkZUJhclN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcblxuICBjb25zdCBuYXZTdHlsZXMgPSB1c2VDYWxsYmFjaygoKSA9PiAoKTogUGFydGlhbDxJTmF2U3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIHdpZHRoOiAnNDhweCcsXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcblxuICAgICAgJy5pcy1zZWxlY3RlZCAubXMtQnV0dG9uLWljb24nOiB7XG4gICAgICAgIGNvbG9yOiBjb2xvcnMuYmx1ZVszMDBdLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgbGlua1RleHQ6IHtcbiAgICAgIGRpc3BsYXk6ICdub25lJyxcbiAgICB9LFxuICAgIGNvbXBvc2l0ZUxpbms6IHtcbiAgICAgIGhlaWdodDogJzQ4cHgnLFxuICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICB9LFxuICAgIGxpbms6IHtcbiAgICAgIG1hcmdpbjogMCxcbiAgICAgIHBhZGRpbmc6IDAsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICAnJiAubXMtQnV0dG9uLWZsZXhDb250YWluZXInOiB7XG4gICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICAgIH0sXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJzpob3ZlciAubXMtQnV0dG9uLWljb24nOiB7XG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5ibHVlWzMwMF0sXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICB9LFxuICAgICAgICAnOmhvdmVyJzoge1xuICAgICAgICAgIGNvbG9yOiBjb2xvcnMuYmx1ZVszMDBdLFxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcbiAgICAgICAgfSxcbiAgICAgICAgJzpmb2N1cyc6IHtcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgIH0sXG4gICAgICAgICc6YWN0aXZlJzoge1xuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcbiAgICAgICAgfSxcbiAgICAgICAgJzo6YWZ0ZXInOiB7XG4gICAgICAgICAgYm9yZGVyTGVmdDogYCR7Y29sb3JzLmJsdWVbMzAwXX0gMnB4IHNvbGlkYCxcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgIH0sXG4gICAgICAgICcuaXMtc2VsZWN0ZWQ6OmFmdGVyJzoge1xuICAgICAgICAgIGJvcmRlckxlZnQ6IGAke2NvbG9ycy5ibHVlWzMwMF19IDJweCBzb2xpZGAsXG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5ibHVlWzMwMF0sXG4gICAgICAgIH0sXG5cbiAgICAgIH0sXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIGNvbnN0IGljb25TdHlsZXMgPSB1c2VDYWxsYmFjaygoKSA9PiAoKTogUGFydGlhbDxJSWNvblN0eWxlcz4gPT4gKHtcbiAgICByb290OiB7XG4gICAgICBmb250U2l6ZTogJzIwcHgnLFxuICAgICAgaGVpZ2h0OiAnMjBweCcsXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIGNvbnN0IG1vbml0b3JJY29uU3R5bGVzID0gdXNlQ2FsbGJhY2soKCkgPT4gKCk6IFBhcnRpYWw8SUljb25TdHlsZXM+ID0+ICh7XG4gICAgLi4uaWNvblN0eWxlcyxcbiAgICByb290OiB7XG4gICAgICBjb2xvcjogY29sb3JzLnByaW1hcnksXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIGNvbnN0IGFkbWluSWNvblN0eWxlcyA9IHVzZUNhbGxiYWNrKCgpID0+ICgpOiBQYXJ0aWFsPElJY29uU3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMuYmx1ZVs2MDBdLFxuICAgIH0sXG4gIH0pLCBbXSlcblxuICBjb25zdCBmaXNjYWxJY29uU3R5bGVzID0gdXNlQ2FsbGJhY2soKCkgPT4gKCk6IFBhcnRpYWw8SUljb25TdHlsZXM+ID0+ICh7XG4gICAgcm9vdDoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ncmVlbls2MDBdLFxuICAgIH0sXG4gIH0pLCBbXSlcblxuICBjb25zdCBhdWRpdG9ySWNvblN0eWxlcyA9IHVzZUNhbGxiYWNrKCgpID0+ICgpOiBQYXJ0aWFsPElJY29uU3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMub3JhbmdlWzYwMF0sXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIHJldHVybiB7XG4gICAgbmF2U3R5bGVzLFxuICAgIGFkbWluSWNvblN0eWxlcyxcbiAgICBmaXNjYWxJY29uU3R5bGVzLFxuICAgIGF1ZGl0b3JJY29uU3R5bGVzLFxuICAgIG1vbml0b3JJY29uU3R5bGVzLFxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNpZGVCYXJNb2R1bGVzXG4iXX0=