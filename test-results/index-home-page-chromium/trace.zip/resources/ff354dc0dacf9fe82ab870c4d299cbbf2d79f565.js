import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserRoleEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useFormData } from "/src/shared/hooks/index.ts";
import { RolesDropdown } from "/src/modules/admin/roles/components/index.ts?t=1701096626433";
import { DatePicker, FlexColumn } from "/src/shared/components/index.ts?t=1701096626433";
const emptyUserRole = {
  usuarioId: void 0,
  cargoId: void 0,
  dataInicial: void 0,
  dataFinal: void 0
};
const UserRoleEditForm = (props) => {
  _s();
  const {
    formData,
    onChange,
    apiError
  } = props;
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onDropdownChange,
    onDateChange,
    onFieldError
  } = useFormData(formData ?? emptyUserRole);
  useEffect(() => {
    if (formData) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData, onChange]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(RolesDropdown, { label: "Cargo", selectedKey: localFormData.cargoId ?? "", onChange: onDropdownChange("cargoId"), styles: {
      root: {
        width: "50%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("cargoId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DatePicker, { label: "Data inicial", value: localFormData.dataInicial ? new Date(localFormData.dataInicial) : void 0, allowTextInput: true, onSelectDate: onDateChange("dataInicial"), formatString: "dd/MM/yyyy", styles: {
      root: {
        width: "50%"
      }
    }, textField: {
      errorMessage: apiError?.errors?.messages ? onFieldError("dataInicial", apiError?.errors?.messages) : void 0
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    formData?.id && /* @__PURE__ */ jsxDEV(DatePicker, { label: "Data final", value: localFormData.dataFinal ? new Date(localFormData.dataFinal) : void 0, allowTextInput: true, onSelectDate: onDateChange("dataFinal"), formatString: "dd/MM/yyyy", styles: {
      root: {
        width: "50%"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx",
      lineNumber: 49,
      columnNumber: 24
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx",
    lineNumber: 36,
    columnNumber: 10
  }, this);
};
_s(UserRoleEditForm, "lLQ+eRly6URCDzWZ+Y3sgvKiQtA=", false, function() {
  return [useFormData];
});
_c = UserRoleEditForm;
export default UserRoleEditForm;
var _c;
$RefreshReg$(_c, "UserRoleEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBckNOLFNBQWFBLGlCQUFpQjtBQUU5QixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFlBQVlDLGtCQUFrQjtBQUV2QyxNQUFNQyxnQkFBMEI7QUFBQSxFQUM5QkMsV0FBV0M7QUFBQUEsRUFDWEMsU0FBU0Q7QUFBQUEsRUFDVEUsYUFBYUY7QUFBQUEsRUFDYkcsV0FBV0g7QUFDYjtBQUVBLE1BQU1JLG1CQUFpREMsV0FBVTtBQUFBQyxLQUFBO0FBQy9ELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxFQUFTLElBQUlKO0FBRXpDLFFBQU07QUFBQSxJQUNKRSxVQUFVRztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlyQixZQUFzQmEsWUFBWVQsYUFBYTtBQUVuREwsWUFBVSxNQUFNO0FBQ2QsUUFBSWMsVUFBVTtBQUNaSyx1QkFBaUJMLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYmQsWUFBVSxNQUFNO0FBQ2RlLGVBQVdFLGFBQWE7QUFBQSxFQUMxQixHQUFHLENBQUNBLGVBQWVGLFFBQVEsQ0FBQztBQUU1QixTQUNFLHVCQUFDLGNBQVcsS0FBTSxJQUNoQjtBQUFBLDJCQUFDLGlCQUNDLE9BQU0sU0FDTixhQUFhRSxjQUFjVCxXQUFXLElBQ3RDLFVBQVVZLGlCQUFpQixTQUFTLEdBQ3BDLFFBQVE7QUFBQSxNQUFFRyxNQUFNO0FBQUEsUUFBRUMsT0FBTztBQUFBLE1BQU07QUFBQSxJQUFFLEdBQ2pDLGNBQWNSLFVBQVVTLFFBQVFDLFdBQzVCSixhQUFhLFdBQVdOLFVBQVVTLFFBQVFDLFFBQVEsSUFDbERuQixVQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRRztBQUFBLElBRUgsdUJBQUMsY0FDQyxPQUFNLGdCQUNOLE9BQ0VVLGNBQWNSLGNBQ1YsSUFBSWtCLEtBQUtWLGNBQWNSLFdBQVcsSUFDbENGLFFBRU4sZ0JBQWMsTUFDZCxjQUFjYyxhQUFhLGFBQWEsR0FDeEMsY0FBYyxjQUNkLFFBQVE7QUFBQSxNQUNORSxNQUFNO0FBQUEsUUFBRUMsT0FBTztBQUFBLE1BQU07QUFBQSxJQUN2QixHQUNBLFdBQVc7QUFBQSxNQUNUSSxjQUFjWixVQUFVUyxRQUFRQyxXQUM1QkosYUFBYSxlQUFlTixVQUFVUyxRQUFRQyxRQUFRLElBQ3REbkI7QUFBQUEsSUFDTixLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJJO0FBQUEsSUFFSE8sVUFBVWUsTUFBTSx1QkFBQyxjQUNoQixPQUFNLGNBQ04sT0FBT1osY0FBY1AsWUFBWSxJQUFJaUIsS0FBS1YsY0FBY1AsU0FBUyxJQUFJSCxRQUNyRSxnQkFBYyxNQUNkLGNBQWNjLGFBQWEsV0FBVyxHQUN0QyxjQUFjLGNBQ2QsUUFBUTtBQUFBLE1BQ05FLE1BQU07QUFBQSxRQUFFQyxPQUFPO0FBQUEsTUFBTTtBQUFBLElBQ3ZCLEtBUmU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFiO0FBQUEsT0F0Q047QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdDQTtBQUVKO0FBQUNYLEdBaEVLRixrQkFBNkM7QUFBQSxVQVM3Q1YsV0FBVztBQUFBO0FBQUE2QixLQVRYbkI7QUFrRU4sZUFBZUE7QUFBZ0IsSUFBQW1CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VGb3JtRGF0YSIsIlJvbGVzRHJvcGRvd24iLCJEYXRlUGlja2VyIiwiRmxleENvbHVtbiIsImVtcHR5VXNlclJvbGUiLCJ1c3VhcmlvSWQiLCJ1bmRlZmluZWQiLCJjYXJnb0lkIiwiZGF0YUluaWNpYWwiLCJkYXRhRmluYWwiLCJVc2VyUm9sZUVkaXRGb3JtIiwicHJvcHMiLCJfcyIsImZvcm1EYXRhIiwib25DaGFuZ2UiLCJhcGlFcnJvciIsImxvY2FsRm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldExvY2FsRm9ybURhdGEiLCJvbkRyb3Bkb3duQ2hhbmdlIiwib25EYXRlQ2hhbmdlIiwib25GaWVsZEVycm9yIiwicm9vdCIsIndpZHRoIiwiZXJyb3JzIiwibWVzc2FnZXMiLCJEYXRlIiwiZXJyb3JNZXNzYWdlIiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJSb2xlRWRpdEZvcm0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi91c2Vycy9jb21wb25lbnRzL1VzZXJSb2xlRWRpdEZvcm0udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgRWRpdEZvcm1Qcm9wcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC90eXBlcy9FZGl0Rm9ybSdcbmltcG9ydCB7IHVzZUZvcm1EYXRhIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuaW1wb3J0IFVzZXJSb2xlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Vc2VyUm9sZSdcbmltcG9ydCB7IFJvbGVzRHJvcGRvd24gfSBmcm9tICcuLi8uLi9yb2xlcy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgRGF0ZVBpY2tlciwgRmxleENvbHVtbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5jb25zdCBlbXB0eVVzZXJSb2xlOiBVc2VyUm9sZSA9IHtcbiAgdXN1YXJpb0lkOiB1bmRlZmluZWQsXG4gIGNhcmdvSWQ6IHVuZGVmaW5lZCxcbiAgZGF0YUluaWNpYWw6IHVuZGVmaW5lZCxcbiAgZGF0YUZpbmFsOiB1bmRlZmluZWQsXG59XG5cbmNvbnN0IFVzZXJSb2xlRWRpdEZvcm06IEZDPEVkaXRGb3JtUHJvcHM8VXNlclJvbGU+PiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGZvcm1EYXRhLCBvbkNoYW5nZSwgYXBpRXJyb3IgfSA9IHByb3BzXG5cbiAgY29uc3Qge1xuICAgIGZvcm1EYXRhOiBsb2NhbEZvcm1EYXRhLFxuICAgIHNldEZvcm1EYXRhOiBzZXRMb2NhbEZvcm1EYXRhLFxuICAgIG9uRHJvcGRvd25DaGFuZ2UsXG4gICAgb25EYXRlQ2hhbmdlLFxuICAgIG9uRmllbGRFcnJvcixcbiAgfSA9IHVzZUZvcm1EYXRhPFVzZXJSb2xlPihmb3JtRGF0YSA/PyBlbXB0eVVzZXJSb2xlKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGZvcm1EYXRhKSB7XG4gICAgICBzZXRMb2NhbEZvcm1EYXRhKGZvcm1EYXRhKVxuICAgIH1cbiAgfSwgW2Zvcm1EYXRhXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9uQ2hhbmdlPy4obG9jYWxGb3JtRGF0YSlcbiAgfSwgW2xvY2FsRm9ybURhdGEsIG9uQ2hhbmdlXSlcblxuICByZXR1cm4gKFxuICAgIDxGbGV4Q29sdW1uIGdhcD17IDEyIH0+XG4gICAgICA8Um9sZXNEcm9wZG93blxuICAgICAgICBsYWJlbD0nQ2FyZ28nXG4gICAgICAgIHNlbGVjdGVkS2V5PXtsb2NhbEZvcm1EYXRhLmNhcmdvSWQgPz8gJyd9XG4gICAgICAgIG9uQ2hhbmdlPXtvbkRyb3Bkb3duQ2hhbmdlKCdjYXJnb0lkJyl9XG4gICAgICAgIHN0eWxlcz17eyByb290OiB7IHdpZHRoOiAnNTAlJyB9IH19XG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignY2FyZ29JZCcsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxuICAgICAgICAgIDogdW5kZWZpbmVkXG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgICA8RGF0ZVBpY2tlclxuICAgICAgICBsYWJlbD1cIkRhdGEgaW5pY2lhbFwiXG4gICAgICAgIHZhbHVlPXtcbiAgICAgICAgICBsb2NhbEZvcm1EYXRhLmRhdGFJbmljaWFsXG4gICAgICAgICAgICA/IG5ldyBEYXRlKGxvY2FsRm9ybURhdGEuZGF0YUluaWNpYWwpXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgICB9XG4gICAgICAgIGFsbG93VGV4dElucHV0XG4gICAgICAgIG9uU2VsZWN0RGF0ZT17b25EYXRlQ2hhbmdlKCdkYXRhSW5pY2lhbCcpfVxuICAgICAgICBmb3JtYXRTdHJpbmc9eydkZC9NTS95eXl5J31cbiAgICAgICAgc3R5bGVzPXt7XG4gICAgICAgICAgcm9vdDogeyB3aWR0aDogJzUwJScgfSxcbiAgICAgICAgfX1cbiAgICAgICAgdGV4dEZpZWxkPXt7XG4gICAgICAgICAgZXJyb3JNZXNzYWdlOiBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xuICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ2RhdGFJbmljaWFsJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICB7Zm9ybURhdGE/LmlkICYmIDxEYXRlUGlja2VyXG4gICAgICAgIGxhYmVsPVwiRGF0YSBmaW5hbFwiXG4gICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLmRhdGFGaW5hbCA/IG5ldyBEYXRlKGxvY2FsRm9ybURhdGEuZGF0YUZpbmFsKSA6IHVuZGVmaW5lZH1cbiAgICAgICAgYWxsb3dUZXh0SW5wdXRcbiAgICAgICAgb25TZWxlY3REYXRlPXtvbkRhdGVDaGFuZ2UoJ2RhdGFGaW5hbCcpfVxuICAgICAgICBmb3JtYXRTdHJpbmc9eydkZC9NTS95eXl5J31cbiAgICAgICAgc3R5bGVzPXt7XG4gICAgICAgICAgcm9vdDogeyB3aWR0aDogJzUwJScgfSxcbiAgICAgICAgfX1cbiAgICAgIC8+fVxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBVc2VyUm9sZUVkaXRGb3JtXG4iXX0=