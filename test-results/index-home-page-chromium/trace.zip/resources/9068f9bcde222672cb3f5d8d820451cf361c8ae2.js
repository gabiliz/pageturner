import { buildForAccountList, buildForCnpj, buildForCompanyName, buildForDate, buildForNumber, buildForRecord, buildForString } from "/src/shared/utils/buildQueryFilter/queries.ts";
export default function buildQueryFilterDefault(columns, value) {
  if (!value)
    return void 0;
  return columns.filter((e) => e?.filterable).map((e) => {
    const field = e.field.toString().replaceAll(".", "/");
    const queryType = e?.filterOptions?.queryType || "string";
    switch (queryType) {
      case "number":
        return buildForNumber(field, value);
      case "date":
        return buildForDate(field, value);
      case "record":
        return buildForRecord(field, value, e.filterOptions?.record);
      case "listConta":
        return buildForAccountList(field, value);
      case "listCnpj":
        return buildForCnpj(field, value);
      case "listCnpjInContract":
        return buildForCnpj(field, value, true);
      case "listRazaoSocial":
        return buildForCompanyName(field, value);
      case "listRazaoSocialInContract":
        return buildForCompanyName(field, value, true);
      case "string":
      default:
        return buildForString(field, value, e.filterOptions?.replace);
    }
  }).filter((e) => e !== null).join(" or ");
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlZmF1bHRGaWx0ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGF0YVRhYmxlQ29sdW1uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cydcbmltcG9ydCB7IGJ1aWxkRm9yQWNjb3VudExpc3QsIGJ1aWxkRm9yQ25waiwgYnVpbGRGb3JDb21wYW55TmFtZSwgYnVpbGRGb3JEYXRlLCBidWlsZEZvck51bWJlciwgYnVpbGRGb3JSZWNvcmQsIGJ1aWxkRm9yU3RyaW5nIH0gZnJvbSAnLi9xdWVyaWVzJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBidWlsZFF1ZXJ5RmlsdGVyRGVmYXVsdDxUPiAoY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPFQ+W10sIHZhbHVlOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gdW5kZWZpbmVkXG4gIHJldHVybiBjb2x1bW5zLmZpbHRlcihlID0+IGU/LmZpbHRlcmFibGUpLm1hcChlID0+IHtcbiAgICBjb25zdCBmaWVsZCA9IGUuZmllbGQudG9TdHJpbmcoKS5yZXBsYWNlQWxsKCcuJywgJy8nKVxuXG4gICAgY29uc3QgcXVlcnlUeXBlID0gZT8uZmlsdGVyT3B0aW9ucz8ucXVlcnlUeXBlIHx8ICdzdHJpbmcnXG5cbiAgICBzd2l0Y2ggKHF1ZXJ5VHlwZSkge1xuICAgICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgICAgcmV0dXJuIGJ1aWxkRm9yTnVtYmVyKGZpZWxkLCB2YWx1ZSlcbiAgICAgIGNhc2UgJ2RhdGUnOlxuICAgICAgICByZXR1cm4gYnVpbGRGb3JEYXRlKGZpZWxkLCB2YWx1ZSlcbiAgICAgIGNhc2UgJ3JlY29yZCc6XG4gICAgICAgIHJldHVybiBidWlsZEZvclJlY29yZChmaWVsZCwgdmFsdWUsIGUuZmlsdGVyT3B0aW9ucz8ucmVjb3JkKVxuICAgICAgY2FzZSAnbGlzdENvbnRhJzpcbiAgICAgICAgcmV0dXJuIGJ1aWxkRm9yQWNjb3VudExpc3QoZmllbGQsIHZhbHVlKVxuICAgICAgY2FzZSAnbGlzdENucGonOlxuICAgICAgICByZXR1cm4gYnVpbGRGb3JDbnBqKGZpZWxkLCB2YWx1ZSlcbiAgICAgIGNhc2UgJ2xpc3RDbnBqSW5Db250cmFjdCc6XG4gICAgICAgIHJldHVybiBidWlsZEZvckNucGooZmllbGQsIHZhbHVlLCB0cnVlKVxuICAgICAgY2FzZSAnbGlzdFJhemFvU29jaWFsJzpcbiAgICAgICAgcmV0dXJuIGJ1aWxkRm9yQ29tcGFueU5hbWUoZmllbGQsIHZhbHVlKVxuICAgICAgY2FzZSAnbGlzdFJhemFvU29jaWFsSW5Db250cmFjdCc6XG4gICAgICAgIHJldHVybiBidWlsZEZvckNvbXBhbnlOYW1lKGZpZWxkLCB2YWx1ZSwgdHJ1ZSlcbiAgICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gYnVpbGRGb3JTdHJpbmcoZmllbGQsIHZhbHVlLCBlLmZpbHRlck9wdGlvbnM/LnJlcGxhY2UpXG4gICAgfVxuICB9KS5maWx0ZXIoZSA9PiBlICE9PSBudWxsKS5qb2luKCcgb3IgJylcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxxQkFBcUIsY0FBYyxxQkFBcUIsY0FBYyxnQkFBZ0IsZ0JBQWdCLHNCQUFzQjtBQUVySSx3QkFBd0Isd0JBQTRCLFNBQStCLE9BQW1DO0FBQ3BILE1BQUksQ0FBQztBQUFPLFdBQU87QUFDbkIsU0FBTyxRQUFRLE9BQU8sT0FBSyxHQUFHLFVBQVUsRUFBRSxJQUFJLE9BQUs7QUFDakQsVUFBTSxRQUFRLEVBQUUsTUFBTSxTQUFTLEVBQUUsV0FBVyxLQUFLLEdBQUc7QUFFcEQsVUFBTSxZQUFZLEdBQUcsZUFBZSxhQUFhO0FBRWpELFlBQVEsV0FBVztBQUFBLE1BQ2pCLEtBQUs7QUFDSCxlQUFPLGVBQWUsT0FBTyxLQUFLO0FBQUEsTUFDcEMsS0FBSztBQUNILGVBQU8sYUFBYSxPQUFPLEtBQUs7QUFBQSxNQUNsQyxLQUFLO0FBQ0gsZUFBTyxlQUFlLE9BQU8sT0FBTyxFQUFFLGVBQWUsTUFBTTtBQUFBLE1BQzdELEtBQUs7QUFDSCxlQUFPLG9CQUFvQixPQUFPLEtBQUs7QUFBQSxNQUN6QyxLQUFLO0FBQ0gsZUFBTyxhQUFhLE9BQU8sS0FBSztBQUFBLE1BQ2xDLEtBQUs7QUFDSCxlQUFPLGFBQWEsT0FBTyxPQUFPLElBQUk7QUFBQSxNQUN4QyxLQUFLO0FBQ0gsZUFBTyxvQkFBb0IsT0FBTyxLQUFLO0FBQUEsTUFDekMsS0FBSztBQUNILGVBQU8sb0JBQW9CLE9BQU8sT0FBTyxJQUFJO0FBQUEsTUFDL0MsS0FBSztBQUFBLE1BQ0w7QUFDRSxlQUFPLGVBQWUsT0FBTyxPQUFPLEVBQUUsZUFBZSxPQUFPO0FBQUEsSUFDaEU7QUFBQSxFQUNGLENBQUMsRUFBRSxPQUFPLE9BQUssTUFBTSxJQUFJLEVBQUUsS0FBSyxNQUFNO0FBQ3hDOyIsIm5hbWVzIjpbXX0=