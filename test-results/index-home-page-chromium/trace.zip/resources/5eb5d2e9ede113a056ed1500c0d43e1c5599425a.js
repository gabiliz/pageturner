import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/richTextEditor/MenuBar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { MenuBarActionButton, MenuBarContainer } from "/src/shared/components/richTextEditor/MenuBar.styles.ts?t=1701096626433";
const MenuBar = ({
  editor
}) => {
  if (!editor) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV(MenuBarContainer, { children: [
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("bold"), onClick: () => editor.chain().focus().toggleBold().run(), iconProps: {
      iconName: "Bold"
    }, ariaDescription: "Negrito", hint: "Negrito" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("italic"), onClick: () => editor.chain().focus().toggleItalic().run(), iconProps: {
      iconName: "Italic"
    }, ariaDescription: "Itálico", hint: "Itálico" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("strike"), onClick: () => editor.chain().focus().toggleStrike().run(), iconProps: {
      iconName: "Strikethrough"
    }, ariaDescription: "Tachado", hint: "Tachado" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("heading", {
      level: 1
    }), onClick: () => editor.chain().focus().toggleHeading({
      level: 1
    }).run(), iconProps: {
      iconName: "Header1"
    }, ariaDescription: "h1", hint: "h1" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("heading", {
      level: 2
    }), onClick: () => editor.chain().focus().toggleHeading({
      level: 2
    }).run(), iconProps: {
      iconName: "Header2"
    }, ariaDescription: "h2", hint: "h2" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("heading", {
      level: 3
    }), onClick: () => editor.chain().focus().toggleHeading({
      level: 3
    }).run(), iconProps: {
      iconName: "Header3"
    }, ariaDescription: "h3", hint: "h3" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("heading", {
      level: 4
    }), onClick: () => editor.chain().focus().toggleHeading({
      level: 4
    }).run(), iconProps: {
      iconName: "Header4"
    }, ariaDescription: "h4", hint: "h4" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("bulletList"), onClick: () => editor.chain().focus().toggleBulletList().run(), iconProps: {
      iconName: "BulletedList2"
    }, ariaDescription: "Lista desordenada", hint: "Lista desordenada" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("orderedList"), onClick: () => editor.chain().focus().toggleOrderedList().run(), iconProps: {
      iconName: "NumberedList"
    }, ariaDescription: "Lista ordenada", hint: "Lista ordenada" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { isActive: editor.isActive("blockquote"), onClick: () => editor.chain().focus().toggleBlockquote().run(), iconProps: {
      iconName: "RightDoubleQuote"
    }, ariaDescription: "Citação", hint: "Citação" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { onClick: () => editor.chain().focus().setHorizontalRule().run(), iconProps: {
      iconName: "Remove"
    }, ariaDescription: "Linha horizontal", hint: "Linha horizontal" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MenuBarActionButton, { onClick: () => editor.chain().focus().undo().run(), iconProps: {
      iconName: "Undo"
    }, ariaDescription: "Desfazer", hint: "Desfazer" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_c = MenuBar;
export default MenuBar;
var _c;
$RefreshReg$(_c, "MenuBar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/richTextEditor/MenuBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTiwyQkFBdUI7QUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUV0QyxTQUFTQSxxQkFBcUJDLHdCQUF3QjtBQU10RCxNQUFNQyxVQUF3QkEsQ0FBQztBQUFBLEVBQUVDO0FBQU8sTUFBTTtBQUM1QyxNQUFJLENBQUNBLFFBQVE7QUFDWCxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsb0JBQ0M7QUFBQSwyQkFBQyx1QkFDQyxVQUFVQSxPQUFPQyxTQUFTLE1BQU0sR0FDaEMsU0FBUyxNQUFNRCxPQUFPRSxNQUFNLEVBQUVDLE1BQU0sRUFBRUMsV0FBVyxFQUFFQyxJQUFJLEdBQ3ZELFdBQVc7QUFBQSxNQUNUQyxVQUFVO0FBQUEsSUFDWixHQUNBLGlCQUFnQixXQUNoQixNQUFLLGFBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9nQjtBQUFBLElBR2hCLHVCQUFDLHVCQUNDLFVBQVVOLE9BQU9DLFNBQVMsUUFBUSxHQUNsQyxTQUFTLE1BQU1ELE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFSSxhQUFhLEVBQUVGLElBQUksR0FDekQsV0FBVztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxJQUNaLEdBQ0EsaUJBQWdCLFdBQ2hCLE1BQUssYUFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT2dCO0FBQUEsSUFHaEIsdUJBQUMsdUJBQ0MsVUFBVU4sT0FBT0MsU0FBUyxRQUFRLEdBQ2xDLFNBQVMsTUFBTUQsT0FBT0UsTUFBTSxFQUFFQyxNQUFNLEVBQUVLLGFBQWEsRUFBRUgsSUFBSSxHQUN6RCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0IsV0FDaEIsTUFBSyxhQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPZ0I7QUFBQSxJQUdoQix1QkFBQyx1QkFDQyxVQUFVTixPQUFPQyxTQUFTLFdBQVc7QUFBQSxNQUFFUSxPQUFPO0FBQUEsSUFBRSxDQUFDLEdBQ2pELFNBQVMsTUFBTVQsT0FBT0UsTUFBTSxFQUFFQyxNQUFNLEVBQUVPLGNBQWM7QUFBQSxNQUFFRCxPQUFPO0FBQUEsSUFBRSxDQUFDLEVBQUVKLElBQUksR0FDdEUsV0FBVztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxJQUNaLEdBQ0EsaUJBQWdCLE1BQ2hCLE1BQUssUUFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT1c7QUFBQSxJQUdYLHVCQUFDLHVCQUNDLFVBQVVOLE9BQU9DLFNBQVMsV0FBVztBQUFBLE1BQUVRLE9BQU87QUFBQSxJQUFFLENBQUMsR0FDakQsU0FBUyxNQUFNVCxPQUFPRSxNQUFNLEVBQUVDLE1BQU0sRUFBRU8sY0FBYztBQUFBLE1BQUVELE9BQU87QUFBQSxJQUFFLENBQUMsRUFBRUosSUFBSSxHQUN0RSxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0IsTUFDaEIsTUFBSyxRQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPVztBQUFBLElBR1gsdUJBQUMsdUJBQ0MsVUFBVU4sT0FBT0MsU0FBUyxXQUFXO0FBQUEsTUFBRVEsT0FBTztBQUFBLElBQUUsQ0FBQyxHQUNqRCxTQUFTLE1BQU1ULE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFTyxjQUFjO0FBQUEsTUFBRUQsT0FBTztBQUFBLElBQUUsQ0FBQyxFQUFFSixJQUFJLEdBQ3RFLFdBQVc7QUFBQSxNQUNUQyxVQUFVO0FBQUEsSUFDWixHQUNBLGlCQUFnQixNQUNoQixNQUFLLFFBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9XO0FBQUEsSUFHWCx1QkFBQyx1QkFDQyxVQUFVTixPQUFPQyxTQUFTLFdBQVc7QUFBQSxNQUFFUSxPQUFPO0FBQUEsSUFBRSxDQUFDLEdBQ2pELFNBQVMsTUFBTVQsT0FBT0UsTUFBTSxFQUFFQyxNQUFNLEVBQUVPLGNBQWM7QUFBQSxNQUFFRCxPQUFPO0FBQUEsSUFBRSxDQUFDLEVBQUVKLElBQUksR0FDdEUsV0FBVztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxJQUNaLEdBQ0EsaUJBQWdCLE1BQ2hCLE1BQUssUUFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT1c7QUFBQSxJQUdYLHVCQUFDLHVCQUNDLFVBQVVOLE9BQU9DLFNBQVMsWUFBWSxHQUN0QyxTQUFTLE1BQU1ELE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFUSxpQkFBaUIsRUFBRU4sSUFBSSxHQUM3RCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0IscUJBQ2hCLE1BQUssdUJBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU8wQjtBQUFBLElBRzFCLHVCQUFDLHVCQUNDLFVBQVVOLE9BQU9DLFNBQVMsYUFBYSxHQUN2QyxTQUFTLE1BQU1ELE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFUyxrQkFBa0IsRUFBRVAsSUFBSSxHQUM5RCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0Isa0JBQ2hCLE1BQUssb0JBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU91QjtBQUFBLElBR3ZCLHVCQUFDLHVCQUNDLFVBQVVOLE9BQU9DLFNBQVMsWUFBWSxHQUN0QyxTQUFTLE1BQU1ELE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFVSxpQkFBaUIsRUFBRVIsSUFBSSxHQUM3RCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0IsV0FDaEIsTUFBSyxhQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPZ0I7QUFBQSxJQUdoQix1QkFBQyx1QkFDQyxTQUFTLE1BQU1OLE9BQU9FLE1BQU0sRUFBRUMsTUFBTSxFQUFFVyxrQkFBa0IsRUFBRVQsSUFBSSxHQUM5RCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0Isb0JBQ2hCLE1BQUssc0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU15QjtBQUFBLElBT3pCLHVCQUFDLHVCQUNDLFNBQVMsTUFBTU4sT0FBT0UsTUFBTSxFQUFFQyxNQUFNLEVBQUVZLEtBQUssRUFBRVYsSUFBSSxHQUNqRCxXQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLElBQ1osR0FDQSxpQkFBZ0IsWUFDaEIsTUFBSyxjQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNaUI7QUFBQSxPQXhIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThIQTtBQUVKO0FBQUNVLEtBdElLakI7QUF1SU4sZUFBZUE7QUFBTyxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk1lbnVCYXJBY3Rpb25CdXR0b24iLCJNZW51QmFyQ29udGFpbmVyIiwiTWVudUJhciIsImVkaXRvciIsImlzQWN0aXZlIiwiY2hhaW4iLCJmb2N1cyIsInRvZ2dsZUJvbGQiLCJydW4iLCJpY29uTmFtZSIsInRvZ2dsZUl0YWxpYyIsInRvZ2dsZVN0cmlrZSIsImxldmVsIiwidG9nZ2xlSGVhZGluZyIsInRvZ2dsZUJ1bGxldExpc3QiLCJ0b2dnbGVPcmRlcmVkTGlzdCIsInRvZ2dsZUJsb2NrcXVvdGUiLCJzZXRIb3Jpem9udGFsUnVsZSIsInVuZG8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1lbnVCYXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvcmljaFRleHRFZGl0b3IvTWVudUJhci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFZGl0b3IgfSBmcm9tICdAdGlwdGFwL3JlYWN0J1xyXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBNZW51QmFyQWN0aW9uQnV0dG9uLCBNZW51QmFyQ29udGFpbmVyIH0gZnJvbSAnLi9NZW51QmFyLnN0eWxlcydcclxuXHJcbmludGVyZmFjZSBJTWVudUJhciB7XHJcbiAgZWRpdG9yOiBFZGl0b3IgfCBudWxsXHJcbn1cclxuXHJcbmNvbnN0IE1lbnVCYXI6IEZDPElNZW51QmFyPiA9ICh7IGVkaXRvciB9KSA9PiB7XHJcbiAgaWYgKCFlZGl0b3IpIHtcclxuICAgIHJldHVybiBudWxsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1lbnVCYXJDb250YWluZXI+XHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnYm9sZCcpfVxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGVkaXRvci5jaGFpbigpLmZvY3VzKCkudG9nZ2xlQm9sZCgpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdCb2xkJyxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGFyaWFEZXNjcmlwdGlvbj0nTmVncml0bydcclxuICAgICAgICBoaW50PSdOZWdyaXRvJ1xyXG4gICAgICAvPlxyXG5cclxuICAgICAgPE1lbnVCYXJBY3Rpb25CdXR0b25cclxuICAgICAgICBpc0FjdGl2ZT17ZWRpdG9yLmlzQWN0aXZlKCdpdGFsaWMnKX1cclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBlZGl0b3IuY2hhaW4oKS5mb2N1cygpLnRvZ2dsZUl0YWxpYygpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdJdGFsaWMnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdJdMOhbGljbydcclxuICAgICAgICBoaW50PSdJdMOhbGljbydcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnc3RyaWtlJyl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVTdHJpa2UoKS5ydW4oKX1cclxuICAgICAgICBpY29uUHJvcHM9e3tcclxuICAgICAgICAgIGljb25OYW1lOiAnU3RyaWtldGhyb3VnaCcsXHJcbiAgICAgICAgfX1cclxuICAgICAgICBhcmlhRGVzY3JpcHRpb249J1RhY2hhZG8nXHJcbiAgICAgICAgaGludD0nVGFjaGFkbydcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnaGVhZGluZycsIHsgbGV2ZWw6IDEgfSl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVIZWFkaW5nKHsgbGV2ZWw6IDEgfSkucnVuKCl9XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ0hlYWRlcjEnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdoMSdcclxuICAgICAgICBoaW50PSdoMSdcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnaGVhZGluZycsIHsgbGV2ZWw6IDIgfSl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVIZWFkaW5nKHsgbGV2ZWw6IDIgfSkucnVuKCl9XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ0hlYWRlcjInLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdoMidcclxuICAgICAgICBoaW50PSdoMidcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnaGVhZGluZycsIHsgbGV2ZWw6IDMgfSl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVIZWFkaW5nKHsgbGV2ZWw6IDMgfSkucnVuKCl9XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ0hlYWRlcjMnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdoMydcclxuICAgICAgICBoaW50PSdoMydcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnaGVhZGluZycsIHsgbGV2ZWw6IDQgfSl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVIZWFkaW5nKHsgbGV2ZWw6IDQgfSkucnVuKCl9XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ0hlYWRlcjQnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdoNCdcclxuICAgICAgICBoaW50PSdoNCdcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnYnVsbGV0TGlzdCcpfVxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGVkaXRvci5jaGFpbigpLmZvY3VzKCkudG9nZ2xlQnVsbGV0TGlzdCgpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdCdWxsZXRlZExpc3QyJyxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGFyaWFEZXNjcmlwdGlvbj0nTGlzdGEgZGVzb3JkZW5hZGEnXHJcbiAgICAgICAgaGludD0nTGlzdGEgZGVzb3JkZW5hZGEnXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8TWVudUJhckFjdGlvbkJ1dHRvblxyXG4gICAgICAgIGlzQWN0aXZlPXtlZGl0b3IuaXNBY3RpdmUoJ29yZGVyZWRMaXN0Jyl9XHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS50b2dnbGVPcmRlcmVkTGlzdCgpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdOdW1iZXJlZExpc3QnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdMaXN0YSBvcmRlbmFkYSdcclxuICAgICAgICBoaW50PSdMaXN0YSBvcmRlbmFkYSdcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgaXNBY3RpdmU9e2VkaXRvci5pc0FjdGl2ZSgnYmxvY2txdW90ZScpfVxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGVkaXRvci5jaGFpbigpLmZvY3VzKCkudG9nZ2xlQmxvY2txdW90ZSgpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdSaWdodERvdWJsZVF1b3RlJyxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGFyaWFEZXNjcmlwdGlvbj0nQ2l0YcOnw6NvJ1xyXG4gICAgICAgIGhpbnQ9J0NpdGHDp8OjbydcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS5zZXRIb3Jpem9udGFsUnVsZSgpLnJ1bigpfVxyXG4gICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgaWNvbk5hbWU6ICdSZW1vdmUnLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdMaW5oYSBob3Jpem9udGFsJ1xyXG4gICAgICAgIGhpbnQ9J0xpbmhhIGhvcml6b250YWwnXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7LyogPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBlZGl0b3IuY2hhaW4oKS5mb2N1cygpLnNldEhhcmRCcmVhaygpLnJ1bigpfT5cclxuICAgICAgICBoYXJkIGJyZWFrXHJcbiAgICAgIDwvYnV0dG9uPiAqL31cclxuXHJcbiAgICAgIDxNZW51QmFyQWN0aW9uQnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS51bmRvKCkucnVuKCl9XHJcbiAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICBpY29uTmFtZTogJ1VuZG8nLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgYXJpYURlc2NyaXB0aW9uPSdEZXNmYXplcidcclxuICAgICAgICBoaW50PSdEZXNmYXplcidcclxuICAgICAgLz5cclxuICAgICAgey8qXHJcbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZWRpdG9yLmNoYWluKCkuZm9jdXMoKS5yZWRvKCkucnVuKCl9PlxyXG4gICAgICAgIHJlZG9cclxuICAgICAgPC9idXR0b24+ICovfVxyXG4gICAgPC9NZW51QmFyQ29udGFpbmVyPlxyXG4gIClcclxufVxyXG5leHBvcnQgZGVmYXVsdCBNZW51QmFyXHJcbiJdfQ==