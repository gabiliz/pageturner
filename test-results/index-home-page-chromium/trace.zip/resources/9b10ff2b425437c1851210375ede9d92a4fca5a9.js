import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/fileDisplay/SelectedFileTag.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { FontWeights, IconButton, mergeStyleSets, TooltipHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { FlexRow } from "/src/shared/components/FlexBox/index.ts";
const SelectedFileTag = ({
  fileName,
  onDelete,
  onClick
}) => {
  _s();
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV("div", { className: styles.container, children: /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "center", styles: {
    marginTop: 3
  }, gap: 10, children: [
    /* @__PURE__ */ jsxDEV(TooltipHost, { content: fileName, children: /* @__PURE__ */ jsxDEV("span", { className: styles.title, children: fileName }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
      iconName: "Download",
      styles: {
        root: {
          fontSize: 12
        }
      }
    }, onClick: (ev) => {
      ev.stopPropagation();
      onClick?.();
    }, styles: {
      root: {
        width: 12,
        height: 12
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    onDelete && /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
      iconName: "Cancel",
      styles: {
        root: {
          fontSize: 12
        }
      }
    }, disabled: false, onClick: (ev) => {
      ev.stopPropagation();
      onDelete?.();
    }, styles: {
      root: {
        width: 12,
        height: 12
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
      lineNumber: 44,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
    lineNumber: 20,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(SelectedFileTag, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = SelectedFileTag;
const useStyles = () => {
  _s2();
  const colors = useThemeColors();
  return mergeStyleSets({
    container: {
      display: "inline-block",
      whiteSpace: "nowrap",
      fontSize: "12px",
      height: 32,
      maxWidth: 250,
      fontWeight: FontWeights.semibold,
      color: colors.blue[500],
      padding: "3px 8px",
      border: `2px solid ${colors.gray[300]}`,
      borderRadius: "20px"
    },
    title: {
      display: "inline-block",
      maxWidth: 150,
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  });
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default SelectedFileTag;
var _c;
$RefreshReg$(_c, "SelectedFileTag");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileTag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJSLFNBQVNBLGFBQWFDLFlBQVlDLGdCQUFnQkMsbUJBQW1CO0FBRXJFLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxlQUFlO0FBUXhCLE1BQU1DLGtCQUE0Q0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVVDO0FBQVEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JGLFFBQU1DLFNBQVNDLFVBQVU7QUFDekIsU0FBUSx1QkFBQyxTQUFJLFdBQVdELE9BQU9FLFdBQzdCLGlDQUFDLFdBQ0MsaUJBQWdCLFVBQ2hCLFFBQVE7QUFBQSxJQUFFQyxXQUFXO0FBQUEsRUFBRSxHQUN2QixLQUFLLElBRUw7QUFBQSwyQkFBQyxlQUFZLFNBQVNQLFVBQ3BCLGlDQUFDLFVBQUssV0FBV0ksT0FBT0ksT0FDckJSLHNCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsY0FDQyxXQUFXO0FBQUEsTUFBRVMsVUFBVTtBQUFBLE1BQVlMLFFBQVE7QUFBQSxRQUFFTSxNQUFNO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFFBQUc7QUFBQSxNQUFFO0FBQUEsSUFBRSxHQUN0RSxTQUFVQyxRQUFPO0FBQ2ZBLFNBQUdDLGdCQUFnQjtBQUNuQlgsZ0JBQVU7QUFBQSxJQUNaLEdBQ0EsUUFBUTtBQUFBLE1BQ05RLE1BQU07QUFBQSxRQUNKSSxPQUFPO0FBQUEsUUFDUEMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdJO0FBQUEsSUFFSGQsWUFBWSx1QkFBQyxjQUNaLFdBQVc7QUFBQSxNQUFFUSxVQUFVO0FBQUEsTUFBVUwsUUFBUTtBQUFBLFFBQUVNLE1BQU07QUFBQSxVQUFFQyxVQUFVO0FBQUEsUUFBRztBQUFBLE1BQUU7QUFBQSxJQUFFLEdBQ3BFLFVBQVUsT0FDVixTQUFVQyxRQUFPO0FBQ2ZBLFNBQUdDLGdCQUFnQjtBQUNuQlosaUJBQVc7QUFBQSxJQUNiLEdBQ0EsUUFBUTtBQUFBLE1BQ05TLE1BQU07QUFBQSxRQUNKSSxPQUFPO0FBQUEsUUFDUEMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGLEtBWlc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlUO0FBQUEsT0FuQ047QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQSxLQXRDTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNSO0FBQ0Y7QUFBQ1osR0ExQ0tKLGlCQUF5QztBQUFBLFVBQzlCTSxTQUFTO0FBQUE7QUFBQVcsS0FEcEJqQjtBQTRDTixNQUFNTSxZQUFZQSxNQUFNO0FBQUFZLE1BQUE7QUFDdEIsUUFBTUMsU0FBU3JCLGVBQWU7QUFDOUIsU0FBT0YsZUFDTDtBQUFBLElBQ0VXLFdBQVc7QUFBQSxNQUNUYSxTQUFTO0FBQUEsTUFDVEMsWUFBWTtBQUFBLE1BQ1pULFVBQVU7QUFBQSxNQUNWSSxRQUFRO0FBQUEsTUFDUk0sVUFBVTtBQUFBLE1BQ1ZDLFlBQVk3QixZQUFZOEI7QUFBQUEsTUFDeEJDLE9BQU9OLE9BQU9PLEtBQUssR0FBRztBQUFBLE1BQ3RCQyxTQUFTO0FBQUEsTUFDVEMsUUFBUyxhQUFZVCxPQUFPVSxLQUFLLEdBQUc7QUFBQSxNQUNwQ0MsY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQXJCLE9BQU87QUFBQSxNQUNMVyxTQUFTO0FBQUEsTUFDVEUsVUFBVTtBQUFBLE1BQ1ZTLFVBQVU7QUFBQSxNQUNWQyxjQUFjO0FBQUEsSUFDaEI7QUFBQSxFQUNGLENBQ0Y7QUFDRjtBQUFDZCxJQXhCS1osV0FBUztBQUFBLFVBQ0VSLGNBQWM7QUFBQTtBQXdCL0IsZUFBZUU7QUFBZSxJQUFBaUI7QUFBQWdCLGFBQUFoQixJQUFBIiwibmFtZXMiOlsiRm9udFdlaWdodHMiLCJJY29uQnV0dG9uIiwibWVyZ2VTdHlsZVNldHMiLCJUb29sdGlwSG9zdCIsInVzZVRoZW1lQ29sb3JzIiwiRmxleFJvdyIsIlNlbGVjdGVkRmlsZVRhZyIsImZpbGVOYW1lIiwib25EZWxldGUiLCJvbkNsaWNrIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJjb250YWluZXIiLCJtYXJnaW5Ub3AiLCJ0aXRsZSIsImljb25OYW1lIiwicm9vdCIsImZvbnRTaXplIiwiZXYiLCJzdG9wUHJvcGFnYXRpb24iLCJ3aWR0aCIsImhlaWdodCIsIl9jIiwiX3MyIiwiY29sb3JzIiwiZGlzcGxheSIsIndoaXRlU3BhY2UiLCJtYXhXaWR0aCIsImZvbnRXZWlnaHQiLCJzZW1pYm9sZCIsImNvbG9yIiwiYmx1ZSIsInBhZGRpbmciLCJib3JkZXIiLCJncmF5IiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJ0ZXh0T3ZlcmZsb3ciLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWxlY3RlZEZpbGVUYWcudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZmlsZURpc3BsYXkvU2VsZWN0ZWRGaWxlVGFnLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZvbnRXZWlnaHRzLCBJY29uQnV0dG9uLCBtZXJnZVN0eWxlU2V0cywgVG9vbHRpcEhvc3QgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWVDb2xvcnMgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEZsZXhSb3cgfSBmcm9tICcuLi9GbGV4Qm94J1xuXG5pbnRlcmZhY2UgU2VsZWN0ZWRGaWxlVGFnUHJvcHMge1xuICBmaWxlTmFtZTogc3RyaW5nXG4gIG9uRGVsZXRlPzogKCkgPT4gdm9pZFxuICBvbkNsaWNrPzogKCkgPT4gdm9pZFxufVxuXG5jb25zdCBTZWxlY3RlZEZpbGVUYWc6IEZDPFNlbGVjdGVkRmlsZVRhZ1Byb3BzPiA9ICh7IGZpbGVOYW1lLCBvbkRlbGV0ZSwgb25DbGljayB9KSA9PiB7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcygpXG4gIHJldHVybiAoPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxuICAgIDxGbGV4Um93XG4gICAgICBob3Jpem9udGFsQWxpZ249J2NlbnRlcidcbiAgICAgIHN0eWxlcz17eyBtYXJnaW5Ub3A6IDMgfX1cbiAgICAgIGdhcD17MTB9XG4gICAgPlxuICAgICAgPFRvb2x0aXBIb3N0IGNvbnRlbnQ9e2ZpbGVOYW1lfT5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMudGl0bGV9PlxuICAgICAgICAgIHtmaWxlTmFtZX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9Ub29sdGlwSG9zdD5cbiAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0Rvd25sb2FkJywgc3R5bGVzOiB7IHJvb3Q6IHsgZm9udFNpemU6IDEyIH0gfSB9fVxuICAgICAgICBvbkNsaWNrPXsoZXYpID0+IHtcbiAgICAgICAgICBldi5zdG9wUHJvcGFnYXRpb24oKVxuICAgICAgICAgIG9uQ2xpY2s/LigpXG4gICAgICAgIH19XG4gICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgIHdpZHRoOiAxMixcbiAgICAgICAgICAgIGhlaWdodDogMTIsXG4gICAgICAgICAgfSxcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICB7b25EZWxldGUgJiYgPEljb25CdXR0b25cbiAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiAnQ2FuY2VsJywgc3R5bGVzOiB7IHJvb3Q6IHsgZm9udFNpemU6IDEyIH0gfSB9fVxuICAgICAgICBkaXNhYmxlZD17ZmFsc2V9XG4gICAgICAgIG9uQ2xpY2s9eyhldikgPT4ge1xuICAgICAgICAgIGV2LnN0b3BQcm9wYWdhdGlvbigpXG4gICAgICAgICAgb25EZWxldGU/LigpXG4gICAgICAgIH19XG4gICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgIHdpZHRoOiAxMixcbiAgICAgICAgICAgIGhlaWdodDogMTIsXG4gICAgICAgICAgfSxcbiAgICAgICAgfX1cbiAgICAgIC8+fVxuICAgIDwvRmxleFJvdz5cbiAgPC9kaXY+KVxufVxuXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKFxuICAgIHtcbiAgICAgIGNvbnRhaW5lcjoge1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXG4gICAgICAgIGZvbnRTaXplOiAnMTJweCcsXG4gICAgICAgIGhlaWdodDogMzIsXG4gICAgICAgIG1heFdpZHRoOiAyNTAsXG4gICAgICAgIGZvbnRXZWlnaHQ6IEZvbnRXZWlnaHRzLnNlbWlib2xkLFxuICAgICAgICBjb2xvcjogY29sb3JzLmJsdWVbNTAwXSxcbiAgICAgICAgcGFkZGluZzogJzNweCA4cHgnLFxuICAgICAgICBib3JkZXI6IGAycHggc29saWQgJHtjb2xvcnMuZ3JheVszMDBdfWAsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzIwcHgnLFxuICAgICAgfSxcbiAgICAgIHRpdGxlOiB7XG4gICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgICBtYXhXaWR0aDogMTUwLFxuICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgKVxufVxuZXhwb3J0IGRlZmF1bHQgU2VsZWN0ZWRGaWxlVGFnXG4iXX0=