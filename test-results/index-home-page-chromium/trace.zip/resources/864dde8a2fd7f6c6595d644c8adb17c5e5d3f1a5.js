import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditsSituation.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsSituation.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyles, FontWeights, FontSizes } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const memo = __vite__cjsImport4_react["memo"];
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { useTagsColors } from "/src/shared/hooks/tagsColors.ts";
import { AuditSituationRecord } from "/src/shared/record/AuditSituationRecord.ts";
const AuditsSituation = (props) => {
  _s();
  const styles = useStyles(props);
  return /* @__PURE__ */ jsxDEV("div", { className: styles, children: AuditSituationRecord[props.situation] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsSituation.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(AuditsSituation, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = AuditsSituation;
const useStyles = (props) => {
  _s2();
  const {
    background,
    color
  } = useTagsColors(props.situation, ListTags);
  return mergeStyles({
    display: "inline-block",
    whiteSpace: "nowrap",
    fontSize: FontSizes.mini,
    marginLeft: props.marginLeft,
    fontWeight: FontWeights.semibold,
    backgroundColor: background,
    color,
    padding: "6px 8px",
    borderRadius: "4px"
  });
};
_s2(useStyles, "yAqk/mHsCk1OPWDYazbBUeiAsGM=", false, function() {
  return [useTagsColors];
});
const ListTags = [{
  value: AuditSituationEnum.Pendente,
  type: "Pendente"
}, {
  value: AuditSituationEnum.EmAndamento,
  type: "Andamento"
}, {
  value: AuditSituationEnum.Finalizado,
  type: "Concluido"
}, {
  value: AuditSituationEnum.Cancelado,
  type: "Recusado"
}, {
  value: AuditSituationEnum.Suspenso,
  type: "Inativo"
}, {
  value: AuditSituationEnum.EmSolicitacao,
  type: "Solicitacao"
}, {
  value: AuditSituationEnum.EmLevantamento,
  type: "Levantamento"
}, {
  value: AuditSituationEnum.Conferencia,
  type: "Conferencia"
}, {
  value: AuditSituationEnum.Apresentacao,
  type: "Apresentacao"
}, {
  value: AuditSituationEnum.Recorrente,
  type: "Recorrente"
}, {
  value: AuditSituationEnum.Implementacao,
  type: "Implementacao"
}, {
  value: AuditSituationEnum.Faturamento,
  type: "Lime"
}, {
  value: AuditSituationEnum.AIniciar,
  type: "Pendente"
}, {
  value: AuditSituationEnum.Restituicao,
  type: "Recorrente"
}, {
  value: AuditSituationEnum.AcaoJudicial,
  type: "Andamento"
}, {
  value: AuditSituationEnum.StandBy,
  type: "Andamento"
}, {
  value: AuditSituationEnum.Planejamento,
  type: "Levantamento"
}, {
  value: AuditSituationEnum.Acompanhamento,
  type: "Conferencia"
}];
export default _c2 = memo(AuditsSituation);
var _c, _c2;
$RefreshReg$(_c, "AuditsSituation");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditsSituation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkSixTQUFTQSxhQUFhQyxhQUFhQyxpQkFBaUI7QUFDcEQsU0FBYUMsWUFBWTtBQUN6QixTQUFTQywwQkFBMEI7QUFDbkMsU0FBZ0NDLHFCQUFxQjtBQUNyRCxTQUFTQyw0QkFBNEI7QUFPckMsTUFBTUMsa0JBQTZDQyxXQUFVO0FBQUFDLEtBQUE7QUFDM0QsUUFBTUMsU0FBU0MsVUFBVUgsS0FBSztBQUM5QixTQUNFLHVCQUFDLFNBQUksV0FBV0UsUUFBU0osK0JBQXFCRSxNQUFNSSxTQUErQixLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFGO0FBRXpGO0FBQUNILEdBTEtGLGlCQUF5QztBQUFBLFVBQzlCSSxTQUFTO0FBQUE7QUFBQUUsS0FEcEJOO0FBT04sTUFBTUksWUFBWUEsQ0FBQ0gsVUFBZ0M7QUFBQU0sTUFBQTtBQUNqRCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBWUM7QUFBQUEsRUFBTSxJQUFJWCxjQUFjRyxNQUFNSSxXQUFXSyxRQUFRO0FBRXJFLFNBQU9qQixZQUFZO0FBQUEsSUFDakJrQixTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLElBQ1pDLFVBQVVsQixVQUFVbUI7QUFBQUEsSUFDcEJDLFlBQVlkLE1BQU1jO0FBQUFBLElBQ2xCQyxZQUFZdEIsWUFBWXVCO0FBQUFBLElBQ3hCQyxpQkFBaUJWO0FBQUFBLElBQ2pCQztBQUFBQSxJQUNBVSxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFDSDtBQUFDYixJQWRLSCxXQUFTO0FBQUEsVUFDaUJOLGFBQWE7QUFBQTtBQWU3QyxNQUFNWSxXQUFXLENBQ2Y7QUFBQSxFQUNFVyxPQUFPeEIsbUJBQW1CeUI7QUFBQUEsRUFDMUJDLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQjJCO0FBQUFBLEVBQzFCRCxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VGLE9BQU94QixtQkFBbUI0QjtBQUFBQSxFQUMxQkYsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1CNkI7QUFBQUEsRUFDMUJILE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQjhCO0FBQUFBLEVBQzFCSixNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VGLE9BQU94QixtQkFBbUIrQjtBQUFBQSxFQUMxQkwsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1CZ0M7QUFBQUEsRUFDMUJOLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQmlDO0FBQUFBLEVBQzFCUCxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VGLE9BQU94QixtQkFBbUJrQztBQUFBQSxFQUMxQlIsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1CbUM7QUFBQUEsRUFDMUJULE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQm9DO0FBQUFBLEVBQzFCVixNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VGLE9BQU94QixtQkFBbUJxQztBQUFBQSxFQUMxQlgsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1Cc0M7QUFBQUEsRUFDMUJaLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQnVDO0FBQUFBLEVBQzFCYixNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VGLE9BQU94QixtQkFBbUJ3QztBQUFBQSxFQUMxQmQsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1CeUM7QUFBQUEsRUFDMUJmLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUYsT0FBT3hCLG1CQUFtQjBDO0FBQUFBLEVBQzFCaEIsTUFBTTtBQUNSLEdBQ0E7QUFBQSxFQUNFRixPQUFPeEIsbUJBQW1CMkM7QUFBQUEsRUFDMUJqQixNQUFNO0FBQ1IsQ0FBQztBQUdILGVBQUFrQixNQUFlN0MsS0FBS0ksZUFBZTtBQUFDLElBQUFNLElBQUFtQztBQUFBQyxhQUFBcEMsSUFBQTtBQUFBb0MsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIm1lcmdlU3R5bGVzIiwiRm9udFdlaWdodHMiLCJGb250U2l6ZXMiLCJtZW1vIiwiQXVkaXRTaXR1YXRpb25FbnVtIiwidXNlVGFnc0NvbG9ycyIsIkF1ZGl0U2l0dWF0aW9uUmVjb3JkIiwiQXVkaXRzU2l0dWF0aW9uIiwicHJvcHMiLCJfcyIsInN0eWxlcyIsInVzZVN0eWxlcyIsInNpdHVhdGlvbiIsIl9jIiwiX3MyIiwiYmFja2dyb3VuZCIsImNvbG9yIiwiTGlzdFRhZ3MiLCJkaXNwbGF5Iiwid2hpdGVTcGFjZSIsImZvbnRTaXplIiwibWluaSIsIm1hcmdpbkxlZnQiLCJmb250V2VpZ2h0Iiwic2VtaWJvbGQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwidmFsdWUiLCJQZW5kZW50ZSIsInR5cGUiLCJFbUFuZGFtZW50byIsIkZpbmFsaXphZG8iLCJDYW5jZWxhZG8iLCJTdXNwZW5zbyIsIkVtU29saWNpdGFjYW8iLCJFbUxldmFudGFtZW50byIsIkNvbmZlcmVuY2lhIiwiQXByZXNlbnRhY2FvIiwiUmVjb3JyZW50ZSIsIkltcGxlbWVudGFjYW8iLCJGYXR1cmFtZW50byIsIkFJbmljaWFyIiwiUmVzdGl0dWljYW8iLCJBY2FvSnVkaWNpYWwiLCJTdGFuZEJ5IiwiUGxhbmVqYW1lbnRvIiwiQWNvbXBhbmhhbWVudG8iLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdHNTaXR1YXRpb24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cy9BdWRpdHNTaXR1YXRpb24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZXMsIEZvbnRXZWlnaHRzLCBGb250U2l6ZXMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCBtZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcbmltcG9ydCB7IFRhZ3NDb21wb3NpdGlvbk1vZHVsZSwgdXNlVGFnc0NvbG9ycyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcy90YWdzQ29sb3JzJ1xyXG5pbXBvcnQgeyBBdWRpdFNpdHVhdGlvblJlY29yZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQvQXVkaXRTaXR1YXRpb25SZWNvcmQnXHJcblxyXG5pbnRlcmZhY2UgQXVkaXRzU2l0dWF0aW9uUHJvcHMge1xyXG4gIHNpdHVhdGlvbjogQXVkaXRTaXR1YXRpb25FbnVtXHJcbiAgbWFyZ2luTGVmdD86IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBBdWRpdHNTaXR1YXRpb246IEZDPEF1ZGl0c1NpdHVhdGlvblByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcyhwcm9wcylcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlc30+e0F1ZGl0U2l0dWF0aW9uUmVjb3JkW3Byb3BzLnNpdHVhdGlvbiBhcyBBdWRpdFNpdHVhdGlvbkVudW1dfTwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKHByb3BzOiBBdWRpdHNTaXR1YXRpb25Qcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgYmFja2dyb3VuZCwgY29sb3IgfSA9IHVzZVRhZ3NDb2xvcnMocHJvcHMuc2l0dWF0aW9uLCBMaXN0VGFncylcclxuXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVzKHtcclxuICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxyXG4gICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXHJcbiAgICBmb250U2l6ZTogRm9udFNpemVzLm1pbmksXHJcbiAgICBtYXJnaW5MZWZ0OiBwcm9wcy5tYXJnaW5MZWZ0LFxyXG4gICAgZm9udFdlaWdodDogRm9udFdlaWdodHMuc2VtaWJvbGQsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IGJhY2tncm91bmQsXHJcbiAgICBjb2xvcjogY29sb3IsXHJcbiAgICBwYWRkaW5nOiAnNnB4IDhweCcsXHJcbiAgICBib3JkZXJSYWRpdXM6ICc0cHgnLFxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IExpc3RUYWdzID0gW1xyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uUGVuZGVudGUsXHJcbiAgICB0eXBlOiAnUGVuZGVudGUnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5FbUFuZGFtZW50byxcclxuICAgIHR5cGU6ICdBbmRhbWVudG8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5GaW5hbGl6YWRvLFxyXG4gICAgdHlwZTogJ0NvbmNsdWlkbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkbyxcclxuICAgIHR5cGU6ICdSZWN1c2FkbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogQXVkaXRTaXR1YXRpb25FbnVtLlN1c3BlbnNvLFxyXG4gICAgdHlwZTogJ0luYXRpdm8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5FbVNvbGljaXRhY2FvLFxyXG4gICAgdHlwZTogJ1NvbGljaXRhY2FvJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uRW1MZXZhbnRhbWVudG8sXHJcbiAgICB0eXBlOiAnTGV2YW50YW1lbnRvJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uQ29uZmVyZW5jaWEsXHJcbiAgICB0eXBlOiAnQ29uZmVyZW5jaWEnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5BcHJlc2VudGFjYW8sXHJcbiAgICB0eXBlOiAnQXByZXNlbnRhY2FvJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uUmVjb3JyZW50ZSxcclxuICAgIHR5cGU6ICdSZWNvcnJlbnRlJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uSW1wbGVtZW50YWNhbyxcclxuICAgIHR5cGU6ICdJbXBsZW1lbnRhY2FvJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uRmF0dXJhbWVudG8sXHJcbiAgICB0eXBlOiAnTGltZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogQXVkaXRTaXR1YXRpb25FbnVtLkFJbmljaWFyLFxyXG4gICAgdHlwZTogJ1BlbmRlbnRlJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiBBdWRpdFNpdHVhdGlvbkVudW0uUmVzdGl0dWljYW8sXHJcbiAgICB0eXBlOiAnUmVjb3JyZW50ZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogQXVkaXRTaXR1YXRpb25FbnVtLkFjYW9KdWRpY2lhbCxcclxuICAgIHR5cGU6ICdBbmRhbWVudG8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5TdGFuZEJ5LFxyXG4gICAgdHlwZTogJ0FuZGFtZW50bycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogQXVkaXRTaXR1YXRpb25FbnVtLlBsYW5lamFtZW50byxcclxuICAgIHR5cGU6ICdMZXZhbnRhbWVudG8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IEF1ZGl0U2l0dWF0aW9uRW51bS5BY29tcGFuaGFtZW50byxcclxuICAgIHR5cGU6ICdDb25mZXJlbmNpYScsXHJcbiAgfSxcclxuXSBhcyBUYWdzQ29tcG9zaXRpb25Nb2R1bGVbXVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbWVtbyhBdWRpdHNTaXR1YXRpb24pXHJcbiJdfQ==