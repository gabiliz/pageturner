import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { mergeStyleSets, PivotItem, mergeStyles, MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport5_react["useMemo"]; const useState = __vite__cjsImport5_react["useState"];
import { useTheme } from "/src/shared/hooks/index.ts";
import { IconButton, PrimaryButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import { AppDrawer } from "/src/shared/components/drawer/index.ts?t=1701096626433";
import { FlexRow } from "/src/shared/components/FlexBox/index.ts";
import { Pivot } from "/src/shared/components/pivot/index.ts";
import NotificationsCenterList from "/src/shared/components/notifications/components/NotificationsCenterList.tsx?t=1701096626433";
import NotificationCenterTitlePivot from "/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx";
import { ModuleEnum } from "/src/shared/enums/ModuleEnum.ts";
import { LoadingScreen } from "/src/shared/components/loadingScreen/index.ts?t=1701096626433";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { notificationsQueryService, notificationsService } from "/src/shared/services/notificationsServices/index.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import NotificationsCenterSettingsContainer from "/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx?t=1701096626433";
const DrawerNotificationsCenter = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    notifications
  } = props;
  const styles = useStyles();
  const theme = useTheme();
  const [selectedKey, setSelectedKey] = useState("todas");
  const {
    currentAccount
  } = useAuth();
  const {
    mutateAsync
  } = useClear(selectedKey !== "todas" ? parseInt(selectedKey) : void 0);
  const [isSettingsDrawerOpen, {
    setTrue: showSettingsDrawer,
    setFalse: hideSettingsDrawer
  }] = useBoolean(false);
  const footer = useMemo(() => /* @__PURE__ */ jsxDEV("div", { className: styles.actionStyles.actions, children: /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Fechar", onClick: () => onDismiss() }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
    lineNumber: 49,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
    lineNumber: 48,
    columnNumber: 32
  }, this), []);
  return /* @__PURE__ */ jsxDEV(AppDrawer, { isOpen, onDismiss, title: "Notificações", footer, noPadding: true, children: [
    isSettingsDrawerOpen && /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsContainer, { isOpen: isSettingsDrawerOpen, onDismiss: hideSettingsDrawer }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
      lineNumber: 52,
      columnNumber: 32
    }, this),
    !notifications && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
      lineNumber: 53,
      columnNumber: 26
    }, this),
    notifications && /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", wrap: "nowrap", styles: {
      marginTop: 24
    }, children: [
      /* @__PURE__ */ jsxDEV(Pivot, { selectedKey, onLinkClick: (item) => setSelectedKey(item?.props.itemKey), style: {
        width: "100%"
      }, styles: {
        itemContainer: {
          paddingBottom: 0
        },
        root: {
          backgroundColor: theme.colors.white,
          zIndex: 1,
          paddingLeft: theme.spacing.xl
        }
      }, children: [
        /* @__PURE__ */ jsxDEV(PivotItem, { itemKey: "todas", onRenderItemLink: () => /* @__PURE__ */ jsxDEV(NotificationCenterTitlePivot, { text: "Todas", notifications }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 69,
          columnNumber: 62
        }, this), children: /* @__PURE__ */ jsxDEV(NotificationsCenterList, { notifications, onDismiss }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 70,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 69,
          columnNumber: 11
        }, this),
        currentAccount.value?.moduloAdministrativoNotificacao && /* @__PURE__ */ jsxDEV(PivotItem, { itemKey: ModuleEnum.Administrativo.toString(), onRenderItemLink: () => /* @__PURE__ */ jsxDEV(NotificationCenterTitlePivot, { text: "Administrativo", module: ModuleEnum.Administrativo, notifications }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 72,
          columnNumber: 151
        }, this), children: /* @__PURE__ */ jsxDEV(NotificationsCenterList, { notifications, module: ModuleEnum.Administrativo, onDismiss }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 73,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 72,
          columnNumber: 69
        }, this),
        currentAccount.value?.moduloFiscalNotificacao && /* @__PURE__ */ jsxDEV(PivotItem, { itemKey: ModuleEnum.Fiscal.toString(), onRenderItemLink: () => /* @__PURE__ */ jsxDEV(NotificationCenterTitlePivot, { text: "Fiscal", module: ModuleEnum.Fiscal, notifications }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 75,
          columnNumber: 135
        }, this), children: /* @__PURE__ */ jsxDEV(NotificationsCenterList, { notifications, module: ModuleEnum.Fiscal, onDismiss }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 76,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 75,
          columnNumber: 61
        }, this),
        currentAccount.value?.moduloContabilNotificacao && /* @__PURE__ */ jsxDEV(PivotItem, { itemKey: ModuleEnum.Contabil.toString(), onRenderItemLink: () => /* @__PURE__ */ jsxDEV(NotificationCenterTitlePivot, { text: "Projetos", module: ModuleEnum.Contabil, notifications }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 78,
          columnNumber: 139
        }, this), children: /* @__PURE__ */ jsxDEV(NotificationsCenterList, { notifications, module: ModuleEnum.Contabil, onDismiss }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 79,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 78,
          columnNumber: 63
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { wrap: "nowrap", styles: {
        position: "absolute",
        top: 24,
        right: 24,
        alignItems: "center",
        height: 44,
        zIndex: 10
      }, children: [
        /* @__PURE__ */ jsxDEV(IconButton, { onClick: () => mutateAsync({
          modulo: 1
        }), iconProps: {
          iconName: "Broom"
        }, styles: styles.pivotBarButton }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(IconButton, { onClick: showSettingsDrawer, styles: styles.pivotBarButton, iconProps: {
          iconName: "Settings"
        } }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
          lineNumber: 95,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
      lineNumber: 54,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx",
    lineNumber: 51,
    columnNumber: 10
  }, this);
};
_s(DrawerNotificationsCenter, "cJsBAToLJdFigBdLuzkPaHkMyEo=", false, function() {
  return [useStyles, useTheme, useAuth, useClear, useBoolean];
});
_c = DrawerNotificationsCenter;
export default DrawerNotificationsCenter;
const useStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  const actionStyles = mergeStyleSets({
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    },
    wrapper: {
      height: "65vh",
      position: "relative",
      maxHeight: "inherit"
    }
  });
  const navLinkContainer = mergeStyles({
    overflowY: "auto",
    maxHeight: "inherit",
    height: "100%",
    "> div": {
      marginTop: "45px"
    }
  });
  const pivotBarButton = {
    menuIcon: {
      fontSize: 14
    },
    iconHovered: {
      color: colors.gray[800]
    },
    rootHovered: {
      color: colors.gray[800]
    }
  };
  return {
    actionStyles,
    navLinkContainer,
    pivotBarButton
  };
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
const useClear = (moduleToDelete) => {
  _s3();
  const {
    showNotification
  } = useNotifications();
  return useMutation(() => {
    return notificationsService.clearAllNotifications(moduleToDelete ? {
      modulo: moduleToDelete
    } : void 0) || Promise.resolve();
  }, {
    onMutate: () => {
      showNotification({
        message: "Limpando notificações, aguarde.",
        type: MessageBarType.info
      });
    },
    onSuccess: () => {
      showNotification({
        message: "Limpo com sucesso!",
        type: MessageBarType.success
      });
      notificationsQueryService.invalidateQueries();
    },
    onError: (error) => {
      if (error.errors?.messages?.length !== void 0 && error.errors?.messages?.length > 0) {
        error.errors?.messages?.forEach((message) => showNotification({
          message: message.message,
          type: MessageBarType.error
        }));
      } else {
        showNotification({
          message: "Houve um problema no servidor",
          type: MessageBarType.error
        });
      }
    }
  });
};
_s3(useClear, "h3E96/uBWbCUn0cveO52RBfxszY=", false, function() {
  return [useNotifications, useMutation];
});
var _c;
$RefreshReg$(_c, "DrawerNotificationsCenter");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/DrawerNotificationsCenter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUNOLFNBQVNBLGdCQUFnQkMsV0FBV0MsYUFBNEJDLHNCQUFzQjtBQUN0RixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBYUMsU0FBU0MsZ0JBQWdCO0FBRXRDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZQyxxQkFBcUI7QUFDMUMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYTtBQUN0QixPQUFPQyw2QkFBNkI7QUFDcEMsT0FBT0Msa0NBQWtDO0FBQ3pDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsbUJBQXNDO0FBRS9DLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQywyQkFBMkJDLDRCQUE0QjtBQUNoRSxTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLDBDQUEwQztBQVFqRCxNQUFNQyw0QkFBaUVDLFdBQVU7QUFBQUMsS0FBQTtBQUMvRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBV0M7QUFBQUEsRUFBYyxJQUFJSjtBQUM3QyxRQUFNSyxTQUFTQyxVQUFVO0FBQ3pCLFFBQU1DLFFBQVF4QixTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ3lCLGFBQWFDLGNBQWMsSUFBSTNCLFNBQWlCLE9BQU87QUFDOUQsUUFBTTtBQUFBLElBQUU0QjtBQUFBQSxFQUFlLElBQUliLFFBQVE7QUFFbkMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLEVBQVksSUFBSUMsU0FBU0osZ0JBQWdCLFVBQzdDSyxTQUFTTCxXQUFXLElBQ3BCTSxNQUFTO0FBRWIsUUFBTSxDQUNKQyxzQkFDQTtBQUFBLElBQUVDLFNBQVNDO0FBQUFBLElBQW9CQyxVQUFVQztBQUFBQSxFQUFtQixDQUFDLElBQzNEdkMsV0FBVyxLQUFLO0FBRXBCLFFBQU13QyxTQUFTdkMsUUFBUSxNQUNyQix1QkFBQyxTQUFJLFdBQVd3QixPQUFPZ0IsYUFBYUMsU0FDbEMsaUNBQUMsaUJBQ0MsTUFBSyxVQUNMLFNBQVMsTUFBTW5CLFVBQVUsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUU2QixLQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0EsR0FDQyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxhQUNDLFFBQ0EsV0FDQSxPQUFNLGdCQUNOLFFBQ0EsV0FBUyxNQUVSWTtBQUFBQSw0QkFDRCx1QkFBQyx3Q0FDQyxRQUFRQSxzQkFDUixXQUFXSSxzQkFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWdDO0FBQUEsSUFHL0IsQ0FBQ2YsaUJBQWlCLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBQ2hDQSxpQkFBaUIsdUJBQUMsV0FDakIsaUJBQWdCLGlCQUNoQixNQUFLLFVBQ0wsUUFBUTtBQUFBLE1BQUVtQixXQUFXO0FBQUEsSUFBRyxHQUV4QjtBQUFBLDZCQUFDLFNBQ0MsYUFDQSxhQUFjQyxVQUFTZixlQUFlZSxNQUFNeEIsTUFBTXlCLE9BQWlCLEdBQ25FLE9BQU87QUFBQSxRQUNMQyxPQUFPO0FBQUEsTUFDVCxHQUNBLFFBQVE7QUFBQSxRQUNOQyxlQUFlO0FBQUEsVUFDYkMsZUFBZTtBQUFBLFFBQ2pCO0FBQUEsUUFDQUMsTUFBTTtBQUFBLFVBQ0pDLGlCQUFpQnZCLE1BQU13QixPQUFPQztBQUFBQSxVQUM5QkMsUUFBUTtBQUFBLFVBQ1JDLGFBQWEzQixNQUFNNEIsUUFBUUM7QUFBQUEsUUFFN0I7QUFBQSxNQUNGLEdBRUE7QUFBQSwrQkFBQyxhQUNDLFNBQVEsU0FDUixrQkFBa0IsTUFDaEIsdUJBQUMsZ0NBQ0MsTUFBSyxTQUNMLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFK0IsR0FHakMsaUNBQUMsMkJBQ0MsZUFDQSxhQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFdUIsS0FWekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFDQzFCLGVBQWUyQixPQUFPQyxtQ0FDckIsdUJBQUMsYUFDQyxTQUFTL0MsV0FBV2dELGVBQWVDLFNBQVMsR0FDNUMsa0JBQWtCLE1BQ2hCLHVCQUFDLGdDQUNDLE1BQUssa0JBQ0wsUUFBUWpELFdBQVdnRCxnQkFDbkIsaUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUcrQixHQUdqQyxpQ0FBQywyQkFDQyxlQUNBLFFBQVFoRCxXQUFXZ0QsZ0JBQ25CLGFBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd1QixLQVp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUVEN0IsZUFBZTJCLE9BQU9JLDJCQUNyQix1QkFBQyxhQUNDLFNBQVNsRCxXQUFXbUQsT0FBT0YsU0FBUyxHQUNwQyxrQkFBa0IsTUFDaEIsdUJBQUMsZ0NBQ0MsTUFBSyxVQUNMLFFBQVFqRCxXQUFXbUQsUUFDbkIsaUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUcrQixHQUdqQyxpQ0FBQywyQkFDQyxlQUNBLFFBQVFuRCxXQUFXbUQsUUFDbkIsYUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR3VCLEtBWnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBRURoQyxlQUFlMkIsT0FBT00sNkJBQ3JCLHVCQUFDLGFBQ0MsU0FBU3BELFdBQVdxRCxTQUFTSixTQUFTLEdBQ3RDLGtCQUFrQixNQUNoQix1QkFBQyxnQ0FDQyxNQUFLLFlBQ0wsUUFBUWpELFdBQVdxRCxVQUNuQixpQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRytCLEdBR2pDLGlDQUFDLDJCQUNDLGVBQ0EsUUFBUXJELFdBQVdxRCxVQUNuQixhQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHdUIsS0FaekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FoRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtGQTtBQUFBLE1BQ0EsdUJBQUMsV0FDQyxNQUFLLFVBQ0wsUUFBUTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxRQUNWQyxLQUFLO0FBQUEsUUFDTEMsT0FBTztBQUFBLFFBQ1BDLFlBQVk7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUmhCLFFBQVE7QUFBQSxNQUNWLEdBRUE7QUFBQSwrQkFBQyxjQUNDLFNBQVMsTUFBTXRCLFlBQVk7QUFBQSxVQUFFdUMsUUFBUTtBQUFBLFFBQUUsQ0FBQyxHQUN4QyxXQUFXO0FBQUEsVUFDVEMsVUFBVTtBQUFBLFFBQ1osR0FDQSxRQUFROUMsT0FBTytDLGtCQUxqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2dDO0FBQUEsUUFFaEMsdUJBQUMsY0FDQyxTQUFTbkMsb0JBQ1QsUUFBUVosT0FBTytDLGdCQUNmLFdBQVc7QUFBQSxVQUNURCxVQUFVO0FBQUEsUUFDWixLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLSTtBQUFBLFdBdkJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQWpIZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtIbEI7QUFBQSxPQWhJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0lBO0FBRUo7QUFBQ2xELEdBOUpLRiwyQkFBNkQ7QUFBQSxVQUVsRE8sV0FDRHZCLFVBRWFjLFNBRUhlLFVBT3BCaEMsVUFBVTtBQUFBO0FBQUF5RSxLQWRWdEQ7QUFnS04sZUFBZUE7QUFFZixNQUFNTyxZQUFZQSxNQUFNO0FBQUFnRCxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFbkI7QUFBQUEsSUFBU0o7QUFBQUEsRUFBTyxJQUFJaEQsU0FBUztBQUVyQyxRQUFNc0MsZUFBZTdDLGVBQWU7QUFBQSxJQUNsQzhDLFNBQVM7QUFBQSxNQUNQaUMsU0FBUztBQUFBLE1BQ1RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxXQUFXO0FBQUEsUUFDVCx5QkFBeUI7QUFBQSxVQUN2QkMsYUFBYXZCLFFBQVF3QjtBQUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQUMsU0FBUztBQUFBLE1BQ1BYLFFBQVE7QUFBQSxNQUNSSixVQUFVO0FBQUEsTUFDVmdCLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTUMsbUJBQW1CcEYsWUFBWTtBQUFBLElBQ25DcUYsV0FBVztBQUFBLElBQ1hGLFdBQVc7QUFBQSxJQUNYWixRQUFRO0FBQUEsSUFDUixTQUFTO0FBQUEsTUFDUDFCLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTTZCLGlCQUF5QztBQUFBLElBQzdDWSxVQUFVO0FBQUEsTUFDUkMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBQyxhQUFhO0FBQUEsTUFDWEMsT0FBT3BDLE9BQU9xQyxLQUFLLEdBQUc7QUFBQSxJQUN4QjtBQUFBLElBQ0FDLGFBQWE7QUFBQSxNQUNYRixPQUFPcEMsT0FBT3FDLEtBQUssR0FBRztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBLFNBQU87QUFBQSxJQUNML0M7QUFBQUEsSUFDQXlDO0FBQUFBLElBQ0FWO0FBQUFBLEVBQ0Y7QUFDRjtBQUFDRSxJQTlDS2hELFdBQVM7QUFBQSxVQUNldkIsUUFBUTtBQUFBO0FBK0N0QyxNQUFNNkIsV0FBV0EsQ0FBQzBELG1CQUFtRTtBQUFBQyxNQUFBO0FBQ25GLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFpQixJQUFJOUUsaUJBQWlCO0FBQzlDLFNBQU9ELFlBQ0wsTUFBTTtBQUNKLFdBQU9HLHFCQUFxQjZFLHNCQUFzQkgsaUJBQzlDO0FBQUEsTUFBRXBCLFFBQVFvQjtBQUFBQSxJQUFlLElBQ3pCeEQsTUFBUyxLQUFLNEQsUUFBUUMsUUFBUTtBQUFBLEVBQ3BDLEdBQ0E7QUFBQSxJQUNFQyxVQUFVQSxNQUFNO0FBQ2RKLHVCQUFpQjtBQUFBLFFBQ2ZLLFNBQVM7QUFBQSxRQUNUQyxNQUFNbkcsZUFBZW9HO0FBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFDQUMsV0FBV0EsTUFBTTtBQUNmUix1QkFBaUI7QUFBQSxRQUNmSyxTQUFTO0FBQUEsUUFDVEMsTUFBTW5HLGVBQWVzRztBQUFBQSxNQUN2QixDQUFDO0FBQ0R0RixnQ0FBMEJ1RixrQkFBa0I7QUFBQSxJQUM5QztBQUFBLElBQ0FDLFNBQVVDLFdBQVU7QUFDbEIsVUFBSUEsTUFBTUMsUUFBUUMsVUFBVUMsV0FBV3pFLFVBQWFzRSxNQUFNQyxRQUFRQyxVQUFVQyxTQUFTLEdBQUc7QUFDdEZILGNBQU1DLFFBQVFDLFVBQVVFLFFBQVFYLGFBQVdMLGlCQUFpQjtBQUFBLFVBQzFESyxTQUFTQSxRQUFRQTtBQUFBQSxVQUNqQkMsTUFBTW5HLGVBQWV5RztBQUFBQSxRQUN2QixDQUFDLENBQUM7QUFBQSxNQUNKLE9BQU87QUFDTFoseUJBQWlCO0FBQUEsVUFDZkssU0FBUztBQUFBLFVBQ1RDLE1BQU1uRyxlQUFleUc7QUFBQUEsUUFDdkIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUNGO0FBQ0Y7QUFBQ2IsSUFyQ0szRCxVQUFRO0FBQUEsVUFDaUJsQixrQkFDdEJELFdBQVc7QUFBQTtBQUFBLElBQUE0RDtBQUFBb0MsYUFBQXBDLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsIlBpdm90SXRlbSIsIm1lcmdlU3R5bGVzIiwiTWVzc2FnZUJhclR5cGUiLCJ1c2VCb29sZWFuIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlVGhlbWUiLCJJY29uQnV0dG9uIiwiUHJpbWFyeUJ1dHRvbiIsIkFwcERyYXdlciIsIkZsZXhSb3ciLCJQaXZvdCIsIk5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0IiwiTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdCIsIk1vZHVsZUVudW0iLCJMb2FkaW5nU2NyZWVuIiwidXNlTXV0YXRpb24iLCJ1c2VOb3RpZmljYXRpb25zIiwibm90aWZpY2F0aW9uc1F1ZXJ5U2VydmljZSIsIm5vdGlmaWNhdGlvbnNTZXJ2aWNlIiwidXNlQXV0aCIsIk5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NvbnRhaW5lciIsIkRyYXdlck5vdGlmaWNhdGlvbnNDZW50ZXIiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwibm90aWZpY2F0aW9ucyIsInN0eWxlcyIsInVzZVN0eWxlcyIsInRoZW1lIiwic2VsZWN0ZWRLZXkiLCJzZXRTZWxlY3RlZEtleSIsImN1cnJlbnRBY2NvdW50IiwibXV0YXRlQXN5bmMiLCJ1c2VDbGVhciIsInBhcnNlSW50IiwidW5kZWZpbmVkIiwiaXNTZXR0aW5nc0RyYXdlck9wZW4iLCJzZXRUcnVlIiwic2hvd1NldHRpbmdzRHJhd2VyIiwic2V0RmFsc2UiLCJoaWRlU2V0dGluZ3NEcmF3ZXIiLCJmb290ZXIiLCJhY3Rpb25TdHlsZXMiLCJhY3Rpb25zIiwibWFyZ2luVG9wIiwiaXRlbSIsIml0ZW1LZXkiLCJ3aWR0aCIsIml0ZW1Db250YWluZXIiLCJwYWRkaW5nQm90dG9tIiwicm9vdCIsImJhY2tncm91bmRDb2xvciIsImNvbG9ycyIsIndoaXRlIiwiekluZGV4IiwicGFkZGluZ0xlZnQiLCJzcGFjaW5nIiwieGwiLCJ2YWx1ZSIsIm1vZHVsb0FkbWluaXN0cmF0aXZvTm90aWZpY2FjYW8iLCJBZG1pbmlzdHJhdGl2byIsInRvU3RyaW5nIiwibW9kdWxvRmlzY2FsTm90aWZpY2FjYW8iLCJGaXNjYWwiLCJtb2R1bG9Db250YWJpbE5vdGlmaWNhY2FvIiwiQ29udGFiaWwiLCJwb3NpdGlvbiIsInRvcCIsInJpZ2h0IiwiYWxpZ25JdGVtcyIsImhlaWdodCIsIm1vZHVsbyIsImljb25OYW1lIiwicGl2b3RCYXJCdXR0b24iLCJfYyIsIl9zMiIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsInNlbGVjdG9ycyIsIm1hcmdpblJpZ2h0IiwibGciLCJ3cmFwcGVyIiwibWF4SGVpZ2h0IiwibmF2TGlua0NvbnRhaW5lciIsIm92ZXJmbG93WSIsIm1lbnVJY29uIiwiZm9udFNpemUiLCJpY29uSG92ZXJlZCIsImNvbG9yIiwiZ3JheSIsInJvb3RIb3ZlcmVkIiwibW9kdWxlVG9EZWxldGUiLCJfczMiLCJzaG93Tm90aWZpY2F0aW9uIiwiY2xlYXJBbGxOb3RpZmljYXRpb25zIiwiUHJvbWlzZSIsInJlc29sdmUiLCJvbk11dGF0ZSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaW5mbyIsIm9uU3VjY2VzcyIsInN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uRXJyb3IiLCJlcnJvciIsImVycm9ycyIsIm1lc3NhZ2VzIiwibGVuZ3RoIiwiZm9yRWFjaCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRyYXdlck5vdGlmaWNhdGlvbnNDZW50ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9jb21wb25lbnRzL0RyYXdlck5vdGlmaWNhdGlvbnNDZW50ZXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMsIFBpdm90SXRlbSwgbWVyZ2VTdHlsZXMsIElCdXR0b25TdHlsZXMsIE1lc3NhZ2VCYXJUeXBlIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VCb29sZWFuIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWhvb2tzJ1xyXG5pbXBvcnQgeyBGQywgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEFwcE5vdGlmaWNhdGlvbiBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQXBwTm90aWZpY2F0aW9uJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzJ1xyXG5pbXBvcnQgeyBJY29uQnV0dG9uLCBQcmltYXJ5QnV0dG9uIH0gZnJvbSAnLi4vLi4vYnV0dG9ucydcclxuaW1wb3J0IHsgQXBwRHJhd2VyIH0gZnJvbSAnLi4vLi4vZHJhd2VyJ1xyXG5pbXBvcnQgeyBGbGV4Um93IH0gZnJvbSAnLi4vLi4vRmxleEJveCdcclxuaW1wb3J0IHsgUGl2b3QgfSBmcm9tICcuLi8uLi9waXZvdCdcclxuaW1wb3J0IE5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0IGZyb20gJy4vTm90aWZpY2F0aW9uc0NlbnRlckxpc3QnXHJcbmltcG9ydCBOb3RpZmljYXRpb25DZW50ZXJUaXRsZVBpdm90IGZyb20gJy4vTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdCdcclxuaW1wb3J0IHsgTW9kdWxlRW51bSB9IGZyb20gJy4uLy4uLy4uL2VudW1zL01vZHVsZUVudW0nXHJcbmltcG9ydCB7IExvYWRpbmdTY3JlZW4gfSBmcm9tICcuLi8uLi9sb2FkaW5nU2NyZWVuJ1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgVXNlTXV0YXRpb25SZXN1bHQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vLi4vZXJyb3JzJ1xyXG5pbXBvcnQgeyB1c2VOb3RpZmljYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb25zUXVlcnlTZXJ2aWNlLCBub3RpZmljYXRpb25zU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL25vdGlmaWNhdGlvbnNTZXJ2aWNlcydcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uLy4uL21vZHVsZXMvYXV0aC9zdG9yZS9hdXRoJ1xyXG5pbXBvcnQgTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyIGZyb20gJy4vTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyJ1xyXG5cclxuaW50ZXJmYWNlIERyYXdlck5vdGlmaWNhdGlvbnNDZW50ZXJQcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuXHJcbiAgb25EaXNtaXNzOiAoKSA9PiB2b2lkXHJcbiAgbm90aWZpY2F0aW9uczogQXBwTm90aWZpY2F0aW9uW11cclxufVxyXG5cclxuY29uc3QgRHJhd2VyTm90aWZpY2F0aW9uc0NlbnRlcjogRkM8RHJhd2VyTm90aWZpY2F0aW9uc0NlbnRlclByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgaXNPcGVuLCBvbkRpc21pc3MsIG5vdGlmaWNhdGlvbnMgfSA9IHByb3BzXHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBbc2VsZWN0ZWRLZXksIHNldFNlbGVjdGVkS2V5XSA9IHVzZVN0YXRlPHN0cmluZz4oJ3RvZGFzJylcclxuICBjb25zdCB7IGN1cnJlbnRBY2NvdW50IH0gPSB1c2VBdXRoKClcclxuXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYyB9ID0gdXNlQ2xlYXIoc2VsZWN0ZWRLZXkgIT09ICd0b2RhcydcclxuICAgID8gcGFyc2VJbnQoc2VsZWN0ZWRLZXkpXHJcbiAgICA6IHVuZGVmaW5lZClcclxuXHJcbiAgY29uc3QgW1xyXG4gICAgaXNTZXR0aW5nc0RyYXdlck9wZW4sXHJcbiAgICB7IHNldFRydWU6IHNob3dTZXR0aW5nc0RyYXdlciwgc2V0RmFsc2U6IGhpZGVTZXR0aW5nc0RyYXdlciB9LFxyXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG5cclxuICBjb25zdCBmb290ZXIgPSB1c2VNZW1vKCgpID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYWN0aW9uU3R5bGVzLmFjdGlvbnN9PlxyXG4gICAgICA8UHJpbWFyeUJ1dHRvblxyXG4gICAgICAgIHRleHQ9XCJGZWNoYXJcIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGlzbWlzcygpfVxyXG4gICAgICAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKSwgW10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QXBwRHJhd2VyXHJcbiAgICAgIGlzT3Blbj17aXNPcGVufVxyXG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cclxuICAgICAgdGl0bGU9J05vdGlmaWNhw6fDtWVzJ1xyXG4gICAgICBmb290ZXI9e2Zvb3Rlcn1cclxuICAgICAgbm9QYWRkaW5nXHJcbiAgICA+XHJcbiAgICAgIHtpc1NldHRpbmdzRHJhd2VyT3BlbiAmJlxyXG4gICAgICA8Tm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyXHJcbiAgICAgICAgaXNPcGVuPXtpc1NldHRpbmdzRHJhd2VyT3Blbn1cclxuICAgICAgICBvbkRpc21pc3M9e2hpZGVTZXR0aW5nc0RyYXdlcn1cclxuICAgICAgLz5cclxuICAgICAgfVxyXG4gICAgICB7IW5vdGlmaWNhdGlvbnMgJiYgPExvYWRpbmdTY3JlZW4gLz59XHJcbiAgICAgIHtub3RpZmljYXRpb25zICYmIDxGbGV4Um93XHJcbiAgICAgICAgaG9yaXpvbnRhbEFsaWduPSdzcGFjZS1iZXR3ZWVuJ1xyXG4gICAgICAgIHdyYXA9J25vd3JhcCdcclxuICAgICAgICBzdHlsZXM9e3sgbWFyZ2luVG9wOiAyNCB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPFBpdm90XHJcbiAgICAgICAgICBzZWxlY3RlZEtleT17c2VsZWN0ZWRLZXl9XHJcbiAgICAgICAgICBvbkxpbmtDbGljaz17KGl0ZW0pID0+IHNldFNlbGVjdGVkS2V5KGl0ZW0/LnByb3BzLml0ZW1LZXkgYXMgc3RyaW5nKX1cclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIGl0ZW1Db250YWluZXI6IHtcclxuICAgICAgICAgICAgICBwYWRkaW5nQm90dG9tOiAwLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb2xvcnMud2hpdGUsXHJcbiAgICAgICAgICAgICAgekluZGV4OiAxLFxyXG4gICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiB0aGVtZS5zcGFjaW5nLnhsLFxyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFBpdm90SXRlbVxyXG4gICAgICAgICAgICBpdGVtS2V5PSd0b2RhcydcclxuICAgICAgICAgICAgb25SZW5kZXJJdGVtTGluaz17KCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxOb3RpZmljYXRpb25DZW50ZXJUaXRsZVBpdm90XHJcbiAgICAgICAgICAgICAgICB0ZXh0PSdUb2RhcydcclxuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbnM9e25vdGlmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgICAgLz4pfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Tm90aWZpY2F0aW9uc0NlbnRlckxpc3RcclxuICAgICAgICAgICAgICBub3RpZmljYXRpb25zPXtub3RpZmljYXRpb25zfVxyXG4gICAgICAgICAgICAgIG9uRGlzbWlzcz17b25EaXNtaXNzfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9QaXZvdEl0ZW0+XHJcbiAgICAgICAgICB7Y3VycmVudEFjY291bnQudmFsdWU/Lm1vZHVsb0FkbWluaXN0cmF0aXZvTm90aWZpY2FjYW8gJiZcclxuICAgICAgICAgICAgPFBpdm90SXRlbVxyXG4gICAgICAgICAgICAgIGl0ZW1LZXk9e01vZHVsZUVudW0uQWRtaW5pc3RyYXRpdm8udG9TdHJpbmcoKX1cclxuICAgICAgICAgICAgICBvblJlbmRlckl0ZW1MaW5rPXsoKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Tm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdFxyXG4gICAgICAgICAgICAgICAgICB0ZXh0PSdBZG1pbmlzdHJhdGl2bydcclxuICAgICAgICAgICAgICAgICAgbW9kdWxlPXtNb2R1bGVFbnVtLkFkbWluaXN0cmF0aXZvfVxyXG4gICAgICAgICAgICAgICAgICBub3RpZmljYXRpb25zPXtub3RpZmljYXRpb25zfVxyXG4gICAgICAgICAgICAgICAgLz4pfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPE5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0XHJcbiAgICAgICAgICAgICAgICBub3RpZmljYXRpb25zPXtub3RpZmljYXRpb25zfVxyXG4gICAgICAgICAgICAgICAgbW9kdWxlPXtNb2R1bGVFbnVtLkFkbWluaXN0cmF0aXZvfVxyXG4gICAgICAgICAgICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9QaXZvdEl0ZW0+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB7Y3VycmVudEFjY291bnQudmFsdWU/Lm1vZHVsb0Zpc2NhbE5vdGlmaWNhY2FvICYmXHJcbiAgICAgICAgICAgIDxQaXZvdEl0ZW1cclxuICAgICAgICAgICAgICBpdGVtS2V5PXtNb2R1bGVFbnVtLkZpc2NhbC50b1N0cmluZygpfVxyXG4gICAgICAgICAgICAgIG9uUmVuZGVySXRlbUxpbms9eygpID0+IChcclxuICAgICAgICAgICAgICAgIDxOb3RpZmljYXRpb25DZW50ZXJUaXRsZVBpdm90XHJcbiAgICAgICAgICAgICAgICAgIHRleHQ9J0Zpc2NhbCdcclxuICAgICAgICAgICAgICAgICAgbW9kdWxlPXtNb2R1bGVFbnVtLkZpc2NhbH1cclxuICAgICAgICAgICAgICAgICAgbm90aWZpY2F0aW9ucz17bm90aWZpY2F0aW9uc31cclxuICAgICAgICAgICAgICAgIC8+KX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyTGlzdFxyXG4gICAgICAgICAgICAgICAgbm90aWZpY2F0aW9ucz17bm90aWZpY2F0aW9uc31cclxuICAgICAgICAgICAgICAgIG1vZHVsZT17TW9kdWxlRW51bS5GaXNjYWx9XHJcbiAgICAgICAgICAgICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L1Bpdm90SXRlbT5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHtjdXJyZW50QWNjb3VudC52YWx1ZT8ubW9kdWxvQ29udGFiaWxOb3RpZmljYWNhbyAmJlxyXG4gICAgICAgICAgICA8UGl2b3RJdGVtXHJcbiAgICAgICAgICAgICAgaXRlbUtleT17TW9kdWxlRW51bS5Db250YWJpbC50b1N0cmluZygpfVxyXG4gICAgICAgICAgICAgIG9uUmVuZGVySXRlbUxpbms9eygpID0+IChcclxuICAgICAgICAgICAgICAgIDxOb3RpZmljYXRpb25DZW50ZXJUaXRsZVBpdm90XHJcbiAgICAgICAgICAgICAgICAgIHRleHQ9J1Byb2pldG9zJ1xyXG4gICAgICAgICAgICAgICAgICBtb2R1bGU9e01vZHVsZUVudW0uQ29udGFiaWx9XHJcbiAgICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbnM9e25vdGlmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAvPil9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Tm90aWZpY2F0aW9uc0NlbnRlckxpc3RcclxuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbnM9e25vdGlmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgICAgICBtb2R1bGU9e01vZHVsZUVudW0uQ29udGFiaWx9XHJcbiAgICAgICAgICAgICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L1Bpdm90SXRlbT5cclxuICAgICAgICAgIH1cclxuICAgICAgICA8L1Bpdm90PlxyXG4gICAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgICB3cmFwPSdub3dyYXAnXHJcbiAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgIHRvcDogMjQsXHJcbiAgICAgICAgICAgIHJpZ2h0OiAyNCxcclxuICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgIGhlaWdodDogNDQsXHJcbiAgICAgICAgICAgIHpJbmRleDogMTAsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG11dGF0ZUFzeW5jKHsgbW9kdWxvOiAxIH0pfVxyXG4gICAgICAgICAgICBpY29uUHJvcHM9e3tcclxuICAgICAgICAgICAgICBpY29uTmFtZTogJ0Jyb29tJyxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgc3R5bGVzPXtzdHlsZXMucGl2b3RCYXJCdXR0b259XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17c2hvd1NldHRpbmdzRHJhd2VyfVxyXG4gICAgICAgICAgICBzdHlsZXM9e3N0eWxlcy5waXZvdEJhckJ1dHRvbn1cclxuICAgICAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICAgICAgaWNvbk5hbWU6ICdTZXR0aW5ncycsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRmxleFJvdz5cclxuICAgICAgPC9GbGV4Um93Pn1cclxuXHJcbiAgICA8L0FwcERyYXdlcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IERyYXdlck5vdGlmaWNhdGlvbnNDZW50ZXJcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB7IHNwYWNpbmcsIGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxyXG5cclxuICBjb25zdCBhY3Rpb25TdHlsZXMgPSBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBhY3Rpb25zOiB7XHJcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCcsXHJcbiAgICAgIHNlbGVjdG9yczoge1xyXG4gICAgICAgICcmID4gOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICBtYXJnaW5SaWdodDogc3BhY2luZy5sZyxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHdyYXBwZXI6IHtcclxuICAgICAgaGVpZ2h0OiAnNjV2aCcsXHJcbiAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICBtYXhIZWlnaHQ6ICdpbmhlcml0JyxcclxuICAgIH0sXHJcbiAgfSlcclxuXHJcbiAgY29uc3QgbmF2TGlua0NvbnRhaW5lciA9IG1lcmdlU3R5bGVzKHtcclxuICAgIG92ZXJmbG93WTogJ2F1dG8nLFxyXG4gICAgbWF4SGVpZ2h0OiAnaW5oZXJpdCcsXHJcbiAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICc+IGRpdic6IHtcclxuICAgICAgbWFyZ2luVG9wOiAnNDVweCcsXHJcbiAgICB9LFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IHBpdm90QmFyQnV0dG9uOiBQYXJ0aWFsPElCdXR0b25TdHlsZXM+ID0ge1xyXG4gICAgbWVudUljb246IHtcclxuICAgICAgZm9udFNpemU6IDE0LFxyXG4gICAgfSxcclxuICAgIGljb25Ib3ZlcmVkOiB7XHJcbiAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs4MDBdLFxyXG4gICAgfSxcclxuICAgIHJvb3RIb3ZlcmVkOiB7XHJcbiAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs4MDBdLFxyXG4gICAgfSxcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBhY3Rpb25TdHlsZXMsXHJcbiAgICBuYXZMaW5rQ29udGFpbmVyLFxyXG4gICAgcGl2b3RCYXJCdXR0b24sXHJcbiAgfVxyXG59XHJcblxyXG5jb25zdCB1c2VDbGVhciA9IChtb2R1bGVUb0RlbGV0ZT86IE1vZHVsZUVudW0pOiBVc2VNdXRhdGlvblJlc3VsdDx2b2lkLCBBcGlFcnJvcj4gPT4ge1xyXG4gIGNvbnN0IHsgc2hvd05vdGlmaWNhdGlvbiB9ID0gdXNlTm90aWZpY2F0aW9ucygpXHJcbiAgcmV0dXJuIHVzZU11dGF0aW9uKFxyXG4gICAgKCkgPT4ge1xyXG4gICAgICByZXR1cm4gbm90aWZpY2F0aW9uc1NlcnZpY2UuY2xlYXJBbGxOb3RpZmljYXRpb25zKG1vZHVsZVRvRGVsZXRlXHJcbiAgICAgICAgPyB7IG1vZHVsbzogbW9kdWxlVG9EZWxldGUgfVxyXG4gICAgICAgIDogdW5kZWZpbmVkKSB8fCBQcm9taXNlLnJlc29sdmUoKVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgb25NdXRhdGU6ICgpID0+IHtcclxuICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgIG1lc3NhZ2U6ICdMaW1wYW5kbyBub3RpZmljYcOnw7VlcywgYWd1YXJkZS4nLFxyXG4gICAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuaW5mbyxcclxuICAgICAgICB9KVxyXG4gICAgICB9LFxyXG4gICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgIG1lc3NhZ2U6ICdMaW1wbyBjb20gc3VjZXNzbyEnLFxyXG4gICAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuc3VjY2VzcyxcclxuICAgICAgICB9KVxyXG4gICAgICAgIG5vdGlmaWNhdGlvbnNRdWVyeVNlcnZpY2UuaW52YWxpZGF0ZVF1ZXJpZXMoKVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yOiAoZXJyb3IpID0+IHtcclxuICAgICAgICBpZiAoZXJyb3IuZXJyb3JzPy5tZXNzYWdlcz8ubGVuZ3RoICE9PSB1bmRlZmluZWQgJiYgZXJyb3IuZXJyb3JzPy5tZXNzYWdlcz8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgZXJyb3IuZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaChtZXNzYWdlID0+IHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBtZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxyXG4gICAgICAgICAgfSkpXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiAnSG91dmUgdW0gcHJvYmxlbWEgbm8gc2Vydmlkb3InLFxyXG4gICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICApXHJcbn1cclxuIl19