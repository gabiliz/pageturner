import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/charts/DonutChart.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/DonutChart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_reactApexcharts from "/node_modules/.vite/deps/react-apexcharts.js?v=9f90a7ff"; const Chart = __vite__cjsImport3_reactApexcharts.__esModule ? __vite__cjsImport3_reactApexcharts.default : __vite__cjsImport3_reactApexcharts;
import { useTheme } from "/src/shared/hooks/index.ts";
const DonutChart = (props) => {
  _s();
  const {
    colors,
    fontSize
  } = useTheme();
  const {
    series,
    height,
    width,
    labels,
    scale,
    donutPercentSize,
    dataLabelOffset,
    showDonutLabel,
    showDonutLabelName,
    showDonutLabelValue,
    enableTooltip,
    enableTooltipShadow,
    expandOnClick,
    donutLabelValueFontSize = fontSize.h1,
    donutLabelNameFontSize = fontSize.p14,
    dataLabelFontSize = fontSize.p16
  } = props;
  const options = {
    colors: [colors.blue[800], colors.blue[600], colors.blue[500], colors.blue[300], colors.blue[200]],
    dataLabels: {
      style: {
        fontSize: dataLabelFontSize,
        colors: [colors.gray[600]]
      },
      dropShadow: {
        enabled: enableTooltipShadow
      }
    },
    tooltip: {
      enabled: enableTooltip
    },
    labels,
    legend: {
      width: 200
    },
    plotOptions: {
      pie: {
        expandOnClick,
        dataLabels: {
          offset: dataLabelOffset
        },
        customScale: scale,
        donut: {
          size: donutPercentSize,
          labels: {
            show: showDonutLabel,
            name: {
              show: showDonutLabelName,
              fontSize: donutLabelNameFontSize
            },
            value: {
              show: showDonutLabelValue,
              fontSize: donutLabelValueFontSize,
              color: colors.gray[600]
            }
          }
        }
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Chart, { series, type: "donut", options, width, height }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/DonutChart.tsx",
    lineNumber: 91,
    columnNumber: 10
  }, this);
};
_s(DonutChart, "ml7ehOPkhnsO8BR7hBqymGyOxPM=", false, function() {
  return [useTheme];
});
_c = DonutChart;
export default DonutChart;
var _c;
$RefreshReg$(_c, "DonutChart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/DonutChart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZJOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0ZKLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsZ0JBQWdCO0FBcUJ6QixNQUFNQyxhQUFtQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQ2pELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFRQztBQUFBQSxFQUFTLElBQUlMLFNBQVM7QUFDdEMsUUFBTTtBQUFBLElBQ0pNO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLDBCQUEwQmQsU0FBU2U7QUFBQUEsSUFDbkNDLHlCQUF5QmhCLFNBQVNpQjtBQUFBQSxJQUNsQ0Msb0JBQW9CbEIsU0FBU21CO0FBQUFBLEVBQy9CLElBQUl0QjtBQUVKLFFBQU11QixVQUF1QjtBQUFBLElBQzNCckIsUUFBUSxDQUNOQSxPQUFPc0IsS0FBSyxHQUFHLEdBQ2Z0QixPQUFPc0IsS0FBSyxHQUFHLEdBQ2Z0QixPQUFPc0IsS0FBSyxHQUFHLEdBQ2Z0QixPQUFPc0IsS0FBSyxHQUFHLEdBQ2Z0QixPQUFPc0IsS0FBSyxHQUFHLENBQUM7QUFBQSxJQUVsQkMsWUFBWTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxRQUNMdkIsVUFBVWtCO0FBQUFBLFFBQ1ZuQixRQUFRLENBQUNBLE9BQU95QixLQUFLLEdBQUcsQ0FBQztBQUFBLE1BQzNCO0FBQUEsTUFDQUMsWUFBWTtBQUFBLFFBQ1ZDLFNBQVNkO0FBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQUEsSUFDQWUsU0FBUztBQUFBLE1BQ1BELFNBQVNmO0FBQUFBLElBQ1g7QUFBQSxJQUNBUDtBQUFBQSxJQUNBd0IsUUFBUTtBQUFBLE1BQ056QixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EwQixhQUFhO0FBQUEsTUFDWEMsS0FBSztBQUFBLFFBQ0hqQjtBQUFBQSxRQUNBUyxZQUFZO0FBQUEsVUFDVlMsUUFBUXhCO0FBQUFBLFFBQ1Y7QUFBQSxRQUNBeUIsYUFBYTNCO0FBQUFBLFFBQ2I0QixPQUFPO0FBQUEsVUFDTEMsTUFBTTVCO0FBQUFBLFVBQ05GLFFBQVE7QUFBQSxZQUNOK0IsTUFBTTNCO0FBQUFBLFlBQ040QixNQUFNO0FBQUEsY0FDSkQsTUFBTTFCO0FBQUFBLGNBQ05ULFVBQVVnQjtBQUFBQSxZQUNaO0FBQUEsWUFDQXFCLE9BQU87QUFBQSxjQUNMRixNQUFNekI7QUFBQUEsY0FDTlYsVUFBVWM7QUFBQUEsY0FDVndCLE9BQU92QyxPQUFPeUIsS0FBSyxHQUFHO0FBQUEsWUFDeEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQ0UsdUJBQUMsU0FDQyxRQUNBLE1BQUssU0FDTCxTQUNBLE9BQ0EsVUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS2lCO0FBRXJCO0FBQUMxQixHQTlFS0YsWUFBK0I7QUFBQSxVQUNORCxRQUFRO0FBQUE7QUFBQTRDLEtBRGpDM0M7QUFnRk4sZUFBZUE7QUFBVSxJQUFBMkM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNoYXJ0IiwidXNlVGhlbWUiLCJEb251dENoYXJ0IiwicHJvcHMiLCJfcyIsImNvbG9ycyIsImZvbnRTaXplIiwic2VyaWVzIiwiaGVpZ2h0Iiwid2lkdGgiLCJsYWJlbHMiLCJzY2FsZSIsImRvbnV0UGVyY2VudFNpemUiLCJkYXRhTGFiZWxPZmZzZXQiLCJzaG93RG9udXRMYWJlbCIsInNob3dEb251dExhYmVsTmFtZSIsInNob3dEb251dExhYmVsVmFsdWUiLCJlbmFibGVUb29sdGlwIiwiZW5hYmxlVG9vbHRpcFNoYWRvdyIsImV4cGFuZE9uQ2xpY2siLCJkb251dExhYmVsVmFsdWVGb250U2l6ZSIsImgxIiwiZG9udXRMYWJlbE5hbWVGb250U2l6ZSIsInAxNCIsImRhdGFMYWJlbEZvbnRTaXplIiwicDE2Iiwib3B0aW9ucyIsImJsdWUiLCJkYXRhTGFiZWxzIiwic3R5bGUiLCJncmF5IiwiZHJvcFNoYWRvdyIsImVuYWJsZWQiLCJ0b29sdGlwIiwibGVnZW5kIiwicGxvdE9wdGlvbnMiLCJwaWUiLCJvZmZzZXQiLCJjdXN0b21TY2FsZSIsImRvbnV0Iiwic2l6ZSIsInNob3ciLCJuYW1lIiwidmFsdWUiLCJjb2xvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRG9udXRDaGFydC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9jaGFydHMvRG9udXRDaGFydC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcGV4T3B0aW9ucyB9IGZyb20gJ2FwZXhjaGFydHMnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IENoYXJ0IGZyb20gJ3JlYWN0LWFwZXhjaGFydHMnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5pbnRlcmZhY2UgRG9udXRDaGFydFByb3BzIHtcbiAgc2VyaWVzPzogQXBleE9wdGlvbnNbJ3NlcmllcyddXG4gIGhlaWdodD86IHN0cmluZyB8IG51bWJlcixcbiAgd2lkdGg/OiBzdHJpbmcgfCBudW1iZXJcbiAgbGFiZWxzPzogc3RyaW5nW11cbiAgc2NhbGU/OiBudW1iZXJcbiAgc2hvd0RvbnV0TGFiZWw/OiBib29sZWFuXG4gIHNob3dEb251dExhYmVsTmFtZT86IGJvb2xlYW5cbiAgc2hvd0RvbnV0TGFiZWxWYWx1ZT86IGJvb2xlYW5cbiAgZG9udXRMYWJlbE5hbWVGb250U2l6ZT86IHN0cmluZ1xuICBkb251dExhYmVsVmFsdWVGb250U2l6ZT86IHN0cmluZ1xuICBkb251dFBlcmNlbnRTaXplPzogc3RyaW5nXG4gIGRhdGFMYWJlbEZvbnRTaXplPzogc3RyaW5nXG4gIGRhdGFMYWJlbE9mZnNldD86IG51bWJlclxuICBlbmFibGVUb29sdGlwPzogYm9vbGVhblxuICBlbmFibGVUb29sdGlwU2hhZG93PzogYm9vbGVhblxuICBleHBhbmRPbkNsaWNrPzogYm9vbGVhbixcbn1cblxuY29uc3QgRG9udXRDaGFydDogRkM8RG9udXRDaGFydFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGNvbG9ycywgZm9udFNpemUgfSA9IHVzZVRoZW1lKClcbiAgY29uc3Qge1xuICAgIHNlcmllcyxcbiAgICBoZWlnaHQsXG4gICAgd2lkdGgsXG4gICAgbGFiZWxzLFxuICAgIHNjYWxlLFxuICAgIGRvbnV0UGVyY2VudFNpemUsXG4gICAgZGF0YUxhYmVsT2Zmc2V0LFxuICAgIHNob3dEb251dExhYmVsLFxuICAgIHNob3dEb251dExhYmVsTmFtZSxcbiAgICBzaG93RG9udXRMYWJlbFZhbHVlLFxuICAgIGVuYWJsZVRvb2x0aXAsXG4gICAgZW5hYmxlVG9vbHRpcFNoYWRvdyxcbiAgICBleHBhbmRPbkNsaWNrLFxuICAgIGRvbnV0TGFiZWxWYWx1ZUZvbnRTaXplID0gZm9udFNpemUuaDEsXG4gICAgZG9udXRMYWJlbE5hbWVGb250U2l6ZSA9IGZvbnRTaXplLnAxNCxcbiAgICBkYXRhTGFiZWxGb250U2l6ZSA9IGZvbnRTaXplLnAxNixcbiAgfSA9IHByb3BzXG5cbiAgY29uc3Qgb3B0aW9uczogQXBleE9wdGlvbnMgPSB7XG4gICAgY29sb3JzOiBbXG4gICAgICBjb2xvcnMuYmx1ZVs4MDBdLFxuICAgICAgY29sb3JzLmJsdWVbNjAwXSxcbiAgICAgIGNvbG9ycy5ibHVlWzUwMF0sXG4gICAgICBjb2xvcnMuYmx1ZVszMDBdLFxuICAgICAgY29sb3JzLmJsdWVbMjAwXSxcbiAgICBdLFxuICAgIGRhdGFMYWJlbHM6IHtcbiAgICAgIHN0eWxlOiB7XG4gICAgICAgIGZvbnRTaXplOiBkYXRhTGFiZWxGb250U2l6ZSxcbiAgICAgICAgY29sb3JzOiBbY29sb3JzLmdyYXlbNjAwXV0sXG4gICAgICB9LFxuICAgICAgZHJvcFNoYWRvdzoge1xuICAgICAgICBlbmFibGVkOiBlbmFibGVUb29sdGlwU2hhZG93LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHRvb2x0aXA6IHtcbiAgICAgIGVuYWJsZWQ6IGVuYWJsZVRvb2x0aXAsXG4gICAgfSxcbiAgICBsYWJlbHM6IGxhYmVscyxcbiAgICBsZWdlbmQ6IHtcbiAgICAgIHdpZHRoOiAyMDAsXG4gICAgfSxcbiAgICBwbG90T3B0aW9uczoge1xuICAgICAgcGllOiB7XG4gICAgICAgIGV4cGFuZE9uQ2xpY2s6IGV4cGFuZE9uQ2xpY2ssXG4gICAgICAgIGRhdGFMYWJlbHM6IHtcbiAgICAgICAgICBvZmZzZXQ6IGRhdGFMYWJlbE9mZnNldCxcbiAgICAgICAgfSxcbiAgICAgICAgY3VzdG9tU2NhbGU6IHNjYWxlLFxuICAgICAgICBkb251dDoge1xuICAgICAgICAgIHNpemU6IGRvbnV0UGVyY2VudFNpemUsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBzaG93RG9udXRMYWJlbCxcbiAgICAgICAgICAgIG5hbWU6IHtcbiAgICAgICAgICAgICAgc2hvdzogc2hvd0RvbnV0TGFiZWxOYW1lLFxuICAgICAgICAgICAgICBmb250U2l6ZTogZG9udXRMYWJlbE5hbWVGb250U2l6ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB2YWx1ZToge1xuICAgICAgICAgICAgICBzaG93OiBzaG93RG9udXRMYWJlbFZhbHVlLFxuICAgICAgICAgICAgICBmb250U2l6ZTogZG9udXRMYWJlbFZhbHVlRm9udFNpemUsXG4gICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9XG4gIHJldHVybiAoXG4gICAgPENoYXJ0XG4gICAgICBzZXJpZXM9e3Nlcmllc31cbiAgICAgIHR5cGU9J2RvbnV0J1xuICAgICAgb3B0aW9ucz17b3B0aW9uc31cbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgIC8+KVxufVxuXG5leHBvcnQgZGVmYXVsdCBEb251dENoYXJ0XG4iXX0=