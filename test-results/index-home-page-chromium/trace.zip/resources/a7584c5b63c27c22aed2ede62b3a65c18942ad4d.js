import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientsDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientsDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { clientService as service } from "/src/modules/admin/clients/services/index.ts";
const ClientsDropdown = (props) => {
  _s();
  const {
    label,
    styles,
    disabled = false
  } = props;
  const [clients, setClients] = useState([]);
  const getAllUsers = useCallback(async () => {
    const data = await service.findQuery();
    setClients(data.value);
  }, [setClients]);
  useEffect(() => {
    getAllUsers();
    return () => {
      setClients([]);
    };
  }, []);
  const options = useMemo(() => clients?.map((client) => ({
    key: client.id,
    text: client.nomeFantasia
  })) ?? [], [clients]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { allowFreeform: true, autoComplete: "on", label, options, disabled, styles, calloutProps: {
    calloutMinWidth: 80
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientsDropdown.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(ClientsDropdown, "pgJ3f1xNcUXySiyITKtEy0srLSg=");
_c = ClientsDropdown;
export default ClientsDropdown;
var _c;
$RefreshReg$(_c, "ClientsDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientsDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNJOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUNKLFNBQWFBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUU5RCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCQyxlQUFlO0FBUXpDLE1BQU1DLGtCQUE0Q0EsQ0FBQ0MsVUFBZ0M7QUFBQUMsS0FBQTtBQUNqRixRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsV0FBVztBQUFBLEVBQ2IsSUFBSUo7QUFFSixRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSVgsU0FBbUIsRUFBRTtBQUVuRCxRQUFNWSxjQUFjZixZQUFZLFlBQVk7QUFDMUMsVUFBTWdCLE9BQU8sTUFBTVYsUUFBUVcsVUFBVTtBQUNyQ0gsZUFBV0UsS0FBS0UsS0FBSztBQUFBLEVBQ3ZCLEdBQUcsQ0FBQ0osVUFBVSxDQUFDO0FBRWZiLFlBQVUsTUFBTTtBQUNkYyxnQkFBWTtBQUVaLFdBQU8sTUFBTTtBQUNYRCxpQkFBVyxFQUFFO0FBQUEsSUFDZjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUssVUFBVWpCLFFBQ2QsTUFBTVcsU0FBU08sSUFBSUMsYUFBVztBQUFBLElBQzVCQyxLQUFLRCxPQUFPRTtBQUFBQSxJQUNaQyxNQUFNSCxPQUFPSTtBQUFBQSxFQUNmLEVBQUUsS0FBSyxJQUNQLENBQUNaLE9BQU8sQ0FDVjtBQUVBLFNBQ0UsdUJBQUMsWUFDQyxlQUFlLE1BQ2YsY0FBYSxNQUNiLE9BQ0EsU0FDQSxVQUNBLFFBQ0EsY0FBYztBQUFBLElBQ1phLGlCQUFpQjtBQUFBLEVBQ25CLEdBQ0EsR0FBSWxCLFNBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVZO0FBR2hCO0FBQUNDLEdBNUNLRixpQkFBeUM7QUFBQW9CLEtBQXpDcEI7QUE4Q04sZUFBZUE7QUFBZSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ29tYm9Cb3giLCJjbGllbnRTZXJ2aWNlIiwic2VydmljZSIsIkNsaWVudHNEcm9wZG93biIsInByb3BzIiwiX3MiLCJsYWJlbCIsInN0eWxlcyIsImRpc2FibGVkIiwiY2xpZW50cyIsInNldENsaWVudHMiLCJnZXRBbGxVc2VycyIsImRhdGEiLCJmaW5kUXVlcnkiLCJ2YWx1ZSIsIm9wdGlvbnMiLCJtYXAiLCJjbGllbnQiLCJrZXkiLCJpZCIsInRleHQiLCJub21lRmFudGFzaWEiLCJjYWxsb3V0TWluV2lkdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNsaWVudHNEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NsaWVudHMvY29tcG9uZW50cy9DbGllbnRzRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbWJvQm94T3B0aW9uLCBJQ29tYm9Cb3hQcm9wcywgSUNvbWJvQm94U3R5bGVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQywgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IENsaWVudCBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQ2xpZW50J1xyXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBjbGllbnRTZXJ2aWNlIGFzIHNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuXHJcbmludGVyZmFjZSBDbGllbnRzRHJvcGRvd25Qcm9wcyBleHRlbmRzIFBhcnRpYWw8SUNvbWJvQm94UHJvcHM+IHtcclxuICBsYWJlbD86IHN0cmluZ1xyXG4gIHNlbGVjdGVkS2V5OiBzdHJpbmcgfCBudWxsXHJcbiAgc3R5bGVzPzogUGFydGlhbDxJQ29tYm9Cb3hTdHlsZXM+XHJcbn1cclxuXHJcbmNvbnN0IENsaWVudHNEcm9wZG93bjogRkM8Q2xpZW50c0Ryb3Bkb3duUHJvcHM+ID0gKHByb3BzOiBDbGllbnRzRHJvcGRvd25Qcm9wcykgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIGxhYmVsLFxyXG4gICAgc3R5bGVzLFxyXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgW2NsaWVudHMsIHNldENsaWVudHNdID0gdXNlU3RhdGU8Q2xpZW50W10+KFtdKVxyXG5cclxuICBjb25zdCBnZXRBbGxVc2VycyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBzZXJ2aWNlLmZpbmRRdWVyeSgpXHJcbiAgICBzZXRDbGllbnRzKGRhdGEudmFsdWUpXHJcbiAgfSwgW3NldENsaWVudHNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0QWxsVXNlcnMoKVxyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHNldENsaWVudHMoW10pXHJcbiAgICB9XHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG9wdGlvbnMgPSB1c2VNZW1vPElDb21ib0JveE9wdGlvbltdPihcclxuICAgICgpID0+IGNsaWVudHM/Lm1hcChjbGllbnQgPT4gKHtcclxuICAgICAga2V5OiBjbGllbnQuaWQgYXMgc3RyaW5nLFxyXG4gICAgICB0ZXh0OiBjbGllbnQubm9tZUZhbnRhc2lhLFxyXG4gICAgfSkpID8/IFtdLFxyXG4gICAgW2NsaWVudHNdLFxyXG4gIClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDb21ib0JveFxyXG4gICAgICBhbGxvd0ZyZWVmb3JtPXt0cnVlfVxyXG4gICAgICBhdXRvQ29tcGxldGU9J29uJ1xyXG4gICAgICBsYWJlbD17bGFiZWx9XHJcbiAgICAgIG9wdGlvbnM9e29wdGlvbnN9XHJcbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cclxuICAgICAgc3R5bGVzPXtzdHlsZXN9XHJcbiAgICAgIGNhbGxvdXRQcm9wcz17e1xyXG4gICAgICAgIGNhbGxvdXRNaW5XaWR0aDogODAsXHJcbiAgICAgIH19XHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDbGllbnRzRHJvcGRvd25cclxuIl19