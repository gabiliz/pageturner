import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/DecimalInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/DecimalInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import TextField from "/src/shared/components/inputs/TextField.tsx";
const DecimalInput = (props) => {
  const {
    maxLength,
    minLength,
    placeholder,
    ...otherProps
  } = props;
  return /* @__PURE__ */ jsxDEV(TextField, { type: "number", step: 0.01, ...otherProps, maxLength, placeholder, minLength }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/DecimalInput.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_c = DecimalInput;
export default DecimalInput;
var _c;
$RefreshReg$(_c, "DecimalInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/DecimalInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJO0FBakJKLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRTFCLE9BQU9BLGVBQWU7QUFNdEIsTUFBTUMsZUFBdUNDLFdBQVU7QUFDckQsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0EsR0FBR0M7QUFBQUEsRUFDTCxJQUFJSjtBQUVKLFNBQ0UsdUJBQUMsYUFDQyxNQUFLLFVBQ0wsTUFBTSxNQUNOLEdBQUlJLFlBQ0osV0FDQSxhQUNBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU11QjtBQUczQjtBQUFDQyxLQWxCS047QUFvQk4sZUFBZUE7QUFBWSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVGV4dEZpZWxkIiwiRGVjaW1hbElucHV0IiwicHJvcHMiLCJtYXhMZW5ndGgiLCJtaW5MZW5ndGgiLCJwbGFjZWhvbGRlciIsIm90aGVyUHJvcHMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRlY2ltYWxJbnB1dC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9pbnB1dHMvRGVjaW1hbElucHV0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElUZXh0RmllbGRQcm9wcyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IFRleHRGaWVsZCBmcm9tICcuL1RleHRGaWVsZCdcclxuXHJcbmludGVyZmFjZSBEZWNpbWFsSW5wdXRQcm9wcyBleHRlbmRzIElUZXh0RmllbGRQcm9wcyB7XHJcbiAgZGlzYWJsZWRBc1JlYWRPbmx5PzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBEZWNpbWFsSW5wdXQ6IEZDPERlY2ltYWxJbnB1dFByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIG1heExlbmd0aCxcclxuICAgIG1pbkxlbmd0aCxcclxuICAgIHBsYWNlaG9sZGVyLFxyXG4gICAgLi4ub3RoZXJQcm9wc1xyXG4gIH0gPSBwcm9wc1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFRleHRGaWVsZFxyXG4gICAgICB0eXBlPSdudW1iZXInXHJcbiAgICAgIHN0ZXA9ezAuMDF9XHJcbiAgICAgIHsuLi5vdGhlclByb3BzfVxyXG4gICAgICBtYXhMZW5ndGg9e21heExlbmd0aH1cclxuICAgICAgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyfVxyXG4gICAgICBtaW5MZW5ndGg9e21pbkxlbmd0aH1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEZWNpbWFsSW5wdXRcclxuIl19