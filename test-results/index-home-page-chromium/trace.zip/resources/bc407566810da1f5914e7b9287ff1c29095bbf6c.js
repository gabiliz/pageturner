import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationCenterItem.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"];
import { useTheme } from "/src/shared/hooks/index.ts";
import { notificationsQueryService } from "/src/shared/services/notificationsServices/index.ts";
import { elapsedTime, formatTextInBoldHTMLString } from "/src/shared/utils/index.ts";
import { FlexColumn, FlexRow } from "/src/shared/components/FlexBox/index.ts";
import NotificationsCenterModuleTag from "/src/shared/components/notifications/components/NotificationsCenterModuleTag.tsx";
import IconButton from "/src/shared/components/buttons/IconButton.tsx";
import { NotificationTypeEnum } from "/src/shared/enums/NotificationTypeEnum.ts";
import { useNavigate } from "/node_modules/.vite/deps/react-router.js?v=9f90a7ff";
import { ApiError } from "/src/shared/errors/index.ts";
import { PersonaGeneral } from "/src/shared/components/persona/index.ts?t=1701096626433";
const NotificationCenterItem = (props) => {
  _s();
  const {
    notification,
    onDismiss
  } = props;
  const {
    colors
  } = useTheme();
  const navigate = useNavigate();
  const activeNotification = notification?.pendente;
  const styles = useStyles(activeNotification);
  const {
    mutateAsync: updateNotification
  } = notificationsQueryService.useUpdate();
  const {
    mutateAsync: actionNotification
  } = notificationsQueryService.useCreate(notification.id);
  const {
    mutateAsync
  } = notificationsQueryService.useDelete(notification.id);
  const date = elapsedTime(new Date(notification.dhrNotificacao));
  const formattedDescription = formatTextInBoldHTMLString(notification?.descricao);
  const deleteNotification = useCallback(async (notification2) => {
    await mutateAsync(notification2);
  }, [notification]);
  const visualizeNotification = useCallback(async (notification2) => {
    await updateNotification(notification2);
  }, [notification]);
  const executeAction = useCallback(async (notification2) => {
    const response = await actionNotification(notification2);
    if (notification2.pendente) {
      await visualizeNotification(notification2);
    }
    if (notification2.tipoNotificacao === NotificationTypeEnum.Redirecionamento) {
      if (!response) {
        throw new ApiError({
          status: 400,
          title: "Não foi possível redirecionar para a página, verifique manualmente."
        });
      } else {
        navigate(response + "");
        onDismiss();
      }
    }
  }, [notification]);
  const notificationsOptions = {
    items: [{
      key: "markAsUnread",
      text: notification.pendente ? "Marcar como lida" : "Marcar como não lida",
      onClick: () => {
        visualizeNotification(notification);
      }
    }, {
      key: "deleteNotification",
      text: "Excluir",
      onClick: () => {
        deleteNotification(notification);
      }
    }]
  };
  return /* @__PURE__ */ jsxDEV(FlexRow, { className: styles.item, width: "100%", padding: 16, verticalAlign: "center", onClick: () => executeAction(notification), children: [
    /* @__PURE__ */ jsxDEV("div", { style: {
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: notification?.pendente ? colors.blue[500] : "",
      marginRight: 8
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(PersonaGeneral, { image: notification.usuario?.image || "", shortName: getShortName(notification.usuario?.nome || ""), iconName: notification.tipoNotificacao === NotificationTypeEnum.Redirecionamento ? MODULE_ICON[notification.modulo] : notification.tipoNotificacao === NotificationTypeEnum.Redirecionamento ? "Download" : "CloudImportExport", color: notification.tipoNotificacao === NotificationTypeEnum.Redirecionamento ? colors.yellow[200] : notification.tipoNotificacao === NotificationTypeEnum.Download ? colors.lime[200] : colors.purple[200], iconFill: notification.tipoNotificacao === NotificationTypeEnum.Redirecionamento ? colors.yellow[800] : notification.tipoNotificacao === NotificationTypeEnum.Download ? colors.lime[800] : colors.white }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { margin: "0 8px", styles: {
      width: "75%"
    }, gap: 4, children: [
      /* @__PURE__ */ jsxDEV(Text, { className: styles.title, children: notification.titulo }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.description, children: /* @__PURE__ */ jsxDEV("span", { dangerouslySetInnerHTML: {
        __html: formattedDescription
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
        lineNumber: 98,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.info, children: [
        notification.cliente && `${notification.cliente.nomeFantasia} -`,
        " ",
        date,
        " ",
        notification.modulo && /* @__PURE__ */ jsxDEV("span", { className: styles.module, children: /* @__PURE__ */ jsxDEV(NotificationsCenterModuleTag, { module: notification.modulo }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
          lineNumber: 103,
          columnNumber: 141
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
          lineNumber: 103,
          columnNumber: 109
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(IconButton, { className: styles.menu, iconProps: {
      iconName: "More",
      styles: {
        root: {
          color: colors.gray[800],
          fontSize: 15
        }
      }
    }, onRenderMenuIcon: () => /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
      lineNumber: 114,
      columnNumber: 32
    }, this), menuProps: notificationsOptions }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
};
_s(NotificationCenterItem, "QiNx0VU3NZvpFrgOQFneTxSGeEQ=", false, function() {
  return [useTheme, useNavigate, useStyles, notificationsQueryService.useUpdate, notificationsQueryService.useCreate, notificationsQueryService.useDelete];
});
_c = NotificationCenterItem;
export default NotificationCenterItem;
function getShortName(str) {
  return str.split(" ").map((word) => word[0]).join("").slice(0, 2);
}
const MODULE_ICON = {
  1: "ContactCard",
  2: "Money",
  3: "IssueTracking"
};
const useStyles = (activeNotification) => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    item: {
      minHeight: 70,
      background: activeNotification ? theme.colors.blue[100] : "",
      cursor: "pointer",
      position: "relative",
      "&:hover": {
        background: activeNotification ? theme.colors.blue[200] : theme.colors.neutralLight[300]
      },
      borderBottom: "1px solid #f2f2f2"
    },
    title: {
      fontSize: 12,
      color: theme.colors.gray[800]
    },
    description: {
      fontSize: 14,
      fontWeight: 400,
      color: theme.colors.gray[800],
      b: {
        fontWeight: 600
      }
    },
    author: {
      fontWeight: "semibold"
    },
    info: {
      fontSize: 12,
      color: theme.colors.gray[600],
      display: "inline-flex",
      alignItems: "center"
    },
    module: {
      marginLeft: 8
    },
    menu: {
      alignSelf: "stretch",
      marginLeft: "auto",
      "&.is-expanded": {
        backgroundColor: "transparent"
      }
    }
  });
};
_s2(useStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
var _c;
$RefreshReg$(_c, "NotificationCenterItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZNLFNBeUQwQixVQXpEMUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2Rk4sU0FBK0JBLGdCQUFnQkMsWUFBWTtBQUMzRCxTQUFhQyxtQkFBbUI7QUFFaEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlDQUFpQztBQUMxQyxTQUFTQyxhQUFhQyxrQ0FBa0M7QUFDeEQsU0FBU0MsWUFBWUMsZUFBZTtBQUNwQyxPQUFPQyxrQ0FBa0M7QUFDekMsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQU8vQixNQUFNQyx5QkFBMkRDLFdBQVU7QUFBQUMsS0FBQTtBQUN6RSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBY0M7QUFBQUEsRUFBVSxJQUFJSDtBQUNwQyxRQUFNO0FBQUEsSUFBRUk7QUFBQUEsRUFBTyxJQUFJakIsU0FBUztBQUM1QixRQUFNa0IsV0FBV1QsWUFBWTtBQUM3QixRQUFNVSxxQkFBcUJKLGNBQWNLO0FBQ3pDLFFBQU1DLFNBQVNDLFVBQVVILGtCQUFrQjtBQUUzQyxRQUFNO0FBQUEsSUFBRUksYUFBYUM7QUFBQUEsRUFBbUIsSUFBSXZCLDBCQUEwQndCLFVBQVU7QUFDaEYsUUFBTTtBQUFBLElBQUVGLGFBQWFHO0FBQUFBLEVBQW1CLElBQUl6QiwwQkFBMEIwQixVQUFVWixhQUFhYSxFQUFFO0FBQy9GLFFBQU07QUFBQSxJQUFFTDtBQUFBQSxFQUFZLElBQUl0QiwwQkFBMEI0QixVQUFVZCxhQUFhYSxFQUFFO0FBRTNFLFFBQU1FLE9BQWU1QixZQUFZLElBQUk2QixLQUFLaEIsYUFBYWlCLGNBQWMsQ0FBQztBQUN0RSxRQUFNQyx1QkFBdUI5QiwyQkFBMkJZLGNBQWNtQixTQUFTO0FBRS9FLFFBQU1DLHFCQUFxQnBDLFlBQVksT0FBT2dCLGtCQUFrQztBQUM5RSxVQUFNUSxZQUFZUixhQUFZO0FBQUEsRUFDaEMsR0FBRyxDQUFDQSxZQUFZLENBQUM7QUFFakIsUUFBTXFCLHdCQUF3QnJDLFlBQzVCLE9BQU9nQixrQkFBa0M7QUFDdkMsVUFBTVMsbUJBQW1CVCxhQUFZO0FBQUEsRUFDdkMsR0FBRyxDQUFDQSxZQUFZLENBQ2xCO0FBRUEsUUFBTXNCLGdCQUFnQnRDLFlBQVksT0FBT2dCLGtCQUFrQztBQUN6RSxVQUFNdUIsV0FBVyxNQUFNWixtQkFBbUJYLGFBQVk7QUFFdEQsUUFBSUEsY0FBYUssVUFBVTtBQUN6QixZQUFNZ0Isc0JBQXNCckIsYUFBWTtBQUFBLElBQzFDO0FBRUEsUUFBSUEsY0FBYXdCLG9CQUFvQi9CLHFCQUFxQmdDLGtCQUFrQjtBQUMxRSxVQUFJLENBQUNGLFVBQVU7QUFDYixjQUFNLElBQUk1QixTQUFTO0FBQUEsVUFDakIrQixRQUFRO0FBQUEsVUFDUkMsT0FBTztBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMeEIsaUJBQVNvQixXQUFXLEVBQUU7QUFDdEJ0QixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNELFlBQVksQ0FBQztBQUVqQixRQUFNNEIsdUJBQTZDO0FBQUEsSUFDakRDLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLEtBQUs7QUFBQSxNQUNMQyxNQUFNL0IsYUFBYUssV0FBVyxxQkFBcUI7QUFBQSxNQUNuRDJCLFNBQVNBLE1BQU07QUFBRVgsOEJBQXNCckIsWUFBWTtBQUFBLE1BQUU7QUFBQSxJQUN2RCxHQUNBO0FBQUEsTUFDRThCLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsU0FBU0EsTUFBTTtBQUFFWiwyQkFBbUJwQixZQUFZO0FBQUEsTUFBRTtBQUFBLElBQ3BELENBQUM7QUFBQSxFQUVMO0FBRUEsU0FDRSx1QkFBQyxXQUNDLFdBQVdNLE9BQU8yQixNQUNsQixPQUFPLFFBQ1AsU0FBUyxJQUNULGVBQWUsVUFDZixTQUFTLE1BQU1YLGNBQWN0QixZQUFZLEdBRXpDO0FBQUEsMkJBQUMsU0FBSSxPQUFPO0FBQUEsTUFDVmtDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUkMsY0FBYztBQUFBLE1BQ2RDLFlBQVlyQyxjQUFjSyxXQUFXSCxPQUFPb0MsS0FBSyxHQUFHLElBQUk7QUFBQSxNQUN4REMsYUFBYTtBQUFBLElBQ2YsS0FOQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUU7QUFBQSxJQUNGLHVCQUFDLGtCQUNDLE9BQU92QyxhQUFhd0MsU0FBU0MsU0FBUyxJQUN0QyxXQUFXQyxhQUFhMUMsYUFBYXdDLFNBQVNHLFFBQWtCLEVBQUUsR0FDbEUsVUFBVTNDLGFBQWF3QixvQkFBb0IvQixxQkFBcUJnQyxtQkFDNURtQixZQUFZNUMsYUFBYTZDLE1BQU0sSUFDL0I3QyxhQUFhd0Isb0JBQW9CL0IscUJBQXFCZ0MsbUJBQ3BELGFBQ0EscUJBRU4sT0FBT3pCLGFBQWF3QixvQkFBb0IvQixxQkFBcUJnQyxtQkFDekR2QixPQUFPNEMsT0FBTyxHQUFHLElBQ2pCOUMsYUFBYXdCLG9CQUFvQi9CLHFCQUFxQnNELFdBQ3BEN0MsT0FBTzhDLEtBQUssR0FBRyxJQUNmOUMsT0FBTytDLE9BQU8sR0FBRyxHQUV2QixVQUFVakQsYUFBYXdCLG9CQUFvQi9CLHFCQUFxQmdDLG1CQUM1RHZCLE9BQU80QyxPQUFPLEdBQUcsSUFDakI5QyxhQUFhd0Isb0JBQW9CL0IscUJBQXFCc0QsV0FDcEQ3QyxPQUFPOEMsS0FBSyxHQUFHLElBQ2Y5QyxPQUFPZ0QsU0FuQmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CRztBQUFBLElBRUgsdUJBQUMsY0FDQyxRQUFRLFNBQ1IsUUFBUTtBQUFBLE1BQ05oQixPQUFPO0FBQUEsSUFDVCxHQUNBLEtBQUssR0FFTDtBQUFBLDZCQUFDLFFBQUssV0FBVzVCLE9BQU9xQixPQUNyQjNCLHVCQUFhbUQsVUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVc3QyxPQUFPOEMsYUFDdEIsaUNBQUMsVUFBSyx5QkFBeUI7QUFBQSxRQUFFQyxRQUFRbkM7QUFBQUEsTUFBcUIsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBV1osT0FBT2dELE1BQ3JCdEQ7QUFBQUEscUJBQWF1RCxXQUFZLEdBQUV2RCxhQUFhdUQsUUFBUUM7QUFBQUEsUUFBaUI7QUFBQSxRQUFFekM7QUFBQUEsUUFBSztBQUFBLFFBQUVmLGFBQWE2QyxVQUFVLHVCQUFDLFVBQUssV0FBV3ZDLE9BQU9tRCxRQUFRLGlDQUFDLGdDQUE2QixRQUFRekQsYUFBYTZDLFVBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBRGhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBQ0EsdUJBQUMsY0FDQyxXQUFXdkMsT0FBT29ELE1BQ2xCLFdBQVc7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVnJELFFBQVE7QUFBQSxRQUNOc0QsTUFBTTtBQUFBLFVBQ0pDLE9BQU8zRCxPQUFPNEQsS0FBSyxHQUFHO0FBQUEsVUFDdEJDLFVBQVU7QUFBQSxRQUNaO0FBQUEsTUFDRjtBQUFBLElBQ0YsR0FDQSxrQkFBa0IsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUUsR0FDMUIsV0FBV25DLHdCQVpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZa0M7QUFBQSxPQWpFcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1FQTtBQUVKO0FBQUM3QixHQWpJS0Ysd0JBQXVEO0FBQUEsVUFFeENaLFVBQ0ZTLGFBRUZhLFdBRTZCckIsMEJBQTBCd0IsV0FDMUJ4QiwwQkFBMEIwQixXQUM5QzFCLDBCQUEwQjRCLFNBQVM7QUFBQTtBQUFBa0QsS0FUdkRuRTtBQW1JTixlQUFlQTtBQUVmLFNBQVM2QyxhQUFjdUIsS0FBYTtBQUNsQyxTQUFPQSxJQUNKQyxNQUFNLEdBQUcsRUFDVEMsSUFBSUMsVUFBUUEsS0FBSyxDQUFDLENBQUMsRUFDbkJDLEtBQUssRUFBRSxFQUNQQyxNQUFNLEdBQUcsQ0FBQztBQUNmO0FBRUEsTUFBTTFCLGNBQTBDO0FBQUEsRUFDOUMsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUNMO0FBRUEsTUFBTXJDLFlBQVlBLENBQUNILHVCQUFpQztBQUFBbUUsTUFBQTtBQUNsRCxRQUFNQyxRQUFRdkYsU0FBUztBQUV2QixTQUFPSCxlQUFlO0FBQUEsSUFDcEJtRCxNQUFNO0FBQUEsTUFDSndDLFdBQVc7QUFBQSxNQUNYcEMsWUFBWWpDLHFCQUFxQm9FLE1BQU10RSxPQUFPb0MsS0FBSyxHQUFHLElBQUk7QUFBQSxNQUMxRG9DLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVixXQUFXO0FBQUEsUUFDVHRDLFlBQVlqQyxxQkFBcUJvRSxNQUFNdEUsT0FBT29DLEtBQUssR0FBRyxJQUFJa0MsTUFBTXRFLE9BQU8wRSxhQUFhLEdBQUc7QUFBQSxNQUN6RjtBQUFBLE1BQ0FDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLElBQ0FsRCxPQUFPO0FBQUEsTUFDTG9DLFVBQVU7QUFBQSxNQUNWRixPQUFPVyxNQUFNdEUsT0FBTzRELEtBQUssR0FBRztBQUFBLElBQzlCO0FBQUEsSUFDQVYsYUFBYTtBQUFBLE1BQ1hXLFVBQVU7QUFBQSxNQUNWZSxZQUFZO0FBQUEsTUFDWmpCLE9BQU9XLE1BQU10RSxPQUFPNEQsS0FBSyxHQUFHO0FBQUEsTUFDNUJpQixHQUFHO0FBQUEsUUFDREQsWUFBWTtBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQUEsSUFDQUUsUUFBUTtBQUFBLE1BQ05GLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQXhCLE1BQU07QUFBQSxNQUNKUyxVQUFVO0FBQUEsTUFDVkYsT0FBT1csTUFBTXRFLE9BQU80RCxLQUFLLEdBQUc7QUFBQSxNQUM1Qm1CLFNBQVM7QUFBQSxNQUNUQyxZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0F6QixRQUFRO0FBQUEsTUFDTjBCLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQXpCLE1BQU07QUFBQSxNQUNKMEIsV0FBVztBQUFBLE1BQ1hELFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLFFBQ2ZFLGlCQUFpQjtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNkLElBOUNLaEUsV0FBUztBQUFBLFVBQ0N0QixRQUFRO0FBQUE7QUFBQSxJQUFBK0U7QUFBQXNCLGFBQUF0QixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJUZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VUaGVtZSIsIm5vdGlmaWNhdGlvbnNRdWVyeVNlcnZpY2UiLCJlbGFwc2VkVGltZSIsImZvcm1hdFRleHRJbkJvbGRIVE1MU3RyaW5nIiwiRmxleENvbHVtbiIsIkZsZXhSb3ciLCJOb3RpZmljYXRpb25zQ2VudGVyTW9kdWxlVGFnIiwiSWNvbkJ1dHRvbiIsIk5vdGlmaWNhdGlvblR5cGVFbnVtIiwidXNlTmF2aWdhdGUiLCJBcGlFcnJvciIsIlBlcnNvbmFHZW5lcmFsIiwiTm90aWZpY2F0aW9uQ2VudGVySXRlbSIsInByb3BzIiwiX3MiLCJub3RpZmljYXRpb24iLCJvbkRpc21pc3MiLCJjb2xvcnMiLCJuYXZpZ2F0ZSIsImFjdGl2ZU5vdGlmaWNhdGlvbiIsInBlbmRlbnRlIiwic3R5bGVzIiwidXNlU3R5bGVzIiwibXV0YXRlQXN5bmMiLCJ1cGRhdGVOb3RpZmljYXRpb24iLCJ1c2VVcGRhdGUiLCJhY3Rpb25Ob3RpZmljYXRpb24iLCJ1c2VDcmVhdGUiLCJpZCIsInVzZURlbGV0ZSIsImRhdGUiLCJEYXRlIiwiZGhyTm90aWZpY2FjYW8iLCJmb3JtYXR0ZWREZXNjcmlwdGlvbiIsImRlc2NyaWNhbyIsImRlbGV0ZU5vdGlmaWNhdGlvbiIsInZpc3VhbGl6ZU5vdGlmaWNhdGlvbiIsImV4ZWN1dGVBY3Rpb24iLCJyZXNwb25zZSIsInRpcG9Ob3RpZmljYWNhbyIsIlJlZGlyZWNpb25hbWVudG8iLCJzdGF0dXMiLCJ0aXRsZSIsIm5vdGlmaWNhdGlvbnNPcHRpb25zIiwiaXRlbXMiLCJrZXkiLCJ0ZXh0Iiwib25DbGljayIsIml0ZW0iLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJibHVlIiwibWFyZ2luUmlnaHQiLCJ1c3VhcmlvIiwiaW1hZ2UiLCJnZXRTaG9ydE5hbWUiLCJub21lIiwiTU9EVUxFX0lDT04iLCJtb2R1bG8iLCJ5ZWxsb3ciLCJEb3dubG9hZCIsImxpbWUiLCJwdXJwbGUiLCJ3aGl0ZSIsInRpdHVsbyIsImRlc2NyaXB0aW9uIiwiX19odG1sIiwiaW5mbyIsImNsaWVudGUiLCJub21lRmFudGFzaWEiLCJtb2R1bGUiLCJtZW51IiwiaWNvbk5hbWUiLCJyb290IiwiY29sb3IiLCJncmF5IiwiZm9udFNpemUiLCJfYyIsInN0ciIsInNwbGl0IiwibWFwIiwid29yZCIsImpvaW4iLCJzbGljZSIsIl9zMiIsInRoZW1lIiwibWluSGVpZ2h0IiwiY3Vyc29yIiwicG9zaXRpb24iLCJuZXV0cmFsTGlnaHQiLCJib3JkZXJCb3R0b20iLCJmb250V2VpZ2h0IiwiYiIsImF1dGhvciIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwibWFyZ2luTGVmdCIsImFsaWduU2VsZiIsImJhY2tncm91bmRDb2xvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbkNlbnRlckl0ZW0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9jb21wb25lbnRzL05vdGlmaWNhdGlvbkNlbnRlckl0ZW0udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbnRleHR1YWxNZW51UHJvcHMsIG1lcmdlU3R5bGVTZXRzLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQXBwTm90aWZpY2F0aW9uIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9BcHBOb3RpZmljYXRpb24nXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzJ1xuaW1wb3J0IHsgbm90aWZpY2F0aW9uc1F1ZXJ5U2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL25vdGlmaWNhdGlvbnNTZXJ2aWNlcydcbmltcG9ydCB7IGVsYXBzZWRUaW1lLCBmb3JtYXRUZXh0SW5Cb2xkSFRNTFN0cmluZyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzJ1xuaW1wb3J0IHsgRmxleENvbHVtbiwgRmxleFJvdyB9IGZyb20gJy4uLy4uL0ZsZXhCb3gnXG5pbXBvcnQgTm90aWZpY2F0aW9uc0NlbnRlck1vZHVsZVRhZyBmcm9tICcuL05vdGlmaWNhdGlvbnNDZW50ZXJNb2R1bGVUYWcnXG5pbXBvcnQgSWNvbkJ1dHRvbiBmcm9tICcuLy4uLy4uL2J1dHRvbnMvSWNvbkJ1dHRvbidcbmltcG9ydCB7IE5vdGlmaWNhdGlvblR5cGVFbnVtIH0gZnJvbSAnLi4vLi4vLi4vZW51bXMvTm90aWZpY2F0aW9uVHlwZUVudW0nXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IE1vZHVsZUVudW0gfSBmcm9tICcuLi8uLi8uLi9lbnVtcy9Nb2R1bGVFbnVtJ1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi8uLi9lcnJvcnMnXG5pbXBvcnQgeyBQZXJzb25hR2VuZXJhbCB9IGZyb20gJy4uLy4uL3BlcnNvbmEnXG5cbmludGVyZmFjZSBOb3RpZmljYXRpb25DZW50ZXJJdGVtUHJvcHMge1xuICBub3RpZmljYXRpb246IEFwcE5vdGlmaWNhdGlvblxuICBvbkRpc21pc3M6ICgpID0+IHZvaWRcbn1cblxuY29uc3QgTm90aWZpY2F0aW9uQ2VudGVySXRlbTogRkM8Tm90aWZpY2F0aW9uQ2VudGVySXRlbVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IG5vdGlmaWNhdGlvbiwgb25EaXNtaXNzIH0gPSBwcm9wc1xuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgYWN0aXZlTm90aWZpY2F0aW9uID0gbm90aWZpY2F0aW9uPy5wZW5kZW50ZVxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoYWN0aXZlTm90aWZpY2F0aW9uKVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHVwZGF0ZU5vdGlmaWNhdGlvbiB9ID0gbm90aWZpY2F0aW9uc1F1ZXJ5U2VydmljZS51c2VVcGRhdGUoKVxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBhY3Rpb25Ob3RpZmljYXRpb24gfSA9IG5vdGlmaWNhdGlvbnNRdWVyeVNlcnZpY2UudXNlQ3JlYXRlKG5vdGlmaWNhdGlvbi5pZClcbiAgY29uc3QgeyBtdXRhdGVBc3luYyB9ID0gbm90aWZpY2F0aW9uc1F1ZXJ5U2VydmljZS51c2VEZWxldGUobm90aWZpY2F0aW9uLmlkKVxuXG4gIGNvbnN0IGRhdGU6IHN0cmluZyA9IGVsYXBzZWRUaW1lKG5ldyBEYXRlKG5vdGlmaWNhdGlvbi5kaHJOb3RpZmljYWNhbykpXG4gIGNvbnN0IGZvcm1hdHRlZERlc2NyaXB0aW9uID0gZm9ybWF0VGV4dEluQm9sZEhUTUxTdHJpbmcobm90aWZpY2F0aW9uPy5kZXNjcmljYW8pXG5cbiAgY29uc3QgZGVsZXRlTm90aWZpY2F0aW9uID0gdXNlQ2FsbGJhY2soYXN5bmMgKG5vdGlmaWNhdGlvbjogQXBwTm90aWZpY2F0aW9uKSA9PiB7XG4gICAgYXdhaXQgbXV0YXRlQXN5bmMobm90aWZpY2F0aW9uKVxuICB9LCBbbm90aWZpY2F0aW9uXSlcblxuICBjb25zdCB2aXN1YWxpemVOb3RpZmljYXRpb24gPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAobm90aWZpY2F0aW9uOiBBcHBOb3RpZmljYXRpb24pID0+IHtcbiAgICAgIGF3YWl0IHVwZGF0ZU5vdGlmaWNhdGlvbihub3RpZmljYXRpb24pXG4gICAgfSwgW25vdGlmaWNhdGlvbl0sXG4gIClcblxuICBjb25zdCBleGVjdXRlQWN0aW9uID0gdXNlQ2FsbGJhY2soYXN5bmMgKG5vdGlmaWNhdGlvbjogQXBwTm90aWZpY2F0aW9uKSA9PiB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhY3Rpb25Ob3RpZmljYXRpb24obm90aWZpY2F0aW9uKVxuXG4gICAgaWYgKG5vdGlmaWNhdGlvbi5wZW5kZW50ZSkge1xuICAgICAgYXdhaXQgdmlzdWFsaXplTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbilcbiAgICB9XG5cbiAgICBpZiAobm90aWZpY2F0aW9uLnRpcG9Ob3RpZmljYWNhbyA9PT0gTm90aWZpY2F0aW9uVHlwZUVudW0uUmVkaXJlY2lvbmFtZW50bykge1xuICAgICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgICB0aHJvdyBuZXcgQXBpRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1czogNDAwLFxuICAgICAgICAgIHRpdGxlOiAnTsOjbyBmb2kgcG9zc8OtdmVsIHJlZGlyZWNpb25hciBwYXJhIGEgcMOhZ2luYSwgdmVyaWZpcXVlIG1hbnVhbG1lbnRlLicsXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBuYXZpZ2F0ZShyZXNwb25zZSArICcnKVxuICAgICAgICBvbkRpc21pc3MoKVxuICAgICAgfVxuICAgIH1cbiAgfSwgW25vdGlmaWNhdGlvbl0pXG5cbiAgY29uc3Qgbm90aWZpY2F0aW9uc09wdGlvbnM6IElDb250ZXh0dWFsTWVudVByb3BzID0ge1xuICAgIGl0ZW1zOiBbXG4gICAgICB7XG4gICAgICAgIGtleTogJ21hcmtBc1VucmVhZCcsXG4gICAgICAgIHRleHQ6IG5vdGlmaWNhdGlvbi5wZW5kZW50ZSA/ICdNYXJjYXIgY29tbyBsaWRhJyA6ICdNYXJjYXIgY29tbyBuw6NvIGxpZGEnLFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiB7IHZpc3VhbGl6ZU5vdGlmaWNhdGlvbihub3RpZmljYXRpb24pIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBrZXk6ICdkZWxldGVOb3RpZmljYXRpb24nLFxuICAgICAgICB0ZXh0OiAnRXhjbHVpcicsXG4gICAgICAgIG9uQ2xpY2s6ICgpID0+IHsgZGVsZXRlTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbikgfSxcbiAgICAgIH0sXG4gICAgXSxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPEZsZXhSb3dcbiAgICAgIGNsYXNzTmFtZT17c3R5bGVzLml0ZW19XG4gICAgICB3aWR0aD17JzEwMCUnfVxuICAgICAgcGFkZGluZz17MTZ9XG4gICAgICB2ZXJ0aWNhbEFsaWduPXsnY2VudGVyJ31cbiAgICAgIG9uQ2xpY2s9eygpID0+IGV4ZWN1dGVBY3Rpb24obm90aWZpY2F0aW9uKX1cbiAgICA+XG4gICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgIHdpZHRoOiA4LFxuICAgICAgICBoZWlnaHQ6IDgsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICAgIGJhY2tncm91bmQ6IG5vdGlmaWNhdGlvbj8ucGVuZGVudGUgPyBjb2xvcnMuYmx1ZVs1MDBdIDogJycsXG4gICAgICAgIG1hcmdpblJpZ2h0OiA4LFxuICAgICAgfX0vPlxuICAgICAgPFBlcnNvbmFHZW5lcmFsXG4gICAgICAgIGltYWdlPXtub3RpZmljYXRpb24udXN1YXJpbz8uaW1hZ2UgfHwgJyd9XG4gICAgICAgIHNob3J0TmFtZT17Z2V0U2hvcnROYW1lKG5vdGlmaWNhdGlvbi51c3VhcmlvPy5ub21lIGFzIHN0cmluZyB8fCAnJyl9XG4gICAgICAgIGljb25OYW1lPXtub3RpZmljYXRpb24udGlwb05vdGlmaWNhY2FvID09PSBOb3RpZmljYXRpb25UeXBlRW51bS5SZWRpcmVjaW9uYW1lbnRvXG4gICAgICAgICAgPyBNT0RVTEVfSUNPTltub3RpZmljYXRpb24ubW9kdWxvXVxuICAgICAgICAgIDogbm90aWZpY2F0aW9uLnRpcG9Ob3RpZmljYWNhbyA9PT0gTm90aWZpY2F0aW9uVHlwZUVudW0uUmVkaXJlY2lvbmFtZW50b1xuICAgICAgICAgICAgPyAnRG93bmxvYWQnXG4gICAgICAgICAgICA6ICdDbG91ZEltcG9ydEV4cG9ydCdcbiAgICAgICAgfVxuICAgICAgICBjb2xvcj17bm90aWZpY2F0aW9uLnRpcG9Ob3RpZmljYWNhbyA9PT0gTm90aWZpY2F0aW9uVHlwZUVudW0uUmVkaXJlY2lvbmFtZW50b1xuICAgICAgICAgID8gY29sb3JzLnllbGxvd1syMDBdXG4gICAgICAgICAgOiBub3RpZmljYXRpb24udGlwb05vdGlmaWNhY2FvID09PSBOb3RpZmljYXRpb25UeXBlRW51bS5Eb3dubG9hZFxuICAgICAgICAgICAgPyBjb2xvcnMubGltZVsyMDBdXG4gICAgICAgICAgICA6IGNvbG9ycy5wdXJwbGVbMjAwXVxuICAgICAgICB9XG4gICAgICAgIGljb25GaWxsPXtub3RpZmljYXRpb24udGlwb05vdGlmaWNhY2FvID09PSBOb3RpZmljYXRpb25UeXBlRW51bS5SZWRpcmVjaW9uYW1lbnRvXG4gICAgICAgICAgPyBjb2xvcnMueWVsbG93WzgwMF1cbiAgICAgICAgICA6IG5vdGlmaWNhdGlvbi50aXBvTm90aWZpY2FjYW8gPT09IE5vdGlmaWNhdGlvblR5cGVFbnVtLkRvd25sb2FkXG4gICAgICAgICAgICA/IGNvbG9ycy5saW1lWzgwMF1cbiAgICAgICAgICAgIDogY29sb3JzLndoaXRlXG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgICA8RmxleENvbHVtblxuICAgICAgICBtYXJnaW49eycwIDhweCd9XG4gICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgIHdpZHRoOiAnNzUlJyxcbiAgICAgICAgfX1cbiAgICAgICAgZ2FwPXs0fVxuICAgICAgPlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy50aXRsZX0+XG4gICAgICAgICAge25vdGlmaWNhdGlvbi50aXR1bG99XG4gICAgICAgIDwvVGV4dD5cbiAgICAgICAgPFRleHQgY2xhc3NOYW1lPXtzdHlsZXMuZGVzY3JpcHRpb259ID5cbiAgICAgICAgICA8c3BhbiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGZvcm1hdHRlZERlc2NyaXB0aW9uIH19IC8+XG4gICAgICAgIDwvVGV4dD5cbiAgICAgICAgPFRleHQgY2xhc3NOYW1lPXtzdHlsZXMuaW5mb30+XG4gICAgICAgICAge25vdGlmaWNhdGlvbi5jbGllbnRlICYmIGAke25vdGlmaWNhdGlvbi5jbGllbnRlLm5vbWVGYW50YXNpYX0gLWB9IHtkYXRlfSB7bm90aWZpY2F0aW9uLm1vZHVsbyAmJiA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy5tb2R1bGV9PjxOb3RpZmljYXRpb25zQ2VudGVyTW9kdWxlVGFnIG1vZHVsZT17bm90aWZpY2F0aW9uLm1vZHVsb30vPjwvc3Bhbj59XG4gICAgICAgIDwvVGV4dD5cbiAgICAgIDwvRmxleENvbHVtbj5cbiAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLm1lbnV9XG4gICAgICAgIGljb25Qcm9wcz17e1xuICAgICAgICAgIGljb25OYW1lOiAnTW9yZScsXG4gICAgICAgICAgc3R5bGVzOiB7XG4gICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs4MDBdLFxuICAgICAgICAgICAgICBmb250U2l6ZTogMTUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH19XG4gICAgICAgIG9uUmVuZGVyTWVudUljb249eygpID0+IDw+PC8+fVxuICAgICAgICBtZW51UHJvcHM9e25vdGlmaWNhdGlvbnNPcHRpb25zfVxuICAgICAgLz5cbiAgICA8L0ZsZXhSb3c+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uQ2VudGVySXRlbVxuXG5mdW5jdGlvbiBnZXRTaG9ydE5hbWUgKHN0cjogc3RyaW5nKSB7XG4gIHJldHVybiBzdHJcbiAgICAuc3BsaXQoJyAnKVxuICAgIC5tYXAod29yZCA9PiB3b3JkWzBdKVxuICAgIC5qb2luKCcnKVxuICAgIC5zbGljZSgwLCAyKVxufVxuXG5jb25zdCBNT0RVTEVfSUNPTjogUmVjb3JkPE1vZHVsZUVudW0sIHN0cmluZz4gPSB7XG4gIDE6ICdDb250YWN0Q2FyZCcsXG4gIDI6ICdNb25leScsXG4gIDM6ICdJc3N1ZVRyYWNraW5nJyxcbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKGFjdGl2ZU5vdGlmaWNhdGlvbj86IGJvb2xlYW4pID0+IHtcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXG5cbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcbiAgICBpdGVtOiB7XG4gICAgICBtaW5IZWlnaHQ6IDcwLFxuICAgICAgYmFja2dyb3VuZDogYWN0aXZlTm90aWZpY2F0aW9uID8gdGhlbWUuY29sb3JzLmJsdWVbMTAwXSA6ICcnLFxuICAgICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICcmOmhvdmVyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kOiBhY3RpdmVOb3RpZmljYXRpb24gPyB0aGVtZS5jb2xvcnMuYmx1ZVsyMDBdIDogdGhlbWUuY29sb3JzLm5ldXRyYWxMaWdodFszMDBdLFxuICAgICAgfSxcbiAgICAgIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCAjZjJmMmYyJyxcbiAgICB9LFxuICAgIHRpdGxlOiB7XG4gICAgICBmb250U2l6ZTogMTIsXG4gICAgICBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbODAwXSxcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICBmb250U2l6ZTogMTQsXG4gICAgICBmb250V2VpZ2h0OiA0MDAsXG4gICAgICBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbODAwXSxcbiAgICAgIGI6IHtcbiAgICAgICAgZm9udFdlaWdodDogNjAwLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGF1dGhvcjoge1xuICAgICAgZm9udFdlaWdodDogJ3NlbWlib2xkJyxcbiAgICB9LFxuICAgIGluZm86IHtcbiAgICAgIGZvbnRTaXplOiAxMixcbiAgICAgIGNvbG9yOiB0aGVtZS5jb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgZGlzcGxheTogJ2lubGluZS1mbGV4JyxcbiAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIH0sXG4gICAgbW9kdWxlOiB7XG4gICAgICBtYXJnaW5MZWZ0OiA4LFxuICAgIH0sXG4gICAgbWVudToge1xuICAgICAgYWxpZ25TZWxmOiAnc3RyZXRjaCcsXG4gICAgICBtYXJnaW5MZWZ0OiAnYXV0bycsXG4gICAgICAnJi5pcy1leHBhbmRlZCc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxufVxuIl19