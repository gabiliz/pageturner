import.meta.env = {"M_REQUEST_TIMEOUT":"0","M_REFRESH_TOKEN_ENDPOINT":"/api/account/refresh-token","MANPATH":"/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man:/usr/share/man:/usr/local/share/man:/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man::","MallocNanoZone":"0","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { HubConnectionBuilder, LogLevel } from "/node_modules/.vite/deps/@microsoft_signalr.js?v=9f90a7ff";
import { notificationsQueryService } from "/src/shared/services/notificationsServices/index.ts";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { NotificationType } from "/src/shared/types/RealTimeMessage.ts";
export default class RealTimeController {
  connection;
  observers;
  constructor(apiBase) {
    this.connection = new HubConnectionBuilder().withUrl(apiBase).withAutomaticReconnect().configureLogging(import.meta.env.PROD ? LogLevel.None : LogLevel.Debug).build();
    this.connection.onclose(this.close);
    this.observers = {
      [NotificationType.APPROVED_CONTRACT]: [],
      [NotificationType.PENDING_CONTRACT]: [],
      [NotificationType.REJECTED_CONTRACT]: [],
      [NotificationType.ACCEPTED_TERMS]: [],
      [NotificationType.REJECTED_TERMS]: []
    };
  }
  subscribe(type, listener) {
    this.observers[type].push(listener);
  }
  unsubscribe(type, listener) {
    const index = this.observers[type].findIndex(
      (_listener) => listener === _listener
    );
    this.observers[type].splice(index, 1);
  }
  async start() {
    try {
      const { showNotification } = useNotifications();
      await this.connection.start();
      this.connection.on("General", (payload) => {
        this.observers[payload.tipo].forEach((listener) => listener(payload));
        notificationsQueryService.invalidateQueries();
        showNotification({
          message: payload.descricao,
          type: 0,
          timeout: 15e3
        });
      });
    } catch (error) {
    }
  }
  close() {
    this.start();
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJlYWxUaW1lQ29udHJvbGxlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIdWJDb25uZWN0aW9uLCBIdWJDb25uZWN0aW9uQnVpbGRlciwgTG9nTGV2ZWwgfSBmcm9tICdAbWljcm9zb2Z0L3NpZ25hbHInXG5pbXBvcnQgeyBub3RpZmljYXRpb25zUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbm90aWZpY2F0aW9uc1NlcnZpY2VzJ1xuaW1wb3J0IHsgdXNlTm90aWZpY2F0aW9ucyB9IGZyb20gJy4uL3N0b3JlL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucydcbmltcG9ydCB7IFJlYWxUaW1lTWVzc2FnZSwgTm90aWZpY2F0aW9uVHlwZSB9IGZyb20gJy4uL3R5cGVzL1JlYWxUaW1lTWVzc2FnZSdcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVhbFRpbWVDb250cm9sbGVyIHtcbiAgY29ubmVjdGlvbjogSHViQ29ubmVjdGlvblxuICBvYnNlcnZlcnM6IFJlY29yZDxOb3RpZmljYXRpb25UeXBlLCBBcnJheTwobWVzc2FnZTogUmVhbFRpbWVNZXNzYWdlKSA9PiB2b2lkPj5cblxuICBjb25zdHJ1Y3RvciAoYXBpQmFzZTogc3RyaW5nKSB7XG4gICAgdGhpcy5jb25uZWN0aW9uID0gbmV3IEh1YkNvbm5lY3Rpb25CdWlsZGVyKClcbiAgICAgIC53aXRoVXJsKGFwaUJhc2UpXG4gICAgICAud2l0aEF1dG9tYXRpY1JlY29ubmVjdCgpXG4gICAgICAuY29uZmlndXJlTG9nZ2luZyhpbXBvcnQubWV0YS5lbnYuUFJPRCA/IExvZ0xldmVsLk5vbmUgOiBMb2dMZXZlbC5EZWJ1ZylcbiAgICAgIC5idWlsZCgpXG5cbiAgICB0aGlzLmNvbm5lY3Rpb24ub25jbG9zZSh0aGlzLmNsb3NlKVxuXG4gICAgdGhpcy5vYnNlcnZlcnMgPSB7XG4gICAgICBbTm90aWZpY2F0aW9uVHlwZS5BUFBST1ZFRF9DT05UUkFDVF06IFtdLFxuICAgICAgW05vdGlmaWNhdGlvblR5cGUuUEVORElOR19DT05UUkFDVF06IFtdLFxuICAgICAgW05vdGlmaWNhdGlvblR5cGUuUkVKRUNURURfQ09OVFJBQ1RdOiBbXSxcbiAgICAgIFtOb3RpZmljYXRpb25UeXBlLkFDQ0VQVEVEX1RFUk1TXTogW10sXG4gICAgICBbTm90aWZpY2F0aW9uVHlwZS5SRUpFQ1RFRF9URVJNU106IFtdLFxuICAgIH1cbiAgfVxuXG4gIHN1YnNjcmliZSAoXG4gICAgdHlwZTogTm90aWZpY2F0aW9uVHlwZSxcbiAgICBsaXN0ZW5lcjogKG1lc3NhZ2U6IFJlYWxUaW1lTWVzc2FnZSkgPT4gdm9pZCxcbiAgKTogdm9pZCB7XG4gICAgdGhpcy5vYnNlcnZlcnNbdHlwZV0ucHVzaChsaXN0ZW5lcilcbiAgfVxuXG4gIHVuc3Vic2NyaWJlIChcbiAgICB0eXBlOiBOb3RpZmljYXRpb25UeXBlLFxuICAgIGxpc3RlbmVyOiAobWVzc2FnZTogUmVhbFRpbWVNZXNzYWdlKSA9PiB2b2lkLFxuICApOiB2b2lkIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMub2JzZXJ2ZXJzW3R5cGVdLmZpbmRJbmRleChcbiAgICAgIF9saXN0ZW5lciA9PiBsaXN0ZW5lciA9PT0gX2xpc3RlbmVyLFxuICAgIClcbiAgICB0aGlzLm9ic2VydmVyc1t0eXBlXS5zcGxpY2UoaW5kZXgsIDEpXG4gIH1cblxuICBhc3luYyBzdGFydCAoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgICAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcbiAgICAgIGF3YWl0IHRoaXMuY29ubmVjdGlvbi5zdGFydCgpXG4gICAgICB0aGlzLmNvbm5lY3Rpb24ub24oJ0dlbmVyYWwnLCAocGF5bG9hZDogUmVhbFRpbWVNZXNzYWdlKSA9PiB7XG4gICAgICAgIHRoaXMub2JzZXJ2ZXJzW3BheWxvYWQudGlwb10uZm9yRWFjaChsaXN0ZW5lciA9PiBsaXN0ZW5lcihwYXlsb2FkKSlcbiAgICAgICAgbm90aWZpY2F0aW9uc1F1ZXJ5U2VydmljZS5pbnZhbGlkYXRlUXVlcmllcygpXG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xuICAgICAgICAgIG1lc3NhZ2U6IHBheWxvYWQuZGVzY3JpY2FvLFxuICAgICAgICAgIHR5cGU6IDAsXG4gICAgICAgICAgdGltZW91dDogMTUwMDAsXG4gICAgICAgIH0pXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgfVxuICB9XG5cbiAgY2xvc2UgKCk6IHZvaWQge1xuICAgIHRoaXMuc3RhcnQoKVxuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQXdCLHNCQUFzQixnQkFBZ0I7QUFDOUQsU0FBUyxpQ0FBaUM7QUFDMUMsU0FBUyx3QkFBd0I7QUFDakMsU0FBMEIsd0JBQXdCO0FBRWxELHFCQUFxQixtQkFBbUI7QUFBQSxFQUN0QztBQUFBLEVBQ0E7QUFBQSxFQUVBLFlBQWEsU0FBaUI7QUFDNUIsU0FBSyxhQUFhLElBQUkscUJBQXFCLEVBQ3hDLFFBQVEsT0FBTyxFQUNmLHVCQUF1QixFQUN2QixpQkFBaUIsWUFBWSxJQUFJLE9BQU8sU0FBUyxPQUFPLFNBQVMsS0FBSyxFQUN0RSxNQUFNO0FBRVQsU0FBSyxXQUFXLFFBQVEsS0FBSyxLQUFLO0FBRWxDLFNBQUssWUFBWTtBQUFBLE1BQ2YsQ0FBQyxpQkFBaUIsaUJBQWlCLEdBQUcsQ0FBQztBQUFBLE1BQ3ZDLENBQUMsaUJBQWlCLGdCQUFnQixHQUFHLENBQUM7QUFBQSxNQUN0QyxDQUFDLGlCQUFpQixpQkFBaUIsR0FBRyxDQUFDO0FBQUEsTUFDdkMsQ0FBQyxpQkFBaUIsY0FBYyxHQUFHLENBQUM7QUFBQSxNQUNwQyxDQUFDLGlCQUFpQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3RDO0FBQUEsRUFDRjtBQUFBLEVBRUEsVUFDRSxNQUNBLFVBQ007QUFDTixTQUFLLFVBQVUsSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLEVBQ3BDO0FBQUEsRUFFQSxZQUNFLE1BQ0EsVUFDTTtBQUNOLFVBQU0sUUFBUSxLQUFLLFVBQVUsSUFBSSxFQUFFO0FBQUEsTUFDakMsZUFBYSxhQUFhO0FBQUEsSUFDNUI7QUFDQSxTQUFLLFVBQVUsSUFBSSxFQUFFLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDdEM7QUFBQSxFQUVBLE1BQU0sUUFBd0I7QUFDNUIsUUFBSTtBQUVGLFlBQU0sRUFBRSxpQkFBaUIsSUFBSSxpQkFBaUI7QUFDOUMsWUFBTSxLQUFLLFdBQVcsTUFBTTtBQUM1QixXQUFLLFdBQVcsR0FBRyxXQUFXLENBQUMsWUFBNkI7QUFDMUQsYUFBSyxVQUFVLFFBQVEsSUFBSSxFQUFFLFFBQVEsY0FBWSxTQUFTLE9BQU8sQ0FBQztBQUNsRSxrQ0FBMEIsa0JBQWtCO0FBQzVDLHlCQUFpQjtBQUFBLFVBQ2YsU0FBUyxRQUFRO0FBQUEsVUFDakIsTUFBTTtBQUFBLFVBQ04sU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsU0FBUyxPQUFQO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLFFBQWU7QUFDYixTQUFLLE1BQU07QUFBQSxFQUNiO0FBQ0Y7IiwibmFtZXMiOltdfQ==