import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/comboBox/ComboBox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/comboBox/ComboBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ComboBox as ComboBoxFluent, mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const ComboBox = ({
  styles,
  ...props
}) => {
  _s();
  const {
    colors
  } = useTheme();
  const comboBoxStyles = useStyles();
  return /* @__PURE__ */ jsxDEV(ComboBoxFluent, { styles: {
    root: {
      ":not(:disabled,:focus)::after": {
        border: `solid 1px ${props.errorMessage ? colors.red[500] : colors.gray[400]}`
      },
      ":hover::after:not(.is-open)": {
        border: `solid 1px ${props.errorMessage ? colors.red[500] : colors.gray[400]}`
      },
      "button:disabled": {
        background: props.disabledAsReadOnly ? colors.gray[200] : colors.neutralLight[100]
      },
      "input[aria-disabled=true]": {
        background: props.disabledAsReadOnly ? colors.gray[200] : colors.neutralLight[100]
      }
    },
    rootFocused: {
      "::after": {
        border: `solid 2px ${colors.blue[300]}`,
        borderRadius: "2px"
      }
    },
    rootHovered: {
      "::after": {
        border: `solid 1px ${colors.blue[300]}`,
        borderRadius: "2px"
      }
    },
    errorMessage: {
      color: colors.red[500]
    },
    rootDisabled: {
      backgroundColor: props.disabledAsReadOnly ? colors.gray[200] : colors.neutralLight[100]
    },
    ...styles
  }, ...props, calloutProps: {
    className: `${comboBoxStyles} ${props.calloutProps?.className}`,
    calloutMaxHeight: 240,
    ...props.calloutProps
  } }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/comboBox/ComboBox.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(ComboBox, "j67ztPnjwkSrwSpFDWp//RzSMIg=", false, function() {
  return [useTheme, useStyles];
});
_c = ComboBox;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyles({
    ".ms-Checkbox.is-checked .ms-Checkbox-checkbox": {
      backgroundColor: colors.purple[500],
      borderColor: colors.purple[500]
    },
    ".ms-Checkbox.is-checked:hover .ms-Checkbox-checkbox": {
      backgroundColor: colors.purple[500],
      borderColor: colors.purple[500]
    },
    ".ms-Checkbox:not(.is-disabled) .ms-Checkbox-checkbox:hover": {
      backgroundColor: colors.purple[500],
      borderColor: colors.purple[500]
    }
  });
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default ComboBox;
var _c;
$RefreshReg$(_c, "ComboBox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/comboBox/ComboBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJKLFNBQ0VBLFlBQVlDLGdCQUVaQyxtQkFDSztBQUVQLFNBQVNDLGdCQUFnQjtBQU16QixNQUFNSCxXQUFzQkEsQ0FBQztBQUFBLEVBQUVJO0FBQUFBLEVBQVEsR0FBR0M7QUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDcEQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSUosU0FBUztBQUU1QixRQUFNSyxpQkFBaUJDLFVBQVU7QUFFakMsU0FDRSx1QkFBQyxrQkFDQyxRQUFRO0FBQUEsSUFDTkMsTUFBTTtBQUFBLE1BQ0osaUNBQWlDO0FBQUEsUUFDL0JDLFFBQVMsYUFBWU4sTUFBTU8sZUFBZUwsT0FBT00sSUFBSSxHQUFHLElBQUlOLE9BQU9PLEtBQUssR0FBRztBQUFBLE1BQzdFO0FBQUEsTUFDQSwrQkFBK0I7QUFBQSxRQUM3QkgsUUFBUyxhQUFZTixNQUFNTyxlQUFlTCxPQUFPTSxJQUFJLEdBQUcsSUFBSU4sT0FBT08sS0FBSyxHQUFHO0FBQUEsTUFDN0U7QUFBQSxNQUNBLG1CQUFtQjtBQUFBLFFBQ2pCQyxZQUFZVixNQUFNVyxxQkFBcUJULE9BQU9PLEtBQUssR0FBRyxJQUFJUCxPQUFPVSxhQUFhLEdBQUc7QUFBQSxNQUNuRjtBQUFBLE1BQ0EsNkJBQTZCO0FBQUEsUUFDM0JGLFlBQVlWLE1BQU1XLHFCQUFxQlQsT0FBT08sS0FBSyxHQUFHLElBQUlQLE9BQU9VLGFBQWEsR0FBRztBQUFBLE1BQ25GO0FBQUEsSUFDRjtBQUFBLElBQ0FDLGFBQWE7QUFBQSxNQUNYLFdBQVc7QUFBQSxRQUNUUCxRQUFTLGFBQVlKLE9BQU9ZLEtBQUssR0FBRztBQUFBLFFBQ3BDQyxjQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQUMsYUFBYTtBQUFBLE1BQ1gsV0FBVztBQUFBLFFBQ1RWLFFBQVMsYUFBWUosT0FBT1ksS0FBSyxHQUFHO0FBQUEsUUFDcENDLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBUixjQUFjO0FBQUEsTUFDWlUsT0FBT2YsT0FBT00sSUFBSSxHQUFHO0FBQUEsSUFDdkI7QUFBQSxJQUNBVSxjQUFjO0FBQUEsTUFDWkMsaUJBQWlCbkIsTUFBTVcscUJBQXFCVCxPQUFPTyxLQUFLLEdBQUcsSUFBSVAsT0FBT1UsYUFBYSxHQUFHO0FBQUEsSUFDeEY7QUFBQSxJQUVBLEdBQUdiO0FBQUFBLEVBQ0wsR0FDQSxHQUFJQyxPQUNKLGNBQWM7QUFBQSxJQUNab0IsV0FBWSxHQUFFakIsa0JBQWtCSCxNQUFNcUIsY0FBY0Q7QUFBQUEsSUFDcERFLGtCQUFrQjtBQUFBLElBQ2xCLEdBQUd0QixNQUFNcUI7QUFBQUEsRUFDWCxLQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMENJO0FBR1I7QUFBQ3BCLEdBbkRLTixVQUFtQjtBQUFBLFVBQ0pHLFVBRUlNLFNBQVM7QUFBQTtBQUFBbUIsS0FINUI1QjtBQXFETixNQUFNUyxZQUFZQSxNQUFNO0FBQUFvQixNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFdEI7QUFBQUEsRUFBTyxJQUFJSixTQUFTO0FBQzVCLFNBQU9ELFlBQVk7QUFBQSxJQUNqQixpREFBaUQ7QUFBQSxNQUMvQ3NCLGlCQUFpQmpCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsYUFBYXhCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxJQUNoQztBQUFBLElBQ0EsdURBQXVEO0FBQUEsTUFDckROLGlCQUFpQmpCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsYUFBYXhCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxJQUNoQztBQUFBLElBQ0EsOERBQThEO0FBQUEsTUFDNUROLGlCQUFpQmpCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsYUFBYXhCLE9BQU91QixPQUFPLEdBQUc7QUFBQSxJQUNoQztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNELElBaEJLcEIsV0FBUztBQUFBLFVBQ01OLFFBQVE7QUFBQTtBQWlCN0IsZUFBZUg7QUFBUSxJQUFBNEI7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbIkNvbWJvQm94IiwiQ29tYm9Cb3hGbHVlbnQiLCJtZXJnZVN0eWxlcyIsInVzZVRoZW1lIiwic3R5bGVzIiwicHJvcHMiLCJfcyIsImNvbG9ycyIsImNvbWJvQm94U3R5bGVzIiwidXNlU3R5bGVzIiwicm9vdCIsImJvcmRlciIsImVycm9yTWVzc2FnZSIsInJlZCIsImdyYXkiLCJiYWNrZ3JvdW5kIiwiZGlzYWJsZWRBc1JlYWRPbmx5IiwibmV1dHJhbExpZ2h0Iiwicm9vdEZvY3VzZWQiLCJibHVlIiwiYm9yZGVyUmFkaXVzIiwicm9vdEhvdmVyZWQiLCJjb2xvciIsInJvb3REaXNhYmxlZCIsImJhY2tncm91bmRDb2xvciIsImNsYXNzTmFtZSIsImNhbGxvdXRQcm9wcyIsImNhbGxvdXRNYXhIZWlnaHQiLCJfYyIsIl9zMiIsInB1cnBsZSIsImJvcmRlckNvbG9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29tYm9Cb3gudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvY29tYm9Cb3gvQ29tYm9Cb3gudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBDb21ib0JveCBhcyBDb21ib0JveEZsdWVudCxcclxuICBJQ29tYm9Cb3hQcm9wcyxcclxuICBtZXJnZVN0eWxlcyxcclxufSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXHJcblxyXG5pbnRlcmZhY2UgUHJvcHMgZXh0ZW5kcyBJQ29tYm9Cb3hQcm9wcyB7XHJcbiAgZGlzYWJsZWRBc1JlYWRPbmx5PzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBDb21ib0JveDogRkM8UHJvcHM+ID0gKHsgc3R5bGVzLCAuLi5wcm9wcyB9KSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgY29uc3QgY29tYm9Cb3hTdHlsZXMgPSB1c2VTdHlsZXMoKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPENvbWJvQm94Rmx1ZW50XHJcbiAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICc6bm90KDpkaXNhYmxlZCw6Zm9jdXMpOjphZnRlcic6IHtcclxuICAgICAgICAgICAgYm9yZGVyOiBgc29saWQgMXB4ICR7cHJvcHMuZXJyb3JNZXNzYWdlID8gY29sb3JzLnJlZFs1MDBdIDogY29sb3JzLmdyYXlbNDAwXX1gLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgICc6aG92ZXI6OmFmdGVyOm5vdCguaXMtb3BlbiknOiB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogYHNvbGlkIDFweCAke3Byb3BzLmVycm9yTWVzc2FnZSA/IGNvbG9ycy5yZWRbNTAwXSA6IGNvbG9ycy5ncmF5WzQwMF19YCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICAnYnV0dG9uOmRpc2FibGVkJzoge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBwcm9wcy5kaXNhYmxlZEFzUmVhZE9ubHkgPyBjb2xvcnMuZ3JheVsyMDBdIDogY29sb3JzLm5ldXRyYWxMaWdodFsxMDBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgICdpbnB1dFthcmlhLWRpc2FibGVkPXRydWVdJzoge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBwcm9wcy5kaXNhYmxlZEFzUmVhZE9ubHkgPyBjb2xvcnMuZ3JheVsyMDBdIDogY29sb3JzLm5ldXRyYWxMaWdodFsxMDBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJvb3RGb2N1c2VkOiB7XHJcbiAgICAgICAgICAnOjphZnRlcic6IHtcclxuICAgICAgICAgICAgYm9yZGVyOiBgc29saWQgMnB4ICR7Y29sb3JzLmJsdWVbMzAwXX1gLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcycHgnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJvb3RIb3ZlcmVkOiB7XHJcbiAgICAgICAgICAnOjphZnRlcic6IHtcclxuICAgICAgICAgICAgYm9yZGVyOiBgc29saWQgMXB4ICR7Y29sb3JzLmJsdWVbMzAwXX1gLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcycHgnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVycm9yTWVzc2FnZToge1xyXG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5yZWRbNTAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJvb3REaXNhYmxlZDoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBwcm9wcy5kaXNhYmxlZEFzUmVhZE9ubHkgPyBjb2xvcnMuZ3JheVsyMDBdIDogY29sb3JzLm5ldXRyYWxMaWdodFsxMDBdLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIC4uLnN0eWxlcyxcclxuICAgICAgfX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgICBjYWxsb3V0UHJvcHM9e3tcclxuICAgICAgICBjbGFzc05hbWU6IGAke2NvbWJvQm94U3R5bGVzfSAke3Byb3BzLmNhbGxvdXRQcm9wcz8uY2xhc3NOYW1lfWAsXHJcbiAgICAgICAgY2FsbG91dE1heEhlaWdodDogMjQwLFxyXG4gICAgICAgIC4uLnByb3BzLmNhbGxvdXRQcm9wcyxcclxuICAgICAgfX1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICByZXR1cm4gbWVyZ2VTdHlsZXMoe1xyXG4gICAgJy5tcy1DaGVja2JveC5pcy1jaGVja2VkIC5tcy1DaGVja2JveC1jaGVja2JveCc6IHtcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICB9LFxyXG4gICAgJy5tcy1DaGVja2JveC5pcy1jaGVja2VkOmhvdmVyIC5tcy1DaGVja2JveC1jaGVja2JveCc6IHtcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICB9LFxyXG4gICAgJy5tcy1DaGVja2JveDpub3QoLmlzLWRpc2FibGVkKSAubXMtQ2hlY2tib3gtY2hlY2tib3g6aG92ZXInOiB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICBib3JkZXJDb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21ib0JveFxyXG4iXX0=