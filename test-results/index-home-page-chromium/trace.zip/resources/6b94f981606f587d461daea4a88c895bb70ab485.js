const VisitTitleRecord = {
  0: "Planejamento",
  1: "Prévia",
  2: "Operacional",
  3: "Balanço",
  4: "Inventário",
  5: "Circularização",
  6: "Reuniões",
  7: "1º ITR",
  8: "2º ITR",
  9: "3º ITR",
  10: "Operacional - Comercial",
  11: "Operacional - Compras",
  12: "Operacional - Contábil",
  13: "Operacional - Custos",
  14: "Operacional - Financeiro",
  15: "Operacional - Fiscal",
  16: "Operacional - Logística",
  17: "Operacional - Estoques",
  18: "Operacional - Produção",
  19: "Operacional - Recursos Humanos",
  20: "Operacional - Engenharia",
  21: "Operacional - TI",
  22: "Operacional - Importação e Exportação",
  23: "Operacional - ECD",
  24: "Operacional - ECF"
};
export default VisitTitleRecord;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlZpc2l0VGl0bGVSZWNvcmQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyBWaXNpdFRpdGxlRW51bSB9IGZyb20gJy4uL2VudW1zL1Zpc2l0VGl0bGVFbnVtJ1xuXG5jb25zdCBWaXNpdFRpdGxlUmVjb3JkOiBSZWNvcmQ8VmlzaXRUaXRsZUVudW0sIHN0cmluZz4gPSB7XG4gIDA6ICdQbGFuZWphbWVudG8nLFxuICAxOiAnUHLDqXZpYScsXG4gIDI6ICdPcGVyYWNpb25hbCcsXG4gIDM6ICdCYWxhbsOnbycsXG4gIDQ6ICdJbnZlbnTDoXJpbycsXG4gIDU6ICdDaXJjdWxhcml6YcOnw6NvJyxcbiAgNjogJ1JldW5pw7VlcycsXG4gIDc6ICcxwrogSVRSJyxcbiAgODogJzLCuiBJVFInLFxuICA5OiAnM8K6IElUUicsXG4gIDEwOiAnT3BlcmFjaW9uYWwgLSBDb21lcmNpYWwnLFxuICAxMTogJ09wZXJhY2lvbmFsIC0gQ29tcHJhcycsXG4gIDEyOiAnT3BlcmFjaW9uYWwgLSBDb250w6FiaWwnLFxuICAxMzogJ09wZXJhY2lvbmFsIC0gQ3VzdG9zJyxcbiAgMTQ6ICdPcGVyYWNpb25hbCAtIEZpbmFuY2Vpcm8nLFxuICAxNTogJ09wZXJhY2lvbmFsIC0gRmlzY2FsJyxcbiAgMTY6ICdPcGVyYWNpb25hbCAtIExvZ8Otc3RpY2EnLFxuICAxNzogJ09wZXJhY2lvbmFsIC0gRXN0b3F1ZXMnLFxuICAxODogJ09wZXJhY2lvbmFsIC0gUHJvZHXDp8OjbycsXG4gIDE5OiAnT3BlcmFjaW9uYWwgLSBSZWN1cnNvcyBIdW1hbm9zJyxcbiAgMjA6ICdPcGVyYWNpb25hbCAtIEVuZ2VuaGFyaWEnLFxuICAyMTogJ09wZXJhY2lvbmFsIC0gVEknLFxuICAyMjogJ09wZXJhY2lvbmFsIC0gSW1wb3J0YcOnw6NvIGUgRXhwb3J0YcOnw6NvJyxcbiAgMjM6ICdPcGVyYWNpb25hbCAtIEVDRCcsXG4gIDI0OiAnT3BlcmFjaW9uYWwgLSBFQ0YnLFxufVxuXG5leHBvcnQgZGVmYXVsdCBWaXNpdFRpdGxlUmVjb3JkXG4iXSwibWFwcGluZ3MiOiJBQUdBLE1BQU0sbUJBQW1EO0FBQUEsRUFDdkQsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUNOO0FBRUEsZUFBZTsiLCJuYW1lcyI6W119