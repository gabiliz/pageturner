import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-YNY3AOFZ.js?v=9f90a7ff";
import {
  FontIcon,
  Icon,
  ImageIcon
} from "/node_modules/.vite/deps/chunk-7CLY36K2.js?v=9f90a7ff";
import {
  AnimationClassNames,
  FontWeights,
  HighContrastSelector,
  IconFontSizes,
  ScreenWidthMaxMedium,
  ZIndexes,
  createTheme,
  focusClear,
  getFocusStyle,
  getGlobalClassNames,
  getHighContrastNoAdjustStyle,
  getScreenSelector,
  getTheme,
  hiddenContentStyle
} from "/node_modules/.vite/deps/chunk-XOB7MPSE.js?v=9f90a7ff";
import {
  WindowContext,
  useAsync,
  useConst,
  useDocument,
  useEventCallback,
  useId,
  useMergedRefs,
  useOnEvent,
  usePrevious,
  useTarget,
  useUnmount,
  useWarnings,
  useWindow
} from "/node_modules/.vite/deps/chunk-AL35FZVI.js?v=9f90a7ff";
import {
  Async,
  Customizer,
  EventGroup,
  FocusRects,
  FocusRectsContext,
  FocusRectsProvider,
  IsFocusVisibleClassName,
  KeyCodes,
  Rectangle,
  addElementAtIndex,
  anchorProperties,
  assign,
  buttonProperties,
  classNamesFunction,
  composeComponentAs,
  composeRenderFunction,
  createMergedRef,
  css,
  customizable,
  divProperties,
  doesElementContainFocus,
  elementContains,
  find,
  findScrollableParent,
  focusAsync,
  focusFirstChild,
  getDocument,
  getElementIndexPath,
  getFirstFocusable,
  getFirstTabbable,
  getFocusableByIndexPath,
  getId,
  getLastFocusable,
  getLastTabbable,
  getNativeProps,
  getNextElement,
  getParent,
  getPreviousElement,
  getPropsWithDefaults,
  getRTL,
  getScrollbarWidth,
  getWindow,
  hoistMethods,
  hoistStatics,
  htmlElementProperties,
  initializeComponentRef,
  isElementFocusSubZone,
  isElementFocusZone,
  isElementTabbable,
  isElementVisibleAndNotHidden,
  isIOS,
  isMac,
  memoizeFunction,
  mergeAriaAttributeValues,
  modalize,
  nullRender,
  on,
  portalContainsElement,
  setFocusVisibility,
  setPortalAttribute,
  setVirtualParent,
  shallowCompare,
  shouldWrapFocus,
  styled,
  unhoistMethods,
  useIsomorphicLayoutEffect,
  warn,
  warnConditionallyRequiredProps,
  warnDeprecations
} from "/node_modules/.vite/deps/chunk-JYWLVXGS.js?v=9f90a7ff";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  __assign,
  __decorate,
  __extends,
  __rest,
  __spreadArray,
  concatStyleSets,
  concatStyleSetsWithProps,
  mergeStyleSets,
  mergeStyles,
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@fluentui/react/lib/components/Nav/Nav.base.js
var React34 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/BaseButton.js
var React25 = __toESM(require_react());

// node_modules/@fluentui/react/lib/common/DirectionalHint.js
var DirectionalHint = {
  /**
   * Appear above the target element, with the left edges of the callout and target aligning.
   */
  topLeftEdge: 0,
  /**
   * Appear above the target element, with the centers of the callout and target aligning.
   */
  topCenter: 1,
  /**
   * Appear above the target element, with the right edges of the callout and target aligning.
   */
  topRightEdge: 2,
  /**
   * Appear above the target element, aligning with the target element such that the callout tends toward
   * the center of the screen.
   */
  topAutoEdge: 3,
  /**
   * Appear below the target element, with the left edges of the callout and target aligning.
   */
  bottomLeftEdge: 4,
  /**
   * Appear below the target element, with the centers of the callout and target aligning.
   */
  bottomCenter: 5,
  /**
   * Appear below the target element, with the right edges of the callout and target aligning.
   */
  bottomRightEdge: 6,
  /**
   * Appear below the target element, aligning with the target element such that the callout tends toward
   * the center of the screen.
   */
  bottomAutoEdge: 7,
  /**
   * Appear to the left of the target element, with the top edges of the callout and target aligning.
   */
  leftTopEdge: 8,
  /**
   * Appear to the left of the target element, with the centers of the callout and target aligning.
   */
  leftCenter: 9,
  /**
   * Appear to the left of the target element, with the bottom edges of the callout and target aligning.
   */
  leftBottomEdge: 10,
  /**
   * Appear to the right of the target element, with the top edges of the callout and target aligning.
   */
  rightTopEdge: 11,
  /**
   * Appear to the right of the target element, with the centers of the callout and target aligning.
   */
  rightCenter: 12,
  /**
   * Appear to the right of the target element, with the bottom edges of the callout and target aligning.
   */
  rightBottomEdge: 13
};

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.js
var React24 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.base.js
var React23 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.types.js
var ContextualMenuItemType;
(function(ContextualMenuItemType2) {
  ContextualMenuItemType2[ContextualMenuItemType2["Normal"] = 0] = "Normal";
  ContextualMenuItemType2[ContextualMenuItemType2["Divider"] = 1] = "Divider";
  ContextualMenuItemType2[ContextualMenuItemType2["Header"] = 2] = "Header";
  ContextualMenuItemType2[ContextualMenuItemType2["Section"] = 3] = "Section";
})(ContextualMenuItemType || (ContextualMenuItemType = {}));

// node_modules/@fluentui/react-focus/lib/version.js
setVersion("@fluentui/react-focus", "8.8.32");

// node_modules/@fluentui/react-focus/lib/components/FocusZone/FocusZone.js
var React = __toESM(require_react());

// node_modules/@fluentui/react-focus/lib/components/FocusZone/FocusZone.types.js
var FocusZoneTabbableElements = {
  /** Tabbing is not allowed */
  none: 0,
  /** All tabbing action is allowed */
  all: 1,
  /** Tabbing is allowed only on input elements */
  inputOnly: 2
};
var FocusZoneDirection;
(function(FocusZoneDirection2) {
  FocusZoneDirection2[FocusZoneDirection2["vertical"] = 0] = "vertical";
  FocusZoneDirection2[FocusZoneDirection2["horizontal"] = 1] = "horizontal";
  FocusZoneDirection2[FocusZoneDirection2["bidirectional"] = 2] = "bidirectional";
  FocusZoneDirection2[FocusZoneDirection2["domOrder"] = 3] = "domOrder";
})(FocusZoneDirection || (FocusZoneDirection = {}));

// node_modules/@fluentui/react-focus/lib/components/FocusZone/FocusZone.js
var IS_FOCUSABLE_ATTRIBUTE = "data-is-focusable";
var IS_ENTER_DISABLED_ATTRIBUTE = "data-disable-click-on-enter";
var FOCUSZONE_ID_ATTRIBUTE = "data-focuszone-id";
var TABINDEX = "tabindex";
var NO_VERTICAL_WRAP = "data-no-vertical-wrap";
var NO_HORIZONTAL_WRAP = "data-no-horizontal-wrap";
var LARGE_DISTANCE_FROM_CENTER = 999999999;
var LARGE_NEGATIVE_DISTANCE_FROM_CENTER = -999999999;
var focusZoneStyles;
var focusZoneClass = "ms-FocusZone";
function raiseClickFromKeyboardEvent(target, ev) {
  var event;
  if (typeof MouseEvent === "function") {
    event = new MouseEvent("click", {
      ctrlKey: ev === null || ev === void 0 ? void 0 : ev.ctrlKey,
      metaKey: ev === null || ev === void 0 ? void 0 : ev.metaKey,
      shiftKey: ev === null || ev === void 0 ? void 0 : ev.shiftKey,
      altKey: ev === null || ev === void 0 ? void 0 : ev.altKey,
      bubbles: ev === null || ev === void 0 ? void 0 : ev.bubbles,
      cancelable: ev === null || ev === void 0 ? void 0 : ev.cancelable
    });
  } else {
    event = document.createEvent("MouseEvents");
    event.initMouseEvent(
      "click",
      ev ? ev.bubbles : false,
      ev ? ev.cancelable : false,
      window,
      // not using getWindow() since this can only be run client side
      0,
      // detail
      0,
      // screen x
      0,
      // screen y
      0,
      // client x
      0,
      // client y
      ev ? ev.ctrlKey : false,
      ev ? ev.altKey : false,
      ev ? ev.shiftKey : false,
      ev ? ev.metaKey : false,
      0,
      // button
      null
    );
  }
  target.dispatchEvent(event);
}
function getRootClass() {
  if (!focusZoneStyles) {
    focusZoneStyles = mergeStyles({
      selectors: {
        ":focus": {
          outline: "none"
        }
      }
    }, focusZoneClass);
  }
  return focusZoneStyles;
}
var _allInstances = {};
var _outerZones = /* @__PURE__ */ new Set();
var ALLOWED_INPUT_TYPES = ["text", "number", "password", "email", "tel", "url", "search", "textarea"];
var ALLOW_VIRTUAL_ELEMENTS = false;
var FocusZone = (
  /** @class */
  function(_super) {
    __extends(FocusZone2, _super);
    function FocusZone2(props) {
      var _this = this;
      var _a3, _b, _c, _d;
      _this = _super.call(this, props) || this;
      _this._root = React.createRef();
      _this._mergedRef = createMergedRef();
      _this._onFocus = function(ev) {
        if (_this._portalContainsElement(ev.target)) {
          return;
        }
        var _a4 = _this.props, onActiveElementChanged = _a4.onActiveElementChanged, doNotAllowFocusEventToPropagate = _a4.doNotAllowFocusEventToPropagate, stopFocusPropagation = _a4.stopFocusPropagation, onFocusNotification = _a4.onFocusNotification, onFocus = _a4.onFocus, shouldFocusInnerElementWhenReceivedFocus = _a4.shouldFocusInnerElementWhenReceivedFocus, defaultTabbableElement = _a4.defaultTabbableElement;
        var isImmediateDescendant = _this._isImmediateDescendantOfZone(ev.target);
        var newActiveElement;
        if (isImmediateDescendant) {
          newActiveElement = ev.target;
        } else {
          var parentElement = ev.target;
          while (parentElement && parentElement !== _this._root.current) {
            if (isElementTabbable(parentElement) && _this._isImmediateDescendantOfZone(parentElement)) {
              newActiveElement = parentElement;
              break;
            }
            parentElement = getParent(parentElement, ALLOW_VIRTUAL_ELEMENTS);
          }
        }
        if (shouldFocusInnerElementWhenReceivedFocus && ev.target === _this._root.current) {
          var maybeElementToFocus = defaultTabbableElement && typeof defaultTabbableElement === "function" && _this._root.current && defaultTabbableElement(_this._root.current);
          if (maybeElementToFocus && isElementTabbable(maybeElementToFocus)) {
            newActiveElement = maybeElementToFocus;
            maybeElementToFocus.focus();
          } else {
            _this.focus(true);
            if (_this._activeElement) {
              newActiveElement = null;
            }
          }
        }
        var initialElementFocused = !_this._activeElement;
        if (newActiveElement && newActiveElement !== _this._activeElement) {
          if (isImmediateDescendant || initialElementFocused) {
            _this._setFocusAlignment(newActiveElement, true, true);
          }
          _this._activeElement = newActiveElement;
          if (initialElementFocused) {
            _this._updateTabIndexes();
          }
        }
        if (onActiveElementChanged) {
          onActiveElementChanged(_this._activeElement, ev);
        }
        if (stopFocusPropagation || doNotAllowFocusEventToPropagate) {
          ev.stopPropagation();
        }
        if (onFocus) {
          onFocus(ev);
        } else if (onFocusNotification) {
          onFocusNotification();
        }
      };
      _this._onBlur = function() {
        _this._setParkedFocus(false);
      };
      _this._onMouseDown = function(ev) {
        if (_this._portalContainsElement(ev.target)) {
          return;
        }
        var disabled = _this.props.disabled;
        if (disabled) {
          return;
        }
        var target = ev.target;
        var path = [];
        while (target && target !== _this._root.current) {
          path.push(target);
          target = getParent(target, ALLOW_VIRTUAL_ELEMENTS);
        }
        while (path.length) {
          target = path.pop();
          if (target && isElementTabbable(target)) {
            _this._setActiveElement(target, true);
          }
          if (isElementFocusZone(target)) {
            break;
          }
        }
      };
      _this._onKeyDown = function(ev, theme) {
        if (_this._portalContainsElement(ev.target)) {
          return;
        }
        var _a4 = _this.props, direction = _a4.direction, disabled = _a4.disabled, isInnerZoneKeystroke = _a4.isInnerZoneKeystroke, pagingSupportDisabled = _a4.pagingSupportDisabled, shouldEnterInnerZone = _a4.shouldEnterInnerZone;
        if (disabled) {
          return;
        }
        if (_this.props.onKeyDown) {
          _this.props.onKeyDown(ev);
        }
        if (ev.isDefaultPrevented()) {
          return;
        }
        if (_this._getDocument().activeElement === _this._root.current && _this._isInnerZone) {
          return;
        }
        if ((shouldEnterInnerZone && shouldEnterInnerZone(ev) || isInnerZoneKeystroke && isInnerZoneKeystroke(ev)) && _this._isImmediateDescendantOfZone(ev.target)) {
          var innerZone = _this._getFirstInnerZone();
          if (innerZone) {
            if (!innerZone.focus(true)) {
              return;
            }
          } else if (isElementFocusSubZone(ev.target)) {
            if (!_this.focusElement(getNextElement(ev.target, ev.target.firstChild, true))) {
              return;
            }
          } else {
            return;
          }
        } else if (ev.altKey) {
          return;
        } else {
          switch (ev.which) {
            case KeyCodes.space:
              if (_this._shouldRaiseClicksOnSpace && _this._tryInvokeClickForFocusable(ev.target, ev)) {
                break;
              }
              return;
            case KeyCodes.left:
              if (direction !== FocusZoneDirection.vertical) {
                _this._preventDefaultWhenHandled(ev);
                if (_this._moveFocusLeft(theme)) {
                  break;
                }
              }
              return;
            case KeyCodes.right:
              if (direction !== FocusZoneDirection.vertical) {
                _this._preventDefaultWhenHandled(ev);
                if (_this._moveFocusRight(theme)) {
                  break;
                }
              }
              return;
            case KeyCodes.up:
              if (direction !== FocusZoneDirection.horizontal) {
                _this._preventDefaultWhenHandled(ev);
                if (_this._moveFocusUp()) {
                  break;
                }
              }
              return;
            case KeyCodes.down:
              if (direction !== FocusZoneDirection.horizontal) {
                _this._preventDefaultWhenHandled(ev);
                if (_this._moveFocusDown()) {
                  break;
                }
              }
              return;
            case KeyCodes.pageDown:
              if (!pagingSupportDisabled && _this._moveFocusPaging(true)) {
                break;
              }
              return;
            case KeyCodes.pageUp:
              if (!pagingSupportDisabled && _this._moveFocusPaging(false)) {
                break;
              }
              return;
            case KeyCodes.tab:
              if (
                // eslint-disable-next-line deprecation/deprecation
                _this.props.allowTabKey || _this.props.handleTabKey === FocusZoneTabbableElements.all || _this.props.handleTabKey === FocusZoneTabbableElements.inputOnly && _this._isElementInput(ev.target)
              ) {
                var focusChanged = false;
                _this._processingTabKey = true;
                if (direction === FocusZoneDirection.vertical || !_this._shouldWrapFocus(_this._activeElement, NO_HORIZONTAL_WRAP)) {
                  focusChanged = ev.shiftKey ? _this._moveFocusUp() : _this._moveFocusDown();
                } else {
                  var tabWithDirection = getRTL(theme) ? !ev.shiftKey : ev.shiftKey;
                  focusChanged = tabWithDirection ? _this._moveFocusLeft(theme) : _this._moveFocusRight(theme);
                }
                _this._processingTabKey = false;
                if (focusChanged) {
                  break;
                } else if (_this.props.shouldResetActiveElementWhenTabFromZone) {
                  _this._activeElement = null;
                }
              }
              return;
            case KeyCodes.home:
              if (_this._isContentEditableElement(ev.target) || _this._isElementInput(ev.target) && !_this._shouldInputLoseFocus(ev.target, false)) {
                return false;
              }
              var firstChild = _this._root.current && _this._root.current.firstChild;
              if (_this._root.current && firstChild && _this.focusElement(getNextElement(_this._root.current, firstChild, true))) {
                break;
              }
              return;
            case KeyCodes.end:
              if (_this._isContentEditableElement(ev.target) || _this._isElementInput(ev.target) && !_this._shouldInputLoseFocus(ev.target, true)) {
                return false;
              }
              var lastChild = _this._root.current && _this._root.current.lastChild;
              if (_this._root.current && _this.focusElement(getPreviousElement(_this._root.current, lastChild, true, true, true))) {
                break;
              }
              return;
            case KeyCodes.enter:
              if (_this._shouldRaiseClicksOnEnter && _this._tryInvokeClickForFocusable(ev.target, ev)) {
                break;
              }
              return;
            default:
              return;
          }
        }
        ev.preventDefault();
        ev.stopPropagation();
      };
      _this._getHorizontalDistanceFromCenter = function(isForward, activeRect, targetRect) {
        var leftAlignment = _this._focusAlignment.left || _this._focusAlignment.x || 0;
        var targetRectTop = Math.floor(targetRect.top);
        var activeRectBottom = Math.floor(activeRect.bottom);
        var targetRectBottom = Math.floor(targetRect.bottom);
        var activeRectTop = Math.floor(activeRect.top);
        var isValidCandidateOnpagingDown = isForward && targetRectTop > activeRectBottom;
        var isValidCandidateOnpagingUp = !isForward && targetRectBottom < activeRectTop;
        if (isValidCandidateOnpagingDown || isValidCandidateOnpagingUp) {
          if (leftAlignment >= targetRect.left && leftAlignment <= targetRect.left + targetRect.width) {
            return 0;
          }
          return Math.abs(targetRect.left + targetRect.width / 2 - leftAlignment);
        }
        if (!_this._shouldWrapFocus(_this._activeElement, NO_VERTICAL_WRAP)) {
          return LARGE_NEGATIVE_DISTANCE_FROM_CENTER;
        }
        return LARGE_DISTANCE_FROM_CENTER;
      };
      initializeComponentRef(_this);
      if (true) {
        warnDeprecations("FocusZone", props, {
          rootProps: void 0,
          allowTabKey: "handleTabKey",
          elementType: "as",
          ariaDescribedBy: "aria-describedby",
          ariaLabelledBy: "aria-labelledby"
        });
      }
      _this._id = getId("FocusZone");
      _this._focusAlignment = {
        left: 0,
        top: 0
      };
      _this._processingTabKey = false;
      var shouldRaiseClicksFallback = (_b = (_a3 = props.shouldRaiseClicks) !== null && _a3 !== void 0 ? _a3 : FocusZone2.defaultProps.shouldRaiseClicks) !== null && _b !== void 0 ? _b : true;
      _this._shouldRaiseClicksOnEnter = (_c = props.shouldRaiseClicksOnEnter) !== null && _c !== void 0 ? _c : shouldRaiseClicksFallback;
      _this._shouldRaiseClicksOnSpace = (_d = props.shouldRaiseClicksOnSpace) !== null && _d !== void 0 ? _d : shouldRaiseClicksFallback;
      return _this;
    }
    FocusZone2.getOuterZones = function() {
      return _outerZones.size;
    };
    FocusZone2._onKeyDownCapture = function(ev) {
      if (ev.which === KeyCodes.tab) {
        _outerZones.forEach(function(zone) {
          return zone._updateTabIndexes();
        });
      }
    };
    FocusZone2.prototype.componentDidMount = function() {
      var root = this._root.current;
      _allInstances[this._id] = this;
      if (root) {
        var parentElement = getParent(root, ALLOW_VIRTUAL_ELEMENTS);
        while (parentElement && parentElement !== this._getDocument().body && parentElement.nodeType === 1) {
          if (isElementFocusZone(parentElement)) {
            this._isInnerZone = true;
            break;
          }
          parentElement = getParent(parentElement, ALLOW_VIRTUAL_ELEMENTS);
        }
        if (!this._isInnerZone) {
          _outerZones.add(this);
          this._root.current && this._root.current.addEventListener("keydown", FocusZone2._onKeyDownCapture, true);
        }
        this._root.current && this._root.current.addEventListener("blur", this._onBlur, true);
        this._updateTabIndexes();
        if (this.props.defaultTabbableElement && typeof this.props.defaultTabbableElement === "string") {
          this._activeElement = this._getDocument().querySelector(this.props.defaultTabbableElement);
        } else if (this.props.defaultActiveElement) {
          this._activeElement = this._getDocument().querySelector(this.props.defaultActiveElement);
        }
        if (this.props.shouldFocusOnMount) {
          this.focus();
        }
      }
    };
    FocusZone2.prototype.componentDidUpdate = function() {
      var root = this._root.current;
      var doc = this._getDocument();
      if (this._activeElement && !elementContains(this._root.current, this._activeElement, ALLOW_VIRTUAL_ELEMENTS) || this._defaultFocusElement && !elementContains(this._root.current, this._defaultFocusElement, ALLOW_VIRTUAL_ELEMENTS)) {
        this._activeElement = null;
        this._defaultFocusElement = null;
        this._updateTabIndexes();
      }
      if (!this.props.preventFocusRestoration && doc && this._lastIndexPath && (doc.activeElement === doc.body || doc.activeElement === null || doc.activeElement === root)) {
        var elementToFocus = getFocusableByIndexPath(root, this._lastIndexPath);
        if (elementToFocus) {
          this._setActiveElement(elementToFocus, true);
          elementToFocus.focus();
          this._setParkedFocus(false);
        } else {
          this._setParkedFocus(true);
        }
      }
    };
    FocusZone2.prototype.componentWillUnmount = function() {
      delete _allInstances[this._id];
      if (!this._isInnerZone) {
        _outerZones.delete(this);
        this._root.current && this._root.current.removeEventListener("keydown", FocusZone2._onKeyDownCapture, true);
      }
      if (this._root.current) {
        this._root.current.removeEventListener("blur", this._onBlur, true);
      }
      this._activeElement = null;
      this._defaultFocusElement = null;
    };
    FocusZone2.prototype.render = function() {
      var _this = this;
      var _a3 = this.props, tag = _a3.as, elementType = _a3.elementType, rootProps = _a3.rootProps, ariaDescribedBy = _a3.ariaDescribedBy, ariaLabelledBy = _a3.ariaLabelledBy, className = _a3.className;
      var divProps = getNativeProps(this.props, htmlElementProperties);
      var Tag = tag || elementType || "div";
      this._evaluateFocusBeforeRender();
      var theme = getTheme();
      return React.createElement(Tag, __assign({ "aria-labelledby": ariaLabelledBy, "aria-describedby": ariaDescribedBy }, divProps, rootProps, {
        // Once the getClassName correctly memoizes inputs this should
        // be replaced so that className is passed to getRootClass and is included there so
        // the class names will always be in the same order.
        className: css(getRootClass(), className),
        // eslint-disable-next-line deprecation/deprecation
        ref: this._mergedRef(this.props.elementRef, this._root),
        "data-focuszone-id": this._id,
        // eslint-disable-next-line react/jsx-no-bind
        onKeyDown: function(ev) {
          return _this._onKeyDown(ev, theme);
        },
        onFocus: this._onFocus,
        onMouseDownCapture: this._onMouseDown
      }), this.props.children);
    };
    FocusZone2.prototype.focus = function(forceIntoFirstElement, bypassHiddenElements) {
      if (forceIntoFirstElement === void 0) {
        forceIntoFirstElement = false;
      }
      if (bypassHiddenElements === void 0) {
        bypassHiddenElements = false;
      }
      if (this._root.current) {
        if (!forceIntoFirstElement && this._root.current.getAttribute(IS_FOCUSABLE_ATTRIBUTE) === "true" && this._isInnerZone) {
          var ownerZoneElement = this._getOwnerZone(this._root.current);
          if (ownerZoneElement !== this._root.current) {
            var ownerZone = _allInstances[ownerZoneElement.getAttribute(FOCUSZONE_ID_ATTRIBUTE)];
            return !!ownerZone && ownerZone.focusElement(this._root.current);
          }
          return false;
        } else if (!forceIntoFirstElement && this._activeElement && elementContains(this._root.current, this._activeElement) && isElementTabbable(this._activeElement) && (!bypassHiddenElements || isElementVisibleAndNotHidden(this._activeElement))) {
          this._activeElement.focus();
          return true;
        } else {
          var firstChild = this._root.current.firstChild;
          return this.focusElement(getNextElement(this._root.current, firstChild, true, void 0, void 0, void 0, void 0, void 0, bypassHiddenElements));
        }
      }
      return false;
    };
    FocusZone2.prototype.focusLast = function() {
      if (this._root.current) {
        var lastChild = this._root.current && this._root.current.lastChild;
        return this.focusElement(getPreviousElement(this._root.current, lastChild, true, true, true));
      }
      return false;
    };
    FocusZone2.prototype.focusElement = function(element, forceAlignment) {
      var _a3 = this.props, onBeforeFocus = _a3.onBeforeFocus, shouldReceiveFocus = _a3.shouldReceiveFocus;
      if (shouldReceiveFocus && !shouldReceiveFocus(element) || onBeforeFocus && !onBeforeFocus(element)) {
        return false;
      }
      if (element) {
        this._setActiveElement(element, forceAlignment);
        if (this._activeElement) {
          this._activeElement.focus();
        }
        return true;
      }
      return false;
    };
    FocusZone2.prototype.setFocusAlignment = function(point) {
      this._focusAlignment = point;
    };
    Object.defineProperty(FocusZone2.prototype, "defaultFocusElement", {
      get: function() {
        return this._defaultFocusElement;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(FocusZone2.prototype, "activeElement", {
      get: function() {
        return this._activeElement;
      },
      enumerable: false,
      configurable: true
    });
    FocusZone2.prototype._evaluateFocusBeforeRender = function() {
      var root = this._root.current;
      var doc = this._getDocument();
      if (doc) {
        var focusedElement = doc.activeElement;
        if (focusedElement !== root) {
          var shouldRestoreFocus = elementContains(root, focusedElement, false);
          this._lastIndexPath = shouldRestoreFocus ? getElementIndexPath(root, focusedElement) : void 0;
        }
      }
    };
    FocusZone2.prototype._setParkedFocus = function(isParked) {
      var root = this._root.current;
      if (root && this._isParked !== isParked) {
        this._isParked = isParked;
        if (isParked) {
          if (!this.props.allowFocusRoot) {
            this._parkedTabIndex = root.getAttribute("tabindex");
            root.setAttribute("tabindex", "-1");
          }
          root.focus();
        } else if (!this.props.allowFocusRoot) {
          if (this._parkedTabIndex) {
            root.setAttribute("tabindex", this._parkedTabIndex);
            this._parkedTabIndex = void 0;
          } else {
            root.removeAttribute("tabindex");
          }
        }
      }
    };
    FocusZone2.prototype._setActiveElement = function(element, forceAlignment) {
      var previousActiveElement = this._activeElement;
      this._activeElement = element;
      if (previousActiveElement) {
        if (isElementFocusZone(previousActiveElement)) {
          this._updateTabIndexes(previousActiveElement);
        }
        previousActiveElement.tabIndex = -1;
      }
      if (this._activeElement) {
        if (!this._focusAlignment || forceAlignment) {
          this._setFocusAlignment(element, true, true);
        }
        this._activeElement.tabIndex = 0;
      }
    };
    FocusZone2.prototype._preventDefaultWhenHandled = function(ev) {
      this.props.preventDefaultWhenHandled && ev.preventDefault();
    };
    FocusZone2.prototype._tryInvokeClickForFocusable = function(targetElement, ev) {
      var target = targetElement;
      if (target === this._root.current) {
        return false;
      }
      do {
        if (target.tagName === "BUTTON" || target.tagName === "A" || target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SUMMARY") {
          return false;
        }
        if (this._isImmediateDescendantOfZone(target) && target.getAttribute(IS_FOCUSABLE_ATTRIBUTE) === "true" && target.getAttribute(IS_ENTER_DISABLED_ATTRIBUTE) !== "true") {
          raiseClickFromKeyboardEvent(target, ev);
          return true;
        }
        target = getParent(target, ALLOW_VIRTUAL_ELEMENTS);
      } while (target !== this._root.current);
      return false;
    };
    FocusZone2.prototype._getFirstInnerZone = function(rootElement) {
      rootElement = rootElement || this._activeElement || this._root.current;
      if (!rootElement) {
        return null;
      }
      if (isElementFocusZone(rootElement)) {
        return _allInstances[rootElement.getAttribute(FOCUSZONE_ID_ATTRIBUTE)];
      }
      var child = rootElement.firstElementChild;
      while (child) {
        if (isElementFocusZone(child)) {
          return _allInstances[child.getAttribute(FOCUSZONE_ID_ATTRIBUTE)];
        }
        var match = this._getFirstInnerZone(child);
        if (match) {
          return match;
        }
        child = child.nextElementSibling;
      }
      return null;
    };
    FocusZone2.prototype._moveFocus = function(isForward, getDistanceFromCenter, ev, useDefaultWrap) {
      if (useDefaultWrap === void 0) {
        useDefaultWrap = true;
      }
      var element = this._activeElement;
      var candidateDistance = -1;
      var candidateElement = void 0;
      var changedFocus = false;
      var isBidirectional = this.props.direction === FocusZoneDirection.bidirectional;
      if (!element || !this._root.current) {
        return false;
      }
      if (this._isElementInput(element)) {
        if (!this._shouldInputLoseFocus(element, isForward)) {
          return false;
        }
      }
      var activeRect = isBidirectional ? element.getBoundingClientRect() : null;
      do {
        element = isForward ? getNextElement(this._root.current, element) : getPreviousElement(this._root.current, element);
        if (isBidirectional) {
          if (element) {
            var targetRect = element.getBoundingClientRect();
            var elementDistance = getDistanceFromCenter(activeRect, targetRect);
            if (elementDistance === -1 && candidateDistance === -1) {
              candidateElement = element;
              break;
            }
            if (elementDistance > -1 && (candidateDistance === -1 || elementDistance < candidateDistance)) {
              candidateDistance = elementDistance;
              candidateElement = element;
            }
            if (candidateDistance >= 0 && elementDistance < 0) {
              break;
            }
          }
        } else {
          candidateElement = element;
          break;
        }
      } while (element);
      if (candidateElement && candidateElement !== this._activeElement) {
        changedFocus = true;
        this.focusElement(candidateElement);
      } else if (this.props.isCircularNavigation && useDefaultWrap) {
        if (isForward) {
          return this.focusElement(getNextElement(this._root.current, this._root.current.firstElementChild, true));
        } else {
          return this.focusElement(getPreviousElement(this._root.current, this._root.current.lastElementChild, true, true, true));
        }
      }
      return changedFocus;
    };
    FocusZone2.prototype._moveFocusDown = function() {
      var _this = this;
      var targetTop = -1;
      var leftAlignment = this._focusAlignment.left || this._focusAlignment.x || 0;
      if (
        // eslint-disable-next-line deprecation/deprecation
        this._moveFocus(true, function(activeRect, targetRect) {
          var distance = -1;
          var targetRectTop = Math.floor(targetRect.top);
          var activeRectBottom = Math.floor(activeRect.bottom);
          if (targetRectTop < activeRectBottom) {
            if (!_this._shouldWrapFocus(_this._activeElement, NO_VERTICAL_WRAP)) {
              return LARGE_NEGATIVE_DISTANCE_FROM_CENTER;
            }
            return LARGE_DISTANCE_FROM_CENTER;
          }
          if (targetTop === -1 && targetRectTop >= activeRectBottom || targetRectTop === targetTop) {
            targetTop = targetRectTop;
            if (leftAlignment >= targetRect.left && leftAlignment <= targetRect.left + targetRect.width) {
              distance = 0;
            } else {
              distance = Math.abs(targetRect.left + targetRect.width / 2 - leftAlignment);
            }
          }
          return distance;
        })
      ) {
        this._setFocusAlignment(this._activeElement, false, true);
        return true;
      }
      return false;
    };
    FocusZone2.prototype._moveFocusUp = function() {
      var _this = this;
      var targetTop = -1;
      var leftAlignment = this._focusAlignment.left || this._focusAlignment.x || 0;
      if (
        // eslint-disable-next-line deprecation/deprecation
        this._moveFocus(false, function(activeRect, targetRect) {
          var distance = -1;
          var targetRectBottom = Math.floor(targetRect.bottom);
          var targetRectTop = Math.floor(targetRect.top);
          var activeRectTop = Math.floor(activeRect.top);
          if (targetRectBottom > activeRectTop) {
            if (!_this._shouldWrapFocus(_this._activeElement, NO_VERTICAL_WRAP)) {
              return LARGE_NEGATIVE_DISTANCE_FROM_CENTER;
            }
            return LARGE_DISTANCE_FROM_CENTER;
          }
          if (targetTop === -1 && targetRectBottom <= activeRectTop || targetRectTop === targetTop) {
            targetTop = targetRectTop;
            if (leftAlignment >= targetRect.left && leftAlignment <= targetRect.left + targetRect.width) {
              distance = 0;
            } else {
              distance = Math.abs(targetRect.left + targetRect.width / 2 - leftAlignment);
            }
          }
          return distance;
        })
      ) {
        this._setFocusAlignment(this._activeElement, false, true);
        return true;
      }
      return false;
    };
    FocusZone2.prototype._moveFocusLeft = function(theme) {
      var _this = this;
      var shouldWrap = this._shouldWrapFocus(this._activeElement, NO_HORIZONTAL_WRAP);
      if (this._moveFocus(
        getRTL(theme),
        // eslint-disable-next-line deprecation/deprecation
        function(activeRect, targetRect) {
          var distance = -1;
          var topBottomComparison;
          if (getRTL(theme)) {
            topBottomComparison = parseFloat(targetRect.top.toFixed(3)) < parseFloat(activeRect.bottom.toFixed(3));
          } else {
            topBottomComparison = parseFloat(targetRect.bottom.toFixed(3)) > parseFloat(activeRect.top.toFixed(3));
          }
          if (topBottomComparison && targetRect.right <= activeRect.right && _this.props.direction !== FocusZoneDirection.vertical) {
            distance = activeRect.right - targetRect.right;
          } else if (!shouldWrap) {
            distance = LARGE_NEGATIVE_DISTANCE_FROM_CENTER;
          }
          return distance;
        },
        void 0,
        shouldWrap
      )) {
        this._setFocusAlignment(this._activeElement, true, false);
        return true;
      }
      return false;
    };
    FocusZone2.prototype._moveFocusRight = function(theme) {
      var _this = this;
      var shouldWrap = this._shouldWrapFocus(this._activeElement, NO_HORIZONTAL_WRAP);
      if (this._moveFocus(
        !getRTL(theme),
        // eslint-disable-next-line deprecation/deprecation
        function(activeRect, targetRect) {
          var distance = -1;
          var topBottomComparison;
          if (getRTL(theme)) {
            topBottomComparison = parseFloat(targetRect.bottom.toFixed(3)) > parseFloat(activeRect.top.toFixed(3));
          } else {
            topBottomComparison = parseFloat(targetRect.top.toFixed(3)) < parseFloat(activeRect.bottom.toFixed(3));
          }
          if (topBottomComparison && targetRect.left >= activeRect.left && _this.props.direction !== FocusZoneDirection.vertical) {
            distance = targetRect.left - activeRect.left;
          } else if (!shouldWrap) {
            distance = LARGE_NEGATIVE_DISTANCE_FROM_CENTER;
          }
          return distance;
        },
        void 0,
        shouldWrap
      )) {
        this._setFocusAlignment(this._activeElement, true, false);
        return true;
      }
      return false;
    };
    FocusZone2.prototype._moveFocusPaging = function(isForward, useDefaultWrap) {
      if (useDefaultWrap === void 0) {
        useDefaultWrap = true;
      }
      var element = this._activeElement;
      if (!element || !this._root.current) {
        return false;
      }
      if (this._isElementInput(element)) {
        if (!this._shouldInputLoseFocus(element, isForward)) {
          return false;
        }
      }
      var scrollableParent = findScrollableParent(element);
      if (!scrollableParent) {
        return false;
      }
      var candidateDistance = -1;
      var candidateElement = void 0;
      var targetTop = -1;
      var targetBottom = -1;
      var pagesize = scrollableParent.clientHeight;
      var activeRect = element.getBoundingClientRect();
      do {
        element = isForward ? getNextElement(this._root.current, element) : getPreviousElement(this._root.current, element);
        if (element) {
          var targetRect = element.getBoundingClientRect();
          var targetRectTop = Math.floor(targetRect.top);
          var activeRectBottom = Math.floor(activeRect.bottom);
          var targetRectBottom = Math.floor(targetRect.bottom);
          var activeRectTop = Math.floor(activeRect.top);
          var elementDistance = this._getHorizontalDistanceFromCenter(isForward, activeRect, targetRect);
          var isElementPassedPageSizeOnPagingDown = isForward && targetRectTop > activeRectBottom + pagesize;
          var isElementPassedPageSizeOnPagingUp = !isForward && targetRectBottom < activeRectTop - pagesize;
          if (isElementPassedPageSizeOnPagingDown || isElementPassedPageSizeOnPagingUp) {
            break;
          }
          if (elementDistance > -1) {
            if (isForward && targetRectTop > targetTop) {
              targetTop = targetRectTop;
              candidateDistance = elementDistance;
              candidateElement = element;
            } else if (!isForward && targetRectBottom < targetBottom) {
              targetBottom = targetRectBottom;
              candidateDistance = elementDistance;
              candidateElement = element;
            } else if (candidateDistance === -1 || elementDistance <= candidateDistance) {
              candidateDistance = elementDistance;
              candidateElement = element;
            }
          }
        }
      } while (element);
      var changedFocus = false;
      if (candidateElement && candidateElement !== this._activeElement) {
        changedFocus = true;
        this.focusElement(candidateElement);
        this._setFocusAlignment(candidateElement, false, true);
      } else if (this.props.isCircularNavigation && useDefaultWrap) {
        if (isForward) {
          return this.focusElement(getNextElement(this._root.current, this._root.current.firstElementChild, true));
        }
        return this.focusElement(getPreviousElement(this._root.current, this._root.current.lastElementChild, true, true, true));
      }
      return changedFocus;
    };
    FocusZone2.prototype._setFocusAlignment = function(element, isHorizontal, isVertical) {
      if (this.props.direction === FocusZoneDirection.bidirectional && (!this._focusAlignment || isHorizontal || isVertical)) {
        var rect = element.getBoundingClientRect();
        var left = rect.left + rect.width / 2;
        var top_1 = rect.top + rect.height / 2;
        if (!this._focusAlignment) {
          this._focusAlignment = { left, top: top_1 };
        }
        if (isHorizontal) {
          this._focusAlignment.left = left;
        }
        if (isVertical) {
          this._focusAlignment.top = top_1;
        }
      }
    };
    FocusZone2.prototype._isImmediateDescendantOfZone = function(element) {
      return this._getOwnerZone(element) === this._root.current;
    };
    FocusZone2.prototype._getOwnerZone = function(element) {
      var parentElement = getParent(element, ALLOW_VIRTUAL_ELEMENTS);
      while (parentElement && parentElement !== this._root.current && parentElement !== this._getDocument().body) {
        if (isElementFocusZone(parentElement)) {
          return parentElement;
        }
        parentElement = getParent(parentElement, ALLOW_VIRTUAL_ELEMENTS);
      }
      return parentElement;
    };
    FocusZone2.prototype._updateTabIndexes = function(element) {
      if (!this._activeElement && this.props.defaultTabbableElement && typeof this.props.defaultTabbableElement === "function") {
        this._activeElement = this.props.defaultTabbableElement(this._root.current);
      }
      if (!element && this._root.current) {
        this._defaultFocusElement = null;
        element = this._root.current;
        if (this._activeElement && !elementContains(element, this._activeElement)) {
          this._activeElement = null;
        }
      }
      if (this._activeElement && !isElementTabbable(this._activeElement)) {
        this._activeElement = null;
      }
      var childNodes = element && element.children;
      for (var childIndex = 0; childNodes && childIndex < childNodes.length; childIndex++) {
        var child = childNodes[childIndex];
        if (!isElementFocusZone(child)) {
          if (child.getAttribute && child.getAttribute(IS_FOCUSABLE_ATTRIBUTE) === "false") {
            child.setAttribute(TABINDEX, "-1");
          }
          if (isElementTabbable(child)) {
            if (this.props.disabled) {
              child.setAttribute(TABINDEX, "-1");
            } else if (!this._isInnerZone && (!this._activeElement && !this._defaultFocusElement || this._activeElement === child)) {
              this._defaultFocusElement = child;
              if (child.getAttribute(TABINDEX) !== "0") {
                child.setAttribute(TABINDEX, "0");
              }
            } else if (child.getAttribute(TABINDEX) !== "-1") {
              child.setAttribute(TABINDEX, "-1");
            }
          } else if (child.tagName === "svg" && child.getAttribute("focusable") !== "false") {
            child.setAttribute("focusable", "false");
          }
        } else if (child.getAttribute(IS_FOCUSABLE_ATTRIBUTE) === "true") {
          if (!this._isInnerZone && (!this._activeElement && !this._defaultFocusElement || this._activeElement === child)) {
            this._defaultFocusElement = child;
            if (child.getAttribute(TABINDEX) !== "0") {
              child.setAttribute(TABINDEX, "0");
            }
          } else if (child.getAttribute(TABINDEX) !== "-1") {
            child.setAttribute(TABINDEX, "-1");
          }
        }
        this._updateTabIndexes(child);
      }
    };
    FocusZone2.prototype._isContentEditableElement = function(element) {
      return element && element.getAttribute("contenteditable") === "true";
    };
    FocusZone2.prototype._isElementInput = function(element) {
      if (element && element.tagName && (element.tagName.toLowerCase() === "input" || element.tagName.toLowerCase() === "textarea")) {
        return true;
      }
      return false;
    };
    FocusZone2.prototype._shouldInputLoseFocus = function(element, isForward) {
      if (!this._processingTabKey && element && element.type && ALLOWED_INPUT_TYPES.indexOf(element.type.toLowerCase()) > -1) {
        var selectionStart = element.selectionStart;
        var selectionEnd = element.selectionEnd;
        var isRangeSelected = selectionStart !== selectionEnd;
        var inputValue = element.value;
        var isReadonly = element.readOnly;
        if (isRangeSelected || selectionStart > 0 && !isForward && !isReadonly || selectionStart !== inputValue.length && isForward && !isReadonly || !!this.props.handleTabKey && !(this.props.shouldInputLoseFocusOnArrowKey && this.props.shouldInputLoseFocusOnArrowKey(element))) {
          return false;
        }
      }
      return true;
    };
    FocusZone2.prototype._shouldWrapFocus = function(element, noWrapDataAttribute) {
      return this.props.checkForNoWrap ? shouldWrapFocus(element, noWrapDataAttribute) : true;
    };
    FocusZone2.prototype._portalContainsElement = function(element) {
      return element && !!this._root.current && portalContainsElement(element, this._root.current);
    };
    FocusZone2.prototype._getDocument = function() {
      return getDocument(this._root.current);
    };
    FocusZone2.defaultProps = {
      isCircularNavigation: false,
      direction: FocusZoneDirection.bidirectional,
      shouldRaiseClicks: true
    };
    return FocusZone2;
  }(React.Component)
);

// node_modules/@fluentui/react/lib/utilities/contextualMenu/contextualMenuUtility.js
function getIsChecked(item) {
  if (item.canCheck) {
    return !!(item.isChecked || item.checked);
  }
  if (typeof item.isChecked === "boolean") {
    return item.isChecked;
  }
  if (typeof item.checked === "boolean") {
    return item.checked;
  }
  return null;
}
function hasSubmenu(item) {
  return !!(item.subMenuProps || item.items);
}
function isItemDisabled(item) {
  return !!(item.isDisabled || item.disabled);
}
function getMenuItemAriaRole(item) {
  var isChecked = getIsChecked(item);
  var canCheck = isChecked !== null;
  return canCheck ? "menuitemcheckbox" : "menuitem";
}

// node_modules/@fluentui/react/lib/components/Callout/Callout.js
var React8 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Callout/CalloutContent.base.js
var React3 = __toESM(require_react());

// node_modules/@fluentui/react/lib/utilities/positioning/positioning.types.js
var RectangleEdge;
(function(RectangleEdge2) {
  RectangleEdge2[RectangleEdge2["top"] = 1] = "top";
  RectangleEdge2[RectangleEdge2["bottom"] = -1] = "bottom";
  RectangleEdge2[RectangleEdge2["left"] = 2] = "left";
  RectangleEdge2[RectangleEdge2["right"] = -2] = "right";
})(RectangleEdge || (RectangleEdge = {}));
var Position;
(function(Position2) {
  Position2[Position2["top"] = 0] = "top";
  Position2[Position2["bottom"] = 1] = "bottom";
  Position2[Position2["start"] = 2] = "start";
  Position2[Position2["end"] = 3] = "end";
})(Position || (Position = {}));

// node_modules/@fluentui/react/lib/utilities/positioning/positioning.js
var _a;
function _createPositionData(targetEdge, alignmentEdge, isAuto) {
  return {
    targetEdge,
    alignmentEdge,
    isAuto
  };
}
var DirectionalDictionary = (_a = {}, _a[DirectionalHint.topLeftEdge] = _createPositionData(RectangleEdge.top, RectangleEdge.left), _a[DirectionalHint.topCenter] = _createPositionData(RectangleEdge.top), _a[DirectionalHint.topRightEdge] = _createPositionData(RectangleEdge.top, RectangleEdge.right), _a[DirectionalHint.topAutoEdge] = _createPositionData(RectangleEdge.top, void 0, true), _a[DirectionalHint.bottomLeftEdge] = _createPositionData(RectangleEdge.bottom, RectangleEdge.left), _a[DirectionalHint.bottomCenter] = _createPositionData(RectangleEdge.bottom), _a[DirectionalHint.bottomRightEdge] = _createPositionData(RectangleEdge.bottom, RectangleEdge.right), _a[DirectionalHint.bottomAutoEdge] = _createPositionData(RectangleEdge.bottom, void 0, true), _a[DirectionalHint.leftTopEdge] = _createPositionData(RectangleEdge.left, RectangleEdge.top), _a[DirectionalHint.leftCenter] = _createPositionData(RectangleEdge.left), _a[DirectionalHint.leftBottomEdge] = _createPositionData(RectangleEdge.left, RectangleEdge.bottom), _a[DirectionalHint.rightTopEdge] = _createPositionData(RectangleEdge.right, RectangleEdge.top), _a[DirectionalHint.rightCenter] = _createPositionData(RectangleEdge.right), _a[DirectionalHint.rightBottomEdge] = _createPositionData(RectangleEdge.right, RectangleEdge.bottom), _a);
function _isRectangleWithinBounds(rect, boundingRect) {
  if (rect.top < boundingRect.top) {
    return false;
  }
  if (rect.bottom > boundingRect.bottom) {
    return false;
  }
  if (rect.left < boundingRect.left) {
    return false;
  }
  if (rect.right > boundingRect.right) {
    return false;
  }
  return true;
}
function _getOutOfBoundsEdges(rect, boundingRect) {
  var outOfBounds = [];
  if (rect.top < boundingRect.top) {
    outOfBounds.push(RectangleEdge.top);
  }
  if (rect.bottom > boundingRect.bottom) {
    outOfBounds.push(RectangleEdge.bottom);
  }
  if (rect.left < boundingRect.left) {
    outOfBounds.push(RectangleEdge.left);
  }
  if (rect.right > boundingRect.right) {
    outOfBounds.push(RectangleEdge.right);
  }
  return outOfBounds;
}
function _getEdgeValue(rect, edge) {
  return rect[RectangleEdge[edge]];
}
function _setEdgeValue(rect, edge, value) {
  rect[RectangleEdge[edge]] = value;
  return rect;
}
function _getCenterValue(rect, edge) {
  var edges = _getFlankingEdges(edge);
  return (_getEdgeValue(rect, edges.positiveEdge) + _getEdgeValue(rect, edges.negativeEdge)) / 2;
}
function _getRelativeEdgeValue(edge, value) {
  if (edge > 0) {
    return value;
  } else {
    return value * -1;
  }
}
function _getRelativeRectEdgeValue(edge, rect) {
  return _getRelativeEdgeValue(edge, _getEdgeValue(rect, edge));
}
function _getRelativeEdgeDifference(rect, hostRect, edge) {
  var edgeDifference = _getEdgeValue(rect, edge) - _getEdgeValue(hostRect, edge);
  return _getRelativeEdgeValue(edge, edgeDifference);
}
function _moveEdge(rect, edge, newValue, maintainSize) {
  if (maintainSize === void 0) {
    maintainSize = true;
  }
  var difference = _getEdgeValue(rect, edge) - newValue;
  var returnRect = _setEdgeValue(rect, edge, newValue);
  if (maintainSize) {
    returnRect = _setEdgeValue(rect, edge * -1, _getEdgeValue(rect, edge * -1) - difference);
  }
  return returnRect;
}
function _alignEdges(rect, target, edge, gap) {
  if (gap === void 0) {
    gap = 0;
  }
  return _moveEdge(rect, edge, _getEdgeValue(target, edge) + _getRelativeEdgeValue(edge, gap));
}
function _alignOppositeEdges(rect, target, targetEdge, gap) {
  if (gap === void 0) {
    gap = 0;
  }
  var oppositeEdge = targetEdge * -1;
  var adjustedGap = _getRelativeEdgeValue(oppositeEdge, gap);
  return _moveEdge(rect, targetEdge * -1, _getEdgeValue(target, targetEdge) + adjustedGap);
}
function _isEdgeInBounds(rect, bounds, edge) {
  var adjustedRectValue = _getRelativeRectEdgeValue(edge, rect);
  return adjustedRectValue > _getRelativeRectEdgeValue(edge, bounds);
}
function _getOutOfBoundsDegree(rect, bounds) {
  var breakingEdges = _getOutOfBoundsEdges(rect, bounds);
  var total = 0;
  for (var _i = 0, breakingEdges_1 = breakingEdges; _i < breakingEdges_1.length; _i++) {
    var edge = breakingEdges_1[_i];
    total += Math.pow(_getRelativeEdgeDifference(rect, bounds, edge), 2);
  }
  return total;
}
function _flipToFit(rect, target, bounding, positionData, gap) {
  if (gap === void 0) {
    gap = 0;
  }
  var directions = [
    RectangleEdge.left,
    RectangleEdge.right,
    RectangleEdge.bottom,
    RectangleEdge.top
  ];
  if (getRTL()) {
    directions[0] *= -1;
    directions[1] *= -1;
  }
  var currentEstimate = rect;
  var currentEdge = positionData.targetEdge;
  var currentAlignment = positionData.alignmentEdge;
  var oobDegree;
  var bestEdge = currentEdge;
  var bestAlignment = currentAlignment;
  for (var i = 0; i < 4; i++) {
    if (!_isEdgeInBounds(currentEstimate, bounding, currentEdge)) {
      var currentOOBDegree = _getOutOfBoundsDegree(currentEstimate, bounding);
      if (!oobDegree || currentOOBDegree < oobDegree) {
        oobDegree = currentOOBDegree;
        bestEdge = currentEdge;
        bestAlignment = currentAlignment;
      }
      directions.splice(directions.indexOf(currentEdge), 1);
      if (directions.length > 0) {
        if (directions.indexOf(currentEdge * -1) > -1) {
          currentEdge = currentEdge * -1;
        } else {
          currentAlignment = currentEdge;
          currentEdge = directions.slice(-1)[0];
        }
        currentEstimate = _estimatePosition(rect, target, { targetEdge: currentEdge, alignmentEdge: currentAlignment }, gap);
      }
    } else {
      return {
        elementRectangle: currentEstimate,
        targetEdge: currentEdge,
        alignmentEdge: currentAlignment
      };
    }
  }
  currentEstimate = _estimatePosition(rect, target, { targetEdge: bestEdge, alignmentEdge: bestAlignment }, gap);
  return {
    elementRectangle: currentEstimate,
    targetEdge: bestEdge,
    alignmentEdge: bestAlignment
  };
}
function _flipAlignmentEdge(elementEstimate, target, gap, coverTarget) {
  var alignmentEdge = elementEstimate.alignmentEdge, targetEdge = elementEstimate.targetEdge, elementRectangle = elementEstimate.elementRectangle;
  var oppositeEdge = alignmentEdge * -1;
  var newEstimate = _estimatePosition(elementRectangle, target, { targetEdge, alignmentEdge: oppositeEdge }, gap, coverTarget);
  return {
    elementRectangle: newEstimate,
    targetEdge,
    alignmentEdge: oppositeEdge
  };
}
function _adjustFitWithinBounds(element, target, bounding, positionData, gap, directionalHintFixed, coverTarget) {
  if (gap === void 0) {
    gap = 0;
  }
  var alignmentEdge = positionData.alignmentEdge, alignTargetEdge = positionData.alignTargetEdge;
  var elementEstimate = {
    elementRectangle: element,
    targetEdge: positionData.targetEdge,
    alignmentEdge
  };
  if (!directionalHintFixed && !coverTarget) {
    elementEstimate = _flipToFit(element, target, bounding, positionData, gap);
  }
  var outOfBounds = _getOutOfBoundsEdges(elementEstimate.elementRectangle, bounding);
  var fixedEdge = directionalHintFixed ? -elementEstimate.targetEdge : void 0;
  if (outOfBounds.length > 0) {
    if (alignTargetEdge) {
      if (elementEstimate.alignmentEdge && outOfBounds.indexOf(elementEstimate.alignmentEdge * -1) > -1) {
        var flippedElementEstimate = _flipAlignmentEdge(elementEstimate, target, gap, coverTarget);
        if (_isRectangleWithinBounds(flippedElementEstimate.elementRectangle, bounding)) {
          return flippedElementEstimate;
        } else {
          elementEstimate = _alignOutOfBoundsEdges(_getOutOfBoundsEdges(flippedElementEstimate.elementRectangle, bounding), elementEstimate, bounding, fixedEdge);
        }
      } else {
        elementEstimate = _alignOutOfBoundsEdges(outOfBounds, elementEstimate, bounding, fixedEdge);
      }
    } else {
      elementEstimate = _alignOutOfBoundsEdges(outOfBounds, elementEstimate, bounding, fixedEdge);
    }
  }
  return elementEstimate;
}
function _alignOutOfBoundsEdges(outOfBoundsEdges, elementEstimate, bounding, preserveEdge) {
  for (var _i = 0, outOfBoundsEdges_1 = outOfBoundsEdges; _i < outOfBoundsEdges_1.length; _i++) {
    var direction = outOfBoundsEdges_1[_i];
    var edgeAttempt = void 0;
    if (preserveEdge && preserveEdge === direction * -1) {
      edgeAttempt = _moveEdge(elementEstimate.elementRectangle, direction, _getEdgeValue(bounding, direction), false);
      elementEstimate.forcedInBounds = true;
    } else {
      edgeAttempt = _alignEdges(elementEstimate.elementRectangle, bounding, direction);
      var inBounds = _isEdgeInBounds(edgeAttempt, bounding, direction * -1);
      if (!inBounds) {
        edgeAttempt = _moveEdge(edgeAttempt, direction * -1, _getEdgeValue(bounding, direction * -1), false);
        elementEstimate.forcedInBounds = true;
      }
    }
    elementEstimate.elementRectangle = edgeAttempt;
  }
  return elementEstimate;
}
function _centerEdgeToPoint(rect, edge, point) {
  var positiveEdge = _getFlankingEdges(edge).positiveEdge;
  var elementMiddle = _getCenterValue(rect, edge);
  var distanceToMiddle = elementMiddle - _getEdgeValue(rect, positiveEdge);
  return _moveEdge(rect, positiveEdge, point - distanceToMiddle);
}
function _estimatePosition(elementToPosition, target, positionData, gap, coverTarget) {
  if (gap === void 0) {
    gap = 0;
  }
  var estimatedElementPosition = new Rectangle(elementToPosition.left, elementToPosition.right, elementToPosition.top, elementToPosition.bottom);
  var alignmentEdge = positionData.alignmentEdge, targetEdge = positionData.targetEdge;
  var elementEdge = coverTarget ? targetEdge : targetEdge * -1;
  estimatedElementPosition = coverTarget ? _alignEdges(estimatedElementPosition, target, targetEdge, gap) : _alignOppositeEdges(estimatedElementPosition, target, targetEdge, gap);
  if (!alignmentEdge) {
    var targetMiddlePoint = _getCenterValue(target, targetEdge);
    estimatedElementPosition = _centerEdgeToPoint(estimatedElementPosition, elementEdge, targetMiddlePoint);
  } else {
    estimatedElementPosition = _alignEdges(estimatedElementPosition, target, alignmentEdge);
  }
  return estimatedElementPosition;
}
function _getFlankingEdges(edge) {
  if (edge === RectangleEdge.top || edge === RectangleEdge.bottom) {
    return {
      positiveEdge: RectangleEdge.left,
      negativeEdge: RectangleEdge.right
    };
  } else {
    return {
      positiveEdge: RectangleEdge.top,
      negativeEdge: RectangleEdge.bottom
    };
  }
}
function _finalizeReturnEdge(elementRectangle, returnEdge, bounds) {
  if (bounds && Math.abs(_getRelativeEdgeDifference(elementRectangle, bounds, returnEdge)) > Math.abs(_getRelativeEdgeDifference(elementRectangle, bounds, returnEdge * -1))) {
    return returnEdge * -1;
  }
  return returnEdge;
}
function _isEdgeOnBounds(elementRectangle, edge, bounds) {
  return bounds !== void 0 && _getEdgeValue(elementRectangle, edge) === _getEdgeValue(bounds, edge);
}
function _finalizeElementPosition(elementRectangle, hostElement, targetEdge, bounds, alignmentEdge, coverTarget, doNotFinalizeReturnEdge, forceWithinBounds) {
  var returnValue = {};
  var hostRect = _getRectangleFromElement(hostElement);
  var elementEdge = coverTarget ? targetEdge : targetEdge * -1;
  var returnEdge = alignmentEdge ? alignmentEdge : _getFlankingEdges(targetEdge).positiveEdge;
  if (!doNotFinalizeReturnEdge || _isEdgeOnBounds(elementRectangle, getOppositeEdge(returnEdge), bounds)) {
    returnEdge = _finalizeReturnEdge(elementRectangle, returnEdge, bounds);
  }
  returnValue[RectangleEdge[elementEdge]] = _getRelativeEdgeDifference(elementRectangle, hostRect, elementEdge);
  returnValue[RectangleEdge[returnEdge]] = _getRelativeEdgeDifference(elementRectangle, hostRect, returnEdge);
  if (forceWithinBounds) {
    returnValue[RectangleEdge[elementEdge * -1]] = _getRelativeEdgeDifference(elementRectangle, hostRect, elementEdge * -1);
    returnValue[RectangleEdge[returnEdge * -1]] = _getRelativeEdgeDifference(elementRectangle, hostRect, returnEdge * -1);
  }
  return returnValue;
}
function _calculateActualBeakWidthInPixels(beakWidth) {
  return Math.sqrt(beakWidth * beakWidth * 2);
}
function _getPositionData(directionalHint, directionalHintForRTL, previousPositions) {
  if (directionalHint === void 0) {
    directionalHint = DirectionalHint.bottomAutoEdge;
  }
  if (previousPositions) {
    return {
      alignmentEdge: previousPositions.alignmentEdge,
      isAuto: previousPositions.isAuto,
      targetEdge: previousPositions.targetEdge
    };
  }
  var positionInformation = __assign({}, DirectionalDictionary[directionalHint]);
  if (getRTL()) {
    if (positionInformation.alignmentEdge && positionInformation.alignmentEdge % 2 === 0) {
      positionInformation.alignmentEdge = positionInformation.alignmentEdge * -1;
    }
    return directionalHintForRTL !== void 0 ? DirectionalDictionary[directionalHintForRTL] : positionInformation;
  }
  return positionInformation;
}
function _getAlignmentData(positionData, target, boundingRect, coverTarget, alignTargetEdge) {
  if (positionData.isAuto) {
    positionData.alignmentEdge = getClosestEdge(positionData.targetEdge, target, boundingRect);
  }
  positionData.alignTargetEdge = alignTargetEdge;
  return positionData;
}
function getClosestEdge(targetEdge, target, boundingRect) {
  var targetCenter = _getCenterValue(target, targetEdge);
  var boundingCenter = _getCenterValue(boundingRect, targetEdge);
  var _a3 = _getFlankingEdges(targetEdge), positiveEdge = _a3.positiveEdge, negativeEdge = _a3.negativeEdge;
  if (targetCenter <= boundingCenter) {
    return positiveEdge;
  } else {
    return negativeEdge;
  }
}
function _positionElementWithinBounds(elementToPosition, target, bounding, positionData, gap, directionalHintFixed, coverTarget) {
  var estimatedElementPosition = _estimatePosition(elementToPosition, target, positionData, gap, coverTarget);
  if (_isRectangleWithinBounds(estimatedElementPosition, bounding)) {
    return {
      elementRectangle: estimatedElementPosition,
      targetEdge: positionData.targetEdge,
      alignmentEdge: positionData.alignmentEdge
    };
  } else {
    return _adjustFitWithinBounds(estimatedElementPosition, target, bounding, positionData, gap, directionalHintFixed, coverTarget);
  }
}
function _finalizeBeakPosition(elementPosition, positionedBeak, bounds) {
  var targetEdge = elementPosition.targetEdge * -1;
  var actualElement = new Rectangle(0, elementPosition.elementRectangle.width, 0, elementPosition.elementRectangle.height);
  var returnValue = {};
  var returnEdge = _finalizeReturnEdge(elementPosition.elementRectangle, elementPosition.alignmentEdge ? elementPosition.alignmentEdge : _getFlankingEdges(targetEdge).positiveEdge, bounds);
  var beakEdgeDifference = _getRelativeEdgeDifference(elementPosition.elementRectangle, elementPosition.targetRectangle, targetEdge);
  var showBeak = beakEdgeDifference > Math.abs(_getEdgeValue(positionedBeak, targetEdge));
  returnValue[RectangleEdge[targetEdge]] = _getEdgeValue(positionedBeak, targetEdge);
  returnValue[RectangleEdge[returnEdge]] = _getRelativeEdgeDifference(positionedBeak, actualElement, returnEdge);
  return {
    elementPosition: __assign({}, returnValue),
    closestEdge: getClosestEdge(elementPosition.targetEdge, positionedBeak, actualElement),
    targetEdge,
    hideBeak: !showBeak
  };
}
function _positionBeak(beakWidth, elementPosition) {
  var target = elementPosition.targetRectangle;
  var _a3 = _getFlankingEdges(elementPosition.targetEdge), positiveEdge = _a3.positiveEdge, negativeEdge = _a3.negativeEdge;
  var beakTargetPoint = _getCenterValue(target, elementPosition.targetEdge);
  var elementBounds = new Rectangle(beakWidth / 2, elementPosition.elementRectangle.width - beakWidth / 2, beakWidth / 2, elementPosition.elementRectangle.height - beakWidth / 2);
  var beakPosition = new Rectangle(0, beakWidth, 0, beakWidth);
  beakPosition = _moveEdge(beakPosition, elementPosition.targetEdge * -1, -beakWidth / 2);
  beakPosition = _centerEdgeToPoint(beakPosition, elementPosition.targetEdge * -1, beakTargetPoint - _getRelativeRectEdgeValue(positiveEdge, elementPosition.elementRectangle));
  if (!_isEdgeInBounds(beakPosition, elementBounds, positiveEdge)) {
    beakPosition = _alignEdges(beakPosition, elementBounds, positiveEdge);
  } else if (!_isEdgeInBounds(beakPosition, elementBounds, negativeEdge)) {
    beakPosition = _alignEdges(beakPosition, elementBounds, negativeEdge);
  }
  return beakPosition;
}
function _getRectangleFromElement(element) {
  var clientRect = element.getBoundingClientRect();
  return new Rectangle(clientRect.left, clientRect.right, clientRect.top, clientRect.bottom);
}
function _getRectangleFromIRect(rect) {
  return new Rectangle(rect.left, rect.right, rect.top, rect.bottom);
}
function _getTargetRect(bounds, target) {
  var targetRectangle;
  if (target) {
    if (!!target.preventDefault) {
      var ev = target;
      targetRectangle = new Rectangle(ev.clientX, ev.clientX, ev.clientY, ev.clientY);
    } else if (!!target.getBoundingClientRect) {
      targetRectangle = _getRectangleFromElement(target);
    } else {
      var rectOrPoint = target;
      var left = rectOrPoint.left || rectOrPoint.x;
      var top_1 = rectOrPoint.top || rectOrPoint.y;
      var right = rectOrPoint.right || left;
      var bottom = rectOrPoint.bottom || top_1;
      targetRectangle = new Rectangle(left, right, top_1, bottom);
    }
    if (!_isRectangleWithinBounds(targetRectangle, bounds)) {
      var outOfBounds = _getOutOfBoundsEdges(targetRectangle, bounds);
      for (var _i = 0, outOfBounds_1 = outOfBounds; _i < outOfBounds_1.length; _i++) {
        var direction = outOfBounds_1[_i];
        targetRectangle[RectangleEdge[direction]] = bounds[RectangleEdge[direction]];
      }
    }
  } else {
    targetRectangle = new Rectangle(0, 0, 0, 0);
  }
  return targetRectangle;
}
function _getMaxHeightFromTargetRectangle(targetRectangle, targetEdge, gapSpace, bounds, coverTarget) {
  var maxHeight = 0;
  var directionalHint = DirectionalDictionary[targetEdge];
  var target = coverTarget ? directionalHint.targetEdge * -1 : directionalHint.targetEdge;
  if (target === RectangleEdge.top) {
    maxHeight = _getEdgeValue(targetRectangle, directionalHint.targetEdge) - bounds.top - gapSpace;
  } else if (target === RectangleEdge.bottom) {
    maxHeight = bounds.bottom - _getEdgeValue(targetRectangle, directionalHint.targetEdge) - gapSpace;
  } else {
    maxHeight = bounds.bottom - targetRectangle.top - gapSpace;
  }
  return maxHeight > 0 ? maxHeight : bounds.height;
}
function _positionElementRelative(props, elementToPosition, boundingRect, previousPositions) {
  var gap = props.gapSpace ? props.gapSpace : 0;
  var targetRect = _getTargetRect(boundingRect, props.target);
  var positionData = _getAlignmentData(_getPositionData(props.directionalHint, props.directionalHintForRTL, previousPositions), targetRect, boundingRect, props.coverTarget, props.alignTargetEdge);
  var positionedElement = _positionElementWithinBounds(_getRectangleFromElement(elementToPosition), targetRect, boundingRect, positionData, gap, props.directionalHintFixed, props.coverTarget);
  return __assign(__assign({}, positionedElement), { targetRectangle: targetRect });
}
function _finalizePositionData(positionedElement, hostElement, bounds, coverTarget, doNotFinalizeReturnEdge) {
  var finalizedElement = _finalizeElementPosition(positionedElement.elementRectangle, hostElement, positionedElement.targetEdge, bounds, positionedElement.alignmentEdge, coverTarget, doNotFinalizeReturnEdge, positionedElement.forcedInBounds);
  return {
    elementPosition: finalizedElement,
    targetEdge: positionedElement.targetEdge,
    alignmentEdge: positionedElement.alignmentEdge
  };
}
function _positionElement(props, hostElement, elementToPosition, previousPositions) {
  var boundingRect = props.bounds ? _getRectangleFromIRect(props.bounds) : new Rectangle(0, window.innerWidth - getScrollbarWidth(), 0, window.innerHeight);
  var positionedElement = _positionElementRelative(props, elementToPosition, boundingRect, previousPositions);
  return _finalizePositionData(positionedElement, hostElement, boundingRect, props.coverTarget);
}
function _positionCallout(props, hostElement, callout, previousPositions, doNotFinalizeReturnEdge) {
  var beakWidth = props.isBeakVisible ? props.beakWidth || 0 : 0;
  var gap = _calculateActualBeakWidthInPixels(beakWidth) / 2 + (props.gapSpace ? props.gapSpace : 0);
  var positionProps = props;
  positionProps.gapSpace = gap;
  var boundingRect = props.bounds ? _getRectangleFromIRect(props.bounds) : new Rectangle(0, window.innerWidth - getScrollbarWidth(), 0, window.innerHeight);
  var positionedElement = _positionElementRelative(positionProps, callout, boundingRect, previousPositions);
  var beakPositioned = _positionBeak(beakWidth, positionedElement);
  var finalizedBeakPosition = _finalizeBeakPosition(positionedElement, beakPositioned, boundingRect);
  return __assign(__assign({}, _finalizePositionData(positionedElement, hostElement, boundingRect, props.coverTarget, doNotFinalizeReturnEdge)), { beakPosition: finalizedBeakPosition });
}
function _positionCard(props, hostElement, callout, previousPositions) {
  return _positionCallout(props, hostElement, callout, previousPositions, true);
}
function positionElement(props, hostElement, elementToPosition, previousPositions) {
  return _positionElement(props, hostElement, elementToPosition, previousPositions);
}
function positionCallout(props, hostElement, elementToPosition, previousPositions) {
  return _positionCallout(props, hostElement, elementToPosition, previousPositions);
}
function positionCard(props, hostElement, elementToPosition, previousPositions) {
  return _positionCard(props, hostElement, elementToPosition, previousPositions);
}
function getMaxHeight(target, targetEdge, gapSpace, bounds, coverTarget) {
  if (gapSpace === void 0) {
    gapSpace = 0;
  }
  var mouseTarget = target;
  var elementTarget = target;
  var rectOrPointTarget = target;
  var targetRect;
  var boundingRectangle = bounds ? _getRectangleFromIRect(bounds) : new Rectangle(0, window.innerWidth - getScrollbarWidth(), 0, window.innerHeight);
  var left = rectOrPointTarget.left || rectOrPointTarget.x;
  var top = rectOrPointTarget.top || rectOrPointTarget.y;
  var right = rectOrPointTarget.right || left;
  var bottom = rectOrPointTarget.bottom || top;
  if (!!mouseTarget.stopPropagation) {
    targetRect = new Rectangle(mouseTarget.clientX, mouseTarget.clientX, mouseTarget.clientY, mouseTarget.clientY);
  } else if (left !== void 0 && top !== void 0) {
    targetRect = new Rectangle(left, right, top, bottom);
  } else {
    targetRect = _getRectangleFromElement(elementTarget);
  }
  return _getMaxHeightFromTargetRectangle(targetRect, targetEdge, gapSpace, boundingRectangle, coverTarget);
}
function getOppositeEdge(edge) {
  return edge * -1;
}
function _getBoundsFromTargetWindow(target, targetWindow) {
  var segments = void 0;
  if (targetWindow.getWindowSegments) {
    segments = targetWindow.getWindowSegments();
  }
  if (segments === void 0 || segments.length <= 1) {
    return {
      top: 0,
      left: 0,
      right: targetWindow.innerWidth,
      bottom: targetWindow.innerHeight,
      width: targetWindow.innerWidth,
      height: targetWindow.innerHeight
    };
  }
  var x = 0;
  var y = 0;
  if (target !== null && !!target.getBoundingClientRect) {
    var clientRect = target.getBoundingClientRect();
    x = (clientRect.left + clientRect.right) / 2;
    y = (clientRect.top + clientRect.bottom) / 2;
  } else if (target !== null) {
    x = target.left || target.x;
    y = target.top || target.y;
  }
  var bounds = { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 };
  for (var _i = 0, segments_1 = segments; _i < segments_1.length; _i++) {
    var segment = segments_1[_i];
    if (x && segment.left <= x && segment.right >= x && y && segment.top <= y && segment.bottom >= y) {
      bounds = {
        top: segment.top,
        left: segment.left,
        right: segment.right,
        bottom: segment.bottom,
        width: segment.width,
        height: segment.height
      };
    }
  }
  return bounds;
}
function getBoundsFromTargetWindow(target, targetWindow) {
  return _getBoundsFromTargetWindow(target, targetWindow);
}

// node_modules/@fluentui/react/lib/components/Popup/Popup.js
var React2 = __toESM(require_react());
function useScrollbarAsync(props, root) {
  var async = useAsync();
  var _a3 = React2.useState(false), needsVerticalScrollBarState = _a3[0], setNeedsVerticalScrollBar = _a3[1];
  React2.useEffect(function() {
    async.requestAnimationFrame(function() {
      var _a4;
      if (props.style && props.style.overflowY) {
        return;
      }
      var needsVerticalScrollBar = false;
      if (root && root.current && ((_a4 = root.current) === null || _a4 === void 0 ? void 0 : _a4.firstElementChild)) {
        var rootHeight = root.current.clientHeight;
        var firstChildHeight = root.current.firstElementChild.clientHeight;
        if (rootHeight > 0 && firstChildHeight > rootHeight) {
          needsVerticalScrollBar = firstChildHeight - rootHeight > 1;
        }
      }
      if (needsVerticalScrollBarState !== needsVerticalScrollBar) {
        setNeedsVerticalScrollBar(needsVerticalScrollBar);
      }
    });
    return function() {
      return async.dispose();
    };
  });
  return needsVerticalScrollBarState;
}
function defaultFocusRestorer(options) {
  var originalElement = options.originalElement, containsFocus = options.containsFocus;
  if (originalElement && containsFocus && originalElement !== getWindow()) {
    setTimeout(function() {
      var _a3;
      (_a3 = originalElement.focus) === null || _a3 === void 0 ? void 0 : _a3.call(originalElement);
    }, 0);
  }
}
function useRestoreFocus(props, root) {
  var _a3 = props.onRestoreFocus, onRestoreFocus = _a3 === void 0 ? defaultFocusRestorer : _a3;
  var originalFocusedElement = React2.useRef();
  var containsFocus = React2.useRef(false);
  React2.useEffect(function() {
    originalFocusedElement.current = getDocument().activeElement;
    if (doesElementContainFocus(root.current)) {
      containsFocus.current = true;
    }
    return function() {
      var _a4;
      onRestoreFocus === null || onRestoreFocus === void 0 ? void 0 : onRestoreFocus({
        originalElement: originalFocusedElement.current,
        containsFocus: containsFocus.current,
        documentContainsFocus: ((_a4 = getDocument()) === null || _a4 === void 0 ? void 0 : _a4.hasFocus()) || false
      });
      originalFocusedElement.current = void 0;
    };
  }, []);
  useOnEvent(root, "focus", React2.useCallback(function() {
    containsFocus.current = true;
  }, []), true);
  useOnEvent(root, "blur", React2.useCallback(function(ev) {
    if (root.current && ev.relatedTarget && !root.current.contains(ev.relatedTarget)) {
      containsFocus.current = false;
    }
  }, []), true);
}
function useHideSiblingNodes(props, root) {
  var shouldHideSiblings = String(props["aria-modal"]).toLowerCase() === "true" && props.enableAriaHiddenSiblings;
  React2.useEffect(function() {
    if (!(shouldHideSiblings && root.current)) {
      return;
    }
    var unmodalize = modalize(root.current);
    return unmodalize;
  }, [root, shouldHideSiblings]);
}
var Popup = React2.forwardRef(function(propsWithoutDefaults, forwardedRef) {
  var props = getPropsWithDefaults({ shouldRestoreFocus: true, enableAriaHiddenSiblings: true }, propsWithoutDefaults);
  var root = React2.useRef();
  var mergedRootRef = useMergedRefs(root, forwardedRef);
  useHideSiblingNodes(props, root);
  useRestoreFocus(props, root);
  var role = props.role, className = props.className, ariaLabel = props.ariaLabel, ariaLabelledBy = props.ariaLabelledBy, ariaDescribedBy = props.ariaDescribedBy, style = props.style, children = props.children, onDismiss = props.onDismiss;
  var needsVerticalScrollBar = useScrollbarAsync(props, root);
  var onKeyDown = React2.useCallback(function(ev) {
    switch (ev.which) {
      case KeyCodes.escape:
        if (onDismiss) {
          onDismiss(ev);
          ev.preventDefault();
          ev.stopPropagation();
        }
        break;
    }
  }, [onDismiss]);
  var win = useWindow();
  useOnEvent(win, "keydown", onKeyDown);
  return React2.createElement("div", __assign({ ref: mergedRootRef }, getNativeProps(props, divProperties), { className, role, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, "aria-describedby": ariaDescribedBy, onKeyDown, style: __assign({ overflowY: needsVerticalScrollBar ? "scroll" : void 0, outline: "none" }, style) }), children);
});
Popup.displayName = "Popup";

// node_modules/@fluentui/react/lib/components/Callout/CalloutContent.base.js
var _a2;
var COMPONENT_NAME = "CalloutContentBase";
var ANIMATIONS = (_a2 = {}, _a2[RectangleEdge.top] = AnimationClassNames.slideUpIn10, _a2[RectangleEdge.bottom] = AnimationClassNames.slideDownIn10, _a2[RectangleEdge.left] = AnimationClassNames.slideLeftIn10, _a2[RectangleEdge.right] = AnimationClassNames.slideRightIn10, _a2);
var BEAK_ORIGIN_POSITION = { top: 0, left: 0 };
var OFF_SCREEN_STYLE = {
  opacity: 0,
  filter: "opacity(0)",
  pointerEvents: "none"
};
var ARIA_ROLE_ATTRIBUTES = ["role", "aria-roledescription"];
var DEFAULT_PROPS = {
  preventDismissOnLostFocus: false,
  preventDismissOnScroll: false,
  preventDismissOnResize: false,
  isBeakVisible: true,
  beakWidth: 16,
  gapSpace: 0,
  minPagePadding: 8,
  directionalHint: DirectionalHint.bottomAutoEdge
};
var getClassNames = classNamesFunction({
  disableCaching: true
  // disabling caching because stylesProp.position mutates often
});
function useBounds(_a3, targetRef, targetWindow) {
  var bounds = _a3.bounds, _b = _a3.minPagePadding, minPagePadding = _b === void 0 ? DEFAULT_PROPS.minPagePadding : _b, target = _a3.target;
  var _c = React3.useState(false), targetWindowResized = _c[0], setTargetWindowResized = _c[1];
  var cachedBounds = React3.useRef();
  var getBounds = React3.useCallback(function() {
    if (!cachedBounds.current || targetWindowResized) {
      var currentBounds = typeof bounds === "function" ? targetWindow ? bounds(target, targetWindow) : void 0 : bounds;
      if (!currentBounds && targetWindow) {
        currentBounds = getBoundsFromTargetWindow(targetRef.current, targetWindow);
        currentBounds = {
          top: currentBounds.top + minPagePadding,
          left: currentBounds.left + minPagePadding,
          right: currentBounds.right - minPagePadding,
          bottom: currentBounds.bottom - minPagePadding,
          width: currentBounds.width - minPagePadding * 2,
          height: currentBounds.height - minPagePadding * 2
        };
      }
      cachedBounds.current = currentBounds;
      targetWindowResized && setTargetWindowResized(false);
    }
    return cachedBounds.current;
  }, [bounds, minPagePadding, target, targetRef, targetWindow, targetWindowResized]);
  var async = useAsync();
  useOnEvent(targetWindow, "resize", async.debounce(function() {
    setTargetWindowResized(true);
  }, 500, { leading: true }));
  return getBounds;
}
function useMaxHeight(_a3, getBounds, positions) {
  var _b;
  var calloutMaxHeight = _a3.calloutMaxHeight, finalHeight = _a3.finalHeight, directionalHint = _a3.directionalHint, directionalHintFixed = _a3.directionalHintFixed, hidden = _a3.hidden;
  var _c = React3.useState(), maxHeight = _c[0], setMaxHeight = _c[1];
  var _d = (_b = positions === null || positions === void 0 ? void 0 : positions.elementPosition) !== null && _b !== void 0 ? _b : {}, top = _d.top, bottom = _d.bottom;
  React3.useEffect(function() {
    var _a4;
    var _b2 = (_a4 = getBounds()) !== null && _a4 !== void 0 ? _a4 : {}, topBounds = _b2.top, bottomBounds = _b2.bottom;
    if (!calloutMaxHeight && !hidden) {
      if (typeof top === "number" && bottomBounds) {
        setMaxHeight(bottomBounds - top);
      } else if (typeof bottom === "number" && typeof topBounds === "number" && bottomBounds) {
        setMaxHeight(bottomBounds - topBounds - bottom);
      }
    } else if (calloutMaxHeight) {
      setMaxHeight(calloutMaxHeight);
    } else {
      setMaxHeight(void 0);
    }
  }, [bottom, calloutMaxHeight, finalHeight, directionalHint, directionalHintFixed, getBounds, hidden, positions, top]);
  return maxHeight;
}
function usePositions(props, hostElement, calloutElement, targetRef, getBounds) {
  var _a3 = React3.useState(), positions = _a3[0], setPositions = _a3[1];
  var positionAttempts = React3.useRef(0);
  var previousTarget = React3.useRef();
  var async = useAsync();
  var hidden = props.hidden, target = props.target, finalHeight = props.finalHeight, calloutMaxHeight = props.calloutMaxHeight, onPositioned = props.onPositioned, directionalHint = props.directionalHint;
  React3.useEffect(function() {
    if (!hidden) {
      var timerId_1 = async.requestAnimationFrame(function() {
        var _a4, _b;
        if (hostElement.current && calloutElement) {
          var currentProps = __assign(__assign({}, props), { target: targetRef.current, bounds: getBounds() });
          var dupeCalloutElement = calloutElement.cloneNode(true);
          dupeCalloutElement.style.maxHeight = calloutMaxHeight ? "" + calloutMaxHeight : "";
          dupeCalloutElement.style.visibility = "hidden";
          (_a4 = calloutElement.parentElement) === null || _a4 === void 0 ? void 0 : _a4.appendChild(dupeCalloutElement);
          var previousPositions = previousTarget.current === target ? positions : void 0;
          var newPositions = finalHeight ? positionCard(currentProps, hostElement.current, dupeCalloutElement, previousPositions) : positionCallout(currentProps, hostElement.current, dupeCalloutElement, previousPositions);
          (_b = calloutElement.parentElement) === null || _b === void 0 ? void 0 : _b.removeChild(dupeCalloutElement);
          if (!positions && newPositions || positions && newPositions && !arePositionsEqual(positions, newPositions) && positionAttempts.current < 5) {
            positionAttempts.current++;
            setPositions(newPositions);
          } else if (positionAttempts.current > 0) {
            positionAttempts.current = 0;
            onPositioned === null || onPositioned === void 0 ? void 0 : onPositioned(positions);
          }
        }
      }, calloutElement);
      previousTarget.current = target;
      return function() {
        async.cancelAnimationFrame(timerId_1);
        previousTarget.current = void 0;
      };
    } else {
      setPositions(void 0);
      positionAttempts.current = 0;
    }
  }, [
    hidden,
    directionalHint,
    async,
    calloutElement,
    calloutMaxHeight,
    hostElement,
    targetRef,
    finalHeight,
    getBounds,
    onPositioned,
    positions,
    props,
    target
  ]);
  return positions;
}
function useAutoFocus(_a3, positions, calloutElement) {
  var hidden = _a3.hidden, setInitialFocus = _a3.setInitialFocus;
  var async = useAsync();
  var hasPositions = !!positions;
  React3.useEffect(function() {
    if (!hidden && setInitialFocus && hasPositions && calloutElement) {
      var timerId_2 = async.requestAnimationFrame(function() {
        return focusFirstChild(calloutElement);
      }, calloutElement);
      return function() {
        return async.cancelAnimationFrame(timerId_2);
      };
    }
  }, [hidden, hasPositions, async, calloutElement, setInitialFocus]);
}
function useDismissHandlers(_a3, positions, hostElement, targetRef, targetWindow) {
  var hidden = _a3.hidden, onDismiss = _a3.onDismiss, preventDismissOnScroll = _a3.preventDismissOnScroll, preventDismissOnResize = _a3.preventDismissOnResize, preventDismissOnLostFocus = _a3.preventDismissOnLostFocus, dismissOnTargetClick = _a3.dismissOnTargetClick, shouldDismissOnWindowFocus = _a3.shouldDismissOnWindowFocus, preventDismissOnEvent = _a3.preventDismissOnEvent;
  var isMouseDownOnPopup = React3.useRef(false);
  var async = useAsync();
  var mouseDownHandlers = useConst([
    function() {
      isMouseDownOnPopup.current = true;
    },
    function() {
      isMouseDownOnPopup.current = false;
    }
  ]);
  var positionsExists = !!positions;
  React3.useEffect(function() {
    var dismissOnScroll = function(ev) {
      if (positionsExists && !preventDismissOnScroll) {
        dismissOnClickOrScroll(ev);
      }
    };
    var dismissOnResize = function(ev) {
      if (!preventDismissOnResize && !(preventDismissOnEvent && preventDismissOnEvent(ev))) {
        onDismiss === null || onDismiss === void 0 ? void 0 : onDismiss(ev);
      }
    };
    var dismissOnLostFocus = function(ev) {
      if (!preventDismissOnLostFocus) {
        dismissOnClickOrScroll(ev);
      }
    };
    var dismissOnClickOrScroll = function(ev) {
      var eventPaths = ev.composedPath ? ev.composedPath() : [];
      var target = eventPaths.length > 0 ? eventPaths[0] : ev.target;
      var isEventTargetOutsideCallout = hostElement.current && !elementContains(hostElement.current, target);
      if (isEventTargetOutsideCallout && isMouseDownOnPopup.current) {
        isMouseDownOnPopup.current = false;
        return;
      }
      if (!targetRef.current && isEventTargetOutsideCallout || ev.target !== targetWindow && isEventTargetOutsideCallout && (!targetRef.current || "stopPropagation" in targetRef.current || dismissOnTargetClick || target !== targetRef.current && !elementContains(targetRef.current, target))) {
        if (preventDismissOnEvent && preventDismissOnEvent(ev)) {
          return;
        }
        onDismiss === null || onDismiss === void 0 ? void 0 : onDismiss(ev);
      }
    };
    var dismissOnTargetWindowBlur = function(ev) {
      if (!shouldDismissOnWindowFocus) {
        return;
      }
      if ((preventDismissOnEvent && !preventDismissOnEvent(ev) || !preventDismissOnEvent && !preventDismissOnLostFocus) && !(targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.document.hasFocus()) && ev.relatedTarget === null) {
        onDismiss === null || onDismiss === void 0 ? void 0 : onDismiss(ev);
      }
    };
    var disposablesPromise = new Promise(function(resolve) {
      async.setTimeout(function() {
        if (!hidden && targetWindow) {
          var disposables_1 = [
            on(targetWindow, "scroll", dismissOnScroll, true),
            on(targetWindow, "resize", dismissOnResize, true),
            on(targetWindow.document.documentElement, "focus", dismissOnLostFocus, true),
            on(targetWindow.document.documentElement, "click", dismissOnLostFocus, true),
            on(targetWindow, "blur", dismissOnTargetWindowBlur, true)
          ];
          resolve(function() {
            disposables_1.forEach(function(dispose) {
              return dispose();
            });
          });
        }
      }, 0);
    });
    return function() {
      disposablesPromise.then(function(dispose) {
        return dispose();
      });
    };
  }, [
    hidden,
    async,
    hostElement,
    targetRef,
    targetWindow,
    onDismiss,
    shouldDismissOnWindowFocus,
    dismissOnTargetClick,
    preventDismissOnLostFocus,
    preventDismissOnResize,
    preventDismissOnScroll,
    positionsExists,
    preventDismissOnEvent
  ]);
  return mouseDownHandlers;
}
var CalloutContentBase = React3.memo(React3.forwardRef(function(propsWithoutDefaults, forwardedRef) {
  var props = getPropsWithDefaults(DEFAULT_PROPS, propsWithoutDefaults);
  var styles = props.styles, style = props.style, ariaLabel = props.ariaLabel, ariaDescribedBy = props.ariaDescribedBy, ariaLabelledBy = props.ariaLabelledBy, className = props.className, isBeakVisible = props.isBeakVisible, children = props.children, beakWidth = props.beakWidth, calloutWidth = props.calloutWidth, calloutMaxWidth = props.calloutMaxWidth, calloutMinWidth = props.calloutMinWidth, doNotLayer = props.doNotLayer, finalHeight = props.finalHeight, _a3 = props.hideOverflow, hideOverflow = _a3 === void 0 ? !!finalHeight : _a3, backgroundColor = props.backgroundColor, calloutMaxHeight = props.calloutMaxHeight, onScroll = props.onScroll, _b = props.shouldRestoreFocus, shouldRestoreFocus = _b === void 0 ? true : _b, target = props.target, hidden = props.hidden, onLayerMounted = props.onLayerMounted, popupProps = props.popupProps;
  var hostElement = React3.useRef(null);
  var _c = React3.useState(null), calloutElement = _c[0], setCalloutElement = _c[1];
  var calloutCallback = React3.useCallback(function(calloutEl) {
    setCalloutElement(calloutEl);
  }, []);
  var rootRef = useMergedRefs(hostElement, forwardedRef);
  var _d = useTarget(props.target, {
    current: calloutElement
  }), targetRef = _d[0], targetWindow = _d[1];
  var getBounds = useBounds(props, targetRef, targetWindow);
  var positions = usePositions(props, hostElement, calloutElement, targetRef, getBounds);
  var maxHeight = useMaxHeight(props, getBounds, positions);
  var _e = useDismissHandlers(props, positions, hostElement, targetRef, targetWindow), mouseDownOnPopup = _e[0], mouseUpOnPopup = _e[1];
  var isForcedInBounds = (positions === null || positions === void 0 ? void 0 : positions.elementPosition.top) && (positions === null || positions === void 0 ? void 0 : positions.elementPosition.bottom);
  var cssPositions = __assign(__assign({}, positions === null || positions === void 0 ? void 0 : positions.elementPosition), { maxHeight });
  if (isForcedInBounds) {
    cssPositions.bottom = void 0;
  }
  useAutoFocus(props, positions, calloutElement);
  React3.useEffect(function() {
    if (!hidden) {
      onLayerMounted === null || onLayerMounted === void 0 ? void 0 : onLayerMounted();
    }
  }, [hidden]);
  if (!targetWindow) {
    return null;
  }
  var overflowYHidden = hideOverflow;
  var beakVisible = isBeakVisible && !!target;
  var classNames = getClassNames(styles, {
    theme: props.theme,
    className,
    overflowYHidden,
    calloutWidth,
    positions,
    beakWidth,
    backgroundColor,
    calloutMaxWidth,
    calloutMinWidth,
    doNotLayer
  });
  var overflowStyle = __assign(__assign({ maxHeight: calloutMaxHeight ? calloutMaxHeight : "100%" }, style), overflowYHidden && { overflowY: "hidden" });
  var visibilityStyle = props.hidden ? { visibility: "hidden" } : void 0;
  return React3.createElement(
    "div",
    { ref: rootRef, className: classNames.container, style: visibilityStyle },
    React3.createElement(
      "div",
      __assign({}, getNativeProps(props, divProperties, ARIA_ROLE_ATTRIBUTES), {
        className: css(classNames.root, positions && positions.targetEdge && ANIMATIONS[positions.targetEdge]),
        style: positions ? __assign({}, cssPositions) : OFF_SCREEN_STYLE,
        // Safari and Firefox on Mac OS requires this to back-stop click events so focus remains in the Callout.
        // See https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#Clicking_and_focus
        tabIndex: -1,
        ref: calloutCallback
      }),
      beakVisible && React3.createElement("div", { className: classNames.beak, style: getBeakPosition(positions) }),
      beakVisible && React3.createElement("div", { className: classNames.beakCurtain }),
      React3.createElement(
        Popup,
        __assign({
          // don't use getNativeElementProps for role and roledescription because it will also
          // pass through data-* props (resulting in them being used in two places)
          role: props.role,
          "aria-roledescription": props["aria-roledescription"],
          ariaDescribedBy,
          ariaLabel,
          ariaLabelledBy,
          className: classNames.calloutMain,
          onDismiss: props.onDismiss,
          onMouseDown: mouseDownOnPopup,
          onMouseUp: mouseUpOnPopup,
          onRestoreFocus: props.onRestoreFocus,
          onScroll,
          shouldRestoreFocus,
          style: overflowStyle
        }, popupProps),
        children
      )
    )
  );
}), function(previousProps, nextProps) {
  if (!nextProps.shouldUpdateWhenHidden && previousProps.hidden && nextProps.hidden) {
    return true;
  }
  return shallowCompare(previousProps, nextProps);
});
function getBeakPosition(positions) {
  var _a3, _b;
  var beakPositionStyle = __assign(__assign({}, (_a3 = positions === null || positions === void 0 ? void 0 : positions.beakPosition) === null || _a3 === void 0 ? void 0 : _a3.elementPosition), { display: ((_b = positions === null || positions === void 0 ? void 0 : positions.beakPosition) === null || _b === void 0 ? void 0 : _b.hideBeak) ? "none" : void 0 });
  if (!beakPositionStyle.top && !beakPositionStyle.bottom && !beakPositionStyle.left && !beakPositionStyle.right) {
    beakPositionStyle.left = BEAK_ORIGIN_POSITION.left;
    beakPositionStyle.top = BEAK_ORIGIN_POSITION.top;
  }
  return beakPositionStyle;
}
function arePositionsEqual(prevElementPositions, newElementPosition) {
  return comparePositions(prevElementPositions.elementPosition, newElementPosition.elementPosition) && comparePositions(prevElementPositions.beakPosition.elementPosition, newElementPosition.beakPosition.elementPosition);
}
function comparePositions(prevElementPositions, newElementPositions) {
  for (var key in newElementPositions) {
    if (newElementPositions.hasOwnProperty(key)) {
      var oldPositionEdge = prevElementPositions[key];
      var newPositionEdge = newElementPositions[key];
      if (oldPositionEdge !== void 0 && newPositionEdge !== void 0) {
        if (oldPositionEdge.toFixed(2) !== newPositionEdge.toFixed(2)) {
          return false;
        }
      } else {
        return false;
      }
    }
  }
  return true;
}
CalloutContentBase.displayName = COMPONENT_NAME;

// node_modules/@fluentui/react/lib/components/Callout/CalloutContent.styles.js
function getBeakStyle(beakWidth) {
  return {
    height: beakWidth,
    width: beakWidth
  };
}
var GlobalClassNames = {
  container: "ms-Callout-container",
  root: "ms-Callout",
  beak: "ms-Callout-beak",
  beakCurtain: "ms-Callout-beakCurtain",
  calloutMain: "ms-Callout-main"
};
var getStyles = function(props) {
  var _a3;
  var theme = props.theme, className = props.className, overflowYHidden = props.overflowYHidden, calloutWidth = props.calloutWidth, beakWidth = props.beakWidth, backgroundColor = props.backgroundColor, calloutMaxWidth = props.calloutMaxWidth, calloutMinWidth = props.calloutMinWidth, doNotLayer = props.doNotLayer;
  var classNames = getGlobalClassNames(GlobalClassNames, theme);
  var semanticColors = theme.semanticColors, effects = theme.effects;
  return {
    container: [
      classNames.container,
      {
        position: "relative"
      }
    ],
    root: [
      classNames.root,
      theme.fonts.medium,
      {
        position: "absolute",
        display: "flex",
        zIndex: doNotLayer ? ZIndexes.Layer : void 0,
        boxSizing: "border-box",
        borderRadius: effects.roundedCorner2,
        boxShadow: effects.elevation16,
        selectors: (_a3 = {}, _a3[HighContrastSelector] = {
          borderWidth: 1,
          borderStyle: "solid",
          borderColor: "WindowText"
        }, _a3)
      },
      focusClear(),
      className,
      !!calloutWidth && { width: calloutWidth },
      !!calloutMaxWidth && { maxWidth: calloutMaxWidth },
      !!calloutMinWidth && { minWidth: calloutMinWidth }
    ],
    beak: [
      classNames.beak,
      {
        position: "absolute",
        backgroundColor: semanticColors.menuBackground,
        boxShadow: "inherit",
        border: "inherit",
        boxSizing: "border-box",
        transform: "rotate(45deg)"
      },
      getBeakStyle(beakWidth),
      backgroundColor && {
        backgroundColor
      }
    ],
    beakCurtain: [
      classNames.beakCurtain,
      {
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        backgroundColor: semanticColors.menuBackground,
        borderRadius: effects.roundedCorner2
      }
    ],
    calloutMain: [
      classNames.calloutMain,
      {
        backgroundColor: semanticColors.menuBackground,
        overflowX: "hidden",
        overflowY: "auto",
        position: "relative",
        width: "100%",
        borderRadius: effects.roundedCorner2
      },
      overflowYHidden && {
        overflowY: "hidden"
      },
      backgroundColor && {
        backgroundColor
      }
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Callout/CalloutContent.js
var CalloutContent = styled(CalloutContentBase, getStyles, void 0, {
  scope: "CalloutContent"
});

// node_modules/@fluentui/react-portal-compat-context/lib/PortalCompatContext.js
var React4 = __toESM(require_react());
var PortalCompatContext = React4.createContext(void 0);
var portalCompatContextDefaultValue = () => () => void 0;
var PortalCompatContextProvider = PortalCompatContext.Provider;
function usePortalCompat() {
  var _React_useContext;
  return (_React_useContext = React4.useContext(PortalCompatContext)) !== null && _React_useContext !== void 0 ? _React_useContext : portalCompatContextDefaultValue;
}

// node_modules/@fluentui/react/lib/components/Layer/Layer.base.js
var React6 = __toESM(require_react());
var ReactDOM = __toESM(require_react_dom());

// node_modules/@fluentui/react/lib/components/Fabric/Fabric.base.js
var React5 = __toESM(require_react());
var getClassNames2 = classNamesFunction();
var getFabricTheme = memoizeFunction(function(theme, isRTL) {
  return createTheme(__assign(__assign({}, theme), { rtl: isRTL }));
});
var getDir = function(_a3) {
  var theme = _a3.theme, dir = _a3.dir;
  var contextDir = getRTL(theme) ? "rtl" : "ltr";
  var pageDir = getRTL() ? "rtl" : "ltr";
  var componentDir = dir ? dir : contextDir;
  return {
    // If Fabric dir !== contextDir
    // Or If contextDir !== pageDir
    // Then we need to set dir of the Fabric root
    rootDir: componentDir !== contextDir || componentDir !== pageDir ? componentDir : dir,
    // If dir !== contextDir || pageDir
    // then set contextual theme around content
    needsTheme: componentDir !== contextDir
  };
};
var FabricBase = React5.forwardRef(function(props, ref) {
  var className = props.className, theme = props.theme, applyTheme = props.applyTheme, applyThemeToBody = props.applyThemeToBody, styles = props.styles;
  var classNames = getClassNames2(styles, {
    theme,
    applyTheme,
    className
  });
  var rootElement = React5.useRef(null);
  useApplyThemeToBody(applyThemeToBody, classNames, rootElement);
  return React5.createElement(React5.Fragment, null, useRenderedContent(props, classNames, rootElement, ref));
});
FabricBase.displayName = "FabricBase";
function useRenderedContent(props, _a3, rootElement, ref) {
  var root = _a3.root;
  var _b = props.as, Root = _b === void 0 ? "div" : _b, dir = props.dir, theme = props.theme;
  var divProps = getNativeProps(props, divProperties, ["dir"]);
  var _c = getDir(props), rootDir = _c.rootDir, needsTheme = _c.needsTheme;
  var renderedContent = React5.createElement(
    FocusRectsProvider,
    { providerRef: rootElement },
    React5.createElement(Root, __assign({ dir: rootDir }, divProps, { className: root, ref: useMergedRefs(rootElement, ref) }))
  );
  if (needsTheme) {
    renderedContent = // eslint-disable-next-line deprecation/deprecation
    React5.createElement(Customizer, { settings: { theme: getFabricTheme(theme, dir === "rtl") } }, renderedContent);
  }
  return renderedContent;
}
function useApplyThemeToBody(applyThemeToBody, _a3, rootElement) {
  var bodyThemed = _a3.bodyThemed;
  React5.useEffect(function() {
    if (applyThemeToBody) {
      var currentDoc_1 = getDocument(rootElement.current);
      if (currentDoc_1) {
        currentDoc_1.body.classList.add(bodyThemed);
        return function() {
          currentDoc_1.body.classList.remove(bodyThemed);
        };
      }
    }
  }, [bodyThemed, applyThemeToBody, rootElement]);
  return rootElement;
}

// node_modules/@fluentui/react/lib/components/Fabric/Fabric.styles.js
var inheritFont = { fontFamily: "inherit" };
var GlobalClassNames2 = {
  root: "ms-Fabric",
  bodyThemed: "ms-Fabric-bodyThemed"
};
var getStyles2 = function(props) {
  var applyTheme = props.applyTheme, className = props.className, preventBlanketFontInheritance = props.preventBlanketFontInheritance, theme = props.theme;
  var classNames = getGlobalClassNames(GlobalClassNames2, theme);
  return {
    root: [
      classNames.root,
      theme.fonts.medium,
      {
        color: theme.palette.neutralPrimary
      },
      !preventBlanketFontInheritance && {
        "& button": inheritFont,
        "& input": inheritFont,
        "& textarea": inheritFont
      },
      // apply theme to only if applyTheme is true
      applyTheme && {
        color: theme.semanticColors.bodyText,
        backgroundColor: theme.semanticColors.bodyBackground
      },
      className
    ],
    bodyThemed: [
      {
        backgroundColor: theme.semanticColors.bodyBackground
      }
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Fabric/Fabric.js
var Fabric = styled(FabricBase, getStyles2, void 0, {
  scope: "Fabric"
});

// node_modules/@fluentui/react/lib/components/Layer/Layer.notification.js
var _layersByHostId = {};
var _layerHostsById = {};
var defaultHostId = "fluent-default-layer-host";
var _defaultHostSelector = "#" + defaultHostId;
function registerLayer(hostId, callback) {
  if (!_layersByHostId[hostId]) {
    _layersByHostId[hostId] = [];
  }
  _layersByHostId[hostId].push(callback);
  var layerHosts = _layerHostsById[hostId];
  if (layerHosts) {
    for (var _i = 0, layerHosts_1 = layerHosts; _i < layerHosts_1.length; _i++) {
      var layerHost = layerHosts_1[_i];
      layerHost.notifyLayersChanged();
    }
  }
}
function unregisterLayer(hostId, callback) {
  var layers = _layersByHostId[hostId];
  if (layers) {
    var idx = layers.indexOf(callback);
    if (idx >= 0) {
      layers.splice(idx, 1);
      if (layers.length === 0) {
        delete _layersByHostId[hostId];
      }
    }
  }
  var layerHosts = _layerHostsById[hostId];
  if (layerHosts) {
    for (var _i = 0, layerHosts_2 = layerHosts; _i < layerHosts_2.length; _i++) {
      var layerHost = layerHosts_2[_i];
      layerHost.notifyLayersChanged();
    }
  }
}
function getLayerCount(hostId) {
  var layers = _layerHostsById[hostId];
  return layers ? layers.length : 0;
}
function getLayerHost(hostId) {
  var layerHosts = _layerHostsById[hostId];
  return layerHosts && layerHosts[0] || void 0;
}
function registerLayerHost(hostId, layerHost) {
  var layerHosts = _layerHostsById[hostId] || (_layerHostsById[hostId] = []);
  layerHosts.unshift(layerHost);
}
function unregisterLayerHost(hostId, layerHost) {
  var layerHosts = _layerHostsById[hostId];
  if (layerHosts) {
    var idx = layerHosts.indexOf(layerHost);
    if (idx >= 0) {
      layerHosts.splice(idx, 1);
    }
    if (layerHosts.length === 0) {
      delete _layerHostsById[hostId];
    }
  }
}
function createDefaultLayerHost(doc) {
  var host = doc.createElement("div");
  host.setAttribute("id", defaultHostId);
  host.style.cssText = "position:fixed;z-index:1000000";
  doc === null || doc === void 0 ? void 0 : doc.body.appendChild(host);
  return host;
}
function cleanupDefaultLayerHost(doc) {
  var host = doc.querySelector("#" + defaultHostId);
  if (host) {
    doc.removeChild(host);
  }
}
function notifyHostChanged(id) {
  if (_layersByHostId[id]) {
    _layersByHostId[id].forEach(function(callback) {
      return callback();
    });
  }
}
function setDefaultTarget(selector) {
  _defaultHostSelector = selector;
}
function getDefaultTarget() {
  return _defaultHostSelector;
}

// node_modules/@fluentui/react/lib/components/Layer/Layer.base.js
var getClassNames3 = classNamesFunction();
var LayerBase = React6.forwardRef(function(props, ref) {
  var registerPortalEl = usePortalCompat();
  var rootRef = React6.useRef(null);
  var mergedRef = useMergedRefs(rootRef, ref);
  var layerRef = React6.useRef();
  var fabricElementRef = React6.useRef(null);
  var _a3 = React6.useState(false), needRaiseLayerMount = _a3[0], setNeedRaiseLayerMount = _a3[1];
  var children = props.children, className = props.className, eventBubblingEnabled = props.eventBubblingEnabled, fabricProps = props.fabricProps, hostId = props.hostId, insertFirst = props.insertFirst, _b = props.onLayerDidMount, onLayerDidMount = _b === void 0 ? function() {
    return void 0;
  } : _b, _c = props.onLayerMounted, onLayerMounted = _c === void 0 ? function() {
    return void 0;
  } : _c, onLayerWillUnmount = props.onLayerWillUnmount, styles = props.styles, theme = props.theme;
  var fabricRef = useMergedRefs(fabricElementRef, fabricProps === null || fabricProps === void 0 ? void 0 : fabricProps.ref);
  var classNames = getClassNames3(styles, {
    theme,
    className,
    isNotHost: !hostId
  });
  var getHost = function(doc) {
    var _a4, _b2;
    if (hostId) {
      var layerHost = getLayerHost(hostId);
      if (layerHost) {
        return (_a4 = layerHost.rootRef.current) !== null && _a4 !== void 0 ? _a4 : null;
      }
      return (_b2 = doc.getElementById(hostId)) !== null && _b2 !== void 0 ? _b2 : null;
    } else {
      var defaultHostSelector = getDefaultTarget();
      var host = defaultHostSelector ? doc.querySelector(defaultHostSelector) : null;
      if (!host) {
        host = createDefaultLayerHost(doc);
      }
      return host;
    }
  };
  var removeLayerElement = function() {
    onLayerWillUnmount === null || onLayerWillUnmount === void 0 ? void 0 : onLayerWillUnmount();
    var elem = layerRef.current;
    layerRef.current = void 0;
    if (elem && elem.parentNode) {
      elem.parentNode.removeChild(elem);
    }
  };
  var createLayerElement = function() {
    var _a4;
    var doc = getDocument(rootRef.current);
    if (!doc) {
      return;
    }
    var host = getHost(doc);
    if (!host) {
      return;
    }
    removeLayerElement();
    var el = ((_a4 = host.ownerDocument) !== null && _a4 !== void 0 ? _a4 : doc).createElement("div");
    el.className = classNames.root;
    setPortalAttribute(el);
    setVirtualParent(el, rootRef.current);
    insertFirst ? host.insertBefore(el, host.firstChild) : host.appendChild(el);
    layerRef.current = el;
    setNeedRaiseLayerMount(true);
  };
  useIsomorphicLayoutEffect(function() {
    createLayerElement();
    if (hostId) {
      registerLayer(hostId, createLayerElement);
    }
    var unregisterPortalEl = layerRef.current ? registerPortalEl(layerRef.current) : void 0;
    return function() {
      if (unregisterPortalEl) {
        unregisterPortalEl();
      }
      removeLayerElement();
      if (hostId) {
        unregisterLayer(hostId, createLayerElement);
      }
    };
  }, [hostId]);
  React6.useEffect(function() {
    if (layerRef.current && needRaiseLayerMount) {
      onLayerMounted === null || onLayerMounted === void 0 ? void 0 : onLayerMounted();
      onLayerDidMount === null || onLayerDidMount === void 0 ? void 0 : onLayerDidMount();
      setNeedRaiseLayerMount(false);
    }
  }, [needRaiseLayerMount, onLayerMounted, onLayerDidMount]);
  useDebugWarnings(props);
  return React6.createElement("span", { className: "ms-layer", ref: mergedRef }, layerRef.current && ReactDOM.createPortal(React6.createElement(
    FocusRectsProvider,
    { layerRoot: true, providerRef: fabricRef },
    React6.createElement(Fabric, __assign({}, !eventBubblingEnabled && getFilteredEvents(), fabricProps, { className: css(classNames.content, fabricProps === null || fabricProps === void 0 ? void 0 : fabricProps.className), ref: fabricRef }), children)
  ), layerRef.current));
});
LayerBase.displayName = "LayerBase";
var filteredEventProps;
var onFilterEvent = function(ev) {
  if (ev.eventPhase === Event.BUBBLING_PHASE && ev.type !== "mouseenter" && ev.type !== "mouseleave" && ev.type !== "touchstart" && ev.type !== "touchend") {
    ev.stopPropagation();
  }
};
function getFilteredEvents() {
  if (!filteredEventProps) {
    filteredEventProps = {};
    [
      "onClick",
      "onContextMenu",
      "onDoubleClick",
      "onDrag",
      "onDragEnd",
      "onDragEnter",
      "onDragExit",
      "onDragLeave",
      "onDragOver",
      "onDragStart",
      "onDrop",
      "onMouseDown",
      "onMouseEnter",
      "onMouseLeave",
      "onMouseMove",
      "onMouseOver",
      "onMouseOut",
      "onMouseUp",
      "onTouchMove",
      "onTouchStart",
      "onTouchCancel",
      "onTouchEnd",
      "onKeyDown",
      "onKeyPress",
      "onKeyUp",
      "onFocus",
      "onBlur",
      "onChange",
      "onInput",
      "onInvalid",
      "onSubmit"
    ].forEach(function(name) {
      return filteredEventProps[name] = onFilterEvent;
    });
  }
  return filteredEventProps;
}
function useDebugWarnings(props) {
  if (true) {
    useWarnings({
      name: "Layer",
      props,
      deprecations: { onLayerMounted: "onLayerDidMount" }
    });
  }
}

// node_modules/@fluentui/react/lib/components/Layer/Layer.styles.js
var GlobalClassNames3 = {
  root: "ms-Layer",
  rootNoHost: "ms-Layer--fixed",
  content: "ms-Layer-content"
};
var getStyles3 = function(props) {
  var className = props.className, isNotHost = props.isNotHost, theme = props.theme;
  var classNames = getGlobalClassNames(GlobalClassNames3, theme);
  return {
    root: [
      classNames.root,
      theme.fonts.medium,
      isNotHost && [
        classNames.rootNoHost,
        {
          position: "fixed",
          zIndex: ZIndexes.Layer,
          top: 0,
          left: 0,
          bottom: 0,
          right: 0,
          visibility: "hidden"
        }
      ],
      className
    ],
    content: [
      classNames.content,
      {
        visibility: "visible"
      }
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Layer/Layer.js
var Layer = styled(LayerBase, getStyles3, void 0, {
  scope: "Layer",
  fields: ["hostId", "theme", "styles"]
});

// node_modules/@fluentui/react/lib/components/Layer/LayerHost.js
var React7 = __toESM(require_react());
var LayerHost = function(props) {
  var className = props.className;
  var layerHostId = React7.useState(function() {
    return getId();
  })[0];
  var _a3 = props.id, hostId = _a3 === void 0 ? layerHostId : _a3;
  var layerHostRef = React7.useRef({
    hostId,
    rootRef: React7.useRef(null),
    notifyLayersChanged: function() {
    }
  });
  React7.useImperativeHandle(props.componentRef, function() {
    return layerHostRef.current;
  });
  React7.useEffect(function() {
    registerLayerHost(hostId, layerHostRef.current);
    notifyHostChanged(hostId);
  }, []);
  useUnmount(function() {
    unregisterLayerHost(hostId, layerHostRef.current);
    notifyHostChanged(hostId);
  });
  return React7.createElement("div", __assign({}, props, { className: css("ms-LayerHost", className), ref: layerHostRef.current.rootRef }));
};

// node_modules/@fluentui/react/lib/components/Callout/Callout.js
var Callout = React8.forwardRef(function(_a3, forwardedRef) {
  var layerProps = _a3.layerProps, doNotLayer = _a3.doNotLayer, rest = __rest(_a3, ["layerProps", "doNotLayer"]);
  var content = React8.createElement(CalloutContent, __assign({}, rest, { doNotLayer, ref: forwardedRef }));
  return doNotLayer ? content : React8.createElement(Layer, __assign({}, layerProps), content);
});
Callout.displayName = "Callout";

// node_modules/@fluentui/react/lib/components/Callout/FocusTrapCallout.js
var React10 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/FocusTrapZone/FocusTrapZone.js
var React9 = __toESM(require_react());
var COMPONENT_NAME2 = "FocusTrapZone";
var DEFAULT_PROPS2 = {
  disabled: false,
  disableFirstFocus: false,
  forceFocusInsideTrap: true,
  isClickableOutsideFocusTrap: false
};
var useComponentRef = function(componentRef, previouslyFocusedElement, focusFTZ) {
  React9.useImperativeHandle(componentRef, function() {
    return {
      get previouslyFocusedElement() {
        return previouslyFocusedElement;
      },
      focus: focusFTZ
    };
  }, [focusFTZ, previouslyFocusedElement]);
};
var FocusTrapZone = React9.forwardRef(function(propsWithoutDefaults, ref) {
  var _a3;
  var root = React9.useRef(null);
  var firstBumper = React9.useRef(null);
  var lastBumper = React9.useRef(null);
  var mergedRootRef = useMergedRefs(root, ref);
  var doc = useDocument();
  var isFirstRender = (_a3 = usePrevious(false)) !== null && _a3 !== void 0 ? _a3 : true;
  var props = getPropsWithDefaults(DEFAULT_PROPS2, propsWithoutDefaults);
  var internalState = useConst({
    hasFocus: false,
    focusStackId: useId("ftz-", props.id)
  });
  var children = props.children, componentRef = props.componentRef, disabled = props.disabled, disableFirstFocus = props.disableFirstFocus, forceFocusInsideTrap = props.forceFocusInsideTrap, focusPreviouslyFocusedInnerElement = props.focusPreviouslyFocusedInnerElement, firstFocusableSelector = props.firstFocusableSelector, firstFocusableTarget = props.firstFocusableTarget, _b = props.disableRestoreFocus, disableRestoreFocus = _b === void 0 ? props.ignoreExternalFocusing : _b, isClickableOutsideFocusTrap = props.isClickableOutsideFocusTrap, enableAriaHiddenSiblings = props.enableAriaHiddenSiblings;
  var bumperProps = {
    "aria-hidden": true,
    style: {
      pointerEvents: "none",
      position: "fixed"
      // 'fixed' prevents browsers from scrolling to bumpers when viewport does not contain them
    },
    tabIndex: disabled ? -1 : 0,
    "data-is-visible": true,
    "data-is-focus-trap-zone-bumper": true
  };
  var focusElementAsync = React9.useCallback(function(element) {
    if (element !== firstBumper.current && element !== lastBumper.current) {
      focusAsync(element);
    }
  }, []);
  var focusFTZ = useEventCallback(function() {
    if (!root.current) {
      return;
    }
    var previouslyFocusedElementInTrapZone = internalState.previouslyFocusedElementInTrapZone;
    if (focusPreviouslyFocusedInnerElement && previouslyFocusedElementInTrapZone && elementContains(root.current, previouslyFocusedElementInTrapZone)) {
      focusElementAsync(previouslyFocusedElementInTrapZone);
      return;
    }
    var firstFocusableChild = null;
    if (typeof firstFocusableTarget === "string") {
      firstFocusableChild = root.current.querySelector(firstFocusableTarget);
    } else if (firstFocusableTarget) {
      firstFocusableChild = firstFocusableTarget(root.current);
    } else if (firstFocusableSelector) {
      var focusSelector = typeof firstFocusableSelector === "string" ? firstFocusableSelector : firstFocusableSelector();
      firstFocusableChild = root.current.querySelector("." + focusSelector);
    }
    if (!firstFocusableChild) {
      firstFocusableChild = getNextElement(root.current, root.current.firstChild, false, false, false, true);
    }
    if (firstFocusableChild) {
      focusElementAsync(firstFocusableChild);
    }
  });
  var focusBumper = function(isFirstBumper) {
    if (disabled || !root.current) {
      return;
    }
    var nextFocusable = isFirstBumper === internalState.hasFocus ? getLastTabbable(root.current, lastBumper.current, true, false) : getFirstTabbable(root.current, firstBumper.current, true, false);
    if (nextFocusable) {
      if (nextFocusable === firstBumper.current || nextFocusable === lastBumper.current) {
        focusFTZ();
      } else {
        nextFocusable.focus();
      }
    }
  };
  var onRootBlurCapture = function(ev) {
    var _a4;
    (_a4 = props.onBlurCapture) === null || _a4 === void 0 ? void 0 : _a4.call(props, ev);
    var relatedTarget = ev.relatedTarget;
    if (ev.relatedTarget === null) {
      relatedTarget = doc.activeElement;
    }
    if (!elementContains(root.current, relatedTarget)) {
      internalState.hasFocus = false;
    }
  };
  var onRootFocusCapture = function(ev) {
    var _a4;
    (_a4 = props.onFocusCapture) === null || _a4 === void 0 ? void 0 : _a4.call(props, ev);
    if (ev.target === firstBumper.current) {
      focusBumper(true);
    } else if (ev.target === lastBumper.current) {
      focusBumper(false);
    }
    internalState.hasFocus = true;
    if (ev.target !== ev.currentTarget && !(ev.target === firstBumper.current || ev.target === lastBumper.current)) {
      internalState.previouslyFocusedElementInTrapZone = ev.target;
    }
  };
  var returnFocusToInitiator = useEventCallback(function(elementToFocusOnDismiss) {
    FocusTrapZone.focusStack = FocusTrapZone.focusStack.filter(function(value) {
      return internalState.focusStackId !== value;
    });
    if (!doc) {
      return;
    }
    var activeElement = doc.activeElement;
    if (!disableRestoreFocus && typeof (elementToFocusOnDismiss === null || elementToFocusOnDismiss === void 0 ? void 0 : elementToFocusOnDismiss.focus) === "function" && // only restore focus if the current focused element is within the FTZ, or if nothing is focused
    (elementContains(root.current, activeElement) || activeElement === doc.body)) {
      focusElementAsync(elementToFocusOnDismiss);
    }
  });
  var forceFocusOrClickInTrap = useEventCallback(function(ev) {
    if (disabled) {
      return;
    }
    if (internalState.focusStackId === FocusTrapZone.focusStack.slice(-1)[0]) {
      var targetElement = ev.target;
      if (targetElement && !elementContains(root.current, targetElement)) {
        if (doc && doc.activeElement === doc.body) {
          setTimeout(function() {
            if (doc && doc.activeElement === doc.body) {
              focusFTZ();
              internalState.hasFocus = true;
            }
          }, 0);
        } else {
          focusFTZ();
          internalState.hasFocus = true;
        }
        ev.preventDefault();
        ev.stopPropagation();
      }
    }
  });
  React9.useEffect(function() {
    var disposables = [];
    if (forceFocusInsideTrap) {
      disposables.push(on(window, "focus", forceFocusOrClickInTrap, true));
    }
    if (!isClickableOutsideFocusTrap) {
      disposables.push(on(window, "click", forceFocusOrClickInTrap, true));
    }
    return function() {
      disposables.forEach(function(dispose) {
        return dispose();
      });
    };
  }, [forceFocusInsideTrap, isClickableOutsideFocusTrap]);
  React9.useEffect(function() {
    if (disabled || !isFirstRender && !forceFocusInsideTrap || !root.current) {
      return;
    }
    FocusTrapZone.focusStack.push(internalState.focusStackId);
    var elementToFocusOnDismiss = props.elementToFocusOnDismiss || doc.activeElement;
    if (!disableFirstFocus && !elementContains(root.current, elementToFocusOnDismiss)) {
      focusFTZ();
    }
    return function() {
      return returnFocusToInitiator(elementToFocusOnDismiss);
    };
  }, [forceFocusInsideTrap, disabled]);
  React9.useEffect(function() {
    if (!disabled && enableAriaHiddenSiblings) {
      var unmodalize = modalize(root.current);
      return unmodalize;
    }
  }, [disabled, enableAriaHiddenSiblings, root]);
  useUnmount(function() {
    delete internalState.previouslyFocusedElementInTrapZone;
  });
  useComponentRef(componentRef, internalState.previouslyFocusedElementInTrapZone, focusFTZ);
  return React9.createElement(
    "div",
    __assign({ "aria-labelledby": props.ariaLabelledBy }, getNativeProps(props, divProperties), { ref: mergedRootRef, onFocusCapture: onRootFocusCapture, onBlurCapture: onRootBlurCapture }),
    React9.createElement("div", __assign({}, bumperProps, { ref: firstBumper })),
    children,
    React9.createElement("div", __assign({}, bumperProps, { ref: lastBumper }))
  );
});
FocusTrapZone.displayName = COMPONENT_NAME2;
FocusTrapZone.focusStack = [];

// node_modules/@fluentui/react/lib/components/Callout/FocusTrapCallout.js
var FocusTrapCallout = function(props) {
  return React10.createElement(
    Callout,
    __assign({}, props),
    React10.createElement(FocusTrapZone, __assign({ disabled: props.hidden }, props.focusTrapProps), props.children)
  );
};

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItem.base.js
var React11 = __toESM(require_react());
var defaultIconRenderer = function(props) {
  var item = props.item, classNames = props.classNames;
  var iconProps = item.iconProps;
  return React11.createElement(Icon, __assign({}, iconProps, { className: classNames.icon }));
};
var renderItemIcon = function(props) {
  var item = props.item, hasIcons = props.hasIcons;
  if (!hasIcons) {
    return null;
  }
  if (item.onRenderIcon) {
    return item.onRenderIcon(props, defaultIconRenderer);
  }
  return defaultIconRenderer(props);
};
var renderCheckMarkIcon = function(_a3) {
  var onCheckmarkClick = _a3.onCheckmarkClick, item = _a3.item, classNames = _a3.classNames;
  var isItemChecked = getIsChecked(item);
  if (onCheckmarkClick) {
    var onClick = function(e) {
      return onCheckmarkClick(item, e);
    };
    return React11.createElement(Icon, {
      iconName: item.canCheck !== false && isItemChecked ? "CheckMark" : "",
      className: classNames.checkmarkIcon,
      // eslint-disable-next-line react/jsx-no-bind
      onClick
    });
  }
  return null;
};
var renderItemName = function(_a3) {
  var item = _a3.item, classNames = _a3.classNames;
  if (item.text || item.name) {
    return React11.createElement("span", { className: classNames.label }, item.text || item.name);
  }
  return null;
};
var renderSecondaryText = function(_a3) {
  var item = _a3.item, classNames = _a3.classNames;
  if (item.secondaryText) {
    return React11.createElement("span", { className: classNames.secondaryText }, item.secondaryText);
  }
  return null;
};
var renderSubMenuIcon = function(_a3) {
  var item = _a3.item, classNames = _a3.classNames, theme = _a3.theme;
  if (hasSubmenu(item)) {
    return React11.createElement(Icon, __assign({ iconName: getRTL(theme) ? "ChevronLeft" : "ChevronRight" }, item.submenuIconProps, { className: classNames.subMenuIcon }));
  }
  return null;
};
var ContextualMenuItemBase = (
  /** @class */
  function(_super) {
    __extends(ContextualMenuItemBase2, _super);
    function ContextualMenuItemBase2(props) {
      var _this = _super.call(this, props) || this;
      _this.openSubMenu = function() {
        var _a3 = _this.props, item = _a3.item, openSubMenu = _a3.openSubMenu, getSubmenuTarget = _a3.getSubmenuTarget;
        if (getSubmenuTarget) {
          var submenuTarget = getSubmenuTarget();
          if (hasSubmenu(item) && openSubMenu && submenuTarget) {
            openSubMenu(item, submenuTarget);
          }
        }
      };
      _this.dismissSubMenu = function() {
        var _a3 = _this.props, item = _a3.item, dismissSubMenu = _a3.dismissSubMenu;
        if (hasSubmenu(item) && dismissSubMenu) {
          dismissSubMenu();
        }
      };
      _this.dismissMenu = function(dismissAll) {
        var dismissMenu = _this.props.dismissMenu;
        if (dismissMenu) {
          dismissMenu(void 0, dismissAll);
        }
      };
      initializeComponentRef(_this);
      return _this;
    }
    ContextualMenuItemBase2.prototype.render = function() {
      var _a3 = this.props, item = _a3.item, classNames = _a3.classNames;
      var renderContent = item.onRenderContent || this._renderLayout;
      return React11.createElement("div", { className: item.split ? classNames.linkContentMenu : classNames.linkContent }, renderContent(this.props, {
        renderCheckMarkIcon,
        renderItemIcon,
        renderItemName,
        renderSecondaryText,
        renderSubMenuIcon
      }));
    };
    ContextualMenuItemBase2.prototype._renderLayout = function(props, defaultRenders) {
      return React11.createElement(
        React11.Fragment,
        null,
        defaultRenders.renderCheckMarkIcon(props),
        defaultRenders.renderItemIcon(props),
        defaultRenders.renderItemName(props),
        defaultRenders.renderSecondaryText(props),
        defaultRenders.renderSubMenuIcon(props)
      );
    };
    return ContextualMenuItemBase2;
  }(React11.Component)
);

// node_modules/@fluentui/react/lib/components/Divider/VerticalDivider.classNames.js
var getDividerClassNames = memoizeFunction(
  // eslint-disable-next-line deprecation/deprecation
  function(theme) {
    return mergeStyleSets({
      wrapper: {
        display: "inline-flex",
        height: "100%",
        alignItems: "center"
      },
      divider: {
        width: 1,
        height: "100%",
        backgroundColor: theme.palette.neutralTertiaryAlt
      }
    });
  }
);

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.cnstyles.js
var CONTEXTUAL_MENU_ITEM_HEIGHT = 36;
var MediumScreenSelector = getScreenSelector(0, ScreenWidthMaxMedium);
var getMenuItemStyles = memoizeFunction(function(theme) {
  var _a3, _b, _c, _d, _e;
  var semanticColors = theme.semanticColors, fonts = theme.fonts, palette = theme.palette;
  var ContextualMenuItemBackgroundHoverColor = semanticColors.menuItemBackgroundHovered;
  var ContextualMenuItemTextHoverColor = semanticColors.menuItemTextHovered;
  var ContextualMenuItemBackgroundSelectedColor = semanticColors.menuItemBackgroundPressed;
  var ContextualMenuItemDividerColor = semanticColors.bodyDivider;
  var menuItemStyles = {
    item: [
      fonts.medium,
      {
        color: semanticColors.bodyText,
        position: "relative",
        boxSizing: "border-box"
      }
    ],
    divider: {
      display: "block",
      height: "1px",
      backgroundColor: ContextualMenuItemDividerColor,
      position: "relative"
    },
    root: [
      getFocusStyle(theme),
      fonts.medium,
      {
        color: semanticColors.bodyText,
        backgroundColor: "transparent",
        border: "none",
        width: "100%",
        height: CONTEXTUAL_MENU_ITEM_HEIGHT,
        lineHeight: CONTEXTUAL_MENU_ITEM_HEIGHT,
        display: "block",
        cursor: "pointer",
        padding: "0px 8px 0 4px",
        textAlign: "left"
      }
    ],
    rootDisabled: {
      color: semanticColors.disabledBodyText,
      cursor: "default",
      pointerEvents: "none",
      selectors: (_a3 = {}, _a3[HighContrastSelector] = {
        // ensure disabled text looks different than enabled
        color: "GrayText",
        opacity: 1
      }, _a3)
    },
    rootHovered: {
      backgroundColor: ContextualMenuItemBackgroundHoverColor,
      color: ContextualMenuItemTextHoverColor,
      selectors: {
        ".ms-ContextualMenu-icon": {
          color: palette.themeDarkAlt
        },
        ".ms-ContextualMenu-submenuIcon": {
          color: palette.neutralPrimary
        }
      }
    },
    rootFocused: {
      backgroundColor: palette.white
    },
    rootChecked: {
      selectors: {
        ".ms-ContextualMenu-checkmarkIcon": {
          color: palette.neutralPrimary
        }
      }
    },
    rootPressed: {
      backgroundColor: ContextualMenuItemBackgroundSelectedColor,
      selectors: {
        ".ms-ContextualMenu-icon": {
          color: palette.themeDark
        },
        ".ms-ContextualMenu-submenuIcon": {
          color: palette.neutralPrimary
        }
      }
    },
    rootExpanded: {
      backgroundColor: ContextualMenuItemBackgroundSelectedColor,
      color: semanticColors.bodyTextChecked,
      selectors: (_b = {
        ".ms-ContextualMenu-submenuIcon": (_c = {}, _c[HighContrastSelector] = {
          // icons inside of anchor tags are not properly inheriting color in high contrast
          color: "inherit"
        }, _c)
      }, _b[HighContrastSelector] = __assign({}, getHighContrastNoAdjustStyle()), _b)
    },
    linkContent: {
      whiteSpace: "nowrap",
      height: "inherit",
      display: "flex",
      alignItems: "center",
      maxWidth: "100%"
    },
    anchorLink: {
      padding: "0px 8px 0 4px",
      textRendering: "auto",
      color: "inherit",
      letterSpacing: "normal",
      wordSpacing: "normal",
      textTransform: "none",
      textIndent: "0px",
      textShadow: "none",
      textDecoration: "none",
      boxSizing: "border-box"
    },
    label: {
      margin: "0 4px",
      verticalAlign: "middle",
      display: "inline-block",
      flexGrow: "1",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden"
    },
    secondaryText: {
      color: theme.palette.neutralSecondary,
      paddingLeft: "20px",
      textAlign: "right"
    },
    icon: {
      display: "inline-block",
      minHeight: "1px",
      maxHeight: CONTEXTUAL_MENU_ITEM_HEIGHT,
      fontSize: IconFontSizes.medium,
      width: IconFontSizes.medium,
      margin: "0 4px",
      verticalAlign: "middle",
      flexShrink: "0",
      selectors: (_d = {}, _d[MediumScreenSelector] = {
        fontSize: IconFontSizes.large,
        width: IconFontSizes.large
      }, _d)
    },
    iconColor: {
      color: semanticColors.menuIcon
    },
    iconDisabled: {
      color: semanticColors.disabledBodyText
    },
    checkmarkIcon: {
      color: semanticColors.bodySubtext
    },
    subMenuIcon: {
      height: CONTEXTUAL_MENU_ITEM_HEIGHT,
      lineHeight: CONTEXTUAL_MENU_ITEM_HEIGHT,
      color: palette.neutralSecondary,
      textAlign: "center",
      display: "inline-block",
      verticalAlign: "middle",
      flexShrink: "0",
      fontSize: IconFontSizes.small,
      selectors: (_e = {
        ":hover": {
          color: palette.neutralPrimary
        },
        ":active": {
          color: palette.neutralPrimary
        }
      }, _e[MediumScreenSelector] = {
        fontSize: IconFontSizes.medium
        // 16px
      }, _e)
    },
    splitButtonFlexContainer: [
      getFocusStyle(theme),
      {
        display: "flex",
        height: CONTEXTUAL_MENU_ITEM_HEIGHT,
        flexWrap: "nowrap",
        justifyContent: "center",
        alignItems: "flex-start"
      }
    ]
  };
  return concatStyleSets(menuItemStyles);
});

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.classNames.js
var CONTEXTUAL_SPLIT_MENU_MINWIDTH = "28px";
var MediumScreenSelector2 = getScreenSelector(0, ScreenWidthMaxMedium);
var getSplitButtonVerticalDividerClassNames = memoizeFunction(
  /* eslint-disable deprecation/deprecation */
  function(theme) {
    var _a3;
    return mergeStyleSets(getDividerClassNames(theme), {
      /* eslint-enable deprecation/deprecation */
      wrapper: {
        position: "absolute",
        right: 28,
        selectors: (_a3 = {}, _a3[MediumScreenSelector2] = {
          right: 32
          // fontSize of the icon increased from 12px to 16px
        }, _a3)
      },
      divider: {
        height: 16,
        width: 1
      }
    });
  }
);
var GlobalClassNames4 = {
  item: "ms-ContextualMenu-item",
  divider: "ms-ContextualMenu-divider",
  root: "ms-ContextualMenu-link",
  isChecked: "is-checked",
  isExpanded: "is-expanded",
  isDisabled: "is-disabled",
  linkContent: "ms-ContextualMenu-linkContent",
  linkContentMenu: "ms-ContextualMenu-linkContent",
  icon: "ms-ContextualMenu-icon",
  iconColor: "ms-ContextualMenu-iconColor",
  checkmarkIcon: "ms-ContextualMenu-checkmarkIcon",
  subMenuIcon: "ms-ContextualMenu-submenuIcon",
  label: "ms-ContextualMenu-itemText",
  secondaryText: "ms-ContextualMenu-secondaryText",
  splitMenu: "ms-ContextualMenu-splitMenu",
  screenReaderText: "ms-ContextualMenu-screenReaderText"
};
var getItemClassNames = memoizeFunction(function(theme, disabled, expanded, checked, isAnchorLink, knownIcon, itemClassName, dividerClassName, iconClassName, subMenuClassName, primaryDisabled, className) {
  var _a3, _b, _c, _d;
  var styles = getMenuItemStyles(theme);
  var classNames = getGlobalClassNames(GlobalClassNames4, theme);
  return mergeStyleSets({
    item: [classNames.item, styles.item, itemClassName],
    divider: [classNames.divider, styles.divider, dividerClassName],
    root: [
      classNames.root,
      styles.root,
      checked && [classNames.isChecked, styles.rootChecked],
      isAnchorLink && styles.anchorLink,
      expanded && [classNames.isExpanded, styles.rootExpanded],
      disabled && [classNames.isDisabled, styles.rootDisabled],
      !disabled && !expanded && [
        {
          selectors: (_a3 = {
            ":hover": styles.rootHovered,
            ":active": styles.rootPressed
          }, _a3["." + IsFocusVisibleClassName + " &:focus, ." + IsFocusVisibleClassName + " &:focus:hover"] = styles.rootFocused, _a3["." + IsFocusVisibleClassName + " &:hover"] = { background: "inherit;" }, _a3)
        }
      ],
      className
    ],
    splitPrimary: [
      styles.root,
      {
        width: "calc(100% - " + CONTEXTUAL_SPLIT_MENU_MINWIDTH + ")"
      },
      checked && ["is-checked", styles.rootChecked],
      (disabled || primaryDisabled) && ["is-disabled", styles.rootDisabled],
      !(disabled || primaryDisabled) && !checked && [
        {
          selectors: (_b = {
            ":hover": styles.rootHovered
          }, // when hovering over the splitPrimary also affect the splitMenu
          _b[":hover ~ ." + classNames.splitMenu] = styles.rootHovered, _b[":active"] = styles.rootPressed, _b["." + IsFocusVisibleClassName + " &:focus, ." + IsFocusVisibleClassName + " &:focus:hover"] = styles.rootFocused, _b["." + IsFocusVisibleClassName + " &:hover"] = { background: "inherit;" }, _b)
        }
      ]
    ],
    splitMenu: [
      classNames.splitMenu,
      styles.root,
      {
        flexBasis: "0",
        padding: "0 8px",
        minWidth: CONTEXTUAL_SPLIT_MENU_MINWIDTH
      },
      expanded && ["is-expanded", styles.rootExpanded],
      disabled && ["is-disabled", styles.rootDisabled],
      !disabled && !expanded && [
        {
          selectors: (_c = {
            ":hover": styles.rootHovered,
            ":active": styles.rootPressed
          }, _c["." + IsFocusVisibleClassName + " &:focus, ." + IsFocusVisibleClassName + " &:focus:hover"] = styles.rootFocused, _c["." + IsFocusVisibleClassName + " &:hover"] = { background: "inherit;" }, _c)
        }
      ]
    ],
    anchorLink: styles.anchorLink,
    linkContent: [classNames.linkContent, styles.linkContent],
    linkContentMenu: [
      classNames.linkContentMenu,
      styles.linkContent,
      {
        justifyContent: "center"
      }
    ],
    icon: [
      classNames.icon,
      knownIcon && styles.iconColor,
      styles.icon,
      iconClassName,
      disabled && [classNames.isDisabled, styles.iconDisabled]
    ],
    iconColor: styles.iconColor,
    checkmarkIcon: [classNames.checkmarkIcon, knownIcon && styles.checkmarkIcon, styles.icon, iconClassName],
    subMenuIcon: [
      classNames.subMenuIcon,
      styles.subMenuIcon,
      subMenuClassName,
      expanded && { color: theme.palette.neutralPrimary },
      disabled && [styles.iconDisabled]
    ],
    label: [classNames.label, styles.label],
    secondaryText: [classNames.secondaryText, styles.secondaryText],
    splitContainer: [
      styles.splitButtonFlexContainer,
      !disabled && !checked && [
        {
          selectors: (_d = {}, _d["." + IsFocusVisibleClassName + " &:focus, ." + IsFocusVisibleClassName + " &:focus:hover"] = styles.rootFocused, _d)
        }
      ]
    ],
    screenReaderText: [
      classNames.screenReaderText,
      styles.screenReaderText,
      hiddenContentStyle,
      { visibility: "hidden" }
    ]
  });
});
var getItemStyles = function(props) {
  var theme = props.theme, disabled = props.disabled, expanded = props.expanded, checked = props.checked, isAnchorLink = props.isAnchorLink, knownIcon = props.knownIcon, itemClassName = props.itemClassName, dividerClassName = props.dividerClassName, iconClassName = props.iconClassName, subMenuClassName = props.subMenuClassName, primaryDisabled = props.primaryDisabled, className = props.className;
  return getItemClassNames(theme, disabled, expanded, checked, isAnchorLink, knownIcon, itemClassName, dividerClassName, iconClassName, subMenuClassName, primaryDisabled, className);
};

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItem.js
var ContextualMenuItem = styled(ContextualMenuItemBase, getItemStyles, void 0, { scope: "ContextualMenuItem" });

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuAnchor.js
var React15 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuItemWrapper.js
var React12 = __toESM(require_react());
var ContextualMenuItemWrapper = (
  /** @class */
  function(_super) {
    __extends(ContextualMenuItemWrapper2, _super);
    function ContextualMenuItemWrapper2(props) {
      var _this = _super.call(this, props) || this;
      _this._onItemMouseEnter = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseEnter = _a3.onItemMouseEnter;
        if (onItemMouseEnter) {
          onItemMouseEnter(item, ev, ev.currentTarget);
        }
      };
      _this._onItemClick = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemClickBase = _a3.onItemClickBase;
        if (onItemClickBase) {
          onItemClickBase(item, ev, ev.currentTarget);
        }
      };
      _this._onItemMouseLeave = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseLeave = _a3.onItemMouseLeave;
        if (onItemMouseLeave) {
          onItemMouseLeave(item, ev);
        }
      };
      _this._onItemKeyDown = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemKeyDown = _a3.onItemKeyDown;
        if (onItemKeyDown) {
          onItemKeyDown(item, ev);
        }
      };
      _this._onItemMouseMove = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseMove = _a3.onItemMouseMove;
        if (onItemMouseMove) {
          onItemMouseMove(item, ev, ev.currentTarget);
        }
      };
      _this._getSubmenuTarget = function() {
        return void 0;
      };
      initializeComponentRef(_this);
      return _this;
    }
    ContextualMenuItemWrapper2.prototype.shouldComponentUpdate = function(newProps) {
      return !shallowCompare(newProps, this.props);
    };
    return ContextualMenuItemWrapper2;
  }(React12.Component)
);

// node_modules/@fluentui/react/lib/utilities/keytips/IKeytipTransitionKey.js
function transitionKeysAreEqual(key1, key2) {
  if (key1.key !== key2.key) {
    return false;
  }
  var mod1 = key1.modifierKeys;
  var mod2 = key2.modifierKeys;
  if (!mod1 && mod2 || mod1 && !mod2) {
    return false;
  }
  if (mod1 && mod2) {
    if (mod1.length !== mod2.length) {
      return false;
    }
    mod1 = mod1.sort();
    mod2 = mod2.sort();
    for (var i = 0; i < mod1.length; i++) {
      if (mod1[i] !== mod2[i]) {
        return false;
      }
    }
  }
  return true;
}
function transitionKeysContain(keys, key) {
  return !!find(keys, function(transitionKey) {
    return transitionKeysAreEqual(transitionKey, key);
  });
}

// node_modules/@fluentui/react/lib/utilities/keytips/KeytipConfig.js
function buildKeytipConfigMap(config) {
  var configMap = {};
  for (var _i = 0, _a3 = config.keytips; _i < _a3.length; _i++) {
    var keytip = _a3[_i];
    constructKeytip(configMap, [], keytip);
  }
  return configMap;
}
function constructKeytip(configMap, parentSequence, keytip) {
  var sequence = keytip.sequence ? keytip.sequence : keytip.content.toLocaleLowerCase();
  var keytipSequence = parentSequence.concat(sequence);
  var keytipProps = __assign(__assign({}, keytip.optionalProps), { keySequences: keytipSequence, content: keytip.content });
  configMap[keytip.id] = keytipProps;
  if (keytip.children) {
    for (var _i = 0, _a3 = keytip.children; _i < _a3.length; _i++) {
      var child = _a3[_i];
      constructKeytip(configMap, keytipSequence, child);
    }
  }
}

// node_modules/@fluentui/react/lib/utilities/keytips/KeytipConstants.js
var KTP_PREFIX = "ktp";
var KTP_SEPARATOR = "-";
var KTP_FULL_PREFIX = KTP_PREFIX + KTP_SEPARATOR;
var DATAKTP_TARGET = "data-ktp-target";
var DATAKTP_EXECUTE_TARGET = "data-ktp-execute-target";
var DATAKTP_ARIA_TARGET = "data-ktp-aria-target";
var KTP_LAYER_ID = "ktp-layer-id";
var KTP_ARIA_SEPARATOR = ", ";
var KeytipEvents;
(function(KeytipEvents2) {
  KeytipEvents2.KEYTIP_ADDED = "keytipAdded";
  KeytipEvents2.KEYTIP_REMOVED = "keytipRemoved";
  KeytipEvents2.KEYTIP_UPDATED = "keytipUpdated";
  KeytipEvents2.PERSISTED_KEYTIP_ADDED = "persistedKeytipAdded";
  KeytipEvents2.PERSISTED_KEYTIP_REMOVED = "persistedKeytipRemoved";
  KeytipEvents2.PERSISTED_KEYTIP_EXECUTE = "persistedKeytipExecute";
  KeytipEvents2.ENTER_KEYTIP_MODE = "enterKeytipMode";
  KeytipEvents2.EXIT_KEYTIP_MODE = "exitKeytipMode";
})(KeytipEvents || (KeytipEvents = {}));

// node_modules/@fluentui/react/lib/utilities/keytips/KeytipManager.js
var KeytipManager = (
  /** @class */
  function() {
    function KeytipManager2() {
      this.keytips = {};
      this.persistedKeytips = {};
      this.sequenceMapping = {};
      this.inKeytipMode = false;
      this.shouldEnterKeytipMode = true;
      this.delayUpdatingKeytipChange = false;
    }
    KeytipManager2.getInstance = function() {
      return this._instance;
    };
    KeytipManager2.prototype.init = function(delayUpdatingKeytipChange) {
      this.delayUpdatingKeytipChange = delayUpdatingKeytipChange;
    };
    KeytipManager2.prototype.register = function(keytipProps, persisted) {
      if (persisted === void 0) {
        persisted = false;
      }
      var props = keytipProps;
      if (!persisted) {
        props = this.addParentOverflow(keytipProps);
        this.sequenceMapping[props.keySequences.toString()] = props;
      }
      var uniqueKeytip = this._getUniqueKtp(props);
      persisted ? this.persistedKeytips[uniqueKeytip.uniqueID] = uniqueKeytip : this.keytips[uniqueKeytip.uniqueID] = uniqueKeytip;
      if (this.inKeytipMode || !this.delayUpdatingKeytipChange) {
        var event_1 = persisted ? KeytipEvents.PERSISTED_KEYTIP_ADDED : KeytipEvents.KEYTIP_ADDED;
        EventGroup.raise(this, event_1, {
          keytip: props,
          uniqueID: uniqueKeytip.uniqueID
        });
      }
      return uniqueKeytip.uniqueID;
    };
    KeytipManager2.prototype.update = function(keytipProps, uniqueID) {
      var newKeytipProps = this.addParentOverflow(keytipProps);
      var uniqueKeytip = this._getUniqueKtp(newKeytipProps, uniqueID);
      var oldKeyTip = this.keytips[uniqueID];
      if (oldKeyTip) {
        uniqueKeytip.keytip.visible = oldKeyTip.keytip.visible;
        this.keytips[uniqueID] = uniqueKeytip;
        delete this.sequenceMapping[oldKeyTip.keytip.keySequences.toString()];
        this.sequenceMapping[uniqueKeytip.keytip.keySequences.toString()] = uniqueKeytip.keytip;
        if (this.inKeytipMode || !this.delayUpdatingKeytipChange) {
          EventGroup.raise(this, KeytipEvents.KEYTIP_UPDATED, {
            keytip: uniqueKeytip.keytip,
            uniqueID: uniqueKeytip.uniqueID
          });
        }
      }
    };
    KeytipManager2.prototype.unregister = function(keytipToRemove, uniqueID, persisted) {
      if (persisted === void 0) {
        persisted = false;
      }
      persisted ? delete this.persistedKeytips[uniqueID] : delete this.keytips[uniqueID];
      !persisted && delete this.sequenceMapping[keytipToRemove.keySequences.toString()];
      var event = persisted ? KeytipEvents.PERSISTED_KEYTIP_REMOVED : KeytipEvents.KEYTIP_REMOVED;
      if (this.inKeytipMode || !this.delayUpdatingKeytipChange) {
        EventGroup.raise(this, event, {
          keytip: keytipToRemove,
          uniqueID
        });
      }
    };
    KeytipManager2.prototype.enterKeytipMode = function() {
      EventGroup.raise(this, KeytipEvents.ENTER_KEYTIP_MODE);
    };
    KeytipManager2.prototype.exitKeytipMode = function() {
      EventGroup.raise(this, KeytipEvents.EXIT_KEYTIP_MODE);
    };
    KeytipManager2.prototype.getKeytips = function() {
      var _this = this;
      return Object.keys(this.keytips).map(function(key) {
        return _this.keytips[key].keytip;
      });
    };
    KeytipManager2.prototype.addParentOverflow = function(keytipProps) {
      var fullSequence = __spreadArray([], keytipProps.keySequences);
      fullSequence.pop();
      if (fullSequence.length !== 0) {
        var parentKeytip = this.sequenceMapping[fullSequence.toString()];
        if (parentKeytip && parentKeytip.overflowSetSequence) {
          return __assign(__assign({}, keytipProps), { overflowSetSequence: parentKeytip.overflowSetSequence });
        }
      }
      return keytipProps;
    };
    KeytipManager2.prototype.menuExecute = function(overflowButtonSequences, keytipSequences) {
      EventGroup.raise(this, KeytipEvents.PERSISTED_KEYTIP_EXECUTE, {
        overflowButtonSequences,
        keytipSequences
      });
    };
    KeytipManager2.prototype._getUniqueKtp = function(keytipProps, uniqueID) {
      if (uniqueID === void 0) {
        uniqueID = getId();
      }
      return { keytip: __assign({}, keytipProps), uniqueID };
    };
    KeytipManager2._instance = new KeytipManager2();
    return KeytipManager2;
  }()
);

// node_modules/@fluentui/react/lib/utilities/keytips/KeytipUtils.js
function sequencesToID(keySequences) {
  return keySequences.reduce(function(prevValue, keySequence) {
    return prevValue + KTP_SEPARATOR + keySequence.split("").join(KTP_SEPARATOR);
  }, KTP_PREFIX);
}
function mergeOverflows(keySequences, overflowKeySequences) {
  var overflowSequenceLen = overflowKeySequences.length;
  var overflowSequence = __spreadArray([], overflowKeySequences).pop();
  var newKeySequences = __spreadArray([], keySequences);
  return addElementAtIndex(newKeySequences, overflowSequenceLen - 1, overflowSequence);
}
function ktpTargetFromSequences(keySequences) {
  return "[" + DATAKTP_TARGET + '="' + sequencesToID(keySequences) + '"]';
}
function ktpTargetFromId(keytipId) {
  return "[" + DATAKTP_EXECUTE_TARGET + '="' + keytipId + '"]';
}
function getAriaDescribedBy(keySequences) {
  var describedby = " " + KTP_LAYER_ID;
  if (!keySequences.length) {
    return describedby;
  }
  return describedby + " " + sequencesToID(keySequences);
}

// node_modules/@fluentui/react/lib/components/KeytipData/useKeytipData.js
var React13 = __toESM(require_react());
function useKeytipData(options) {
  var uniqueId = React13.useRef();
  var keytipProps = options.keytipProps ? __assign({ disabled: options.disabled }, options.keytipProps) : void 0;
  var keytipManager = useConst(KeytipManager.getInstance());
  var prevOptions = usePrevious(options);
  useIsomorphicLayoutEffect(function() {
    if (uniqueId.current && keytipProps && ((prevOptions === null || prevOptions === void 0 ? void 0 : prevOptions.keytipProps) !== options.keytipProps || (prevOptions === null || prevOptions === void 0 ? void 0 : prevOptions.disabled) !== options.disabled)) {
      keytipManager.update(keytipProps, uniqueId.current);
    }
  });
  useIsomorphicLayoutEffect(function() {
    if (keytipProps) {
      uniqueId.current = keytipManager.register(keytipProps);
    }
    return function() {
      keytipProps && keytipManager.unregister(keytipProps, uniqueId.current);
    };
  }, []);
  var nativeKeytipProps = {
    ariaDescribedBy: void 0,
    keytipId: void 0
  };
  if (keytipProps) {
    nativeKeytipProps = getKeytipData(keytipManager, keytipProps, options.ariaDescribedBy);
  }
  return nativeKeytipProps;
}
function getKeytipData(keytipManager, keytipProps, describedByPrepend) {
  var newKeytipProps = keytipManager.addParentOverflow(keytipProps);
  var ariaDescribedBy = mergeAriaAttributeValues(describedByPrepend, getAriaDescribedBy(newKeytipProps.keySequences));
  var keySequences = __spreadArray([], newKeytipProps.keySequences);
  if (newKeytipProps.overflowSetSequence) {
    keySequences = mergeOverflows(keySequences, newKeytipProps.overflowSetSequence);
  }
  var keytipId = sequencesToID(keySequences);
  return {
    ariaDescribedBy,
    keytipId
  };
}

// node_modules/@fluentui/react/lib/components/KeytipData/KeytipData.js
var KeytipData = function(props) {
  var _a3;
  var children = props.children, keytipDataProps = __rest(props, ["children"]);
  var _b = useKeytipData(keytipDataProps), keytipId = _b.keytipId, ariaDescribedBy = _b.ariaDescribedBy;
  return children((_a3 = {}, _a3[DATAKTP_TARGET] = keytipId, _a3[DATAKTP_EXECUTE_TARGET] = keytipId, _a3["aria-describedby"] = ariaDescribedBy, _a3));
};

// node_modules/@fluentui/react/lib/components/KeytipData/useKeytipRef.js
var React14 = __toESM(require_react());
function useKeytipRef(options) {
  var _a3 = useKeytipData(options), keytipId = _a3.keytipId, ariaDescribedBy = _a3.ariaDescribedBy;
  var contentRef = React14.useCallback(function(contentElement) {
    if (!contentElement) {
      return;
    }
    var targetElement = findFirstElement(contentElement, DATAKTP_TARGET) || contentElement;
    var executeElement = findFirstElement(contentElement, DATAKTP_EXECUTE_TARGET) || targetElement;
    var ariaElement = findFirstElement(contentElement, DATAKTP_ARIA_TARGET) || executeElement;
    setAttribute(targetElement, DATAKTP_TARGET, keytipId);
    setAttribute(executeElement, DATAKTP_EXECUTE_TARGET, keytipId);
    setAttribute(ariaElement, "aria-describedby", ariaDescribedBy, true);
  }, [keytipId, ariaDescribedBy]);
  return contentRef;
}
function setAttribute(element, attributeName, attributeValue, append) {
  if (append === void 0) {
    append = false;
  }
  if (element && attributeValue) {
    var value = attributeValue;
    if (append) {
      var currentValue = element.getAttribute(attributeName);
      if (currentValue && currentValue.indexOf(attributeValue) === -1) {
        value = currentValue + " " + attributeValue;
      }
    }
    element.setAttribute(attributeName, value);
  }
}
function findFirstElement(rootElement, dataAttribute) {
  return rootElement.querySelector("[" + dataAttribute + "]");
}

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuAnchor.js
var ContextualMenuAnchor = (
  /** @class */
  function(_super) {
    __extends(ContextualMenuAnchor2, _super);
    function ContextualMenuAnchor2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this._anchor = React15.createRef();
      _this._getMemoizedMenuButtonKeytipProps = memoizeFunction(function(keytipProps) {
        return __assign(__assign({}, keytipProps), { hasMenu: true });
      });
      _this._getSubmenuTarget = function() {
        return _this._anchor.current ? _this._anchor.current : void 0;
      };
      _this._onItemClick = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemClick = _a3.onItemClick;
        if (onItemClick) {
          onItemClick(item, ev);
        }
      };
      _this._renderAriaDescription = function(ariaDescription, className) {
        return ariaDescription ? React15.createElement("span", { id: _this._ariaDescriptionId, className }, ariaDescription) : null;
      };
      return _this;
    }
    ContextualMenuAnchor2.prototype.render = function() {
      var _this = this;
      var _a3 = this.props, item = _a3.item, classNames = _a3.classNames, index = _a3.index, focusableElementIndex = _a3.focusableElementIndex, totalItemCount = _a3.totalItemCount, hasCheckmarks = _a3.hasCheckmarks, hasIcons = _a3.hasIcons, _b = _a3.contextualMenuItemAs, ChildrenRenderer = _b === void 0 ? ContextualMenuItem : _b, expandedMenuItemKey = _a3.expandedMenuItemKey, onItemClick = _a3.onItemClick, openSubMenu = _a3.openSubMenu, dismissSubMenu = _a3.dismissSubMenu, dismissMenu = _a3.dismissMenu;
      var anchorRel = item.rel;
      if (item.target && item.target.toLowerCase() === "_blank") {
        anchorRel = anchorRel ? anchorRel : "nofollow noopener noreferrer";
      }
      var itemHasSubmenu = hasSubmenu(item);
      var nativeProps = getNativeProps(item, anchorProperties);
      var disabled = isItemDisabled(item);
      var itemProps = item.itemProps, ariaDescription = item.ariaDescription;
      var keytipProps = item.keytipProps;
      if (keytipProps && itemHasSubmenu) {
        keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
      }
      if (ariaDescription) {
        this._ariaDescriptionId = getId();
      }
      var ariaDescribedByIds = mergeAriaAttributeValues(item.ariaDescribedBy, ariaDescription ? this._ariaDescriptionId : void 0, nativeProps["aria-describedby"]);
      var additionalItemProperties = {
        "aria-describedby": ariaDescribedByIds
      };
      return React15.createElement(
        "div",
        null,
        React15.createElement(KeytipData, { keytipProps: item.keytipProps, ariaDescribedBy: ariaDescribedByIds, disabled }, function(keytipAttributes) {
          return React15.createElement(
            "a",
            __assign({}, additionalItemProperties, nativeProps, keytipAttributes, {
              ref: _this._anchor,
              href: item.href,
              target: item.target,
              rel: anchorRel,
              className: classNames.root,
              role: "menuitem",
              "aria-haspopup": itemHasSubmenu || void 0,
              "aria-expanded": itemHasSubmenu ? item.key === expandedMenuItemKey : void 0,
              "aria-posinset": focusableElementIndex + 1,
              "aria-setsize": totalItemCount,
              "aria-disabled": isItemDisabled(item),
              // eslint-disable-next-line deprecation/deprecation
              style: item.style,
              onClick: _this._onItemClick,
              onMouseEnter: _this._onItemMouseEnter,
              onMouseLeave: _this._onItemMouseLeave,
              onMouseMove: _this._onItemMouseMove,
              onKeyDown: itemHasSubmenu ? _this._onItemKeyDown : void 0
            }),
            React15.createElement(ChildrenRenderer, __assign({ componentRef: item.componentRef, item, classNames, index, onCheckmarkClick: hasCheckmarks && onItemClick ? onItemClick : void 0, hasIcons, openSubMenu, dismissSubMenu, dismissMenu, getSubmenuTarget: _this._getSubmenuTarget }, itemProps)),
            _this._renderAriaDescription(ariaDescription, classNames.screenReaderText)
          );
        })
      );
    };
    return ContextualMenuAnchor2;
  }(ContextualMenuItemWrapper)
);

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuButton.js
var React16 = __toESM(require_react());
var ContextualMenuButton = (
  /** @class */
  function(_super) {
    __extends(ContextualMenuButton2, _super);
    function ContextualMenuButton2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this._btn = React16.createRef();
      _this._getMemoizedMenuButtonKeytipProps = memoizeFunction(function(keytipProps) {
        return __assign(__assign({}, keytipProps), { hasMenu: true });
      });
      _this._renderAriaDescription = function(ariaDescription, className) {
        return ariaDescription ? React16.createElement("span", { id: _this._ariaDescriptionId, className }, ariaDescription) : null;
      };
      _this._getSubmenuTarget = function() {
        return _this._btn.current ? _this._btn.current : void 0;
      };
      return _this;
    }
    ContextualMenuButton2.prototype.render = function() {
      var _this = this;
      var _a3 = this.props, item = _a3.item, classNames = _a3.classNames, index = _a3.index, focusableElementIndex = _a3.focusableElementIndex, totalItemCount = _a3.totalItemCount, hasCheckmarks = _a3.hasCheckmarks, hasIcons = _a3.hasIcons, _b = _a3.contextualMenuItemAs, ChildrenRenderer = _b === void 0 ? ContextualMenuItem : _b, expandedMenuItemKey = _a3.expandedMenuItemKey, onItemMouseDown2 = _a3.onItemMouseDown, onItemClick = _a3.onItemClick, openSubMenu = _a3.openSubMenu, dismissSubMenu = _a3.dismissSubMenu, dismissMenu = _a3.dismissMenu;
      var isChecked = getIsChecked(item);
      var canCheck = isChecked !== null;
      var defaultRole = getMenuItemAriaRole(item);
      var itemHasSubmenu = hasSubmenu(item);
      var itemProps = item.itemProps, ariaLabel = item.ariaLabel, ariaDescription = item.ariaDescription;
      var buttonNativeProperties = getNativeProps(item, buttonProperties);
      delete buttonNativeProperties.disabled;
      var itemRole = item.role || defaultRole;
      if (ariaDescription) {
        this._ariaDescriptionId = getId();
      }
      var ariaDescribedByIds = mergeAriaAttributeValues(item.ariaDescribedBy, ariaDescription ? this._ariaDescriptionId : void 0, buttonNativeProperties["aria-describedby"]);
      var itemButtonProperties = {
        className: classNames.root,
        onClick: this._onItemClick,
        onKeyDown: itemHasSubmenu ? this._onItemKeyDown : void 0,
        onMouseEnter: this._onItemMouseEnter,
        onMouseLeave: this._onItemMouseLeave,
        onMouseDown: function(ev) {
          return onItemMouseDown2 ? onItemMouseDown2(item, ev) : void 0;
        },
        onMouseMove: this._onItemMouseMove,
        href: item.href,
        title: item.title,
        "aria-label": ariaLabel,
        "aria-describedby": ariaDescribedByIds,
        "aria-haspopup": itemHasSubmenu || void 0,
        "aria-expanded": itemHasSubmenu ? item.key === expandedMenuItemKey : void 0,
        "aria-posinset": focusableElementIndex + 1,
        "aria-setsize": totalItemCount,
        "aria-disabled": isItemDisabled(item),
        "aria-checked": (itemRole === "menuitemcheckbox" || itemRole === "menuitemradio") && canCheck ? !!isChecked : void 0,
        "aria-selected": itemRole === "menuitem" && canCheck ? !!isChecked : void 0,
        role: itemRole,
        // eslint-disable-next-line deprecation/deprecation
        style: item.style
      };
      var keytipProps = item.keytipProps;
      if (keytipProps && itemHasSubmenu) {
        keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
      }
      return React16.createElement(KeytipData, { keytipProps, ariaDescribedBy: ariaDescribedByIds, disabled: isItemDisabled(item) }, function(keytipAttributes) {
        return React16.createElement(
          "button",
          __assign({ ref: _this._btn }, buttonNativeProperties, itemButtonProperties, keytipAttributes),
          React16.createElement(ChildrenRenderer, __assign({ componentRef: item.componentRef, item, classNames, index, onCheckmarkClick: hasCheckmarks && onItemClick ? onItemClick : void 0, hasIcons, openSubMenu, dismissSubMenu, dismissMenu, getSubmenuTarget: _this._getSubmenuTarget }, itemProps)),
          _this._renderAriaDescription(ariaDescription, classNames.screenReaderText)
        );
      });
    };
    return ContextualMenuButton2;
  }(ContextualMenuItemWrapper)
);

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuSplitButton.js
var React18 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Divider/VerticalDivider.styles.js
var getStyles4 = function(props) {
  var theme = props.theme, getClassNames7 = props.getClassNames, className = props.className;
  if (!theme) {
    throw new Error("Theme is undefined or null.");
  }
  if (getClassNames7) {
    var names = getClassNames7(theme);
    return {
      wrapper: [names.wrapper],
      divider: [names.divider]
    };
  }
  return {
    wrapper: [
      {
        display: "inline-flex",
        height: "100%",
        alignItems: "center"
      },
      className
    ],
    divider: [
      {
        width: 1,
        height: "100%",
        backgroundColor: theme.palette.neutralTertiaryAlt
      }
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Divider/VerticalDivider.base.js
var React17 = __toESM(require_react());
var getClassNames4 = classNamesFunction();
var VerticalDividerBase = React17.forwardRef(function(props, ref) {
  var styles = props.styles, theme = props.theme, deprecatedGetClassNames = props.getClassNames, className = props.className;
  var classNames = getClassNames4(styles, { theme, getClassNames: deprecatedGetClassNames, className });
  return React17.createElement(
    "span",
    { className: classNames.wrapper, ref },
    React17.createElement("span", { className: classNames.divider })
  );
});
VerticalDividerBase.displayName = "VerticalDividerBase";

// node_modules/@fluentui/react/lib/components/Divider/VerticalDivider.js
var VerticalDivider = styled(VerticalDividerBase, getStyles4, void 0, {
  scope: "VerticalDivider"
});

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenuItemWrapper/ContextualMenuSplitButton.js
var TouchIdleDelay = 500;
var ContextualMenuSplitButton = (
  /** @class */
  function(_super) {
    __extends(ContextualMenuSplitButton2, _super);
    function ContextualMenuSplitButton2(props) {
      var _this = _super.call(this, props) || this;
      _this._getMemoizedMenuButtonKeytipProps = memoizeFunction(function(keytipProps) {
        return __assign(__assign({}, keytipProps), { hasMenu: true });
      });
      _this._onItemKeyDown = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemKeyDown = _a3.onItemKeyDown;
        if (ev.which === KeyCodes.enter) {
          _this._executeItemClick(ev);
          ev.preventDefault();
          ev.stopPropagation();
        } else if (onItemKeyDown) {
          onItemKeyDown(item, ev);
        }
      };
      _this._getSubmenuTarget = function() {
        return _this._splitButton;
      };
      _this._renderAriaDescription = function(ariaDescription, className) {
        return ariaDescription ? React18.createElement("span", { id: _this._ariaDescriptionId, className }, ariaDescription) : null;
      };
      _this._onItemMouseEnterPrimary = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseEnter = _a3.onItemMouseEnter;
        if (onItemMouseEnter) {
          onItemMouseEnter(__assign(__assign({}, item), { subMenuProps: void 0, items: void 0 }), ev, _this._splitButton);
        }
      };
      _this._onItemMouseEnterIcon = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseEnter = _a3.onItemMouseEnter;
        if (onItemMouseEnter) {
          onItemMouseEnter(item, ev, _this._splitButton);
        }
      };
      _this._onItemMouseMovePrimary = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseMove = _a3.onItemMouseMove;
        if (onItemMouseMove) {
          onItemMouseMove(__assign(__assign({}, item), { subMenuProps: void 0, items: void 0 }), ev, _this._splitButton);
        }
      };
      _this._onItemMouseMoveIcon = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemMouseMove = _a3.onItemMouseMove;
        if (onItemMouseMove) {
          onItemMouseMove(item, ev, _this._splitButton);
        }
      };
      _this._onIconItemClick = function(ev) {
        var _a3 = _this.props, item = _a3.item, onItemClickBase = _a3.onItemClickBase;
        if (onItemClickBase) {
          onItemClickBase(item, ev, _this._splitButton ? _this._splitButton : ev.currentTarget);
        }
      };
      _this._executeItemClick = function(ev) {
        var _a3 = _this.props, item = _a3.item, executeItemClick = _a3.executeItemClick, onItemClick = _a3.onItemClick;
        if (item.disabled || item.isDisabled) {
          return;
        }
        if (_this._processingTouch && onItemClick) {
          return onItemClick(item, ev);
        }
        if (executeItemClick) {
          executeItemClick(item, ev);
        }
      };
      _this._onTouchStart = function(ev) {
        if (_this._splitButton && !("onpointerdown" in _this._splitButton)) {
          _this._handleTouchAndPointerEvent(ev);
        }
      };
      _this._onPointerDown = function(ev) {
        if (ev.pointerType === "touch") {
          _this._handleTouchAndPointerEvent(ev);
          ev.preventDefault();
          ev.stopImmediatePropagation();
        }
      };
      _this._async = new Async(_this);
      _this._events = new EventGroup(_this);
      return _this;
    }
    ContextualMenuSplitButton2.prototype.componentDidMount = function() {
      if (this._splitButton && "onpointerdown" in this._splitButton) {
        this._events.on(this._splitButton, "pointerdown", this._onPointerDown, true);
      }
    };
    ContextualMenuSplitButton2.prototype.componentWillUnmount = function() {
      this._async.dispose();
      this._events.dispose();
    };
    ContextualMenuSplitButton2.prototype.render = function() {
      var _this = this;
      var _a3 = this.props, item = _a3.item, classNames = _a3.classNames, index = _a3.index, focusableElementIndex = _a3.focusableElementIndex, totalItemCount = _a3.totalItemCount, hasCheckmarks = _a3.hasCheckmarks, hasIcons = _a3.hasIcons, onItemMouseLeave = _a3.onItemMouseLeave, expandedMenuItemKey = _a3.expandedMenuItemKey;
      var itemHasSubmenu = hasSubmenu(item);
      var keytipProps = item.keytipProps;
      if (keytipProps) {
        keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
      }
      var ariaDescription = item.ariaDescription;
      if (ariaDescription) {
        this._ariaDescriptionId = getId();
      }
      return React18.createElement(KeytipData, { keytipProps, disabled: isItemDisabled(item) }, function(keytipAttributes) {
        return React18.createElement(
          "div",
          { "data-ktp-target": keytipAttributes["data-ktp-target"], ref: function(splitButton) {
            return _this._splitButton = splitButton;
          }, role: getMenuItemAriaRole(item), "aria-label": item.ariaLabel, className: classNames.splitContainer, "aria-disabled": isItemDisabled(item), "aria-expanded": itemHasSubmenu ? item.key === expandedMenuItemKey : void 0, "aria-haspopup": true, "aria-describedby": mergeAriaAttributeValues(item.ariaDescribedBy, ariaDescription ? _this._ariaDescriptionId : void 0, keytipAttributes["aria-describedby"]), "aria-checked": item.isChecked || item.checked, "aria-posinset": focusableElementIndex + 1, "aria-setsize": totalItemCount, onMouseEnter: _this._onItemMouseEnterPrimary, onMouseLeave: onItemMouseLeave ? onItemMouseLeave.bind(_this, __assign(__assign({}, item), { subMenuProps: null, items: null })) : void 0, onMouseMove: _this._onItemMouseMovePrimary, onKeyDown: _this._onItemKeyDown, onClick: _this._executeItemClick, onTouchStart: _this._onTouchStart, tabIndex: 0, "data-is-focusable": true, "aria-roledescription": item["aria-roledescription"] },
          _this._renderSplitPrimaryButton(item, classNames, index, hasCheckmarks, hasIcons),
          _this._renderSplitDivider(item),
          _this._renderSplitIconButton(item, classNames, index, keytipAttributes),
          _this._renderAriaDescription(ariaDescription, classNames.screenReaderText)
        );
      });
    };
    ContextualMenuSplitButton2.prototype._renderSplitPrimaryButton = function(item, classNames, index, hasCheckmarks, hasIcons) {
      var _a3 = this.props, _b = _a3.contextualMenuItemAs, ChildrenRenderer = _b === void 0 ? ContextualMenuItem : _b, onItemClick = _a3.onItemClick;
      var itemProps = {
        key: item.key,
        disabled: isItemDisabled(item) || item.primaryDisabled,
        /* eslint-disable deprecation/deprecation */
        name: item.name,
        text: item.text || item.name,
        secondaryText: item.secondaryText,
        /* eslint-enable deprecation/deprecation */
        className: classNames.splitPrimary,
        canCheck: item.canCheck,
        isChecked: item.isChecked,
        checked: item.checked,
        iconProps: item.iconProps,
        onRenderIcon: item.onRenderIcon,
        data: item.data,
        "data-is-focusable": false
      };
      var itemComponentProps = item.itemProps;
      return React18.createElement(
        "button",
        __assign({}, getNativeProps(itemProps, buttonProperties)),
        React18.createElement(ChildrenRenderer, __assign({ "data-is-focusable": false, item: itemProps, classNames, index, onCheckmarkClick: hasCheckmarks && onItemClick ? onItemClick : void 0, hasIcons }, itemComponentProps))
      );
    };
    ContextualMenuSplitButton2.prototype._renderSplitDivider = function(item) {
      var getDividerClassNames2 = item.getSplitButtonVerticalDividerClassNames || getSplitButtonVerticalDividerClassNames;
      return React18.createElement(VerticalDivider, { getClassNames: getDividerClassNames2 });
    };
    ContextualMenuSplitButton2.prototype._renderSplitIconButton = function(item, classNames, index, keytipAttributes) {
      var _a3 = this.props, _b = _a3.contextualMenuItemAs, ChildrenRenderer = _b === void 0 ? ContextualMenuItem : _b, onItemMouseLeave = _a3.onItemMouseLeave, onItemMouseDown2 = _a3.onItemMouseDown, openSubMenu = _a3.openSubMenu, dismissSubMenu = _a3.dismissSubMenu, dismissMenu = _a3.dismissMenu;
      var itemProps = {
        onClick: this._onIconItemClick,
        disabled: isItemDisabled(item),
        className: classNames.splitMenu,
        subMenuProps: item.subMenuProps,
        submenuIconProps: item.submenuIconProps,
        split: true,
        key: item.key
      };
      var buttonProps = __assign(__assign({}, getNativeProps(itemProps, buttonProperties)), {
        onMouseEnter: this._onItemMouseEnterIcon,
        onMouseLeave: onItemMouseLeave ? onItemMouseLeave.bind(this, item) : void 0,
        onMouseDown: function(ev) {
          return onItemMouseDown2 ? onItemMouseDown2(item, ev) : void 0;
        },
        onMouseMove: this._onItemMouseMoveIcon,
        "data-is-focusable": false,
        "data-ktp-execute-target": keytipAttributes["data-ktp-execute-target"],
        "aria-hidden": true
      });
      var itemComponentProps = item.itemProps;
      return React18.createElement(
        "button",
        __assign({}, buttonProps),
        React18.createElement(ChildrenRenderer, __assign({ componentRef: item.componentRef, item: itemProps, classNames, index, hasIcons: false, openSubMenu, dismissSubMenu, dismissMenu, getSubmenuTarget: this._getSubmenuTarget }, itemComponentProps))
      );
    };
    ContextualMenuSplitButton2.prototype._handleTouchAndPointerEvent = function(ev) {
      var _this = this;
      var onTap = this.props.onTap;
      if (onTap) {
        onTap(ev);
      }
      if (this._lastTouchTimeoutId) {
        this._async.clearTimeout(this._lastTouchTimeoutId);
        this._lastTouchTimeoutId = void 0;
      }
      this._processingTouch = true;
      this._lastTouchTimeoutId = this._async.setTimeout(function() {
        _this._processingTouch = false;
        _this._lastTouchTimeoutId = void 0;
      }, TouchIdleDelay);
    };
    return ContextualMenuSplitButton2;
  }(ContextualMenuItemWrapper)
);

// node_modules/@fluentui/react/lib/utilities/hooks/useResponsiveMode.js
var React21 = __toESM(require_react());

// node_modules/@fluentui/react/lib/utilities/decorators/withResponsiveMode.js
var React20 = __toESM(require_react());

// node_modules/@fluentui/react/lib/utilities/decorators/BaseDecorator.js
var React19 = __toESM(require_react());
var BaseDecorator = (
  /** @class */
  function(_super) {
    __extends(BaseDecorator2, _super);
    function BaseDecorator2(props) {
      var _this = _super.call(this, props) || this;
      _this._updateComposedComponentRef = _this._updateComposedComponentRef.bind(_this);
      return _this;
    }
    BaseDecorator2.prototype._updateComposedComponentRef = function(composedComponentInstance) {
      this._composedComponentInstance = composedComponentInstance;
      if (composedComponentInstance) {
        this._hoisted = hoistMethods(this, composedComponentInstance);
      } else if (this._hoisted) {
        unhoistMethods(this, this._hoisted);
      }
    };
    return BaseDecorator2;
  }(React19.Component)
);

// node_modules/@fluentui/react/lib/utilities/decorators/withResponsiveMode.js
var ResponsiveMode;
(function(ResponsiveMode2) {
  ResponsiveMode2[ResponsiveMode2["small"] = 0] = "small";
  ResponsiveMode2[ResponsiveMode2["medium"] = 1] = "medium";
  ResponsiveMode2[ResponsiveMode2["large"] = 2] = "large";
  ResponsiveMode2[ResponsiveMode2["xLarge"] = 3] = "xLarge";
  ResponsiveMode2[ResponsiveMode2["xxLarge"] = 4] = "xxLarge";
  ResponsiveMode2[ResponsiveMode2["xxxLarge"] = 5] = "xxxLarge";
  ResponsiveMode2[ResponsiveMode2["unknown"] = 999] = "unknown";
})(ResponsiveMode || (ResponsiveMode = {}));
var RESPONSIVE_MAX_CONSTRAINT = [479, 639, 1023, 1365, 1919, 99999999];
var _defaultMode;
var _lastMode;
function setResponsiveMode(responsiveMode) {
  _defaultMode = responsiveMode;
}
function initializeResponsiveMode(element) {
  var currentWindow = getWindow(element);
  if (currentWindow) {
    getResponsiveMode(currentWindow);
  }
}
function getInitialResponsiveMode() {
  var _a3;
  return (_a3 = _defaultMode !== null && _defaultMode !== void 0 ? _defaultMode : _lastMode) !== null && _a3 !== void 0 ? _a3 : ResponsiveMode.large;
}
function withResponsiveMode(ComposedComponent) {
  var _a3;
  var resultClass = (_a3 = /** @class */
  function(_super) {
    __extends(WithResponsiveMode, _super);
    function WithResponsiveMode(props) {
      var _this = _super.call(this, props) || this;
      _this._onResize = function() {
        var responsiveMode = getResponsiveMode(_this.context.window);
        if (responsiveMode !== _this.state.responsiveMode) {
          _this.setState({
            responsiveMode
          });
        }
      };
      _this._events = new EventGroup(_this);
      _this._updateComposedComponentRef = _this._updateComposedComponentRef.bind(_this);
      _this.state = {
        responsiveMode: getInitialResponsiveMode()
      };
      return _this;
    }
    WithResponsiveMode.prototype.componentDidMount = function() {
      this._events.on(this.context.window, "resize", this._onResize);
      this._onResize();
    };
    WithResponsiveMode.prototype.componentWillUnmount = function() {
      this._events.dispose();
    };
    WithResponsiveMode.prototype.render = function() {
      var responsiveMode = this.state.responsiveMode;
      return responsiveMode === ResponsiveMode.unknown ? null : React20.createElement(ComposedComponent, __assign({ ref: this._updateComposedComponentRef, responsiveMode }, this.props));
    };
    return WithResponsiveMode;
  }(BaseDecorator), _a3.contextType = WindowContext, _a3);
  return hoistStatics(ComposedComponent, resultClass);
}
function getWidthOfCurrentWindow(currentWindow) {
  try {
    return currentWindow.document.documentElement.clientWidth;
  } catch (e) {
    return currentWindow.innerWidth;
  }
}
function getResponsiveMode(currentWindow) {
  var responsiveMode = ResponsiveMode.small;
  if (currentWindow) {
    try {
      while (getWidthOfCurrentWindow(currentWindow) > RESPONSIVE_MAX_CONSTRAINT[responsiveMode]) {
        responsiveMode++;
      }
    } catch (e) {
      responsiveMode = getInitialResponsiveMode();
    }
    _lastMode = responsiveMode;
  } else {
    if (_defaultMode !== void 0) {
      responsiveMode = _defaultMode;
    } else {
      throw new Error("Content was rendered in a server environment without providing a default responsive mode. Call setResponsiveMode to define what the responsive mode is.");
    }
  }
  return responsiveMode;
}

// node_modules/@fluentui/react/lib/utilities/hooks/useResponsiveMode.js
var useResponsiveMode = function(elementRef, overrideResponsiveMode) {
  var _a3 = React21.useState(getInitialResponsiveMode()), lastResponsiveMode = _a3[0], setLastResponsiveMode = _a3[1];
  var onResize = React21.useCallback(function() {
    var newResponsiveMode = getResponsiveMode(getWindow(elementRef.current));
    if (lastResponsiveMode !== newResponsiveMode) {
      setLastResponsiveMode(newResponsiveMode);
    }
  }, [elementRef, lastResponsiveMode]);
  var win = useWindow();
  useOnEvent(win, "resize", onResize);
  React21.useEffect(function() {
    if (overrideResponsiveMode === void 0) {
      onResize();
    }
  }, [overrideResponsiveMode]);
  return overrideResponsiveMode !== null && overrideResponsiveMode !== void 0 ? overrideResponsiveMode : lastResponsiveMode;
};

// node_modules/@fluentui/react/lib/utilities/MenuContext/MenuContext.js
var React22 = __toESM(require_react());
var MenuContext = React22.createContext({});

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.base.js
var getClassNames5 = classNamesFunction();
var getContextualMenuItemClassNames = classNamesFunction();
var DEFAULT_PROPS3 = {
  items: [],
  shouldFocusOnMount: true,
  gapSpace: 0,
  directionalHint: DirectionalHint.bottomAutoEdge,
  beakWidth: 16
};
function getSubmenuItems(item, options) {
  var target = options === null || options === void 0 ? void 0 : options.target;
  var items = item.subMenuProps ? item.subMenuProps.items : item.items;
  if (items) {
    var overrideItems = [];
    for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
      var subItem = items_1[_i];
      if (subItem.preferMenuTargetAsEventTarget) {
        var onClick = subItem.onClick, contextItem = __rest(subItem, ["onClick"]);
        overrideItems.push(__assign(__assign({}, contextItem), { onClick: getOnClickWithOverrideTarget(onClick, target) }));
      } else {
        overrideItems.push(subItem);
      }
    }
    return overrideItems;
  }
}
function canAnyMenuItemsCheck(items) {
  return items.some(function(item) {
    if (item.canCheck) {
      return true;
    }
    if (item.sectionProps && item.sectionProps.items.some(function(submenuItem) {
      return submenuItem.canCheck === true;
    })) {
      return true;
    }
    return false;
  });
}
var NavigationIdleDelay = 250;
var COMPONENT_NAME3 = "ContextualMenu";
var _getMenuItemStylesFunction = memoizeFunction(function() {
  var styles = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    styles[_i] = arguments[_i];
  }
  return function(styleProps) {
    return concatStyleSetsWithProps.apply(void 0, __spreadArray([styleProps, getItemStyles], styles));
  };
});
function useVisibility(props, targetWindow) {
  var _a3 = props.hidden, hidden = _a3 === void 0 ? false : _a3, onMenuDismissed = props.onMenuDismissed, onMenuOpened = props.onMenuOpened;
  var previousHidden = usePrevious(hidden);
  var onMenuOpenedRef = React23.useRef(onMenuOpened);
  var onMenuClosedRef = React23.useRef(onMenuDismissed);
  var propsRef = React23.useRef(props);
  onMenuOpenedRef.current = onMenuOpened;
  onMenuClosedRef.current = onMenuDismissed;
  propsRef.current = props;
  React23.useEffect(function() {
    var _a4, _b;
    if (hidden && previousHidden === false) {
      (_a4 = onMenuClosedRef.current) === null || _a4 === void 0 ? void 0 : _a4.call(onMenuClosedRef, propsRef.current);
    } else if (!hidden && previousHidden !== false) {
      (_b = onMenuOpenedRef.current) === null || _b === void 0 ? void 0 : _b.call(onMenuOpenedRef, propsRef.current);
    }
  }, [hidden, previousHidden]);
  React23.useEffect(function() {
    return function() {
      var _a4;
      return (_a4 = onMenuClosedRef.current) === null || _a4 === void 0 ? void 0 : _a4.call(onMenuClosedRef, propsRef.current);
    };
  }, []);
}
function useSubMenuState(_a3, dismiss) {
  var hidden = _a3.hidden, items = _a3.items, theme = _a3.theme, className = _a3.className, id = _a3.id, menuTarget = _a3.target;
  var _b = React23.useState(), expandedMenuItemKey = _b[0], setExpandedMenuItemKey = _b[1];
  var _c = React23.useState(), submenuTarget = _c[0], setSubmenuTarget = _c[1];
  var _d = React23.useState(), shouldFocusOnContainer = _d[0], setShouldFocusOnContainer = _d[1];
  var subMenuId = useId(COMPONENT_NAME3, id);
  var closeSubMenu = React23.useCallback(function() {
    setShouldFocusOnContainer(void 0);
    setExpandedMenuItemKey(void 0);
    setSubmenuTarget(void 0);
  }, []);
  var openSubMenu = React23.useCallback(function(_a4, target, focusContainer) {
    var submenuItemKey = _a4.key;
    if (expandedMenuItemKey === submenuItemKey) {
      return;
    }
    target.focus();
    setShouldFocusOnContainer(focusContainer);
    setExpandedMenuItemKey(submenuItemKey);
    setSubmenuTarget(target);
  }, [expandedMenuItemKey]);
  React23.useEffect(function() {
    if (hidden) {
      closeSubMenu();
    }
  }, [hidden, closeSubMenu]);
  var onSubMenuDismiss = useOnSubmenuDismiss(dismiss, closeSubMenu);
  var getSubmenuProps = function() {
    var item = findItemByKeyFromItems(expandedMenuItemKey, items);
    var submenuProps = null;
    if (item) {
      submenuProps = {
        items: getSubmenuItems(item, { target: menuTarget }),
        target: submenuTarget,
        onDismiss: onSubMenuDismiss,
        isSubMenu: true,
        id: subMenuId,
        shouldFocusOnMount: true,
        shouldFocusOnContainer,
        directionalHint: getRTL(theme) ? DirectionalHint.leftTopEdge : DirectionalHint.rightTopEdge,
        className,
        gapSpace: 0,
        isBeakVisible: false
      };
      if (item.subMenuProps) {
        assign(submenuProps, item.subMenuProps);
      }
      if (item.preferMenuTargetAsEventTarget) {
        var onItemClick = item.onItemClick;
        submenuProps.onItemClick = getOnClickWithOverrideTarget(onItemClick, menuTarget);
      }
    }
    return submenuProps;
  };
  return [expandedMenuItemKey, openSubMenu, getSubmenuProps, onSubMenuDismiss];
}
function useShouldUpdateFocusOnMouseMove(_a3) {
  var delayUpdateFocusOnHover = _a3.delayUpdateFocusOnHover, hidden = _a3.hidden;
  var shouldUpdateFocusOnMouseEvent = React23.useRef(!delayUpdateFocusOnHover);
  var gotMouseMove = React23.useRef(false);
  React23.useEffect(function() {
    shouldUpdateFocusOnMouseEvent.current = !delayUpdateFocusOnHover;
    gotMouseMove.current = hidden ? false : !delayUpdateFocusOnHover && gotMouseMove.current;
  }, [delayUpdateFocusOnHover, hidden]);
  var onMenuFocusCapture = React23.useCallback(function() {
    if (delayUpdateFocusOnHover) {
      shouldUpdateFocusOnMouseEvent.current = false;
    }
  }, [delayUpdateFocusOnHover]);
  return [shouldUpdateFocusOnMouseEvent, gotMouseMove, onMenuFocusCapture];
}
function usePreviousActiveElement(_a3, targetWindow, hostElement) {
  var hidden = _a3.hidden, onRestoreFocus = _a3.onRestoreFocus;
  var previousActiveElement = React23.useRef();
  var tryFocusPreviousActiveElement = React23.useCallback(function(options) {
    var _a4, _b;
    if (onRestoreFocus) {
      onRestoreFocus(options);
    } else if (options === null || options === void 0 ? void 0 : options.documentContainsFocus) {
      (_b = (_a4 = previousActiveElement.current) === null || _a4 === void 0 ? void 0 : _a4.focus) === null || _b === void 0 ? void 0 : _b.call(_a4);
    }
  }, [onRestoreFocus]);
  useIsomorphicLayoutEffect(function() {
    var _a4, _b;
    if (!hidden) {
      var newElement = targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.document.activeElement;
      if (!((_a4 = hostElement.current) === null || _a4 === void 0 ? void 0 : _a4.contains(newElement)) && newElement.tagName !== "BODY") {
        previousActiveElement.current = newElement;
      }
    } else if (previousActiveElement.current) {
      tryFocusPreviousActiveElement({
        originalElement: previousActiveElement.current,
        containsFocus: true,
        documentContainsFocus: ((_b = getDocument()) === null || _b === void 0 ? void 0 : _b.hasFocus()) || false
      });
      previousActiveElement.current = void 0;
    }
  }, [hidden, targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.document.activeElement, tryFocusPreviousActiveElement, hostElement]);
  return [tryFocusPreviousActiveElement];
}
function useKeyHandlers(_a3, dismiss, hostElement, openSubMenu) {
  var theme = _a3.theme, isSubMenu = _a3.isSubMenu, _b = _a3.focusZoneProps, _c = _b === void 0 ? {} : _b, checkForNoWrap = _c.checkForNoWrap, _d = _c.direction, focusZoneDirection = _d === void 0 ? FocusZoneDirection.vertical : _d;
  var lastKeyDownWasAltOrMeta = React23.useRef();
  var keyHandler = function(ev, shouldHandleKey, dismissAllMenus) {
    var handled = false;
    if (shouldHandleKey(ev)) {
      dismiss(ev, dismissAllMenus);
      ev.preventDefault();
      ev.stopPropagation();
      handled = true;
    }
    return handled;
  };
  var shouldCloseSubMenu = function(ev) {
    var submenuCloseKey = getRTL(theme) ? KeyCodes.right : KeyCodes.left;
    if (ev.which !== submenuCloseKey || !isSubMenu) {
      return false;
    }
    return !!(focusZoneDirection === FocusZoneDirection.vertical || checkForNoWrap && !shouldWrapFocus(ev.target, "data-no-horizontal-wrap"));
  };
  var shouldHandleKeyDown = function(ev) {
    return (
      // eslint-disable-next-line deprecation/deprecation
      ev.which === KeyCodes.escape || shouldCloseSubMenu(ev) || // eslint-disable-next-line deprecation/deprecation
      ev.which === KeyCodes.up && (ev.altKey || ev.metaKey)
    );
  };
  var onKeyDown = function(ev) {
    lastKeyDownWasAltOrMeta.current = isAltOrMeta(ev);
    var dismissAllMenus = ev.which === KeyCodes.escape && (isMac() || isIOS());
    return keyHandler(ev, shouldHandleKeyDown, dismissAllMenus);
  };
  var shouldHandleKeyUp = function(ev) {
    var keyPressIsAltOrMetaAlone = lastKeyDownWasAltOrMeta.current && isAltOrMeta(ev);
    lastKeyDownWasAltOrMeta.current = false;
    return !!keyPressIsAltOrMetaAlone && !(isIOS() || isMac());
  };
  var onKeyUp = function(ev) {
    return keyHandler(
      ev,
      shouldHandleKeyUp,
      true
      /* dismissAllMenus */
    );
  };
  var onMenuKeyDown = function(ev) {
    var handled = onKeyDown(ev);
    if (handled || !hostElement.current) {
      return;
    }
    var hasModifier = !!(ev.altKey || ev.metaKey);
    var isUp = ev.which === KeyCodes.up;
    var isDown = ev.which === KeyCodes.down;
    if (!hasModifier && (isUp || isDown)) {
      var elementToFocus = isUp ? getLastFocusable(hostElement.current, hostElement.current.lastChild, true) : getFirstFocusable(hostElement.current, hostElement.current.firstChild, true);
      if (elementToFocus) {
        elementToFocus.focus();
        ev.preventDefault();
        ev.stopPropagation();
      }
    }
  };
  var onItemKeyDown = function(item, ev) {
    var openKey = getRTL(theme) ? KeyCodes.left : KeyCodes.right;
    if (!item.disabled && // eslint-disable-next-line deprecation/deprecation
    (ev.which === openKey || ev.which === KeyCodes.enter || ev.which === KeyCodes.down && (ev.altKey || ev.metaKey))) {
      openSubMenu(item, ev.currentTarget);
      ev.preventDefault();
    }
  };
  return [onKeyDown, onKeyUp, onMenuKeyDown, onItemKeyDown];
}
function useScrollHandler(asyncTracker) {
  var isScrollIdle = React23.useRef(true);
  var scrollIdleTimeoutId = React23.useRef();
  var onScroll = function() {
    if (!isScrollIdle.current && scrollIdleTimeoutId.current !== void 0) {
      asyncTracker.clearTimeout(scrollIdleTimeoutId.current);
      scrollIdleTimeoutId.current = void 0;
    } else {
      isScrollIdle.current = false;
    }
    scrollIdleTimeoutId.current = asyncTracker.setTimeout(function() {
      isScrollIdle.current = true;
    }, NavigationIdleDelay);
  };
  return [onScroll, isScrollIdle];
}
function useOnSubmenuDismiss(dismiss, closeSubMenu) {
  var isMountedRef = React23.useRef(false);
  React23.useEffect(function() {
    isMountedRef.current = true;
    return function() {
      isMountedRef.current = false;
    };
  }, []);
  var onSubMenuDismiss = function(ev, dismissAll) {
    if (dismissAll) {
      dismiss(ev, dismissAll);
    } else if (isMountedRef.current) {
      closeSubMenu();
    }
  };
  return onSubMenuDismiss;
}
function useSubmenuEnterTimer(_a3, asyncTracker) {
  var _b = _a3.subMenuHoverDelay, subMenuHoverDelay = _b === void 0 ? NavigationIdleDelay : _b;
  var enterTimerRef = React23.useRef(void 0);
  var cancelSubMenuTimer = function() {
    if (enterTimerRef.current !== void 0) {
      asyncTracker.clearTimeout(enterTimerRef.current);
      enterTimerRef.current = void 0;
    }
  };
  var startSubmenuTimer = function(onTimerExpired) {
    enterTimerRef.current = asyncTracker.setTimeout(function() {
      onTimerExpired();
      cancelSubMenuTimer();
    }, subMenuHoverDelay);
  };
  return [cancelSubMenuTimer, startSubmenuTimer, enterTimerRef];
}
function useMouseHandlers(props, isScrollIdle, subMenuEntryTimer, targetWindow, shouldUpdateFocusOnMouseEvent, gotMouseMove, expandedMenuItemKey, hostElement, startSubmenuTimer, cancelSubMenuTimer, openSubMenu, onSubMenuDismiss, dismiss) {
  var menuTarget = props.target;
  var onItemMouseEnterBase = function(item, ev, target) {
    if (shouldUpdateFocusOnMouseEvent.current) {
      gotMouseMove.current = true;
    }
    if (shouldIgnoreMouseEvent()) {
      return;
    }
    updateFocusOnMouseEvent(item, ev, target);
  };
  var onItemMouseMoveBase = function(item, ev, target) {
    var targetElement = ev.currentTarget;
    if (shouldUpdateFocusOnMouseEvent.current) {
      gotMouseMove.current = true;
    } else {
      return;
    }
    if (!isScrollIdle.current || subMenuEntryTimer.current !== void 0 || targetElement === (targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.document.activeElement)) {
      return;
    }
    updateFocusOnMouseEvent(item, ev, target);
  };
  var shouldIgnoreMouseEvent = function() {
    return !isScrollIdle.current || !gotMouseMove.current;
  };
  var onMouseItemLeave = function(item, ev) {
    var _a3;
    if (shouldIgnoreMouseEvent()) {
      return;
    }
    cancelSubMenuTimer();
    if (expandedMenuItemKey !== void 0) {
      return;
    }
    if (hostElement.current.setActive) {
      try {
        hostElement.current.setActive();
      } catch (e) {
      }
    } else {
      (_a3 = hostElement.current) === null || _a3 === void 0 ? void 0 : _a3.focus();
    }
  };
  var updateFocusOnMouseEvent = function(item, ev, target) {
    var targetElement = target ? target : ev.currentTarget;
    if (item.key === expandedMenuItemKey) {
      return;
    }
    cancelSubMenuTimer();
    if (expandedMenuItemKey === void 0) {
      targetElement.focus();
    }
    if (hasSubmenu(item)) {
      ev.stopPropagation();
      startSubmenuTimer(function() {
        targetElement.focus();
        openSubMenu(item, targetElement, true);
      });
    } else {
      startSubmenuTimer(function() {
        onSubMenuDismiss(ev);
        targetElement.focus();
      });
    }
  };
  var onItemClick = function(item, ev) {
    onItemClickBase(item, ev, ev.currentTarget);
  };
  var onItemClickBase = function(item, ev, target) {
    var items = getSubmenuItems(item, { target: menuTarget });
    cancelSubMenuTimer();
    if (!hasSubmenu(item) && (!items || !items.length)) {
      executeItemClick(item, ev);
    } else {
      if (item.key !== expandedMenuItemKey) {
        var shouldFocusOnContainer = typeof props.shouldFocusOnContainer === "boolean" ? props.shouldFocusOnContainer : ev.nativeEvent.pointerType === "mouse";
        openSubMenu(item, target, shouldFocusOnContainer);
      }
    }
    ev.stopPropagation();
    ev.preventDefault();
  };
  var onAnchorClick = function(item, ev) {
    executeItemClick(item, ev);
    ev.stopPropagation();
  };
  var executeItemClick = function(item, ev) {
    if (item.disabled || item.isDisabled) {
      return;
    }
    if (item.preferMenuTargetAsEventTarget) {
      overrideTarget(ev, menuTarget);
    }
    var shouldDismiss = false;
    if (item.onClick) {
      shouldDismiss = !!item.onClick(ev, item);
    } else if (props.onItemClick) {
      shouldDismiss = !!props.onItemClick(ev, item);
    }
    if (shouldDismiss || !ev.defaultPrevented) {
      dismiss(ev, true);
    }
  };
  return [
    onItemMouseEnterBase,
    onItemMouseMoveBase,
    onMouseItemLeave,
    onItemClick,
    onAnchorClick,
    executeItemClick,
    onItemClickBase
  ];
}
var ContextualMenuBase = React23.memo(React23.forwardRef(function(propsWithoutDefaults, forwardedRef) {
  var _a3;
  var _b = getPropsWithDefaults(DEFAULT_PROPS3, propsWithoutDefaults), ref = _b.ref, props = __rest(_b, ["ref"]);
  var hostElement = React23.useRef(null);
  var asyncTracker = useAsync();
  var menuId = useId(COMPONENT_NAME3, props.id);
  useWarnings({
    name: COMPONENT_NAME3,
    props,
    deprecations: {
      getMenuClassNames: "styles"
    }
  });
  var dismiss = function(ev, dismissAll) {
    var _a4;
    return (_a4 = props.onDismiss) === null || _a4 === void 0 ? void 0 : _a4.call(props, ev, dismissAll);
  };
  var _c = useTarget(props.target, hostElement), targetRef = _c[0], targetWindow = _c[1];
  var tryFocusPreviousActiveElement = usePreviousActiveElement(props, targetWindow, hostElement)[0];
  var _d = useSubMenuState(props, dismiss), expandedMenuItemKey = _d[0], openSubMenu = _d[1], getSubmenuProps = _d[2], onSubMenuDismiss = _d[3];
  var _e = useShouldUpdateFocusOnMouseMove(props), shouldUpdateFocusOnMouseEvent = _e[0], gotMouseMove = _e[1], onMenuFocusCapture = _e[2];
  var _f = useScrollHandler(asyncTracker), onScroll = _f[0], isScrollIdle = _f[1];
  var _g = useSubmenuEnterTimer(props, asyncTracker), cancelSubMenuTimer = _g[0], startSubmenuTimer = _g[1], subMenuEntryTimer = _g[2];
  var responsiveMode = useResponsiveMode(hostElement, props.responsiveMode);
  useVisibility(props, targetWindow);
  var _h = useKeyHandlers(props, dismiss, hostElement, openSubMenu), onKeyDown = _h[0], onKeyUp = _h[1], onMenuKeyDown = _h[2], onItemKeyDown = _h[3];
  var _j = useMouseHandlers(props, isScrollIdle, subMenuEntryTimer, targetWindow, shouldUpdateFocusOnMouseEvent, gotMouseMove, expandedMenuItemKey, hostElement, startSubmenuTimer, cancelSubMenuTimer, openSubMenu, onSubMenuDismiss, dismiss), onItemMouseEnterBase = _j[0], onItemMouseMoveBase = _j[1], onMouseItemLeave = _j[2], onItemClick = _j[3], onAnchorClick = _j[4], executeItemClick = _j[5], onItemClickBase = _j[6];
  var onDefaultRenderMenuList = function(menuListProps, menuClassNames, defaultRender) {
    var indexCorrection = 0;
    var items2 = menuListProps.items, totalItemCount = menuListProps.totalItemCount, hasCheckmarks2 = menuListProps.hasCheckmarks, hasIcons2 = menuListProps.hasIcons;
    return React23.createElement("ul", { className: menuClassNames.list, onKeyDown, onKeyUp, role: "presentation" }, items2.map(function(item2, index) {
      var menuItem = renderMenuItem(item2, index, indexCorrection, totalItemCount, hasCheckmarks2, hasIcons2, menuClassNames);
      if (item2.itemType !== ContextualMenuItemType.Divider && item2.itemType !== ContextualMenuItemType.Header) {
        var indexIncrease = item2.customOnRenderListLength ? item2.customOnRenderListLength : 1;
        indexCorrection += indexIncrease;
      }
      return menuItem;
    }));
  };
  var renderFocusZone = function(children, adjustedFocusZoneProps2) {
    var _a4 = props.focusZoneAs, ChildrenRenderer = _a4 === void 0 ? FocusZone : _a4;
    return React23.createElement(ChildrenRenderer, __assign({}, adjustedFocusZoneProps2), children);
  };
  var renderMenuItem = function(item2, index, focusableElementIndex, totalItemCount, hasCheckmarks2, hasIcons2, menuClassNames) {
    var _a4;
    var renderedItems = [];
    var iconProps = item2.iconProps || { iconName: "None" };
    var getItemClassNames2 = item2.getItemClassNames, itemProps = item2.itemProps;
    var styles2 = itemProps ? itemProps.styles : void 0;
    var dividerClassName = item2.itemType === ContextualMenuItemType.Divider ? item2.className : void 0;
    var subMenuIconClassName = item2.submenuIconProps ? item2.submenuIconProps.className : "";
    var itemClassNames;
    if (getItemClassNames2) {
      itemClassNames = getItemClassNames2(props.theme, isItemDisabled(item2), expandedMenuItemKey === item2.key, !!getIsChecked(item2), !!item2.href, iconProps.iconName !== "None", item2.className, dividerClassName, iconProps.className, subMenuIconClassName, item2.primaryDisabled);
    } else {
      var itemStyleProps = {
        theme: props.theme,
        disabled: isItemDisabled(item2),
        expanded: expandedMenuItemKey === item2.key,
        checked: !!getIsChecked(item2),
        isAnchorLink: !!item2.href,
        knownIcon: iconProps.iconName !== "None",
        itemClassName: item2.className,
        dividerClassName,
        iconClassName: iconProps.className,
        subMenuClassName: subMenuIconClassName,
        primaryDisabled: item2.primaryDisabled
      };
      itemClassNames = getContextualMenuItemClassNames(_getMenuItemStylesFunction((_a4 = menuClassNames.subComponentStyles) === null || _a4 === void 0 ? void 0 : _a4.menuItem, styles2), itemStyleProps);
    }
    if (item2.text === "-" || item2.name === "-") {
      item2.itemType = ContextualMenuItemType.Divider;
    }
    switch (item2.itemType) {
      case ContextualMenuItemType.Divider:
        renderedItems.push(renderSeparator(index, itemClassNames));
        break;
      case ContextualMenuItemType.Header:
        renderedItems.push(renderSeparator(index, itemClassNames));
        var headerItem = renderHeaderMenuItem(item2, itemClassNames, menuClassNames, index, hasCheckmarks2, hasIcons2);
        renderedItems.push(renderListItem(headerItem, item2.key || index, itemClassNames, item2.title));
        break;
      case ContextualMenuItemType.Section:
        renderedItems.push(renderSectionItem(item2, itemClassNames, menuClassNames, index, hasCheckmarks2, hasIcons2));
        break;
      default:
        var defaultRenderNormalItem = function() {
          return renderNormalItem(item2, itemClassNames, index, focusableElementIndex, totalItemCount, hasCheckmarks2, hasIcons2);
        };
        var menuItem = props.onRenderContextualMenuItem ? props.onRenderContextualMenuItem(item2, defaultRenderNormalItem) : defaultRenderNormalItem();
        renderedItems.push(renderListItem(menuItem, item2.key || index, itemClassNames, item2.title));
        break;
    }
    return React23.createElement(React23.Fragment, { key: item2.key }, renderedItems);
  };
  var defaultMenuItemRenderer = function(item2, menuClassNames) {
    var index = item2.index, focusableElementIndex = item2.focusableElementIndex, totalItemCount = item2.totalItemCount, hasCheckmarks2 = item2.hasCheckmarks, hasIcons2 = item2.hasIcons;
    return renderMenuItem(item2, index, focusableElementIndex, totalItemCount, hasCheckmarks2, hasIcons2, menuClassNames);
  };
  var renderSectionItem = function(sectionItem, itemClassNames, menuClassNames, index, hasCheckmarks2, hasIcons2) {
    var sectionProps = sectionItem.sectionProps;
    if (!sectionProps) {
      return;
    }
    var headerItem;
    var groupProps;
    if (sectionProps.title) {
      var headerContextualMenuItem = void 0;
      var ariaLabelledby = "";
      if (typeof sectionProps.title === "string") {
        var id_1 = menuId + sectionProps.title.replace(/\s/g, "");
        headerContextualMenuItem = {
          key: "section-" + sectionProps.title + "-title",
          itemType: ContextualMenuItemType.Header,
          text: sectionProps.title,
          id: id_1
        };
        ariaLabelledby = id_1;
      } else {
        var id_2 = sectionProps.title.id || menuId + sectionProps.title.key.replace(/\s/g, "");
        headerContextualMenuItem = __assign(__assign({}, sectionProps.title), { id: id_2 });
        ariaLabelledby = id_2;
      }
      if (headerContextualMenuItem) {
        groupProps = {
          role: "group",
          "aria-labelledby": ariaLabelledby
        };
        headerItem = renderHeaderMenuItem(headerContextualMenuItem, itemClassNames, menuClassNames, index, hasCheckmarks2, hasIcons2);
      }
    }
    if (sectionProps.items && sectionProps.items.length > 0) {
      return React23.createElement(
        "li",
        { role: "presentation", key: sectionProps.key || sectionItem.key || "section-" + index },
        React23.createElement(
          "div",
          __assign({}, groupProps),
          React23.createElement(
            "ul",
            { className: menuClassNames.list, role: "presentation" },
            sectionProps.topDivider && renderSeparator(index, itemClassNames, true, true),
            headerItem && renderListItem(headerItem, sectionItem.key || index, itemClassNames, sectionItem.title),
            sectionProps.items.map(function(contextualMenuItem, itemsIndex) {
              return renderMenuItem(contextualMenuItem, itemsIndex, itemsIndex, sectionProps.items.length, hasCheckmarks2, hasIcons2, menuClassNames);
            }),
            sectionProps.bottomDivider && renderSeparator(index, itemClassNames, false, true)
          )
        )
      );
    }
  };
  var renderListItem = function(content, key, classNames2, title2) {
    return React23.createElement("li", { role: "presentation", title: title2, key, className: classNames2.item }, content);
  };
  var renderSeparator = function(index, classNames2, top, fromSection) {
    if (fromSection || index > 0) {
      return React23.createElement("li", { role: "separator", key: "separator-" + index + (top === void 0 ? "" : top ? "-top" : "-bottom"), className: classNames2.divider, "aria-hidden": "true" });
    }
    return null;
  };
  var renderNormalItem = function(item2, classNames2, index, focusableElementIndex, totalItemCount, hasCheckmarks2, hasIcons2) {
    if (item2.onRender) {
      return item2.onRender(__assign({ "aria-posinset": focusableElementIndex + 1, "aria-setsize": totalItemCount }, item2), dismiss);
    }
    var contextualMenuItemAs = props.contextualMenuItemAs;
    var commonProps = {
      item: item2,
      classNames: classNames2,
      index,
      focusableElementIndex,
      totalItemCount,
      hasCheckmarks: hasCheckmarks2,
      hasIcons: hasIcons2,
      contextualMenuItemAs,
      onItemMouseEnter: onItemMouseEnterBase,
      onItemMouseLeave: onMouseItemLeave,
      onItemMouseMove: onItemMouseMoveBase,
      onItemMouseDown,
      executeItemClick,
      onItemKeyDown,
      expandedMenuItemKey,
      openSubMenu,
      dismissSubMenu: onSubMenuDismiss,
      dismissMenu: dismiss
    };
    if (item2.href) {
      return React23.createElement(ContextualMenuAnchor, __assign({}, commonProps, { onItemClick: onAnchorClick }));
    }
    if (item2.split && hasSubmenu(item2)) {
      return React23.createElement(ContextualMenuSplitButton, __assign({}, commonProps, { onItemClick, onItemClickBase, onTap: cancelSubMenuTimer }));
    }
    return React23.createElement(ContextualMenuButton, __assign({}, commonProps, { onItemClick, onItemClickBase }));
  };
  var renderHeaderMenuItem = function(item2, itemClassNames, menuClassNames, index, hasCheckmarks2, hasIcons2) {
    var _a4 = props.contextualMenuItemAs, ChildrenRenderer = _a4 === void 0 ? ContextualMenuItem : _a4;
    var itemProps = item2.itemProps, id2 = item2.id;
    var divHtmlProperties = itemProps && getNativeProps(itemProps, divProperties);
    return (
      // eslint-disable-next-line deprecation/deprecation
      React23.createElement(
        "div",
        __assign({ id: id2, className: menuClassNames.header }, divHtmlProperties, { style: item2.style }),
        React23.createElement(ChildrenRenderer, __assign({ item: item2, classNames: itemClassNames, index, onCheckmarkClick: hasCheckmarks2 ? onItemClick : void 0, hasIcons: hasIcons2 }, itemProps))
      )
    );
  };
  var isBeakVisible = props.isBeakVisible;
  var items = props.items, labelElementId = props.labelElementId, id = props.id, className = props.className, beakWidth = props.beakWidth, directionalHint = props.directionalHint, directionalHintForRTL = props.directionalHintForRTL, alignTargetEdge = props.alignTargetEdge, gapSpace = props.gapSpace, coverTarget = props.coverTarget, ariaLabel = props.ariaLabel, doNotLayer = props.doNotLayer, target = props.target, bounds = props.bounds, useTargetWidth = props.useTargetWidth, useTargetAsMinWidth = props.useTargetAsMinWidth, directionalHintFixed = props.directionalHintFixed, shouldFocusOnMount = props.shouldFocusOnMount, shouldFocusOnContainer = props.shouldFocusOnContainer, title = props.title, styles = props.styles, theme = props.theme, calloutProps = props.calloutProps, _k = props.onRenderSubMenu, onRenderSubMenu2 = _k === void 0 ? onDefaultRenderSubMenu : _k, _l = props.onRenderMenuList, onRenderMenuList = _l === void 0 ? function(menuListProps, defaultRender) {
    return onDefaultRenderMenuList(menuListProps, classNames, defaultRender);
  } : _l, focusZoneProps = props.focusZoneProps, getMenuClassNames = props.getMenuClassNames;
  var classNames = getMenuClassNames ? getMenuClassNames(theme, className) : getClassNames5(styles, {
    theme,
    className
  });
  var hasIcons = itemsHaveIcons(items);
  function itemsHaveIcons(contextualMenuItems) {
    for (var _i2 = 0, contextualMenuItems_1 = contextualMenuItems; _i2 < contextualMenuItems_1.length; _i2++) {
      var item2 = contextualMenuItems_1[_i2];
      if (item2.iconProps) {
        return true;
      }
      if (item2.itemType === ContextualMenuItemType.Section && item2.sectionProps && itemsHaveIcons(item2.sectionProps.items)) {
        return true;
      }
    }
    return false;
  }
  var adjustedFocusZoneProps = __assign(__assign({ direction: FocusZoneDirection.vertical, handleTabKey: FocusZoneTabbableElements.all, isCircularNavigation: true }, focusZoneProps), { className: css(classNames.root, (_a3 = props.focusZoneProps) === null || _a3 === void 0 ? void 0 : _a3.className) });
  var hasCheckmarks = canAnyMenuItemsCheck(items);
  var submenuProps = expandedMenuItemKey && props.hidden !== true ? getSubmenuProps() : null;
  isBeakVisible = isBeakVisible === void 0 ? responsiveMode <= ResponsiveMode.medium : isBeakVisible;
  var contextMenuStyle;
  var targetAsHtmlElement = targetRef.current;
  if ((useTargetWidth || useTargetAsMinWidth) && targetAsHtmlElement && targetAsHtmlElement.offsetWidth) {
    var targetBoundingRect = targetAsHtmlElement.getBoundingClientRect();
    var targetWidth = targetBoundingRect.width - 2;
    if (useTargetWidth) {
      contextMenuStyle = {
        width: targetWidth
      };
    } else if (useTargetAsMinWidth) {
      contextMenuStyle = {
        minWidth: targetWidth
      };
    }
  }
  if (items && items.length > 0) {
    var totalItemCount_1 = 0;
    for (var _i = 0, items_2 = items; _i < items_2.length; _i++) {
      var item = items_2[_i];
      if (item.itemType !== ContextualMenuItemType.Divider && item.itemType !== ContextualMenuItemType.Header) {
        var itemCount = item.customOnRenderListLength ? item.customOnRenderListLength : 1;
        totalItemCount_1 += itemCount;
      }
    }
    var calloutStyles_1 = classNames.subComponentStyles ? classNames.subComponentStyles.callout : void 0;
    return React23.createElement(MenuContext.Consumer, null, function(menuContext) {
      return React23.createElement(
        Callout,
        __assign({ styles: calloutStyles_1, onRestoreFocus: tryFocusPreviousActiveElement }, calloutProps, { target: target || menuContext.target, isBeakVisible, beakWidth, directionalHint, directionalHintForRTL, gapSpace, coverTarget, doNotLayer, className: css("ms-ContextualMenu-Callout", calloutProps && calloutProps.className), setInitialFocus: shouldFocusOnMount, onDismiss: props.onDismiss || menuContext.onDismiss, onScroll, bounds, directionalHintFixed, alignTargetEdge, hidden: props.hidden || menuContext.hidden, ref: forwardedRef }),
        React23.createElement(
          "div",
          { style: contextMenuStyle, ref: hostElement, id, className: classNames.container, tabIndex: shouldFocusOnContainer ? 0 : -1, onKeyDown: onMenuKeyDown, onKeyUp, onFocusCapture: onMenuFocusCapture, "aria-label": ariaLabel, "aria-labelledby": labelElementId, role: "menu" },
          title && React23.createElement(
            "div",
            { className: classNames.title },
            " ",
            title,
            " "
          ),
          items && items.length ? renderFocusZone(onRenderMenuList({
            ariaLabel,
            items,
            totalItemCount: totalItemCount_1,
            hasCheckmarks,
            hasIcons,
            defaultMenuItemRenderer: function(item2) {
              return defaultMenuItemRenderer(item2, classNames);
            },
            labelElementId
          }, function(menuListProps, defaultRender) {
            return onDefaultRenderMenuList(menuListProps, classNames, defaultRender);
          }), adjustedFocusZoneProps) : null,
          submenuProps && onRenderSubMenu2(submenuProps, onDefaultRenderSubMenu)
        ),
        React23.createElement(FocusRects, null)
      );
    });
  } else {
    return null;
  }
}), function(prevProps, newProps) {
  if (!newProps.shouldUpdateWhenHidden && prevProps.hidden && newProps.hidden) {
    return true;
  }
  return shallowCompare(prevProps, newProps);
});
ContextualMenuBase.displayName = "ContextualMenuBase";
function isAltOrMeta(ev) {
  return ev.which === KeyCodes.alt || ev.key === "Meta";
}
function onItemMouseDown(item, ev) {
  var _a3;
  (_a3 = item.onMouseDown) === null || _a3 === void 0 ? void 0 : _a3.call(item, item, ev);
}
function onDefaultRenderSubMenu(subMenuProps, defaultRender) {
  throw Error("ContextualMenuBase: onRenderSubMenu callback is null or undefined. Please ensure to set `onRenderSubMenu` property either manually or with `styled` helper.");
}
function findItemByKeyFromItems(key, items) {
  for (var _i = 0, items_3 = items; _i < items_3.length; _i++) {
    var item = items_3[_i];
    if (item.itemType === ContextualMenuItemType.Section && item.sectionProps) {
      var match = findItemByKeyFromItems(key, item.sectionProps.items);
      if (match) {
        return match;
      }
    } else if (item.key && item.key === key) {
      return item;
    }
  }
}
function getOnClickWithOverrideTarget(onClick, target) {
  return onClick ? function(ev, item) {
    overrideTarget(ev, target);
    return onClick(ev, item);
  } : onClick;
}
function overrideTarget(ev, target) {
  if (ev && target) {
    ev.persist();
    if (target instanceof Event) {
      ev.target = target.target;
    } else if (target instanceof Element) {
      ev.target = target;
    }
  }
}

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.styles.js
var GlobalClassNames5 = {
  root: "ms-ContextualMenu",
  container: "ms-ContextualMenu-container",
  list: "ms-ContextualMenu-list",
  header: "ms-ContextualMenu-header",
  title: "ms-ContextualMenu-title",
  isopen: "is-open"
};
var getStyles5 = function(props) {
  var className = props.className, theme = props.theme;
  var classNames = getGlobalClassNames(GlobalClassNames5, theme);
  var fonts = theme.fonts, semanticColors = theme.semanticColors, effects = theme.effects;
  return {
    root: [
      theme.fonts.medium,
      classNames.root,
      classNames.isopen,
      {
        backgroundColor: semanticColors.menuBackground,
        minWidth: "180px"
      },
      className
    ],
    container: [
      classNames.container,
      {
        selectors: {
          ":focus": { outline: 0 }
        }
      }
    ],
    list: [
      classNames.list,
      classNames.isopen,
      {
        listStyleType: "none",
        margin: "0",
        padding: "0"
      }
    ],
    header: [
      classNames.header,
      fonts.small,
      {
        fontWeight: FontWeights.semibold,
        color: semanticColors.menuHeader,
        background: "none",
        backgroundColor: "transparent",
        border: "none",
        height: CONTEXTUAL_MENU_ITEM_HEIGHT,
        lineHeight: CONTEXTUAL_MENU_ITEM_HEIGHT,
        cursor: "default",
        padding: "0px 6px",
        userSelect: "none",
        textAlign: "left"
      }
    ],
    title: [
      classNames.title,
      {
        fontSize: fonts.mediumPlus.fontSize,
        paddingRight: "14px",
        paddingLeft: "14px",
        paddingBottom: "5px",
        paddingTop: "5px",
        backgroundColor: semanticColors.menuItemBackgroundPressed
      }
    ],
    subComponentStyles: {
      callout: {
        root: {
          boxShadow: effects.elevation8
        }
      },
      menuItem: {}
    }
  };
};

// node_modules/@fluentui/react/lib/components/ContextualMenu/ContextualMenu.js
function onRenderSubMenu(subMenuProps) {
  return React24.createElement(LocalContextualMenu, __assign({}, subMenuProps));
}
var LocalContextualMenu = styled(ContextualMenuBase, getStyles5, function(props) {
  return {
    onRenderSubMenu: props.onRenderSubMenu ? composeRenderFunction(props.onRenderSubMenu, onRenderSubMenu) : onRenderSubMenu
  };
}, { scope: "ContextualMenu" });
var ContextualMenu = LocalContextualMenu;
ContextualMenu.displayName = "ContextualMenu";

// node_modules/@fluentui/react/lib/components/Button/BaseButton.classNames.js
var ButtonGlobalClassNames = {
  msButton: "ms-Button",
  msButtonHasMenu: "ms-Button--hasMenu",
  msButtonIcon: "ms-Button-icon",
  msButtonMenuIcon: "ms-Button-menuIcon",
  msButtonLabel: "ms-Button-label",
  msButtonDescription: "ms-Button-description",
  msButtonScreenReaderText: "ms-Button-screenReaderText",
  msButtonFlexContainer: "ms-Button-flexContainer",
  msButtonTextContainer: "ms-Button-textContainer"
};
var getBaseButtonClassNames = memoizeFunction(function(theme, styles, className, variantClassName, iconClassName, menuIconClassName, disabled, hasMenu, checked, expanded, isSplit) {
  var _a3, _b;
  var classNames = getGlobalClassNames(ButtonGlobalClassNames, theme || {});
  var isExpanded = expanded && !isSplit;
  return mergeStyleSets({
    root: [
      classNames.msButton,
      styles.root,
      variantClassName,
      checked && ["is-checked", styles.rootChecked],
      isExpanded && [
        "is-expanded",
        styles.rootExpanded,
        {
          selectors: (_a3 = {}, _a3[":hover ." + classNames.msButtonIcon] = styles.iconExpandedHovered, // menuIcon falls back to rootExpandedHovered to support original behavior
          _a3[":hover ." + classNames.msButtonMenuIcon] = styles.menuIconExpandedHovered || styles.rootExpandedHovered, _a3[":hover"] = styles.rootExpandedHovered, _a3)
        }
      ],
      hasMenu && [ButtonGlobalClassNames.msButtonHasMenu, styles.rootHasMenu],
      disabled && ["is-disabled", styles.rootDisabled],
      !disabled && !isExpanded && !checked && {
        selectors: (_b = {
          ":hover": styles.rootHovered
        }, _b[":hover ." + classNames.msButtonLabel] = styles.labelHovered, _b[":hover ." + classNames.msButtonIcon] = styles.iconHovered, _b[":hover ." + classNames.msButtonDescription] = styles.descriptionHovered, _b[":hover ." + classNames.msButtonMenuIcon] = styles.menuIconHovered, _b[":focus"] = styles.rootFocused, _b[":active"] = styles.rootPressed, _b[":active ." + classNames.msButtonIcon] = styles.iconPressed, _b[":active ." + classNames.msButtonDescription] = styles.descriptionPressed, _b[":active ." + classNames.msButtonMenuIcon] = styles.menuIconPressed, _b)
      },
      disabled && checked && [styles.rootCheckedDisabled],
      !disabled && checked && {
        selectors: {
          ":hover": styles.rootCheckedHovered,
          ":active": styles.rootCheckedPressed
        }
      },
      className
    ],
    flexContainer: [classNames.msButtonFlexContainer, styles.flexContainer],
    textContainer: [classNames.msButtonTextContainer, styles.textContainer],
    icon: [
      classNames.msButtonIcon,
      iconClassName,
      styles.icon,
      isExpanded && styles.iconExpanded,
      checked && styles.iconChecked,
      disabled && styles.iconDisabled
    ],
    label: [classNames.msButtonLabel, styles.label, checked && styles.labelChecked, disabled && styles.labelDisabled],
    menuIcon: [
      classNames.msButtonMenuIcon,
      menuIconClassName,
      styles.menuIcon,
      checked && styles.menuIconChecked,
      disabled && !isSplit && styles.menuIconDisabled,
      !disabled && !isExpanded && !checked && {
        selectors: {
          ":hover": styles.menuIconHovered,
          ":active": styles.menuIconPressed
        }
      },
      isExpanded && ["is-expanded", styles.menuIconExpanded]
    ],
    description: [
      classNames.msButtonDescription,
      styles.description,
      checked && styles.descriptionChecked,
      disabled && styles.descriptionDisabled
    ],
    screenReaderText: [classNames.msButtonScreenReaderText, styles.screenReaderText]
  });
});

// node_modules/@fluentui/react/lib/components/Button/SplitButton/SplitButton.classNames.js
var getSplitButtonClassNames = memoizeFunction(function(styles, disabled, expanded, checked, primaryDisabled) {
  return {
    root: mergeStyles(styles.splitButtonMenuButton, expanded && [styles.splitButtonMenuButtonExpanded], disabled && [styles.splitButtonMenuButtonDisabled], checked && !disabled && [styles.splitButtonMenuButtonChecked], primaryDisabled && !disabled && [
      {
        selectors: {
          ":focus": styles.splitButtonMenuFocused
        }
      }
    ]),
    splitButtonContainer: mergeStyles(styles.splitButtonContainer, !disabled && checked && [
      styles.splitButtonContainerChecked,
      {
        selectors: {
          ":hover": styles.splitButtonContainerCheckedHovered
        }
      }
    ], !disabled && !checked && [
      {
        selectors: {
          ":hover": styles.splitButtonContainerHovered,
          ":focus": styles.splitButtonContainerFocused
        }
      }
    ], disabled && styles.splitButtonContainerDisabled),
    icon: mergeStyles(styles.splitButtonMenuIcon, disabled && styles.splitButtonMenuIconDisabled, !disabled && primaryDisabled && styles.splitButtonMenuIcon),
    flexContainer: mergeStyles(styles.splitButtonFlexContainer),
    divider: mergeStyles(styles.splitButtonDivider, (primaryDisabled || disabled) && styles.splitButtonDividerDisabled)
  };
});

// node_modules/@fluentui/react/lib/components/Button/BaseButton.js
var TouchIdleDelay2 = 500;
var COMPONENT_NAME4 = "BaseButton";
var BaseButton = (
  /** @class */
  function(_super) {
    __extends(BaseButton2, _super);
    function BaseButton2(props) {
      var _this = _super.call(this, props) || this;
      _this._buttonElement = React25.createRef();
      _this._splitButtonContainer = React25.createRef();
      _this._mergedRef = createMergedRef();
      _this._renderedVisibleMenu = false;
      _this._getMemoizedMenuButtonKeytipProps = memoizeFunction(function(keytipProps) {
        return __assign(__assign({}, keytipProps), { hasMenu: true });
      });
      _this._onRenderIcon = function(buttonProps, defaultRender) {
        var iconProps = _this.props.iconProps;
        if (iconProps && (iconProps.iconName !== void 0 || iconProps.imageProps)) {
          var className = iconProps.className, imageProps = iconProps.imageProps, rest = __rest(iconProps, ["className", "imageProps"]);
          if (iconProps.styles) {
            return React25.createElement(Icon, __assign({ className: css(_this._classNames.icon, className), imageProps }, rest));
          }
          if (iconProps.iconName) {
            return React25.createElement(FontIcon, __assign({ className: css(_this._classNames.icon, className) }, rest));
          }
          if (imageProps) {
            return React25.createElement(ImageIcon, __assign({ className: css(_this._classNames.icon, className), imageProps }, rest));
          }
        }
        return null;
      };
      _this._onRenderTextContents = function() {
        var _a3 = _this.props, text = _a3.text, children = _a3.children, _b = _a3.secondaryText, secondaryText = _b === void 0 ? _this.props.description : _b, _c = _a3.onRenderText, onRenderText = _c === void 0 ? _this._onRenderText : _c, _d = _a3.onRenderDescription, onRenderDescription = _d === void 0 ? _this._onRenderDescription : _d;
        if (text || typeof children === "string" || secondaryText) {
          return React25.createElement(
            "span",
            { className: _this._classNames.textContainer },
            onRenderText(_this.props, _this._onRenderText),
            onRenderDescription(_this.props, _this._onRenderDescription)
          );
        }
        return [onRenderText(_this.props, _this._onRenderText), onRenderDescription(_this.props, _this._onRenderDescription)];
      };
      _this._onRenderText = function() {
        var text = _this.props.text;
        var children = _this.props.children;
        if (text === void 0 && typeof children === "string") {
          text = children;
        }
        if (_this._hasText()) {
          return React25.createElement("span", { key: _this._labelId, className: _this._classNames.label, id: _this._labelId }, text);
        }
        return null;
      };
      _this._onRenderChildren = function() {
        var children = _this.props.children;
        if (typeof children === "string") {
          return null;
        }
        return children;
      };
      _this._onRenderDescription = function(props2) {
        var _a3 = props2.secondaryText, secondaryText = _a3 === void 0 ? _this.props.description : _a3;
        return secondaryText ? React25.createElement("span", { key: _this._descriptionId, className: _this._classNames.description, id: _this._descriptionId }, secondaryText) : null;
      };
      _this._onRenderAriaDescription = function() {
        var ariaDescription = _this.props.ariaDescription;
        return ariaDescription ? React25.createElement("span", { className: _this._classNames.screenReaderText, id: _this._ariaDescriptionId }, ariaDescription) : null;
      };
      _this._onRenderMenuIcon = function(props2) {
        var menuIconProps = _this.props.menuIconProps;
        return React25.createElement(FontIcon, __assign({ iconName: "ChevronDown" }, menuIconProps, { className: _this._classNames.menuIcon }));
      };
      _this._onRenderMenu = function(menuProps) {
        var MenuType = _this.props.menuAs ? composeComponentAs(_this.props.menuAs, ContextualMenu) : ContextualMenu;
        return React25.createElement(MenuType, __assign({}, menuProps));
      };
      _this._onDismissMenu = function(ev) {
        var menuProps = _this.props.menuProps;
        if (menuProps && menuProps.onDismiss) {
          menuProps.onDismiss(ev);
        }
        if (!ev || !ev.defaultPrevented) {
          _this._dismissMenu();
        }
      };
      _this._dismissMenu = function() {
        _this._menuShouldFocusOnMount = void 0;
        _this._menuShouldFocusOnContainer = void 0;
        _this.setState({ menuHidden: true });
      };
      _this._openMenu = function(shouldFocusOnContainer, shouldFocusOnMount) {
        if (shouldFocusOnMount === void 0) {
          shouldFocusOnMount = true;
        }
        if (_this.props.menuProps) {
          _this._menuShouldFocusOnContainer = shouldFocusOnContainer;
          _this._menuShouldFocusOnMount = shouldFocusOnMount;
          _this._renderedVisibleMenu = true;
          _this.setState({ menuHidden: false });
        }
      };
      _this._onToggleMenu = function(shouldFocusOnContainer) {
        var shouldFocusOnMount = true;
        if (_this.props.menuProps && _this.props.menuProps.shouldFocusOnMount === false) {
          shouldFocusOnMount = false;
        }
        _this.state.menuHidden ? _this._openMenu(shouldFocusOnContainer, shouldFocusOnMount) : _this._dismissMenu();
      };
      _this._onSplitContainerFocusCapture = function(ev) {
        var container = _this._splitButtonContainer.current;
        if (!container || ev.target && portalContainsElement(ev.target, container)) {
          return;
        }
        container.focus();
      };
      _this._onSplitButtonPrimaryClick = function(ev) {
        if (!_this.state.menuHidden) {
          _this._dismissMenu();
        }
        if (!_this._processingTouch && _this.props.onClick) {
          _this.props.onClick(ev);
        } else if (_this._processingTouch) {
          _this._onMenuClick(ev);
        }
      };
      _this._onKeyDown = function(ev) {
        if (_this.props.disabled && (ev.which === KeyCodes.enter || ev.which === KeyCodes.space)) {
          ev.preventDefault();
          ev.stopPropagation();
        } else if (!_this.props.disabled) {
          if (_this.props.menuProps) {
            _this._onMenuKeyDown(ev);
          } else if (_this.props.onKeyDown !== void 0) {
            _this.props.onKeyDown(ev);
          }
        }
      };
      _this._onKeyUp = function(ev) {
        if (!_this.props.disabled && _this.props.onKeyUp !== void 0) {
          _this.props.onKeyUp(ev);
        }
      };
      _this._onKeyPress = function(ev) {
        if (!_this.props.disabled && _this.props.onKeyPress !== void 0) {
          _this.props.onKeyPress(ev);
        }
      };
      _this._onMouseUp = function(ev) {
        if (!_this.props.disabled && _this.props.onMouseUp !== void 0) {
          _this.props.onMouseUp(ev);
        }
      };
      _this._onMouseDown = function(ev) {
        if (!_this.props.disabled && _this.props.onMouseDown !== void 0) {
          _this.props.onMouseDown(ev);
        }
      };
      _this._onClick = function(ev) {
        if (!_this.props.disabled) {
          if (_this.props.menuProps) {
            _this._onMenuClick(ev);
          } else if (_this.props.onClick !== void 0) {
            _this.props.onClick(ev);
          }
        }
      };
      _this._onSplitButtonContainerKeyDown = function(ev) {
        if (ev.which === KeyCodes.enter || ev.which === KeyCodes.space) {
          if (_this._buttonElement.current) {
            _this._buttonElement.current.click();
            ev.preventDefault();
            ev.stopPropagation();
          }
        } else {
          _this._onMenuKeyDown(ev);
        }
      };
      _this._onMenuKeyDown = function(ev) {
        var _a3;
        if (_this.props.disabled) {
          return;
        }
        if (_this.props.onKeyDown) {
          _this.props.onKeyDown(ev);
        }
        var isUp = ev.which === KeyCodes.up;
        var isDown = ev.which === KeyCodes.down;
        if (!ev.defaultPrevented && _this._isValidMenuOpenKey(ev)) {
          var onMenuClick = _this.props.onMenuClick;
          if (onMenuClick) {
            onMenuClick(ev, _this.props);
          }
          _this._onToggleMenu(false);
          ev.preventDefault();
          ev.stopPropagation();
        }
        if (ev.which === KeyCodes.enter || ev.which === KeyCodes.space) {
          setFocusVisibility(true, ev.target, (_a3 = _this.context) === null || _a3 === void 0 ? void 0 : _a3.registeredProviders);
        }
        if (!(ev.altKey || ev.metaKey) && (isUp || isDown)) {
          if (!_this.state.menuHidden && _this.props.menuProps) {
            var currentShouldFocusOnMount = _this._menuShouldFocusOnMount !== void 0 ? _this._menuShouldFocusOnMount : _this.props.menuProps.shouldFocusOnMount;
            if (!currentShouldFocusOnMount) {
              ev.preventDefault();
              ev.stopPropagation();
              _this._menuShouldFocusOnMount = true;
              _this.forceUpdate();
            }
          }
        }
      };
      _this._onTouchStart = function() {
        if (_this._isSplitButton && _this._splitButtonContainer.current && !("onpointerdown" in _this._splitButtonContainer.current)) {
          _this._handleTouchAndPointerEvent();
        }
      };
      _this._onMenuClick = function(ev) {
        var _a3 = _this.props, onMenuClick = _a3.onMenuClick, menuProps = _a3.menuProps;
        if (onMenuClick) {
          onMenuClick(ev, _this.props);
        }
        var shouldFocusOnContainer = typeof (menuProps === null || menuProps === void 0 ? void 0 : menuProps.shouldFocusOnContainer) === "boolean" ? menuProps.shouldFocusOnContainer : ev.nativeEvent.pointerType === "mouse";
        if (!ev.defaultPrevented) {
          _this._onToggleMenu(shouldFocusOnContainer);
          ev.preventDefault();
          ev.stopPropagation();
        }
      };
      initializeComponentRef(_this);
      _this._async = new Async(_this);
      _this._events = new EventGroup(_this);
      warnConditionallyRequiredProps(COMPONENT_NAME4, props, ["menuProps", "onClick"], "split", _this.props.split);
      warnDeprecations(COMPONENT_NAME4, props, {
        rootProps: void 0,
        description: "secondaryText",
        toggled: "checked"
      });
      _this._labelId = getId();
      _this._descriptionId = getId();
      _this._ariaDescriptionId = getId();
      _this.state = {
        menuHidden: true
      };
      return _this;
    }
    Object.defineProperty(BaseButton2.prototype, "_isSplitButton", {
      get: function() {
        return !!this.props.menuProps && !!this.props.onClick && this.props.split === true;
      },
      enumerable: false,
      configurable: true
    });
    BaseButton2.prototype.render = function() {
      var _a3;
      var _b = this.props, ariaDescription = _b.ariaDescription, ariaLabel = _b.ariaLabel, ariaHidden = _b.ariaHidden, className = _b.className, disabled = _b.disabled, allowDisabledFocus = _b.allowDisabledFocus, primaryDisabled = _b.primaryDisabled, _c = _b.secondaryText, secondaryText = _c === void 0 ? this.props.description : _c, href = _b.href, iconProps = _b.iconProps, menuIconProps = _b.menuIconProps, styles = _b.styles, checked = _b.checked, variantClassName = _b.variantClassName, theme = _b.theme, toggle = _b.toggle, getClassNames7 = _b.getClassNames, role = _b.role;
      var menuHidden = this.state.menuHidden;
      var isPrimaryButtonDisabled = disabled || primaryDisabled;
      this._classNames = getClassNames7 ? getClassNames7(theme, className, variantClassName, iconProps && iconProps.className, menuIconProps && menuIconProps.className, isPrimaryButtonDisabled, checked, !menuHidden, !!this.props.menuProps, this.props.split, !!allowDisabledFocus) : getBaseButtonClassNames(theme, styles, className, variantClassName, iconProps && iconProps.className, menuIconProps && menuIconProps.className, isPrimaryButtonDisabled, !!this.props.menuProps, checked, !menuHidden, this.props.split);
      var _d = this, _ariaDescriptionId = _d._ariaDescriptionId, _labelId = _d._labelId, _descriptionId = _d._descriptionId;
      var renderAsAnchor = !isPrimaryButtonDisabled && !!href;
      var tag = renderAsAnchor ? "a" : "button";
      var nativeProps = getNativeProps(
        // eslint-disable-next-line deprecation/deprecation
        assign(renderAsAnchor ? {} : { type: "button" }, this.props.rootProps, this.props),
        renderAsAnchor ? anchorProperties : buttonProperties,
        [
          "disabled"
          // let disabled buttons be focused and styled as disabled.
        ]
      );
      var resolvedAriaLabel = ariaLabel || nativeProps["aria-label"];
      var ariaDescribedBy = void 0;
      if (ariaDescription) {
        ariaDescribedBy = _ariaDescriptionId;
      } else if (secondaryText && this.props.onRenderDescription !== nullRender) {
        ariaDescribedBy = _descriptionId;
      } else if (nativeProps["aria-describedby"]) {
        ariaDescribedBy = nativeProps["aria-describedby"];
      }
      var ariaLabelledBy = void 0;
      if (nativeProps["aria-labelledby"]) {
        ariaLabelledBy = nativeProps["aria-labelledby"];
      } else if (ariaDescribedBy && !resolvedAriaLabel) {
        ariaLabelledBy = this._hasText() ? _labelId : void 0;
      }
      var dataIsFocusable = this.props["data-is-focusable"] === false || disabled && !allowDisabledFocus || this._isSplitButton ? false : true;
      var isCheckboxTypeRole = role === "menuitemcheckbox" || role === "checkbox";
      var checkedOrPressedValue = isCheckboxTypeRole ? !!checked : toggle === true ? !!checked : void 0;
      var buttonProps = assign(nativeProps, (_a3 = {
        className: this._classNames.root,
        // eslint-disable-next-line deprecation/deprecation
        ref: this._mergedRef(this.props.elementRef, this._buttonElement),
        disabled: isPrimaryButtonDisabled && !allowDisabledFocus,
        onKeyDown: this._onKeyDown,
        onKeyPress: this._onKeyPress,
        onKeyUp: this._onKeyUp,
        onMouseDown: this._onMouseDown,
        onMouseUp: this._onMouseUp,
        onClick: this._onClick,
        "aria-label": resolvedAriaLabel,
        "aria-labelledby": ariaLabelledBy,
        "aria-describedby": ariaDescribedBy,
        "aria-disabled": isPrimaryButtonDisabled,
        "data-is-focusable": dataIsFocusable
      }, // aria-pressed attribute should only be present for toggle buttons
      // aria-checked attribute should only be present for toggle buttons with checkbox type role
      _a3[isCheckboxTypeRole ? "aria-checked" : "aria-pressed"] = checkedOrPressedValue, _a3));
      if (ariaHidden) {
        buttonProps["aria-hidden"] = true;
      }
      if (this._isSplitButton) {
        return this._onRenderSplitButtonContent(tag, buttonProps);
      } else if (this.props.menuProps) {
        var _e = this.props.menuProps.id, id = _e === void 0 ? this._labelId + "-menu" : _e;
        assign(buttonProps, {
          "aria-expanded": !menuHidden,
          "aria-controls": !menuHidden ? id : null,
          "aria-haspopup": true
        });
      }
      return this._onRenderContent(tag, buttonProps);
    };
    BaseButton2.prototype.componentDidMount = function() {
      if (this._isSplitButton && this._splitButtonContainer.current) {
        if ("onpointerdown" in this._splitButtonContainer.current) {
          this._events.on(this._splitButtonContainer.current, "pointerdown", this._onPointerDown, true);
        }
        if ("onpointerup" in this._splitButtonContainer.current && this.props.onPointerUp) {
          this._events.on(this._splitButtonContainer.current, "pointerup", this.props.onPointerUp, true);
        }
      }
    };
    BaseButton2.prototype.componentDidUpdate = function(prevProps, prevState) {
      if (this.props.onAfterMenuDismiss && !prevState.menuHidden && this.state.menuHidden) {
        this.props.onAfterMenuDismiss();
      }
    };
    BaseButton2.prototype.componentWillUnmount = function() {
      this._async.dispose();
      this._events.dispose();
    };
    BaseButton2.prototype.focus = function() {
      var _a3, _b;
      if (this._isSplitButton && this._splitButtonContainer.current) {
        setFocusVisibility(true, void 0, (_a3 = this.context) === null || _a3 === void 0 ? void 0 : _a3.registeredProviders);
        this._splitButtonContainer.current.focus();
      } else if (this._buttonElement.current) {
        setFocusVisibility(true, void 0, (_b = this.context) === null || _b === void 0 ? void 0 : _b.registeredProviders);
        this._buttonElement.current.focus();
      }
    };
    BaseButton2.prototype.dismissMenu = function() {
      this._dismissMenu();
    };
    BaseButton2.prototype.openMenu = function(shouldFocusOnContainer, shouldFocusOnMount) {
      this._openMenu(shouldFocusOnContainer, shouldFocusOnMount);
    };
    BaseButton2.prototype._onRenderContent = function(tag, buttonProps) {
      var _this = this;
      var props = this.props;
      var Tag = tag;
      var menuIconProps = props.menuIconProps, menuProps = props.menuProps, _a3 = props.onRenderIcon, onRenderIcon = _a3 === void 0 ? this._onRenderIcon : _a3, _b = props.onRenderAriaDescription, onRenderAriaDescription = _b === void 0 ? this._onRenderAriaDescription : _b, _c = props.onRenderChildren, onRenderChildren = _c === void 0 ? this._onRenderChildren : _c, _d = props.onRenderMenu, onRenderMenu = _d === void 0 ? this._onRenderMenu : _d, _e = props.onRenderMenuIcon, onRenderMenuIcon = _e === void 0 ? this._onRenderMenuIcon : _e, disabled = props.disabled;
      var keytipProps = props.keytipProps;
      if (keytipProps && menuProps) {
        keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
      }
      var Button2 = function(keytipAttributes) {
        return React25.createElement(
          Tag,
          __assign({}, buttonProps, keytipAttributes),
          React25.createElement(
            "span",
            { className: _this._classNames.flexContainer, "data-automationid": "splitbuttonprimary" },
            onRenderIcon(props, _this._onRenderIcon),
            _this._onRenderTextContents(),
            onRenderAriaDescription(props, _this._onRenderAriaDescription),
            onRenderChildren(props, _this._onRenderChildren),
            !_this._isSplitButton && (menuProps || menuIconProps || _this.props.onRenderMenuIcon) && onRenderMenuIcon(_this.props, _this._onRenderMenuIcon),
            menuProps && !menuProps.doNotLayer && _this._shouldRenderMenu() && onRenderMenu(_this._getMenuProps(menuProps), _this._onRenderMenu)
          )
        );
      };
      var Content = keytipProps ? (
        // If we're making a split button, we won't put the keytip here
        React25.createElement(KeytipData, { keytipProps: !this._isSplitButton ? keytipProps : void 0, ariaDescribedBy: buttonProps["aria-describedby"], disabled }, function(keytipAttributes) {
          return Button2(keytipAttributes);
        })
      ) : Button2();
      if (menuProps && menuProps.doNotLayer) {
        return React25.createElement(
          React25.Fragment,
          null,
          Content,
          this._shouldRenderMenu() && onRenderMenu(this._getMenuProps(menuProps), this._onRenderMenu)
        );
      }
      return React25.createElement(
        React25.Fragment,
        null,
        Content,
        React25.createElement(FocusRects, null)
      );
    };
    BaseButton2.prototype._shouldRenderMenu = function() {
      var menuHidden = this.state.menuHidden;
      var _a3 = this.props, persistMenu = _a3.persistMenu, renderPersistedMenuHiddenOnMount = _a3.renderPersistedMenuHiddenOnMount;
      if (!menuHidden) {
        return true;
      } else if (persistMenu && (this._renderedVisibleMenu || renderPersistedMenuHiddenOnMount)) {
        return true;
      }
      return false;
    };
    BaseButton2.prototype._hasText = function() {
      return this.props.text !== null && (this.props.text !== void 0 || typeof this.props.children === "string");
    };
    BaseButton2.prototype._getMenuProps = function(menuProps) {
      var persistMenu = this.props.persistMenu;
      var menuHidden = this.state.menuHidden;
      if (!menuProps.ariaLabel && !menuProps.labelElementId && this._hasText()) {
        menuProps = __assign(__assign({}, menuProps), { labelElementId: this._labelId });
      }
      return __assign(__assign({ id: this._labelId + "-menu", directionalHint: DirectionalHint.bottomLeftEdge }, menuProps), { shouldFocusOnContainer: this._menuShouldFocusOnContainer, shouldFocusOnMount: this._menuShouldFocusOnMount, hidden: persistMenu ? menuHidden : void 0, className: css("ms-BaseButton-menuhost", menuProps.className), target: this._isSplitButton ? this._splitButtonContainer.current : this._buttonElement.current, onDismiss: this._onDismissMenu });
    };
    BaseButton2.prototype._onRenderSplitButtonContent = function(tag, buttonProps) {
      var _this = this;
      var _a3 = this.props, _b = _a3.styles, styles = _b === void 0 ? {} : _b, disabled = _a3.disabled, allowDisabledFocus = _a3.allowDisabledFocus, checked = _a3.checked, getSplitButtonClassNames2 = _a3.getSplitButtonClassNames, primaryDisabled = _a3.primaryDisabled, menuProps = _a3.menuProps, toggle = _a3.toggle, role = _a3.role, primaryActionButtonProps = _a3.primaryActionButtonProps;
      var keytipProps = this.props.keytipProps;
      var menuHidden = this.state.menuHidden;
      var classNames = getSplitButtonClassNames2 ? getSplitButtonClassNames2(!!disabled, !menuHidden, !!checked, !!allowDisabledFocus) : styles && getSplitButtonClassNames(styles, !!disabled, !menuHidden, !!checked, !!primaryDisabled);
      assign(buttonProps, {
        onClick: void 0,
        onPointerDown: void 0,
        onPointerUp: void 0,
        tabIndex: -1,
        "data-is-focusable": false
      });
      if (keytipProps && menuProps) {
        keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
      }
      var containerProps = getNativeProps(buttonProps, [], ["disabled"]);
      if (primaryActionButtonProps) {
        assign(buttonProps, primaryActionButtonProps);
      }
      var SplitButton = function(keytipAttributes) {
        return React25.createElement(
          "div",
          __assign({}, containerProps, { "data-ktp-target": keytipAttributes ? keytipAttributes["data-ktp-target"] : void 0, role: role ? role : "button", "aria-disabled": disabled, "aria-haspopup": true, "aria-expanded": !menuHidden, "aria-pressed": toggle ? !!checked : void 0, "aria-describedby": mergeAriaAttributeValues(buttonProps["aria-describedby"], keytipAttributes ? keytipAttributes["aria-describedby"] : void 0), className: classNames && classNames.splitButtonContainer, onKeyDown: _this._onSplitButtonContainerKeyDown, onTouchStart: _this._onTouchStart, ref: _this._splitButtonContainer, "data-is-focusable": true, onClick: !disabled && !primaryDisabled ? _this._onSplitButtonPrimaryClick : void 0, tabIndex: !disabled && !primaryDisabled || allowDisabledFocus ? 0 : void 0, "aria-roledescription": buttonProps["aria-roledescription"], onFocusCapture: _this._onSplitContainerFocusCapture }),
          React25.createElement(
            "span",
            { style: { display: "flex", width: "100%" } },
            _this._onRenderContent(tag, buttonProps),
            _this._onRenderSplitButtonMenuButton(classNames, keytipAttributes),
            _this._onRenderSplitButtonDivider(classNames)
          )
        );
      };
      return keytipProps ? React25.createElement(KeytipData, { keytipProps, disabled }, function(keytipAttributes) {
        return SplitButton(keytipAttributes);
      }) : SplitButton();
    };
    BaseButton2.prototype._onRenderSplitButtonDivider = function(classNames) {
      if (classNames && classNames.divider) {
        var onClick = function(ev) {
          ev.stopPropagation();
        };
        return React25.createElement("span", { className: classNames.divider, "aria-hidden": true, onClick });
      }
      return null;
    };
    BaseButton2.prototype._onRenderSplitButtonMenuButton = function(classNames, keytipAttributes) {
      var _a3 = this.props, allowDisabledFocus = _a3.allowDisabledFocus, checked = _a3.checked, disabled = _a3.disabled, splitButtonMenuProps = _a3.splitButtonMenuProps, splitButtonAriaLabel = _a3.splitButtonAriaLabel, primaryDisabled = _a3.primaryDisabled;
      var menuHidden = this.state.menuHidden;
      var menuIconProps = this.props.menuIconProps;
      if (menuIconProps === void 0) {
        menuIconProps = {
          iconName: "ChevronDown"
        };
      }
      var splitButtonProps = __assign(__assign({}, splitButtonMenuProps), { styles: classNames, checked, disabled, allowDisabledFocus, onClick: this._onMenuClick, menuProps: void 0, iconProps: __assign(__assign({}, menuIconProps), { className: this._classNames.menuIcon }), ariaLabel: splitButtonAriaLabel, "aria-haspopup": true, "aria-expanded": !menuHidden, "data-is-focusable": false });
      return React25.createElement(BaseButton2, __assign({}, splitButtonProps, { "data-ktp-execute-target": keytipAttributes ? keytipAttributes["data-ktp-execute-target"] : keytipAttributes, onMouseDown: this._onMouseDown, tabIndex: primaryDisabled && !allowDisabledFocus ? 0 : -1 }));
    };
    BaseButton2.prototype._onPointerDown = function(ev) {
      var onPointerDown = this.props.onPointerDown;
      if (onPointerDown) {
        onPointerDown(ev);
      }
      if (ev.pointerType === "touch") {
        this._handleTouchAndPointerEvent();
        ev.preventDefault();
        ev.stopImmediatePropagation();
      }
    };
    BaseButton2.prototype._handleTouchAndPointerEvent = function() {
      var _this = this;
      if (this._lastTouchTimeoutId !== void 0) {
        this._async.clearTimeout(this._lastTouchTimeoutId);
        this._lastTouchTimeoutId = void 0;
      }
      this._processingTouch = true;
      this._lastTouchTimeoutId = this._async.setTimeout(function() {
        _this._processingTouch = false;
        _this._lastTouchTimeoutId = void 0;
        if (_this.state.menuHidden) {
          _this.focus();
        }
      }, TouchIdleDelay2);
    };
    BaseButton2.prototype._isValidMenuOpenKey = function(ev) {
      if (this.props.menuTriggerKeyCode) {
        return ev.which === this.props.menuTriggerKeyCode;
      } else if (this.props.menuProps) {
        return ev.which === KeyCodes.down && (ev.altKey || ev.metaKey);
      }
      return false;
    };
    BaseButton2.defaultProps = {
      baseClassName: "ms-Button",
      styles: {},
      split: false
    };
    BaseButton2.contextType = FocusRectsContext;
    return BaseButton2;
  }(React25.Component)
);

// node_modules/@fluentui/react/lib/components/Button/Button.types.js
var ElementType;
(function(ElementType2) {
  ElementType2[ElementType2["button"] = 0] = "button";
  ElementType2[ElementType2["anchor"] = 1] = "anchor";
})(ElementType || (ElementType = {}));
var ButtonType;
(function(ButtonType2) {
  ButtonType2[ButtonType2["normal"] = 0] = "normal";
  ButtonType2[ButtonType2["primary"] = 1] = "primary";
  ButtonType2[ButtonType2["hero"] = 2] = "hero";
  ButtonType2[ButtonType2["compound"] = 3] = "compound";
  ButtonType2[ButtonType2["command"] = 4] = "command";
  ButtonType2[ButtonType2["icon"] = 5] = "icon";
  ButtonType2[ButtonType2["default"] = 6] = "default";
})(ButtonType || (ButtonType = {}));

// node_modules/@fluentui/react/lib/components/Button/Button.js
var React31 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/DefaultButton/DefaultButton.js
var React26 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/BaseButton.styles.js
var noOutline = {
  outline: 0
};
var iconStyle = function(fontSize) {
  return {
    fontSize,
    margin: "0 4px",
    height: "16px",
    lineHeight: "16px",
    textAlign: "center",
    flexShrink: 0
  };
};
var getStyles6 = memoizeFunction(function(theme) {
  var _a3, _b;
  var semanticColors = theme.semanticColors, effects = theme.effects, fonts = theme.fonts;
  var border = semanticColors.buttonBorder;
  var disabledBackground = semanticColors.disabledBackground;
  var disabledText = semanticColors.disabledText;
  var buttonHighContrastFocus = {
    left: -2,
    top: -2,
    bottom: -2,
    right: -2,
    outlineColor: "ButtonText"
  };
  return {
    root: [
      getFocusStyle(theme, { inset: 1, highContrastStyle: buttonHighContrastFocus, borderColor: "transparent" }),
      theme.fonts.medium,
      {
        border: "1px solid " + border,
        borderRadius: effects.roundedCorner2,
        boxSizing: "border-box",
        cursor: "pointer",
        display: "inline-block",
        padding: "0 16px",
        textDecoration: "none",
        textAlign: "center",
        userSelect: "none",
        selectors: {
          // IE11 workaround for preventing shift of child elements of a button when active.
          ":active > span": {
            position: "relative",
            left: 0,
            top: 0
          }
        }
      }
    ],
    rootDisabled: [
      getFocusStyle(theme, { inset: 1, highContrastStyle: buttonHighContrastFocus, borderColor: "transparent" }),
      {
        backgroundColor: disabledBackground,
        borderColor: disabledBackground,
        color: disabledText,
        cursor: "default",
        selectors: {
          ":hover": noOutline,
          ":focus": noOutline
        }
      }
    ],
    iconDisabled: {
      color: disabledText,
      selectors: (_a3 = {}, _a3[HighContrastSelector] = {
        color: "GrayText"
      }, _a3)
    },
    menuIconDisabled: {
      color: disabledText,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        color: "GrayText"
      }, _b)
    },
    flexContainer: {
      display: "flex",
      height: "100%",
      flexWrap: "nowrap",
      justifyContent: "center",
      alignItems: "center"
    },
    description: {
      display: "block"
    },
    textContainer: {
      flexGrow: 1,
      display: "block"
    },
    icon: iconStyle(fonts.mediumPlus.fontSize),
    menuIcon: iconStyle(fonts.small.fontSize),
    label: {
      margin: "0 4px",
      lineHeight: "100%",
      display: "block"
    },
    screenReaderText: hiddenContentStyle
  };
});

// node_modules/@fluentui/react/lib/components/Button/SplitButton/SplitButton.styles.js
var getStyles7 = memoizeFunction(function(theme, customStyles) {
  var _a3, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
  var effects = theme.effects, palette = theme.palette, semanticColors = theme.semanticColors;
  var buttonHighContrastFocus = {
    left: -2,
    top: -2,
    bottom: -2,
    right: -2,
    border: "none"
  };
  var splitButtonDividerBaseStyles2 = {
    position: "absolute",
    width: 1,
    right: 31,
    top: 8,
    bottom: 8
  };
  var splitButtonStyles = {
    splitButtonContainer: [
      getFocusStyle(theme, { highContrastStyle: buttonHighContrastFocus, inset: 2, pointerEvents: "none" }),
      {
        display: "inline-flex",
        selectors: {
          ".ms-Button--default": {
            borderTopRightRadius: "0",
            borderBottomRightRadius: "0",
            borderRight: "none",
            flexGrow: "1"
          },
          ".ms-Button--primary": {
            borderTopRightRadius: "0",
            borderBottomRightRadius: "0",
            border: "none",
            flexGrow: "1",
            selectors: (_a3 = {}, _a3[HighContrastSelector] = __assign({ color: "WindowText", backgroundColor: "Window", border: "1px solid WindowText", borderRightWidth: "0" }, getHighContrastNoAdjustStyle()), _a3[":hover"] = {
              border: "none"
            }, _a3[":active"] = {
              border: "none"
            }, _a3)
          },
          ".ms-Button--primary + .ms-Button": {
            border: "none",
            selectors: (_b = {}, _b[HighContrastSelector] = {
              border: "1px solid WindowText",
              borderLeftWidth: "0"
            }, _b)
          }
        }
      }
    ],
    splitButtonContainerHovered: {
      selectors: {
        ".ms-Button--primary": {
          selectors: (_c = {}, _c[HighContrastSelector] = {
            color: "Window",
            backgroundColor: "Highlight"
          }, _c)
        },
        ".ms-Button.is-disabled": {
          color: semanticColors.buttonTextDisabled,
          selectors: (_d = {}, _d[HighContrastSelector] = {
            color: "GrayText",
            borderColor: "GrayText",
            backgroundColor: "Window"
          }, _d)
        }
      }
    },
    splitButtonContainerChecked: {
      selectors: {
        ".ms-Button--primary": {
          selectors: (_e = {}, _e[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText" }, getHighContrastNoAdjustStyle()), _e)
        }
      }
    },
    splitButtonContainerCheckedHovered: {
      selectors: {
        ".ms-Button--primary": {
          selectors: (_f = {}, _f[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText" }, getHighContrastNoAdjustStyle()), _f)
        }
      }
    },
    splitButtonContainerFocused: {
      outline: "none!important"
    },
    splitButtonMenuButton: (_g = {
      padding: 6,
      height: "auto",
      boxSizing: "border-box",
      borderRadius: 0,
      borderTopRightRadius: effects.roundedCorner2,
      borderBottomRightRadius: effects.roundedCorner2,
      border: "1px solid " + palette.neutralSecondaryAlt,
      borderLeft: "none",
      outline: "transparent",
      userSelect: "none",
      display: "inline-block",
      textDecoration: "none",
      textAlign: "center",
      cursor: "pointer",
      verticalAlign: "top",
      width: 32,
      marginLeft: -1,
      marginTop: 0,
      marginRight: 0,
      marginBottom: 0
    }, _g[HighContrastSelector] = {
      ".ms-Button-menuIcon": {
        color: "WindowText"
      }
    }, _g),
    splitButtonDivider: __assign(__assign({}, splitButtonDividerBaseStyles2), { selectors: (_h = {}, _h[HighContrastSelector] = {
      backgroundColor: "WindowText"
    }, _h) }),
    splitButtonDividerDisabled: __assign(__assign({}, splitButtonDividerBaseStyles2), { selectors: (_j = {}, _j[HighContrastSelector] = {
      backgroundColor: "GrayText"
    }, _j) }),
    splitButtonMenuButtonDisabled: {
      pointerEvents: "none",
      border: "none",
      selectors: (_k = {
        ":hover": {
          cursor: "default"
        },
        ".ms-Button--primary": {
          selectors: (_l = {}, _l[HighContrastSelector] = {
            color: "GrayText",
            borderColor: "GrayText",
            backgroundColor: "Window"
          }, _l)
        },
        ".ms-Button-menuIcon": {
          selectors: (_m = {}, _m[HighContrastSelector] = {
            color: "GrayText"
          }, _m)
        }
      }, _k[HighContrastSelector] = {
        color: "GrayText",
        border: "1px solid GrayText",
        backgroundColor: "Window"
      }, _k)
    },
    splitButtonFlexContainer: {
      display: "flex",
      height: "100%",
      flexWrap: "nowrap",
      justifyContent: "center",
      alignItems: "center"
    },
    splitButtonContainerDisabled: {
      outline: "none",
      border: "none",
      selectors: (_o = {}, _o[HighContrastSelector] = __assign({ color: "GrayText", borderColor: "GrayText", backgroundColor: "Window" }, getHighContrastNoAdjustStyle()), _o)
    },
    splitButtonMenuFocused: __assign({}, getFocusStyle(theme, { highContrastStyle: buttonHighContrastFocus, inset: 2 }))
  };
  return concatStyleSets(splitButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/ButtonThemes.js
var splitButtonDividerBaseStyles = function() {
  return {
    position: "absolute",
    width: 1,
    right: 31,
    top: 8,
    bottom: 8
  };
};
function standardStyles(theme) {
  var _a3, _b, _c, _d, _e;
  var s = theme.semanticColors, p = theme.palette;
  var buttonBackground = s.buttonBackground;
  var buttonBackgroundPressed = s.buttonBackgroundPressed;
  var buttonBackgroundHovered = s.buttonBackgroundHovered;
  var buttonBackgroundDisabled = s.buttonBackgroundDisabled;
  var buttonText = s.buttonText;
  var buttonTextHovered = s.buttonTextHovered;
  var buttonTextDisabled = s.buttonTextDisabled;
  var buttonTextChecked = s.buttonTextChecked;
  var buttonTextCheckedHovered = s.buttonTextCheckedHovered;
  return {
    root: {
      backgroundColor: buttonBackground,
      color: buttonText
    },
    rootHovered: {
      backgroundColor: buttonBackgroundHovered,
      color: buttonTextHovered,
      selectors: (_a3 = {}, _a3[HighContrastSelector] = {
        borderColor: "Highlight",
        color: "Highlight"
      }, _a3)
    },
    rootPressed: {
      backgroundColor: buttonBackgroundPressed,
      color: buttonTextChecked
    },
    rootExpanded: {
      backgroundColor: buttonBackgroundPressed,
      color: buttonTextChecked
    },
    rootChecked: {
      backgroundColor: buttonBackgroundPressed,
      color: buttonTextChecked
    },
    rootCheckedHovered: {
      backgroundColor: buttonBackgroundPressed,
      color: buttonTextCheckedHovered
    },
    rootDisabled: {
      color: buttonTextDisabled,
      backgroundColor: buttonBackgroundDisabled,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        color: "GrayText",
        borderColor: "GrayText",
        backgroundColor: "Window"
      }, _b)
    },
    // Split button styles
    splitButtonContainer: {
      selectors: (_c = {}, _c[HighContrastSelector] = {
        border: "none"
      }, _c)
    },
    splitButtonMenuButton: {
      color: p.white,
      backgroundColor: "transparent",
      selectors: {
        ":hover": {
          backgroundColor: p.neutralLight,
          selectors: (_d = {}, _d[HighContrastSelector] = {
            color: "Highlight"
          }, _d)
        }
      }
    },
    splitButtonMenuButtonDisabled: {
      backgroundColor: s.buttonBackgroundDisabled,
      selectors: {
        ":hover": {
          backgroundColor: s.buttonBackgroundDisabled
        }
      }
    },
    splitButtonDivider: __assign(__assign({}, splitButtonDividerBaseStyles()), { backgroundColor: p.neutralTertiaryAlt, selectors: (_e = {}, _e[HighContrastSelector] = {
      backgroundColor: "WindowText"
    }, _e) }),
    splitButtonDividerDisabled: {
      backgroundColor: theme.palette.neutralTertiaryAlt
    },
    splitButtonMenuButtonChecked: {
      backgroundColor: p.neutralQuaternaryAlt,
      selectors: {
        ":hover": {
          backgroundColor: p.neutralQuaternaryAlt
        }
      }
    },
    splitButtonMenuButtonExpanded: {
      backgroundColor: p.neutralQuaternaryAlt,
      selectors: {
        ":hover": {
          backgroundColor: p.neutralQuaternaryAlt
        }
      }
    },
    splitButtonMenuIcon: {
      color: s.buttonText
    },
    splitButtonMenuIconDisabled: {
      color: s.buttonTextDisabled
    }
  };
}
function primaryStyles(theme) {
  var _a3, _b, _c, _d, _e, _f, _g, _h, _j;
  var p = theme.palette, s = theme.semanticColors;
  return {
    root: {
      backgroundColor: s.primaryButtonBackground,
      border: "1px solid " + s.primaryButtonBackground,
      color: s.primaryButtonText,
      selectors: (_a3 = {}, _a3[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText", borderColor: "WindowText" }, getHighContrastNoAdjustStyle()), _a3["." + IsFocusVisibleClassName + " &:focus"] = {
        selectors: {
          ":after": {
            border: "none",
            outlineColor: p.white
          }
        }
      }, _a3)
    },
    rootHovered: {
      backgroundColor: s.primaryButtonBackgroundHovered,
      border: "1px solid " + s.primaryButtonBackgroundHovered,
      color: s.primaryButtonTextHovered,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        color: "Window",
        backgroundColor: "Highlight",
        borderColor: "Highlight"
      }, _b)
    },
    rootPressed: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      border: "1px solid " + s.primaryButtonBackgroundPressed,
      color: s.primaryButtonTextPressed,
      selectors: (_c = {}, _c[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText", borderColor: "WindowText" }, getHighContrastNoAdjustStyle()), _c)
    },
    rootExpanded: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      color: s.primaryButtonTextPressed
    },
    rootChecked: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      color: s.primaryButtonTextPressed
    },
    rootCheckedHovered: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      color: s.primaryButtonTextPressed
    },
    rootDisabled: {
      color: s.primaryButtonTextDisabled,
      backgroundColor: s.primaryButtonBackgroundDisabled,
      selectors: (_d = {}, _d[HighContrastSelector] = {
        color: "GrayText",
        borderColor: "GrayText",
        backgroundColor: "Window"
      }, _d)
    },
    // Split button styles
    splitButtonContainer: {
      selectors: (_e = {}, _e[HighContrastSelector] = {
        border: "none"
      }, _e)
    },
    splitButtonDivider: __assign(__assign({}, splitButtonDividerBaseStyles()), { backgroundColor: p.white, selectors: (_f = {}, _f[HighContrastSelector] = {
      backgroundColor: "Window"
    }, _f) }),
    splitButtonMenuButton: {
      backgroundColor: s.primaryButtonBackground,
      color: s.primaryButtonText,
      selectors: (_g = {}, _g[HighContrastSelector] = {
        backgroundColor: "Canvas"
      }, _g[":hover"] = {
        backgroundColor: s.primaryButtonBackgroundHovered,
        selectors: (_h = {}, _h[HighContrastSelector] = {
          color: "Highlight"
        }, _h)
      }, _g)
    },
    splitButtonMenuButtonDisabled: {
      backgroundColor: s.primaryButtonBackgroundDisabled,
      selectors: {
        ":hover": {
          backgroundColor: s.primaryButtonBackgroundDisabled
        }
      }
    },
    splitButtonMenuButtonChecked: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      selectors: {
        ":hover": {
          backgroundColor: s.primaryButtonBackgroundPressed
        }
      }
    },
    splitButtonMenuButtonExpanded: {
      backgroundColor: s.primaryButtonBackgroundPressed,
      selectors: {
        ":hover": {
          backgroundColor: s.primaryButtonBackgroundPressed
        }
      }
    },
    splitButtonMenuIcon: {
      color: s.primaryButtonText
    },
    splitButtonMenuIconDisabled: {
      color: p.neutralTertiary,
      selectors: (_j = {}, _j[HighContrastSelector] = {
        color: "GrayText"
      }, _j)
    }
  };
}

// node_modules/@fluentui/react/lib/components/Button/DefaultButton/DefaultButton.styles.js
var DEFAULT_BUTTON_HEIGHT = "32px";
var DEFAULT_BUTTON_MIN_WIDTH = "80px";
var getStyles8 = memoizeFunction(function(theme, customStyles, primary) {
  var baseButtonStyles = getStyles6(theme);
  var splitButtonStyles = getStyles7(theme);
  var defaultButtonStyles = {
    root: {
      minWidth: DEFAULT_BUTTON_MIN_WIDTH,
      height: DEFAULT_BUTTON_HEIGHT
    },
    label: {
      fontWeight: FontWeights.semibold
    }
  };
  return concatStyleSets(baseButtonStyles, defaultButtonStyles, primary ? primaryStyles(theme) : standardStyles(theme), splitButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/DefaultButton/DefaultButton.js
var DefaultButton = (
  /** @class */
  function(_super) {
    __extends(DefaultButton2, _super);
    function DefaultButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultButton2.prototype.render = function() {
      var _a3 = this.props, _b = _a3.primary, primary = _b === void 0 ? false : _b, styles = _a3.styles, theme = _a3.theme;
      return React26.createElement(BaseButton, __assign({}, this.props, { variantClassName: primary ? "ms-Button--primary" : "ms-Button--default", styles: getStyles8(theme, styles, primary), onRenderDescription: nullRender }));
    };
    DefaultButton2 = __decorate([
      customizable("DefaultButton", ["theme", "styles"], true)
    ], DefaultButton2);
    return DefaultButton2;
  }(React26.Component)
);

// node_modules/@fluentui/react/lib/components/Button/ActionButton/ActionButton.js
var React27 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/ActionButton/ActionButton.styles.js
var DEFAULT_BUTTON_HEIGHT2 = "40px";
var DEFAULT_PADDING = "0 4px";
var getStyles9 = memoizeFunction(function(theme, customStyles) {
  var _a3, _b, _c;
  var baseButtonStyles = getStyles6(theme);
  var actionButtonStyles = {
    root: {
      padding: DEFAULT_PADDING,
      height: DEFAULT_BUTTON_HEIGHT2,
      color: theme.palette.neutralPrimary,
      backgroundColor: "transparent",
      border: "1px solid transparent",
      selectors: (_a3 = {}, _a3[HighContrastSelector] = {
        borderColor: "Window"
      }, _a3)
    },
    rootHovered: {
      color: theme.palette.themePrimary,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        color: "Highlight"
      }, _b)
    },
    iconHovered: {
      color: theme.palette.themePrimary
    },
    rootPressed: {
      color: theme.palette.black
    },
    rootExpanded: {
      color: theme.palette.themePrimary
    },
    iconPressed: {
      color: theme.palette.themeDarker
    },
    rootDisabled: {
      color: theme.palette.neutralTertiary,
      backgroundColor: "transparent",
      borderColor: "transparent",
      selectors: (_c = {}, _c[HighContrastSelector] = {
        color: "GrayText"
      }, _c)
    },
    rootChecked: {
      color: theme.palette.black
    },
    iconChecked: {
      color: theme.palette.themeDarker
    },
    flexContainer: {
      justifyContent: "flex-start"
    },
    icon: {
      color: theme.palette.themeDarkAlt
    },
    iconDisabled: {
      color: "inherit"
    },
    menuIcon: {
      color: theme.palette.neutralSecondary
    },
    textContainer: {
      flexGrow: 0
    }
  };
  return concatStyleSets(baseButtonStyles, actionButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/ActionButton/ActionButton.js
var ActionButton = (
  /** @class */
  function(_super) {
    __extends(ActionButton2, _super);
    function ActionButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    ActionButton2.prototype.render = function() {
      var _a3 = this.props, styles = _a3.styles, theme = _a3.theme;
      return React27.createElement(BaseButton, __assign({}, this.props, { variantClassName: "ms-Button--action ms-Button--command", styles: getStyles9(theme, styles), onRenderDescription: nullRender }));
    };
    ActionButton2 = __decorate([
      customizable("ActionButton", ["theme", "styles"], true)
    ], ActionButton2);
    return ActionButton2;
  }(React27.Component)
);

// node_modules/@fluentui/react/lib/components/Button/CompoundButton/CompoundButton.js
var React28 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/CompoundButton/CompoundButton.styles.js
var getStyles10 = memoizeFunction(function(theme, customStyles, primary) {
  var _a3, _b, _c, _d, _e;
  var fonts = theme.fonts, palette = theme.palette;
  var baseButtonStyles = getStyles6(theme);
  var splitButtonStyles = getStyles7(theme);
  var compoundButtonStyles = {
    root: {
      maxWidth: "280px",
      minHeight: "72px",
      height: "auto",
      padding: "16px 12px"
    },
    flexContainer: {
      flexDirection: "row",
      alignItems: "flex-start",
      minWidth: "100%",
      margin: ""
    },
    textContainer: {
      textAlign: "left"
    },
    icon: {
      fontSize: "2em",
      lineHeight: "1em",
      height: "1em",
      margin: "0px 8px 0px 0px",
      flexBasis: "1em",
      flexShrink: "0"
    },
    label: {
      margin: "0 0 5px",
      lineHeight: "100%",
      fontWeight: FontWeights.semibold
    },
    description: [
      fonts.small,
      {
        lineHeight: "100%"
      }
    ]
  };
  var standardCompoundTheme = {
    description: {
      color: palette.neutralSecondary
    },
    descriptionHovered: {
      color: palette.neutralDark
    },
    descriptionPressed: {
      color: "inherit"
    },
    descriptionChecked: {
      color: "inherit"
    },
    descriptionDisabled: {
      color: "inherit"
    }
  };
  var primaryCompoundTheme = {
    description: {
      color: palette.white,
      selectors: (_a3 = {}, _a3[HighContrastSelector] = __assign({ backgroundColor: "WindowText", color: "Window" }, getHighContrastNoAdjustStyle()), _a3)
    },
    descriptionHovered: {
      color: palette.white,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        backgroundColor: "Highlight",
        color: "Window"
      }, _b)
    },
    descriptionPressed: {
      color: "inherit",
      selectors: (_c = {}, _c[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText" }, getHighContrastNoAdjustStyle()), _c)
    },
    descriptionChecked: {
      color: "inherit",
      selectors: (_d = {}, _d[HighContrastSelector] = __assign({ color: "Window", backgroundColor: "WindowText" }, getHighContrastNoAdjustStyle()), _d)
    },
    descriptionDisabled: {
      color: "inherit",
      selectors: (_e = {}, _e[HighContrastSelector] = {
        color: "inherit"
      }, _e)
    }
  };
  return concatStyleSets(baseButtonStyles, compoundButtonStyles, primary ? primaryStyles(theme) : standardStyles(theme), primary ? primaryCompoundTheme : standardCompoundTheme, splitButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/CompoundButton/CompoundButton.js
var CompoundButton = (
  /** @class */
  function(_super) {
    __extends(CompoundButton2, _super);
    function CompoundButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    CompoundButton2.prototype.render = function() {
      var _a3 = this.props, _b = _a3.primary, primary = _b === void 0 ? false : _b, styles = _a3.styles, theme = _a3.theme;
      return React28.createElement(BaseButton, __assign({}, this.props, { variantClassName: primary ? "ms-Button--compoundPrimary" : "ms-Button--compound", styles: getStyles10(theme, styles, primary) }));
    };
    CompoundButton2 = __decorate([
      customizable("CompoundButton", ["theme", "styles"], true)
    ], CompoundButton2);
    return CompoundButton2;
  }(React28.Component)
);

// node_modules/@fluentui/react/lib/components/Button/IconButton/IconButton.js
var React29 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/IconButton/IconButton.styles.js
var getStyles11 = memoizeFunction(function(theme, customStyles) {
  var _a3;
  var baseButtonStyles = getStyles6(theme);
  var splitButtonStyles = getStyles7(theme);
  var palette = theme.palette, semanticColors = theme.semanticColors;
  var iconButtonStyles = {
    root: {
      padding: "0 4px",
      width: "32px",
      height: "32px",
      backgroundColor: "transparent",
      border: "none",
      color: semanticColors.link
    },
    rootHovered: {
      color: palette.themeDarkAlt,
      backgroundColor: palette.neutralLighter,
      selectors: (_a3 = {}, _a3[HighContrastSelector] = {
        borderColor: "Highlight",
        color: "Highlight"
      }, _a3)
    },
    rootHasMenu: {
      width: "auto"
    },
    rootPressed: {
      color: palette.themeDark,
      backgroundColor: palette.neutralLight
    },
    rootExpanded: {
      color: palette.themeDark,
      backgroundColor: palette.neutralLight
    },
    rootChecked: {
      color: palette.themeDark,
      backgroundColor: palette.neutralLight
    },
    rootCheckedHovered: {
      color: palette.themeDark,
      backgroundColor: palette.neutralQuaternaryAlt
    },
    rootDisabled: {
      color: palette.neutralTertiaryAlt
    }
  };
  return concatStyleSets(baseButtonStyles, iconButtonStyles, splitButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/IconButton/IconButton.js
var IconButton = (
  /** @class */
  function(_super) {
    __extends(IconButton2, _super);
    function IconButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    IconButton2.prototype.render = function() {
      var _a3 = this.props, styles = _a3.styles, theme = _a3.theme;
      return React29.createElement(BaseButton, __assign({}, this.props, { variantClassName: "ms-Button--icon", styles: getStyles11(theme, styles), onRenderText: nullRender, onRenderDescription: nullRender }));
    };
    IconButton2 = __decorate([
      customizable("IconButton", ["theme", "styles"], true)
    ], IconButton2);
    return IconButton2;
  }(React29.Component)
);

// node_modules/@fluentui/react/lib/components/Button/PrimaryButton/PrimaryButton.js
var React30 = __toESM(require_react());
var PrimaryButton = (
  /** @class */
  function(_super) {
    __extends(PrimaryButton2, _super);
    function PrimaryButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    PrimaryButton2.prototype.render = function() {
      return React30.createElement(DefaultButton, __assign({}, this.props, { primary: true, onRenderDescription: nullRender }));
    };
    PrimaryButton2 = __decorate([
      customizable("PrimaryButton", ["theme", "styles"], true)
    ], PrimaryButton2);
    return PrimaryButton2;
  }(React30.Component)
);

// node_modules/@fluentui/react/lib/components/Button/Button.js
var Button = (
  /** @class */
  function(_super) {
    __extends(Button2, _super);
    function Button2(props) {
      var _this = _super.call(this, props) || this;
      warn("The Button component has been deprecated. Use specific variants instead. (PrimaryButton, DefaultButton, IconButton, ActionButton, etc.)");
      return _this;
    }
    Button2.prototype.render = function() {
      var props = this.props;
      switch (props.buttonType) {
        case ButtonType.command:
          return React31.createElement(ActionButton, __assign({}, props));
        case ButtonType.compound:
          return React31.createElement(CompoundButton, __assign({}, props));
        case ButtonType.icon:
          return React31.createElement(IconButton, __assign({}, props));
        case ButtonType.primary:
          return React31.createElement(PrimaryButton, __assign({}, props));
        default:
          return React31.createElement(DefaultButton, __assign({}, props));
      }
    };
    return Button2;
  }(React31.Component)
);

// node_modules/@fluentui/react/lib/components/Button/CommandBarButton/CommandBarButton.js
var React32 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/CommandBarButton/CommandBarButton.styles.js
var getStyles12 = memoizeFunction(function(theme, customStyles, focusInset, focusColor) {
  var _a3, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
  var baseButtonStyles = getStyles6(theme);
  var baseSplitButtonStyles = getStyles7(theme);
  var p = theme.palette, semanticColors = theme.semanticColors;
  var commandButtonHighContrastFocus = {
    left: 4,
    top: 4,
    bottom: 4,
    right: 4,
    border: "none"
  };
  var commandButtonStyles = {
    root: [
      getFocusStyle(theme, {
        inset: 2,
        highContrastStyle: commandButtonHighContrastFocus,
        borderColor: "transparent"
      }),
      theme.fonts.medium,
      {
        minWidth: "40px",
        backgroundColor: p.white,
        color: p.neutralPrimary,
        padding: "0 4px",
        border: "none",
        borderRadius: 0,
        selectors: (_a3 = {}, _a3[HighContrastSelector] = {
          border: "none"
        }, _a3)
      }
    ],
    rootHovered: {
      backgroundColor: p.neutralLighter,
      color: p.neutralDark,
      selectors: (_b = {}, _b[HighContrastSelector] = {
        color: "Highlight"
      }, _b["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: p.themeDarkAlt
      }, _b["." + ButtonGlobalClassNames.msButtonMenuIcon] = {
        color: p.neutralPrimary
      }, _b)
    },
    rootPressed: {
      backgroundColor: p.neutralLight,
      color: p.neutralDark,
      selectors: (_c = {}, _c["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: p.themeDark
      }, _c["." + ButtonGlobalClassNames.msButtonMenuIcon] = {
        color: p.neutralPrimary
      }, _c)
    },
    rootChecked: {
      backgroundColor: p.neutralLight,
      color: p.neutralDark,
      selectors: (_d = {}, _d["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: p.themeDark
      }, _d["." + ButtonGlobalClassNames.msButtonMenuIcon] = {
        color: p.neutralPrimary
      }, _d)
    },
    rootCheckedHovered: {
      backgroundColor: p.neutralQuaternaryAlt,
      selectors: (_e = {}, _e["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: p.themeDark
      }, _e["." + ButtonGlobalClassNames.msButtonMenuIcon] = {
        color: p.neutralPrimary
      }, _e)
    },
    rootExpanded: {
      backgroundColor: p.neutralLight,
      color: p.neutralDark,
      selectors: (_f = {}, _f["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: p.themeDark
      }, _f["." + ButtonGlobalClassNames.msButtonMenuIcon] = {
        color: p.neutralPrimary
      }, _f)
    },
    rootExpandedHovered: {
      backgroundColor: p.neutralQuaternaryAlt
    },
    rootDisabled: {
      backgroundColor: p.white,
      selectors: (_g = {}, _g["." + ButtonGlobalClassNames.msButtonIcon] = {
        color: semanticColors.disabledBodySubtext,
        selectors: (_h = {}, _h[HighContrastSelector] = __assign({ color: "GrayText" }, getHighContrastNoAdjustStyle()), _h)
      }, _g[HighContrastSelector] = __assign({ color: "GrayText", backgroundColor: "Window" }, getHighContrastNoAdjustStyle()), _g)
    },
    // Split button styles
    splitButtonContainer: {
      height: "100%",
      selectors: (_j = {}, _j[HighContrastSelector] = {
        border: "none"
      }, _j)
    },
    splitButtonDividerDisabled: {
      selectors: (_k = {}, _k[HighContrastSelector] = {
        backgroundColor: "Window"
      }, _k)
    },
    splitButtonDivider: {
      backgroundColor: p.neutralTertiaryAlt
    },
    splitButtonMenuButton: {
      backgroundColor: p.white,
      border: "none",
      borderTopRightRadius: "0",
      borderBottomRightRadius: "0",
      color: p.neutralSecondary,
      selectors: {
        ":hover": {
          backgroundColor: p.neutralLighter,
          color: p.neutralDark,
          selectors: (_l = {}, _l[HighContrastSelector] = {
            color: "Highlight"
          }, _l["." + ButtonGlobalClassNames.msButtonIcon] = {
            color: p.neutralPrimary
          }, _l)
        },
        ":active": {
          backgroundColor: p.neutralLight,
          selectors: (_m = {}, _m["." + ButtonGlobalClassNames.msButtonIcon] = {
            color: p.neutralPrimary
          }, _m)
        }
      }
    },
    splitButtonMenuButtonDisabled: {
      backgroundColor: p.white,
      selectors: (_o = {}, _o[HighContrastSelector] = __assign({ color: "GrayText", border: "none", backgroundColor: "Window" }, getHighContrastNoAdjustStyle()), _o)
    },
    splitButtonMenuButtonChecked: {
      backgroundColor: p.neutralLight,
      color: p.neutralDark,
      selectors: {
        ":hover": {
          backgroundColor: p.neutralQuaternaryAlt
        }
      }
    },
    splitButtonMenuButtonExpanded: {
      backgroundColor: p.neutralLight,
      color: p.black,
      selectors: {
        ":hover": {
          backgroundColor: p.neutralQuaternaryAlt
        }
      }
    },
    splitButtonMenuIcon: {
      color: p.neutralPrimary
    },
    splitButtonMenuIconDisabled: {
      color: p.neutralTertiary
    },
    label: {
      fontWeight: "normal"
      // theme.fontWeights.semibold,
    },
    icon: {
      color: p.themePrimary
    },
    menuIcon: (_p = {
      color: p.neutralSecondary
    }, _p[HighContrastSelector] = {
      color: "GrayText"
    }, _p)
  };
  return concatStyleSets(baseButtonStyles, baseSplitButtonStyles, commandButtonStyles, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/CommandBarButton/CommandBarButton.js
var CommandBarButton = (
  /** @class */
  function(_super) {
    __extends(CommandBarButton2, _super);
    function CommandBarButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    CommandBarButton2.prototype.render = function() {
      var _a3 = this.props, styles = _a3.styles, theme = _a3.theme;
      return React32.createElement(BaseButton, __assign({}, this.props, { variantClassName: "ms-Button--commandBar", styles: getStyles12(theme, styles), onRenderDescription: nullRender }));
    };
    CommandBarButton2 = __decorate([
      customizable("CommandBarButton", ["theme", "styles"], true)
    ], CommandBarButton2);
    return CommandBarButton2;
  }(React32.Component)
);

// node_modules/@fluentui/react/lib/components/Button/CommandButton/CommandButton.js
var CommandButton = ActionButton;

// node_modules/@fluentui/react/lib/components/Button/MessageBarButton/MessageBarButton.js
var React33 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Button/MessageBarButton/MessageBarButton.styles.js
var getStyles13 = memoizeFunction(function(theme, customStyles) {
  return concatStyleSets({
    root: [
      getFocusStyle(theme, {
        inset: 1,
        highContrastStyle: {
          outlineOffset: "-4px",
          outline: "1px solid Window"
        },
        borderColor: "transparent"
      }),
      {
        height: 24
      }
    ]
  }, customStyles);
});

// node_modules/@fluentui/react/lib/components/Button/MessageBarButton/MessageBarButton.js
var MessageBarButton = (
  /** @class */
  function(_super) {
    __extends(MessageBarButton2, _super);
    function MessageBarButton2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    MessageBarButton2.prototype.render = function() {
      var _a3 = this.props, styles = _a3.styles, theme = _a3.theme;
      return React33.createElement(DefaultButton, __assign({}, this.props, { styles: getStyles13(theme, styles), onRenderDescription: nullRender }));
    };
    MessageBarButton2 = __decorate([
      customizable("MessageBarButton", ["theme", "styles"], true)
    ], MessageBarButton2);
    return MessageBarButton2;
  }(React33.Component)
);

// node_modules/@fluentui/react/lib/components/Nav/Nav.styles.js
var GlobalClassNames6 = {
  root: "ms-Nav",
  linkText: "ms-Nav-linkText",
  compositeLink: "ms-Nav-compositeLink",
  link: "ms-Nav-link",
  chevronButton: "ms-Nav-chevronButton",
  chevronIcon: "ms-Nav-chevron",
  navItem: "ms-Nav-navItem",
  navItems: "ms-Nav-navItems",
  group: "ms-Nav-group",
  groupContent: "ms-Nav-groupContent"
};
var buttonStyles = {
  textContainer: {
    overflow: "hidden"
  },
  label: {
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    overflow: "hidden"
  }
};
var getStyles14 = function(props) {
  var _a3;
  var className = props.className, theme = props.theme, isOnTop = props.isOnTop, isExpanded = props.isExpanded, isGroup = props.isGroup, isLink = props.isLink, isSelected = props.isSelected, isDisabled = props.isDisabled, isButtonEntry = props.isButtonEntry, _b = props.navHeight, navHeight = _b === void 0 ? 44 : _b, position = props.position, _c = props.leftPadding, leftPadding = _c === void 0 ? 20 : _c, _d = props.leftPaddingExpanded, leftPaddingExpanded = _d === void 0 ? 28 : _d, _e = props.rightPadding, rightPadding = _e === void 0 ? 20 : _e;
  var palette = theme.palette, semanticColors = theme.semanticColors, fonts = theme.fonts;
  var classNames = getGlobalClassNames(GlobalClassNames6, theme);
  return {
    root: [
      classNames.root,
      className,
      fonts.medium,
      {
        overflowY: "auto",
        userSelect: "none",
        WebkitOverflowScrolling: "touch"
      },
      isOnTop && [
        {
          position: "absolute"
        },
        AnimationClassNames.slideRightIn40
      ]
    ],
    linkText: [
      classNames.linkText,
      {
        margin: "0 4px",
        overflow: "hidden",
        verticalAlign: "middle",
        textAlign: "left",
        textOverflow: "ellipsis"
      }
    ],
    compositeLink: [
      classNames.compositeLink,
      {
        display: "block",
        position: "relative",
        color: semanticColors.bodyText
      },
      isExpanded && "is-expanded",
      isSelected && "is-selected",
      isDisabled && "is-disabled",
      isDisabled && {
        color: semanticColors.disabledText
      }
    ],
    link: [
      classNames.link,
      getFocusStyle(theme),
      {
        display: "block",
        position: "relative",
        height: navHeight,
        width: "100%",
        lineHeight: navHeight + "px",
        textDecoration: "none",
        cursor: "pointer",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        paddingLeft: leftPadding,
        paddingRight: rightPadding,
        color: semanticColors.bodyText,
        selectors: (_a3 = {}, _a3[HighContrastSelector] = {
          border: 0,
          selectors: {
            ":focus": {
              border: "1px solid WindowText"
            }
          }
        }, _a3)
      },
      !isDisabled && {
        selectors: {
          ".ms-Nav-compositeLink:hover &": {
            backgroundColor: semanticColors.bodyBackgroundHovered
          }
        }
      },
      isSelected && {
        color: semanticColors.bodyTextChecked,
        fontWeight: FontWeights.semibold,
        backgroundColor: semanticColors.bodyBackgroundChecked,
        selectors: {
          "&:after": {
            borderLeft: "2px solid " + palette.themePrimary,
            content: '""',
            position: "absolute",
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            pointerEvents: "none"
          }
        }
      },
      isDisabled && {
        color: semanticColors.disabledText
      },
      isButtonEntry && {
        color: palette.themePrimary
      }
    ],
    chevronButton: [
      classNames.chevronButton,
      getFocusStyle(theme),
      fonts.small,
      {
        display: "block",
        textAlign: "left",
        lineHeight: navHeight + "px",
        margin: "5px 0",
        padding: "0px, " + rightPadding + "px, 0px, " + leftPaddingExpanded + "px",
        border: "none",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        cursor: "pointer",
        color: semanticColors.bodyText,
        backgroundColor: "transparent",
        selectors: {
          "&:visited": {
            color: semanticColors.bodyText
          }
        }
      },
      isGroup && {
        fontSize: fonts.large.fontSize,
        width: "100%",
        height: navHeight,
        borderBottom: "1px solid " + semanticColors.bodyDivider
      },
      isLink && {
        display: "block",
        width: leftPaddingExpanded - 2,
        height: navHeight - 2,
        position: "absolute",
        top: "1px",
        left: position + "px",
        zIndex: ZIndexes.Nav,
        padding: 0,
        margin: 0
      }
    ],
    chevronIcon: [
      classNames.chevronIcon,
      {
        position: "absolute",
        left: "8px",
        height: navHeight,
        // inline-flex prevents the chevron from shifting with custom line height styles
        display: "inline-flex",
        alignItems: "center",
        lineHeight: navHeight + "px",
        fontSize: fonts.small.fontSize,
        transition: "transform .1s linear"
      },
      isExpanded && {
        transform: "rotate(-180deg)"
      },
      isLink && {
        top: 0
      }
    ],
    navItem: [
      classNames.navItem,
      {
        padding: 0
      }
    ],
    navItems: [
      classNames.navItems,
      {
        listStyleType: "none",
        padding: 0,
        margin: 0
        // remove default <UL> styles
      }
    ],
    group: [classNames.group, isExpanded && "is-expanded"],
    groupContent: [
      classNames.groupContent,
      {
        display: "none",
        marginBottom: "40px"
      },
      AnimationClassNames.slideDownIn20,
      isExpanded && {
        display: "block"
      }
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Nav/Nav.base.js
var _indentationSize = 14;
var _baseIndent = 3;
var _urlResolver;
function isRelativeUrl(url) {
  return !!url && !/^[a-z0-9+-.]+:\/\//i.test(url);
}
var getClassNames6 = classNamesFunction();
var NavBase = (
  /** @class */
  function(_super) {
    __extends(NavBase2, _super);
    function NavBase2(props) {
      var _this = _super.call(this, props) || this;
      _this._focusZone = React34.createRef();
      _this._onRenderLink = function(link) {
        var _a3 = _this.props, styles = _a3.styles, groups = _a3.groups, theme = _a3.theme;
        var classNames = getClassNames6(styles, { theme, groups });
        return React34.createElement("div", { className: classNames.linkText }, link.name);
      };
      _this._renderGroup = function(group, groupIndex) {
        var _a3 = _this.props, styles = _a3.styles, groups = _a3.groups, theme = _a3.theme, _b = _a3.onRenderGroupHeader, onRenderGroupHeader = _b === void 0 ? _this._renderGroupHeader : _b;
        var isExpanded = _this._isGroupExpanded(group);
        var classNames = getClassNames6(styles, {
          theme,
          isGroup: true,
          isExpanded,
          groups
        });
        var finalOnHeaderClick = function(ev, isCollapsing) {
          _this._onGroupHeaderClicked(group, ev);
        };
        var groupProps = __assign(__assign({}, group), { isExpanded, onHeaderClick: finalOnHeaderClick });
        return React34.createElement(
          "div",
          { key: groupIndex, className: classNames.group },
          groupProps.name ? onRenderGroupHeader(groupProps, _this._renderGroupHeader) : null,
          React34.createElement("div", { className: classNames.groupContent }, _this._renderLinks(
            groupProps.links,
            0
            /* nestingLevel */
          ))
        );
      };
      _this._renderGroupHeader = function(group) {
        var _a3;
        var _b = _this.props, styles = _b.styles, groups = _b.groups, theme = _b.theme, expandButtonAriaLabel = _b.expandButtonAriaLabel;
        var isExpanded = group.isExpanded;
        var classNames = getClassNames6(styles, {
          theme,
          isGroup: true,
          isExpanded,
          groups
        });
        var collapseAriaLabel = (_a3 = group.collapseAriaLabel) !== null && _a3 !== void 0 ? _a3 : group.expandAriaLabel;
        var label = (isExpanded ? collapseAriaLabel : group.expandAriaLabel) || expandButtonAriaLabel;
        var onHeaderClick = group.onHeaderClick;
        var onClick = onHeaderClick ? function(ev) {
          onHeaderClick(ev, isExpanded);
        } : void 0;
        return React34.createElement(
          "button",
          { className: classNames.chevronButton, onClick, "aria-label": label, "aria-expanded": isExpanded },
          React34.createElement(Icon, { className: classNames.chevronIcon, iconName: "ChevronDown" }),
          group.name
        );
      };
      initializeComponentRef(_this);
      _this.state = {
        isGroupCollapsed: {},
        // TODO: consider removing
        // eslint-disable-next-line react/no-unused-state
        isLinkExpandStateChanged: false,
        selectedKey: props.initialSelectedKey || props.selectedKey
      };
      return _this;
    }
    NavBase2.prototype.render = function() {
      var _a3 = this.props, styles = _a3.styles, groups = _a3.groups, className = _a3.className, isOnTop = _a3.isOnTop, _b = _a3.role, role = _b === void 0 ? "navigation" : _b, theme = _a3.theme;
      if (!groups) {
        return null;
      }
      var groupElements = groups.map(this._renderGroup);
      var classNames = getClassNames6(styles, { theme, className, isOnTop, groups });
      return React34.createElement(
        FocusZone,
        __assign({ direction: FocusZoneDirection.vertical, componentRef: this._focusZone }, this.props.focusZoneProps),
        React34.createElement("nav", { role, className: classNames.root, "aria-label": this.props.ariaLabel }, groupElements)
      );
    };
    Object.defineProperty(NavBase2.prototype, "selectedKey", {
      get: function() {
        return this.state.selectedKey;
      },
      enumerable: false,
      configurable: true
    });
    NavBase2.prototype.focus = function(forceIntoFirstElement) {
      if (forceIntoFirstElement === void 0) {
        forceIntoFirstElement = false;
      }
      if (this._focusZone && this._focusZone.current) {
        return this._focusZone.current.focus(forceIntoFirstElement);
      }
      return false;
    };
    NavBase2.prototype._renderNavLink = function(link, linkIndex, nestingLevel) {
      var _a3 = this.props, styles = _a3.styles, groups = _a3.groups, theme = _a3.theme;
      var isLinkWithIcon = link.icon || link.iconProps;
      var isSelectedLink = this._isLinkSelected(link);
      var _b = link.ariaCurrent, ariaCurrent = _b === void 0 ? "page" : _b;
      var classNames = getClassNames6(styles, {
        theme,
        isSelected: isSelectedLink,
        isDisabled: link.disabled,
        isButtonEntry: link.onClick && !link.forceAnchor,
        leftPadding: _indentationSize * nestingLevel + _baseIndent + (isLinkWithIcon ? 0 : 24),
        groups
      });
      var rel = link.url && link.target && !isRelativeUrl(link.url) ? "noopener noreferrer" : void 0;
      var LinkAs = this.props.linkAs ? composeComponentAs(this.props.linkAs, ActionButton) : ActionButton;
      var onRenderLink = this.props.onRenderLink ? composeRenderFunction(this.props.onRenderLink, this._onRenderLink) : this._onRenderLink;
      return React34.createElement(LinkAs, {
        className: classNames.link,
        styles: buttonStyles,
        href: link.url || (link.forceAnchor ? "#" : void 0),
        iconProps: link.iconProps || { iconName: link.icon },
        // eslint-disable-next-line react/jsx-no-bind
        onClick: link.onClick ? this._onNavButtonLinkClicked.bind(this, link) : this._onNavAnchorLinkClicked.bind(this, link),
        title: link.title !== void 0 ? link.title : link.name,
        target: link.target,
        rel,
        disabled: link.disabled,
        "aria-current": isSelectedLink ? ariaCurrent : void 0,
        "aria-label": link.ariaLabel ? link.ariaLabel : void 0,
        link
      }, onRenderLink(link));
    };
    NavBase2.prototype._renderCompositeLink = function(link, linkIndex, nestingLevel) {
      var _a3;
      var divProps = __assign({}, getNativeProps(link, divProperties, ["onClick"]));
      var _b = this.props, expandButtonAriaLabel = _b.expandButtonAriaLabel, styles = _b.styles, groups = _b.groups, theme = _b.theme;
      var classNames = getClassNames6(styles, {
        theme,
        isExpanded: !!link.isExpanded,
        isSelected: this._isLinkSelected(link),
        isLink: true,
        isDisabled: link.disabled,
        position: _indentationSize * nestingLevel + 1,
        groups
      });
      var finalExpandBtnAriaLabel = "";
      if (link.links && link.links.length > 0) {
        if (link.collapseAriaLabel || link.expandAriaLabel) {
          var collapseAriaLabel = (_a3 = link.collapseAriaLabel) !== null && _a3 !== void 0 ? _a3 : link.expandAriaLabel;
          finalExpandBtnAriaLabel = link.isExpanded ? collapseAriaLabel : link.expandAriaLabel;
        } else {
          finalExpandBtnAriaLabel = expandButtonAriaLabel ? link.name + " " + expandButtonAriaLabel : link.name;
        }
      }
      return React34.createElement(
        "div",
        __assign({}, divProps, { key: link.key || linkIndex, className: classNames.compositeLink }),
        link.links && link.links.length > 0 ? React34.createElement(
          "button",
          { className: classNames.chevronButton, onClick: this._onLinkExpandClicked.bind(this, link), "aria-label": finalExpandBtnAriaLabel, "aria-expanded": link.isExpanded ? "true" : "false" },
          React34.createElement(Icon, { className: classNames.chevronIcon, iconName: "ChevronDown" })
        ) : null,
        this._renderNavLink(link, linkIndex, nestingLevel)
      );
    };
    NavBase2.prototype._renderLink = function(link, linkIndex, nestingLevel) {
      var _a3 = this.props, styles = _a3.styles, groups = _a3.groups, theme = _a3.theme;
      var classNames = getClassNames6(styles, { theme, groups });
      return React34.createElement(
        "li",
        { key: link.key || linkIndex, role: "listitem", className: classNames.navItem },
        this._renderCompositeLink(link, linkIndex, nestingLevel),
        link.isExpanded ? this._renderLinks(link.links, ++nestingLevel) : null
      );
    };
    NavBase2.prototype._renderLinks = function(links, nestingLevel) {
      var _this = this;
      if (!links || !links.length) {
        return null;
      }
      var linkElements = links.map(function(link, linkIndex) {
        return _this._renderLink(link, linkIndex, nestingLevel);
      });
      var _a3 = this.props, styles = _a3.styles, groups = _a3.groups, theme = _a3.theme;
      var classNames = getClassNames6(styles, { theme, groups });
      return React34.createElement("ul", { role: "list", className: classNames.navItems }, linkElements);
    };
    NavBase2.prototype._onGroupHeaderClicked = function(group, ev) {
      if (group.onHeaderClick) {
        group.onHeaderClick(ev, this._isGroupExpanded(group));
      }
      if (group.isExpanded === void 0) {
        this._toggleCollapsed(group);
      }
      if (ev) {
        ev.preventDefault();
        ev.stopPropagation();
      }
    };
    NavBase2.prototype._onLinkExpandClicked = function(link, ev) {
      var onLinkExpandClick = this.props.onLinkExpandClick;
      if (onLinkExpandClick) {
        onLinkExpandClick(ev, link);
      }
      if (!ev.defaultPrevented) {
        link.isExpanded = !link.isExpanded;
        this.setState({ isLinkExpandStateChanged: true });
      }
      ev.preventDefault();
      ev.stopPropagation();
    };
    NavBase2.prototype._preventBounce = function(link, ev) {
      if (!link.url && link.forceAnchor) {
        ev.preventDefault();
      }
    };
    NavBase2.prototype._onNavAnchorLinkClicked = function(link, ev) {
      this._preventBounce(link, ev);
      if (this.props.onLinkClick) {
        this.props.onLinkClick(ev, link);
      }
      if (!link.url && link.links && link.links.length > 0) {
        this._onLinkExpandClicked(link, ev);
      }
      this.setState({ selectedKey: link.key });
    };
    NavBase2.prototype._onNavButtonLinkClicked = function(link, ev) {
      this._preventBounce(link, ev);
      if (link.onClick) {
        link.onClick(ev, link);
      }
      if (!link.url && link.links && link.links.length > 0) {
        this._onLinkExpandClicked(link, ev);
      }
      this.setState({ selectedKey: link.key });
    };
    NavBase2.prototype._isLinkSelected = function(link) {
      if (this.props.selectedKey !== void 0) {
        return link.key === this.props.selectedKey;
      } else if (this.state.selectedKey !== void 0) {
        return link.key === this.state.selectedKey;
      } else if (typeof getWindow() === "undefined" || !link.url) {
        return false;
      } else {
        _urlResolver = _urlResolver || document.createElement("a");
        _urlResolver.href = link.url || "";
        var target = _urlResolver.href;
        if (location.href === target) {
          return true;
        }
        if (location.protocol + "//" + location.host + location.pathname === target) {
          return true;
        }
        if (location.hash) {
          if (location.hash === link.url) {
            return true;
          }
          _urlResolver.href = location.hash.substring(1);
          return _urlResolver.href === target;
        }
      }
      return false;
    };
    NavBase2.prototype._isGroupExpanded = function(group) {
      if (group.isExpanded !== void 0) {
        return group.isExpanded;
      }
      if (group.name && this.state.isGroupCollapsed.hasOwnProperty(group.name)) {
        return !this.state.isGroupCollapsed[group.name];
      }
      if (group.collapseByDefault !== void 0) {
        return !group.collapseByDefault;
      }
      return true;
    };
    NavBase2.prototype._toggleCollapsed = function(group) {
      var _a3;
      if (group.name) {
        var newGroupCollapsed = __assign(__assign({}, this.state.isGroupCollapsed), (_a3 = {}, _a3[group.name] = this._isGroupExpanded(group), _a3));
        this.setState({ isGroupCollapsed: newGroupCollapsed });
      }
    };
    NavBase2.defaultProps = {
      groups: null
    };
    return NavBase2;
  }(React34.Component)
);

// node_modules/@fluentui/react/lib/components/Nav/Nav.js
var Nav = styled(NavBase, getStyles14, void 0, {
  scope: "Nav"
});

export {
  DirectionalHint,
  RectangleEdge,
  Position,
  positionElement,
  positionCallout,
  positionCard,
  getMaxHeight,
  getOppositeEdge,
  getBoundsFromTargetWindow,
  Popup,
  CalloutContentBase,
  CalloutContent,
  FabricBase,
  Fabric,
  registerLayer,
  unregisterLayer,
  getLayerCount,
  getLayerHost,
  registerLayerHost,
  unregisterLayerHost,
  createDefaultLayerHost,
  cleanupDefaultLayerHost,
  notifyHostChanged,
  setDefaultTarget,
  getDefaultTarget,
  LayerBase,
  getStyles3 as getStyles,
  Layer,
  LayerHost,
  Callout,
  FocusTrapZone,
  FocusTrapCallout,
  FocusZoneTabbableElements,
  FocusZoneDirection,
  FocusZone,
  ContextualMenuItemType,
  ContextualMenuItemBase,
  getMenuItemStyles,
  getItemClassNames,
  getItemStyles,
  ContextualMenuItem,
  transitionKeysAreEqual,
  transitionKeysContain,
  buildKeytipConfigMap,
  constructKeytip,
  KTP_PREFIX,
  KTP_SEPARATOR,
  KTP_FULL_PREFIX,
  DATAKTP_TARGET,
  DATAKTP_EXECUTE_TARGET,
  DATAKTP_ARIA_TARGET,
  KTP_LAYER_ID,
  KTP_ARIA_SEPARATOR,
  KeytipEvents,
  KeytipManager,
  sequencesToID,
  mergeOverflows,
  ktpTargetFromSequences,
  ktpTargetFromId,
  getAriaDescribedBy,
  KeytipData,
  useKeytipRef,
  VerticalDivider,
  BaseDecorator,
  ResponsiveMode,
  setResponsiveMode,
  initializeResponsiveMode,
  getInitialResponsiveMode,
  withResponsiveMode,
  getResponsiveMode,
  useResponsiveMode,
  getSubmenuItems,
  canAnyMenuItemsCheck,
  ContextualMenuBase,
  ContextualMenu,
  ButtonGlobalClassNames,
  getSplitButtonClassNames,
  BaseButton,
  ElementType,
  ButtonType,
  getStyles6 as getStyles2,
  DefaultButton,
  getStyles9 as getStyles3,
  ActionButton,
  CompoundButton,
  IconButton,
  PrimaryButton,
  Button,
  CommandBarButton,
  CommandButton,
  MessageBarButton,
  isRelativeUrl,
  NavBase,
  Nav
};
//# sourceMappingURL=chunk-QGX6AQKV.js.map
