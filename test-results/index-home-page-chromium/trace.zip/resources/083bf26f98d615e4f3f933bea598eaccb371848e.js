import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useLocation, useNavigate, useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { Link, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { testProcessQueryServices } from "/src/modules/audit/testProcess/service/index.ts";
import { TestProcessPathNumberedRecord, TestProcessPathRecord } from "/src/shared/record/index.ts";
const sortConfig = {
  field: "nome",
  descending: false
};
const AuditExecutionTestProcessSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const [searchParams] = useSearchParams();
  const {
    auditId,
    visionType,
    testId,
    testProcessType
  } = useParams();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const {
    data: audit,
    isLoading: loadingAudit
  } = auditQueryService.useFindOne(auditId);
  const {
    data,
    isLoading
  } = testProcessQueryServices.useFindAll(auditId, TestProcessPathNumberedRecord[testProcessType], {
    $orderby: `${sortConfig.field.replaceAll(".", "/")} ${sortConfig.descending ? "desc" : "asc"}`
  });
  const testProcessDescription = useMemo(() => {
    if (!testProcessType)
      return "";
    return TestProcessPathRecord[testProcessType];
  }, [testProcessType]);
  const navLinkGroups = useMemo(() => {
    if (data) {
      return [{
        links: data?.map((link) => ({
          name: `${link.codCadastro} - ${link.nome}`,
          permission: "Auditoria",
          key: link.id,
          url: `${pathname.split(visionType)[0]}${visionType}/${link.id}?description=${searchParams.get("description")}`
        }))
      }];
    }
  }, [data, testId]);
  const permissionNav = useMemo(() => {
    const filteredGroup = navLinkGroups ? [...navLinkGroups] : [];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups, testId]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(`${pathname.split(visionType)[0]}details/${item.key}`);
    }
  };
  const handleNavigateBack = useCallback(() => {
    const path = pathname.split("tests")[0];
    navigate(path.includes("financial-statements") ? `${path}old` : path);
  }, [pathname]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: testProcessDescription, isLoading: loadingAudit || isLoading, disabledCollapse: true, subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx",
    lineNumber: 85,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx",
    lineNumber: 84,
    columnNumber: 116
  }, this), selectedKey: testId, groups: permissionNav, onLinkClick: handleClick, goBack: handleNavigateBack }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx",
    lineNumber: 84,
    columnNumber: 10
  }, this);
};
_s(AuditExecutionTestProcessSideMenu, "OLq45LgSD9cNWGlolaoM0RHVzlQ=", false, function() {
  return [useNavigate, useLocation, useSearchParams, useParams, usePermissions, useTheme, auditQueryService.useFindOne, testProcessQueryServices.useFindAll];
});
_c = AuditExecutionTestProcessSideMenu;
export default AuditExecutionTestProcessSideMenu;
var _c;
$RefreshReg$(_c, "AuditExecutionTestProcessSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestProcessSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUZWLFNBQXlCQSxhQUFhQyxlQUFlO0FBRXJELFNBQVNDLGFBQWFDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUNyRSxTQUF1QkMsc0JBQXNCO0FBQzdDLFNBQThCQyxnQkFBZ0I7QUFDOUMsU0FBU0MsTUFBTUMsWUFBWTtBQUMzQixTQUFTQyxnQkFBZ0I7QUFFekIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxnQ0FBZ0M7QUFDekMsU0FBU0MsK0JBQStCQyw2QkFBNkI7QUFHckUsTUFBTUMsYUFBa0M7QUFBQSxFQUN0Q0MsT0FBTztBQUFBLEVBQ1BDLFlBQVk7QUFDZDtBQUVBLE1BQU1DLG9DQUF3Q0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2xELFFBQU1DLFdBQVdsQixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFbUI7QUFBQUEsRUFBUyxJQUFJcEIsWUFBWTtBQUNqQyxRQUFNLENBQUNxQixZQUFZLElBQUlsQixnQkFBZ0I7QUFDdkMsUUFBTTtBQUFBLElBQUVtQjtBQUFBQSxJQUFTQztBQUFBQSxJQUFZQztBQUFBQSxJQUFRQztBQUFBQSxFQUFnQixJQUFJdkIsVUFBcUM7QUFDOUYsUUFBTTtBQUFBLElBQUV3QjtBQUFBQSxFQUFjLElBQUl0QixlQUFlO0FBQ3pDLFFBQU07QUFBQSxJQUFFdUI7QUFBQUEsSUFBUUM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBWUM7QUFBQUEsRUFBUyxJQUFJdEIsU0FBUztBQUMzRCxRQUFNO0FBQUEsSUFBRXVCLE1BQU1DO0FBQUFBLElBQU9DLFdBQVdDO0FBQUFBLEVBQWEsSUFBSXpCLGtCQUFrQjBCLFdBQVdiLE9BQWlCO0FBRS9GLFFBQU07QUFBQSxJQUFFUztBQUFBQSxJQUFNRTtBQUFBQSxFQUFVLElBQUl0Qix5QkFBeUJ5QixXQUNuRGQsU0FDQVYsOEJBQThCYSxlQUFzQyxHQUNwRTtBQUFBLElBQ0VZLFVBQVcsR0FBRXZCLFdBQVdDLE1BQU11QixXQUFXLEtBQUssR0FBRyxLQUFLeEIsV0FBV0UsYUFBYSxTQUFTO0FBQUEsRUFDekYsQ0FDRjtBQUVBLFFBQU11Qix5QkFBeUJ4QyxRQUFRLE1BQU07QUFDM0MsUUFBSSxDQUFDMEI7QUFBaUIsYUFBTztBQUM3QixXQUFPWixzQkFBc0JZLGVBQXNDO0FBQUEsRUFDckUsR0FBRyxDQUFDQSxlQUFlLENBQUM7QUFFcEIsUUFBTWUsZ0JBQTZDekMsUUFBUSxNQUFNO0FBQy9ELFFBQUlnQyxNQUFNO0FBQ1IsYUFBTyxDQUNMO0FBQUEsUUFDRVUsT0FBT1YsTUFBTVcsSUFBSUMsV0FBVTtBQUFBLFVBQ3pCQyxNQUFPLEdBQUVELEtBQUtFLGlCQUFpQkYsS0FBS0c7QUFBQUEsVUFDcENDLFlBQVk7QUFBQSxVQUNaQyxLQUFLTCxLQUFLTTtBQUFBQSxVQUNWQyxLQUFNLEdBQUU5QixTQUFTK0IsTUFBTTVCLFVBQW9CLEVBQUUsQ0FBQyxJQUFJQSxjQUFjb0IsS0FBS00sa0JBQWtCNUIsYUFBYStCLElBQUksYUFBYTtBQUFBLFFBQ3ZILEVBQWU7QUFBQSxNQUNqQixDQUFDO0FBQUEsSUFFTDtBQUFBLEVBQ0YsR0FBRyxDQUFDckIsTUFBTVAsTUFBTSxDQUFDO0FBRWpCLFFBQU02QixnQkFBZ0J0RCxRQUFRLE1BQU07QUFDbEMsVUFBTXVELGdCQUFpQ2QsZ0JBQWdCLENBQUMsR0FBR0EsYUFBYSxJQUFJO0FBQzVFYyxrQkFBY0MsUUFBUSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3RDSCxvQkFBY0csS0FBSyxFQUFFaEIsUUFBUWUsTUFBTWYsTUFBTWlCLE9BQU9DLGFBQVdqQyxjQUFjaUMsUUFBUVosWUFBNEIsWUFBWSxDQUFDO0FBQUEsSUFDNUgsQ0FBQztBQUNELFdBQU9PO0FBQUFBLEVBQ1QsR0FBRyxDQUFDZCxlQUFlaEIsTUFBTSxDQUFDO0FBRTFCLFFBQU1vQyxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQjdDLGVBQVUsR0FBRUMsU0FBUytCLE1BQU01QixVQUFvQixFQUFFLENBQUMsWUFBWXVDLEtBQUtkLEtBQUs7QUFBQSxJQUMxRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUIscUJBQXFCbkUsWUFBWSxNQUFNO0FBQzNDLFVBQU1vRSxPQUFPOUMsU0FBUytCLE1BQU0sT0FBTyxFQUFFLENBQUM7QUFDdENoQyxhQUFTK0MsS0FBS0MsU0FBUyxzQkFBc0IsSUFBSyxHQUFFRCxZQUFZQSxJQUFJO0FBQUEsRUFDdEUsR0FBRyxDQUFDOUMsUUFBUSxDQUFDO0FBRWIsU0FDRSx1QkFBQyxZQUNDLE9BQU9tQix3QkFDUCxXQUFXTCxnQkFBZ0JELFdBQzNCLGtCQUFnQixNQUNoQixVQUNFLHVCQUFDLFFBQ0MsTUFDRyxrQkFBaUJELE9BQU9vQyxVQUFVQyx1QkFDakNyQyxPQUFPb0MsVUFBVUUsc0JBQ1osR0FBRXRDLE9BQU9vQyxTQUFTRSxtQ0FBbUN0QyxPQUFPb0MsVUFBVUcsbUJBQ3ZFdkMsT0FBT29DLFVBQVVuQixNQUd6QixRQUFPLFNBRVAsaUNBQUMsUUFDQyxRQUFRO0FBQUEsSUFDTnVCLE1BQU07QUFBQSxNQUNKQyxPQUFPOUMsT0FBTytDLEtBQUssR0FBRztBQUFBLE1BQ3RCN0MsWUFBWUEsV0FBVzhDO0FBQUFBLE1BQ3ZCN0MsVUFBVUEsU0FBUzhDO0FBQUFBLE1BQ25CQyxxQkFBcUJsRCxPQUFPK0MsS0FBSyxHQUFHO0FBQUEsTUFDcENJLFlBQVlsRCxRQUFRbUQ7QUFBQUEsTUFDcEJDLFVBQVU7QUFBQSxNQUNWQyxjQUFjckQsUUFBUXNEO0FBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUTCxxQkFBcUJsRCxPQUFPK0MsS0FBSyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLE9BQUssTUFFSjFDO0FBQUFBLFdBQU9vQyxVQUFVZTtBQUFBQSxJQUFhO0FBQUEsSUFBSXpFLHFCQUFxQnNCLE9BQU9vQyxVQUFVRyxjQUF3QjtBQUFBLE9BakJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsR0FFRixhQUFhL0MsUUFDYixRQUFRNkIsZUFDUixhQUFhTyxhQUNiLFFBQVFLLHNCQXZDVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUM2QjtBQUdqQztBQUFDL0MsR0FwR0tELG1DQUFxQztBQUFBLFVBQ3hCaEIsYUFDSUQsYUFDRUcsaUJBQ2tDRCxXQUMvQkUsZ0JBQ3dCSSxVQUNEQyxrQkFBa0IwQixZQUV2Q3hCLHlCQUF5QnlCLFVBQVU7QUFBQTtBQUFBZ0QsS0FUM0RuRTtBQXNHTixlQUFlQTtBQUFpQyxJQUFBbUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ1c2VTZWFyY2hQYXJhbXMiLCJ1c2VQZXJtaXNzaW9ucyIsIlNpZGVNZW51IiwiTGluayIsIlRleHQiLCJ1c2VUaGVtZSIsImF1ZGl0UXVlcnlTZXJ2aWNlIiwiZm9ybWF0UHJvcG9zYWxOdW1iZXIiLCJ0ZXN0UHJvY2Vzc1F1ZXJ5U2VydmljZXMiLCJUZXN0UHJvY2Vzc1BhdGhOdW1iZXJlZFJlY29yZCIsIlRlc3RQcm9jZXNzUGF0aFJlY29yZCIsInNvcnRDb25maWciLCJmaWVsZCIsImRlc2NlbmRpbmciLCJBdWRpdEV4ZWN1dGlvblRlc3RQcm9jZXNzU2lkZU1lbnUiLCJfcyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJzZWFyY2hQYXJhbXMiLCJhdWRpdElkIiwidmlzaW9uVHlwZSIsInRlc3RJZCIsInRlc3RQcm9jZXNzVHlwZSIsImhhc1Blcm1pc3Npb24iLCJjb2xvcnMiLCJzcGFjaW5nIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwiZGF0YSIsImF1ZGl0IiwiaXNMb2FkaW5nIiwibG9hZGluZ0F1ZGl0IiwidXNlRmluZE9uZSIsInVzZUZpbmRBbGwiLCIkb3JkZXJieSIsInJlcGxhY2VBbGwiLCJ0ZXN0UHJvY2Vzc0Rlc2NyaXB0aW9uIiwibmF2TGlua0dyb3VwcyIsImxpbmtzIiwibWFwIiwibGluayIsIm5hbWUiLCJjb2RDYWRhc3RybyIsIm5vbWUiLCJwZXJtaXNzaW9uIiwia2V5IiwiaWQiLCJ1cmwiLCJzcGxpdCIsImdldCIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXJlZEdyb3VwIiwiZm9yRWFjaCIsImdyb3VwIiwiaW5kZXgiLCJmaWx0ZXIiLCJuYXZMaW5rIiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZU5hdmlnYXRlQmFjayIsInBhdGgiLCJpbmNsdWRlcyIsImNvbnRyYXRvIiwiY2xpZW50ZUlkIiwiY29udHJhdG9QcmluY2lwYWxJZCIsIm51bWVyb1Byb3Bvc3RhIiwicm9vdCIsImNvbG9yIiwiZ3JheSIsInNlbWlib2xkIiwicDE0IiwidGV4dERlY29yYXRpb25Db2xvciIsIm1hcmdpbkxlZnQiLCJsZyIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwibWQiLCJub21lRmFudGFzaWEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0RXhlY3V0aW9uVGVzdFByb2Nlc3NTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRFeGVjdXRpb25UZXN0UHJvY2Vzc1NpZGVNZW51LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBNb3VzZUV2ZW50LCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJTmF2TGlua0dyb3VwLCBJTmF2TGluayB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC9saWIvTmF2J1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcywgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXHJcbmltcG9ydCB7IERhdGFUYWJsZVNvcnRDb25maWcsIFNpZGVNZW51IH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IExpbmssIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBJRXhlY3V0aW9uVGVzdHNQYWdlUGFyYW1zIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3R5cGVzL3BhZ2VSb3V0ZXNQYXJhbXMnXHJcbmltcG9ydCB7IGF1ZGl0UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vYXVkaXRzL3NlcnZpY2VzJ1xyXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgdGVzdFByb2Nlc3NRdWVyeVNlcnZpY2VzIH0gZnJvbSAnLi4vdGVzdFByb2Nlc3Mvc2VydmljZSdcclxuaW1wb3J0IHsgVGVzdFByb2Nlc3NQYXRoTnVtYmVyZWRSZWNvcmQsIFRlc3RQcm9jZXNzUGF0aFJlY29yZCB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQnXHJcbmltcG9ydCB7IFRlc3RQcm9jZXNzUGF0aEVudW0gfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvZW51bXMvVGVzdFByb2Nlc3NQYXRoRW51bSdcclxuXHJcbmNvbnN0IHNvcnRDb25maWc6IERhdGFUYWJsZVNvcnRDb25maWcgPSB7XHJcbiAgZmllbGQ6ICdub21lJyxcclxuICBkZXNjZW5kaW5nOiBmYWxzZSxcclxufVxyXG5cclxuY29uc3QgQXVkaXRFeGVjdXRpb25UZXN0UHJvY2Vzc1NpZGVNZW51OiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxyXG4gIGNvbnN0IHsgYXVkaXRJZCwgdmlzaW9uVHlwZSwgdGVzdElkLCB0ZXN0UHJvY2Vzc1R5cGUgfSA9IHVzZVBhcmFtczxJRXhlY3V0aW9uVGVzdHNQYWdlUGFyYW1zPigpXHJcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXHJcbiAgY29uc3QgeyBjb2xvcnMsIHNwYWNpbmcsIGZvbnRXZWlnaHQsIGZvbnRTaXplIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgeyBkYXRhOiBhdWRpdCwgaXNMb2FkaW5nOiBsb2FkaW5nQXVkaXQgfSA9IGF1ZGl0UXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoYXVkaXRJZCBhcyBzdHJpbmcpXHJcblxyXG4gIGNvbnN0IHsgZGF0YSwgaXNMb2FkaW5nIH0gPSB0ZXN0UHJvY2Vzc1F1ZXJ5U2VydmljZXMudXNlRmluZEFsbChcclxuICAgIGF1ZGl0SWQsXHJcbiAgICBUZXN0UHJvY2Vzc1BhdGhOdW1iZXJlZFJlY29yZFt0ZXN0UHJvY2Vzc1R5cGUgYXMgVGVzdFByb2Nlc3NQYXRoRW51bV0sXHJcbiAgICB7XHJcbiAgICAgICRvcmRlcmJ5OiBgJHtzb3J0Q29uZmlnLmZpZWxkLnJlcGxhY2VBbGwoJy4nLCAnLycpfSAke3NvcnRDb25maWcuZGVzY2VuZGluZyA/ICdkZXNjJyA6ICdhc2MnfWAsXHJcbiAgICB9LFxyXG4gIClcclxuXHJcbiAgY29uc3QgdGVzdFByb2Nlc3NEZXNjcmlwdGlvbiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCF0ZXN0UHJvY2Vzc1R5cGUpIHJldHVybiAnJ1xyXG4gICAgcmV0dXJuIFRlc3RQcm9jZXNzUGF0aFJlY29yZFt0ZXN0UHJvY2Vzc1R5cGUgYXMgVGVzdFByb2Nlc3NQYXRoRW51bV1cclxuICB9LCBbdGVzdFByb2Nlc3NUeXBlXSlcclxuXHJcbiAgY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdIHwgdW5kZWZpbmVkID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoZGF0YSkge1xyXG4gICAgICByZXR1cm4gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGxpbmtzOiBkYXRhPy5tYXAobGluayA9PiAoKHtcclxuICAgICAgICAgICAgbmFtZTogYCR7bGluay5jb2RDYWRhc3Ryb30gLSAke2xpbmsubm9tZX1gLFxyXG4gICAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgICAga2V5OiBsaW5rLmlkLFxyXG4gICAgICAgICAgICB1cmw6IGAke3BhdGhuYW1lLnNwbGl0KHZpc2lvblR5cGUgYXMgc3RyaW5nKVswXX0ke3Zpc2lvblR5cGV9LyR7bGluay5pZH0/ZGVzY3JpcHRpb249JHtzZWFyY2hQYXJhbXMuZ2V0KCdkZXNjcmlwdGlvbicpfWAsXHJcbiAgICAgICAgICB9KSBhcyBJTmF2TGluaykpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF1cclxuICAgIH1cclxuICB9LCBbZGF0YSwgdGVzdElkXSlcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbk5hdiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gbmF2TGlua0dyb3VwcyA/IFsuLi5uYXZMaW5rR3JvdXBzXSA6IFtdXHJcbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyb3VwLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5wZXJtaXNzaW9uIGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInKSlcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZmlsdGVyZWRHcm91cFxyXG4gIH0sIFtuYXZMaW5rR3JvdXBzLCB0ZXN0SWRdKVxyXG5cclxuICBjb25zdCBoYW5kbGVDbGljayA9IChldj86IE1vdXNlRXZlbnQsIGl0ZW0/OiBJTmF2TGluaykgPT4ge1xyXG4gICAgaWYgKGV2ICE9PSB1bmRlZmluZWQgJiYgaXRlbSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgbmF2aWdhdGUoYCR7cGF0aG5hbWUuc3BsaXQodmlzaW9uVHlwZSBhcyBzdHJpbmcpWzBdfWRldGFpbHMvJHtpdGVtLmtleX1gKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTmF2aWdhdGVCYWNrID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgY29uc3QgcGF0aCA9IHBhdGhuYW1lLnNwbGl0KCd0ZXN0cycpWzBdXHJcbiAgICBuYXZpZ2F0ZShwYXRoLmluY2x1ZGVzKCdmaW5hbmNpYWwtc3RhdGVtZW50cycpID8gYCR7cGF0aH1vbGRgIDogcGF0aClcclxuICB9LCBbcGF0aG5hbWVdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNpZGVNZW51XHJcbiAgICAgIHRpdGxlPXt0ZXN0UHJvY2Vzc0Rlc2NyaXB0aW9ufVxyXG4gICAgICBpc0xvYWRpbmc9e2xvYWRpbmdBdWRpdCB8fCBpc0xvYWRpbmd9XHJcbiAgICAgIGRpc2FibGVkQ29sbGFwc2VcclxuICAgICAgc3VidGl0bGU9e1xyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICBocmVmPXtcclxuICAgICAgICAgICAgYC9hZG1pbi9jbGllbnRzLyR7YXVkaXQ/LmNvbnRyYXRvPy5jbGllbnRlSWR9L2NvbnRyYWN0cy8ke1xyXG4gICAgICAgICAgICAgIGF1ZGl0Py5jb250cmF0bz8uY29udHJhdG9QcmluY2lwYWxJZFxyXG4gICAgICAgICAgICAgICAgPyBgJHthdWRpdD8uY29udHJhdG8uY29udHJhdG9QcmluY2lwYWxJZH0/c3ViY29udHJhY3Q9JHthdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhfWBcclxuICAgICAgICAgICAgICAgIDogYXVkaXQ/LmNvbnRyYXRvPy5pZFxyXG4gICAgICAgICAgICB9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGFyZ2V0PVwiYmxhbmtcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXHJcbiAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAyMDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXHJcbiAgICAgICAgICAgICAgICAnOjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2F1ZGl0Py5jb250cmF0bz8ubm9tZUZhbnRhc2lhfSAtIHtmb3JtYXRQcm9wb3NhbE51bWJlcihhdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhIGFzIHN0cmluZyl9XHJcbiAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICB9XHJcbiAgICAgIHNlbGVjdGVkS2V5PXt0ZXN0SWR9XHJcbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cclxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBnb0JhY2s9e2hhbmRsZU5hdmlnYXRlQmFja31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWRpdEV4ZWN1dGlvblRlc3RQcm9jZXNzU2lkZU1lbnVcclxuIl19