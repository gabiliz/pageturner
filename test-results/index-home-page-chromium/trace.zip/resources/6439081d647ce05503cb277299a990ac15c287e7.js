import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn } from "/src/shared/components/FlexBox/index.ts";
const NotificationsCenterSettingsSection = (props) => {
  _s();
  const {
    spacing
  } = useTheme();
  const {
    cardStyles
  } = useStyles();
  return /* @__PURE__ */ jsxDEV(FlexColumn, { className: cardStyles.container, children: [
    /* @__PURE__ */ jsxDEV(Text, { as: "p", className: cardStyles.title, children: props.title }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Text, { as: "span", className: cardStyles.subtitle, children: props.subtitle }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: spacing.xs, className: cardStyles.content, children: props.children }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterSettingsSection, "VsyZ+OvjBMqotQbAcxSMrhOz8sU=", false, function() {
  return [useTheme, useStyles];
});
_c = NotificationsCenterSettingsSection;
const useStyles = () => {
  _s2();
  const {
    spacing,
    fontSize,
    fontWeight,
    colors
  } = useTheme();
  const cardStyles = mergeStyleSets({
    container: {
      padding: spacing.lg,
      border: `${colors.neutralLight[300]} 1px solid`,
      borderRadius: 2
    },
    title: {
      fontSize: fontSize.p16,
      fontWeight: fontWeight.semibold,
      margin: 0
    },
    subtitle: {
      fontSize: fontSize.p16,
      fontWeight: fontWeight.regular,
      color: colors.gray[400]
    },
    content: {
      marginTop: spacing.lg
    }
  });
  return {
    cardStyles
  };
};
_s2(useStyles, "CqO0AgI4Hw9eyRYDZ8Z1V/J6bEg=", false, function() {
  return [useTheme];
});
export default NotificationsCenterSettingsSection;
var _c;
$RefreshReg$(_c, "NotificationsCenterSettingsSection");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFmTixTQUFTQSxnQkFBZ0JDLFlBQVk7QUFFckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQU8zQixNQUFNQyxxQ0FBbUZDLFdBQVU7QUFBQUMsS0FBQTtBQUNqRyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBUSxJQUFJTCxTQUFTO0FBQzdCLFFBQU07QUFBQSxJQUFFTTtBQUFBQSxFQUFXLElBQUlDLFVBQVU7QUFDakMsU0FDRSx1QkFBQyxjQUFXLFdBQVdELFdBQVdFLFdBQ2hDO0FBQUEsMkJBQUMsUUFBSyxJQUFHLEtBQUksV0FBV0YsV0FBV0csT0FBUU4sZ0JBQU1NLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFBQSxJQUN2RCx1QkFBQyxRQUFLLElBQUcsUUFBTyxXQUFXSCxXQUFXSSxVQUNuQ1AsZ0JBQU1PLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxjQUFXLEtBQUtMLFFBQVFNLElBQUksV0FBV0wsV0FBV00sU0FDaERULGdCQUFNVSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ1QsR0FkS0Ysb0NBQStFO0FBQUEsVUFDL0RGLFVBQ0dPLFNBQVM7QUFBQTtBQUFBTyxLQUY1Qlo7QUFnQk4sTUFBTUssWUFBWUEsTUFBTTtBQUFBUSxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFVjtBQUFBQSxJQUFTVztBQUFBQSxJQUFVQztBQUFBQSxJQUFZQztBQUFBQSxFQUFPLElBQUlsQixTQUFTO0FBRTNELFFBQU1NLGFBQWFSLGVBQWU7QUFBQSxJQUNoQ1UsV0FBVztBQUFBLE1BQ1RXLFNBQVNkLFFBQVFlO0FBQUFBLE1BQ2pCQyxRQUFTLEdBQUVILE9BQU9JLGFBQWEsR0FBRztBQUFBLE1BQ2xDQyxjQUFjO0FBQUEsSUFDaEI7QUFBQSxJQUNBZCxPQUFPO0FBQUEsTUFDTE8sVUFBVUEsU0FBU1E7QUFBQUEsTUFDbkJQLFlBQVlBLFdBQVdRO0FBQUFBLE1BQ3ZCQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FoQixVQUFVO0FBQUEsTUFDUk0sVUFBVUEsU0FBU1E7QUFBQUEsTUFDbkJQLFlBQVlBLFdBQVdVO0FBQUFBLE1BQ3ZCQyxPQUFPVixPQUFPVyxLQUFLLEdBQUc7QUFBQSxJQUN4QjtBQUFBLElBQ0FqQixTQUFTO0FBQUEsTUFDUGtCLFdBQVd6QixRQUFRZTtBQUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU87QUFBQSxJQUNMZDtBQUFBQSxFQUNGO0FBQ0Y7QUFBQ1MsSUEzQktSLFdBQVM7QUFBQSxVQUNxQ1AsUUFBUTtBQUFBO0FBNEI1RCxlQUFlRTtBQUFrQyxJQUFBWTtBQUFBaUIsYUFBQWpCLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsIlRleHQiLCJ1c2VUaGVtZSIsIkZsZXhDb2x1bW4iLCJOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uIiwicHJvcHMiLCJfcyIsInNwYWNpbmciLCJjYXJkU3R5bGVzIiwidXNlU3R5bGVzIiwiY29udGFpbmVyIiwidGl0bGUiLCJzdWJ0aXRsZSIsInhzIiwiY29udGVudCIsImNoaWxkcmVuIiwiX2MiLCJfczIiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvcnMiLCJwYWRkaW5nIiwibGciLCJib3JkZXIiLCJuZXV0cmFsTGlnaHQiLCJib3JkZXJSYWRpdXMiLCJwMTYiLCJzZW1pYm9sZCIsIm1hcmdpbiIsInJlZ3VsYXIiLCJjb2xvciIsImdyYXkiLCJtYXJnaW5Ub3AiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL25vdGlmaWNhdGlvbnMvY29tcG9uZW50cy9Ob3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1lcmdlU3R5bGVTZXRzLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MnXG5pbXBvcnQgeyBGbGV4Q29sdW1uIH0gZnJvbSAnLi4vLi4vRmxleEJveCdcblxuaW50ZXJmYWNlIE5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc1NlY3Rpb25Qcm9wcyB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgc3VidGl0bGU6IHN0cmluZ1xufVxuXG5jb25zdCBOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uOiBGQzxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCB7IGNhcmRTdHlsZXMgfSA9IHVzZVN0eWxlcygpXG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW4gY2xhc3NOYW1lPXtjYXJkU3R5bGVzLmNvbnRhaW5lcn0+XG4gICAgICA8VGV4dCBhcz0ncCcgY2xhc3NOYW1lPXtjYXJkU3R5bGVzLnRpdGxlfT57cHJvcHMudGl0bGV9PC9UZXh0PlxuICAgICAgPFRleHQgYXM9J3NwYW4nIGNsYXNzTmFtZT17Y2FyZFN0eWxlcy5zdWJ0aXRsZX0+XG4gICAgICAgIHtwcm9wcy5zdWJ0aXRsZX1cbiAgICAgIDwvVGV4dD5cbiAgICAgIDxGbGV4Q29sdW1uIGdhcD17c3BhY2luZy54c30gY2xhc3NOYW1lPXtjYXJkU3R5bGVzLmNvbnRlbnR9PlxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XG4gICAgICA8L0ZsZXhDb2x1bW4+XG4gICAgPC9GbGV4Q29sdW1uPlxuICApXG59XG5cbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgeyBzcGFjaW5nLCBmb250U2l6ZSwgZm9udFdlaWdodCwgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG5cbiAgY29uc3QgY2FyZFN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcbiAgICBjb250YWluZXI6IHtcbiAgICAgIHBhZGRpbmc6IHNwYWNpbmcubGcsXG4gICAgICBib3JkZXI6IGAke2NvbG9ycy5uZXV0cmFsTGlnaHRbMzAwXX0gMXB4IHNvbGlkYCxcbiAgICAgIGJvcmRlclJhZGl1czogMixcbiAgICB9LFxuICAgIHRpdGxlOiB7XG4gICAgICBmb250U2l6ZTogZm9udFNpemUucDE2LFxuICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcbiAgICAgIG1hcmdpbjogMCxcbiAgICB9LFxuICAgIHN1YnRpdGxlOiB7XG4gICAgICBmb250U2l6ZTogZm9udFNpemUucDE2LFxuICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5yZWd1bGFyLFxuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzQwMF0sXG4gICAgfSxcbiAgICBjb250ZW50OiB7XG4gICAgICBtYXJnaW5Ub3A6IHNwYWNpbmcubGcsXG4gICAgfSxcbiAgfSlcblxuICByZXR1cm4ge1xuICAgIGNhcmRTdHlsZXMsXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzU2VjdGlvblxuIl19