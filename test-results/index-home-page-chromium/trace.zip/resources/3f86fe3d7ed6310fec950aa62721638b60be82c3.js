import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/fileDisplay/FileDisplay.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Icon, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { getFileTypeIconProps } from "/node_modules/.vite/deps/@fluentui_react-file-type-icons.js?v=9f90a7ff";
import { TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { FileExtensionEnum } from "/src/shared/enums/FileExtensionEnum.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import FileExtensionRecord from "/src/shared/record/FileExtensionRecord.ts";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
const FileDisplay = ({
  extension,
  name
}) => {
  _s();
  const {
    colors,
    fontWeight
  } = useTheme();
  const iconExtension = extension.replace(/\./g, "") || FileExtensionEnum.txt;
  return /* @__PURE__ */ jsxDEV(FlexRow, { gap: 7, verticalAlign: "center", wrap: "nowrap", styles: {
    position: "relative"
  }, children: [
    /* @__PURE__ */ jsxDEV(Icon, { ...getFileTypeIconProps({
      extension: FileExtensionRecord[iconExtension],
      size: 16
    }), styles: {
      root: {
        overflow: "initial",
        width: 20
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TooltipHost, { content: name, styles: {
      root: {
        width: "100%"
      }
    }, children: /* @__PURE__ */ jsxDEV(Text, { nowrap: true, variant: "mediumPlus", styles: {
      root: {
        color: colors.gray[400],
        fontWeight: fontWeight.regular,
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        width: "94%",
        display: "block",
        fontSize: 12
      }
    }, children: name }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx",
      lineNumber: 41,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_s(FileDisplay, "/ezGRJMw4+/ZPFFb2HhcorAb2Qw=", false, function() {
  return [useTheme];
});
_c = FileDisplay;
export default FileDisplay;
var _c;
$RefreshReg$(_c, "FileDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/FileDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJOLFNBQVNBLE1BQU1DLFlBQVk7QUFDM0IsU0FBU0MsNEJBQTRCO0FBRXJDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyxhQUFhO0FBT3BCLE1BQU1DLGNBQW9DQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBV0M7QUFBSyxNQUFNO0FBQUFDLEtBQUE7QUFDakUsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLEVBQVcsSUFBSVIsU0FBUztBQUN4QyxRQUFNUyxnQkFBZ0JMLFVBQVVNLFFBQVEsT0FBTyxFQUFFLEtBQTBCWCxrQkFBa0JZO0FBRTdGLFNBQ0UsdUJBQUMsV0FBUSxLQUFNLEdBQUksZUFBYyxVQUFTLE1BQUssVUFBUyxRQUFRO0FBQUEsSUFBRUMsVUFBVTtBQUFBLEVBQVcsR0FDckY7QUFBQSwyQkFBQyxRQUNDLEdBQUlmLHFCQUFxQjtBQUFBLE1BQUVPLFdBQVdILG9CQUFvQlEsYUFBYTtBQUFBLE1BQUdJLE1BQU07QUFBQSxJQUFHLENBQUMsR0FDcEYsUUFBUTtBQUFBLE1BQUVDLE1BQU07QUFBQSxRQUFFQyxVQUFVO0FBQUEsUUFBV0MsT0FBTztBQUFBLE1BQUc7QUFBQSxJQUFFLEtBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFdUQ7QUFBQSxJQUV2RCx1QkFBQyxlQUNDLFNBQVNYLE1BQ1QsUUFBUTtBQUFBLE1BQUVTLE1BQU07QUFBQSxRQUFFRSxPQUFPO0FBQUEsTUFBTztBQUFBLElBQUUsR0FFbEMsaUNBQUMsUUFDQyxRQUFNLE1BQ04sU0FBUSxjQUNSLFFBQVE7QUFBQSxNQUNORixNQUFNO0FBQUEsUUFDSkcsT0FBT1YsT0FBT1csS0FBSyxHQUFHO0FBQUEsUUFDdEJWLFlBQVlBLFdBQVdXO0FBQUFBLFFBQ3ZCQyxZQUFZO0FBQUEsUUFDWkwsVUFBVTtBQUFBLFFBQ1ZNLGNBQWM7QUFBQSxRQUNkTCxPQUFPO0FBQUEsUUFDUE0sU0FBUztBQUFBLFFBQ1RDLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixHQUVDbEIsa0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLE9BM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkE7QUFFSjtBQUFDQyxHQW5DS0gsYUFBaUM7QUFBQSxVQUNOSCxRQUFRO0FBQUE7QUFBQXdCLEtBRG5DckI7QUFxQ04sZUFBZUE7QUFBVyxJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkljb24iLCJUZXh0IiwiZ2V0RmlsZVR5cGVJY29uUHJvcHMiLCJUb29sdGlwSG9zdCIsIkZpbGVFeHRlbnNpb25FbnVtIiwidXNlVGhlbWUiLCJGaWxlRXh0ZW5zaW9uUmVjb3JkIiwiRmxleFJvdyIsIkZpbGVEaXNwbGF5IiwiZXh0ZW5zaW9uIiwibmFtZSIsIl9zIiwiY29sb3JzIiwiZm9udFdlaWdodCIsImljb25FeHRlbnNpb24iLCJyZXBsYWNlIiwidHh0IiwicG9zaXRpb24iLCJzaXplIiwicm9vdCIsIm92ZXJmbG93Iiwid2lkdGgiLCJjb2xvciIsImdyYXkiLCJyZWd1bGFyIiwid2hpdGVTcGFjZSIsInRleHRPdmVyZmxvdyIsImRpc3BsYXkiLCJmb250U2l6ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmlsZURpc3BsYXkudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZmlsZURpc3BsYXkvRmlsZURpc3BsYXkudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSWNvbiwgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IGdldEZpbGVUeXBlSWNvblByb3BzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWZpbGUtdHlwZS1pY29ucydcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBUb29sdGlwSG9zdCB9IGZyb20gJy4uJ1xuaW1wb3J0IHsgRmlsZUV4dGVuc2lvbkVudW0gfSBmcm9tICcuLi8uLi9lbnVtcy9GaWxlRXh0ZW5zaW9uRW51bSdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5pbXBvcnQgRmlsZUV4dGVuc2lvblJlY29yZCBmcm9tICcuLi8uLi9yZWNvcmQvRmlsZUV4dGVuc2lvblJlY29yZCdcbmltcG9ydCBGbGV4Um93IGZyb20gJy4vLi4vRmxleEJveC9GbGV4Um93J1xuXG5pbnRlcmZhY2UgRmlsZURpc3BsYXlQcm9wcyB7XG4gIGV4dGVuc2lvbjogc3RyaW5nXG4gIG5hbWU6IHN0cmluZ1xufVxuXG5jb25zdCBGaWxlRGlzcGxheTogRkM8RmlsZURpc3BsYXlQcm9wcz4gPSAoeyBleHRlbnNpb24sIG5hbWUgfSkgPT4ge1xuICBjb25zdCB7IGNvbG9ycywgZm9udFdlaWdodCB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCBpY29uRXh0ZW5zaW9uID0gZXh0ZW5zaW9uLnJlcGxhY2UoL1xcLi9nLCAnJykgYXMgRmlsZUV4dGVuc2lvbkVudW0gfHwgRmlsZUV4dGVuc2lvbkVudW0udHh0XG5cbiAgcmV0dXJuIChcbiAgICA8RmxleFJvdyBnYXA9eyA3IH0gdmVydGljYWxBbGlnbj1cImNlbnRlclwiIHdyYXA9J25vd3JhcCcgc3R5bGVzPXt7IHBvc2l0aW9uOiAncmVsYXRpdmUnIH19PlxuICAgICAgPEljb25cbiAgICAgICAgey4uLmdldEZpbGVUeXBlSWNvblByb3BzKHsgZXh0ZW5zaW9uOiBGaWxlRXh0ZW5zaW9uUmVjb3JkW2ljb25FeHRlbnNpb25dLCBzaXplOiAxNiB9KX1cbiAgICAgICAgc3R5bGVzPXt7IHJvb3Q6IHsgb3ZlcmZsb3c6ICdpbml0aWFsJywgd2lkdGg6IDIwIH0gfX1cbiAgICAgIC8+XG4gICAgICA8VG9vbHRpcEhvc3RcbiAgICAgICAgY29udGVudD17bmFtZX1cbiAgICAgICAgc3R5bGVzPXt7IHJvb3Q6IHsgd2lkdGg6ICcxMDAlJyB9IH19XG4gICAgICA+XG4gICAgICAgIDxUZXh0XG4gICAgICAgICAgbm93cmFwXG4gICAgICAgICAgdmFyaWFudD1cIm1lZGl1bVBsdXNcIlxuICAgICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgICAgcm9vdDoge1xuICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNDAwXSxcbiAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5yZWd1bGFyLFxuICAgICAgICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgICAgICB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcycsXG4gICAgICAgICAgICAgIHdpZHRoOiAnOTQlJyxcbiAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgZm9udFNpemU6IDEyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge25hbWV9XG4gICAgICAgIDwvVGV4dD5cbiAgICAgIDwvVG9vbHRpcEhvc3Q+XG4gICAgPC9GbGV4Um93PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEZpbGVEaXNwbGF5XG4iXX0=