export var RegulatoryBodyEnum = /* @__PURE__ */ ((RegulatoryBodyEnum2) => {
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["CVM"] = 0] = "CVM";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["ANS"] = 1] = "ANS";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["ANEEL"] = 2] = "ANEEL";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["SUSEP"] = 3] = "SUSEP";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["ANTT"] = 4] = "ANTT";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["BACEN"] = 5] = "BACEN";
  RegulatoryBodyEnum2[RegulatoryBodyEnum2["CFC"] = 6] = "CFC";
  return RegulatoryBodyEnum2;
})(RegulatoryBodyEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJlZ3VsYXRvcnlCb2R5RW51bS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xuZXhwb3J0IGVudW0gUmVndWxhdG9yeUJvZHlFbnVtIHtcbiAgQ1ZNLFxuICBBTlMsXG4gIEFORUVMLFxuICBTVVNFUCxcbiAgQU5UVCxcbiAgQkFDRU4sXG4gIENGQyxcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ08sV0FBSyxxQkFBTCxrQkFBS0Esd0JBQUw7QUFDTCxFQUFBQSx3Q0FBQTtBQUNBLEVBQUFBLHdDQUFBO0FBQ0EsRUFBQUEsd0NBQUE7QUFDQSxFQUFBQSx3Q0FBQTtBQUNBLEVBQUFBLHdDQUFBO0FBQ0EsRUFBQUEsd0NBQUE7QUFDQSxFQUFBQSx3Q0FBQTtBQVBVLFNBQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6WyJSZWd1bGF0b3J5Qm9keUVudW0iXX0=