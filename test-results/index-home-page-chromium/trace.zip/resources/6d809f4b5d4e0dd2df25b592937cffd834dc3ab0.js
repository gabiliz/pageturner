import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Label } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"]; const useCallback = __vite__cjsImport4_react["useCallback"];
import { Checkbox, DatePicker, FlexColumn, FlexItem, FlexRow, TextField, MaskedTextField, ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { RolesDropdown } from "/src/modules/admin/roles/components/index.ts?t=1701096626433";
import { OfficesDropdown } from "/src/modules/admin/offices/components/index.ts?t=1701096626433";
import { ProfileDropdown } from "/src/modules/admin/profiles/components/index.ts?t=1701096626433";
import { UserAvatarUpload } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
const emptyUser = {
  nome: "",
  email: "",
  image: "",
  status: true,
  genero: 0,
  dataNascimento: (/* @__PURE__ */ new Date()).toISOString(),
  dataAdmissao: (/* @__PURE__ */ new Date()).toISOString(),
  apelido: "",
  nroCrc: "",
  phoneNumber: "",
  possuiVeiculo: false,
  possuiCrc: false,
  possuiCnaiQtg: false,
  possuiCnaiBacen: false,
  possuiCnaiSusep: false,
  possuiCnaiCvm: false,
  possuiCnaiPrevic: false,
  socio: false,
  desenvolvedor: false,
  perfilId: "",
  cargo: null,
  escritorios: [],
  responsavelRelatorio: false
};
const status = [{
  key: "true",
  text: "Habilitado"
}, {
  key: "false",
  text: "Desabilitado"
}];
const stackTokens = 12;
const UserEditForm = (props) => {
  _s();
  const theme = useTheme();
  const {
    currentAccount
  } = useAuth();
  const {
    formData,
    onChange,
    apiError
  } = props;
  const {
    formData: localFormData,
    onTextChange,
    onDropdownChange,
    onDateChange,
    onCheckboxChange,
    onMultiDropdownChange,
    onNumberTextChange,
    onFieldError,
    setFormData: setLocalFormData
  } = useFormData(formData ?? emptyUser);
  const [selectedRole, setSelectedRole] = useState("");
  const [selectedOffices, setSelectedOffices] = useState([]);
  useEffect(() => {
    if (formData) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData]);
  useEffect(() => {
    if (localFormData.cargo?.cargoId) {
      setSelectedRole(localFormData.cargo.cargoId);
    }
  }, [localFormData.cargo]);
  useEffect(() => {
    setSelectedOffices(localFormData.escritorios?.map((office) => office.escritorioId) ?? []);
  }, [localFormData.escritorios]);
  const handleStatusDropdown = useCallback((_, value) => {
    if (value !== void 0) {
      const newValue = value.key === "true";
      setLocalFormData({
        ...localFormData,
        status: newValue
      });
    }
  }, [localFormData]);
  const handleRoleDropdown = useCallback((_, value) => {
    if (value !== void 0) {
      const roleId = value.key;
      const roleDate = /* @__PURE__ */ new Date();
      setLocalFormData({
        ...localFormData,
        cargo: {
          cargoId: roleId,
          dataInicial: roleDate.toISOString()
        }
      });
    }
  }, [localFormData]);
  const removeImage = useCallback(() => {
    setLocalFormData({
      ...localFormData,
      image: ""
    });
  }, [localFormData]);
  const maskFormat = useCallback(() => {
    if (localFormData.phoneNumber === null) {
      localFormData.phoneNumber = "";
    }
    return localFormData.phoneNumber.length < 11 ? "(99) 9999-99999" : "(99) 9 9999-9999";
  }, [localFormData]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: stackTokens, children: [
    /* @__PURE__ */ jsxDEV(UserAvatarUpload, { image: localFormData.image, onChange: (path) => onTextChange("image")(null, path), hasImage: localFormData.image !== "", removeImage }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: stackTokens, children: /* @__PURE__ */ jsxDEV(FlexItem, { grow: 2, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Apelido", required: true, value: localFormData.apelido, onChange: onTextChange("apelido"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("apelido", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 124,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 123,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Atuações" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.lg, children: [
        /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Sócio", onChange: onCheckboxChange("socio"), checked: localFormData.socio }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 131,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 130,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Responsável por relatório", onChange: onCheckboxChange("responsavelRelatorio"), checked: localFormData.responsavelRelatorio }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 134,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 133,
          columnNumber: 11
        }, this),
        (currentAccount.value?.id === localFormData.id && localFormData.desenvolvedor || currentAccount.value?.administrator) && /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Desenvolvedor", disabled: true, checked: localFormData.desenvolvedor }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 137,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 136,
          columnNumber: 133
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 129,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome Completo", required: true, value: localFormData.nome, onChange: onTextChange("nome"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("nome", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DatePicker, { label: "Data de nascimento", value: new Date(localFormData.dataNascimento), allowTextInput: true, onSelectDate: onDateChange("dataNascimento"), formatString: "dd/MM/yyyy", styles: {
      root: {
        width: "25%"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DatePicker, { label: "Data de admissão", value: new Date(localFormData.dataAdmissao), allowTextInput: true, onSelectDate: onDateChange("dataAdmissao"), formatString: "dd/MM/yyyy", styles: {
      root: {
        width: "25%"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 147,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "E-mail", required: true, value: localFormData.email, maxLength: 450, onChange: onTextChange("email"), errorMessage: apiError?.errors?.messages ? onFieldError("email", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MaskedTextField, { label: "Telefone", mask: maskFormat(), maskChar: " ", onChange: onNumberTextChange("phoneNumber"), value: localFormData.phoneNumber ?? "", styles: {
      root: {
        width: "25%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("phoneNumber", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 153,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ProfileDropdown, { label: "Perfil", required: true, selectedKey: localFormData.perfilId, onChange: onDropdownChange("perfilId"), styles: {
      root: {
        width: "50%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("perfilId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 158,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ComboBox, { label: "Situação", options: status, onChange: handleStatusDropdown, selectedKey: localFormData.status.toString(), styles: {
      root: {
        width: "50%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("status", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(OfficesDropdown, { label: "Escritório", multiSelect: true, selectedKeys: selectedOffices, onChange: onMultiDropdownChange("escritorios", "escritorioId"), styles: {
      root: {
        width: "50%"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    !localFormData.id && /* @__PURE__ */ jsxDEV(RolesDropdown, { label: "Cargo", required: true, selectedKey: selectedRole, onChange: handleRoleDropdown, styles: {
      root: {
        width: "50%"
      }
    }, errorMessage: apiError?.errors?.messages ? onFieldError("cargo", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 173,
      columnNumber: 29
    }, this),
    /* @__PURE__ */ jsxDEV(Checkbox, { label: "Possui veículo", onChange: onCheckboxChange("possuiVeiculo"), checked: localFormData.possuiVeiculo, styles: {
      label: {
        marginTop: theme.spacing.xs,
        marginBottom: theme.spacing.xs
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 178,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.xs, children: [
      /* @__PURE__ */ jsxDEV(Checkbox, { label: "Registro CRC", onChange: onCheckboxChange("possuiCrc"), checked: localFormData.possuiCrc, styles: {
        label: {
          marginTop: theme.spacing.xs,
          marginBottom: theme.spacing.xs
        }
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this),
      localFormData.possuiCrc && /* @__PURE__ */ jsxDEV(TextField, { onChange: onTextChange("nroCrc"), value: localFormData.nroCrc, maxLength: 30, styles: {
        root: {
          width: "50%"
        }
      }, errorMessage: apiError?.errors?.messages ? onFieldError("perfilId", apiError?.errors?.messages) : void 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 191,
        columnNumber: 37
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 184,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.xs, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Registro CNAI" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 198,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexColumn, { gap: stackTokens, children: [
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "QTG", onChange: onCheckboxChange("possuiCnaiQtg"), checked: localFormData.possuiCnaiQtg }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 200,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "BACEN", onChange: onCheckboxChange("possuiCnaiBacen"), checked: localFormData.possuiCnaiBacen }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 201,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "SUSEP", onChange: onCheckboxChange("possuiCnaiSusep"), checked: localFormData.possuiCnaiSusep }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 202,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "CVM", onChange: onCheckboxChange("possuiCnaiCvm"), checked: localFormData.possuiCnaiCvm }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 203,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "PREVIC", onChange: onCheckboxChange("possuiCnaiPrevic"), checked: localFormData.possuiCnaiPrevic }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
          lineNumber: 204,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
        lineNumber: 199,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
      lineNumber: 197,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx",
    lineNumber: 120,
    columnNumber: 10
  }, this);
};
_s(UserEditForm, "CWnFCGON9siJXazYVpL56eZzQNw=", false, function() {
  return [useTheme, useAuth, useFormData];
});
_c = UserEditForm;
export default UserEditForm;
var _c;
$RefreshReg$(_c, "UserEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0lNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdElOLFNBQ0VBLGFBRUs7QUFDUCxTQUFhQyxXQUFXQyxVQUFVQyxtQkFBbUI7QUFHckQsU0FBU0MsVUFBVUMsWUFBWUMsWUFBWUMsVUFBVUMsU0FBU0MsV0FBV0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUcsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFlBQWtCO0FBQUEsRUFDdEJDLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLFFBQVE7QUFBQSxFQUNSQyxRQUFRO0FBQUEsRUFDUkMsaUJBQWdCLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVk7QUFBQSxFQUN2Q0MsZUFBYyxvQkFBSUYsS0FBSyxHQUFFQyxZQUFZO0FBQUEsRUFDckNFLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQUEsRUFDUkMsYUFBYTtBQUFBLEVBQ2JDLGVBQWU7QUFBQSxFQUNmQyxXQUFXO0FBQUEsRUFDWEMsZUFBZTtBQUFBLEVBQ2ZDLGlCQUFpQjtBQUFBLEVBQ2pCQyxpQkFBaUI7QUFBQSxFQUNqQkMsZUFBZTtBQUFBLEVBQ2ZDLGtCQUFrQjtBQUFBLEVBQ2xCQyxPQUFPO0FBQUEsRUFDUEMsZUFBZTtBQUFBLEVBQ2ZDLFVBQVU7QUFBQSxFQUNWQyxPQUFPO0FBQUEsRUFDUEMsYUFBYTtBQUFBLEVBQ2JDLHNCQUFzQjtBQUN4QjtBQUVBLE1BQU1yQixTQUE0QixDQUNoQztBQUFBLEVBQUVzQixLQUFLO0FBQUEsRUFBUUMsTUFBTTtBQUFhLEdBQ2xDO0FBQUEsRUFBRUQsS0FBSztBQUFBLEVBQVNDLE1BQU07QUFBZSxDQUFDO0FBR3hDLE1BQU1DLGNBQWM7QUFFcEIsTUFBTUMsZUFBeUNDLFdBQVU7QUFBQUMsS0FBQTtBQUN2RCxRQUFNQyxRQUFRdEMsU0FBUztBQUN2QixRQUFNO0FBQUEsSUFBRXVDO0FBQUFBLEVBQWUsSUFBSWxDLFFBQVE7QUFDbkMsUUFBTTtBQUFBLElBQUVtQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxFQUFTLElBQUlOO0FBQ3pDLFFBQU07QUFBQSxJQUNKSSxVQUFVRztBQUFBQSxJQUNWQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxhQUFhQztBQUFBQSxFQUNmLElBQUlyRCxZQUFrQnlDLFlBQVlsQyxTQUFTO0FBRTNDLFFBQU0sQ0FBQytDLGNBQWNDLGVBQWUsSUFBSWpFLFNBQWlCLEVBQUU7QUFDM0QsUUFBTSxDQUFDa0UsaUJBQWlCQyxrQkFBa0IsSUFBSW5FLFNBQW1CLEVBQUU7QUFFbkVELFlBQVUsTUFBTTtBQUNkLFFBQUlvRCxVQUFVO0FBQ1pZLHVCQUFpQlosUUFBUTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLENBQUNBLFFBQVEsQ0FBQztBQUVicEQsWUFBVSxNQUFNO0FBQ2RxRCxlQUFXRSxhQUFhO0FBQUEsRUFDMUIsR0FBRyxDQUFDQSxhQUFhLENBQUM7QUFFbEJ2RCxZQUFVLE1BQU07QUFDZCxRQUFJdUQsY0FBY2QsT0FBTzRCLFNBQVM7QUFDaENILHNCQUFnQlgsY0FBY2QsTUFBTTRCLE9BQU87QUFBQSxJQUM3QztBQUFBLEVBQ0YsR0FBRyxDQUFDZCxjQUFjZCxLQUFLLENBQUM7QUFFeEJ6QyxZQUFVLE1BQU07QUFDZG9FLHVCQUNFYixjQUFjYixhQUFhNEIsSUFDeEJDLFlBQVdBLE9BQU9DLFlBQ3JCLEtBQUssRUFDUDtBQUFBLEVBQ0YsR0FBRyxDQUFDakIsY0FBY2IsV0FBVyxDQUFDO0FBRTlCLFFBQU0rQix1QkFBdUJ2RSxZQUFZLENBQUN3RSxHQUFhQyxVQUE0QjtBQUNqRixRQUFJQSxVQUFVQyxRQUFXO0FBQ3ZCLFlBQU1DLFdBQVdGLE1BQU0vQixRQUFRO0FBQy9Cb0IsdUJBQWlCO0FBQUEsUUFDZixHQUFHVDtBQUFBQSxRQUNIakMsUUFBUXVEO0FBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ3RCLGFBQWEsQ0FBQztBQUVsQixRQUFNdUIscUJBQXFCNUUsWUFBWSxDQUFDd0UsR0FBYUMsVUFBNEI7QUFDL0UsUUFBSUEsVUFBVUMsUUFBVztBQUN2QixZQUFNRyxTQUFTSixNQUFNL0I7QUFDckIsWUFBTW9DLFdBQVcsb0JBQUl2RCxLQUFLO0FBQzFCdUMsdUJBQWlCO0FBQUEsUUFDZixHQUFHVDtBQUFBQSxRQUNIZCxPQUFPO0FBQUEsVUFDTDRCLFNBQVNVO0FBQUFBLFVBQ1RFLGFBQWFELFNBQVN0RCxZQUFZO0FBQUEsUUFDcEM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUM2QixhQUFhLENBQUM7QUFFbEIsUUFBTTJCLGNBQWNoRixZQUFZLE1BQU07QUFDcEM4RCxxQkFBaUI7QUFBQSxNQUNmLEdBQUdUO0FBQUFBLE1BQ0hsQyxPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNrQyxhQUFhLENBQUM7QUFFbEIsUUFBTTRCLGFBQWFqRixZQUFZLE1BQU07QUFDbkMsUUFBSXFELGNBQWN6QixnQkFBZ0IsTUFBTTtBQUN0Q3lCLG9CQUFjekIsY0FBYztBQUFBLElBQzlCO0FBRUEsV0FBT3lCLGNBQWN6QixZQUFZc0QsU0FBUyxLQUN0QyxvQkFDQTtBQUFBLEVBQ04sR0FBRyxDQUFDN0IsYUFBYSxDQUFDO0FBRWxCLFNBQ0UsdUJBQUMsY0FBVyxLQUFLVCxhQUNmO0FBQUEsMkJBQUMsb0JBQ0MsT0FBT1MsY0FBY2xDLE9BQ3JCLFVBQVVnRSxVQUFRN0IsYUFBYSxPQUFPLEVBQUUsTUFBTTZCLElBQUksR0FDbEQsVUFBVTlCLGNBQWNsQyxVQUFVLElBQ2xDLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUkyQjtBQUFBLElBRTNCLHVCQUFDLFdBQ0MsZUFBYyxVQUNkLEtBQUt5QixhQUVMLGlDQUFDLFlBQVMsTUFBTSxHQUNkLGlDQUFDLGFBQ0MsT0FBTSxXQUNOLFVBQVEsTUFDUixPQUFPUyxjQUFjM0IsU0FDckIsVUFBVTRCLGFBQWEsU0FBUyxHQUNoQyxXQUFXLEtBQ1gsY0FBY0YsVUFBVWdDLFFBQVFDLFdBQzVCekIsYUFBYSxXQUFXUixVQUFVZ0MsUUFBUUMsUUFBUSxJQUNsRFgsVUFSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0csS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBQ0EsdUJBQUMsY0FDQztBQUFBLDZCQUFDLFNBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxXQUFRLEtBQUsxQixNQUFNc0MsUUFBUUMsSUFDMUI7QUFBQSwrQkFBQyxZQUFTLE1BQU0sR0FDZCxpQ0FBQyxZQUNDLE9BQU0sU0FDTixVQUFVOUIsaUJBQWlCLE9BQU8sR0FDbEMsU0FBU0osY0FBY2pCLFNBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHK0IsS0FKakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxZQUFTLE1BQU0sR0FDZCxpQ0FBQyxZQUNDLE9BQU0sNkJBQ04sVUFBVXFCLGlCQUFpQixzQkFBc0IsR0FDakQsU0FBU0osY0FBY1osd0JBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHOEMsS0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsU0FHSVEsZUFBZXdCLE9BQU9lLE9BQU9uQyxjQUFjbUMsTUFDN0NuQyxjQUFjaEIsaUJBRWRZLGVBQWV3QixPQUFPZ0Isa0JBQ25CLHVCQUFDLFlBQVMsTUFBTSxHQUNuQixpQ0FBQyxZQUNDLE9BQU0saUJBQ04sVUFBUSxNQUNSLFNBQVNwQyxjQUFjaEIsaUJBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHdUMsS0FKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1MO0FBQUEsV0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQkE7QUFBQSxJQUNBLHVCQUFDLGFBQ0MsT0FBTSxpQkFDTixVQUFRLE1BQ1IsT0FBT2dCLGNBQWNwQyxNQUNyQixVQUFVcUMsYUFBYSxNQUFNLEdBQzdCLFdBQVcsS0FDWCxjQUFjRixVQUFVZ0MsUUFBUUMsV0FDNUJ6QixhQUFhLFFBQVFSLFVBQVVnQyxRQUFRQyxRQUFRLElBQy9DWCxVQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTRztBQUFBLElBRUgsdUJBQUMsY0FDQyxPQUFNLHNCQUNOLE9BQU8sSUFBSW5ELEtBQUs4QixjQUFjL0IsY0FBYyxHQUM1QyxnQkFBYyxNQUNkLGNBQWNrQyxhQUFhLGdCQUFnQixHQUMzQyxjQUFjLGNBQ2QsUUFBUTtBQUFBLE1BQ05rQyxNQUFNO0FBQUEsUUFBRUMsT0FBTztBQUFBLE1BQU07QUFBQSxJQUN2QixLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRSTtBQUFBLElBRUosdUJBQUMsY0FDQyxPQUFNLG9CQUNOLE9BQU8sSUFBSXBFLEtBQUs4QixjQUFjNUIsWUFBWSxHQUMxQyxnQkFBYyxNQUNkLGNBQWMrQixhQUFhLGNBQWMsR0FDekMsY0FBYyxjQUNkLFFBQVE7QUFBQSxNQUNOa0MsTUFBTTtBQUFBLFFBQUVDLE9BQU87QUFBQSxNQUFNO0FBQUEsSUFDdkIsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUk7QUFBQSxJQUVKLHVCQUFDLGFBQ0MsT0FBTSxVQUNOLFVBQVEsTUFDUixPQUFPdEMsY0FBY25DLE9BQ3JCLFdBQVcsS0FDWCxVQUFVb0MsYUFBYSxPQUFPLEdBQzlCLGNBQWNGLFVBQVVnQyxRQUFRQyxXQUM1QnpCLGFBQWEsU0FBU1IsVUFBVWdDLFFBQVFDLFFBQVEsSUFDaERYLFVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNHO0FBQUEsSUFFSCx1QkFBQyxtQkFDQyxPQUFNLFlBQ04sTUFBTU8sV0FBVyxHQUNqQixVQUFTLEtBQ1QsVUFBVXRCLG1CQUFtQixhQUFhLEdBQzFDLE9BQU9OLGNBQWN6QixlQUFlLElBQ3BDLFFBQVE7QUFBQSxNQUNOOEQsTUFBTTtBQUFBLFFBQUVDLE9BQU87QUFBQSxNQUFNO0FBQUEsSUFDdkIsR0FDQSxjQUFjdkMsVUFBVWdDLFFBQVFDLFdBQzVCekIsYUFBYSxlQUFlUixVQUFVZ0MsUUFBUUMsUUFBUSxJQUN0RFgsVUFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUc7QUFBQSxJQUVILHVCQUFDLG1CQUNDLE9BQU8sVUFDUCxVQUFRLE1BQ1IsYUFBYXJCLGNBQWNmLFVBQzNCLFVBQVVpQixpQkFBaUIsVUFBVSxHQUNyQyxRQUFRO0FBQUEsTUFDTm1DLE1BQU07QUFBQSxRQUFFQyxPQUFPO0FBQUEsTUFBTTtBQUFBLElBQ3ZCLEdBQ0EsY0FBY3ZDLFVBQVVnQyxRQUFRQyxXQUM1QnpCLGFBQWEsWUFBWVIsVUFBVWdDLFFBQVFDLFFBQVEsSUFDbkRYLFVBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdHO0FBQUEsSUFFSCx1QkFBQyxZQUNDLE9BQU0sWUFDTixTQUFTdEQsUUFDVCxVQUFVbUQsc0JBQ1YsYUFBYWxCLGNBQWNqQyxPQUFPd0UsU0FBUyxHQUMzQyxRQUFRO0FBQUEsTUFDTkYsTUFBTTtBQUFBLFFBQUVDLE9BQU87QUFBQSxNQUFNO0FBQUEsSUFDdkIsR0FDQSxjQUFjdkMsVUFBVWdDLFFBQVFDLFdBQzVCekIsYUFBYSxVQUFVUixVQUFVZ0MsUUFBUUMsUUFBUSxJQUNqRFgsVUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0c7QUFBQSxJQUVILHVCQUFDLG1CQUNDLE9BQU0sY0FDTixhQUFXLE1BQ1gsY0FBY1QsaUJBQ2QsVUFBVVAsc0JBQXNCLGVBQWUsY0FBYyxHQUM3RCxRQUFRO0FBQUEsTUFDTmdDLE1BQU07QUFBQSxRQUFFQyxPQUFPO0FBQUEsTUFBTTtBQUFBLElBQ3ZCLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9JO0FBQUEsSUFFSCxDQUFDdEMsY0FBY21DLE1BQ2QsdUJBQUMsaUJBQ0MsT0FBTSxTQUNOLFVBQVEsTUFDUixhQUFhekIsY0FDYixVQUFVYSxvQkFDVixRQUFRO0FBQUEsTUFDTmMsTUFBTTtBQUFBLFFBQUVDLE9BQU87QUFBQSxNQUFNO0FBQUEsSUFDdkIsR0FDQSxjQUFjdkMsVUFBVWdDLFFBQVFDLFdBQzVCekIsYUFBYSxTQUFTUixVQUFVZ0MsUUFBUUMsUUFBUSxJQUNoRFgsVUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0c7QUFBQSxJQUdMLHVCQUFDLFlBQ0MsT0FBTSxrQkFDTixVQUFVakIsaUJBQWlCLGVBQWUsR0FDMUMsU0FBU0osY0FBY3hCLGVBQ3ZCLFFBQVE7QUFBQSxNQUNOZ0UsT0FBTztBQUFBLFFBQ0xDLFdBQVc5QyxNQUFNc0MsUUFBUVM7QUFBQUEsUUFDekJDLGNBQWNoRCxNQUFNc0MsUUFBUVM7QUFBQUEsTUFDOUI7QUFBQSxJQUNGLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNJO0FBQUEsSUFFSix1QkFBQyxjQUFXLEtBQU0vQyxNQUFNc0MsUUFBUVMsSUFDOUI7QUFBQSw2QkFBQyxZQUNDLE9BQU0sZ0JBQ04sVUFBVXRDLGlCQUFpQixXQUFXLEdBQ3RDLFNBQVNKLGNBQWN2QixXQUN2QixRQUFRO0FBQUEsUUFDTitELE9BQU87QUFBQSxVQUNMQyxXQUFXOUMsTUFBTXNDLFFBQVFTO0FBQUFBLFVBQ3pCQyxjQUFjaEQsTUFBTXNDLFFBQVFTO0FBQUFBLFFBQzlCO0FBQUEsTUFDRixLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTSTtBQUFBLE1BRUgxQyxjQUFjdkIsYUFDYix1QkFBQyxhQUNDLFVBQVV3QixhQUFhLFFBQVEsR0FDL0IsT0FBT0QsY0FBYzFCLFFBQ3JCLFdBQVcsSUFDWCxRQUFRO0FBQUEsUUFDTitELE1BQU07QUFBQSxVQUFFQyxPQUFPO0FBQUEsUUFBTTtBQUFBLE1BQ3ZCLEdBQ0EsY0FBY3ZDLFVBQVVnQyxRQUFRQyxXQUM1QnpCLGFBQWEsWUFBWVIsVUFBVWdDLFFBQVFDLFFBQVEsSUFDbkRYLFVBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVHO0FBQUEsU0F2QlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxLQUFNMUIsTUFBTXNDLFFBQVFTLElBQzlCO0FBQUEsNkJBQUMsU0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEIsdUJBQUMsY0FBVyxLQUFLbkQsYUFDZjtBQUFBLCtCQUFDLFlBQ0MsT0FBTSxPQUNOLFVBQVVhLGlCQUFpQixlQUFlLEdBQzFDLFNBQVNKLGNBQWN0QixpQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd1QztBQUFBLFFBRXZDLHVCQUFDLFlBQ0MsT0FBTSxTQUNOLFVBQVUwQixpQkFBaUIsaUJBQWlCLEdBQzVDLFNBQVNKLGNBQWNyQixtQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd5QztBQUFBLFFBRXpDLHVCQUFDLFlBQ0MsT0FBTSxTQUNOLFVBQVV5QixpQkFBaUIsaUJBQWlCLEdBQzVDLFNBQVNKLGNBQWNwQixtQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd5QztBQUFBLFFBRXpDLHVCQUFDLFlBQ0MsT0FBTSxPQUNOLFVBQVV3QixpQkFBaUIsZUFBZSxHQUMxQyxTQUFTSixjQUFjbkIsaUJBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHdUM7QUFBQSxRQUV2Qyx1QkFBQyxZQUNDLE9BQU0sVUFDTixVQUFVdUIsaUJBQWlCLGtCQUFrQixHQUM3QyxTQUFTSixjQUFjbEIsb0JBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHMEM7QUFBQSxXQXhCNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxPQXRPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdU9BO0FBRUo7QUFBQ1ksR0E5VEtGLGNBQXFDO0FBQUEsVUFDM0JuQyxVQUNhSyxTQVl2Qk4sV0FBVztBQUFBO0FBQUF3RixLQWRYcEQ7QUFnVU4sZUFBZUE7QUFBWSxJQUFBb0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxhYmVsIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsIkNoZWNrYm94IiwiRGF0ZVBpY2tlciIsIkZsZXhDb2x1bW4iLCJGbGV4SXRlbSIsIkZsZXhSb3ciLCJUZXh0RmllbGQiLCJNYXNrZWRUZXh0RmllbGQiLCJDb21ib0JveCIsInVzZUZvcm1EYXRhIiwidXNlVGhlbWUiLCJSb2xlc0Ryb3Bkb3duIiwiT2ZmaWNlc0Ryb3Bkb3duIiwiUHJvZmlsZURyb3Bkb3duIiwiVXNlckF2YXRhclVwbG9hZCIsInVzZUF1dGgiLCJlbXB0eVVzZXIiLCJub21lIiwiZW1haWwiLCJpbWFnZSIsInN0YXR1cyIsImdlbmVybyIsImRhdGFOYXNjaW1lbnRvIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwiZGF0YUFkbWlzc2FvIiwiYXBlbGlkbyIsIm5yb0NyYyIsInBob25lTnVtYmVyIiwicG9zc3VpVmVpY3VsbyIsInBvc3N1aUNyYyIsInBvc3N1aUNuYWlRdGciLCJwb3NzdWlDbmFpQmFjZW4iLCJwb3NzdWlDbmFpU3VzZXAiLCJwb3NzdWlDbmFpQ3ZtIiwicG9zc3VpQ25haVByZXZpYyIsInNvY2lvIiwiZGVzZW52b2x2ZWRvciIsInBlcmZpbElkIiwiY2FyZ28iLCJlc2NyaXRvcmlvcyIsInJlc3BvbnNhdmVsUmVsYXRvcmlvIiwia2V5IiwidGV4dCIsInN0YWNrVG9rZW5zIiwiVXNlckVkaXRGb3JtIiwicHJvcHMiLCJfcyIsInRoZW1lIiwiY3VycmVudEFjY291bnQiLCJmb3JtRGF0YSIsIm9uQ2hhbmdlIiwiYXBpRXJyb3IiLCJsb2NhbEZvcm1EYXRhIiwib25UZXh0Q2hhbmdlIiwib25Ecm9wZG93bkNoYW5nZSIsIm9uRGF0ZUNoYW5nZSIsIm9uQ2hlY2tib3hDaGFuZ2UiLCJvbk11bHRpRHJvcGRvd25DaGFuZ2UiLCJvbk51bWJlclRleHRDaGFuZ2UiLCJvbkZpZWxkRXJyb3IiLCJzZXRGb3JtRGF0YSIsInNldExvY2FsRm9ybURhdGEiLCJzZWxlY3RlZFJvbGUiLCJzZXRTZWxlY3RlZFJvbGUiLCJzZWxlY3RlZE9mZmljZXMiLCJzZXRTZWxlY3RlZE9mZmljZXMiLCJjYXJnb0lkIiwibWFwIiwib2ZmaWNlIiwiZXNjcml0b3Jpb0lkIiwiaGFuZGxlU3RhdHVzRHJvcGRvd24iLCJfIiwidmFsdWUiLCJ1bmRlZmluZWQiLCJuZXdWYWx1ZSIsImhhbmRsZVJvbGVEcm9wZG93biIsInJvbGVJZCIsInJvbGVEYXRlIiwiZGF0YUluaWNpYWwiLCJyZW1vdmVJbWFnZSIsIm1hc2tGb3JtYXQiLCJsZW5ndGgiLCJwYXRoIiwiZXJyb3JzIiwibWVzc2FnZXMiLCJzcGFjaW5nIiwibGciLCJpZCIsImFkbWluaXN0cmF0b3IiLCJyb290Iiwid2lkdGgiLCJ0b1N0cmluZyIsImxhYmVsIiwibWFyZ2luVG9wIiwieHMiLCJtYXJnaW5Cb3R0b20iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJFZGl0Rm9ybS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlckVkaXRGb3JtLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgTGFiZWwsXHJcbiAgSURyb3Bkb3duT3B0aW9uLFxyXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBVc2VyIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Vc2VyJ1xyXG5pbXBvcnQgeyBFZGl0Rm9ybVByb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL0VkaXRGb3JtJ1xyXG5pbXBvcnQgeyBDaGVja2JveCwgRGF0ZVBpY2tlciwgRmxleENvbHVtbiwgRmxleEl0ZW0sIEZsZXhSb3csIFRleHRGaWVsZCwgTWFza2VkVGV4dEZpZWxkLCBDb21ib0JveCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VGb3JtRGF0YSwgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IFJvbGVzRHJvcGRvd24gfSBmcm9tICcuLi8uLi9yb2xlcy9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBPZmZpY2VzRHJvcGRvd24gfSBmcm9tICcuLi8uLi9vZmZpY2VzL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IFByb2ZpbGVEcm9wZG93biB9IGZyb20gJy4uLy4uL3Byb2ZpbGVzL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IFVzZXJBdmF0YXJVcGxvYWQgfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zdG9yZS9hdXRoJ1xyXG5cclxuY29uc3QgZW1wdHlVc2VyOiBVc2VyID0ge1xyXG4gIG5vbWU6ICcnLFxyXG4gIGVtYWlsOiAnJyxcclxuICBpbWFnZTogJycsXHJcbiAgc3RhdHVzOiB0cnVlLFxyXG4gIGdlbmVybzogMCxcclxuICBkYXRhTmFzY2ltZW50bzogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gIGRhdGFBZG1pc3NhbzogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gIGFwZWxpZG86ICcnLFxyXG4gIG5yb0NyYzogJycsXHJcbiAgcGhvbmVOdW1iZXI6ICcnLFxyXG4gIHBvc3N1aVZlaWN1bG86IGZhbHNlLFxyXG4gIHBvc3N1aUNyYzogZmFsc2UsXHJcbiAgcG9zc3VpQ25haVF0ZzogZmFsc2UsXHJcbiAgcG9zc3VpQ25haUJhY2VuOiBmYWxzZSxcclxuICBwb3NzdWlDbmFpU3VzZXA6IGZhbHNlLFxyXG4gIHBvc3N1aUNuYWlDdm06IGZhbHNlLFxyXG4gIHBvc3N1aUNuYWlQcmV2aWM6IGZhbHNlLFxyXG4gIHNvY2lvOiBmYWxzZSxcclxuICBkZXNlbnZvbHZlZG9yOiBmYWxzZSxcclxuICBwZXJmaWxJZDogJycsXHJcbiAgY2FyZ286IG51bGwsXHJcbiAgZXNjcml0b3Jpb3M6IFtdLFxyXG4gIHJlc3BvbnNhdmVsUmVsYXRvcmlvOiBmYWxzZSxcclxufVxyXG5cclxuY29uc3Qgc3RhdHVzOiBJRHJvcGRvd25PcHRpb25bXSA9IFtcclxuICB7IGtleTogJ3RydWUnLCB0ZXh0OiAnSGFiaWxpdGFkbycgfSxcclxuICB7IGtleTogJ2ZhbHNlJywgdGV4dDogJ0Rlc2FiaWxpdGFkbycgfSxcclxuXVxyXG5cclxuY29uc3Qgc3RhY2tUb2tlbnMgPSAxMlxyXG5cclxuY29uc3QgVXNlckVkaXRGb3JtOiBGQzxFZGl0Rm9ybVByb3BzPFVzZXI+PiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IHsgY3VycmVudEFjY291bnQgfSA9IHVzZUF1dGgoKVxyXG4gIGNvbnN0IHsgZm9ybURhdGEsIG9uQ2hhbmdlLCBhcGlFcnJvciB9ID0gcHJvcHNcclxuICBjb25zdCB7XHJcbiAgICBmb3JtRGF0YTogbG9jYWxGb3JtRGF0YSxcclxuICAgIG9uVGV4dENoYW5nZSxcclxuICAgIG9uRHJvcGRvd25DaGFuZ2UsXHJcbiAgICBvbkRhdGVDaGFuZ2UsXHJcbiAgICBvbkNoZWNrYm94Q2hhbmdlLFxyXG4gICAgb25NdWx0aURyb3Bkb3duQ2hhbmdlLFxyXG4gICAgb25OdW1iZXJUZXh0Q2hhbmdlLFxyXG4gICAgb25GaWVsZEVycm9yLFxyXG4gICAgc2V0Rm9ybURhdGE6IHNldExvY2FsRm9ybURhdGEsXHJcbiAgfSA9IHVzZUZvcm1EYXRhPFVzZXI+KGZvcm1EYXRhID8/IGVtcHR5VXNlcilcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkUm9sZSwgc2V0U2VsZWN0ZWRSb2xlXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpXHJcbiAgY29uc3QgW3NlbGVjdGVkT2ZmaWNlcywgc2V0U2VsZWN0ZWRPZmZpY2VzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YSkge1xyXG4gICAgICBzZXRMb2NhbEZvcm1EYXRhKGZvcm1EYXRhKVxyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YV0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBvbkNoYW5nZT8uKGxvY2FsRm9ybURhdGEpXHJcbiAgfSwgW2xvY2FsRm9ybURhdGFdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGxvY2FsRm9ybURhdGEuY2FyZ28/LmNhcmdvSWQpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRSb2xlKGxvY2FsRm9ybURhdGEuY2FyZ28uY2FyZ29JZClcclxuICAgIH1cclxuICB9LCBbbG9jYWxGb3JtRGF0YS5jYXJnb10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZE9mZmljZXMoXHJcbiAgICAgIGxvY2FsRm9ybURhdGEuZXNjcml0b3Jpb3M/Lm1hcChcclxuICAgICAgICAob2ZmaWNlKSA9PiBvZmZpY2UuZXNjcml0b3Jpb0lkLFxyXG4gICAgICApID8/IFtdLFxyXG4gICAgKVxyXG4gIH0sIFtsb2NhbEZvcm1EYXRhLmVzY3JpdG9yaW9zXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlU3RhdHVzRHJvcGRvd24gPSB1c2VDYWxsYmFjaygoXz86IHVua25vd24sIHZhbHVlPzogSURyb3Bkb3duT3B0aW9uKSA9PiB7XHJcbiAgICBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBjb25zdCBuZXdWYWx1ZSA9IHZhbHVlLmtleSA9PT0gJ3RydWUnXHJcbiAgICAgIHNldExvY2FsRm9ybURhdGEoe1xyXG4gICAgICAgIC4uLmxvY2FsRm9ybURhdGEsXHJcbiAgICAgICAgc3RhdHVzOiBuZXdWYWx1ZSxcclxuICAgICAgfSlcclxuICAgIH1cclxuICB9LCBbbG9jYWxGb3JtRGF0YV0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZVJvbGVEcm9wZG93biA9IHVzZUNhbGxiYWNrKChfPzogdW5rbm93biwgdmFsdWU/OiBJRHJvcGRvd25PcHRpb24pID0+IHtcclxuICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGNvbnN0IHJvbGVJZCA9IHZhbHVlLmtleVxyXG4gICAgICBjb25zdCByb2xlRGF0ZSA9IG5ldyBEYXRlKClcclxuICAgICAgc2V0TG9jYWxGb3JtRGF0YSh7XHJcbiAgICAgICAgLi4ubG9jYWxGb3JtRGF0YSxcclxuICAgICAgICBjYXJnbzoge1xyXG4gICAgICAgICAgY2FyZ29JZDogcm9sZUlkIGFzIHN0cmluZyxcclxuICAgICAgICAgIGRhdGFJbmljaWFsOiByb2xlRGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcbiAgfSwgW2xvY2FsRm9ybURhdGFdKVxyXG5cclxuICBjb25zdCByZW1vdmVJbWFnZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIHNldExvY2FsRm9ybURhdGEoe1xyXG4gICAgICAuLi5sb2NhbEZvcm1EYXRhLFxyXG4gICAgICBpbWFnZTogJycsXHJcbiAgICB9KVxyXG4gIH0sIFtsb2NhbEZvcm1EYXRhXSlcclxuXHJcbiAgY29uc3QgbWFza0Zvcm1hdCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmIChsb2NhbEZvcm1EYXRhLnBob25lTnVtYmVyID09PSBudWxsKSB7XHJcbiAgICAgIGxvY2FsRm9ybURhdGEucGhvbmVOdW1iZXIgPSAnJ1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBsb2NhbEZvcm1EYXRhLnBob25lTnVtYmVyLmxlbmd0aCA8IDExXHJcbiAgICAgID8gJyg5OSkgOTk5OS05OTk5OSdcclxuICAgICAgOiAnKDk5KSA5IDk5OTktOTk5OSdcclxuICB9LCBbbG9jYWxGb3JtRGF0YV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmxleENvbHVtbiBnYXA9e3N0YWNrVG9rZW5zfT5cclxuICAgICAgPFVzZXJBdmF0YXJVcGxvYWRcclxuICAgICAgICBpbWFnZT17bG9jYWxGb3JtRGF0YS5pbWFnZX1cclxuICAgICAgICBvbkNoYW5nZT17cGF0aCA9PiBvblRleHRDaGFuZ2UoJ2ltYWdlJykobnVsbCwgcGF0aCl9XHJcbiAgICAgICAgaGFzSW1hZ2U9e2xvY2FsRm9ybURhdGEuaW1hZ2UgIT09ICcnfVxyXG4gICAgICAgIHJlbW92ZUltYWdlPXtyZW1vdmVJbWFnZX1cclxuICAgICAgLz5cclxuICAgICAgPEZsZXhSb3dcclxuICAgICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXHJcbiAgICAgICAgZ2FwPXtzdGFja1Rva2Vuc31cclxuICAgICAgPlxyXG4gICAgICAgIDxGbGV4SXRlbSBncm93PXsyfT5cclxuICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgbGFiZWw9XCJBcGVsaWRvXCJcclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEuYXBlbGlkb31cclxuICAgICAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnYXBlbGlkbycpfVxyXG4gICAgICAgICAgICBtYXhMZW5ndGg9ezEwMH1cclxuICAgICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdhcGVsaWRvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0ZsZXhJdGVtPlxyXG4gICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgIDxGbGV4Q29sdW1uPlxyXG4gICAgICAgIDxMYWJlbD5BdHVhw6fDtWVzPC9MYWJlbD5cclxuICAgICAgICA8RmxleFJvdyBnYXA9e3RoZW1lLnNwYWNpbmcubGd9PlxyXG4gICAgICAgICAgPEZsZXhJdGVtIGdyb3c9ezB9PlxyXG4gICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICBsYWJlbD1cIlPDs2Npb1wiXHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e29uQ2hlY2tib3hDaGFuZ2UoJ3NvY2lvJyl9XHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5zb2Npb31cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgICA8RmxleEl0ZW0gZ3Jvdz17MH0+XHJcbiAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUmVzcG9uc8OhdmVsIHBvciByZWxhdMOzcmlvXCJcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17b25DaGVja2JveENoYW5nZSgncmVzcG9uc2F2ZWxSZWxhdG9yaW8nKX1cclxuICAgICAgICAgICAgICBjaGVja2VkPXtsb2NhbEZvcm1EYXRhLnJlc3BvbnNhdmVsUmVsYXRvcmlvfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9GbGV4SXRlbT5cclxuICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICBjdXJyZW50QWNjb3VudC52YWx1ZT8uaWQgPT09IGxvY2FsRm9ybURhdGEuaWQgJiZcclxuICAgICAgICAgICAgbG9jYWxGb3JtRGF0YS5kZXNlbnZvbHZlZG9yXHJcbiAgICAgICAgICAgICkgfHxcclxuICAgICAgICAgICAgY3VycmVudEFjY291bnQudmFsdWU/LmFkbWluaXN0cmF0b3JcclxuICAgICAgICAgICkgJiYgPEZsZXhJdGVtIGdyb3c9ezB9PlxyXG4gICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICBsYWJlbD1cIkRlc2Vudm9sdmVkb3JcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5kZXNlbnZvbHZlZG9yfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9GbGV4SXRlbT59XHJcbiAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICBsYWJlbD1cIk5vbWUgQ29tcGxldG9cIlxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEubm9tZX1cclxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdub21lJyl9XHJcbiAgICAgICAgbWF4TGVuZ3RoPXsxMDB9XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ25vbWUnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgIGxhYmVsPVwiRGF0YSBkZSBuYXNjaW1lbnRvXCJcclxuICAgICAgICB2YWx1ZT17bmV3IERhdGUobG9jYWxGb3JtRGF0YS5kYXRhTmFzY2ltZW50byl9XHJcbiAgICAgICAgYWxsb3dUZXh0SW5wdXRcclxuICAgICAgICBvblNlbGVjdERhdGU9e29uRGF0ZUNoYW5nZSgnZGF0YU5hc2NpbWVudG8nKX1cclxuICAgICAgICBmb3JtYXRTdHJpbmc9eydkZC9NTS95eXl5J31cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6ICcyNSUnIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICBsYWJlbD1cIkRhdGEgZGUgYWRtaXNzw6NvXCJcclxuICAgICAgICB2YWx1ZT17bmV3IERhdGUobG9jYWxGb3JtRGF0YS5kYXRhQWRtaXNzYW8pfVxyXG4gICAgICAgIGFsbG93VGV4dElucHV0XHJcbiAgICAgICAgb25TZWxlY3REYXRlPXtvbkRhdGVDaGFuZ2UoJ2RhdGFBZG1pc3NhbycpfVxyXG4gICAgICAgIGZvcm1hdFN0cmluZz17J2RkL01NL3l5eXknfVxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgcm9vdDogeyB3aWR0aDogJzI1JScgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAvPlxyXG4gICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgbGFiZWw9XCJFLW1haWxcIlxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgbWF4TGVuZ3RoPXs0NTB9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnZW1haWwnKX1cclxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignZW1haWwnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8TWFza2VkVGV4dEZpZWxkXHJcbiAgICAgICAgbGFiZWw9XCJUZWxlZm9uZVwiXHJcbiAgICAgICAgbWFzaz17bWFza0Zvcm1hdCgpfVxyXG4gICAgICAgIG1hc2tDaGFyPVwiIFwiXHJcbiAgICAgICAgb25DaGFuZ2U9e29uTnVtYmVyVGV4dENoYW5nZSgncGhvbmVOdW1iZXInKX1cclxuICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5waG9uZU51bWJlciA/PyAnJ31cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6ICcyNSUnIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcigncGhvbmVOdW1iZXInLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8UHJvZmlsZURyb3Bkb3duXHJcbiAgICAgICAgbGFiZWw9eydQZXJmaWwnfVxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgc2VsZWN0ZWRLZXk9e2xvY2FsRm9ybURhdGEucGVyZmlsSWR9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uRHJvcGRvd25DaGFuZ2UoJ3BlcmZpbElkJyl9XHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICByb290OiB7IHdpZHRoOiAnNTAlJyB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ3BlcmZpbElkJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuICAgICAgPENvbWJvQm94XHJcbiAgICAgICAgbGFiZWw9XCJTaXR1YcOnw6NvXCJcclxuICAgICAgICBvcHRpb25zPXtzdGF0dXN9XHJcbiAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVN0YXR1c0Ryb3Bkb3dufVxyXG4gICAgICAgIHNlbGVjdGVkS2V5PXtsb2NhbEZvcm1EYXRhLnN0YXR1cy50b1N0cmluZygpfVxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgcm9vdDogeyB3aWR0aDogJzUwJScgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgID8gb25GaWVsZEVycm9yKCdzdGF0dXMnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8T2ZmaWNlc0Ryb3Bkb3duXHJcbiAgICAgICAgbGFiZWw9XCJFc2NyaXTDs3Jpb1wiXHJcbiAgICAgICAgbXVsdGlTZWxlY3RcclxuICAgICAgICBzZWxlY3RlZEtleXM9e3NlbGVjdGVkT2ZmaWNlc31cclxuICAgICAgICBvbkNoYW5nZT17b25NdWx0aURyb3Bkb3duQ2hhbmdlKCdlc2NyaXRvcmlvcycsICdlc2NyaXRvcmlvSWQnKX1cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6ICc1MCUnIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICAgeyFsb2NhbEZvcm1EYXRhLmlkICYmXHJcbiAgICAgICAgPFJvbGVzRHJvcGRvd25cclxuICAgICAgICAgIGxhYmVsPVwiQ2FyZ29cIlxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIHNlbGVjdGVkS2V5PXtzZWxlY3RlZFJvbGV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUm9sZURyb3Bkb3dufVxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6ICc1MCUnIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICA/IG9uRmllbGRFcnJvcignY2FyZ28nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICB9XHJcbiAgICAgIDxDaGVja2JveFxyXG4gICAgICAgIGxhYmVsPVwiUG9zc3VpIHZlw61jdWxvXCJcclxuICAgICAgICBvbkNoYW5nZT17b25DaGVja2JveENoYW5nZSgncG9zc3VpVmVpY3VsbycpfVxyXG4gICAgICAgIGNoZWNrZWQ9e2xvY2FsRm9ybURhdGEucG9zc3VpVmVpY3Vsb31cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGxhYmVsOiB7XHJcbiAgICAgICAgICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZy54cyxcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiB0aGVtZS5zcGFjaW5nLnhzLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAvPlxyXG4gICAgICA8RmxleENvbHVtbiBnYXA9eyB0aGVtZS5zcGFjaW5nLnhzIH0+XHJcbiAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICBsYWJlbD1cIlJlZ2lzdHJvIENSQ1wiXHJcbiAgICAgICAgICBvbkNoYW5nZT17b25DaGVja2JveENoYW5nZSgncG9zc3VpQ3JjJyl9XHJcbiAgICAgICAgICBjaGVja2VkPXtsb2NhbEZvcm1EYXRhLnBvc3N1aUNyY31cclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICBsYWJlbDoge1xyXG4gICAgICAgICAgICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZy54cyxcclxuICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHRoZW1lLnNwYWNpbmcueHMsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAge2xvY2FsRm9ybURhdGEucG9zc3VpQ3JjICYmXHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvblRleHRDaGFuZ2UoJ25yb0NyYycpfVxyXG4gICAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5ucm9DcmN9XHJcbiAgICAgICAgICAgIG1heExlbmd0aD17MzB9XHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6ICc1MCUnIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgICA/IG9uRmllbGRFcnJvcigncGVyZmlsSWQnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIH1cclxuICAgICAgPC9GbGV4Q29sdW1uPlxyXG4gICAgICA8RmxleENvbHVtbiBnYXA9eyB0aGVtZS5zcGFjaW5nLnhzIH0+XHJcbiAgICAgICAgPExhYmVsPlJlZ2lzdHJvIENOQUk8L0xhYmVsPlxyXG4gICAgICAgIDxGbGV4Q29sdW1uIGdhcD17c3RhY2tUb2tlbnN9PlxyXG4gICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgIGxhYmVsPVwiUVRHXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9e29uQ2hlY2tib3hDaGFuZ2UoJ3Bvc3N1aUNuYWlRdGcnKX1cclxuICAgICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5wb3NzdWlDbmFpUXRnfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICBsYWJlbD1cIkJBQ0VOXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9e29uQ2hlY2tib3hDaGFuZ2UoJ3Bvc3N1aUNuYWlCYWNlbicpfVxyXG4gICAgICAgICAgICBjaGVja2VkPXtsb2NhbEZvcm1EYXRhLnBvc3N1aUNuYWlCYWNlbn1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgbGFiZWw9XCJTVVNFUFwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdwb3NzdWlDbmFpU3VzZXAnKX1cclxuICAgICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5wb3NzdWlDbmFpU3VzZXB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgIGxhYmVsPVwiQ1ZNXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9e29uQ2hlY2tib3hDaGFuZ2UoJ3Bvc3N1aUNuYWlDdm0nKX1cclxuICAgICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5wb3NzdWlDbmFpQ3ZtfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICBsYWJlbD1cIlBSRVZJQ1wiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdwb3NzdWlDbmFpUHJldmljJyl9XHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2xvY2FsRm9ybURhdGEucG9zc3VpQ25haVByZXZpY31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9GbGV4Q29sdW1uPlxyXG4gICAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyRWRpdEZvcm1cclxuIl19