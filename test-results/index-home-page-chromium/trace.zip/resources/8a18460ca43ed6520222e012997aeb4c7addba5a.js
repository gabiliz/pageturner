import { EditorContent } from "/node_modules/.vite/deps/@tiptap_react.js?v=9f90a7ff";
import styled from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
export const RichTextContainer = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  background-color: ${(props) => props.theme.colors.gray[200]};
  border-radius: 4px;
  overflow: hidden;

  .ProseMirror {
      min-height: ${(props) => props.minHeight ?? "5rem"};
      padding: ${(props) => props.theme.spacing.md};

      border: 1px solid ${(props) => props.theme.colors.neutralLight[200]};
      border-top: 0;
      border-radius: 0 0 4px 4px;

      :focus {
        outline: none;
      }

      > * + * {
        margin-top: 0.75em;
      }

      p.is-editor-empty:first-child::before {
        color: ${(props) => props.theme.colors.gray[400]};
        content: attr(data-placeholder);
        float: left;
        height: 0;
        pointer-events: none;
      }

      ul, ol {
        margin: 0 ${(props) => props.theme.spacing.md};
        padding: 0 ${(props) => props.theme.spacing.md};
      }

      h1,h2,h3,h4,h5,h6 {
        line-height: 1.1;
      }

      h2 {
        font-weight: ${(props) => props.theme.fontWeight.semibold};
      }

      code {
        background-color: rgba(${(props) => props.theme.colors.purple[300]}, 0.1);
        color: ${(props) => props.theme.colors.purple[300]};
      }

      pre {
        background: ${(props) => props.theme.colors.purple[800]};
        color: ${(props) => props.theme.colors.white};
        font-family: "JetBrainsMono; monospace";
        padding: ${(props) => props.theme.spacing.sm} ${(props) => props.theme.spacing.md};
        border-radius: ${(props) => props.theme.spacing.xs};

        code {
          color: inherit;
          padding: 0;
          background: none;
          font-size: 0.8rem;
        }
      }

      img {
        max-width: 100%;
        height: auto;
      }

      blockquote {
        padding-left: 1rem;
        border-left: 2px solid ${(props) => props.theme.colors.neutralLight[300]};
      }

      hr {
        border: none;
        border-top: 2px solid ${(props) => props.theme.colors.neutralLight[300]};
        margin: 1rem 0;
      }

    }
`;
export const EditorContentStyled = styled(EditorContent)`
  height: 100%;
  overflow: auto;
`;
export const RichTextSuffix = styled.div`
  position: absolute;
  bottom: ${(props) => props.theme.spacing.xs};
  right: ${(props) => props.theme.spacing.xs};
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJpY2hUZXh0RWRpdG9yLnN0eWxlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFZGl0b3JDb250ZW50IH0gZnJvbSAnQHRpcHRhcC9yZWFjdCdcbmltcG9ydCBzdHlsZWQsIHsgQ1NTUHJvcGVydGllcyB9IGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xuXG5pbnRlcmZhY2UgUmljaFRleHRFZGl0b3JDb250ZW50UHJvcHMge1xuICBtaW5IZWlnaHQ/OiBzdHJpbmcsXG4gIHN0eWxlPzogQ1NTUHJvcGVydGllc1xufVxuXG5leHBvcnQgY29uc3QgUmljaFRleHRDb250YWluZXIgPSBzdHlsZWQuZGl2PFJpY2hUZXh0RWRpdG9yQ29udGVudFByb3BzPmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5ncmF5WzIwMF19O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG5cbiAgLlByb3NlTWlycm9yIHtcbiAgICAgIG1pbi1oZWlnaHQ6ICR7cHJvcHMgPT4gcHJvcHMubWluSGVpZ2h0ID8/ICc1cmVtJ307XG4gICAgICBwYWRkaW5nOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcubWR9O1xuXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5uZXV0cmFsTGlnaHRbMjAwXX07XG4gICAgICBib3JkZXItdG9wOiAwO1xuICAgICAgYm9yZGVyLXJhZGl1czogMCAwIDRweCA0cHg7XG5cbiAgICAgIDpmb2N1cyB7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICB9XG5cbiAgICAgID4gKiArICoge1xuICAgICAgICBtYXJnaW4tdG9wOiAwLjc1ZW07XG4gICAgICB9XG5cbiAgICAgIHAuaXMtZWRpdG9yLWVtcHR5OmZpcnN0LWNoaWxkOjpiZWZvcmUge1xuICAgICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMuZ3JheVs0MDBdfTtcbiAgICAgICAgY29udGVudDogYXR0cihkYXRhLXBsYWNlaG9sZGVyKTtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIGhlaWdodDogMDtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgICB9XG5cbiAgICAgIHVsLCBvbCB7XG4gICAgICAgIG1hcmdpbjogMCAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcubWR9O1xuICAgICAgICBwYWRkaW5nOiAwICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy5tZH07XG4gICAgICB9XG5cbiAgICAgIGgxLGgyLGgzLGg0LGg1LGg2IHtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEuMTtcbiAgICAgIH1cblxuICAgICAgaDIge1xuICAgICAgICBmb250LXdlaWdodDogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250V2VpZ2h0LnNlbWlib2xkfTtcbiAgICAgIH1cblxuICAgICAgY29kZSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzMwMF19LCAwLjEpO1xuICAgICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzMwMF19O1xuICAgICAgfVxuXG4gICAgICBwcmUge1xuICAgICAgICBiYWNrZ3JvdW5kOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbODAwXX07XG4gICAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy53aGl0ZX07XG4gICAgICAgIGZvbnQtZmFtaWx5OiBcIkpldEJyYWluc01vbm87IG1vbm9zcGFjZVwiO1xuICAgICAgICBwYWRkaW5nOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcuc219ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy5tZH07XG4gICAgICAgIGJvcmRlci1yYWRpdXM6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy54c307XG5cbiAgICAgICAgY29kZSB7XG4gICAgICAgICAgY29sb3I6IGluaGVyaXQ7XG4gICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMC44cmVtO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGltZyB7XG4gICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgfVxuXG4gICAgICBibG9ja3F1b3RlIHtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxcmVtO1xuICAgICAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLm5ldXRyYWxMaWdodFszMDBdfTtcbiAgICAgIH1cblxuICAgICAgaHIge1xuICAgICAgICBib3JkZXI6IG5vbmU7XG4gICAgICAgIGJvcmRlci10b3A6IDJweCBzb2xpZCAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5uZXV0cmFsTGlnaHRbMzAwXX07XG4gICAgICAgIG1hcmdpbjogMXJlbSAwO1xuICAgICAgfVxuXG4gICAgfVxuYFxuXG5leHBvcnQgY29uc3QgRWRpdG9yQ29udGVudFN0eWxlZCA9IHN0eWxlZChFZGl0b3JDb250ZW50KWBcbiAgaGVpZ2h0OiAxMDAlO1xuICBvdmVyZmxvdzogYXV0bztcbmBcblxuZXhwb3J0IGNvbnN0IFJpY2hUZXh0U3VmZml4ID0gc3R5bGVkLmRpdmBcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy54c307XG4gIHJpZ2h0OiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcueHN9O1xuYFxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLHFCQUFxQjtBQUM5QixPQUFPLFlBQStCO0FBTy9CLGFBQU0sb0JBQW9CLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJbEIsV0FBUyxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUt0QyxXQUFTLE1BQU0sYUFBYTtBQUFBLGlCQUMvQixXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQSwwQkFFcEIsV0FBUyxNQUFNLE1BQU0sT0FBTyxhQUFhLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhckQsV0FBUyxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVFqQyxXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUEscUJBQzVCLFdBQVMsTUFBTSxNQUFNLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVEzQixXQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBSXRCLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUEsaUJBQ3RELFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSWpDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUEsaUJBQzNDLFdBQVMsTUFBTSxNQUFNLE9BQU87QUFBQTtBQUFBLG1CQUUxQixXQUFTLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBLHlCQUMxRCxXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FpQnJCLFdBQVMsTUFBTSxNQUFNLE9BQU8sYUFBYSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FLN0MsV0FBUyxNQUFNLE1BQU0sT0FBTyxhQUFhLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT3JFLGFBQU0sc0JBQXNCLE9BQU8sYUFBYTtBQUFBO0FBQUE7QUFBQTtBQUtoRCxhQUFNLGlCQUFpQixPQUFPO0FBQUE7QUFBQSxZQUV6QixXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUEsV0FDOUIsV0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBOyIsIm5hbWVzIjpbXX0=