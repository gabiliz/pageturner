import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/offices/components/OfficeNameList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeNameList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { officeQueryService } from "/src/modules/admin/offices/services/index.ts";
const OfficeNameList = (props) => {
  _s();
  const {
    ids,
    offices
  } = props;
  const {
    data
  } = ids ? officeQueryService.useFindAllPaginated() : {
    data: {
      value: offices
    }
  };
  const result = useMemo(() => {
    if (ids) {
      return data?.value?.filter(({
        id
      }) => ids.includes(id))?.map(({
        nome
      }) => nome).join(", ");
    }
    return data?.value?.map(({
      nome
    }) => nome).join(", ");
  }, [ids, data]);
  return /* @__PURE__ */ jsxDEV("span", { children: result }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeNameList.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(OfficeNameList, "XkrUBQoOW+FcdtvRKOwT/WqhfAw=", false, function() {
  return [officeQueryService.useFindAllPaginated];
});
_c = OfficeNameList;
export default OfficeNameList;
var _c;
$RefreshReg$(_c, "OfficeNameList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeNameList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJTOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJULFNBQWFBLGVBQWU7QUFFNUIsU0FBU0MsMEJBQTBCO0FBT25DLE1BQU1DLGlCQUEyQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3pELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFLQztBQUFBQSxFQUFRLElBQUlIO0FBQ3pCLFFBQU07QUFBQSxJQUFFSTtBQUFBQSxFQUFLLElBQUlGLE1BQU1KLG1CQUFtQk8sb0JBQW9CLElBQUk7QUFBQSxJQUFFRCxNQUFNO0FBQUEsTUFBRUUsT0FBT0g7QUFBQUEsSUFBUTtBQUFBLEVBQUU7QUFFN0YsUUFBTUksU0FBU1YsUUFBUSxNQUFNO0FBQzNCLFFBQUlLLEtBQUs7QUFDUCxhQUFPRSxNQUFNRSxPQUNURSxPQUFPLENBQUM7QUFBQSxRQUFFQztBQUFBQSxNQUFHLE1BQU1QLElBQUlRLFNBQVNELEVBQVksQ0FBQyxHQUM3Q0UsSUFBSSxDQUFDO0FBQUEsUUFBRUM7QUFBQUEsTUFBSyxNQUFNQSxJQUFJLEVBQ3ZCQyxLQUFLLElBQUk7QUFBQSxJQUNkO0FBRUEsV0FBT1QsTUFBTUUsT0FDVEssSUFBSSxDQUFDO0FBQUEsTUFBRUM7QUFBQUEsSUFBSyxNQUFNQSxJQUFJLEVBQ3ZCQyxLQUFLLElBQUk7QUFBQSxFQUNkLEdBQUcsQ0FBQ1gsS0FBS0UsSUFBSSxDQUFDO0FBRWQsU0FBTyx1QkFBQyxVQUFNRyxvQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWM7QUFDdkI7QUFBQ04sR0FsQktGLGdCQUF1QztBQUFBLFVBRXBCRCxtQkFBbUJPLG1CQUFtQjtBQUFBO0FBQUFTLEtBRnpEZjtBQW9CTixlQUFlQTtBQUFjLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwib2ZmaWNlUXVlcnlTZXJ2aWNlIiwiT2ZmaWNlTmFtZUxpc3QiLCJwcm9wcyIsIl9zIiwiaWRzIiwib2ZmaWNlcyIsImRhdGEiLCJ1c2VGaW5kQWxsUGFnaW5hdGVkIiwidmFsdWUiLCJyZXN1bHQiLCJmaWx0ZXIiLCJpZCIsImluY2x1ZGVzIiwibWFwIiwibm9tZSIsImpvaW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk9mZmljZU5hbWVMaXN0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vb2ZmaWNlcy9jb21wb25lbnRzL09mZmljZU5hbWVMaXN0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgT2ZmaWNlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9PZmZpY2UnXG5pbXBvcnQgeyBvZmZpY2VRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcblxuaW50ZXJmYWNlIE9mZmljZU5hbWVMaXN0UHJvcHMge1xuICBpZHM/OiBzdHJpbmdbXVxuICBvZmZpY2VzPzogT2ZmaWNlW11cbn1cblxuY29uc3QgT2ZmaWNlTmFtZUxpc3Q6IEZDPE9mZmljZU5hbWVMaXN0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgaWRzLCBvZmZpY2VzIH0gPSBwcm9wc1xuICBjb25zdCB7IGRhdGEgfSA9IGlkcyA/IG9mZmljZVF1ZXJ5U2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKCkgOiB7IGRhdGE6IHsgdmFsdWU6IG9mZmljZXMgfSB9XG5cbiAgY29uc3QgcmVzdWx0ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKGlkcykge1xuICAgICAgcmV0dXJuIGRhdGE/LnZhbHVlXG4gICAgICAgID8uZmlsdGVyKCh7IGlkIH0pID0+IGlkcy5pbmNsdWRlcyhpZCBhcyBzdHJpbmcpKVxuICAgICAgICA/Lm1hcCgoeyBub21lIH0pID0+IG5vbWUpXG4gICAgICAgIC5qb2luKCcsICcpXG4gICAgfVxuXG4gICAgcmV0dXJuIGRhdGE/LnZhbHVlXG4gICAgICA/Lm1hcCgoeyBub21lIH0pID0+IG5vbWUpXG4gICAgICAuam9pbignLCAnKVxuICB9LCBbaWRzLCBkYXRhXSlcblxuICByZXR1cm4gPHNwYW4+e3Jlc3VsdH08L3NwYW4+XG59XG5cbmV4cG9ydCBkZWZhdWx0IE9mZmljZU5hbWVMaXN0XG4iXX0=