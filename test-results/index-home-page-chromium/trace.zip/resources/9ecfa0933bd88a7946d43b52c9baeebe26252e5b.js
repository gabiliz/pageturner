import {
  Provider_default,
  ReactReduxContext,
  connectAdvanced,
  connect_default,
  createDispatchHook,
  createSelectorHook,
  createStoreHook,
  import_react_dom,
  shallowEqual,
  useDispatch,
  useSelector,
  useStore
} from "/node_modules/.vite/deps/chunk-VAK7BYUT.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-7VNMPKVM.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HTHQKSPX.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-KBUAZBQ3.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-7BGERXIW.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-YNY3AOFZ.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";
var export_batch = import_react_dom.unstable_batchedUpdates;
export {
  Provider_default as Provider,
  ReactReduxContext,
  export_batch as batch,
  connect_default as connect,
  connectAdvanced,
  createDispatchHook,
  createSelectorHook,
  createStoreHook,
  shallowEqual,
  useDispatch,
  useSelector,
  useStore
};
//# sourceMappingURL=react-redux.js.map
