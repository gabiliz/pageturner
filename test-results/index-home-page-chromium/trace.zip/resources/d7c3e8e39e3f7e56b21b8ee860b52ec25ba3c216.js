export var ModuleEnum = /* @__PURE__ */ ((ModuleEnum2) => {
  ModuleEnum2[ModuleEnum2["Administrativo"] = 1] = "Administrativo";
  ModuleEnum2[ModuleEnum2["Fiscal"] = 2] = "Fiscal";
  ModuleEnum2[ModuleEnum2["Contabil"] = 3] = "Contabil";
  return ModuleEnum2;
})(ModuleEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1vZHVsZUVudW0udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cbmV4cG9ydCBlbnVtIE1vZHVsZUVudW0ge1xuICBBZG1pbmlzdHJhdGl2byA9IDEsXG4gIEZpc2NhbCA9IDIsXG4gIENvbnRhYmlsID0gM1xufVxuIl0sIm1hcHBpbmdzIjoiQUFDTyxXQUFLLGFBQUwsa0JBQUtBLGdCQUFMO0FBQ0wsRUFBQUEsd0JBQUEsb0JBQWlCLEtBQWpCO0FBQ0EsRUFBQUEsd0JBQUEsWUFBUyxLQUFUO0FBQ0EsRUFBQUEsd0JBQUEsY0FBVyxLQUFYO0FBSFUsU0FBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbIk1vZHVsZUVudW0iXX0=