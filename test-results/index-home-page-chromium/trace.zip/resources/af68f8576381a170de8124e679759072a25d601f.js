import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  Stylesheet,
  __assign,
  __extends,
  __rest,
  concatStyleSets,
  concatStyleSetsWithProps,
  mergeCssSets,
  mergeStyles,
  setRTL,
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@fluentui/utilities/lib/dom/canUseDOM.js
function canUseDOM() {
  return typeof window !== "undefined" && !!(window.document && // eslint-disable-next-line deprecation/deprecation
  window.document.createElement);
}

// node_modules/@fluentui/utilities/lib/dom/getWindow.js
var _window = void 0;
try {
  _window = window;
} catch (e) {
}
function getWindow(rootElement) {
  if (!canUseDOM() || typeof _window === "undefined") {
    return void 0;
  } else {
    var el = rootElement;
    return el && el.ownerDocument && el.ownerDocument.defaultView ? el.ownerDocument.defaultView : _window;
  }
}

// node_modules/@fluentui/utilities/lib/Async.js
var Async = (
  /** @class */
  function() {
    function Async2(parent, onError) {
      this._timeoutIds = null;
      this._immediateIds = null;
      this._intervalIds = null;
      this._animationFrameIds = null;
      this._isDisposed = false;
      this._parent = parent || null;
      this._onErrorHandler = onError;
      this._noop = function() {
      };
    }
    Async2.prototype.dispose = function() {
      var id;
      this._isDisposed = true;
      this._parent = null;
      if (this._timeoutIds) {
        for (id in this._timeoutIds) {
          if (this._timeoutIds.hasOwnProperty(id)) {
            this.clearTimeout(parseInt(id, 10));
          }
        }
        this._timeoutIds = null;
      }
      if (this._immediateIds) {
        for (id in this._immediateIds) {
          if (this._immediateIds.hasOwnProperty(id)) {
            this.clearImmediate(parseInt(id, 10));
          }
        }
        this._immediateIds = null;
      }
      if (this._intervalIds) {
        for (id in this._intervalIds) {
          if (this._intervalIds.hasOwnProperty(id)) {
            this.clearInterval(parseInt(id, 10));
          }
        }
        this._intervalIds = null;
      }
      if (this._animationFrameIds) {
        for (id in this._animationFrameIds) {
          if (this._animationFrameIds.hasOwnProperty(id)) {
            this.cancelAnimationFrame(parseInt(id, 10));
          }
        }
        this._animationFrameIds = null;
      }
    };
    Async2.prototype.setTimeout = function(callback, duration) {
      var _this = this;
      var timeoutId = 0;
      if (!this._isDisposed) {
        if (!this._timeoutIds) {
          this._timeoutIds = {};
        }
        timeoutId = setTimeout(function() {
          try {
            if (_this._timeoutIds) {
              delete _this._timeoutIds[timeoutId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        }, duration);
        this._timeoutIds[timeoutId] = true;
      }
      return timeoutId;
    };
    Async2.prototype.clearTimeout = function(id) {
      if (this._timeoutIds && this._timeoutIds[id]) {
        clearTimeout(id);
        delete this._timeoutIds[id];
      }
    };
    Async2.prototype.setImmediate = function(callback, targetElement) {
      var _this = this;
      var immediateId = 0;
      var win = getWindow(targetElement);
      if (!this._isDisposed) {
        if (!this._immediateIds) {
          this._immediateIds = {};
        }
        var setImmediateCallback = function() {
          try {
            if (_this._immediateIds) {
              delete _this._immediateIds[immediateId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        };
        immediateId = win.setTimeout(setImmediateCallback, 0);
        this._immediateIds[immediateId] = true;
      }
      return immediateId;
    };
    Async2.prototype.clearImmediate = function(id, targetElement) {
      var win = getWindow(targetElement);
      if (this._immediateIds && this._immediateIds[id]) {
        win.clearTimeout(id);
        delete this._immediateIds[id];
      }
    };
    Async2.prototype.setInterval = function(callback, duration) {
      var _this = this;
      var intervalId = 0;
      if (!this._isDisposed) {
        if (!this._intervalIds) {
          this._intervalIds = {};
        }
        intervalId = setInterval(function() {
          try {
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        }, duration);
        this._intervalIds[intervalId] = true;
      }
      return intervalId;
    };
    Async2.prototype.clearInterval = function(id) {
      if (this._intervalIds && this._intervalIds[id]) {
        clearInterval(id);
        delete this._intervalIds[id];
      }
    };
    Async2.prototype.throttle = function(func, wait, options) {
      var _this = this;
      if (this._isDisposed) {
        return this._noop;
      }
      var waitMS = wait || 0;
      var leading = true;
      var trailing = true;
      var lastExecuteTime = 0;
      var lastResult;
      var lastArgs;
      var timeoutId = null;
      if (options && typeof options.leading === "boolean") {
        leading = options.leading;
      }
      if (options && typeof options.trailing === "boolean") {
        trailing = options.trailing;
      }
      var callback = function(userCall) {
        var now2 = Date.now();
        var delta = now2 - lastExecuteTime;
        var waitLength = leading ? waitMS - delta : waitMS;
        if (delta >= waitMS && (!userCall || leading)) {
          lastExecuteTime = now2;
          if (timeoutId) {
            _this.clearTimeout(timeoutId);
            timeoutId = null;
          }
          lastResult = func.apply(_this._parent, lastArgs);
        } else if (timeoutId === null && trailing) {
          timeoutId = _this.setTimeout(callback, waitLength);
        }
        return lastResult;
      };
      var resultFunction = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        lastArgs = args;
        return callback(true);
      };
      return resultFunction;
    };
    Async2.prototype.debounce = function(func, wait, options) {
      var _this = this;
      if (this._isDisposed) {
        var noOpFunction = function() {
        };
        noOpFunction.cancel = function() {
          return;
        };
        noOpFunction.flush = function() {
          return null;
        };
        noOpFunction.pending = function() {
          return false;
        };
        return noOpFunction;
      }
      var waitMS = wait || 0;
      var leading = false;
      var trailing = true;
      var maxWait = null;
      var lastCallTime = 0;
      var lastExecuteTime = Date.now();
      var lastResult;
      var lastArgs;
      var timeoutId = null;
      if (options && typeof options.leading === "boolean") {
        leading = options.leading;
      }
      if (options && typeof options.trailing === "boolean") {
        trailing = options.trailing;
      }
      if (options && typeof options.maxWait === "number" && !isNaN(options.maxWait)) {
        maxWait = options.maxWait;
      }
      var markExecuted = function(time) {
        if (timeoutId) {
          _this.clearTimeout(timeoutId);
          timeoutId = null;
        }
        lastExecuteTime = time;
      };
      var invokeFunction = function(time) {
        markExecuted(time);
        lastResult = func.apply(_this._parent, lastArgs);
      };
      var callback = function(userCall) {
        var now2 = Date.now();
        var executeImmediately = false;
        if (userCall) {
          if (leading && now2 - lastCallTime >= waitMS) {
            executeImmediately = true;
          }
          lastCallTime = now2;
        }
        var delta = now2 - lastCallTime;
        var waitLength = waitMS - delta;
        var maxWaitDelta = now2 - lastExecuteTime;
        var maxWaitExpired = false;
        if (maxWait !== null) {
          if (maxWaitDelta >= maxWait && timeoutId) {
            maxWaitExpired = true;
          } else {
            waitLength = Math.min(waitLength, maxWait - maxWaitDelta);
          }
        }
        if (delta >= waitMS || maxWaitExpired || executeImmediately) {
          invokeFunction(now2);
        } else if ((timeoutId === null || !userCall) && trailing) {
          timeoutId = _this.setTimeout(callback, waitLength);
        }
        return lastResult;
      };
      var pending = function() {
        return !!timeoutId;
      };
      var cancel = function() {
        if (pending()) {
          markExecuted(Date.now());
        }
      };
      var flush = function() {
        if (pending()) {
          invokeFunction(Date.now());
        }
        return lastResult;
      };
      var resultFunction = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        lastArgs = args;
        return callback(true);
      };
      resultFunction.cancel = cancel;
      resultFunction.flush = flush;
      resultFunction.pending = pending;
      return resultFunction;
    };
    Async2.prototype.requestAnimationFrame = function(callback, targetElement) {
      var _this = this;
      var animationFrameId = 0;
      var win = getWindow(targetElement);
      if (!this._isDisposed) {
        if (!this._animationFrameIds) {
          this._animationFrameIds = {};
        }
        var animationFrameCallback = function() {
          try {
            if (_this._animationFrameIds) {
              delete _this._animationFrameIds[animationFrameId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        };
        animationFrameId = win.requestAnimationFrame ? win.requestAnimationFrame(animationFrameCallback) : win.setTimeout(animationFrameCallback, 0);
        this._animationFrameIds[animationFrameId] = true;
      }
      return animationFrameId;
    };
    Async2.prototype.cancelAnimationFrame = function(id, targetElement) {
      var win = getWindow(targetElement);
      if (this._animationFrameIds && this._animationFrameIds[id]) {
        win.cancelAnimationFrame ? win.cancelAnimationFrame(id) : win.clearTimeout(id);
        delete this._animationFrameIds[id];
      }
    };
    Async2.prototype._logError = function(e) {
      if (this._onErrorHandler) {
        this._onErrorHandler(e);
      }
    };
    return Async2;
  }()
);

// node_modules/@fluentui/utilities/lib/object.js
function shallowCompare(a, b) {
  if (!a || !b) {
    return !a && !b;
  }
  for (var propName in a) {
    if (a.hasOwnProperty(propName)) {
      if (!b.hasOwnProperty(propName) || b[propName] !== a[propName]) {
        return false;
      }
    }
  }
  for (var propName in b) {
    if (b.hasOwnProperty(propName)) {
      if (!a.hasOwnProperty(propName)) {
        return false;
      }
    }
  }
  return true;
}
function assign(target) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  return filteredAssign.apply(this, [null, target].concat(args));
}
function filteredAssign(isAllowed, target) {
  var args = [];
  for (var _i = 2; _i < arguments.length; _i++) {
    args[_i - 2] = arguments[_i];
  }
  target = target || {};
  for (var _a2 = 0, args_1 = args; _a2 < args_1.length; _a2++) {
    var sourceObject = args_1[_a2];
    if (sourceObject) {
      for (var propName in sourceObject) {
        if (sourceObject.hasOwnProperty(propName) && (!isAllowed || isAllowed(propName))) {
          target[propName] = sourceObject[propName];
        }
      }
    }
  }
  return target;
}
function mapEnumByName(theEnum, callback) {
  return Object.keys(theEnum).map(function(p) {
    if (String(Number(p)) !== p) {
      return callback(p, theEnum[p]);
    }
    return void 0;
  }).filter(function(v) {
    return !!v;
  });
}
function values(obj) {
  return Object.keys(obj).reduce(function(arr, key) {
    arr.push(obj[key]);
    return arr;
  }, []);
}
function omit(obj, exclusions) {
  var result = {};
  for (var key in obj) {
    if (exclusions.indexOf(key) === -1 && obj.hasOwnProperty(key)) {
      result[key] = obj[key];
    }
  }
  return result;
}

// node_modules/@fluentui/utilities/lib/EventGroup.js
var EventGroup = (
  /** @class */
  function() {
    function EventGroup2(parent) {
      this._id = EventGroup2._uniqueId++;
      this._parent = parent;
      this._eventRecords = [];
    }
    EventGroup2.raise = function(target, eventName, eventArgs, bubbleEvent) {
      var retVal2;
      if (EventGroup2._isElement(target)) {
        if (typeof document !== "undefined" && document.createEvent) {
          var ev = document.createEvent("HTMLEvents");
          ev.initEvent(eventName, bubbleEvent || false, true);
          assign(ev, eventArgs);
          retVal2 = target.dispatchEvent(ev);
        } else if (typeof document !== "undefined" && document.createEventObject) {
          var evObj = document.createEventObject(eventArgs);
          target.fireEvent("on" + eventName, evObj);
        }
      } else {
        while (target && retVal2 !== false) {
          var events = target.__events__;
          var eventRecords = events ? events[eventName] : null;
          if (eventRecords) {
            for (var id in eventRecords) {
              if (eventRecords.hasOwnProperty(id)) {
                var eventRecordList = eventRecords[id];
                for (var listIndex = 0; retVal2 !== false && listIndex < eventRecordList.length; listIndex++) {
                  var record = eventRecordList[listIndex];
                  if (record.objectCallback) {
                    retVal2 = record.objectCallback.call(record.parent, eventArgs);
                  }
                }
              }
            }
          }
          target = bubbleEvent ? target.parent : null;
        }
      }
      return retVal2;
    };
    EventGroup2.isObserved = function(target, eventName) {
      var events = target && target.__events__;
      return !!events && !!events[eventName];
    };
    EventGroup2.isDeclared = function(target, eventName) {
      var declaredEvents = target && target.__declaredEvents;
      return !!declaredEvents && !!declaredEvents[eventName];
    };
    EventGroup2.stopPropagation = function(event) {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    };
    EventGroup2._isElement = function(target) {
      return !!target && (!!target.addEventListener || typeof HTMLElement !== "undefined" && target instanceof HTMLElement);
    };
    EventGroup2.prototype.dispose = function() {
      if (!this._isDisposed) {
        this._isDisposed = true;
        this.off();
        this._parent = null;
      }
    };
    EventGroup2.prototype.onAll = function(target, events, useCapture) {
      for (var eventName in events) {
        if (events.hasOwnProperty(eventName)) {
          this.on(target, eventName, events[eventName], useCapture);
        }
      }
    };
    EventGroup2.prototype.on = function(target, eventName, callback, options) {
      var _this = this;
      if (eventName.indexOf(",") > -1) {
        var events = eventName.split(/[ ,]+/);
        for (var i = 0; i < events.length; i++) {
          this.on(target, events[i], callback, options);
        }
      } else {
        var parent_1 = this._parent;
        var eventRecord = {
          target,
          eventName,
          parent: parent_1,
          callback,
          options
        };
        var events = target.__events__ = target.__events__ || {};
        events[eventName] = events[eventName] || {
          count: 0
        };
        events[eventName][this._id] = events[eventName][this._id] || [];
        events[eventName][this._id].push(eventRecord);
        events[eventName].count++;
        if (EventGroup2._isElement(target)) {
          var processElementEvent = function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            if (_this._isDisposed) {
              return;
            }
            var result;
            try {
              result = callback.apply(parent_1, args);
              if (result === false && args[0]) {
                var e = args[0];
                if (e.preventDefault) {
                  e.preventDefault();
                }
                if (e.stopPropagation) {
                  e.stopPropagation();
                }
                e.cancelBubble = true;
              }
            } catch (e2) {
            }
            return result;
          };
          eventRecord.elementCallback = processElementEvent;
          if (target.addEventListener) {
            target.addEventListener(eventName, processElementEvent, options);
          } else if (target.attachEvent) {
            target.attachEvent("on" + eventName, processElementEvent);
          }
        } else {
          var processObjectEvent = function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            if (_this._isDisposed) {
              return;
            }
            return callback.apply(parent_1, args);
          };
          eventRecord.objectCallback = processObjectEvent;
        }
        this._eventRecords.push(eventRecord);
      }
    };
    EventGroup2.prototype.off = function(target, eventName, callback, options) {
      for (var i = 0; i < this._eventRecords.length; i++) {
        var eventRecord = this._eventRecords[i];
        if ((!target || target === eventRecord.target) && (!eventName || eventName === eventRecord.eventName) && (!callback || callback === eventRecord.callback) && (typeof options !== "boolean" || options === eventRecord.options)) {
          var events = eventRecord.target.__events__;
          var targetArrayLookup = events[eventRecord.eventName];
          var targetArray = targetArrayLookup ? targetArrayLookup[this._id] : null;
          if (targetArray) {
            if (targetArray.length === 1 || !callback) {
              targetArrayLookup.count -= targetArray.length;
              delete events[eventRecord.eventName][this._id];
            } else {
              targetArrayLookup.count--;
              targetArray.splice(targetArray.indexOf(eventRecord), 1);
            }
            if (!targetArrayLookup.count) {
              delete events[eventRecord.eventName];
            }
          }
          if (eventRecord.elementCallback) {
            if (eventRecord.target.removeEventListener) {
              eventRecord.target.removeEventListener(eventRecord.eventName, eventRecord.elementCallback, eventRecord.options);
            } else if (eventRecord.target.detachEvent) {
              eventRecord.target.detachEvent("on" + eventRecord.eventName, eventRecord.elementCallback);
            }
          }
          this._eventRecords.splice(i--, 1);
        }
      }
    };
    EventGroup2.prototype.raise = function(eventName, eventArgs, bubbleEvent) {
      return EventGroup2.raise(this._parent, eventName, eventArgs, bubbleEvent);
    };
    EventGroup2.prototype.declare = function(event) {
      var declaredEvents = this._parent.__declaredEvents = this._parent.__declaredEvents || {};
      if (typeof event === "string") {
        declaredEvents[event] = true;
      } else {
        for (var i = 0; i < event.length; i++) {
          declaredEvents[event[i]] = true;
        }
      }
    };
    EventGroup2._uniqueId = 0;
    return EventGroup2;
  }()
);

// node_modules/@fluentui/utilities/lib/dom/getDocument.js
function getDocument(rootElement) {
  if (!canUseDOM() || typeof document === "undefined") {
    return void 0;
  } else {
    var el = rootElement;
    return el && el.ownerDocument ? el.ownerDocument : document;
  }
}

// node_modules/@fluentui/utilities/lib/scroll.js
var _scrollbarWidth;
var _bodyScrollDisabledCount = 0;
var DisabledScrollClassName = mergeStyles({
  overflow: "hidden !important"
});
var DATA_IS_SCROLLABLE_ATTRIBUTE = "data-is-scrollable";
var allowScrollOnElement = function(element, events) {
  if (!element) {
    return;
  }
  var _previousClientY = 0;
  var _element = null;
  var _saveClientY = function(event) {
    if (event.targetTouches.length === 1) {
      _previousClientY = event.targetTouches[0].clientY;
    }
  };
  var _preventOverscrolling = function(event) {
    if (event.targetTouches.length !== 1) {
      return;
    }
    event.stopPropagation();
    if (!_element) {
      return;
    }
    var clientY = event.targetTouches[0].clientY - _previousClientY;
    var scrollableParent = findScrollableParent(event.target);
    if (scrollableParent) {
      _element = scrollableParent;
    }
    if (_element.scrollTop === 0 && clientY > 0) {
      event.preventDefault();
    }
    if (_element.scrollHeight - Math.ceil(_element.scrollTop) <= _element.clientHeight && clientY < 0) {
      event.preventDefault();
    }
  };
  events.on(element, "touchstart", _saveClientY, { passive: false });
  events.on(element, "touchmove", _preventOverscrolling, { passive: false });
  _element = element;
};
var allowOverscrollOnElement = function(element, events) {
  if (!element) {
    return;
  }
  var _allowElementScroll = function(event) {
    event.stopPropagation();
  };
  events.on(element, "touchmove", _allowElementScroll, { passive: false });
};
var _disableIosBodyScroll = function(event) {
  event.preventDefault();
};
function disableBodyScroll() {
  var doc = getDocument();
  if (doc && doc.body && !_bodyScrollDisabledCount) {
    doc.body.classList.add(DisabledScrollClassName);
    doc.body.addEventListener("touchmove", _disableIosBodyScroll, { passive: false, capture: false });
  }
  _bodyScrollDisabledCount++;
}
function enableBodyScroll() {
  if (_bodyScrollDisabledCount > 0) {
    var doc = getDocument();
    if (doc && doc.body && _bodyScrollDisabledCount === 1) {
      doc.body.classList.remove(DisabledScrollClassName);
      doc.body.removeEventListener("touchmove", _disableIosBodyScroll);
    }
    _bodyScrollDisabledCount--;
  }
}
function getScrollbarWidth() {
  if (_scrollbarWidth === void 0) {
    var scrollDiv = document.createElement("div");
    scrollDiv.style.setProperty("width", "100px");
    scrollDiv.style.setProperty("height", "100px");
    scrollDiv.style.setProperty("overflow", "scroll");
    scrollDiv.style.setProperty("position", "absolute");
    scrollDiv.style.setProperty("top", "-9999px");
    document.body.appendChild(scrollDiv);
    _scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
    document.body.removeChild(scrollDiv);
  }
  return _scrollbarWidth;
}
function findScrollableParent(startingElement) {
  var el = startingElement;
  var doc = getDocument(startingElement);
  while (el && el !== doc.body) {
    if (el.getAttribute(DATA_IS_SCROLLABLE_ATTRIBUTE) === "true") {
      return el;
    }
    el = el.parentElement;
  }
  el = startingElement;
  while (el && el !== doc.body) {
    if (el.getAttribute(DATA_IS_SCROLLABLE_ATTRIBUTE) !== "false") {
      var computedStyles = getComputedStyle(el);
      var overflowY = computedStyles ? computedStyles.getPropertyValue("overflow-y") : "";
      if (overflowY && (overflowY === "scroll" || overflowY === "auto")) {
        return el;
      }
    }
    el = el.parentElement;
  }
  if (!el || el === doc.body) {
    el = getWindow(startingElement);
  }
  return el;
}

// node_modules/@fluentui/utilities/lib/dom/getRect.js
function getRect(element) {
  var rect;
  if (element) {
    if (element === window) {
      rect = {
        left: 0,
        top: 0,
        width: window.innerWidth,
        height: window.innerHeight,
        right: window.innerWidth,
        bottom: window.innerHeight
      };
    } else if (element.getBoundingClientRect) {
      rect = element.getBoundingClientRect();
    }
  }
  return rect;
}

// node_modules/@fluentui/utilities/lib/AutoScroll.js
var SCROLL_ITERATION_DELAY = 16;
var SCROLL_GUTTER = 100;
var MAX_SCROLL_VELOCITY = 15;
var AutoScroll = (
  /** @class */
  function() {
    function AutoScroll2(element) {
      this._events = new EventGroup(this);
      this._scrollableParent = findScrollableParent(element);
      this._incrementScroll = this._incrementScroll.bind(this);
      this._scrollRect = getRect(this._scrollableParent);
      if (this._scrollableParent === window) {
        this._scrollableParent = document.body;
      }
      if (this._scrollableParent) {
        this._events.on(window, "mousemove", this._onMouseMove, true);
        this._events.on(window, "touchmove", this._onTouchMove, true);
      }
    }
    AutoScroll2.prototype.dispose = function() {
      this._events.dispose();
      this._stopScroll();
    };
    AutoScroll2.prototype._onMouseMove = function(ev) {
      this._computeScrollVelocity(ev);
    };
    AutoScroll2.prototype._onTouchMove = function(ev) {
      if (ev.touches.length > 0) {
        this._computeScrollVelocity(ev);
      }
    };
    AutoScroll2.prototype._computeScrollVelocity = function(ev) {
      if (!this._scrollRect) {
        return;
      }
      var clientX;
      var clientY;
      if ("clientX" in ev) {
        clientX = ev.clientX;
        clientY = ev.clientY;
      } else {
        clientX = ev.touches[0].clientX;
        clientY = ev.touches[0].clientY;
      }
      var scrollRectTop = this._scrollRect.top;
      var scrollRectLeft = this._scrollRect.left;
      var scrollClientBottom = scrollRectTop + this._scrollRect.height - SCROLL_GUTTER;
      var scrollClientRight = scrollRectLeft + this._scrollRect.width - SCROLL_GUTTER;
      var scrollRect;
      var clientDirection;
      var scrollClient;
      if (clientY < scrollRectTop + SCROLL_GUTTER || clientY > scrollClientBottom) {
        clientDirection = clientY;
        scrollRect = scrollRectTop;
        scrollClient = scrollClientBottom;
        this._isVerticalScroll = true;
      } else {
        clientDirection = clientX;
        scrollRect = scrollRectLeft;
        scrollClient = scrollClientRight;
        this._isVerticalScroll = false;
      }
      if (clientDirection < scrollRect + SCROLL_GUTTER) {
        this._scrollVelocity = Math.max(-MAX_SCROLL_VELOCITY, -MAX_SCROLL_VELOCITY * ((SCROLL_GUTTER - (clientDirection - scrollRect)) / SCROLL_GUTTER));
      } else if (clientDirection > scrollClient) {
        this._scrollVelocity = Math.min(MAX_SCROLL_VELOCITY, MAX_SCROLL_VELOCITY * ((clientDirection - scrollClient) / SCROLL_GUTTER));
      } else {
        this._scrollVelocity = 0;
      }
      if (this._scrollVelocity) {
        this._startScroll();
      } else {
        this._stopScroll();
      }
    };
    AutoScroll2.prototype._startScroll = function() {
      if (!this._timeoutId) {
        this._incrementScroll();
      }
    };
    AutoScroll2.prototype._incrementScroll = function() {
      if (this._scrollableParent) {
        if (this._isVerticalScroll) {
          this._scrollableParent.scrollTop += Math.round(this._scrollVelocity);
        } else {
          this._scrollableParent.scrollLeft += Math.round(this._scrollVelocity);
        }
      }
      this._timeoutId = setTimeout(this._incrementScroll, SCROLL_ITERATION_DELAY);
    };
    AutoScroll2.prototype._stopScroll = function() {
      if (this._timeoutId) {
        clearTimeout(this._timeoutId);
        delete this._timeoutId;
      }
    };
    return AutoScroll2;
  }()
);

// node_modules/@fluentui/utilities/lib/warn/warn.js
var _warningCallback = void 0;
function warn(message) {
  if (_warningCallback && true) {
    _warningCallback(message);
  } else if (console && console.warn) {
    console.warn(message);
  }
}
function setWarningCallback(warningCallback) {
  _warningCallback = warningCallback;
}

// node_modules/@fluentui/utilities/lib/warn/warnConditionallyRequiredProps.js
function warnConditionallyRequiredProps(componentName, props, requiredProps, conditionalPropName, condition) {
  if (condition === true && true) {
    for (var _i = 0, requiredProps_1 = requiredProps; _i < requiredProps_1.length; _i++) {
      var requiredPropName = requiredProps_1[_i];
      if (!(requiredPropName in props)) {
        warn("".concat(componentName, " property '").concat(requiredPropName, "' is required when '").concat(conditionalPropName, "' is used.'"));
      }
    }
  }
}

// node_modules/@fluentui/utilities/lib/warn/warnMutuallyExclusive.js
function warnMutuallyExclusive(componentName, props, exclusiveMap) {
  if (true) {
    for (var propName in exclusiveMap) {
      if (props && props[propName] !== void 0) {
        var propInExclusiveMapValue = exclusiveMap[propName];
        if (propInExclusiveMapValue && props[propInExclusiveMapValue] !== void 0) {
          warn("".concat(componentName, " property '").concat(propName, "' is mutually exclusive with '").concat(exclusiveMap[propName], "'. ") + "Use one or the other.");
        }
      }
    }
  }
}

// node_modules/@fluentui/utilities/lib/warn/warnDeprecations.js
function warnDeprecations(componentName, props, deprecationMap) {
  if (true) {
    for (var propName in deprecationMap) {
      if (props && propName in props) {
        var deprecationMessage = "".concat(componentName, " property '").concat(propName, "' was used but has been deprecated.");
        var replacementPropName = deprecationMap[propName];
        if (replacementPropName) {
          deprecationMessage += " Use '".concat(replacementPropName, "' instead.");
        }
        warn(deprecationMessage);
      }
    }
  }
}

// node_modules/@fluentui/utilities/lib/BaseComponent.js
var React = __toESM(require_react());
var BaseComponent = (
  /** @class */
  function(_super) {
    __extends(BaseComponent2, _super);
    function BaseComponent2(props, context) {
      var _this = _super.call(this, props, context) || this;
      _makeAllSafe(_this, BaseComponent2.prototype, [
        "componentDidMount",
        "shouldComponentUpdate",
        "getSnapshotBeforeUpdate",
        "render",
        "componentDidUpdate",
        "componentWillUnmount"
      ]);
      return _this;
    }
    BaseComponent2.prototype.componentDidUpdate = function(prevProps, prevState) {
      this._updateComponentRef(prevProps, this.props);
    };
    BaseComponent2.prototype.componentDidMount = function() {
      this._setComponentRef(this.props.componentRef, this);
    };
    BaseComponent2.prototype.componentWillUnmount = function() {
      this._setComponentRef(this.props.componentRef, null);
      if (this.__disposables) {
        for (var i = 0, len = this._disposables.length; i < len; i++) {
          var disposable = this.__disposables[i];
          if (disposable.dispose) {
            disposable.dispose();
          }
        }
        this.__disposables = null;
      }
    };
    Object.defineProperty(BaseComponent2.prototype, "className", {
      /**
       * Gets the object's class name.
       */
      get: function() {
        if (!this.__className) {
          var funcNameRegex = /function (.{1,})\(/;
          var results = funcNameRegex.exec(this.constructor.toString());
          this.__className = results && results.length > 1 ? results[1] : "";
        }
        return this.__className;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_disposables", {
      /**
       * Allows subclasses to push things to this._disposables to be auto disposed.
       */
      get: function() {
        if (!this.__disposables) {
          this.__disposables = [];
        }
        return this.__disposables;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_async", {
      /**
       * Gets the async instance associated with the component, created on demand. The async instance gives
       * subclasses a way to execute setTimeout/setInterval async calls safely, where the callbacks
       * will be cleared/ignored automatically after unmounting. The helpers within the async object also
       * preserve the this pointer so that you don't need to "bind" the callbacks.
       */
      get: function() {
        if (!this.__async) {
          this.__async = new Async(this);
          this._disposables.push(this.__async);
        }
        return this.__async;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_events", {
      /**
       * Gets the event group instance assocaited with the component, created on demand. The event instance
       * provides on/off methods for listening to DOM (or regular javascript object) events. The event callbacks
       * will be automatically disconnected after unmounting. The helpers within the events object also
       * preserve the this reference so that you don't need to "bind" the callbacks.
       */
      get: function() {
        if (!this.__events) {
          this.__events = new EventGroup(this);
          this._disposables.push(this.__events);
        }
        return this.__events;
      },
      enumerable: false,
      configurable: true
    });
    BaseComponent2.prototype._resolveRef = function(refName) {
      var _this = this;
      if (!this.__resolves) {
        this.__resolves = {};
      }
      if (!this.__resolves[refName]) {
        this.__resolves[refName] = function(ref) {
          return _this[refName] = ref;
        };
      }
      return this.__resolves[refName];
    };
    BaseComponent2.prototype._updateComponentRef = function(currentProps, newProps) {
      if (newProps === void 0) {
        newProps = {};
      }
      if (currentProps && newProps && currentProps.componentRef !== newProps.componentRef) {
        this._setComponentRef(currentProps.componentRef, null);
        this._setComponentRef(newProps.componentRef, this);
      }
    };
    BaseComponent2.prototype._warnDeprecations = function(deprecationMap) {
      warnDeprecations(this.className, this.props, deprecationMap);
    };
    BaseComponent2.prototype._warnMutuallyExclusive = function(mutuallyExclusiveMap) {
      warnMutuallyExclusive(this.className, this.props, mutuallyExclusiveMap);
    };
    BaseComponent2.prototype._warnConditionallyRequiredProps = function(requiredProps, conditionalPropName, condition) {
      warnConditionallyRequiredProps(this.className, this.props, requiredProps, conditionalPropName, condition);
    };
    BaseComponent2.prototype._setComponentRef = function(ref, value) {
      if (!this._skipComponentRefResolution && ref) {
        if (typeof ref === "function") {
          ref(value);
        }
        if (typeof ref === "object") {
          ref.current = value;
        }
      }
    };
    return BaseComponent2;
  }(React.Component)
);
function _makeAllSafe(obj, prototype, methodNames) {
  for (var i = 0, len = methodNames.length; i < len; i++) {
    _makeSafe(obj, prototype, methodNames[i]);
  }
}
function _makeSafe(obj, prototype, methodName) {
  var classMethod = obj[methodName];
  var prototypeMethod = prototype[methodName];
  if (classMethod || prototypeMethod) {
    obj[methodName] = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var retVal2;
      if (prototypeMethod) {
        retVal2 = prototypeMethod.apply(this, args);
      }
      if (classMethod !== prototypeMethod) {
        retVal2 = classMethod.apply(this, args);
      }
      return retVal2;
    };
  }
}
function nullRender() {
  return null;
}

// node_modules/@fluentui/utilities/lib/DelayedRender.js
var React2 = __toESM(require_react());
var DelayedRender = (
  /** @class */
  function(_super) {
    __extends(DelayedRender2, _super);
    function DelayedRender2(props) {
      var _this = _super.call(this, props) || this;
      _this.state = {
        isRendered: getWindow() === void 0
      };
      return _this;
    }
    DelayedRender2.prototype.componentDidMount = function() {
      var _this = this;
      var delay = this.props.delay;
      this._timeoutId = window.setTimeout(function() {
        _this.setState({
          isRendered: true
        });
      }, delay);
    };
    DelayedRender2.prototype.componentWillUnmount = function() {
      if (this._timeoutId) {
        clearTimeout(this._timeoutId);
      }
    };
    DelayedRender2.prototype.render = function() {
      return this.state.isRendered ? React2.Children.only(this.props.children) : null;
    };
    DelayedRender2.defaultProps = {
      delay: 0
    };
    return DelayedRender2;
  }(React2.Component)
);

// node_modules/@fluentui/utilities/lib/FabricPerformance.js
var now = function() {
  return typeof performance !== "undefined" && !!performance.now ? performance.now() : Date.now();
};
var RESET_INTERVAL = 3 * 60 * 1e3;
var FabricPerformance = (
  /** @class */
  function() {
    function FabricPerformance2() {
    }
    FabricPerformance2.measure = function(name, func) {
      if (FabricPerformance2._timeoutId) {
        FabricPerformance2.setPeriodicReset();
      }
      var start = now();
      func();
      var end = now();
      var measurement = FabricPerformance2.summary[name] || {
        totalDuration: 0,
        count: 0,
        all: []
      };
      var duration = end - start;
      measurement.totalDuration += duration;
      measurement.count++;
      measurement.all.push({
        duration,
        timeStamp: end
      });
      FabricPerformance2.summary[name] = measurement;
    };
    FabricPerformance2.reset = function() {
      FabricPerformance2.summary = {};
      clearTimeout(FabricPerformance2._timeoutId);
      FabricPerformance2._timeoutId = NaN;
    };
    FabricPerformance2.setPeriodicReset = function() {
      FabricPerformance2._timeoutId = setTimeout(function() {
        return FabricPerformance2.reset();
      }, RESET_INTERVAL);
    };
    FabricPerformance2.summary = {};
    return FabricPerformance2;
  }()
);

// node_modules/@fluentui/utilities/lib/GlobalSettings.js
var GLOBAL_SETTINGS_PROP_NAME = "__globalSettings__";
var CALLBACK_STATE_PROP_NAME = "__callbacks__";
var _counter = 0;
var GlobalSettings = (
  /** @class */
  function() {
    function GlobalSettings2() {
    }
    GlobalSettings2.getValue = function(key, defaultValue) {
      var globalSettings = _getGlobalSettings();
      if (globalSettings[key] === void 0) {
        globalSettings[key] = typeof defaultValue === "function" ? defaultValue() : defaultValue;
      }
      return globalSettings[key];
    };
    GlobalSettings2.setValue = function(key, value) {
      var globalSettings = _getGlobalSettings();
      var callbacks = globalSettings[CALLBACK_STATE_PROP_NAME];
      var oldValue = globalSettings[key];
      if (value !== oldValue) {
        globalSettings[key] = value;
        var changeDescription = {
          oldValue,
          value,
          key
        };
        for (var id in callbacks) {
          if (callbacks.hasOwnProperty(id)) {
            callbacks[id](changeDescription);
          }
        }
      }
      return value;
    };
    GlobalSettings2.addChangeListener = function(cb) {
      var id = cb.__id__;
      var callbacks = _getCallbacks();
      if (!id) {
        id = cb.__id__ = String(_counter++);
      }
      callbacks[id] = cb;
    };
    GlobalSettings2.removeChangeListener = function(cb) {
      var callbacks = _getCallbacks();
      delete callbacks[cb.__id__];
    };
    return GlobalSettings2;
  }()
);
function _getGlobalSettings() {
  var _a2;
  var win = getWindow();
  var globalObj = win || {};
  if (!globalObj[GLOBAL_SETTINGS_PROP_NAME]) {
    globalObj[GLOBAL_SETTINGS_PROP_NAME] = (_a2 = {}, _a2[CALLBACK_STATE_PROP_NAME] = {}, _a2);
  }
  return globalObj[GLOBAL_SETTINGS_PROP_NAME];
}
function _getCallbacks() {
  var globalSettings = _getGlobalSettings();
  return globalSettings[CALLBACK_STATE_PROP_NAME];
}

// node_modules/@fluentui/utilities/lib/KeyCodes.js
var KeyCodes = {
  backspace: 8,
  tab: 9,
  enter: 13,
  shift: 16,
  ctrl: 17,
  alt: 18,
  pauseBreak: 19,
  capslock: 20,
  escape: 27,
  space: 32,
  pageUp: 33,
  pageDown: 34,
  end: 35,
  home: 36,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  insert: 45,
  del: 46,
  zero: 48,
  one: 49,
  two: 50,
  three: 51,
  four: 52,
  five: 53,
  six: 54,
  seven: 55,
  eight: 56,
  nine: 57,
  colon: 58,
  a: 65,
  b: 66,
  c: 67,
  d: 68,
  e: 69,
  f: 70,
  g: 71,
  h: 72,
  i: 73,
  j: 74,
  k: 75,
  l: 76,
  m: 77,
  n: 78,
  o: 79,
  p: 80,
  q: 81,
  r: 82,
  s: 83,
  t: 84,
  u: 85,
  v: 86,
  w: 87,
  x: 88,
  y: 89,
  z: 90,
  leftWindow: 91,
  rightWindow: 92,
  select: 93,
  /* eslint-disable @typescript-eslint/naming-convention */
  zero_numpad: 96,
  one_numpad: 97,
  two_numpad: 98,
  three_numpad: 99,
  four_numpad: 100,
  five_numpad: 101,
  six_numpad: 102,
  seven_numpad: 103,
  eight_numpad: 104,
  nine_numpad: 105,
  /* eslint-enable @typescript-eslint/naming-convention */
  multiply: 106,
  add: 107,
  subtract: 109,
  decimalPoint: 110,
  divide: 111,
  f1: 112,
  f2: 113,
  f3: 114,
  f4: 115,
  f5: 116,
  f6: 117,
  f7: 118,
  f8: 119,
  f9: 120,
  f10: 121,
  f11: 122,
  f12: 123,
  numlock: 144,
  scrollLock: 145,
  semicolon: 186,
  equalSign: 187,
  comma: 188,
  dash: 189,
  period: 190,
  forwardSlash: 191,
  graveAccent: 192,
  openBracket: 219,
  backSlash: 220,
  closeBracket: 221,
  singleQuote: 222
};

// node_modules/@fluentui/utilities/lib/Rectangle.js
var Rectangle = (
  /** @class */
  function() {
    function Rectangle2(left, right, top, bottom) {
      if (left === void 0) {
        left = 0;
      }
      if (right === void 0) {
        right = 0;
      }
      if (top === void 0) {
        top = 0;
      }
      if (bottom === void 0) {
        bottom = 0;
      }
      this.top = top;
      this.bottom = bottom;
      this.left = left;
      this.right = right;
    }
    Object.defineProperty(Rectangle2.prototype, "width", {
      /**
       * Calculated automatically by subtracting the right from left
       */
      get: function() {
        return this.right - this.left;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Rectangle2.prototype, "height", {
      /**
       * Calculated automatically by subtracting the bottom from top.
       */
      get: function() {
        return this.bottom - this.top;
      },
      enumerable: false,
      configurable: true
    });
    Rectangle2.prototype.equals = function(rect) {
      return parseFloat(this.top.toFixed(4)) === parseFloat(rect.top.toFixed(4)) && parseFloat(this.bottom.toFixed(4)) === parseFloat(rect.bottom.toFixed(4)) && parseFloat(this.left.toFixed(4)) === parseFloat(rect.left.toFixed(4)) && parseFloat(this.right.toFixed(4)) === parseFloat(rect.right.toFixed(4));
    };
    return Rectangle2;
  }()
);

// node_modules/@fluentui/utilities/lib/appendFunction.js
function appendFunction(parent) {
  var functions = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    functions[_i - 1] = arguments[_i];
  }
  if (functions.length < 2) {
    return functions[0];
  }
  return function() {
    var args = [];
    for (var _i2 = 0; _i2 < arguments.length; _i2++) {
      args[_i2] = arguments[_i2];
    }
    functions.forEach(function(f) {
      return f && f.apply(parent, args);
    });
  };
}

// node_modules/@fluentui/utilities/lib/aria.js
function mergeAriaAttributeValues() {
  var ariaAttributes = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    ariaAttributes[_i] = arguments[_i];
  }
  var mergedAttribute = ariaAttributes.filter(function(arg) {
    return arg;
  }).join(" ").trim();
  return mergedAttribute === "" ? void 0 : mergedAttribute;
}

// node_modules/@fluentui/utilities/lib/array.js
function findIndex(array, cb, fromIndex) {
  if (fromIndex === void 0) {
    fromIndex = 0;
  }
  var index = -1;
  for (var i = fromIndex; array && i < array.length; i++) {
    if (cb(array[i], i)) {
      index = i;
      break;
    }
  }
  return index;
}
function find(array, cb) {
  var index = findIndex(array, cb);
  if (index < 0) {
    return void 0;
  }
  return array[index];
}
function createArray(size, getItem3) {
  var array = [];
  for (var i = 0; i < size; i++) {
    array.push(getItem3(i));
  }
  return array;
}
function toMatrix(items, columnCount) {
  return items.reduce(function(rows, currentValue, index) {
    if (index % columnCount === 0) {
      rows.push([currentValue]);
    } else {
      rows[rows.length - 1].push(currentValue);
    }
    return rows;
  }, []);
}
function removeIndex(array, index) {
  return array.filter(function(_, i) {
    return index !== i;
  });
}
function replaceElement(array, newElement, index) {
  var copy = array.slice();
  copy[index] = newElement;
  return copy;
}
function addElementAtIndex(array, index, itemToAdd) {
  var copy = array.slice();
  copy.splice(index, 0, itemToAdd);
  return copy;
}
function flatten(array) {
  var result = [];
  array.forEach(function(item) {
    return result = result.concat(item);
  });
  return result;
}
function arraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }
  for (var i = 0; i < array1.length; i++) {
    if (array1[i] !== array2[i]) {
      return false;
    }
  }
  return true;
}

// node_modules/@fluentui/utilities/lib/asAsync.js
var React3 = __toESM(require_react());
var _syncModuleCache = typeof WeakMap !== "undefined" ? (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  /* @__PURE__ */ new WeakMap()
) : void 0;
function asAsync(options) {
  var Async2 = (
    /** @class */
    function(_super) {
      __extends(Async3, _super);
      function Async3() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.state = {
          Component: _syncModuleCache ? _syncModuleCache.get(options.load) : void 0
        };
        return _this;
      }
      Async3.prototype.render = function() {
        var _a2 = this.props, forwardedRef = _a2.forwardedRef, Placeholder = _a2.asyncPlaceholder, rest = __rest(_a2, ["forwardedRef", "asyncPlaceholder"]);
        var Component6 = this.state.Component;
        return Component6 ? React3.createElement(Component6, __assign(__assign({}, rest), { ref: forwardedRef })) : Placeholder ? React3.createElement(Placeholder, null) : null;
      };
      Async3.prototype.componentDidMount = function() {
        var _this = this;
        var Component6 = this.state.Component;
        if (!Component6) {
          options.load().then(function(LoadedComponent) {
            if (LoadedComponent) {
              _syncModuleCache && _syncModuleCache.set(options.load, LoadedComponent);
              _this.setState({
                Component: LoadedComponent
              }, options.onLoad);
            }
          }).catch(options.onError);
        }
      };
      return Async3;
    }(React3.Component)
  );
  return React3.forwardRef(function(props, ref) {
    return React3.createElement(Async2, __assign({}, props, { forwardedRef: ref }));
  });
}

// node_modules/@fluentui/utilities/lib/assertNever.js
function assertNever(x) {
  throw new Error("Unexpected object: " + x);
}

// node_modules/@fluentui/utilities/lib/sessionStorage.js
function getItem(key) {
  var result = null;
  try {
    var win = getWindow();
    result = win ? win.sessionStorage.getItem(key) : null;
  } catch (e) {
  }
  return result;
}
function setItem(key, data) {
  var _a2;
  try {
    (_a2 = getWindow()) === null || _a2 === void 0 ? void 0 : _a2.sessionStorage.setItem(key, data);
  } catch (e) {
  }
}

// node_modules/@fluentui/utilities/lib/rtl.js
var RTL_LOCAL_STORAGE_KEY = "isRTL";
var _isRTL;
function getRTL(theme) {
  if (theme === void 0) {
    theme = {};
  }
  if (theme.rtl !== void 0) {
    return theme.rtl;
  }
  if (_isRTL === void 0) {
    var savedRTL = getItem(RTL_LOCAL_STORAGE_KEY);
    if (savedRTL !== null) {
      _isRTL = savedRTL === "1";
      setRTL2(_isRTL);
    }
    var doc = getDocument();
    if (_isRTL === void 0 && doc) {
      _isRTL = (doc.body && doc.body.getAttribute("dir") || doc.documentElement.getAttribute("dir")) === "rtl";
      setRTL(_isRTL);
    }
  }
  return !!_isRTL;
}
function setRTL2(isRTL, persistSetting) {
  if (persistSetting === void 0) {
    persistSetting = false;
  }
  var doc = getDocument();
  if (doc) {
    doc.documentElement.setAttribute("dir", isRTL ? "rtl" : "ltr");
  }
  if (persistSetting) {
    setItem(RTL_LOCAL_STORAGE_KEY, isRTL ? "1" : "0");
  }
  _isRTL = isRTL;
  setRTL(_isRTL);
}
function getRTLSafeKeyCode(key, theme) {
  if (theme === void 0) {
    theme = {};
  }
  if (getRTL(theme)) {
    if (key === KeyCodes.left) {
      key = KeyCodes.right;
    } else if (key === KeyCodes.right) {
      key = KeyCodes.left;
    }
  }
  return key;
}

// node_modules/@fluentui/dom-utilities/lib/isVirtualElement.js
function isVirtualElement(element) {
  return element && !!element._virtual;
}

// node_modules/@fluentui/dom-utilities/lib/getVirtualParent.js
function getVirtualParent(child) {
  var parent;
  if (child && isVirtualElement(child)) {
    parent = child._virtual.parent;
  }
  return parent;
}

// node_modules/@fluentui/dom-utilities/lib/getParent.js
function getParent(child, allowVirtualParents) {
  if (allowVirtualParents === void 0) {
    allowVirtualParents = true;
  }
  return child && (allowVirtualParents && getVirtualParent(child) || child.parentNode && child.parentNode);
}

// node_modules/@fluentui/dom-utilities/lib/elementContains.js
function elementContains(parent, child, allowVirtualParents) {
  if (allowVirtualParents === void 0) {
    allowVirtualParents = true;
  }
  var isContained = false;
  if (parent && child) {
    if (allowVirtualParents) {
      if (parent === child) {
        isContained = true;
      } else {
        isContained = false;
        while (child) {
          var nextParent = getParent(child);
          if (nextParent === parent) {
            isContained = true;
            break;
          }
          child = nextParent;
        }
      }
    } else if (parent.contains) {
      isContained = parent.contains(child);
    }
  }
  return isContained;
}

// node_modules/@fluentui/dom-utilities/lib/findElementRecursive.js
function findElementRecursive(element, matchFunction) {
  if (!element || element === document.body) {
    return null;
  }
  return matchFunction(element) ? element : findElementRecursive(getParent(element), matchFunction);
}

// node_modules/@fluentui/dom-utilities/lib/elementContainsAttribute.js
function elementContainsAttribute(element, attribute) {
  var elementMatch = findElementRecursive(element, function(testElement) {
    return testElement.hasAttribute(attribute);
  });
  return elementMatch && elementMatch.getAttribute(attribute);
}

// node_modules/@fluentui/dom-utilities/lib/getChildren.js
function getChildren(parent, allowVirtualChildren) {
  if (allowVirtualChildren === void 0) {
    allowVirtualChildren = true;
  }
  var children = [];
  if (parent) {
    for (var i = 0; i < parent.children.length; i++) {
      children.push(parent.children.item(i));
    }
    if (allowVirtualChildren && isVirtualElement(parent)) {
      children.push.apply(children, parent._virtual.children);
    }
  }
  return children;
}

// node_modules/@fluentui/dom-utilities/lib/setPortalAttribute.js
var DATA_PORTAL_ATTRIBUTE = "data-portal-element";
function setPortalAttribute(element) {
  element.setAttribute(DATA_PORTAL_ATTRIBUTE, "true");
}

// node_modules/@fluentui/dom-utilities/lib/portalContainsElement.js
function portalContainsElement(target, parent) {
  var elementMatch = findElementRecursive(target, function(testElement) {
    return parent === testElement || testElement.hasAttribute(DATA_PORTAL_ATTRIBUTE);
  });
  return elementMatch !== null && elementMatch.hasAttribute(DATA_PORTAL_ATTRIBUTE);
}

// node_modules/@fluentui/dom-utilities/lib/setVirtualParent.js
function setVirtualParent(child, parent) {
  var virtualChild = child;
  var virtualParent = parent;
  if (!virtualChild._virtual) {
    virtualChild._virtual = {
      children: []
    };
  }
  var oldParent = virtualChild._virtual.parent;
  if (oldParent && oldParent !== parent) {
    var index = oldParent._virtual.children.indexOf(virtualChild);
    if (index > -1) {
      oldParent._virtual.children.splice(index, 1);
    }
  }
  virtualChild._virtual.parent = virtualParent || void 0;
  if (virtualParent) {
    if (!virtualParent._virtual) {
      virtualParent._virtual = {
        children: []
      };
    }
    virtualParent._virtual.children.push(virtualChild);
  }
}

// node_modules/@fluentui/dom-utilities/lib/version.js
setVersion("@fluentui/dom-utilities", "2.2.11");

// node_modules/@fluentui/utilities/lib/focus.js
var IS_FOCUSABLE_ATTRIBUTE = "data-is-focusable";
var IS_VISIBLE_ATTRIBUTE = "data-is-visible";
var FOCUSZONE_ID_ATTRIBUTE = "data-focuszone-id";
var FOCUSZONE_SUB_ATTRIBUTE = "data-is-sub-focuszone";
function getFirstFocusable(rootElement, currentElement, includeElementsInFocusZones) {
  return getNextElement(rootElement, currentElement, true, false, false, includeElementsInFocusZones);
}
function getLastFocusable(rootElement, currentElement, includeElementsInFocusZones) {
  return getPreviousElement(rootElement, currentElement, true, false, true, includeElementsInFocusZones);
}
function getFirstTabbable(rootElement, currentElement, includeElementsInFocusZones, checkNode) {
  if (checkNode === void 0) {
    checkNode = true;
  }
  return getNextElement(
    rootElement,
    currentElement,
    checkNode,
    false,
    false,
    includeElementsInFocusZones,
    false,
    true
    /*tabbable*/
  );
}
function getLastTabbable(rootElement, currentElement, includeElementsInFocusZones, checkNode) {
  if (checkNode === void 0) {
    checkNode = true;
  }
  return getPreviousElement(
    rootElement,
    currentElement,
    checkNode,
    false,
    true,
    includeElementsInFocusZones,
    false,
    true
    /*tabbable*/
  );
}
function focusFirstChild(rootElement, bypassHiddenElements) {
  var element = getNextElement(rootElement, rootElement, true, false, false, true, void 0, void 0, bypassHiddenElements);
  if (element) {
    focusAsync(element);
    return true;
  }
  return false;
}
function getPreviousElement(rootElement, currentElement, checkNode, suppressParentTraversal, traverseChildren, includeElementsInFocusZones, allowFocusRoot, tabbable) {
  if (!currentElement || !allowFocusRoot && currentElement === rootElement) {
    return null;
  }
  var isCurrentElementVisible = isElementVisible(currentElement);
  if (traverseChildren && isCurrentElementVisible && (includeElementsInFocusZones || !(isElementFocusZone(currentElement) || isElementFocusSubZone(currentElement)))) {
    var childMatch = getPreviousElement(rootElement, currentElement.lastElementChild, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
    if (childMatch) {
      if (tabbable && isElementTabbable(childMatch, true) || !tabbable) {
        return childMatch;
      }
      var childMatchSiblingMatch = getPreviousElement(rootElement, childMatch.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
      if (childMatchSiblingMatch) {
        return childMatchSiblingMatch;
      }
      var childMatchParent = childMatch.parentElement;
      while (childMatchParent && childMatchParent !== currentElement) {
        var childMatchParentMatch = getPreviousElement(rootElement, childMatchParent.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
        if (childMatchParentMatch) {
          return childMatchParentMatch;
        }
        childMatchParent = childMatchParent.parentElement;
      }
    }
  }
  if (checkNode && isCurrentElementVisible && isElementTabbable(currentElement, tabbable)) {
    return currentElement;
  }
  var siblingMatch = getPreviousElement(rootElement, currentElement.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
  if (siblingMatch) {
    return siblingMatch;
  }
  if (!suppressParentTraversal) {
    return getPreviousElement(rootElement, currentElement.parentElement, true, false, false, includeElementsInFocusZones, allowFocusRoot, tabbable);
  }
  return null;
}
function getNextElement(rootElement, currentElement, checkNode, suppressParentTraversal, suppressChildTraversal, includeElementsInFocusZones, allowFocusRoot, tabbable, bypassHiddenElements) {
  if (!currentElement || currentElement === rootElement && suppressChildTraversal && !allowFocusRoot) {
    return null;
  }
  var checkElementVisibility = bypassHiddenElements ? isElementVisibleAndNotHidden : isElementVisible;
  var isCurrentElementVisible = checkElementVisibility(currentElement);
  if (checkNode && isCurrentElementVisible && isElementTabbable(currentElement, tabbable)) {
    return currentElement;
  }
  if (!suppressChildTraversal && isCurrentElementVisible && (includeElementsInFocusZones || !(isElementFocusZone(currentElement) || isElementFocusSubZone(currentElement)))) {
    var childMatch = getNextElement(rootElement, currentElement.firstElementChild, true, true, false, includeElementsInFocusZones, allowFocusRoot, tabbable, bypassHiddenElements);
    if (childMatch) {
      return childMatch;
    }
  }
  if (currentElement === rootElement) {
    return null;
  }
  var siblingMatch = getNextElement(rootElement, currentElement.nextElementSibling, true, true, false, includeElementsInFocusZones, allowFocusRoot, tabbable, bypassHiddenElements);
  if (siblingMatch) {
    return siblingMatch;
  }
  if (!suppressParentTraversal) {
    return getNextElement(rootElement, currentElement.parentElement, false, false, true, includeElementsInFocusZones, allowFocusRoot, tabbable, bypassHiddenElements);
  }
  return null;
}
function isElementVisible(element) {
  if (!element || !element.getAttribute) {
    return false;
  }
  var visibilityAttribute = element.getAttribute(IS_VISIBLE_ATTRIBUTE);
  if (visibilityAttribute !== null && visibilityAttribute !== void 0) {
    return visibilityAttribute === "true";
  }
  return element.offsetHeight !== 0 || element.offsetParent !== null || // eslint-disable-next-line @typescript-eslint/no-explicit-any
  element.isVisible === true;
}
function isElementVisibleAndNotHidden(element) {
  return !!element && isElementVisible(element) && !element.hidden && window.getComputedStyle(element).visibility !== "hidden";
}
function isElementTabbable(element, checkTabIndex) {
  if (!element || element.disabled) {
    return false;
  }
  var tabIndex = 0;
  var tabIndexAttributeValue = null;
  if (element && element.getAttribute) {
    tabIndexAttributeValue = element.getAttribute("tabIndex");
    if (tabIndexAttributeValue) {
      tabIndex = parseInt(tabIndexAttributeValue, 10);
    }
  }
  var isFocusableAttribute = element.getAttribute ? element.getAttribute(IS_FOCUSABLE_ATTRIBUTE) : null;
  var isTabIndexSet = tabIndexAttributeValue !== null && tabIndex >= 0;
  var result = !!element && isFocusableAttribute !== "false" && (element.tagName === "A" || element.tagName === "BUTTON" || element.tagName === "INPUT" || element.tagName === "TEXTAREA" || element.tagName === "SELECT" || isFocusableAttribute === "true" || isTabIndexSet);
  return checkTabIndex ? tabIndex !== -1 && result : result;
}
function isElementFocusZone(element) {
  return !!(element && element.getAttribute && !!element.getAttribute(FOCUSZONE_ID_ATTRIBUTE));
}
function isElementFocusSubZone(element) {
  return !!(element && element.getAttribute && element.getAttribute(FOCUSZONE_SUB_ATTRIBUTE) === "true");
}
function doesElementContainFocus(element) {
  var document2 = getDocument(element);
  var currentActiveElement = document2 && document2.activeElement;
  if (currentActiveElement && elementContains(element, currentActiveElement)) {
    return true;
  }
  return false;
}
function shouldWrapFocus(element, noWrapDataAttribute) {
  return elementContainsAttribute(element, noWrapDataAttribute) === "true" ? false : true;
}
var animationId = void 0;
function focusAsync(element) {
  if (element) {
    var win = getWindow(element);
    if (win) {
      if (animationId !== void 0) {
        win.cancelAnimationFrame(animationId);
      }
      animationId = win.requestAnimationFrame(function() {
        element && element.focus();
        animationId = void 0;
      });
    }
  }
}
function getFocusableByIndexPath(parent, path) {
  var element = parent;
  for (var _i = 0, path_1 = path; _i < path_1.length; _i++) {
    var index = path_1[_i];
    var nextChild = element.children[Math.min(index, element.children.length - 1)];
    if (!nextChild) {
      break;
    }
    element = nextChild;
  }
  element = isElementTabbable(element) && isElementVisible(element) ? element : getNextElement(parent, element, true) || getPreviousElement(parent, element);
  return element;
}
function getElementIndexPath(fromElement, toElement) {
  var path = [];
  while (toElement && fromElement && toElement !== fromElement) {
    var parent_1 = getParent(toElement, true);
    if (parent_1 === null) {
      return [];
    }
    path.unshift(Array.prototype.indexOf.call(parent_1.children, toElement));
    toElement = parent_1;
  }
  return path;
}

// node_modules/@fluentui/utilities/lib/dom/getFirstVisibleElementFromSelector.js
function getFirstVisibleElementFromSelector(selector) {
  var elements = getDocument().querySelectorAll(selector);
  return Array.from(elements).find(function(element) {
    return isElementVisibleAndNotHidden(element);
  });
}

// node_modules/@fluentui/utilities/lib/dom/on.js
function on(element, eventName, callback, options) {
  element.addEventListener(eventName, callback, options);
  return function() {
    return element.removeEventListener(eventName, callback, options);
  };
}

// node_modules/@fluentui/utilities/lib/dom/raiseClick.js
function raiseClick(target) {
  var event = createNewEvent("MouseEvents");
  event.initEvent("click", true, true);
  target.dispatchEvent(event);
}
function createNewEvent(eventName) {
  var event;
  if (typeof Event === "function") {
    event = new Event(eventName);
  } else {
    event = document.createEvent("Event");
    event.initEvent(eventName, true, true);
  }
  return event;
}

// node_modules/@fluentui/utilities/lib/classNamesFunction.js
var MAX_CACHE_COUNT = 50;
var DEFAULT_SPECIFICITY_MULTIPLIER = 5;
var _memoizedClassNames = 0;
var stylesheet = Stylesheet.getInstance();
if (stylesheet && stylesheet.onReset) {
  stylesheet.onReset(function() {
    return _memoizedClassNames++;
  });
}
var retVal = "__retval__";
function classNamesFunction(options) {
  if (options === void 0) {
    options = {};
  }
  var map = /* @__PURE__ */ new Map();
  var styleCalcCount = 0;
  var getClassNamesCount = 0;
  var currentMemoizedClassNames = _memoizedClassNames;
  var getClassNames = function(styleFunctionOrObject, styleProps) {
    var _a2;
    if (styleProps === void 0) {
      styleProps = {};
    }
    if (options.useStaticStyles && typeof styleFunctionOrObject === "function" && styleFunctionOrObject.__noStyleOverride__) {
      return styleFunctionOrObject(styleProps);
    }
    getClassNamesCount++;
    var current = map;
    var theme = styleProps.theme;
    var rtl = theme && theme.rtl !== void 0 ? theme.rtl : getRTL();
    var disableCaching = options.disableCaching;
    if (currentMemoizedClassNames !== _memoizedClassNames) {
      currentMemoizedClassNames = _memoizedClassNames;
      map = /* @__PURE__ */ new Map();
      styleCalcCount = 0;
    }
    if (!options.disableCaching) {
      current = _traverseMap(map, styleFunctionOrObject);
      current = _traverseMap(current, styleProps);
    }
    if (disableCaching || !current[retVal]) {
      if (styleFunctionOrObject === void 0) {
        current[retVal] = {};
      } else {
        current[retVal] = mergeCssSets([
          typeof styleFunctionOrObject === "function" ? styleFunctionOrObject(styleProps) : styleFunctionOrObject
        ], { rtl: !!rtl, specificityMultiplier: options.useStaticStyles ? DEFAULT_SPECIFICITY_MULTIPLIER : void 0 });
      }
      if (!disableCaching) {
        styleCalcCount++;
      }
    }
    if (styleCalcCount > (options.cacheSize || MAX_CACHE_COUNT)) {
      var win = getWindow();
      if ((_a2 = win === null || win === void 0 ? void 0 : win.FabricConfig) === null || _a2 === void 0 ? void 0 : _a2.enableClassNameCacheFullWarning) {
        console.warn("Styles are being recalculated too frequently. Cache miss rate is ".concat(styleCalcCount, "/").concat(getClassNamesCount, "."));
        console.trace();
      }
      map.clear();
      styleCalcCount = 0;
      options.disableCaching = true;
    }
    return current[retVal];
  };
  return getClassNames;
}
function _traverseEdge(current, value) {
  value = _normalizeValue(value);
  if (!current.has(value)) {
    current.set(value, /* @__PURE__ */ new Map());
  }
  return current.get(value);
}
function _traverseMap(current, inputs) {
  if (typeof inputs === "function") {
    var cachedInputsFromStyled = inputs.__cachedInputs__;
    if (cachedInputsFromStyled) {
      for (var _i = 0, _a2 = inputs.__cachedInputs__; _i < _a2.length; _i++) {
        var input = _a2[_i];
        current = _traverseEdge(current, input);
      }
    } else {
      current = _traverseEdge(current, inputs);
    }
  } else if (typeof inputs === "object") {
    for (var propName in inputs) {
      if (inputs.hasOwnProperty(propName)) {
        current = _traverseEdge(current, inputs[propName]);
      }
    }
  }
  return current;
}
function _normalizeValue(value) {
  switch (value) {
    case void 0:
      return "__undefined__";
    case null:
      return "__null__";
    default:
      return value;
  }
}

// node_modules/@fluentui/utilities/lib/memoize.js
var _initializedStylesheetResets = false;
var _resetCounter = 0;
var _emptyObject = { empty: true };
var _dictionary = {};
var _weakMap = typeof WeakMap === "undefined" ? null : WeakMap;
function setMemoizeWeakMap(weakMap) {
  _weakMap = weakMap;
}
function resetMemoizations() {
  _resetCounter++;
}
function memoize(_target, _key, descriptor) {
  var fn = memoizeFunction(descriptor.value && descriptor.value.bind(null));
  return {
    configurable: true,
    get: function() {
      return fn;
    }
  };
}
function memoizeFunction(cb, maxCacheSize, ignoreNullOrUndefinedResult) {
  if (maxCacheSize === void 0) {
    maxCacheSize = 100;
  }
  if (ignoreNullOrUndefinedResult === void 0) {
    ignoreNullOrUndefinedResult = false;
  }
  if (!_weakMap) {
    return cb;
  }
  if (!_initializedStylesheetResets) {
    var stylesheet2 = Stylesheet.getInstance();
    if (stylesheet2 && stylesheet2.onReset) {
      Stylesheet.getInstance().onReset(resetMemoizations);
    }
    _initializedStylesheetResets = true;
  }
  var rootNode;
  var cacheSize = 0;
  var localResetCounter = _resetCounter;
  return function memoizedFunction() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      args[_i] = arguments[_i];
    }
    var currentNode = rootNode;
    if (rootNode === void 0 || localResetCounter !== _resetCounter || maxCacheSize > 0 && cacheSize > maxCacheSize) {
      rootNode = _createNode();
      cacheSize = 0;
      localResetCounter = _resetCounter;
    }
    currentNode = rootNode;
    for (var i = 0; i < args.length; i++) {
      var arg = _normalizeArg(args[i]);
      if (!currentNode.map.has(arg)) {
        currentNode.map.set(arg, _createNode());
      }
      currentNode = currentNode.map.get(arg);
    }
    if (!currentNode.hasOwnProperty("value")) {
      currentNode.value = cb.apply(void 0, args);
      cacheSize++;
    }
    if (ignoreNullOrUndefinedResult && (currentNode.value === null || currentNode.value === void 0)) {
      currentNode.value = cb.apply(void 0, args);
    }
    return currentNode.value;
  };
}
function createMemoizer(getValue) {
  if (!_weakMap) {
    return getValue;
  }
  var cache = new _weakMap();
  function memoizedGetValue(input) {
    if (!input || typeof input !== "function" && typeof input !== "object") {
      return getValue(input);
    }
    if (cache.has(input)) {
      return cache.get(input);
    }
    var value = getValue(input);
    cache.set(input, value);
    return value;
  }
  return memoizedGetValue;
}
function _normalizeArg(val) {
  if (!val) {
    return _emptyObject;
  } else if (typeof val === "object" || typeof val === "function") {
    return val;
  } else if (!_dictionary[val]) {
    _dictionary[val] = { val };
  }
  return _dictionary[val];
}
function _createNode() {
  return {
    map: _weakMap ? new _weakMap() : null
  };
}

// node_modules/@fluentui/utilities/lib/componentAs/composeComponentAs.js
var React4 = __toESM(require_react());
function createComposedComponent(outer) {
  var Outer = outer;
  var outerMemoizer = createMemoizer(function(inner) {
    if (outer === inner) {
      throw new Error("Attempted to compose a component with itself.");
    }
    var Inner = inner;
    var innerMemoizer = createMemoizer(function(defaultRender) {
      var InnerWithDefaultRender = function(innerProps) {
        return React4.createElement(Inner, __assign({}, innerProps, { defaultRender }));
      };
      return InnerWithDefaultRender;
    });
    var OuterWithDefaultRender = function(outerProps) {
      var defaultRender = outerProps.defaultRender;
      return React4.createElement(Outer, __assign({}, outerProps, { defaultRender: defaultRender ? innerMemoizer(defaultRender) : Inner }));
    };
    return OuterWithDefaultRender;
  });
  return outerMemoizer;
}
var componentAsMemoizer = createMemoizer(createComposedComponent);
function composeComponentAs(outer, inner) {
  return componentAsMemoizer(outer)(inner);
}

// node_modules/@fluentui/utilities/lib/controlled.js
function isControlled(props, valueProp) {
  return props[valueProp] !== void 0 && props[valueProp] !== null;
}

// node_modules/@fluentui/utilities/lib/css.js
function css() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  var classes = [];
  for (var _a2 = 0, args_1 = args; _a2 < args_1.length; _a2++) {
    var arg = args_1[_a2];
    if (arg) {
      if (typeof arg === "string") {
        classes.push(arg);
      } else if (arg.hasOwnProperty("toString") && typeof arg.toString === "function") {
        classes.push(arg.toString());
      } else {
        for (var key in arg) {
          if (arg[key]) {
            classes.push(key);
          }
        }
      }
    }
  }
  return classes.join(" ");
}

// node_modules/@fluentui/utilities/lib/customizations/Customizations.js
var CustomizationsGlobalKey = "customizations";
var NO_CUSTOMIZATIONS = { settings: {}, scopedSettings: {}, inCustomizerContext: false };
var _allSettings = GlobalSettings.getValue(CustomizationsGlobalKey, {
  settings: {},
  scopedSettings: {},
  inCustomizerContext: false
});
var _events = [];
var Customizations = (
  /** @class */
  function() {
    function Customizations2() {
    }
    Customizations2.reset = function() {
      _allSettings.settings = {};
      _allSettings.scopedSettings = {};
    };
    Customizations2.applySettings = function(settings) {
      _allSettings.settings = __assign(__assign({}, _allSettings.settings), settings);
      Customizations2._raiseChange();
    };
    Customizations2.applyScopedSettings = function(scopeName, settings) {
      _allSettings.scopedSettings[scopeName] = __assign(__assign({}, _allSettings.scopedSettings[scopeName]), settings);
      Customizations2._raiseChange();
    };
    Customizations2.getSettings = function(properties, scopeName, localSettings) {
      if (localSettings === void 0) {
        localSettings = NO_CUSTOMIZATIONS;
      }
      var settings = {};
      var localScopedSettings = scopeName && localSettings.scopedSettings[scopeName] || {};
      var globalScopedSettings = scopeName && _allSettings.scopedSettings[scopeName] || {};
      for (var _i = 0, properties_1 = properties; _i < properties_1.length; _i++) {
        var property = properties_1[_i];
        settings[property] = localScopedSettings[property] || localSettings.settings[property] || globalScopedSettings[property] || _allSettings.settings[property];
      }
      return settings;
    };
    Customizations2.applyBatchedUpdates = function(code, suppressUpdate) {
      Customizations2._suppressUpdates = true;
      try {
        code();
      } catch (_a2) {
      }
      Customizations2._suppressUpdates = false;
      if (!suppressUpdate) {
        Customizations2._raiseChange();
      }
    };
    Customizations2.observe = function(onChange) {
      _events.push(onChange);
    };
    Customizations2.unobserve = function(onChange) {
      _events = _events.filter(function(cb) {
        return cb !== onChange;
      });
    };
    Customizations2._raiseChange = function() {
      if (!Customizations2._suppressUpdates) {
        _events.forEach(function(cb) {
          return cb();
        });
      }
    };
    return Customizations2;
  }()
);

// node_modules/@fluentui/utilities/lib/customizations/CustomizerContext.js
var React5 = __toESM(require_react());
var CustomizerContext = React5.createContext({
  customizations: {
    inCustomizerContext: false,
    settings: {},
    scopedSettings: {}
  }
});

// node_modules/@fluentui/utilities/lib/customizations/mergeSettings.js
function mergeSettings(oldSettings, newSettings) {
  if (oldSettings === void 0) {
    oldSettings = {};
  }
  var mergeSettingsWith = _isSettingsFunction(newSettings) ? newSettings : _settingsMergeWith(newSettings);
  return mergeSettingsWith(oldSettings);
}
function mergeScopedSettings(oldSettings, newSettings) {
  if (oldSettings === void 0) {
    oldSettings = {};
  }
  var mergeSettingsWith = _isSettingsFunction(newSettings) ? newSettings : _scopedSettingsMergeWith(newSettings);
  return mergeSettingsWith(oldSettings);
}
function _isSettingsFunction(settings) {
  return typeof settings === "function";
}
function _settingsMergeWith(newSettings) {
  return function(settings) {
    return newSettings ? __assign(__assign({}, settings), newSettings) : settings;
  };
}
function _scopedSettingsMergeWith(scopedSettingsFromProps) {
  if (scopedSettingsFromProps === void 0) {
    scopedSettingsFromProps = {};
  }
  return function(oldScopedSettings) {
    var newScopedSettings = __assign({}, oldScopedSettings);
    for (var scopeName in scopedSettingsFromProps) {
      if (scopedSettingsFromProps.hasOwnProperty(scopeName)) {
        newScopedSettings[scopeName] = __assign(__assign({}, oldScopedSettings[scopeName]), scopedSettingsFromProps[scopeName]);
      }
    }
    return newScopedSettings;
  };
}

// node_modules/@fluentui/utilities/lib/customizations/mergeCustomizations.js
function mergeCustomizations(props, parentContext) {
  var _a2 = (parentContext || {}).customizations, customizations = _a2 === void 0 ? { settings: {}, scopedSettings: {} } : _a2;
  return {
    customizations: {
      settings: mergeSettings(customizations.settings, props.settings),
      scopedSettings: mergeScopedSettings(customizations.scopedSettings, props.scopedSettings),
      inCustomizerContext: true
    }
  };
}

// node_modules/@fluentui/utilities/lib/customizations/Customizer.js
var React6 = __toESM(require_react());
var Customizer = (
  /** @class */
  function(_super) {
    __extends(Customizer2, _super);
    function Customizer2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this._onCustomizationChange = function() {
        return _this.forceUpdate();
      };
      return _this;
    }
    Customizer2.prototype.componentDidMount = function() {
      Customizations.observe(this._onCustomizationChange);
    };
    Customizer2.prototype.componentWillUnmount = function() {
      Customizations.unobserve(this._onCustomizationChange);
    };
    Customizer2.prototype.render = function() {
      var _this = this;
      var contextTransform = this.props.contextTransform;
      return React6.createElement(CustomizerContext.Consumer, null, function(parentContext) {
        var newContext = mergeCustomizations(_this.props, parentContext);
        if (contextTransform) {
          newContext = contextTransform(newContext);
        }
        return React6.createElement(CustomizerContext.Provider, { value: newContext }, _this.props.children);
      });
    };
    return Customizer2;
  }(React6.Component)
);

// node_modules/@fluentui/utilities/lib/hoistStatics.js
function hoistStatics(source, dest) {
  for (var name_1 in source) {
    if (source.hasOwnProperty(name_1)) {
      dest[name_1] = source[name_1];
    }
  }
  return dest;
}

// node_modules/@fluentui/utilities/lib/customizations/customizable.js
var React7 = __toESM(require_react());
function customizable(scope, fields, concatStyles) {
  return function customizableFactory(ComposedComponent) {
    var _a2;
    var resultClass = (_a2 = /** @class */
    function(_super) {
      __extends(ComponentWithInjectedProps, _super);
      function ComponentWithInjectedProps(props) {
        var _this = _super.call(this, props) || this;
        _this._styleCache = {};
        _this._onSettingChanged = _this._onSettingChanged.bind(_this);
        return _this;
      }
      ComponentWithInjectedProps.prototype.componentDidMount = function() {
        Customizations.observe(this._onSettingChanged);
      };
      ComponentWithInjectedProps.prototype.componentWillUnmount = function() {
        Customizations.unobserve(this._onSettingChanged);
      };
      ComponentWithInjectedProps.prototype.render = function() {
        var _this = this;
        return React7.createElement(CustomizerContext.Consumer, null, function(context) {
          var defaultProps = Customizations.getSettings(fields, scope, context.customizations);
          var componentProps = _this.props;
          if (defaultProps.styles && typeof defaultProps.styles === "function") {
            defaultProps.styles = defaultProps.styles(__assign(__assign({}, defaultProps), componentProps));
          }
          if (concatStyles && defaultProps.styles) {
            if (_this._styleCache.default !== defaultProps.styles || _this._styleCache.component !== componentProps.styles) {
              var mergedStyles = concatStyleSets(defaultProps.styles, componentProps.styles);
              _this._styleCache.default = defaultProps.styles;
              _this._styleCache.component = componentProps.styles;
              _this._styleCache.merged = mergedStyles;
            }
            return React7.createElement(ComposedComponent, __assign({}, defaultProps, componentProps, { styles: _this._styleCache.merged }));
          }
          return React7.createElement(ComposedComponent, __assign({}, defaultProps, componentProps));
        });
      };
      ComponentWithInjectedProps.prototype._onSettingChanged = function() {
        this.forceUpdate();
      };
      return ComponentWithInjectedProps;
    }(React7.Component), _a2.displayName = "Customized" + scope, _a2);
    return hoistStatics(ComposedComponent, resultClass);
  };
}

// node_modules/@fluentui/utilities/lib/customizations/useCustomizationSettings.js
var React8 = __toESM(require_react());
function useCustomizationSettings(properties, scopeName) {
  var forceUpdate = useForceUpdate();
  var customizations = React8.useContext(CustomizerContext).customizations;
  var inCustomizerContext = customizations.inCustomizerContext;
  React8.useEffect(function() {
    if (!inCustomizerContext) {
      Customizations.observe(forceUpdate);
    }
    return function() {
      if (!inCustomizerContext) {
        Customizations.unobserve(forceUpdate);
      }
    };
  }, [inCustomizerContext]);
  return Customizations.getSettings(properties, scopeName, customizations);
}
function useForceUpdate() {
  var _a2 = React8.useState(0), setValue = _a2[1];
  return function() {
    return setValue(function(value) {
      return ++value;
    });
  };
}

// node_modules/@fluentui/utilities/lib/extendComponent.js
function extendComponent(parent, methods) {
  for (var name_1 in methods) {
    if (methods.hasOwnProperty(name_1)) {
      parent[name_1] = appendFunction(parent, parent[name_1], methods[name_1]);
    }
  }
}

// node_modules/@fluentui/utilities/lib/getId.js
var CURRENT_ID_PROPERTY = "__currentId__";
var DEFAULT_ID_STRING = "id__";
var _global = getWindow() || {};
if (_global[CURRENT_ID_PROPERTY] === void 0) {
  _global[CURRENT_ID_PROPERTY] = 0;
}
var _initializedStylesheetResets2 = false;
function getId(prefix) {
  if (!_initializedStylesheetResets2) {
    var stylesheet2 = Stylesheet.getInstance();
    if (stylesheet2 && stylesheet2.onReset) {
      stylesheet2.onReset(resetIds);
    }
    _initializedStylesheetResets2 = true;
  }
  var index = _global[CURRENT_ID_PROPERTY]++;
  return (prefix === void 0 ? DEFAULT_ID_STRING : prefix) + index;
}
function resetIds(counter) {
  if (counter === void 0) {
    counter = 0;
  }
  _global[CURRENT_ID_PROPERTY] = counter;
}

// node_modules/@fluentui/utilities/lib/properties.js
var toObjectMap = function() {
  var items = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    items[_i] = arguments[_i];
  }
  var result = {};
  for (var _a2 = 0, items_1 = items; _a2 < items_1.length; _a2++) {
    var item = items_1[_a2];
    var keys = Array.isArray(item) ? item : Object.keys(item);
    for (var _b = 0, keys_1 = keys; _b < keys_1.length; _b++) {
      var key = keys_1[_b];
      result[key] = 1;
    }
  }
  return result;
};
var baseElementEvents = toObjectMap([
  "onCopy",
  "onCut",
  "onPaste",
  "onCompositionEnd",
  "onCompositionStart",
  "onCompositionUpdate",
  "onFocus",
  "onFocusCapture",
  "onBlur",
  "onBlurCapture",
  "onChange",
  "onInput",
  "onSubmit",
  "onLoad",
  "onError",
  "onKeyDown",
  "onKeyDownCapture",
  "onKeyPress",
  "onKeyUp",
  "onAbort",
  "onCanPlay",
  "onCanPlayThrough",
  "onDurationChange",
  "onEmptied",
  "onEncrypted",
  "onEnded",
  "onLoadedData",
  "onLoadedMetadata",
  "onLoadStart",
  "onPause",
  "onPlay",
  "onPlaying",
  "onProgress",
  "onRateChange",
  "onSeeked",
  "onSeeking",
  "onStalled",
  "onSuspend",
  "onTimeUpdate",
  "onVolumeChange",
  "onWaiting",
  "onClick",
  "onClickCapture",
  "onContextMenu",
  "onDoubleClick",
  "onDrag",
  "onDragEnd",
  "onDragEnter",
  "onDragExit",
  "onDragLeave",
  "onDragOver",
  "onDragStart",
  "onDrop",
  "onMouseDown",
  "onMouseDownCapture",
  "onMouseEnter",
  "onMouseLeave",
  "onMouseMove",
  "onMouseOut",
  "onMouseOver",
  "onMouseUp",
  "onMouseUpCapture",
  "onSelect",
  "onTouchCancel",
  "onTouchEnd",
  "onTouchMove",
  "onTouchStart",
  "onScroll",
  "onWheel",
  "onPointerCancel",
  "onPointerDown",
  "onPointerEnter",
  "onPointerLeave",
  "onPointerMove",
  "onPointerOut",
  "onPointerOver",
  "onPointerUp",
  "onGotPointerCapture",
  "onLostPointerCapture"
]);
var baseElementProperties = toObjectMap([
  "accessKey",
  "children",
  "className",
  "contentEditable",
  "dir",
  "draggable",
  "hidden",
  "htmlFor",
  "id",
  "lang",
  "ref",
  "role",
  "style",
  "tabIndex",
  "title",
  "translate",
  "spellCheck",
  "name"
  // global
]);
var htmlElementProperties = toObjectMap(baseElementProperties, baseElementEvents);
var labelProperties = toObjectMap(htmlElementProperties, [
  "form"
  // button, fieldset, input, label, meter, object, output, select, textarea
]);
var audioProperties = toObjectMap(htmlElementProperties, [
  "height",
  "loop",
  "muted",
  "preload",
  "src",
  "width"
  // canvas, embed, iframe, img, input, object, video
]);
var videoProperties = toObjectMap(audioProperties, [
  "poster"
  // video
]);
var olProperties = toObjectMap(htmlElementProperties, [
  "start"
  // ol
]);
var liProperties = toObjectMap(htmlElementProperties, [
  "value"
  // button, input, li, option, meter, progress, param
]);
var anchorProperties = toObjectMap(htmlElementProperties, [
  "download",
  "href",
  "hrefLang",
  "media",
  "rel",
  "target",
  "type"
  // a, button, input, link, menu, object, script, source, style
]);
var buttonProperties = toObjectMap(htmlElementProperties, [
  "autoFocus",
  "disabled",
  "form",
  "formAction",
  "formEncType",
  "formMethod",
  "formNoValidate",
  "formTarget",
  "type",
  "value"
  // button, input, li, option, meter, progress, param,
]);
var inputProperties = toObjectMap(buttonProperties, [
  "accept",
  "alt",
  "autoCapitalize",
  "autoComplete",
  "checked",
  "dirname",
  "form",
  "height",
  "inputMode",
  "list",
  "max",
  "maxLength",
  "min",
  "minLength",
  "multiple",
  "pattern",
  "placeholder",
  "readOnly",
  "required",
  "src",
  "step",
  "size",
  "type",
  "value",
  "width"
  // canvas, embed, iframe, img, input, object, video
]);
var textAreaProperties = toObjectMap(buttonProperties, [
  "autoCapitalize",
  "cols",
  "dirname",
  "form",
  "maxLength",
  "minLength",
  "placeholder",
  "readOnly",
  "required",
  "rows",
  "wrap"
  // textarea
]);
var selectProperties = toObjectMap(buttonProperties, [
  "form",
  "multiple",
  "required"
  // input, select, textarea
]);
var optionProperties = toObjectMap(htmlElementProperties, [
  "selected",
  "value"
  // button, input, li, option, meter, progress, param
]);
var tableProperties = toObjectMap(htmlElementProperties, [
  "cellPadding",
  "cellSpacing"
  // table
]);
var trProperties = htmlElementProperties;
var thProperties = toObjectMap(htmlElementProperties, [
  "rowSpan",
  "scope"
  // th
]);
var tdProperties = toObjectMap(htmlElementProperties, [
  "colSpan",
  "headers",
  "rowSpan",
  "scope"
  // th
]);
var colGroupProperties = toObjectMap(htmlElementProperties, [
  "span"
  // col, colgroup
]);
var colProperties = toObjectMap(htmlElementProperties, [
  "span"
  // col, colgroup
]);
var formProperties = toObjectMap(htmlElementProperties, [
  "acceptCharset",
  "action",
  "encType",
  "encType",
  "method",
  "noValidate",
  "target"
  // form
]);
var iframeProperties = toObjectMap(htmlElementProperties, [
  "allow",
  "allowFullScreen",
  "allowPaymentRequest",
  "allowTransparency",
  "csp",
  "height",
  "importance",
  "referrerPolicy",
  "sandbox",
  "src",
  "srcDoc",
  "width"
  // canvas, embed, iframe, img, input, object, video,
]);
var imgProperties = toObjectMap(htmlElementProperties, [
  "alt",
  "crossOrigin",
  "height",
  "src",
  "srcSet",
  "useMap",
  "width"
  // canvas, embed, iframe, img, input, object, video
]);
var imageProperties = imgProperties;
var divProperties = htmlElementProperties;
function getNativeProps(props, allowedPropNames, excludedPropNames) {
  var isArray = Array.isArray(allowedPropNames);
  var result = {};
  var keys = Object.keys(props);
  for (var _i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
    var key = keys_2[_i];
    var isNativeProp = !isArray && allowedPropNames[key] || isArray && allowedPropNames.indexOf(key) >= 0 || key.indexOf("data-") === 0 || key.indexOf("aria-") === 0;
    if (isNativeProp && (!excludedPropNames || (excludedPropNames === null || excludedPropNames === void 0 ? void 0 : excludedPropNames.indexOf(key)) === -1)) {
      result[key] = props[key];
    }
  }
  return result;
}

// node_modules/@fluentui/utilities/lib/getNativeElementProps.js
var nativeElementMap = {
  label: labelProperties,
  audio: audioProperties,
  video: videoProperties,
  ol: olProperties,
  li: liProperties,
  a: anchorProperties,
  button: buttonProperties,
  input: inputProperties,
  textarea: textAreaProperties,
  select: selectProperties,
  option: optionProperties,
  table: tableProperties,
  tr: trProperties,
  th: thProperties,
  td: tdProperties,
  colGroup: colGroupProperties,
  col: colProperties,
  form: formProperties,
  iframe: iframeProperties,
  img: imgProperties
};
function getNativeElementProps(tagName, props, excludedPropNames) {
  var allowedPropNames = tagName && nativeElementMap[tagName] || htmlElementProperties;
  return getNativeProps(props, allowedPropNames, excludedPropNames);
}

// node_modules/@fluentui/utilities/lib/hoist.js
var REACT_LIFECYCLE_EXCLUSIONS = [
  "setState",
  "render",
  "componentWillMount",
  "UNSAFE_componentWillMount",
  "componentDidMount",
  "componentWillReceiveProps",
  "UNSAFE_componentWillReceiveProps",
  "shouldComponentUpdate",
  "componentWillUpdate",
  "getSnapshotBeforeUpdate",
  "UNSAFE_componentWillUpdate",
  "componentDidUpdate",
  "componentWillUnmount"
];
function hoistMethods(destination, source, exclusions) {
  if (exclusions === void 0) {
    exclusions = REACT_LIFECYCLE_EXCLUSIONS;
  }
  var hoisted = [];
  var _loop_1 = function(methodName2) {
    if (typeof source[methodName2] === "function" && destination[methodName2] === void 0 && (!exclusions || exclusions.indexOf(methodName2) === -1)) {
      hoisted.push(methodName2);
      destination[methodName2] = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        source[methodName2].apply(source, args);
      };
    }
  };
  for (var methodName in source) {
    _loop_1(methodName);
  }
  return hoisted;
}
function unhoistMethods(source, methodNames) {
  methodNames.forEach(function(methodName) {
    return delete source[methodName];
  });
}

// node_modules/@fluentui/utilities/lib/initializeComponentRef.js
function initializeComponentRef(obj) {
  extendComponent(obj, {
    componentDidMount: _onMount,
    componentDidUpdate: _onUpdate,
    componentWillUnmount: _onUnmount
  });
}
function _onMount() {
  _setComponentRef(this.props.componentRef, this);
}
function _onUpdate(prevProps) {
  if (prevProps.componentRef !== this.props.componentRef) {
    _setComponentRef(prevProps.componentRef, null);
    _setComponentRef(this.props.componentRef, this);
  }
}
function _onUnmount() {
  _setComponentRef(this.props.componentRef, null);
}
function _setComponentRef(componentRef, value) {
  if (componentRef) {
    if (typeof componentRef === "object") {
      componentRef.current = value;
    } else if (typeof componentRef === "function") {
      componentRef(value);
    }
  }
}

// node_modules/@fluentui/utilities/lib/keyboard.js
var _a;
var DirectionalKeyCodes = (_a = {}, _a[KeyCodes.up] = 1, _a[KeyCodes.down] = 1, _a[KeyCodes.left] = 1, _a[KeyCodes.right] = 1, _a[KeyCodes.home] = 1, _a[KeyCodes.end] = 1, _a[KeyCodes.tab] = 1, _a[KeyCodes.pageUp] = 1, _a[KeyCodes.pageDown] = 1, _a);
function isDirectionalKeyCode(which) {
  return !!DirectionalKeyCodes[which];
}
function addDirectionalKeyCode(which) {
  DirectionalKeyCodes[which] = 1;
}
function removeDirectionalKeyCode(which) {
  delete DirectionalKeyCodes[which];
}

// node_modules/@fluentui/utilities/lib/setFocusVisibility.js
var IsFocusVisibleClassName = "ms-Fabric--isFocusVisible";
var IsFocusHiddenClassName = "ms-Fabric--isFocusHidden";
function updateClassList(el, enabled) {
  if (el) {
    el.classList.add(enabled ? IsFocusVisibleClassName : IsFocusHiddenClassName);
    el.classList.remove(enabled ? IsFocusHiddenClassName : IsFocusVisibleClassName);
  }
}
function setFocusVisibility(enabled, target, registeredProviders) {
  var _a2;
  if (registeredProviders) {
    registeredProviders.forEach(function(ref) {
      return updateClassList(ref.current, enabled);
    });
  } else {
    updateClassList((_a2 = getWindow(target)) === null || _a2 === void 0 ? void 0 : _a2.document.body, enabled);
  }
}

// node_modules/@fluentui/utilities/lib/initializeFocusRects.js
function initializeFocusRects(window2) {
  var _a2;
  var win = window2 || getWindow();
  if (!win || ((_a2 = win.FabricConfig) === null || _a2 === void 0 ? void 0 : _a2.disableFocusRects) === true) {
    return;
  }
  if (!win.__hasInitializeFocusRects__) {
    win.__hasInitializeFocusRects__ = true;
    win.addEventListener("mousedown", _onMouseDown, true);
    win.addEventListener("pointerdown", _onPointerDown, true);
    win.addEventListener("keydown", _onKeyDown, true);
  }
}
function _onMouseDown(ev) {
  setFocusVisibility(false, ev.target);
}
function _onPointerDown(ev) {
  if (ev.pointerType !== "mouse") {
    setFocusVisibility(false, ev.target);
  }
}
function _onKeyDown(ev) {
  isDirectionalKeyCode(ev.which) && setFocusVisibility(true, ev.target);
}

// node_modules/@fluentui/utilities/lib/useFocusRects.js
var React9 = __toESM(require_react());
var mountCounters = /* @__PURE__ */ new WeakMap();
var callbackMap = /* @__PURE__ */ new WeakMap();
function setMountCounters(key, delta) {
  var newValue;
  var currValue = mountCounters.get(key);
  if (currValue) {
    newValue = currValue + delta;
  } else {
    newValue = 1;
  }
  mountCounters.set(key, newValue);
  return newValue;
}
function setCallbackMap(context) {
  var callbacks = callbackMap.get(context);
  if (callbacks) {
    return callbacks;
  }
  var onMouseDown = function(ev) {
    return _onMouseDown2(ev, context.registeredProviders);
  };
  var onPointerDown = function(ev) {
    return _onPointerDown2(ev, context.registeredProviders);
  };
  var onKeyDown = function(ev) {
    return _onKeyDown2(ev, context.registeredProviders);
  };
  var onKeyUp = function(ev) {
    return _onKeyUp(ev, context.registeredProviders);
  };
  callbacks = { onMouseDown, onPointerDown, onKeyDown, onKeyUp };
  callbackMap.set(context, callbacks);
  return callbacks;
}
var FocusRectsContext = React9.createContext(void 0);
function useFocusRects(rootRef) {
  var context = React9.useContext(FocusRectsContext);
  React9.useEffect(function() {
    var _a2, _b, _c, _d;
    var win = getWindow(rootRef === null || rootRef === void 0 ? void 0 : rootRef.current);
    if (!win || ((_a2 = win.FabricConfig) === null || _a2 === void 0 ? void 0 : _a2.disableFocusRects) === true) {
      return void 0;
    }
    var el = win;
    var onMouseDown;
    var onPointerDown;
    var onKeyDown;
    var onKeyUp;
    if (((_b = context === null || context === void 0 ? void 0 : context.providerRef) === null || _b === void 0 ? void 0 : _b.current) && ((_d = (_c = context === null || context === void 0 ? void 0 : context.providerRef) === null || _c === void 0 ? void 0 : _c.current) === null || _d === void 0 ? void 0 : _d.addEventListener)) {
      el = context.providerRef.current;
      var callbacks = (
        /*@__NOINLINE__*/
        setCallbackMap(context)
      );
      onMouseDown = callbacks.onMouseDown;
      onPointerDown = callbacks.onPointerDown;
      onKeyDown = callbacks.onKeyDown;
      onKeyUp = callbacks.onKeyUp;
    } else {
      onMouseDown = _onMouseDown2;
      onPointerDown = _onPointerDown2;
      onKeyDown = _onKeyDown2;
      onKeyUp = _onKeyUp;
    }
    var count = setMountCounters(el, 1);
    if (count <= 1) {
      el.addEventListener("mousedown", onMouseDown, true);
      el.addEventListener("pointerdown", onPointerDown, true);
      el.addEventListener("keydown", onKeyDown, true);
      el.addEventListener("keyup", onKeyUp, true);
    }
    return function() {
      var _a3;
      if (!win || ((_a3 = win.FabricConfig) === null || _a3 === void 0 ? void 0 : _a3.disableFocusRects) === true) {
        return;
      }
      count = setMountCounters(el, -1);
      if (count === 0) {
        el.removeEventListener("mousedown", onMouseDown, true);
        el.removeEventListener("pointerdown", onPointerDown, true);
        el.removeEventListener("keydown", onKeyDown, true);
        el.removeEventListener("keyup", onKeyUp, true);
      }
    };
  }, [context, rootRef]);
}
var FocusRects = function(props) {
  useFocusRects(props.rootRef);
  return null;
};
function _onMouseDown2(ev, registeredProviders) {
  setFocusVisibility(false, ev.target, registeredProviders);
}
function _onPointerDown2(ev, registeredProviders) {
  if (ev.pointerType !== "mouse") {
    setFocusVisibility(false, ev.target, registeredProviders);
  }
}
function _onKeyDown2(ev, registeredProviders) {
  if (isDirectionalKeyCode(ev.which)) {
    setFocusVisibility(true, ev.target, registeredProviders);
  }
}
function _onKeyUp(ev, registeredProviders) {
  if (isDirectionalKeyCode(ev.which)) {
    setFocusVisibility(true, ev.target, registeredProviders);
  }
}

// node_modules/@fluentui/utilities/lib/FocusRectsProvider.js
var React10 = __toESM(require_react());
var FocusRectsProvider = function(props) {
  var providerRef = props.providerRef, layerRoot = props.layerRoot;
  var registeredProviders = React10.useState([])[0];
  var parentContext = React10.useContext(FocusRectsContext);
  var inheritParentContext = parentContext !== void 0 && !layerRoot;
  var context = React10.useMemo(function() {
    return inheritParentContext ? void 0 : {
      providerRef,
      registeredProviders,
      registerProvider: function(ref) {
        registeredProviders.push(ref);
        parentContext === null || parentContext === void 0 ? void 0 : parentContext.registerProvider(ref);
      },
      unregisterProvider: function(ref) {
        parentContext === null || parentContext === void 0 ? void 0 : parentContext.unregisterProvider(ref);
        var i = registeredProviders.indexOf(ref);
        if (i >= 0) {
          registeredProviders.splice(i, 1);
        }
      }
    };
  }, [providerRef, registeredProviders, parentContext, inheritParentContext]);
  React10.useEffect(function() {
    if (context) {
      context.registerProvider(context.providerRef);
      return function() {
        return context.unregisterProvider(context.providerRef);
      };
    }
  }, [context]);
  if (context) {
    return React10.createElement(FocusRectsContext.Provider, { value: context }, props.children);
  } else {
    return React10.createElement(React10.Fragment, null, props.children);
  }
};

// node_modules/@fluentui/utilities/lib/initials.js
var UNWANTED_ENCLOSURES_REGEX = /[\(\[\{\<][^\)\]\}\>]*[\)\]\}\>]/g;
var UNWANTED_CHARS_REGEX = /[\0-\u001F\!-/:-@\[-`\{-\u00BF\u0250-\u036F\uD800-\uFFFF]/g;
var PHONENUMBER_REGEX = /^\d+[\d\s]*(:?ext|x|)\s*\d+$/i;
var MULTIPLE_WHITESPACES_REGEX = /\s+/g;
var UNSUPPORTED_TEXT_REGEX = (
  // eslint-disable-next-line @fluentui/max-len
  /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uAC00-\uD7AF\uD7B0-\uD7FF\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]|[\uD840-\uD869][\uDC00-\uDED6]/
);
function getInitialsLatin(displayName, isRtl) {
  var initials = "";
  var splits = displayName.split(" ");
  if (splits.length === 2) {
    initials += splits[0].charAt(0).toUpperCase();
    initials += splits[1].charAt(0).toUpperCase();
  } else if (splits.length === 3) {
    initials += splits[0].charAt(0).toUpperCase();
    initials += splits[2].charAt(0).toUpperCase();
  } else if (splits.length !== 0) {
    initials += splits[0].charAt(0).toUpperCase();
  }
  if (isRtl && initials.length > 1) {
    return initials.charAt(1) + initials.charAt(0);
  }
  return initials;
}
function cleanupDisplayName(displayName) {
  displayName = displayName.replace(UNWANTED_ENCLOSURES_REGEX, "");
  displayName = displayName.replace(UNWANTED_CHARS_REGEX, "");
  displayName = displayName.replace(MULTIPLE_WHITESPACES_REGEX, " ");
  displayName = displayName.trim();
  return displayName;
}
function getInitials(displayName, isRtl, allowPhoneInitials) {
  if (!displayName) {
    return "";
  }
  displayName = cleanupDisplayName(displayName);
  if (UNSUPPORTED_TEXT_REGEX.test(displayName) || !allowPhoneInitials && PHONENUMBER_REGEX.test(displayName)) {
    return "";
  }
  return getInitialsLatin(displayName, isRtl);
}

// node_modules/@fluentui/utilities/lib/localStorage.js
function getItem2(key) {
  var result = null;
  try {
    var win = getWindow();
    result = win ? win.localStorage.getItem(key) : null;
  } catch (e) {
  }
  return result;
}
function setItem2(key, data) {
  try {
    var win = getWindow();
    win && win.localStorage.setItem(key, data);
  } catch (e) {
  }
}

// node_modules/@fluentui/utilities/lib/language.js
var _language;
var STORAGE_KEY = "language";
function getLanguage(persistenceType) {
  if (persistenceType === void 0) {
    persistenceType = "sessionStorage";
  }
  if (_language === void 0) {
    var doc = getDocument();
    var savedLanguage = persistenceType === "localStorage" ? getItem2(STORAGE_KEY) : persistenceType === "sessionStorage" ? getItem(STORAGE_KEY) : void 0;
    if (savedLanguage) {
      _language = savedLanguage;
    }
    if (_language === void 0 && doc) {
      _language = doc.documentElement.getAttribute("lang");
    }
    if (_language === void 0) {
      _language = "en";
    }
  }
  return _language;
}
function setLanguage(language, persistenceParam) {
  var doc = getDocument();
  if (doc) {
    doc.documentElement.setAttribute("lang", language);
  }
  var persistenceType = persistenceParam === true ? "none" : !persistenceParam ? "sessionStorage" : persistenceParam;
  if (persistenceType === "localStorage") {
    setItem2(STORAGE_KEY, language);
  } else if (persistenceType === "sessionStorage") {
    setItem(STORAGE_KEY, language);
  }
  _language = language;
}

// node_modules/@fluentui/utilities/lib/math.js
function getDistanceBetweenPoints(point1, point2) {
  var left1 = point1.left || point1.x || 0;
  var top1 = point1.top || point1.y || 0;
  var left2 = point2.left || point2.x || 0;
  var top2 = point2.top || point2.y || 0;
  var distance = Math.sqrt(Math.pow(left1 - left2, 2) + Math.pow(top1 - top2, 2));
  return distance;
}
function fitContentToBounds(options) {
  var contentSize = options.contentSize, boundsSize = options.boundsSize, _a2 = options.mode, mode = _a2 === void 0 ? "contain" : _a2, _b = options.maxScale, maxScale = _b === void 0 ? 1 : _b;
  var contentAspectRatio = contentSize.width / contentSize.height;
  var boundsAspectRatio = boundsSize.width / boundsSize.height;
  var scale;
  if (mode === "contain" ? contentAspectRatio > boundsAspectRatio : contentAspectRatio < boundsAspectRatio) {
    scale = boundsSize.width / contentSize.width;
  } else {
    scale = boundsSize.height / contentSize.height;
  }
  var finalScale = Math.min(maxScale, scale);
  return {
    width: contentSize.width * finalScale,
    height: contentSize.height * finalScale
  };
}
function calculatePrecision(value) {
  var groups = /[1-9]([0]+$)|\.([0-9]*)/.exec(String(value));
  if (!groups) {
    return 0;
  }
  if (groups[1]) {
    return -groups[1].length;
  }
  if (groups[2]) {
    return groups[2].length;
  }
  return 0;
}
function precisionRound(value, precision, base) {
  if (base === void 0) {
    base = 10;
  }
  var exp = Math.pow(base, precision);
  return Math.round(value * exp) / exp;
}

// node_modules/@fluentui/utilities/lib/merge.js
function merge(target) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  for (var _a2 = 0, args_1 = args; _a2 < args_1.length; _a2++) {
    var arg = args_1[_a2];
    _merge(target || {}, arg);
  }
  return target;
}
function _merge(target, source, circularReferences) {
  if (circularReferences === void 0) {
    circularReferences = [];
  }
  circularReferences.push(source);
  for (var name_1 in source) {
    if (source.hasOwnProperty(name_1)) {
      if (name_1 !== "__proto__" && name_1 !== "constructor" && name_1 !== "prototype") {
        var value = source[name_1];
        if (typeof value === "object" && value !== null && !Array.isArray(value)) {
          var isCircularReference = circularReferences.indexOf(value) > -1;
          target[name_1] = isCircularReference ? value : _merge(target[name_1] || {}, value, circularReferences);
        } else {
          target[name_1] = value;
        }
      }
    }
  }
  circularReferences.pop();
  return target;
}

// node_modules/@fluentui/utilities/lib/mobileDetector.js
var isIOS = function() {
  if (!window || !window.navigator || !window.navigator.userAgent) {
    return false;
  }
  return /iPad|iPhone|iPod/i.test(window.navigator.userAgent);
};

// node_modules/@fluentui/utilities/lib/modalize.js
var tagsToIgnore = ["TEMPLATE", "STYLE", "SCRIPT"];
function modalize(target) {
  var targetDocument = getDocument(target);
  if (!targetDocument) {
    return function() {
      return void 0;
    };
  }
  var affectedNodes = [];
  while (target !== targetDocument.body && target.parentElement) {
    for (var _i = 0, _a2 = target.parentElement.children; _i < _a2.length; _i++) {
      var sibling = _a2[_i];
      var ariaHidden = sibling.getAttribute("aria-hidden");
      if (sibling !== target && (ariaHidden === null || ariaHidden === void 0 ? void 0 : ariaHidden.toLowerCase()) !== "true" && tagsToIgnore.indexOf(sibling.tagName) === -1) {
        affectedNodes.push([sibling, ariaHidden]);
      }
    }
    target = target.parentElement;
  }
  affectedNodes.forEach(function(_a3) {
    var node = _a3[0];
    node.setAttribute("aria-hidden", "true");
  });
  return function() {
    unmodalize(affectedNodes);
    affectedNodes = [];
  };
}
function unmodalize(affectedNodes) {
  affectedNodes.forEach(function(_a2) {
    var node = _a2[0], originalValue = _a2[1];
    if (originalValue) {
      node.setAttribute("aria-hidden", originalValue);
    } else {
      node.removeAttribute("aria-hidden");
    }
  });
}

// node_modules/@fluentui/utilities/lib/osDetector.js
var isMacResult;
function isMac(reset) {
  var _a2;
  if (typeof isMacResult === "undefined" || reset) {
    var win = getWindow();
    var userAgent = (_a2 = win === null || win === void 0 ? void 0 : win.navigator) === null || _a2 === void 0 ? void 0 : _a2.userAgent;
    isMacResult = !!userAgent && userAgent.indexOf("Macintosh") !== -1;
  }
  return !!isMacResult;
}

// node_modules/@fluentui/utilities/lib/overflow.js
function hasHorizontalOverflow(element) {
  return element.clientWidth < element.scrollWidth;
}
function hasVerticalOverflow(element) {
  return element.clientHeight < element.scrollHeight;
}
function hasOverflow(element) {
  return hasHorizontalOverflow(element) || hasVerticalOverflow(element);
}

// node_modules/@fluentui/utilities/lib/renderFunction/composeRenderFunction.js
function createComposedRenderFunction(outer) {
  var outerMemoizer = createMemoizer(function(inner) {
    var innerMemoizer = createMemoizer(function(defaultRender) {
      return function(innerProps) {
        return inner(innerProps, defaultRender);
      };
    });
    return function(outerProps, defaultRender) {
      return outer(outerProps, defaultRender ? innerMemoizer(defaultRender) : inner);
    };
  });
  return outerMemoizer;
}
var memoizer = createMemoizer(createComposedRenderFunction);
function composeRenderFunction(outer, inner) {
  return memoizer(outer)(inner);
}

// node_modules/@fluentui/utilities/lib/resources.js
var _baseUrl = "";
function getResourceUrl(url) {
  return _baseUrl + url;
}
function setBaseUrl(baseUrl) {
  _baseUrl = baseUrl;
}

// node_modules/@fluentui/utilities/lib/safeRequestAnimationFrame.js
var safeRequestAnimationFrame = function(component) {
  var activeTimeouts;
  return function(cb) {
    if (!activeTimeouts) {
      activeTimeouts = /* @__PURE__ */ new Set();
      extendComponent(component, {
        componentWillUnmount: function() {
          activeTimeouts.forEach(function(id) {
            return cancelAnimationFrame(id);
          });
        }
      });
    }
    var timeoutId = requestAnimationFrame(function() {
      activeTimeouts.delete(timeoutId);
      cb();
    });
    activeTimeouts.add(timeoutId);
  };
};

// node_modules/@fluentui/utilities/lib/safeSetTimeout.js
var safeSetTimeout = function(component) {
  var activeTimeouts;
  return function(cb, duration) {
    if (!activeTimeouts) {
      activeTimeouts = /* @__PURE__ */ new Set();
      extendComponent(component, {
        componentWillUnmount: function() {
          activeTimeouts.forEach(function(id) {
            return clearTimeout(id);
          });
        }
      });
    }
    var timeoutId = setTimeout(function() {
      activeTimeouts.delete(timeoutId);
      cb();
    }, duration);
    activeTimeouts.add(timeoutId);
  };
};

// node_modules/@fluentui/utilities/lib/selection/Selection.types.js
var SELECTION_CHANGE = "change";
var SELECTION_ITEMS_CHANGE = "items-change";
var SelectionMode;
(function(SelectionMode2) {
  SelectionMode2[SelectionMode2["none"] = 0] = "none";
  SelectionMode2[SelectionMode2["single"] = 1] = "single";
  SelectionMode2[SelectionMode2["multiple"] = 2] = "multiple";
})(SelectionMode || (SelectionMode = {}));
var SelectionDirection;
(function(SelectionDirection2) {
  SelectionDirection2[SelectionDirection2["horizontal"] = 0] = "horizontal";
  SelectionDirection2[SelectionDirection2["vertical"] = 1] = "vertical";
})(SelectionDirection || (SelectionDirection = {}));

// node_modules/@fluentui/utilities/lib/selection/Selection.js
var Selection = (
  /** @class */
  function() {
    function Selection2() {
      var options = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        options[_i] = arguments[_i];
      }
      var _a2 = options[0] || {}, onSelectionChanged = _a2.onSelectionChanged, onItemsChanged = _a2.onItemsChanged, getKey = _a2.getKey, _b = _a2.canSelectItem, canSelectItem = _b === void 0 ? function() {
        return true;
      } : _b, items = _a2.items, _c = _a2.selectionMode, selectionMode = _c === void 0 ? SelectionMode.multiple : _c;
      this.mode = selectionMode;
      this._getKey = getKey || defaultGetKey;
      this._changeEventSuppressionCount = 0;
      this._exemptedCount = 0;
      this._anchoredIndex = 0;
      this._unselectableCount = 0;
      this._onSelectionChanged = onSelectionChanged;
      this._onItemsChanged = onItemsChanged;
      this._canSelectItem = canSelectItem;
      this._keyToIndexMap = {};
      this._isModal = false;
      this.setItems(items || [], true);
      this.count = this.getSelectedCount();
    }
    Selection2.prototype.canSelectItem = function(item, index) {
      if (typeof index === "number" && index < 0) {
        return false;
      }
      return this._canSelectItem(item, index);
    };
    Selection2.prototype.getKey = function(item, index) {
      var key = this._getKey(item, index);
      return typeof key === "number" || key ? "".concat(key) : "";
    };
    Selection2.prototype.setChangeEvents = function(isEnabled, suppressChange) {
      this._changeEventSuppressionCount += isEnabled ? -1 : 1;
      if (this._changeEventSuppressionCount === 0 && this._hasChanged) {
        this._hasChanged = false;
        if (!suppressChange) {
          this._change();
        }
      }
    };
    Selection2.prototype.isModal = function() {
      return this._isModal;
    };
    Selection2.prototype.setModal = function(isModal) {
      if (this._isModal !== isModal) {
        this.setChangeEvents(false);
        this._isModal = isModal;
        if (!isModal) {
          this.setAllSelected(false);
        }
        this._change();
        this.setChangeEvents(true);
      }
    };
    Selection2.prototype.setItems = function(items, shouldClear) {
      if (shouldClear === void 0) {
        shouldClear = true;
      }
      var newKeyToIndexMap = {};
      var newUnselectableIndices = {};
      var hasSelectionChanged = false;
      this.setChangeEvents(false);
      this._unselectableCount = 0;
      var haveItemsChanged = false;
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (item) {
          var key = this.getKey(item, i);
          if (key) {
            if (!haveItemsChanged && (!(key in this._keyToIndexMap) || this._keyToIndexMap[key] !== i)) {
              haveItemsChanged = true;
            }
            newKeyToIndexMap[key] = i;
          }
        }
        newUnselectableIndices[i] = item && !this.canSelectItem(item);
        if (newUnselectableIndices[i]) {
          this._unselectableCount++;
        }
      }
      if (shouldClear || items.length === 0) {
        this._setAllSelected(false, true);
      }
      var newExemptedIndicies = {};
      var newExemptedCount = 0;
      for (var indexProperty in this._exemptedIndices) {
        if (this._exemptedIndices.hasOwnProperty(indexProperty)) {
          var index = Number(indexProperty);
          var item = this._items[index];
          var exemptKey = item ? this.getKey(item, Number(index)) : void 0;
          var newIndex = exemptKey ? newKeyToIndexMap[exemptKey] : index;
          if (newIndex === void 0) {
            hasSelectionChanged = true;
          } else {
            newExemptedIndicies[newIndex] = true;
            newExemptedCount++;
            hasSelectionChanged = hasSelectionChanged || newIndex !== index;
          }
        }
      }
      if (this._items && this._exemptedCount === 0 && items.length !== this._items.length && this._isAllSelected) {
        hasSelectionChanged = true;
      }
      if (!haveItemsChanged) {
        for (var _i = 0, _a2 = Object.keys(this._keyToIndexMap); _i < _a2.length; _i++) {
          var key = _a2[_i];
          if (!(key in newKeyToIndexMap)) {
            haveItemsChanged = true;
            break;
          }
        }
      }
      this._exemptedIndices = newExemptedIndicies;
      this._exemptedCount = newExemptedCount;
      this._keyToIndexMap = newKeyToIndexMap;
      this._unselectableIndices = newUnselectableIndices;
      this._items = items;
      this._selectedItems = null;
      if (hasSelectionChanged) {
        this._updateCount();
      }
      if (haveItemsChanged) {
        EventGroup.raise(this, SELECTION_ITEMS_CHANGE);
        if (this._onItemsChanged) {
          this._onItemsChanged();
        }
      }
      if (hasSelectionChanged) {
        this._change();
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.getItems = function() {
      return this._items;
    };
    Selection2.prototype.getSelection = function() {
      if (!this._selectedItems) {
        this._selectedItems = [];
        var items = this._items;
        if (items) {
          for (var i = 0; i < items.length; i++) {
            if (this.isIndexSelected(i)) {
              this._selectedItems.push(items[i]);
            }
          }
        }
      }
      return this._selectedItems;
    };
    Selection2.prototype.getSelectedCount = function() {
      return this._isAllSelected ? this._items.length - this._exemptedCount - this._unselectableCount : this._exemptedCount;
    };
    Selection2.prototype.getSelectedIndices = function() {
      if (!this._selectedIndices) {
        this._selectedIndices = [];
        var items = this._items;
        if (items) {
          for (var i = 0; i < items.length; i++) {
            if (this.isIndexSelected(i)) {
              this._selectedIndices.push(i);
            }
          }
        }
      }
      return this._selectedIndices;
    };
    Selection2.prototype.getItemIndex = function(key) {
      var index = this._keyToIndexMap[key];
      return index !== null && index !== void 0 ? index : -1;
    };
    Selection2.prototype.isRangeSelected = function(fromIndex, count) {
      if (count === 0) {
        return false;
      }
      var endIndex = fromIndex + count;
      for (var i = fromIndex; i < endIndex; i++) {
        if (!this.isIndexSelected(i)) {
          return false;
        }
      }
      return true;
    };
    Selection2.prototype.isAllSelected = function() {
      var selectableCount = this._items.length - this._unselectableCount;
      if (this.mode === SelectionMode.single) {
        selectableCount = Math.min(selectableCount, 1);
      }
      return this.count > 0 && this._isAllSelected && this._exemptedCount === 0 || !this._isAllSelected && this._exemptedCount === selectableCount && selectableCount > 0;
    };
    Selection2.prototype.isKeySelected = function(key) {
      var index = this._keyToIndexMap[key];
      return this.isIndexSelected(index);
    };
    Selection2.prototype.isIndexSelected = function(index) {
      return !!(this.count > 0 && this._isAllSelected && !this._exemptedIndices[index] && !this._unselectableIndices[index] || !this._isAllSelected && this._exemptedIndices[index]);
    };
    Selection2.prototype.setAllSelected = function(isAllSelected) {
      if (isAllSelected && this.mode !== SelectionMode.multiple) {
        return;
      }
      var selectableCount = this._items ? this._items.length - this._unselectableCount : 0;
      this.setChangeEvents(false);
      if (selectableCount > 0 && (this._exemptedCount > 0 || isAllSelected !== this._isAllSelected)) {
        this._exemptedIndices = {};
        if (isAllSelected !== this._isAllSelected || this._exemptedCount > 0) {
          this._exemptedCount = 0;
          this._isAllSelected = isAllSelected;
          this._change();
        }
        this._updateCount();
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.setKeySelected = function(key, isSelected, shouldAnchor) {
      var index = this._keyToIndexMap[key];
      if (index >= 0) {
        this.setIndexSelected(index, isSelected, shouldAnchor);
      }
    };
    Selection2.prototype.setIndexSelected = function(index, isSelected, shouldAnchor) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      index = Math.min(Math.max(0, index), this._items.length - 1);
      if (index < 0 || index >= this._items.length) {
        return;
      }
      this.setChangeEvents(false);
      var isExempt = this._exemptedIndices[index];
      var canSelect = !this._unselectableIndices[index];
      if (canSelect) {
        if (isSelected && this.mode === SelectionMode.single) {
          this._setAllSelected(false, true);
        }
        if (isExempt && (isSelected && this._isAllSelected || !isSelected && !this._isAllSelected)) {
          delete this._exemptedIndices[index];
          this._exemptedCount--;
        }
        if (!isExempt && (isSelected && !this._isAllSelected || !isSelected && this._isAllSelected)) {
          this._exemptedIndices[index] = true;
          this._exemptedCount++;
        }
        if (shouldAnchor) {
          this._anchoredIndex = index;
        }
      }
      this._updateCount();
      this.setChangeEvents(true);
    };
    Selection2.prototype.setRangeSelected = function(fromIndex, count, isSelected, shouldAnchor) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      fromIndex = Math.min(Math.max(0, fromIndex), this._items.length - 1);
      count = Math.min(Math.max(0, count), this._items.length - fromIndex);
      if (fromIndex < 0 || fromIndex >= this._items.length || count === 0) {
        return;
      }
      this.setChangeEvents(false);
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = fromIndex;
      var endIndex = fromIndex + count - 1;
      var newAnchorIndex = anchorIndex >= endIndex ? startIndex : endIndex;
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, isSelected, shouldAnchor ? startIndex === newAnchorIndex : false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.selectToKey = function(key, clearSelection) {
      this.selectToIndex(this._keyToIndexMap[key], clearSelection);
    };
    Selection2.prototype.selectToRange = function(fromIndex, count, clearSelection) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      if (this.mode === SelectionMode.single) {
        if (count === 1) {
          this.setIndexSelected(fromIndex, true, true);
        }
        return;
      }
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = Math.min(fromIndex, anchorIndex);
      var endIndex = Math.max(fromIndex + count - 1, anchorIndex);
      this.setChangeEvents(false);
      if (clearSelection) {
        this._setAllSelected(false, true);
      }
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, true, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.selectToIndex = function(index, clearSelection) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      if (this.mode === SelectionMode.single) {
        this.setIndexSelected(index, true, true);
        return;
      }
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = Math.min(index, anchorIndex);
      var endIndex = Math.max(index, anchorIndex);
      this.setChangeEvents(false);
      if (clearSelection) {
        this._setAllSelected(false, true);
      }
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, true, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.toggleAllSelected = function() {
      this.setAllSelected(!this.isAllSelected());
    };
    Selection2.prototype.toggleKeySelected = function(key) {
      this.setKeySelected(key, !this.isKeySelected(key), true);
    };
    Selection2.prototype.toggleIndexSelected = function(index) {
      this.setIndexSelected(index, !this.isIndexSelected(index), true);
    };
    Selection2.prototype.toggleRangeSelected = function(fromIndex, count) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      var isRangeSelected = this.isRangeSelected(fromIndex, count);
      var endIndex = fromIndex + count;
      if (this.mode === SelectionMode.single && count > 1) {
        return;
      }
      this.setChangeEvents(false);
      for (var i = fromIndex; i < endIndex; i++) {
        this.setIndexSelected(i, !isRangeSelected, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype._updateCount = function(preserveModalState) {
      if (preserveModalState === void 0) {
        preserveModalState = false;
      }
      var count = this.getSelectedCount();
      if (count !== this.count) {
        this.count = count;
        this._change();
      }
      if (!this.count && !preserveModalState) {
        this.setModal(false);
      }
    };
    Selection2.prototype._setAllSelected = function(isAllSelected, preserveModalState) {
      if (preserveModalState === void 0) {
        preserveModalState = false;
      }
      if (isAllSelected && this.mode !== SelectionMode.multiple) {
        return;
      }
      var selectableCount = this._items ? this._items.length - this._unselectableCount : 0;
      this.setChangeEvents(false);
      if (selectableCount > 0 && (this._exemptedCount > 0 || isAllSelected !== this._isAllSelected)) {
        this._exemptedIndices = {};
        if (isAllSelected !== this._isAllSelected || this._exemptedCount > 0) {
          this._exemptedCount = 0;
          this._isAllSelected = isAllSelected;
          this._change();
        }
        this._updateCount(preserveModalState);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype._change = function() {
      if (this._changeEventSuppressionCount === 0) {
        this._selectedItems = null;
        this._selectedIndices = void 0;
        EventGroup.raise(this, SELECTION_CHANGE);
        if (this._onSelectionChanged) {
          this._onSelectionChanged();
        }
      } else {
        this._hasChanged = true;
      }
    };
    return Selection2;
  }()
);
function defaultGetKey(item, index) {
  var _a2 = (item || {}).key, key = _a2 === void 0 ? "".concat(index) : _a2;
  return key;
}

// node_modules/@fluentui/utilities/lib/string.js
var FORMAT_ARGS_REGEX = /[\{\}]/g;
var FORMAT_REGEX = /\{\d+\}/g;
function format(s) {
  var values2 = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    values2[_i - 1] = arguments[_i];
  }
  var args = values2;
  function replaceFunc(match) {
    var replacement = args[match.replace(FORMAT_ARGS_REGEX, "")];
    if (replacement === null || replacement === void 0) {
      replacement = "";
    }
    return replacement;
  }
  return s.replace(FORMAT_REGEX, replaceFunc);
}

// node_modules/@fluentui/utilities/lib/styled.js
var React11 = __toESM(require_react());
var DefaultFields = ["theme", "styles"];
function styled(Component6, baseStyles, getProps, customizable2, pure) {
  customizable2 = customizable2 || { scope: "", fields: void 0 };
  var scope = customizable2.scope, _a2 = customizable2.fields, fields = _a2 === void 0 ? DefaultFields : _a2;
  var Wrapped = React11.forwardRef(function(props, forwardedRef) {
    var styles = React11.useRef();
    var settings = useCustomizationSettings(fields, scope);
    var customizedStyles = settings.styles, dir = settings.dir, rest = __rest(settings, ["styles", "dir"]);
    var additionalProps = getProps ? getProps(props) : void 0;
    var cache = styles.current && styles.current.__cachedInputs__ || [];
    var propStyles = props.styles;
    if (!styles.current || customizedStyles !== cache[1] || propStyles !== cache[2]) {
      var concatenatedStyles = function(styleProps) {
        return concatStyleSetsWithProps(styleProps, baseStyles, customizedStyles, propStyles);
      };
      concatenatedStyles.__cachedInputs__ = [
        baseStyles,
        customizedStyles,
        propStyles
      ];
      concatenatedStyles.__noStyleOverride__ = !customizedStyles && !propStyles;
      styles.current = concatenatedStyles;
    }
    return React11.createElement(Component6, __assign({ ref: forwardedRef }, rest, additionalProps, props, { styles: styles.current }));
  });
  Wrapped.displayName = "Styled".concat(Component6.displayName || Component6.name);
  var pureComponent = pure ? React11.memo(Wrapped) : Wrapped;
  if (Wrapped.displayName) {
    pureComponent.displayName = Wrapped.displayName;
  }
  return pureComponent;
}

// node_modules/@fluentui/utilities/lib/warn/warnControlledUsage.js
var warningsMap;
if (true) {
  warningsMap = {
    valueOnChange: {},
    valueDefaultValue: {},
    controlledToUncontrolled: {},
    uncontrolledToControlled: {}
  };
}
function resetControlledWarnings() {
  if (true) {
    warningsMap.valueOnChange = {};
    warningsMap.valueDefaultValue = {};
    warningsMap.controlledToUncontrolled = {};
    warningsMap.uncontrolledToControlled = {};
  }
}
function warnControlledUsage(params) {
  if (true) {
    var componentId = params.componentId, componentName = params.componentName, defaultValueProp = params.defaultValueProp, props = params.props, oldProps = params.oldProps, onChangeProp = params.onChangeProp, readOnlyProp = params.readOnlyProp, valueProp = params.valueProp;
    var oldIsControlled = oldProps ? isControlled(oldProps, valueProp) : void 0;
    var newIsControlled = isControlled(props, valueProp);
    if (newIsControlled) {
      var hasOnChange = !!props[onChangeProp];
      var isReadOnly = !!(readOnlyProp && props[readOnlyProp]);
      if (!(hasOnChange || isReadOnly) && !warningsMap.valueOnChange[componentId]) {
        warningsMap.valueOnChange[componentId] = true;
        warn("Warning: You provided a '".concat(String(valueProp), "' prop to a ").concat(String(componentName), " without an '").concat(String(onChangeProp), "' handler. ") + "This will render a read-only field. If the field should be mutable use '".concat(String(defaultValueProp), "'. ") + "Otherwise, set '".concat(String(onChangeProp), "'").concat(readOnlyProp ? " or '".concat(String(readOnlyProp), "'") : "", "."));
      }
      var defaultValue = props[defaultValueProp];
      if (defaultValue !== void 0 && defaultValue !== null && !warningsMap.valueDefaultValue[componentId]) {
        warningsMap.valueDefaultValue[componentId] = true;
        warn("Warning: You provided both '".concat(String(valueProp), "' and '").concat(String(defaultValueProp), "' to a ").concat(componentName, ". ") + "Form fields must be either controlled or uncontrolled (specify either the '".concat(String(valueProp), "' prop, ") + "or the '".concat(String(defaultValueProp), "' prop, but not both). Decide between using a controlled or uncontrolled ") + "".concat(componentName, " and remove one of these props. More info: https://fb.me/react-controlled-components"));
      }
    }
    if (oldProps && newIsControlled !== oldIsControlled) {
      var oldType = oldIsControlled ? "a controlled" : "an uncontrolled";
      var newType = oldIsControlled ? "uncontrolled" : "controlled";
      var warnMap = oldIsControlled ? warningsMap.controlledToUncontrolled : warningsMap.uncontrolledToControlled;
      if (!warnMap[componentId]) {
        warnMap[componentId] = true;
        warn("Warning: A component is changing ".concat(oldType, " ").concat(componentName, " to be ").concat(newType, ". ") + "".concat(componentName, "s should not switch from controlled to uncontrolled (or vice versa). ") + "Decide between using controlled or uncontrolled for the lifetime of the component. More info: https://fb.me/react-controlled-components");
      }
    }
  }
}

// node_modules/@fluentui/utilities/lib/ie11Detector.js
var isIE11 = function() {
  var _a2;
  var win = getWindow();
  if (!((_a2 = win === null || win === void 0 ? void 0 : win.navigator) === null || _a2 === void 0 ? void 0 : _a2.userAgent)) {
    return false;
  }
  return win.navigator.userAgent.indexOf("rv:11.0") > -1;
};

// node_modules/@fluentui/utilities/lib/getPropsWithDefaults.js
function getPropsWithDefaults(defaultProps, propsWithoutDefaults) {
  var props = __assign({}, propsWithoutDefaults);
  for (var _i = 0, _a2 = Object.keys(defaultProps); _i < _a2.length; _i++) {
    var key = _a2[_i];
    if (props[key] === void 0) {
      props[key] = defaultProps[key];
    }
  }
  return props;
}

// node_modules/@fluentui/utilities/lib/dom/setSSR.js
function setSSR(isEnabled) {
  throw new Error("setSSR has been deprecated and is not used in any utilities anymore. Use canUseDOM from @fluentui/utilities instead.");
}

// node_modules/@fluentui/utilities/lib/createMergedRef.js
var createResolver = function(local) {
  return function(newValue) {
    for (var _i = 0, _a2 = local.refs; _i < _a2.length; _i++) {
      var ref = _a2[_i];
      if (typeof ref === "function") {
        ref(newValue);
      } else if (ref) {
        ref.current = newValue;
      }
    }
  };
};
var createMergedRef = function(value) {
  var local = {
    refs: []
  };
  return function() {
    var newRefs = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      newRefs[_i] = arguments[_i];
    }
    if (!local.resolver || !arraysEqual(local.refs, newRefs)) {
      local.resolver = createResolver(local);
    }
    local.refs = newRefs;
    return local.resolver;
  };
};

// node_modules/@fluentui/utilities/lib/useIsomorphicLayoutEffect.js
var React12 = __toESM(require_react());
var useIsomorphicLayoutEffect = canUseDOM() ? React12.useLayoutEffect : React12.useEffect;

// node_modules/@fluentui/utilities/lib/version.js
setVersion("@fluentui/utilities", "8.13.19");

export {
  canUseDOM,
  getWindow,
  Async,
  shallowCompare,
  assign,
  filteredAssign,
  mapEnumByName,
  values,
  omit,
  EventGroup,
  getDocument,
  DATA_IS_SCROLLABLE_ATTRIBUTE,
  allowScrollOnElement,
  allowOverscrollOnElement,
  disableBodyScroll,
  enableBodyScroll,
  getScrollbarWidth,
  findScrollableParent,
  getRect,
  AutoScroll,
  warn,
  setWarningCallback,
  warnConditionallyRequiredProps,
  warnMutuallyExclusive,
  warnDeprecations,
  BaseComponent,
  nullRender,
  DelayedRender,
  FabricPerformance,
  GlobalSettings,
  KeyCodes,
  Rectangle,
  appendFunction,
  mergeAriaAttributeValues,
  findIndex,
  find,
  createArray,
  toMatrix,
  removeIndex,
  replaceElement,
  addElementAtIndex,
  flatten,
  arraysEqual,
  asAsync,
  assertNever,
  getRTL,
  setRTL2 as setRTL,
  getRTLSafeKeyCode,
  isVirtualElement,
  getVirtualParent,
  getParent,
  elementContains,
  findElementRecursive,
  elementContainsAttribute,
  getChildren,
  DATA_PORTAL_ATTRIBUTE,
  setPortalAttribute,
  portalContainsElement,
  setVirtualParent,
  getFirstFocusable,
  getLastFocusable,
  getFirstTabbable,
  getLastTabbable,
  focusFirstChild,
  getPreviousElement,
  getNextElement,
  isElementVisible,
  isElementVisibleAndNotHidden,
  isElementTabbable,
  isElementFocusZone,
  isElementFocusSubZone,
  doesElementContainFocus,
  shouldWrapFocus,
  focusAsync,
  getFocusableByIndexPath,
  getElementIndexPath,
  getFirstVisibleElementFromSelector,
  on,
  raiseClick,
  classNamesFunction,
  setMemoizeWeakMap,
  resetMemoizations,
  memoize,
  memoizeFunction,
  createMemoizer,
  composeComponentAs,
  isControlled,
  css,
  Customizations,
  CustomizerContext,
  mergeSettings,
  mergeScopedSettings,
  mergeCustomizations,
  Customizer,
  hoistStatics,
  customizable,
  useCustomizationSettings,
  extendComponent,
  getId,
  resetIds,
  baseElementEvents,
  baseElementProperties,
  htmlElementProperties,
  labelProperties,
  audioProperties,
  videoProperties,
  olProperties,
  liProperties,
  anchorProperties,
  buttonProperties,
  inputProperties,
  textAreaProperties,
  selectProperties,
  optionProperties,
  tableProperties,
  trProperties,
  thProperties,
  tdProperties,
  colGroupProperties,
  colProperties,
  formProperties,
  iframeProperties,
  imgProperties,
  imageProperties,
  divProperties,
  getNativeProps,
  getNativeElementProps,
  hoistMethods,
  unhoistMethods,
  initializeComponentRef,
  isDirectionalKeyCode,
  addDirectionalKeyCode,
  removeDirectionalKeyCode,
  IsFocusVisibleClassName,
  setFocusVisibility,
  initializeFocusRects,
  FocusRectsContext,
  useFocusRects,
  FocusRects,
  FocusRectsProvider,
  getInitials,
  getLanguage,
  setLanguage,
  getDistanceBetweenPoints,
  fitContentToBounds,
  calculatePrecision,
  precisionRound,
  merge,
  isIOS,
  modalize,
  isMac,
  hasHorizontalOverflow,
  hasVerticalOverflow,
  hasOverflow,
  composeRenderFunction,
  getResourceUrl,
  setBaseUrl,
  safeRequestAnimationFrame,
  safeSetTimeout,
  SELECTION_CHANGE,
  SelectionMode,
  SelectionDirection,
  Selection,
  format,
  styled,
  resetControlledWarnings,
  warnControlledUsage,
  isIE11,
  getPropsWithDefaults,
  setSSR,
  createMergedRef,
  useIsomorphicLayoutEffect
};
//# sourceMappingURL=chunk-JYWLVXGS.js.map
