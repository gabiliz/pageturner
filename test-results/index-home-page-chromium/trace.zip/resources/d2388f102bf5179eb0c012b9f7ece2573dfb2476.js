import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useFormData } from "/src/shared/hooks/index.ts";
import { OfficesDropdown } from "/src/modules/admin/offices/components/index.ts?t=1701096626433";
import { FlexColumn, TextField } from "/src/shared/components/index.ts?t=1701096626433";
const emptyClient = {
  escritorioId: "",
  nomeFantasia: ""
};
const ClientEditForm = (props) => {
  _s();
  const {
    formData,
    onChange,
    apiError
  } = props;
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange,
    onDropdownChange,
    onFieldError
  } = useFormData(formData ?? emptyClient);
  useEffect(() => {
    if (formData) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData, onChange]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(OfficesDropdown, { label: "Escritório", required: true, selectedKey: localFormData.escritorioId, onChange: onDropdownChange("escritorioId"), errorMessage: apiError?.errors?.messages ? onFieldError("escritorioId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditForm.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome fantasia", required: true, value: localFormData.nomeFantasia, onChange: onTextChange("nomeFantasia"), maxLength: 100, errorMessage: apiError?.errors?.messages ? onFieldError("nomeFantasia", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditForm.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditForm.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(ClientEditForm, "oX7lG8AjmfO12JbeuuiMNzWPStU=", false, function() {
  return [useFormData];
});
_c = ClientEditForm;
export default ClientEditForm;
var _c;
$RefreshReg$(_c, "ClientEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkNOLFNBQWFBLGlCQUFpQjtBQUc5QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFlBQVlDLGlCQUFpQjtBQUV0QyxNQUFNQyxjQUFzQjtBQUFBLEVBQzFCQyxjQUFjO0FBQUEsRUFDZEMsY0FBYztBQUNoQjtBQUVBLE1BQU1DLGlCQUE2Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQzNELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxFQUFTLElBQUlKO0FBRXpDLFFBQU07QUFBQSxJQUNKRSxVQUFVRztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlsQixZQUFvQlUsWUFBWU4sV0FBVztBQUUvQ0wsWUFBVSxNQUFNO0FBQ2QsUUFBSVcsVUFBVTtBQUNaSyx1QkFBaUJMLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYlgsWUFBVSxNQUFNO0FBQ2RZLGVBQVdFLGFBQWE7QUFBQSxFQUMxQixHQUFHLENBQUNBLGVBQWVGLFFBQVEsQ0FBQztBQUU1QixTQUNFLHVCQUFDLGNBQVcsS0FBTSxJQUNoQjtBQUFBLDJCQUFDLG1CQUNDLE9BQU0sY0FDTixVQUFRLE1BQ1IsYUFBYUUsY0FBY1IsY0FDM0IsVUFBVVksaUJBQWlCLGNBQWMsR0FDekMsY0FBY0wsVUFBVU8sUUFBUUMsV0FDNUJGLGFBQWEsZ0JBQWdCTixVQUFVTyxRQUFRQyxRQUFRLElBQ3ZEQyxVQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRRztBQUFBLElBRUgsdUJBQUMsYUFDQyxPQUFNLGlCQUNOLFVBQVEsTUFDUixPQUFPUixjQUFjUCxjQUNyQixVQUFVVSxhQUFhLGNBQWMsR0FDckMsV0FBVyxLQUNYLGNBQWNKLFVBQVVPLFFBQVFDLFdBQzVCRixhQUFhLGdCQUFnQk4sVUFBVU8sUUFBUUMsUUFBUSxJQUN2REMsVUFSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0c7QUFBQSxPQXBCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBO0FBRUo7QUFBQ1osR0E5Q0tGLGdCQUF5QztBQUFBLFVBU3pDUCxXQUFXO0FBQUE7QUFBQXNCLEtBVFhmO0FBZ0ROLGVBQWVBO0FBQWMsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZUZvcm1EYXRhIiwiT2ZmaWNlc0Ryb3Bkb3duIiwiRmxleENvbHVtbiIsIlRleHRGaWVsZCIsImVtcHR5Q2xpZW50IiwiZXNjcml0b3Jpb0lkIiwibm9tZUZhbnRhc2lhIiwiQ2xpZW50RWRpdEZvcm0iLCJwcm9wcyIsIl9zIiwiZm9ybURhdGEiLCJvbkNoYW5nZSIsImFwaUVycm9yIiwibG9jYWxGb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0TG9jYWxGb3JtRGF0YSIsIm9uVGV4dENoYW5nZSIsIm9uRHJvcGRvd25DaGFuZ2UiLCJvbkZpZWxkRXJyb3IiLCJlcnJvcnMiLCJtZXNzYWdlcyIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2xpZW50RWRpdEZvcm0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jbGllbnRzL2NvbXBvbmVudHMvQ2xpZW50RWRpdEZvcm0udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IENsaWVudCBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQ2xpZW50J1xuaW1wb3J0IHsgRWRpdEZvcm1Qcm9wcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC90eXBlcy9FZGl0Rm9ybSdcbmltcG9ydCB7IHVzZUZvcm1EYXRhIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuaW1wb3J0IHsgT2ZmaWNlc0Ryb3Bkb3duIH0gZnJvbSAnLi4vLi4vb2ZmaWNlcy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgRmxleENvbHVtbiwgVGV4dEZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXG5cbmNvbnN0IGVtcHR5Q2xpZW50OiBDbGllbnQgPSB7XG4gIGVzY3JpdG9yaW9JZDogJycsXG4gIG5vbWVGYW50YXNpYTogJycsXG59XG5cbmNvbnN0IENsaWVudEVkaXRGb3JtOiBGQzxFZGl0Rm9ybVByb3BzPENsaWVudD4+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgZm9ybURhdGEsIG9uQ2hhbmdlLCBhcGlFcnJvciB9ID0gcHJvcHNcblxuICBjb25zdCB7XG4gICAgZm9ybURhdGE6IGxvY2FsRm9ybURhdGEsXG4gICAgc2V0Rm9ybURhdGE6IHNldExvY2FsRm9ybURhdGEsXG4gICAgb25UZXh0Q2hhbmdlLFxuICAgIG9uRHJvcGRvd25DaGFuZ2UsXG4gICAgb25GaWVsZEVycm9yLFxuICB9ID0gdXNlRm9ybURhdGE8Q2xpZW50Pihmb3JtRGF0YSA/PyBlbXB0eUNsaWVudClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChmb3JtRGF0YSkge1xuICAgICAgc2V0TG9jYWxGb3JtRGF0YShmb3JtRGF0YSlcbiAgICB9XG4gIH0sIFtmb3JtRGF0YV0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBvbkNoYW5nZT8uKGxvY2FsRm9ybURhdGEpXG4gIH0sIFtsb2NhbEZvcm1EYXRhLCBvbkNoYW5nZV0pXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxuICAgICAgPE9mZmljZXNEcm9wZG93blxuICAgICAgICBsYWJlbD1cIkVzY3JpdMOzcmlvXCJcbiAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgc2VsZWN0ZWRLZXk9e2xvY2FsRm9ybURhdGEuZXNjcml0b3Jpb0lkfVxuICAgICAgICBvbkNoYW5nZT17b25Ecm9wZG93bkNoYW5nZSgnZXNjcml0b3Jpb0lkJyl9XG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignZXNjcml0b3Jpb0lkJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXG4gICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgbGFiZWw9XCJOb21lIGZhbnRhc2lhXCJcbiAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEubm9tZUZhbnRhc2lhfVxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdub21lRmFudGFzaWEnKX1cbiAgICAgICAgbWF4TGVuZ3RoPXsxMDB9XG4gICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignbm9tZUZhbnRhc2lhJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXG4gICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgfVxuICAgICAgLz5cbiAgICA8L0ZsZXhDb2x1bW4+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2xpZW50RWRpdEZvcm1cbiJdfQ==