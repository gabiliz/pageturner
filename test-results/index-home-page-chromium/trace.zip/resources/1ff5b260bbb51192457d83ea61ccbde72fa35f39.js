import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientName.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientName.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { clientQueryService } from "/src/modules/admin/clients/services/index.ts";
const ClientName = ({
  id
}) => {
  _s();
  const {
    data
  } = clientQueryService.useFindOne(id);
  return /* @__PURE__ */ jsxDEV("span", { children: data?.nomeFantasia }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientName.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(ClientName, "SPUSTaH9utC8vSSrVPbkM6DBdis=", false, function() {
  return [clientQueryService.useFindOne];
});
_c = ClientName;
export default ClientName;
var _c;
$RefreshReg$(_c, "ClientName");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientName.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFKVCxTQUFTQSwwQkFBMEI7QUFFbkMsTUFBTUMsYUFBK0JBLENBQUM7QUFBQSxFQUFFQztBQUFHLE1BQU07QUFBQUMsS0FBQTtBQUMvQyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBSyxJQUFJSixtQkFBbUJLLFdBQVdILEVBQUU7QUFDakQsU0FBTyx1QkFBQyxVQUFNRSxnQkFBTUUsZ0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQjtBQUNuQztBQUFDSCxHQUhLRixZQUE0QjtBQUFBLFVBQ2ZELG1CQUFtQkssVUFBVTtBQUFBO0FBQUFFLEtBRDFDTjtBQUtOLGVBQWVBO0FBQVUsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImNsaWVudFF1ZXJ5U2VydmljZSIsIkNsaWVudE5hbWUiLCJpZCIsIl9zIiwiZGF0YSIsInVzZUZpbmRPbmUiLCJub21lRmFudGFzaWEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNsaWVudE5hbWUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jbGllbnRzL2NvbXBvbmVudHMvQ2xpZW50TmFtZS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY2xpZW50UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5cbmNvbnN0IENsaWVudE5hbWU6IEZDPHtpZDogc3RyaW5nfT4gPSAoeyBpZCB9KSA9PiB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gY2xpZW50UXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoaWQpXG4gIHJldHVybiA8c3Bhbj57ZGF0YT8ubm9tZUZhbnRhc2lhfTwvc3Bhbj5cbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2xpZW50TmFtZVxuIl19