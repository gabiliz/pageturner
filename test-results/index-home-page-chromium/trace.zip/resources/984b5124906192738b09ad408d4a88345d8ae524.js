import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/modules/ModulesMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"];
import { IconButton, Panel, PanelType, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { ModuleMenuRoutes } from "/src/routes/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
const ModulesMenu = (props) => {
  _s();
  const {
    isOpen,
    onDismiss
  } = props;
  const theme = useTheme();
  const renderHeader = useCallback(() => {
    return /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
      iconName: "WaffleOffice365"
    }, onClick: onDismiss, styles: {
      root: {
        marginLeft: "24px"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx",
      lineNumber: 19,
      columnNumber: 12
    }, this);
  }, []);
  return /* @__PURE__ */ jsxDEV(Panel, { isOpen, isLightDismiss: true, hasCloseButton: false, onRenderHeader: renderHeader, type: PanelType.customNear, customWidth: "400px", onDismiss, children: /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
    /* @__PURE__ */ jsxDEV(Text, { variant: "mediumPlus", block: true, nowrap: true, styles: {
      root: {
        marginTop: theme.spacing.lg,
        fontWeight: theme.fontWeight.semibold,
        color: theme.colors.primary
      }
    }, children: "Módulos" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ModuleMenuRoutes, { dismissMenu: onDismiss }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx",
      lineNumber: 38,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx",
    lineNumber: 27,
    columnNumber: 10
  }, this);
};
_s(ModulesMenu, "GWW7MDsoqedqnsNG8kPdY44rm3Q=", false, function() {
  return [useTheme];
});
_c = ModulesMenu;
export default ModulesMenu;
var _c;
$RefreshReg$(_c, "ModulesMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JXOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJYLFNBQWFBLG1CQUFtQjtBQUNoQyxTQUFTQyxZQUFZQyxPQUFPQyxXQUFXQyxZQUFZO0FBQ25ELFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsZ0JBQWdCO0FBT3ZCLE1BQU1DLGNBQXFDQyxXQUFVO0FBQUFDLEtBQUE7QUFDbkQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLEVBQVUsSUFBSUg7QUFDOUIsUUFBTUksUUFBUVAsU0FBUztBQUV2QixRQUFNUSxlQUFlZCxZQUFZLE1BQU07QUFDckMsV0FBTyx1QkFBQyxjQUNOLFdBQVc7QUFBQSxNQUFFZSxVQUFVO0FBQUEsSUFBa0IsR0FDekMsU0FBU0gsV0FDVCxRQUFRO0FBQUEsTUFDTkksTUFBTTtBQUFBLFFBQ0pDLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRixLQVBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPSDtBQUFBLEVBRU4sR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxTQUNDLFFBQ0EsZ0JBQWMsTUFDZCxnQkFBZ0IsT0FDaEIsZ0JBQWdCSCxjQUNoQixNQUFNWCxVQUFVZSxZQUNoQixhQUFhLFNBQ2IsV0FFQSxpQ0FBQyxjQUNDO0FBQUEsMkJBQUMsUUFDQyxTQUFRLGNBQ1IsT0FBSyxNQUNMLFFBQU0sTUFDTixRQUFRO0FBQUEsTUFDTkYsTUFBTTtBQUFBLFFBQ0pHLFdBQVdOLE1BQU1PLFFBQVFDO0FBQUFBLFFBQ3pCQyxZQUFZVCxNQUFNUyxXQUFXQztBQUFBQSxRQUM3QkMsT0FBT1gsTUFBTVksT0FBT0M7QUFBQUEsTUFDdEI7QUFBQSxJQUNGLEdBQUUsdUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFDQSx1QkFBQyxvQkFDQyxhQUFhZCxhQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDeUI7QUFBQSxPQWhCM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBRUo7QUFBQ0YsR0EvQ0tGLGFBQWlDO0FBQUEsVUFFdkJGLFFBQVE7QUFBQTtBQUFBcUIsS0FGbEJuQjtBQWlETixlQUFlQTtBQUFXLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJJY29uQnV0dG9uIiwiUGFuZWwiLCJQYW5lbFR5cGUiLCJUZXh0IiwiTW9kdWxlTWVudVJvdXRlcyIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIk1vZHVsZXNNZW51IiwicHJvcHMiLCJfcyIsImlzT3BlbiIsIm9uRGlzbWlzcyIsInRoZW1lIiwicmVuZGVySGVhZGVyIiwiaWNvbk5hbWUiLCJyb290IiwibWFyZ2luTGVmdCIsImN1c3RvbU5lYXIiLCJtYXJnaW5Ub3AiLCJzcGFjaW5nIiwibGciLCJmb250V2VpZ2h0Iiwic2VtaWJvbGQiLCJjb2xvciIsImNvbG9ycyIsInByaW1hcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1vZHVsZXNNZW51LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL21vZHVsZXMvTW9kdWxlc01lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBJY29uQnV0dG9uLCBQYW5lbCwgUGFuZWxUeXBlLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgTW9kdWxlTWVudVJvdXRlcyB9IGZyb20gJy4uLy4uLy4uL3JvdXRlcydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5pbXBvcnQgRmxleENvbHVtbiBmcm9tICcuLy4uL0ZsZXhCb3gvRmxleENvbHVtbidcblxuZXhwb3J0IGludGVyZmFjZSBNb2R1bGVzTWVudVByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuLFxuICBvbkRpc21pc3M6ICgpID0+IHZvaWQsXG59XG5cbmNvbnN0IE1vZHVsZXNNZW51OiBGQzxNb2R1bGVzTWVudVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGlzT3Blbiwgb25EaXNtaXNzIH0gPSBwcm9wc1xuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcblxuICBjb25zdCByZW5kZXJIZWFkZXIgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgcmV0dXJuIDxJY29uQnV0dG9uXG4gICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdXYWZmbGVPZmZpY2UzNjUnIH19XG4gICAgICBvbkNsaWNrPXtvbkRpc21pc3N9XG4gICAgICBzdHlsZXM9e3tcbiAgICAgICAgcm9vdDoge1xuICAgICAgICAgIG1hcmdpbkxlZnQ6ICcyNHB4JyxcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgLz5cbiAgfSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8UGFuZWxcbiAgICAgIGlzT3Blbj17aXNPcGVufVxuICAgICAgaXNMaWdodERpc21pc3NcbiAgICAgIGhhc0Nsb3NlQnV0dG9uPXtmYWxzZX1cbiAgICAgIG9uUmVuZGVySGVhZGVyPXtyZW5kZXJIZWFkZXJ9XG4gICAgICB0eXBlPXtQYW5lbFR5cGUuY3VzdG9tTmVhcn1cbiAgICAgIGN1c3RvbVdpZHRoPXsnNDAwcHgnfVxuICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XG4gICAgPlxuICAgICAgPEZsZXhDb2x1bW4+XG4gICAgICAgIDxUZXh0XG4gICAgICAgICAgdmFyaWFudD1cIm1lZGl1bVBsdXNcIlxuICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgbm93cmFwXG4gICAgICAgICAgc3R5bGVzPXt7XG4gICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZy5sZyxcbiAgICAgICAgICAgICAgZm9udFdlaWdodDogdGhlbWUuZm9udFdlaWdodC5zZW1pYm9sZCxcbiAgICAgICAgICAgICAgY29sb3I6IHRoZW1lLmNvbG9ycy5wcmltYXJ5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgTcOzZHVsb3NcbiAgICAgICAgPC9UZXh0PlxuICAgICAgICA8TW9kdWxlTWVudVJvdXRlc1xuICAgICAgICAgIGRpc21pc3NNZW51PXtvbkRpc21pc3N9XG4gICAgICAgIC8+XG4gICAgICA8L0ZsZXhDb2x1bW4+XG4gICAgPC9QYW5lbD5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBNb2R1bGVzTWVudVxuIl19