import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/offices/components/OfficesDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficesDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { officeService } from "/src/modules/admin/offices/services/index.ts";
const OfficesDropdown = (props) => {
  _s();
  const {
    selectedKeys,
    multiSelect = false,
    selectedKey,
    disabled = false,
    styles
  } = props;
  const [offices, setOffices] = useState([]);
  const getAllOffices = useCallback(async () => {
    const data = await officeService.findQuery();
    setOffices(data);
  }, [setOffices]);
  useEffect(() => {
    getAllOffices();
  }, []);
  const options = useMemo(() => offices.map((office) => ({
    key: office.id,
    text: office.nome
  })) ?? [], [offices]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { multiSelect, allowFreeform: true, autoComplete: "on", options, selectedKey: multiSelect ? selectedKeys : selectedKey, disabled, styles, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficesDropdown.tsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(OfficesDropdown, "eMUJgnTgLkeWM0PcDZ9NY2eIQUI=");
_c = OfficesDropdown;
export default OfficesDropdown;
var _c;
$RefreshReg$(_c, "OfficesDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficesDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NJOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkNKLFNBQWFBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUU5RCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MscUJBQXFCO0FBVTlCLE1BQU1DLGtCQUFvQ0EsQ0FBQ0MsVUFBd0I7QUFBQUMsS0FBQTtBQUNqRSxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUMsY0FBYztBQUFBLElBQ2RDO0FBQUFBLElBQ0FDLFdBQVc7QUFBQSxJQUNYQztBQUFBQSxFQUNGLElBQUlOO0FBQ0osUUFBTSxDQUFDTyxTQUFTQyxVQUFVLElBQUlaLFNBQW1CLEVBQUU7QUFDbkQsUUFBTWEsZ0JBQWdCaEIsWUFBWSxZQUFZO0FBQzVDLFVBQU1pQixPQUFPLE1BQU1aLGNBQWNhLFVBQVU7QUFDM0NILGVBQVdFLElBQUk7QUFBQSxFQUNqQixHQUFHLENBQUNGLFVBQVUsQ0FBQztBQUVmZCxZQUFVLE1BQU07QUFDZGUsa0JBQWM7QUFBQSxFQUNoQixHQUFHLEVBQUU7QUFDTCxRQUFNRyxVQUFVakIsUUFDZCxNQUFNWSxRQUFRTSxJQUFJQyxhQUFXO0FBQUEsSUFDM0JDLEtBQUtELE9BQU9FO0FBQUFBLElBQ1pDLE1BQU1ILE9BQU9JO0FBQUFBLEVBQ2YsRUFBRSxLQUFLLElBQ1AsQ0FBQ1gsT0FBTyxDQUNWO0FBRUEsU0FDRSx1QkFBQyxZQUNDLGFBQ0EsZUFBZSxNQUNmLGNBQWEsTUFDYixTQUNBLGFBQWFKLGNBQWNELGVBQWVFLGFBQzFDLFVBQ0EsUUFDQSxHQUFJSixTQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRWTtBQUdoQjtBQUFDQyxHQXJDS0YsaUJBQWlDO0FBQUFvQixLQUFqQ3BCO0FBdUNOLGVBQWVBO0FBQWUsSUFBQW9CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIkNvbWJvQm94Iiwib2ZmaWNlU2VydmljZSIsIk9mZmljZXNEcm9wZG93biIsInByb3BzIiwiX3MiLCJzZWxlY3RlZEtleXMiLCJtdWx0aVNlbGVjdCIsInNlbGVjdGVkS2V5IiwiZGlzYWJsZWQiLCJzdHlsZXMiLCJvZmZpY2VzIiwic2V0T2ZmaWNlcyIsImdldEFsbE9mZmljZXMiLCJkYXRhIiwiZmluZFF1ZXJ5Iiwib3B0aW9ucyIsIm1hcCIsIm9mZmljZSIsImtleSIsImlkIiwidGV4dCIsIm5vbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk9mZmljZXNEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL29mZmljZXMvY29tcG9uZW50cy9PZmZpY2VzRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbWJvQm94T3B0aW9uLCBJQ29tYm9Cb3hQcm9wcywgSUNvbWJvQm94U3R5bGVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgT2ZmaWNlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9PZmZpY2UnXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgb2ZmaWNlU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xuXG5pbnRlcmZhY2UgT2ZmaWNlc1Byb3BzIGV4dGVuZHMgUGFydGlhbDxJQ29tYm9Cb3hQcm9wcz4ge1xuICBzZWxlY3RlZEtleXM/OiBzdHJpbmdbXVxuICBzZWxlY3RlZEtleT86IHN0cmluZyB8IG51bGxcbiAgbXVsdGlTZWxlY3Q/OiBib29sZWFuXG4gIGRpc2FibGVkPzogYm9vbGVhblxuICBzdHlsZXM/OiBQYXJ0aWFsPElDb21ib0JveFN0eWxlcz5cbn1cblxuY29uc3QgT2ZmaWNlc0Ryb3Bkb3duOiBGQzxPZmZpY2VzUHJvcHM+ID0gKHByb3BzOiBPZmZpY2VzUHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIHNlbGVjdGVkS2V5cyxcbiAgICBtdWx0aVNlbGVjdCA9IGZhbHNlLFxuICAgIHNlbGVjdGVkS2V5LFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgc3R5bGVzLFxuICB9ID0gcHJvcHNcbiAgY29uc3QgW29mZmljZXMsIHNldE9mZmljZXNdID0gdXNlU3RhdGU8T2ZmaWNlW10+KFtdKVxuICBjb25zdCBnZXRBbGxPZmZpY2VzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBvZmZpY2VTZXJ2aWNlLmZpbmRRdWVyeSgpXG4gICAgc2V0T2ZmaWNlcyhkYXRhKVxuICB9LCBbc2V0T2ZmaWNlc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBnZXRBbGxPZmZpY2VzKClcbiAgfSwgW10pXG4gIGNvbnN0IG9wdGlvbnMgPSB1c2VNZW1vPElDb21ib0JveE9wdGlvbltdPihcbiAgICAoKSA9PiBvZmZpY2VzLm1hcChvZmZpY2UgPT4gKHtcbiAgICAgIGtleTogb2ZmaWNlLmlkIGFzIHN0cmluZyxcbiAgICAgIHRleHQ6IG9mZmljZS5ub21lLFxuICAgIH0pKSA/PyBbXSxcbiAgICBbb2ZmaWNlc10sXG4gIClcblxuICByZXR1cm4gKFxuICAgIDxDb21ib0JveFxuICAgICAgbXVsdGlTZWxlY3Q9e211bHRpU2VsZWN0fVxuICAgICAgYWxsb3dGcmVlZm9ybT17dHJ1ZX1cbiAgICAgIGF1dG9Db21wbGV0ZT0nb24nXG4gICAgICBvcHRpb25zPXtvcHRpb25zfVxuICAgICAgc2VsZWN0ZWRLZXk9e211bHRpU2VsZWN0ID8gc2VsZWN0ZWRLZXlzIDogc2VsZWN0ZWRLZXl9XG4gICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICBzdHlsZXM9e3N0eWxlc31cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE9mZmljZXNEcm9wZG93blxuIl19