import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileDetails.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Label, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { Tree } from "/node_modules/.vite/deps/primereact_tree.js?v=9f90a7ff";
import { permissionService } from "/src/modules/admin/profiles/services/index.ts";
import { FlexColumn, FlexItem } from "/src/shared/components/index.ts?t=1701096626433";
const ProfileDetails = (props) => {
  _s();
  const {
    data
  } = props;
  const {
    data: permissionModules
  } = permissionService.useFindAllPaginated();
  const permissionsTree = useMemo(() => {
    if (permissionModules) {
      return makeTree(data.permissoes?.map((permission) => {
        return permission.permissao;
      }), permissionModules);
    }
    return [];
  }, [data, permissionModules]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nome" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.nome }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Descrição" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.descricao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Text, { variant: "xLarge", children: "Permissões " }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Tree, { value: permissionsTree, selectionKeys: {
        ".": {
          checked: true
        }
      }, selectionMode: "checkbox" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
};
_s(ProfileDetails, "cXiFrapQJItAPyIsI0XTHuAO7xI=", false, function() {
  return [permissionService.useFindAllPaginated];
});
_c = ProfileDetails;
function makeTree(profilePermissions, permissionModules) {
  return permissionModules.reduce((modules, module) => {
    const foundServices = module.servicos.reduce((services, service) => {
      const foundPermissions = service.regras.reduce((permissions, permission) => {
        if (profilePermissions.some(({
          codigo,
          permissao
        }) => permission.codigo === codigo && permission.permissao === permissao)) {
          return [...permissions, {
            key: ".",
            // TODO
            label: permission.permissao.charAt(0).concat(permission.permissao.slice(1).toLocaleLowerCase())
          }];
        }
        return permissions;
      }, []);
      if (foundPermissions.length) {
        return [...services, {
          key: service.servico,
          label: service.descricao?.charAt(0).concat(service.descricao.slice(1).toLocaleLowerCase()),
          children: foundPermissions,
          selectable: false
        }];
      }
      return services;
    }, []);
    if (foundServices.length) {
      return [...modules, {
        key: module.modulo,
        label: module.modulo.charAt(0).concat(module.modulo.slice(1).toLocaleLowerCase()),
        children: foundServices,
        selectable: false
      }];
    }
    return modules;
  }, []);
}
export default ProfileDetails;
var _c;
$RefreshReg$(_c, "ProfileDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7O0FBN0JSLFNBQWFBLGVBQWU7QUFDNUIsU0FBU0MsT0FBT0MsWUFBWTtBQUM1QixTQUFTQyxZQUFtQztBQUs1QyxTQUFTQyx5QkFBeUI7QUFHbEMsU0FBU0MsWUFBWUMsZ0JBQWdCO0FBRXJDLE1BQU1DLGlCQUFzREMsV0FBVTtBQUFBQyxLQUFBO0FBQ3BFLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFLLElBQUlGO0FBRWpCLFFBQU07QUFBQSxJQUFFRSxNQUFNQztBQUFBQSxFQUFrQixJQUFJUCxrQkFBa0JRLG9CQUFvQjtBQUUxRSxRQUFNQyxrQkFBa0JiLFFBQW9CLE1BQU07QUFDaEQsUUFBSVcsbUJBQW1CO0FBQ3JCLGFBQU9HLFNBQVNKLEtBQUtLLFlBQ2pCQyxJQUFLQyxnQkFBZTtBQUFFLGVBQU9BLFdBQVdDO0FBQUFBLE1BQXdCLENBQUMsR0FBR1AsaUJBQWlCO0FBQUEsSUFDM0Y7QUFFQSxXQUFPO0FBQUEsRUFDVCxHQUFHLENBQUNELE1BQU1DLGlCQUFpQixDQUFDO0FBRTVCLFNBQ0UsdUJBQUMsY0FBVyxLQUFNLElBQ2hCO0FBQUEsMkJBQUMsWUFDQztBQUFBLDZCQUFDLFNBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDWCx1QkFBQyxRQUFNRCxlQUFLUyxRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxTQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxTQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0I7QUFBQSxNQUNoQix1QkFBQyxRQUFNVCxlQUFLVSxhQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxTQUZ4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxRQUFLLFNBQVEsVUFBUywyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLFFBQ0MsT0FBT1AsaUJBQ1AsZUFBZ0I7QUFBQSxRQUNkLEtBQUs7QUFBQSxVQUNIUSxTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsR0FDQSxlQUFjLGNBUGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPMEI7QUFBQSxTQVQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ1osR0F0Q0tGLGdCQUFrRDtBQUFBLFVBR2xCSCxrQkFBa0JRLG1CQUFtQjtBQUFBO0FBQUFVLEtBSHJFZjtBQXdDTixTQUFTTyxTQUFVUyxvQkFBa0NaLG1CQUF1QztBQUMxRixTQUFPQSxrQkFBa0JhLE9BQU8sQ0FBQ0MsU0FBU0MsV0FBVztBQUNuRCxVQUFNQyxnQkFBZ0JELE9BQU9FLFNBQVNKLE9BQU8sQ0FBQ0ssVUFBVUMsWUFBWTtBQUNsRSxZQUFNQyxtQkFBbUJELFFBQVFFLE9BQU9SLE9BQU8sQ0FBQ1MsYUFBYWhCLGVBQWU7QUFDMUUsWUFBSU0sbUJBQW1CVyxLQUNyQixDQUFDO0FBQUEsVUFBRUM7QUFBQUEsVUFBUWpCO0FBQUFBLFFBQVUsTUFDbkJELFdBQVdrQixXQUFXQSxVQUN0QmxCLFdBQVdDLGNBQWNBLFNBRTdCLEdBQUc7QUFDRCxpQkFBTyxDQUNMLEdBQUdlLGFBQ0g7QUFBQSxZQUNFRyxLQUFLO0FBQUE7QUFBQSxZQUNMQyxPQUFPcEIsV0FBV0MsVUFBVW9CLE9BQU8sQ0FBQyxFQUFFQyxPQUFPdEIsV0FBV0MsVUFBVXNCLE1BQU0sQ0FBQyxFQUFFQyxrQkFBa0IsQ0FBQztBQUFBLFVBQ2hHLENBQUM7QUFBQSxRQUVMO0FBQ0EsZUFBT1I7QUFBQUEsTUFDVCxHQUFHLEVBQWdCO0FBRW5CLFVBQUlGLGlCQUFpQlcsUUFBUTtBQUMzQixlQUFPLENBQ0wsR0FBR2IsVUFDSDtBQUFBLFVBQ0VPLEtBQUtOLFFBQVFhO0FBQUFBLFVBQ2JOLE9BQU9QLFFBQVFWLFdBQVdrQixPQUFPLENBQUMsRUFBRUMsT0FBT1QsUUFBUVYsVUFBVW9CLE1BQU0sQ0FBQyxFQUFFQyxrQkFBa0IsQ0FBQztBQUFBLFVBQ3pGRyxVQUFVYjtBQUFBQSxVQUNWYyxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFFTDtBQUNBLGFBQU9oQjtBQUFBQSxJQUNULEdBQUcsRUFBZ0I7QUFFbkIsUUFBSUYsY0FBY2UsUUFBUTtBQUN4QixhQUFPLENBQ0wsR0FBR2pCLFNBQ0g7QUFBQSxRQUNFVyxLQUFLVixPQUFPb0I7QUFBQUEsUUFDWlQsT0FBT1gsT0FBT29CLE9BQU9SLE9BQU8sQ0FBQyxFQUFFQyxPQUFPYixPQUFPb0IsT0FBT04sTUFBTSxDQUFDLEVBQUVDLGtCQUFrQixDQUFDO0FBQUEsUUFDaEZHLFVBQVVqQjtBQUFBQSxRQUNWa0IsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBRUw7QUFDQSxXQUFPcEI7QUFBQUEsRUFDVCxHQUFHLEVBQWdCO0FBQ3JCO0FBRUEsZUFBZWxCO0FBQWMsSUFBQWU7QUFBQXlCLGFBQUF6QixJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIkxhYmVsIiwiVGV4dCIsIlRyZWUiLCJwZXJtaXNzaW9uU2VydmljZSIsIkZsZXhDb2x1bW4iLCJGbGV4SXRlbSIsIlByb2ZpbGVEZXRhaWxzIiwicHJvcHMiLCJfcyIsImRhdGEiLCJwZXJtaXNzaW9uTW9kdWxlcyIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCJwZXJtaXNzaW9uc1RyZWUiLCJtYWtlVHJlZSIsInBlcm1pc3NvZXMiLCJtYXAiLCJwZXJtaXNzaW9uIiwicGVybWlzc2FvIiwibm9tZSIsImRlc2NyaWNhbyIsImNoZWNrZWQiLCJfYyIsInByb2ZpbGVQZXJtaXNzaW9ucyIsInJlZHVjZSIsIm1vZHVsZXMiLCJtb2R1bGUiLCJmb3VuZFNlcnZpY2VzIiwic2Vydmljb3MiLCJzZXJ2aWNlcyIsInNlcnZpY2UiLCJmb3VuZFBlcm1pc3Npb25zIiwicmVncmFzIiwicGVybWlzc2lvbnMiLCJzb21lIiwiY29kaWdvIiwia2V5IiwibGFiZWwiLCJjaGFyQXQiLCJjb25jYXQiLCJzbGljZSIsInRvTG9jYWxlTG93ZXJDYXNlIiwibGVuZ3RoIiwic2VydmljbyIsImNoaWxkcmVuIiwic2VsZWN0YWJsZSIsIm1vZHVsbyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2ZpbGVEZXRhaWxzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vcHJvZmlsZXMvY29tcG9uZW50cy9Qcm9maWxlRGV0YWlscy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMYWJlbCwgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgVHJlZSwgVHJlZVNlbGVjdGlvbktleXNUeXBlIH0gZnJvbSAncHJpbWVyZWFjdC90cmVlJ1xyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLXVucmVzb2x2ZWRcclxuaW1wb3J0IFRyZWVOb2RlIGZyb20gJ3ByaW1lcmVhY3QvdHJlZW5vZGUnXHJcbmltcG9ydCBQcm9maWxlUXVlcnkgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1Byb2ZpbGVRdWVyeSdcclxuaW1wb3J0IHsgRGV0YWlsc1ZpZXdQcm9wcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC90eXBlcy9EZXRhaWxzVmlldydcclxuaW1wb3J0IHsgcGVybWlzc2lvblNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuaW1wb3J0IFBlcm1pc3Npb25Nb2R1bGUgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1Blcm1pc3Npb25Nb2R1bGUnXHJcbmltcG9ydCBQZXJtaXNzaW9uIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9QZXJtaXNzaW9uJ1xyXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBGbGV4SXRlbSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5cclxuY29uc3QgUHJvZmlsZURldGFpbHM6IEZDPERldGFpbHNWaWV3UHJvcHM8UHJvZmlsZVF1ZXJ5Pj4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IGRhdGEgfSA9IHByb3BzXHJcblxyXG4gIGNvbnN0IHsgZGF0YTogcGVybWlzc2lvbk1vZHVsZXMgfSA9IHBlcm1pc3Npb25TZXJ2aWNlLnVzZUZpbmRBbGxQYWdpbmF0ZWQoKVxyXG5cclxuICBjb25zdCBwZXJtaXNzaW9uc1RyZWUgPSB1c2VNZW1vPFRyZWVOb2RlW10+KCgpID0+IHtcclxuICAgIGlmIChwZXJtaXNzaW9uTW9kdWxlcykge1xyXG4gICAgICByZXR1cm4gbWFrZVRyZWUoZGF0YS5wZXJtaXNzb2VzXHJcbiAgICAgICAgPy5tYXAoKHBlcm1pc3Npb24pID0+IHsgcmV0dXJuIHBlcm1pc3Npb24ucGVybWlzc2FvIGFzIFBlcm1pc3Npb24gfSksIHBlcm1pc3Npb25Nb2R1bGVzKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBbXVxyXG4gIH0sIFtkYXRhLCBwZXJtaXNzaW9uTW9kdWxlc10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxyXG4gICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgPExhYmVsPk5vbWU8L0xhYmVsPlxyXG4gICAgICAgIDxUZXh0PntkYXRhLm5vbWV9PC9UZXh0PlxyXG4gICAgICA8L0ZsZXhJdGVtPlxyXG4gICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgPExhYmVsPkRlc2NyacOnw6NvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dD57ZGF0YS5kZXNjcmljYW99PC9UZXh0PlxyXG4gICAgICA8L0ZsZXhJdGVtPlxyXG4gICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgPFRleHQgdmFyaWFudD1cInhMYXJnZVwiPlBlcm1pc3PDtWVzIDwvVGV4dD5cclxuICAgICAgICA8VHJlZVxyXG4gICAgICAgICAgdmFsdWU9e3Blcm1pc3Npb25zVHJlZX1cclxuICAgICAgICAgIHNlbGVjdGlvbktleXM9eyB7XHJcbiAgICAgICAgICAgICcuJzoge1xyXG4gICAgICAgICAgICAgIGNoZWNrZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9IGFzIHVua25vd24gYXMgVHJlZVNlbGVjdGlvbktleXNUeXBlfVxyXG4gICAgICAgICAgc2VsZWN0aW9uTW9kZT0nY2hlY2tib3gnXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9GbGV4SXRlbT5cclxuICAgIDwvIEZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYWtlVHJlZSAocHJvZmlsZVBlcm1pc3Npb25zOiBQZXJtaXNzaW9uW10sIHBlcm1pc3Npb25Nb2R1bGVzOiBQZXJtaXNzaW9uTW9kdWxlW10pIHtcclxuICByZXR1cm4gcGVybWlzc2lvbk1vZHVsZXMucmVkdWNlKChtb2R1bGVzLCBtb2R1bGUpID0+IHtcclxuICAgIGNvbnN0IGZvdW5kU2VydmljZXMgPSBtb2R1bGUuc2Vydmljb3MucmVkdWNlKChzZXJ2aWNlcywgc2VydmljZSkgPT4ge1xyXG4gICAgICBjb25zdCBmb3VuZFBlcm1pc3Npb25zID0gc2VydmljZS5yZWdyYXMucmVkdWNlKChwZXJtaXNzaW9ucywgcGVybWlzc2lvbikgPT4ge1xyXG4gICAgICAgIGlmIChwcm9maWxlUGVybWlzc2lvbnMuc29tZShcclxuICAgICAgICAgICh7IGNvZGlnbywgcGVybWlzc2FvIH0pID0+IChcclxuICAgICAgICAgICAgcGVybWlzc2lvbi5jb2RpZ28gPT09IGNvZGlnbyAmJlxyXG4gICAgICAgICAgICBwZXJtaXNzaW9uLnBlcm1pc3NhbyA9PT0gcGVybWlzc2FvXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICkpIHtcclxuICAgICAgICAgIHJldHVybiBbXHJcbiAgICAgICAgICAgIC4uLnBlcm1pc3Npb25zLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAga2V5OiAnLicsIC8vIFRPRE9cclxuICAgICAgICAgICAgICBsYWJlbDogcGVybWlzc2lvbi5wZXJtaXNzYW8uY2hhckF0KDApLmNvbmNhdChwZXJtaXNzaW9uLnBlcm1pc3Nhby5zbGljZSgxKS50b0xvY2FsZUxvd2VyQ2FzZSgpKSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHBlcm1pc3Npb25zXHJcbiAgICAgIH0sIFtdIGFzIFRyZWVOb2RlW10pXHJcblxyXG4gICAgICBpZiAoZm91bmRQZXJtaXNzaW9ucy5sZW5ndGgpIHtcclxuICAgICAgICByZXR1cm4gW1xyXG4gICAgICAgICAgLi4uc2VydmljZXMsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogc2VydmljZS5zZXJ2aWNvLFxyXG4gICAgICAgICAgICBsYWJlbDogc2VydmljZS5kZXNjcmljYW8/LmNoYXJBdCgwKS5jb25jYXQoc2VydmljZS5kZXNjcmljYW8uc2xpY2UoMSkudG9Mb2NhbGVMb3dlckNhc2UoKSksXHJcbiAgICAgICAgICAgIGNoaWxkcmVuOiBmb3VuZFBlcm1pc3Npb25zLFxyXG4gICAgICAgICAgICBzZWxlY3RhYmxlOiBmYWxzZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBzZXJ2aWNlc1xyXG4gICAgfSwgW10gYXMgVHJlZU5vZGVbXSlcclxuXHJcbiAgICBpZiAoZm91bmRTZXJ2aWNlcy5sZW5ndGgpIHtcclxuICAgICAgcmV0dXJuIFtcclxuICAgICAgICAuLi5tb2R1bGVzLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGtleTogbW9kdWxlLm1vZHVsbyxcclxuICAgICAgICAgIGxhYmVsOiBtb2R1bGUubW9kdWxvLmNoYXJBdCgwKS5jb25jYXQobW9kdWxlLm1vZHVsby5zbGljZSgxKS50b0xvY2FsZUxvd2VyQ2FzZSgpKSxcclxuICAgICAgICAgIGNoaWxkcmVuOiBmb3VuZFNlcnZpY2VzLFxyXG4gICAgICAgICAgc2VsZWN0YWJsZTogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgXVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIG1vZHVsZXNcclxuICB9LCBbXSBhcyBUcmVlTm9kZVtdKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9maWxlRGV0YWlsc1xyXG4iXX0=