import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/ChangePasswordSuccessPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ChangePasswordSuccessPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ChangePasswordSuccess } from "/src/modules/auth/components/index.ts?t=1701096626433";
import AuthPageBoilerplate from "/src/modules/auth/pages/AuthPageBoilerplate.tsx?t=1701096626433";
const ChangePasswordSuccessPage = () => {
  return /* @__PURE__ */ jsxDEV(AuthPageBoilerplate, { children: /* @__PURE__ */ jsxDEV(ChangePasswordSuccess, { title: "Senha alterada com sucesso", subtitle: "A sua senha foi alterada. Efetue o login com a nova senha" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ChangePasswordSuccessPage.tsx",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ChangePasswordSuccessPage.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = ChangePasswordSuccessPage;
export default ChangePasswordSuccessPage;
var _c;
$RefreshReg$(_c, "ChangePasswordSuccessPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ChangePasswordSuccessPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTiwyQkFBU0E7QUFBNkI7QUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVyRCxPQUFPQyx5QkFBeUI7QUFFaEMsTUFBTUMsNEJBQWdDQSxNQUFNO0FBQzFDLFNBQ0UsdUJBQUMsdUJBQ0MsaUNBQUMseUJBQ0MsT0FBTSw4QkFDTixVQUFTLCtEQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFc0UsS0FIeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0MsS0FUS0Q7QUFXTixlQUFlQTtBQUF5QixJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ2hhbmdlUGFzc3dvcmRTdWNjZXNzIiwiQXV0aFBhZ2VCb2lsZXJwbGF0ZSIsIkNoYW5nZVBhc3N3b3JkU3VjY2Vzc1BhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNoYW5nZVBhc3N3b3JkU3VjY2Vzc1BhZ2UudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdXRoL3BhZ2VzL0NoYW5nZVBhc3N3b3JkU3VjY2Vzc1BhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2hhbmdlUGFzc3dvcmRTdWNjZXNzIH0gZnJvbSAnLi4vY29tcG9uZW50cydcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQXV0aFBhZ2VCb2lsZXJwbGF0ZSBmcm9tICcuL0F1dGhQYWdlQm9pbGVycGxhdGUnXG5cbmNvbnN0IENoYW5nZVBhc3N3b3JkU3VjY2Vzc1BhZ2U6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxBdXRoUGFnZUJvaWxlcnBsYXRlID5cbiAgICAgIDxDaGFuZ2VQYXNzd29yZFN1Y2Nlc3NcbiAgICAgICAgdGl0bGU9J1NlbmhhIGFsdGVyYWRhIGNvbSBzdWNlc3NvJ1xuICAgICAgICBzdWJ0aXRsZT0nQSBzdWEgc2VuaGEgZm9pIGFsdGVyYWRhLiBFZmV0dWUgbyBsb2dpbiBjb20gYSBub3ZhIHNlbmhhJ1xuICAgICAgLz5cbiAgICA8LyBBdXRoUGFnZUJvaWxlcnBsYXRlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IENoYW5nZVBhc3N3b3JkU3VjY2Vzc1BhZ2VcbiJdfQ==