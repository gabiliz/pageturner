import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfilesDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfilesDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { profileQueryService as service } from "/src/modules/admin/profiles/services/index.ts";
const ProfileDropdown = (props) => {
  _s();
  const {
    styles
  } = props;
  const {
    data
  } = service.useFindAllPaginated();
  const options = useMemo(() => data?.value.map((profile) => ({
    key: profile.id,
    text: profile.nome
  })) ?? [], [data]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { allowFreeform: true, autoComplete: "on", options, styles, calloutProps: {
    calloutMinWidth: 80
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfilesDropdown.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(ProfileDropdown, "NSJ1gXFGWIyWJXFNGs+sZgixTAk=", false, function() {
  return [service.useFindAllPaginated];
});
_c = ProfileDropdown;
export default ProfileDropdown;
var _c;
$RefreshReg$(_c, "ProfileDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfilesDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEJKLFNBQWFBLGVBQWU7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHVCQUF1QkMsZUFBZTtBQU0vQyxNQUFNQyxrQkFBNENBLENBQUNDLFVBQWdDO0FBQUFDLEtBQUE7QUFDakYsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSUY7QUFFbkIsUUFBTTtBQUFBLElBQUVHO0FBQUFBLEVBQUssSUFBSUwsUUFBUU0sb0JBQW9CO0FBRTdDLFFBQU1DLFVBQVVWLFFBQ2QsTUFBTVEsTUFBTUcsTUFBTUMsSUFBSUMsY0FBWTtBQUFBLElBQ2hDQyxLQUFLRCxRQUFRRTtBQUFBQSxJQUNiQyxNQUFNSCxRQUFRSTtBQUFBQSxFQUNoQixFQUFFLEtBQUssSUFDUCxDQUFDVCxJQUFJLENBQ1A7QUFFQSxTQUNFLHVCQUFDLFlBQ0MsZUFBZSxNQUNmLGNBQWEsTUFDYixTQUNBLFFBQ0EsY0FBYztBQUFBLElBQ1pVLGlCQUFpQjtBQUFBLEVBQ25CLEdBQ0EsR0FBSWIsU0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUVk7QUFHaEI7QUFBQ0MsR0F6QktGLGlCQUF5QztBQUFBLFVBRzVCRCxRQUFRTSxtQkFBbUI7QUFBQTtBQUFBVSxLQUh4Q2Y7QUEyQk4sZUFBZUE7QUFBZSxJQUFBZTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIkNvbWJvQm94IiwicHJvZmlsZVF1ZXJ5U2VydmljZSIsInNlcnZpY2UiLCJQcm9maWxlRHJvcGRvd24iLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwiZGF0YSIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCJvcHRpb25zIiwidmFsdWUiLCJtYXAiLCJwcm9maWxlIiwia2V5IiwiaWQiLCJ0ZXh0Iiwibm9tZSIsImNhbGxvdXRNaW5XaWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvZmlsZXNEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3Byb2ZpbGVzL2NvbXBvbmVudHMvUHJvZmlsZXNEcm9wZG93bi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJQ29tYm9Cb3hPcHRpb24sIElDb21ib0JveFByb3BzLCBJQ29tYm9Cb3hTdHlsZXMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IENvbWJvQm94IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IHByb2ZpbGVRdWVyeVNlcnZpY2UgYXMgc2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xyXG5cclxuaW50ZXJmYWNlIFByb2ZpbGVEcm9wZG93blByb3BzIGV4dGVuZHMgUGFydGlhbDxJQ29tYm9Cb3hQcm9wcz4ge1xyXG4gIHN0eWxlcz86IFBhcnRpYWw8SUNvbWJvQm94U3R5bGVzPlxyXG59XHJcblxyXG5jb25zdCBQcm9maWxlRHJvcGRvd246IEZDPFByb2ZpbGVEcm9wZG93blByb3BzPiA9IChwcm9wczogUHJvZmlsZURyb3Bkb3duUHJvcHMpID0+IHtcclxuICBjb25zdCB7IHN0eWxlcyB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgeyBkYXRhIH0gPSBzZXJ2aWNlLnVzZUZpbmRBbGxQYWdpbmF0ZWQoKVxyXG5cclxuICBjb25zdCBvcHRpb25zID0gdXNlTWVtbzxJQ29tYm9Cb3hPcHRpb25bXT4oXHJcbiAgICAoKSA9PiBkYXRhPy52YWx1ZS5tYXAocHJvZmlsZSA9PiAoe1xyXG4gICAgICBrZXk6IHByb2ZpbGUuaWQgYXMgc3RyaW5nLFxyXG4gICAgICB0ZXh0OiBwcm9maWxlLm5vbWUsXHJcbiAgICB9KSkgPz8gW10sXHJcbiAgICBbZGF0YV0sXHJcbiAgKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPENvbWJvQm94XHJcbiAgICAgIGFsbG93RnJlZWZvcm09e3RydWV9XHJcbiAgICAgIGF1dG9Db21wbGV0ZT0nb24nXHJcbiAgICAgIG9wdGlvbnM9e29wdGlvbnN9XHJcbiAgICAgIHN0eWxlcz17c3R5bGVzfVxyXG4gICAgICBjYWxsb3V0UHJvcHM9e3tcclxuICAgICAgICBjYWxsb3V0TWluV2lkdGg6IDgwLFxyXG4gICAgICB9fVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvZmlsZURyb3Bkb3duXHJcbiJdfQ==