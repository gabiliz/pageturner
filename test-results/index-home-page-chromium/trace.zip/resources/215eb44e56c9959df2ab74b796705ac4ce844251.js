import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { ErrorBoundary } from "/node_modules/.vite/deps/react-error-boundary.js?v=9f90a7ff";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { DataTableInt, ErrorScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
import { clientQueryService } from "/src/modules/admin/clients/services/index.ts";
import ClientActions from "/src/modules/admin/clients/components/ClientActions.tsx?t=1701096626433";
import ClientEditDrawer from "/src/modules/admin/clients/components/ClientEditDrawer.tsx?t=1701096626433";
import { buildQueryFilterDefault } from "/src/shared/utils/index.ts";
const ClientList = (props) => {
  _s();
  const {
    deletePermission,
    createPermission,
    visualizePermission,
    updatePermission
  } = props;
  const navigate = useNavigate();
  const [isEditDrawerOpen, {
    setTrue: openEditDrawer,
    setFalse: closeEditDrawer
  }] = useBoolean(false);
  const [clientToEdit, setClientToEdit] = useState();
  const {
    openDialog
  } = useDialogs();
  const {
    mutateAsync: deleteItem
  } = clientQueryService.useDelete();
  const [selection, setSelection] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [paginationConfig, setPaginationConfig] = useState({
    itemsSkipped: 0,
    pageSize: 12
  });
  const [sortConfig, setSortConfig] = useState({
    field: "nomeFantasia",
    descending: false
  });
  const [filter, setFilter] = useState();
  const filterData = useCallback((value) => {
    setFilter(buildQueryFilterDefault(columns, value));
  }, [setFilter, columns, filter]);
  const {
    error,
    data,
    isLoading
  } = clientQueryService.useFindAllPaginated({
    $skip: paginationConfig.itemsSkipped,
    $top: paginationConfig.pageSize,
    $orderby: `${sortConfig.field.replaceAll(".", "/")} ${sortConfig.descending ? "desc" : "asc"}`,
    $filter: filter && `${filter ? `(${filter})` : ""}`
  });
  useEffect(() => {
    setSelection([]);
  }, [data]);
  const updateDrawer = useCallback((client) => {
    setIsCreating(false);
    setClientToEdit(client);
    openEditDrawer();
  }, []);
  const createDrawer = useCallback(() => {
    setIsCreating(true);
    setClientToEdit(void 0);
    openEditDrawer();
  }, []);
  const removeItems = useCallback(async (toRemove) => {
    await Promise.allSettled(toRemove.map((item) => item.id ? deleteItem(item) : Promise.resolve()));
  }, []);
  const confirmRemoval = useCallback((client) => {
    const toRemove = client ? [client] : selection;
    const description = toRemove.length > 1 ? "Tem certeza que deseja excluir os clientes?" : "Tem certeza que deseja excluir o cliente?";
    openDialog({
      title: "Excluir cliente",
      description,
      acceptLabel: "Excluir",
      style: "danger",
      onAccept: () => removeItems(toRemove)
    });
  }, [selection, removeItems]);
  const menuOptions = useCallback((client) => {
    const menu = [];
    if (updatePermission) {
      menu.push({
        key: "update",
        text: "Alterar",
        onClick: () => updateDrawer(client)
      });
    }
    if (deletePermission) {
      menu.push({
        key: "delete",
        text: "Excluir",
        onClick: () => confirmRemoval(client)
      });
    }
    menu.push({
      key: "companies",
      text: "Empresas",
      onClick: () => navigate(`${client.id}/companies`)
    });
    if (visualizePermission) {
      menu.push({
        key: "contracts",
        text: "Contratos",
        onClick: () => navigate(`${client.id}/contracts`)
      });
    }
    return menu;
  }, [updateDrawer, confirmRemoval, updatePermission, deletePermission, visualizePermission]);
  const actions = useCallback(() => /* @__PURE__ */ jsxDEV(ClientActions, { onAdd: () => createDrawer(), onRemove: () => confirmRemoval(), disabledRemoveButton: selection.length === 0, createPermission, deletePermission, visualizePermission }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
    lineNumber: 122,
    columnNumber: 37
  }, this), [selection, confirmRemoval, createPermission, deletePermission, visualizePermission]);
  if (error)
    return /* @__PURE__ */ jsxDEV(ErrorScreen, { error }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
      lineNumber: 123,
      columnNumber: 21
    }, this);
  return /* @__PURE__ */ jsxDEV(ErrorBoundary, { fallbackRender: ({
    error: error2
  }) => /* @__PURE__ */ jsxDEV(ErrorScreen, { error: error2 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
    lineNumber: 126,
    columnNumber: 9
  }, this), children: [
    /* @__PURE__ */ jsxDEV(DataTableInt, { items: data?.value ?? [], itemsCount: data?.["@odata.count"], onSearchTextChange: filterData, columns, paginated: true, renderActions: actions, hasSearch: true, hasControlsColumn: true, selection, onSelection: setSelection, menuOptions, sortConfig, onPageChange: setPaginationConfig, onSortChange: setSortConfig, hasSelection: true, loading: isLoading }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    isEditDrawerOpen && /* @__PURE__ */ jsxDEV(ClientEditDrawer, { isOpen: isEditDrawerOpen, onDismiss: closeEditDrawer, client: clientToEdit, isCreating }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
      lineNumber: 128,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx",
    lineNumber: 124,
    columnNumber: 10
  }, this);
};
_s(ClientList, "DajYMRpmp9lr2XC12zfTOuAnIRs=", false, function() {
  return [useNavigate, useBoolean, useDialogs, clientQueryService.useDelete, clientQueryService.useFindAllPaginated];
});
_c = ClientList;
const columns = [{
  header: "Nome fantasia",
  field: "nomeFantasia",
  type: "string",
  filterable: true,
  sortable: true
}, {
  header: "Escritório",
  field: "escritorio.nome",
  type: "string",
  filterable: true,
  sortable: true
}, {
  header: "CNPJ",
  field: "empresas",
  type: "string",
  filterOptions: {
    queryType: "listCnpj",
    queryMode: "default"
  },
  blockShowing: true,
  filterable: true,
  sortable: true
}, {
  header: "Razão Social",
  field: "empresas",
  type: "string",
  filterOptions: {
    queryType: "listRazaoSocial",
    queryMode: "default"
  },
  blockShowing: true,
  filterable: true,
  sortable: true
}, {
  header: "Data de inclusão",
  field: "dtInclusao",
  format: (item) => {
    if (item.dtInclusao) {
      const date = new Date(item.dtInclusao);
      date.setTime(date.getTime() + date.getTimezoneOffset() * 60 * 1e3);
      return format(date, "dd/MM/yyyy");
    }
  },
  filterOptions: {
    queryType: "date",
    queryMode: "default"
  },
  type: "date",
  filterable: true,
  sortable: true
}];
export default ClientList;
var _c;
$RefreshReg$(_c, "ClientList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOElJOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0lKLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQWFDLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUNyRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQTBCQyxjQUE4REMsbUJBQW1CO0FBQzNHLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQywwQkFBMEI7QUFDbkMsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHNCQUFzQjtBQUM3QixTQUFTQywrQkFBK0I7QUFTeEMsTUFBTUMsYUFBbUNDLFdBQVU7QUFBQUMsS0FBQTtBQUNqRCxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJTDtBQUNKLFFBQU1NLFdBQVdmLFlBQVk7QUFDN0IsUUFBTSxDQUNKZ0Isa0JBQ0E7QUFBQSxJQUFFQyxTQUFTQztBQUFBQSxJQUFnQkMsVUFBVUM7QUFBQUEsRUFBZ0IsQ0FBQyxJQUNwRDFCLFdBQVcsS0FBSztBQUVwQixRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUl4QixTQUFpQjtBQUV6RCxRQUFNO0FBQUEsSUFBRXlCO0FBQUFBLEVBQVcsSUFBSXBCLFdBQVc7QUFFbEMsUUFBTTtBQUFBLElBQUVxQixhQUFhQztBQUFBQSxFQUFXLElBQUlyQixtQkFBbUJzQixVQUFVO0FBQ2pFLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJOUIsU0FBbUIsRUFBRTtBQUN2RCxRQUFNLENBQUMrQixZQUFZQyxhQUFhLElBQUloQyxTQUFrQixLQUFLO0FBRTNELFFBQU0sQ0FBQ2lDLGtCQUFrQkMsbUJBQW1CLElBQUlsQyxTQUFvQztBQUFBLElBQ2xGbUMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXRDLFNBQThCO0FBQUEsSUFDaEV1QyxPQUFPO0FBQUEsSUFDUEMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJMUMsU0FBaUI7QUFDN0MsUUFBTTJDLGFBQWE3QyxZQUFZLENBQUM4QyxVQUF3QjtBQUN0REYsY0FBVWpDLHdCQUF3Qm9DLFNBQVNELEtBQUssQ0FBQztBQUFBLEVBQ25ELEdBQUcsQ0FBQ0YsV0FBV0csU0FBU0osTUFBTSxDQUFDO0FBRS9CLFFBQU07QUFBQSxJQUFFSztBQUFBQSxJQUFPQztBQUFBQSxJQUFNQztBQUFBQSxFQUFVLElBQUkxQyxtQkFBbUIyQyxvQkFBb0I7QUFBQSxJQUN4RUMsT0FBT2pCLGlCQUFpQkU7QUFBQUEsSUFDeEJnQixNQUFNbEIsaUJBQWlCRztBQUFBQSxJQUN2QmdCLFVBQVcsR0FBRWYsV0FBV0UsTUFBTWMsV0FBVyxLQUFLLEdBQUcsS0FBS2hCLFdBQVdHLGFBQWEsU0FBUztBQUFBLElBQ3ZGYyxTQUFTYixVQUFXLEdBQUVBLFNBQVUsSUFBR0EsWUFBWTtBQUFBLEVBQ2pELENBQUM7QUFFRDFDLFlBQVUsTUFBTTtBQUNkK0IsaUJBQWEsRUFBRTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ2lCLElBQUksQ0FBQztBQUVULFFBQU1RLGVBQWV6RCxZQUFZLENBQUMwRCxXQUFtQjtBQUNuRHhCLGtCQUFjLEtBQUs7QUFDbkJSLG9CQUFnQmdDLE1BQU07QUFDdEJwQyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU1xQyxlQUFlM0QsWUFBWSxNQUFNO0FBQ3JDa0Msa0JBQWMsSUFBSTtBQUNsQlIsb0JBQWdCa0MsTUFBUztBQUN6QnRDLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTXVDLGNBQWM3RCxZQUFZLE9BQU84RCxhQUF1QjtBQUM1RCxVQUFNQyxRQUFRQyxXQUNaRixTQUFTRyxJQUFJQyxVQUFRQSxLQUFLQyxLQUN0QnRDLFdBQVdxQyxJQUFJLElBQ2ZILFFBQVFLLFFBQVEsQ0FDcEIsQ0FDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsaUJBQWlCckUsWUFDckIsQ0FBQzBELFdBQW9CO0FBQ25CLFVBQU1JLFdBQVdKLFNBQVMsQ0FBQ0EsTUFBTSxJQUFJM0I7QUFDckMsVUFBTXVDLGNBQWNSLFNBQVNTLFNBQVMsSUFDbEMsZ0RBQ0E7QUFDSjVDLGVBQVc7QUFBQSxNQUNUNkMsT0FBTztBQUFBLE1BQ1BGO0FBQUFBLE1BQ0FHLGFBQWE7QUFBQSxNQUNiQyxPQUFPO0FBQUEsTUFDUEMsVUFBVUEsTUFBTWQsWUFBWUMsUUFBUTtBQUFBLElBQ3RDLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQy9CLFdBQVc4QixXQUFXLENBQUM7QUFFN0IsUUFBTWUsY0FBYzVFLFlBQ2xCLENBQUMwRCxXQUEwQztBQUN6QyxVQUFNbUIsT0FBTztBQUNiLFFBQUkzRCxrQkFBa0I7QUFDcEIyRCxXQUFLQyxLQUFLO0FBQUEsUUFDUkMsS0FBSztBQUFBLFFBQ0xDLE1BQU07QUFBQSxRQUNOQyxTQUFTQSxNQUFNeEIsYUFBYUMsTUFBTTtBQUFBLE1BQ3BDLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSTNDLGtCQUFrQjtBQUNwQjhELFdBQUtDLEtBQUs7QUFBQSxRQUNSQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLFFBQ05DLFNBQVNBLE1BQU1aLGVBQWVYLE1BQU07QUFBQSxNQUN0QyxDQUFDO0FBQUEsSUFDSDtBQUNBbUIsU0FBS0MsS0FBSztBQUFBLE1BQ1JDLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsU0FBU0EsTUFBTTlELFNBQVUsR0FBRXVDLE9BQU9TLGNBQWM7QUFBQSxJQUNsRCxDQUFDO0FBQ0QsUUFBSWxELHFCQUFxQjtBQUN2QjRELFdBQUtDLEtBQUs7QUFBQSxRQUNSQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLFFBQ05DLFNBQVNBLE1BQU05RCxTQUFVLEdBQUV1QyxPQUFPUyxjQUFjO0FBQUEsTUFDbEQsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPVTtBQUFBQSxFQUNULEdBQ0EsQ0FDRXBCLGNBQ0FZLGdCQUNBbkQsa0JBQ0FILGtCQUNBRSxtQkFBbUIsQ0FDcEI7QUFFSCxRQUFNaUUsVUFBVWxGLFlBQVksTUFDMUIsdUJBQUMsaUJBQ0MsT0FBTyxNQUFNMkQsYUFBYSxHQUMxQixVQUFVLE1BQU1VLGVBQWUsR0FDL0Isc0JBQXNCdEMsVUFBVXdDLFdBQVcsR0FDM0Msa0JBQ0Esa0JBQ0EsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU0yQyxHQUUxQyxDQUNEeEMsV0FDQXNDLGdCQUNBckQsa0JBQ0FELGtCQUNBRSxtQkFBbUIsQ0FDcEI7QUFFRCxNQUFJK0I7QUFBTyxXQUFPLHVCQUFDLGVBQVksU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBRTVDLFNBQ0UsdUJBQUMsaUJBQ0MsZ0JBQWdCLENBQUM7QUFBQSxJQUFFQTtBQUFBQSxFQUFNLE1BQ3ZCLHVCQUFDLGVBQVksT0FBT0EsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQixHQUc1QjtBQUFBLDJCQUFDLGdCQUNDLE9BQU9DLE1BQU1ILFNBQVMsSUFDdEIsWUFBWUcsT0FBTyxjQUFjLEdBQ2pDLG9CQUFvQkosWUFDcEIsU0FDQSxXQUFTLE1BQ1QsZUFBZXFDLFNBQ2YsV0FBUyxNQUNULG1CQUFpQixNQUNqQixXQUNBLGFBQWFsRCxjQUNiLGFBQ0EsWUFDQSxjQUFjSSxxQkFDZCxjQUFjSSxlQUNkLGNBQVksTUFDWixTQUFTVSxhQWhCWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JxQjtBQUFBLElBRXBCOUIsb0JBQ0MsdUJBQUMsb0JBQ0MsUUFBUUEsa0JBQ1IsV0FBV0ksaUJBQ1gsUUFBUUMsY0FDUixjQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJeUI7QUFBQSxPQTVCN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNYLEdBNUtLRixZQUErQjtBQUFBLFVBT2xCUixhQUliTixZQUltQlMsWUFFYUMsbUJBQW1Cc0IsV0FpQnBCdEIsbUJBQW1CMkMsbUJBQW1CO0FBQUE7QUFBQWdDLEtBbENyRXZFO0FBOEtOLE1BQU1tQyxVQUFxQyxDQUN6QztBQUFBLEVBQ0VxQyxRQUFRO0FBQUEsRUFDUjNDLE9BQU87QUFBQSxFQUNQNEMsTUFBTTtBQUFBLEVBQ05DLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VILFFBQVE7QUFBQSxFQUNSM0MsT0FBTztBQUFBLEVBQ1A0QyxNQUFNO0FBQUEsRUFDTkMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUgsUUFBUTtBQUFBLEVBQ1IzQyxPQUFPO0FBQUEsRUFDUDRDLE1BQU07QUFBQSxFQUNORyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsY0FBYztBQUFBLEVBQ2RMLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VILFFBQVE7QUFBQSxFQUNSM0MsT0FBTztBQUFBLEVBQ1A0QyxNQUFNO0FBQUEsRUFDTkcsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLGNBQWM7QUFBQSxFQUNkTCxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUNaLEdBQ0E7QUFBQSxFQUNFSCxRQUFRO0FBQUEsRUFDUjNDLE9BQU87QUFBQSxFQUNQMUMsUUFBU21FLFVBQVM7QUFDaEIsUUFBSUEsS0FBSzBCLFlBQVk7QUFDbkIsWUFBTUMsT0FBTyxJQUFJQyxLQUFLNUIsS0FBSzBCLFVBQVU7QUFDckNDLFdBQUtFLFFBQVFGLEtBQUtHLFFBQVEsSUFBSUgsS0FBS0ksa0JBQWtCLElBQUksS0FBSyxHQUFJO0FBQ2xFLGFBQU9sRyxPQUFPOEYsTUFBTSxZQUFZO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBQUEsRUFDQUwsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FMLE1BQU07QUFBQSxFQUNOQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUNaLENBQUM7QUFHSCxlQUFlM0U7QUFBVSxJQUFBdUU7QUFBQWUsYUFBQWYsSUFBQSIsIm5hbWVzIjpbInVzZUJvb2xlYW4iLCJmb3JtYXQiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiRXJyb3JCb3VuZGFyeSIsInVzZU5hdmlnYXRlIiwiRGF0YVRhYmxlSW50IiwiRXJyb3JTY3JlZW4iLCJ1c2VEaWFsb2dzIiwiY2xpZW50UXVlcnlTZXJ2aWNlIiwiQ2xpZW50QWN0aW9ucyIsIkNsaWVudEVkaXREcmF3ZXIiLCJidWlsZFF1ZXJ5RmlsdGVyRGVmYXVsdCIsIkNsaWVudExpc3QiLCJwcm9wcyIsIl9zIiwiZGVsZXRlUGVybWlzc2lvbiIsImNyZWF0ZVBlcm1pc3Npb24iLCJ2aXN1YWxpemVQZXJtaXNzaW9uIiwidXBkYXRlUGVybWlzc2lvbiIsIm5hdmlnYXRlIiwiaXNFZGl0RHJhd2VyT3BlbiIsInNldFRydWUiLCJvcGVuRWRpdERyYXdlciIsInNldEZhbHNlIiwiY2xvc2VFZGl0RHJhd2VyIiwiY2xpZW50VG9FZGl0Iiwic2V0Q2xpZW50VG9FZGl0Iiwib3BlbkRpYWxvZyIsIm11dGF0ZUFzeW5jIiwiZGVsZXRlSXRlbSIsInVzZURlbGV0ZSIsInNlbGVjdGlvbiIsInNldFNlbGVjdGlvbiIsImlzQ3JlYXRpbmciLCJzZXRJc0NyZWF0aW5nIiwicGFnaW5hdGlvbkNvbmZpZyIsInNldFBhZ2luYXRpb25Db25maWciLCJpdGVtc1NraXBwZWQiLCJwYWdlU2l6ZSIsInNvcnRDb25maWciLCJzZXRTb3J0Q29uZmlnIiwiZmllbGQiLCJkZXNjZW5kaW5nIiwiZmlsdGVyIiwic2V0RmlsdGVyIiwiZmlsdGVyRGF0YSIsInZhbHVlIiwiY29sdW1ucyIsImVycm9yIiwiZGF0YSIsImlzTG9hZGluZyIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCIkc2tpcCIsIiR0b3AiLCIkb3JkZXJieSIsInJlcGxhY2VBbGwiLCIkZmlsdGVyIiwidXBkYXRlRHJhd2VyIiwiY2xpZW50IiwiY3JlYXRlRHJhd2VyIiwidW5kZWZpbmVkIiwicmVtb3ZlSXRlbXMiLCJ0b1JlbW92ZSIsIlByb21pc2UiLCJhbGxTZXR0bGVkIiwibWFwIiwiaXRlbSIsImlkIiwicmVzb2x2ZSIsImNvbmZpcm1SZW1vdmFsIiwiZGVzY3JpcHRpb24iLCJsZW5ndGgiLCJ0aXRsZSIsImFjY2VwdExhYmVsIiwic3R5bGUiLCJvbkFjY2VwdCIsIm1lbnVPcHRpb25zIiwibWVudSIsInB1c2giLCJrZXkiLCJ0ZXh0Iiwib25DbGljayIsImFjdGlvbnMiLCJfYyIsImhlYWRlciIsInR5cGUiLCJmaWx0ZXJhYmxlIiwic29ydGFibGUiLCJmaWx0ZXJPcHRpb25zIiwicXVlcnlUeXBlIiwicXVlcnlNb2RlIiwiYmxvY2tTaG93aW5nIiwiZHRJbmNsdXNhbyIsImRhdGUiLCJEYXRlIiwic2V0VGltZSIsImdldFRpbWUiLCJnZXRUaW1lem9uZU9mZnNldCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNsaWVudExpc3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jbGllbnRzL2NvbXBvbmVudHMvQ2xpZW50TGlzdC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJQ29udGV4dHVhbE1lbnVJdGVtIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IGZvcm1hdCB9IGZyb20gJ2RhdGUtZm5zJ1xuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgQ2xpZW50IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9DbGllbnQnXG5pbXBvcnQgeyBEYXRhVGFibGVDb2x1bW4sIERhdGFUYWJsZUludCwgRGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZywgRGF0YVRhYmxlU29ydENvbmZpZywgRXJyb3JTY3JlZW4gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IHVzZURpYWxvZ3MgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvc3RvcmUvZGlhbG9ncy9kaWFsb2dzJ1xuaW1wb3J0IHsgY2xpZW50UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5pbXBvcnQgQ2xpZW50QWN0aW9ucyBmcm9tICcuL0NsaWVudEFjdGlvbnMnXG5pbXBvcnQgQ2xpZW50RWRpdERyYXdlciBmcm9tICcuL0NsaWVudEVkaXREcmF3ZXInXG5pbXBvcnQgeyBidWlsZFF1ZXJ5RmlsdGVyRGVmYXVsdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscydcblxuaW50ZXJmYWNlIENsaWVudExpc3RQcm9wcyB7XG4gIGRlbGV0ZVBlcm1pc3Npb246IGJvb2xlYW5cbiAgY3JlYXRlUGVybWlzc2lvbjogYm9vbGVhblxuICB2aXN1YWxpemVQZXJtaXNzaW9uOiBib29sZWFuXG4gIHVwZGF0ZVBlcm1pc3Npb246IGJvb2xlYW5cbn1cblxuY29uc3QgQ2xpZW50TGlzdDogRkM8Q2xpZW50TGlzdFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgZGVsZXRlUGVybWlzc2lvbixcbiAgICBjcmVhdGVQZXJtaXNzaW9uLFxuICAgIHZpc3VhbGl6ZVBlcm1pc3Npb24sXG4gICAgdXBkYXRlUGVybWlzc2lvbixcbiAgfSA9IHByb3BzXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBbXG4gICAgaXNFZGl0RHJhd2VyT3BlbixcbiAgICB7IHNldFRydWU6IG9wZW5FZGl0RHJhd2VyLCBzZXRGYWxzZTogY2xvc2VFZGl0RHJhd2VyIH0sXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxuXG4gIGNvbnN0IFtjbGllbnRUb0VkaXQsIHNldENsaWVudFRvRWRpdF0gPSB1c2VTdGF0ZTxDbGllbnQ+KClcblxuICBjb25zdCB7IG9wZW5EaWFsb2cgfSA9IHVzZURpYWxvZ3MoKVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGRlbGV0ZUl0ZW0gfSA9IGNsaWVudFF1ZXJ5U2VydmljZS51c2VEZWxldGUoKVxuICBjb25zdCBbc2VsZWN0aW9uLCBzZXRTZWxlY3Rpb25dID0gdXNlU3RhdGU8Q2xpZW50W10+KFtdKVxuICBjb25zdCBbaXNDcmVhdGluZywgc2V0SXNDcmVhdGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSlcblxuICBjb25zdCBbcGFnaW5hdGlvbkNvbmZpZywgc2V0UGFnaW5hdGlvbkNvbmZpZ10gPSB1c2VTdGF0ZTxEYXRhVGFibGVQYWdpbmF0aW9uQ29uZmlnPih7XG4gICAgaXRlbXNTa2lwcGVkOiAwLFxuICAgIHBhZ2VTaXplOiAxMixcbiAgfSlcbiAgY29uc3QgW3NvcnRDb25maWcsIHNldFNvcnRDb25maWddID0gdXNlU3RhdGU8RGF0YVRhYmxlU29ydENvbmZpZz4oe1xuICAgIGZpZWxkOiAnbm9tZUZhbnRhc2lhJyxcbiAgICBkZXNjZW5kaW5nOiBmYWxzZSxcbiAgfSlcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oKVxuICBjb25zdCBmaWx0ZXJEYXRhID0gdXNlQ2FsbGJhY2soKHZhbHVlOiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICBzZXRGaWx0ZXIoYnVpbGRRdWVyeUZpbHRlckRlZmF1bHQoY29sdW1ucywgdmFsdWUpKVxuICB9LCBbc2V0RmlsdGVyLCBjb2x1bW5zLCBmaWx0ZXJdKVxuXG4gIGNvbnN0IHsgZXJyb3IsIGRhdGEsIGlzTG9hZGluZyB9ID0gY2xpZW50UXVlcnlTZXJ2aWNlLnVzZUZpbmRBbGxQYWdpbmF0ZWQoe1xuICAgICRza2lwOiBwYWdpbmF0aW9uQ29uZmlnLml0ZW1zU2tpcHBlZCxcbiAgICAkdG9wOiBwYWdpbmF0aW9uQ29uZmlnLnBhZ2VTaXplLFxuICAgICRvcmRlcmJ5OiBgJHtzb3J0Q29uZmlnLmZpZWxkLnJlcGxhY2VBbGwoJy4nLCAnLycpfSAke3NvcnRDb25maWcuZGVzY2VuZGluZyA/ICdkZXNjJyA6ICdhc2MnfWAsXG4gICAgJGZpbHRlcjogZmlsdGVyICYmIGAke2ZpbHRlciA/IGAoJHtmaWx0ZXJ9KWAgOiAnJ31gLFxuICB9KVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0U2VsZWN0aW9uKFtdKVxuICB9LCBbZGF0YV0pXG5cbiAgY29uc3QgdXBkYXRlRHJhd2VyID0gdXNlQ2FsbGJhY2soKGNsaWVudDogQ2xpZW50KSA9PiB7XG4gICAgc2V0SXNDcmVhdGluZyhmYWxzZSlcbiAgICBzZXRDbGllbnRUb0VkaXQoY2xpZW50KVxuICAgIG9wZW5FZGl0RHJhd2VyKClcbiAgfSwgW10pXG5cbiAgY29uc3QgY3JlYXRlRHJhd2VyID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldElzQ3JlYXRpbmcodHJ1ZSlcbiAgICBzZXRDbGllbnRUb0VkaXQodW5kZWZpbmVkKVxuICAgIG9wZW5FZGl0RHJhd2VyKClcbiAgfSwgW10pXG5cbiAgY29uc3QgcmVtb3ZlSXRlbXMgPSB1c2VDYWxsYmFjayhhc3luYyAodG9SZW1vdmU6IENsaWVudFtdKSA9PiB7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGxTZXR0bGVkKFxuICAgICAgdG9SZW1vdmUubWFwKGl0ZW0gPT4gaXRlbS5pZFxuICAgICAgICA/IGRlbGV0ZUl0ZW0oaXRlbSlcbiAgICAgICAgOiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICAgICksXG4gICAgKVxuICB9LCBbXSlcblxuICBjb25zdCBjb25maXJtUmVtb3ZhbCA9IHVzZUNhbGxiYWNrKFxuICAgIChjbGllbnQ/OiBDbGllbnQpID0+IHtcbiAgICAgIGNvbnN0IHRvUmVtb3ZlID0gY2xpZW50ID8gW2NsaWVudF0gOiBzZWxlY3Rpb25cbiAgICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdG9SZW1vdmUubGVuZ3RoID4gMVxuICAgICAgICA/ICdUZW0gY2VydGV6YSBxdWUgZGVzZWphIGV4Y2x1aXIgb3MgY2xpZW50ZXM/J1xuICAgICAgICA6ICdUZW0gY2VydGV6YSBxdWUgZGVzZWphIGV4Y2x1aXIgbyBjbGllbnRlPydcbiAgICAgIG9wZW5EaWFsb2coe1xuICAgICAgICB0aXRsZTogJ0V4Y2x1aXIgY2xpZW50ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgICBhY2NlcHRMYWJlbDogJ0V4Y2x1aXInLFxuICAgICAgICBzdHlsZTogJ2RhbmdlcicsXG4gICAgICAgIG9uQWNjZXB0OiAoKSA9PiByZW1vdmVJdGVtcyh0b1JlbW92ZSksXG4gICAgICB9KVxuICAgIH0sIFtzZWxlY3Rpb24sIHJlbW92ZUl0ZW1zXSlcblxuICBjb25zdCBtZW51T3B0aW9ucyA9IHVzZUNhbGxiYWNrKFxuICAgIChjbGllbnQ6IENsaWVudCk6IElDb250ZXh0dWFsTWVudUl0ZW1bXSA9PiB7XG4gICAgICBjb25zdCBtZW51ID0gW11cbiAgICAgIGlmICh1cGRhdGVQZXJtaXNzaW9uKSB7XG4gICAgICAgIG1lbnUucHVzaCh7XG4gICAgICAgICAga2V5OiAndXBkYXRlJyxcbiAgICAgICAgICB0ZXh0OiAnQWx0ZXJhcicsXG4gICAgICAgICAgb25DbGljazogKCkgPT4gdXBkYXRlRHJhd2VyKGNsaWVudCksXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICBpZiAoZGVsZXRlUGVybWlzc2lvbikge1xuICAgICAgICBtZW51LnB1c2goe1xuICAgICAgICAgIGtleTogJ2RlbGV0ZScsXG4gICAgICAgICAgdGV4dDogJ0V4Y2x1aXInLFxuICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGNvbmZpcm1SZW1vdmFsKGNsaWVudCksXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICBtZW51LnB1c2goe1xuICAgICAgICBrZXk6ICdjb21wYW5pZXMnLFxuICAgICAgICB0ZXh0OiAnRW1wcmVzYXMnLFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiBuYXZpZ2F0ZShgJHtjbGllbnQuaWR9L2NvbXBhbmllc2ApLFxuICAgICAgfSlcbiAgICAgIGlmICh2aXN1YWxpemVQZXJtaXNzaW9uKSB7XG4gICAgICAgIG1lbnUucHVzaCh7XG4gICAgICAgICAga2V5OiAnY29udHJhY3RzJyxcbiAgICAgICAgICB0ZXh0OiAnQ29udHJhdG9zJyxcbiAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBuYXZpZ2F0ZShgJHtjbGllbnQuaWR9L2NvbnRyYWN0c2ApLFxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgcmV0dXJuIG1lbnVcbiAgICB9LFxuICAgIFtcbiAgICAgIHVwZGF0ZURyYXdlcixcbiAgICAgIGNvbmZpcm1SZW1vdmFsLFxuICAgICAgdXBkYXRlUGVybWlzc2lvbixcbiAgICAgIGRlbGV0ZVBlcm1pc3Npb24sXG4gICAgICB2aXN1YWxpemVQZXJtaXNzaW9uLFxuICAgIF0pXG5cbiAgY29uc3QgYWN0aW9ucyA9IHVzZUNhbGxiYWNrKCgpID0+IChcbiAgICA8Q2xpZW50QWN0aW9uc1xuICAgICAgb25BZGQ9eygpID0+IGNyZWF0ZURyYXdlcigpfVxuICAgICAgb25SZW1vdmU9eygpID0+IGNvbmZpcm1SZW1vdmFsKCl9XG4gICAgICBkaXNhYmxlZFJlbW92ZUJ1dHRvbj17c2VsZWN0aW9uLmxlbmd0aCA9PT0gMH1cbiAgICAgIGNyZWF0ZVBlcm1pc3Npb249e2NyZWF0ZVBlcm1pc3Npb259XG4gICAgICBkZWxldGVQZXJtaXNzaW9uPXtkZWxldGVQZXJtaXNzaW9ufVxuICAgICAgdmlzdWFsaXplUGVybWlzc2lvbj17dmlzdWFsaXplUGVybWlzc2lvbn1cbiAgICAvPlxuICApLCBbXG4gICAgc2VsZWN0aW9uLFxuICAgIGNvbmZpcm1SZW1vdmFsLFxuICAgIGNyZWF0ZVBlcm1pc3Npb24sXG4gICAgZGVsZXRlUGVybWlzc2lvbixcbiAgICB2aXN1YWxpemVQZXJtaXNzaW9uLFxuICBdKVxuXG4gIGlmIChlcnJvcikgcmV0dXJuIDxFcnJvclNjcmVlbiBlcnJvcj17ZXJyb3J9IC8+XG5cbiAgcmV0dXJuIChcbiAgICA8RXJyb3JCb3VuZGFyeVxuICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IGVycm9yIH0pID0+IChcbiAgICAgICAgPEVycm9yU2NyZWVuIGVycm9yPXtlcnJvcn0gLz5cbiAgICAgICl9XG4gICAgPlxuICAgICAgPERhdGFUYWJsZUludFxuICAgICAgICBpdGVtcz17ZGF0YT8udmFsdWUgPz8gW119XG4gICAgICAgIGl0ZW1zQ291bnQ9e2RhdGE/LlsnQG9kYXRhLmNvdW50J119XG4gICAgICAgIG9uU2VhcmNoVGV4dENoYW5nZT17ZmlsdGVyRGF0YX1cbiAgICAgICAgY29sdW1ucz17Y29sdW1uc31cbiAgICAgICAgcGFnaW5hdGVkXG4gICAgICAgIHJlbmRlckFjdGlvbnM9e2FjdGlvbnN9XG4gICAgICAgIGhhc1NlYXJjaFxuICAgICAgICBoYXNDb250cm9sc0NvbHVtblxuICAgICAgICBzZWxlY3Rpb249e3NlbGVjdGlvbn1cbiAgICAgICAgb25TZWxlY3Rpb249e3NldFNlbGVjdGlvbn1cbiAgICAgICAgbWVudU9wdGlvbnM9e21lbnVPcHRpb25zfVxuICAgICAgICBzb3J0Q29uZmlnPXtzb3J0Q29uZmlnfVxuICAgICAgICBvblBhZ2VDaGFuZ2U9e3NldFBhZ2luYXRpb25Db25maWd9XG4gICAgICAgIG9uU29ydENoYW5nZT17c2V0U29ydENvbmZpZ31cbiAgICAgICAgaGFzU2VsZWN0aW9uXG4gICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ31cbiAgICAgIC8+XG4gICAgICB7aXNFZGl0RHJhd2VyT3BlbiAmJlxuICAgICAgICA8Q2xpZW50RWRpdERyYXdlclxuICAgICAgICAgIGlzT3Blbj17aXNFZGl0RHJhd2VyT3Blbn1cbiAgICAgICAgICBvbkRpc21pc3M9e2Nsb3NlRWRpdERyYXdlcn1cbiAgICAgICAgICBjbGllbnQ9e2NsaWVudFRvRWRpdH1cbiAgICAgICAgICBpc0NyZWF0aW5nPXtpc0NyZWF0aW5nfVxuICAgICAgICAvPn1cbiAgICA8L0Vycm9yQm91bmRhcnk+XG4gIClcbn1cblxuY29uc3QgY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPENsaWVudD5bXSA9IFtcbiAge1xuICAgIGhlYWRlcjogJ05vbWUgZmFudGFzaWEnLFxuICAgIGZpZWxkOiAnbm9tZUZhbnRhc2lhJyxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnRXNjcml0w7NyaW8nLFxuICAgIGZpZWxkOiAnZXNjcml0b3Jpby5ub21lJyxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnQ05QSicsXG4gICAgZmllbGQ6ICdlbXByZXNhcycsXG4gICAgdHlwZTogJ3N0cmluZycsXG4gICAgZmlsdGVyT3B0aW9uczoge1xuICAgICAgcXVlcnlUeXBlOiAnbGlzdENucGonLFxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXG4gICAgfSxcbiAgICBibG9ja1Nob3dpbmc6IHRydWUsXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ1JhesOjbyBTb2NpYWwnLFxuICAgIGZpZWxkOiAnZW1wcmVzYXMnLFxuICAgIHR5cGU6ICdzdHJpbmcnLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ2xpc3RSYXphb1NvY2lhbCcsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIGJsb2NrU2hvd2luZzogdHJ1ZSxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnRGF0YSBkZSBpbmNsdXPDo28nLFxuICAgIGZpZWxkOiAnZHRJbmNsdXNhbycsXG4gICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xuICAgICAgaWYgKGl0ZW0uZHRJbmNsdXNhbykge1xuICAgICAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoaXRlbS5kdEluY2x1c2FvKVxuICAgICAgICBkYXRlLnNldFRpbWUoZGF0ZS5nZXRUaW1lKCkgKyBkYXRlLmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MCAqIDEwMDApXG4gICAgICAgIHJldHVybiBmb3JtYXQoZGF0ZSwgJ2RkL01NL3l5eXknKVxuICAgICAgfVxuICAgIH0sXG4gICAgZmlsdGVyT3B0aW9uczoge1xuICAgICAgcXVlcnlUeXBlOiAnZGF0ZScsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdkYXRlJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBDbGllbnRMaXN0XG4iXX0=