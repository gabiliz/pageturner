import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/roles/components/RoleDetails.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Label, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { FlexColumn, FlexItem } from "/src/shared/components/index.ts?t=1701096626433";
const RoleDetails = (props) => {
  const {
    data
  } = props;
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nome" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.nome }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Descrição" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.descricao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_c = RoleDetails;
export default RoleDetails;
var _c;
$RefreshReg$(_c, "RoleDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7QUFaUiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixTQUFTQSxPQUFPQyxZQUFZO0FBRzVCLFNBQVNDLFlBQVlDLGdCQUFnQjtBQUVyQyxNQUFNQyxjQUEyQ0MsV0FBVTtBQUN6RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBSyxJQUFJRDtBQUVqQixTQUNFLHVCQUFDLGNBQVcsS0FBTSxJQUNoQjtBQUFBLDJCQUFDLFlBQ0M7QUFBQSw2QkFBQyxTQUFNLG9CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQ1gsdUJBQUMsUUFBTUMsZUFBS0MsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsU0FGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCO0FBQUEsTUFDaEIsdUJBQUMsUUFBTUQsZUFBS0UsYUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsU0FGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDQyxLQWZLTDtBQWlCTixlQUFlQTtBQUFXLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMYWJlbCIsIlRleHQiLCJGbGV4Q29sdW1uIiwiRmxleEl0ZW0iLCJSb2xlRGV0YWlscyIsInByb3BzIiwiZGF0YSIsIm5vbWUiLCJkZXNjcmljYW8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJvbGVEZXRhaWxzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vcm9sZXMvY29tcG9uZW50cy9Sb2xlRGV0YWlscy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGFiZWwsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBEZXRhaWxzVmlld1Byb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL0RldGFpbHNWaWV3J1xuaW1wb3J0IFJvbGUgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1JvbGUnXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBGbGV4SXRlbSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5jb25zdCBSb2xlRGV0YWlsczogRkM8RGV0YWlsc1ZpZXdQcm9wczxSb2xlPj4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBkYXRhIH0gPSBwcm9wc1xuXG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW4gZ2FwPXsgMTIgfT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPk5vbWU8L0xhYmVsPlxuICAgICAgICA8VGV4dD57ZGF0YS5ub21lfTwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD5EZXNjcmnDp8OjbzwvTGFiZWw+XG4gICAgICAgIDxUZXh0PntkYXRhLmRlc2NyaWNhb308L1RleHQ+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSb2xlRGV0YWlsc1xuIl19