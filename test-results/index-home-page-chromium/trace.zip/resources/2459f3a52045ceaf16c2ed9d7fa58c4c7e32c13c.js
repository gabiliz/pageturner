import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientEditDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { EditDrawer } from "/src/shared/components/index.ts?t=1701096626433";
import { useHandleRejection } from "/src/shared/hooks/index.ts";
import { clientQueryService } from "/src/modules/admin/clients/services/index.ts";
import ClientEditForm from "/src/modules/admin/clients/components/ClientEditForm.tsx?t=1701096626433";
const ClientEditDrawer = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    client,
    isCreating
  } = props;
  const navigate = useNavigate();
  const [formData, setFormData] = useState(client);
  const {
    mutateAsync: save,
    isLoading: isSaving
  } = clientQueryService.useUpdate();
  const {
    mutateAsync: create,
    isLoading: loadingCreating
  } = clientQueryService.useCreate();
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  const updateProfile = useCallback(async () => {
    await save(formData);
    navigate(`${formData?.id}/companies`);
    onDismiss();
  }, [formData]);
  const createProfile = useCallback(async () => {
    const savedClient = await create(formData);
    clientQueryService.invalidateQueries();
    navigate(`${savedClient?.clienteId}/companies`);
    onDismiss();
  }, [formData]);
  const dismiss = useCallback(() => {
    onDismiss();
  }, [onDismiss]);
  return /* @__PURE__ */ jsxDEV(EditDrawer, { title: isCreating ? "Adicionar cliente" : "Alterar cliente", isOpen, onDismiss: dismiss, onSave: isCreating ? createProfile : updateProfile, disabled: isSaving || loadingCreating, loading: isSaving || loadingCreating, children: /* @__PURE__ */ jsxDEV(ClientEditForm, { formData, onChange: setFormData, apiError: error?.reason ? error?.reason : void 0 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditDrawer.tsx",
    lineNumber: 59,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditDrawer.tsx",
    lineNumber: 58,
    columnNumber: 10
  }, this);
};
_s(ClientEditDrawer, "Lv36StWXD+Z1PL8sUDxnzt0l/mM=", false, function() {
  return [useNavigate, clientQueryService.useUpdate, clientQueryService.useCreate, useHandleRejection];
});
_c = ClientEditDrawer;
export default ClientEditDrawer;
var _c;
$RefreshReg$(_c, "ClientEditDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientEditDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VNOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEVOLFNBQWFBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUNyRCxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0Msa0JBQWtCO0FBRzNCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywwQkFBMEI7QUFDbkMsT0FBT0Msb0JBQW9CO0FBVTNCLE1BQU1DLG1CQUErQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQzdELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFRQztBQUFBQSxJQUFXQztBQUFBQSxJQUFRQztBQUFBQSxFQUFXLElBQUlMO0FBQ2xELFFBQU1NLFdBQVdaLFlBQVk7QUFFN0IsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlmLFNBQWlCVyxNQUFnQjtBQUNqRSxRQUFNO0FBQUEsSUFBRUssYUFBYUM7QUFBQUEsSUFBTUMsV0FBV0M7QUFBQUEsRUFBUyxJQUFJZixtQkFBbUJnQixVQUFVO0FBQ2hGLFFBQU07QUFBQSxJQUFFSixhQUFhSztBQUFBQSxJQUFRSCxXQUFXSTtBQUFBQSxFQUFnQixJQUFJbEIsbUJBQW1CbUIsVUFBVTtBQUN6RixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXpCLFNBQWdDO0FBQzFELFFBQU07QUFBQSxJQUNKMEI7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJeEIsbUJBQW1CO0FBRXZCSixZQUFVLE1BQU07QUFDZDJCLHFCQUFpQkQsUUFBUTtBQUN6QixXQUFPLE1BQU07QUFDWEUseUJBQW1CRixRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUcsZ0JBQWdCOUIsWUFBWSxZQUFZO0FBQzVDLFVBQU1tQixLQUFLSCxRQUFRO0FBQ25CRCxhQUFVLEdBQUVDLFVBQVVlLGNBQWM7QUFDcENuQixjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNJLFFBQVEsQ0FBQztBQUViLFFBQU1nQixnQkFBZ0JoQyxZQUFZLFlBQVk7QUFDNUMsVUFBTWlDLGNBQWMsTUFBTVYsT0FBT1AsUUFBUTtBQUN6Q1YsdUJBQW1CNEIsa0JBQWtCO0FBQ3JDbkIsYUFBVSxHQUFFa0IsYUFBYUUscUJBQXFCO0FBQzlDdkIsY0FBVTtBQUFBLEVBQ1osR0FBRyxDQUFDSSxRQUFRLENBQUM7QUFFYixRQUFNb0IsVUFBVXBDLFlBQVksTUFBTTtBQUNoQ1ksY0FBVTtBQUFBLEVBQ1osR0FBRyxDQUFDQSxTQUFTLENBQUM7QUFFZCxTQUNFLHVCQUFDLGNBQ0MsT0FBT0UsYUFBYSxzQkFBc0IsbUJBQzFDLFFBQ0EsV0FBV3NCLFNBQ1gsUUFBUXRCLGFBQWFrQixnQkFBZ0JGLGVBQ3JDLFVBQVVULFlBQVlHLGlCQUN0QixTQUFTSCxZQUFZRyxpQkFFckIsaUNBQUMsa0JBQ0MsVUFDQSxVQUFVUCxhQUNWLFVBQVVTLE9BQU9XLFNBQVNYLE9BQU9XLFNBQXFCQyxVQUh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR2tFLEtBWHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUM1QixHQXJES0Ysa0JBQTJDO0FBQUEsVUFFOUJMLGFBR2tDRyxtQkFBbUJnQixXQUNWaEIsbUJBQW1CbUIsV0FLM0VwQixrQkFBa0I7QUFBQTtBQUFBa0MsS0FYbEIvQjtBQXVETixlQUFlQTtBQUFnQixJQUFBK0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsIkVkaXREcmF3ZXIiLCJ1c2VIYW5kbGVSZWplY3Rpb24iLCJjbGllbnRRdWVyeVNlcnZpY2UiLCJDbGllbnRFZGl0Rm9ybSIsIkNsaWVudEVkaXREcmF3ZXIiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwiY2xpZW50IiwiaXNDcmVhdGluZyIsIm5hdmlnYXRlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm11dGF0ZUFzeW5jIiwic2F2ZSIsImlzTG9hZGluZyIsImlzU2F2aW5nIiwidXNlVXBkYXRlIiwiY3JlYXRlIiwibG9hZGluZ0NyZWF0aW5nIiwidXNlQ3JlYXRlIiwiZXJyb3IiLCJzZXRFcnJvciIsInJlZ2lzdGVyTGlzdGVuZXIiLCJ1bnJlZ2lzdGVyTGlzdGVuZXIiLCJ1cGRhdGVQcm9maWxlIiwiaWQiLCJjcmVhdGVQcm9maWxlIiwic2F2ZWRDbGllbnQiLCJpbnZhbGlkYXRlUXVlcmllcyIsImNsaWVudGVJZCIsImRpc21pc3MiLCJyZWFzb24iLCJ1bmRlZmluZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNsaWVudEVkaXREcmF3ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jbGllbnRzL2NvbXBvbmVudHMvQ2xpZW50RWRpdERyYXdlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgQ2xpZW50IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9DbGllbnQnXHJcbmltcG9ydCB7IEVkaXREcmF3ZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IHsgQXBwRHJhd2VyUHJvcHMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cy9kcmF3ZXIvQXBwRHJhd2VyJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lcnJvcnMnXHJcbmltcG9ydCB7IHVzZUhhbmRsZVJlamVjdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgY2xpZW50UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcbmltcG9ydCBDbGllbnRFZGl0Rm9ybSBmcm9tICcuL0NsaWVudEVkaXRGb3JtJ1xyXG5cclxuaW50ZXJmYWNlIENsaWVudEVkaXREcmF3ZXJQcm9wcyBleHRlbmRzIFBpY2s8XHJcbkFwcERyYXdlclByb3BzLFxyXG4naXNPcGVuJ3wnb25EaXNtaXNzJ1xyXG4+IHtcclxuICBjbGllbnQ/OiBDbGllbnRcclxuICBpc0NyZWF0aW5nOiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IENsaWVudEVkaXREcmF3ZXI6IEZDPENsaWVudEVkaXREcmF3ZXJQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IGlzT3Blbiwgb25EaXNtaXNzLCBjbGllbnQsIGlzQ3JlYXRpbmcgfSA9IHByb3BzXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8Q2xpZW50PihjbGllbnQgYXMgQ2xpZW50KVxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHNhdmUsIGlzTG9hZGluZzogaXNTYXZpbmcgfSA9IGNsaWVudFF1ZXJ5U2VydmljZS51c2VVcGRhdGUoKVxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGNyZWF0ZSwgaXNMb2FkaW5nOiBsb2FkaW5nQ3JlYXRpbmcgfSA9IGNsaWVudFF1ZXJ5U2VydmljZS51c2VDcmVhdGUoKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8UHJvbWlzZVJlamVjdGlvbkV2ZW50PigpXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXJMaXN0ZW5lcixcclxuICAgIHVucmVnaXN0ZXJMaXN0ZW5lcixcclxuICB9ID0gdXNlSGFuZGxlUmVqZWN0aW9uKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB1bnJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXHJcbiAgICB9XHJcbiAgfSwgW3NldEVycm9yXSlcclxuXHJcbiAgY29uc3QgdXBkYXRlUHJvZmlsZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHNhdmUoZm9ybURhdGEpXHJcbiAgICBuYXZpZ2F0ZShgJHtmb3JtRGF0YT8uaWR9L2NvbXBhbmllc2ApXHJcbiAgICBvbkRpc21pc3MoKVxyXG4gIH0sIFtmb3JtRGF0YV0pXHJcblxyXG4gIGNvbnN0IGNyZWF0ZVByb2ZpbGUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBzYXZlZENsaWVudCA9IGF3YWl0IGNyZWF0ZShmb3JtRGF0YSlcclxuICAgIGNsaWVudFF1ZXJ5U2VydmljZS5pbnZhbGlkYXRlUXVlcmllcygpXHJcbiAgICBuYXZpZ2F0ZShgJHtzYXZlZENsaWVudD8uY2xpZW50ZUlkfS9jb21wYW5pZXNgKVxyXG4gICAgb25EaXNtaXNzKClcclxuICB9LCBbZm9ybURhdGFdKVxyXG5cclxuICBjb25zdCBkaXNtaXNzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgb25EaXNtaXNzKClcclxuICB9LCBbb25EaXNtaXNzXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxFZGl0RHJhd2VyXHJcbiAgICAgIHRpdGxlPXtpc0NyZWF0aW5nID8gJ0FkaWNpb25hciBjbGllbnRlJyA6ICdBbHRlcmFyIGNsaWVudGUnfVxyXG4gICAgICBpc09wZW49e2lzT3Blbn1cclxuICAgICAgb25EaXNtaXNzPXtkaXNtaXNzfVxyXG4gICAgICBvblNhdmU9e2lzQ3JlYXRpbmcgPyBjcmVhdGVQcm9maWxlIDogdXBkYXRlUHJvZmlsZX1cclxuICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nIHx8IGxvYWRpbmdDcmVhdGluZ31cclxuICAgICAgbG9hZGluZz17aXNTYXZpbmcgfHwgbG9hZGluZ0NyZWF0aW5nfVxyXG4gICAgPlxyXG4gICAgICA8Q2xpZW50RWRpdEZvcm1cclxuICAgICAgICBmb3JtRGF0YT17Zm9ybURhdGF9XHJcbiAgICAgICAgb25DaGFuZ2U9e3NldEZvcm1EYXRhfVxyXG4gICAgICAgIGFwaUVycm9yPXtlcnJvcj8ucmVhc29uID8gZXJyb3I/LnJlYXNvbiBhcyBBcGlFcnJvciA6IHVuZGVmaW5lZH1cclxuICAgICAgLz5cclxuICAgIDwvRWRpdERyYXdlcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENsaWVudEVkaXREcmF3ZXJcclxuIl19