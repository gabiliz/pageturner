import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/AuthPageBoilerplate.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { FlexRow } from "/src/shared/components/index.ts?t=1701096626433";
const AuthPageBoilerplate = (props) => {
  return /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", verticalAlign: "center", children: [
    /* @__PURE__ */ jsxDEV("img", { src: "/login.png", className: pageStyles.image, loading: "lazy" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx",
      lineNumber: 6,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: props.children }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = AuthPageBoilerplate;
const pageStyles = mergeStyleSets({
  image: {
    objectFit: "cover",
    height: "100vh"
  }
});
export default AuthPageBoilerplate;
var _c;
$RefreshReg$(_c, "AuthPageBoilerplate");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/AuthPageBoilerplate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07QUFWTiwyQkFBdUI7QUFBUSxJQUFpQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWhELFNBQVNBLGVBQWU7QUFFeEIsTUFBTUMsc0JBQTJCQyxXQUFVO0FBQ3pDLFNBQ0UsdUJBQUMsV0FDQyxpQkFBZ0IsaUJBQ2hCLGVBQWMsVUFFZDtBQUFBLDJCQUFDLFNBQ0MsS0FBSSxjQUNKLFdBQVdDLFdBQVdDLE9BQ3RCLFNBQVEsVUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR2dCO0FBQUEsSUFFaEIsdUJBQUMsU0FDRUYsZ0JBQU1HLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLE9BWlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ0MsS0FqQktMO0FBbUJOLE1BQU1FLGFBQWFJLGVBQWU7QUFBQSxFQUNoQ0gsT0FBTztBQUFBLElBQ0xJLFdBQVc7QUFBQSxJQUNYQyxRQUFRO0FBQUEsRUFDVjtBQUNGLENBQUM7QUFFRCxlQUFlUjtBQUFtQixJQUFBSztBQUFBSSxhQUFBSixJQUFBIiwibmFtZXMiOlsiRmxleFJvdyIsIkF1dGhQYWdlQm9pbGVycGxhdGUiLCJwcm9wcyIsInBhZ2VTdHlsZXMiLCJpbWFnZSIsImNoaWxkcmVuIiwiX2MiLCJtZXJnZVN0eWxlU2V0cyIsIm9iamVjdEZpdCIsImhlaWdodCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1dGhQYWdlQm9pbGVycGxhdGUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdXRoL3BhZ2VzL0F1dGhQYWdlQm9pbGVycGxhdGUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgRmxleFJvdyB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5jb25zdCBBdXRoUGFnZUJvaWxlcnBsYXRlOiBGQyA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxGbGV4Um93XG4gICAgICBob3Jpem9udGFsQWxpZ249J3NwYWNlLWJldHdlZW4nXG4gICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXG4gICAgPlxuICAgICAgPGltZ1xuICAgICAgICBzcmM9XCIvbG9naW4ucG5nXCJcbiAgICAgICAgY2xhc3NOYW1lPXtwYWdlU3R5bGVzLmltYWdlfVxuICAgICAgICBsb2FkaW5nPSdsYXp5J1xuICAgICAgLz5cbiAgICAgIDxkaXY+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj48L2Rpdj5cbiAgICA8L0ZsZXhSb3c+XG4gIClcbn1cblxuY29uc3QgcGFnZVN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcbiAgaW1hZ2U6IHtcbiAgICBvYmplY3RGaXQ6ICdjb3ZlcicsXG4gICAgaGVpZ2h0OiAnMTAwdmgnLFxuICB9LFxufSlcblxuZXhwb3J0IGRlZmF1bHQgQXV0aFBhZ2VCb2lsZXJwbGF0ZVxuIl19