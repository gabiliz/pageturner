export default function formatCnpj(cnpj) {
  if (!cnpj)
    return "";
  return cnpj.replace(
    /(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/,
    "$1.$2.$3/$4-$5"
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm1hdENucGoudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZm9ybWF0Q25waiAoY25wajogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCFjbnBqKSByZXR1cm4gJydcbiAgcmV0dXJuIGNucGoucmVwbGFjZShcbiAgICAvKFxcZHsyfSkoXFxkezN9KShcXGR7M30pKFxcZHs0fSkoXFxkezJ9KS8sXG4gICAgJyQxLiQyLiQzLyQ0LSQ1JyxcbiAgKVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsV0FBWSxNQUFzQjtBQUN4RCxNQUFJLENBQUM7QUFBTSxXQUFPO0FBQ2xCLFNBQU8sS0FBSztBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=