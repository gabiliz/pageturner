import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/spinner/Spinner.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/spinner/Spinner.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import styled, { css, keyframes } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { SpinnerSizeEnum } from "/src/shared/enums/SpinnerSizeEnum.ts";
const Spinner = ({
  styles,
  size = SpinnerSizeEnum.medium
}) => {
  return /* @__PURE__ */ jsxDEV(SpinnerStyled, { styles, size }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/spinner/Spinner.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_c = Spinner;
export default Spinner;
const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;
const sizeCustom = css`
  ${(props) => {
  switch (props.size) {
    case 0:
      return css`
          width: 12px;
          height: 12px;
        `;
    case 1:
      return css`
          width: 16px;
          height: 16px;
        `;
    case 2:
      return css`
          width: 20px;
          height: 20px;
        `;
    case 3:
      return css`
          width: 28px;
          height: 28px;
        `;
  }
}}
`;
const SpinnerStyled = styled.div`
  border: 1.5px solid ${(props) => props.theme.colors.purple[300]};
  border-radius: 50%;
  border-top: 1.5px solid ${(props) => props.theme.colors.purple[800]};
  animation: ${spin} 2s linear infinite;
  align-self: center;

  ${(props) => props.styles !== void 0 ? props.styles : ""}

  ${sizeCustom}
`;
_c2 = SpinnerStyled;
var _c, _c2;
$RefreshReg$(_c, "Spinner");
$RefreshReg$(_c2, "SpinnerStyled");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/spinner/Spinner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0k7QUFYSiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixPQUFPQSxVQUEwREMsS0FBS0MsaUJBQWlCO0FBQ3ZGLFNBQVNDLHVCQUF1QjtBQU9oQyxNQUFNQyxVQUE2QkEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVFDLE9BQU9ILGdCQUFnQkk7QUFBTyxNQUFNO0FBQ2hGLFNBQ0UsdUJBQUMsaUJBQ0MsUUFDQSxRQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFYTtBQUdqQjtBQUFDQyxLQVBLSjtBQVNOLGVBQWVBO0FBRWYsTUFBTUssT0FBT1A7QUFBQUE7QUFBQUE7QUFBQUE7QUFLYixNQUFNUSxhQUFhVDtBQUFBQSxJQUNkVSxXQUFVO0FBQ1gsVUFBUUEsTUFBTUwsTUFBSTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxhQUFPTDtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSxJQUlULEtBQUs7QUFDSCxhQUFPQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSxJQUlULEtBQUs7QUFDSCxhQUFPQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSxJQUlULEtBQUs7QUFDSCxhQUFPQTtBQUFBQTtBQUFBQTtBQUFBQTtBQUFBQSxFQUlYO0FBQ0Y7QUFBQTtBQUlGLE1BQU1XLGdCQUFnQlosT0FBT2E7QUFBQUEsd0JBQ0pGLFdBQVVBLE1BQU1HLE1BQU1DLE9BQU9DLE9BQU8sR0FBRztBQUFBO0FBQUEsNEJBRW5DTCxXQUFVQSxNQUFNRyxNQUFNQyxPQUFPQyxPQUFPLEdBQUc7QUFBQSxlQUNyRFA7QUFBQUE7QUFBQUE7QUFBQUEsSUFHVkUsV0FBVUEsTUFBTU4sV0FBV1ksU0FBWU4sTUFBTU4sU0FBUztBQUFBO0FBQUEsSUFFdkRLO0FBQUFBO0FBQ0hRLE1BVktOO0FBQWEsSUFBQUosSUFBQVU7QUFBQUMsYUFBQVgsSUFBQTtBQUFBVyxhQUFBRCxLQUFBIiwibmFtZXMiOlsic3R5bGVkIiwiY3NzIiwia2V5ZnJhbWVzIiwiU3Bpbm5lclNpemVFbnVtIiwiU3Bpbm5lciIsInN0eWxlcyIsInNpemUiLCJtZWRpdW0iLCJfYyIsInNwaW4iLCJzaXplQ3VzdG9tIiwicHJvcHMiLCJTcGlubmVyU3R5bGVkIiwiZGl2IiwidGhlbWUiLCJjb2xvcnMiLCJwdXJwbGUiLCJ1bmRlZmluZWQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTcGlubmVyLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3NwaW5uZXIvU3Bpbm5lci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCwgeyBEZWZhdWx0VGhlbWUsIEZsYXR0ZW5JbnRlcnBvbGF0aW9uLCBUaGVtZVByb3BzLCBjc3MsIGtleWZyYW1lcyB9IGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xuaW1wb3J0IHsgU3Bpbm5lclNpemVFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvU3Bpbm5lclNpemVFbnVtJ1xuXG5pbnRlcmZhY2UgSVNwaW5uZXJQcm9wcyB7XG4gIHN0eWxlcz86IEZsYXR0ZW5JbnRlcnBvbGF0aW9uPFRoZW1lUHJvcHM8RGVmYXVsdFRoZW1lPj4sXG4gIHNpemU/OiBTcGlubmVyU2l6ZUVudW1cbn1cblxuY29uc3QgU3Bpbm5lcjogRkM8SVNwaW5uZXJQcm9wcz4gPSAoeyBzdHlsZXMsIHNpemUgPSBTcGlubmVyU2l6ZUVudW0ubWVkaXVtIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8U3Bpbm5lclN0eWxlZFxuICAgICAgc3R5bGVzPXtzdHlsZXN9XG4gICAgICBzaXplPXtzaXplfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3Bpbm5lclxuXG5jb25zdCBzcGluID0ga2V5ZnJhbWVzYFxuICAwJSB7IHRyYW5zZm9ybTogcm90YXRlKDBkZWcpOyB9XG4gIDEwMCUgeyB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpOyB9XG5gXG5cbmNvbnN0IHNpemVDdXN0b20gPSBjc3M8SVNwaW5uZXJQcm9wcz5gXG4gICR7KHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5zaXplKSB7XG4gICAgICBjYXNlIDA6XG4gICAgICAgIHJldHVybiBjc3NgXG4gICAgICAgICAgd2lkdGg6IDEycHg7XG4gICAgICAgICAgaGVpZ2h0OiAxMnB4O1xuICAgICAgICBgXG4gICAgICBjYXNlIDE6XG4gICAgICAgIHJldHVybiBjc3NgXG4gICAgICAgICAgd2lkdGg6IDE2cHg7XG4gICAgICAgICAgaGVpZ2h0OiAxNnB4O1xuICAgICAgICBgXG4gICAgICBjYXNlIDI6XG4gICAgICAgIHJldHVybiBjc3NgXG4gICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgICBgXG4gICAgICBjYXNlIDM6XG4gICAgICAgIHJldHVybiBjc3NgXG4gICAgICAgICAgd2lkdGg6IDI4cHg7XG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xuICAgICAgICBgXG4gICAgfVxuICB9XG59XG5gXG5cbmNvbnN0IFNwaW5uZXJTdHlsZWQgPSBzdHlsZWQuZGl2PElTcGlubmVyUHJvcHM+YFxuICBib3JkZXI6IDEuNXB4IHNvbGlkICR7KHByb3BzKSA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzMwMF19O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJvcmRlci10b3A6IDEuNXB4IHNvbGlkICR7KHByb3BzKSA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzgwMF19O1xuICBhbmltYXRpb246ICR7c3Bpbn0gMnMgbGluZWFyIGluZmluaXRlO1xuICBhbGlnbi1zZWxmOiBjZW50ZXI7XG5cbiAgJHsocHJvcHMpID0+IHByb3BzLnN0eWxlcyAhPT0gdW5kZWZpbmVkID8gcHJvcHMuc3R5bGVzIDogJyd9XG5cbiAgJHtzaXplQ3VzdG9tfVxuYFxuIl19