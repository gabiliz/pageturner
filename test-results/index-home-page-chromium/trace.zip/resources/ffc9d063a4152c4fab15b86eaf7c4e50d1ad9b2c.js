import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/fileDisplay/SelectedFileDisplay.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text, IconButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { FileDisplay } from "/src/shared/components/index.ts?t=1701096626433";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { getFileSize } from "/src/shared/utils/index.ts";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
import FlexItem from "/src/shared/components/FlexBox/FlexItem.tsx";
function getFileExtension(filename) {
  return `.${filename.split(".").pop()}`;
}
const SelectedFileDisplay = (props) => {
  _s();
  const colors = useThemeColors();
  const {
    selectedFile,
    removeFile,
    width
  } = props;
  const fileExtension = getFileExtension(selectedFile.name);
  return /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", verticalAlign: "center", styles: {
    backgroundColor: colors.gray[100],
    width,
    height: 32
  }, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { styles: {
      width: 200,
      padding: 12
    }, children: /* @__PURE__ */ jsxDEV(FileDisplay, { name: selectedFile.name, extension: fileExtension }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 35,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { styles: {
      width: 100,
      padding: 12
    }, children: /* @__PURE__ */ jsxDEV(Text, { variant: "mediumPlus", styles: {
      root: {
        fontSize: 12
      }
    }, children: selectedFile.size ? getFileSize(selectedFile.size) : "" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 41,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { styles: {
      margin: 7
    }, children: /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
      iconName: "Delete"
    }, title: "Excluir", ariaLabel: "Excluir", disabled: false, onClick: removeFile }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 52,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(SelectedFileDisplay, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
_c = SelectedFileDisplay;
export default SelectedFileDisplay;
var _c;
$RefreshReg$(_c, "SelectedFileDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/fileDisplay/SelectedFileDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NROzs7Ozs7Ozs7Ozs7Ozs7O0FBcENSLFNBQ0VBLE1BQ0FDLGtCQUNLO0FBRVAsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxjQUFjO0FBUXJCLFNBQVNDLGlCQUFrQkMsVUFBa0I7QUFDM0MsU0FBUSxJQUFHQSxTQUFTQyxNQUFNLEdBQUcsRUFBRUMsSUFBSTtBQUNyQztBQUVBLE1BQU1DLHNCQUFxREMsV0FBVTtBQUFBQyxLQUFBO0FBQ25FLFFBQU1DLFNBQVNYLGVBQWU7QUFDOUIsUUFBTTtBQUFBLElBQUVZO0FBQUFBLElBQWNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQU0sSUFBSUw7QUFDNUMsUUFBTU0sZ0JBQWdCWCxpQkFBaUJRLGFBQWFJLElBQUk7QUFFeEQsU0FDRSx1QkFBQyxXQUNDLGlCQUFnQixpQkFDaEIsZUFBYyxVQUNkLFFBQVE7QUFBQSxJQUFFQyxpQkFBaUJOLE9BQU9PLEtBQUssR0FBRztBQUFBLElBQUdKO0FBQUFBLElBQWNLLFFBQVE7QUFBQSxFQUFHLEdBRXRFO0FBQUEsMkJBQUMsWUFBUyxRQUFRO0FBQUEsTUFDaEJMLE9BQU87QUFBQSxNQUNQTSxTQUFTO0FBQUEsSUFDWCxHQUNFLGlDQUFDLGVBQ0MsTUFBTVIsYUFBYUksTUFDbkIsV0FBV0QsaUJBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUUyQixLQU43QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFlBQVMsUUFBUTtBQUFBLE1BQUVELE9BQU87QUFBQSxNQUFLTSxTQUFTO0FBQUEsSUFBRyxHQUMxQyxpQ0FBQyxRQUNDLFNBQVEsY0FDUixRQUFRO0FBQUEsTUFDTkMsTUFBTTtBQUFBLFFBQ0pDLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixHQUVDVix1QkFBYVcsT0FBT3RCLFlBQVlXLGFBQWFXLElBQUksSUFBSSxNQVJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFlBQVMsUUFBUTtBQUFBLE1BQUVDLFFBQVE7QUFBQSxJQUFFLEdBQzVCLGlDQUFDLGNBQ0MsV0FBVztBQUFBLE1BQUVDLFVBQVU7QUFBQSxJQUFTLEdBQ2hDLE9BQU0sV0FDTixXQUFVLFdBQ1YsVUFBVSxPQUNWLFNBQVNaLGNBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtzQixLQU54QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBO0FBRUo7QUFBQ0gsR0EzQ0tGLHFCQUFpRDtBQUFBLFVBQ3RDUixjQUFjO0FBQUE7QUFBQTBCLEtBRHpCbEI7QUE2Q04sZUFBZUE7QUFBbUIsSUFBQWtCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUZXh0IiwiSWNvbkJ1dHRvbiIsIkZpbGVEaXNwbGF5IiwidXNlVGhlbWVDb2xvcnMiLCJnZXRGaWxlU2l6ZSIsIkZsZXhSb3ciLCJGbGV4SXRlbSIsImdldEZpbGVFeHRlbnNpb24iLCJmaWxlbmFtZSIsInNwbGl0IiwicG9wIiwiU2VsZWN0ZWRGaWxlRGlzcGxheSIsInByb3BzIiwiX3MiLCJjb2xvcnMiLCJzZWxlY3RlZEZpbGUiLCJyZW1vdmVGaWxlIiwid2lkdGgiLCJmaWxlRXh0ZW5zaW9uIiwibmFtZSIsImJhY2tncm91bmRDb2xvciIsImdyYXkiLCJoZWlnaHQiLCJwYWRkaW5nIiwicm9vdCIsImZvbnRTaXplIiwic2l6ZSIsIm1hcmdpbiIsImljb25OYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWxlY3RlZEZpbGVEaXNwbGF5LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2ZpbGVEaXNwbGF5L1NlbGVjdGVkRmlsZURpc3BsYXkudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgVGV4dCxcbiAgSWNvbkJ1dHRvbixcbn0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEZpbGVEaXNwbGF5IH0gZnJvbSAnLi4nXG5pbXBvcnQgeyB1c2VUaGVtZUNvbG9ycyB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuaW1wb3J0IHsgZ2V0RmlsZVNpemUgfSBmcm9tICcuLi8uLi91dGlscydcbmltcG9ydCBGbGV4Um93IGZyb20gJy4vLi4vRmxleEJveC9GbGV4Um93J1xuaW1wb3J0IEZsZXhJdGVtIGZyb20gJy4vLi4vRmxleEJveC9GbGV4SXRlbSdcblxuZXhwb3J0IGludGVyZmFjZSBTZWxlY3RlZEZpbGVEaXNwbGF5UHJvcHMge1xuICBzZWxlY3RlZEZpbGU6IEZpbGUsXG4gIHdpZHRoOiBudW1iZXIsXG4gIHJlbW92ZUZpbGU6ICgpID0+IHZvaWRcbn1cblxuZnVuY3Rpb24gZ2V0RmlsZUV4dGVuc2lvbiAoZmlsZW5hbWU6IHN0cmluZykge1xuICByZXR1cm4gYC4ke2ZpbGVuYW1lLnNwbGl0KCcuJykucG9wKCl9YFxufVxuXG5jb25zdCBTZWxlY3RlZEZpbGVEaXNwbGF5OiBGQzxTZWxlY3RlZEZpbGVEaXNwbGF5UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgY29uc3QgeyBzZWxlY3RlZEZpbGUsIHJlbW92ZUZpbGUsIHdpZHRoIH0gPSBwcm9wc1xuICBjb25zdCBmaWxlRXh0ZW5zaW9uID0gZ2V0RmlsZUV4dGVuc2lvbihzZWxlY3RlZEZpbGUubmFtZSlcblxuICByZXR1cm4gKFxuICAgIDxGbGV4Um93XG4gICAgICBob3Jpem9udGFsQWxpZ249J3NwYWNlLWJldHdlZW4nXG4gICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXG4gICAgICBzdHlsZXM9e3sgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuZ3JheVsxMDBdLCB3aWR0aDogd2lkdGgsIGhlaWdodDogMzIgfX1cbiAgICA+XG4gICAgICA8RmxleEl0ZW0gc3R5bGVzPXt7XG4gICAgICAgIHdpZHRoOiAyMDAsXG4gICAgICAgIHBhZGRpbmc6IDEyLFxuICAgICAgfX0+XG4gICAgICAgIDxGaWxlRGlzcGxheVxuICAgICAgICAgIG5hbWU9e3NlbGVjdGVkRmlsZS5uYW1lfVxuICAgICAgICAgIGV4dGVuc2lvbj17ZmlsZUV4dGVuc2lvbn1cbiAgICAgICAgLz5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0gc3R5bGVzPXt7IHdpZHRoOiAxMDAsIHBhZGRpbmc6IDEyIH19PlxuICAgICAgICA8VGV4dFxuICAgICAgICAgIHZhcmlhbnQ9XCJtZWRpdW1QbHVzXCJcbiAgICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgZm9udFNpemU6IDEyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge3NlbGVjdGVkRmlsZS5zaXplID8gZ2V0RmlsZVNpemUoc2VsZWN0ZWRGaWxlLnNpemUpIDogJyd9XG4gICAgICAgIDwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0gc3R5bGVzPXt7IG1hcmdpbjogNyB9fT5cbiAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdEZWxldGUnIH19XG4gICAgICAgICAgdGl0bGU9XCJFeGNsdWlyXCJcbiAgICAgICAgICBhcmlhTGFiZWw9XCJFeGNsdWlyXCJcbiAgICAgICAgICBkaXNhYmxlZD17ZmFsc2V9XG4gICAgICAgICAgb25DbGljaz17cmVtb3ZlRmlsZX1cbiAgICAgICAgLz5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgPC9GbGV4Um93PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFNlbGVjdGVkRmlsZURpc3BsYXlcbiJdfQ==