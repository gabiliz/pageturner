import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { MessageBarType, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useContext = __vite__cjsImport5_react["useContext"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useMemo = __vite__cjsImport5_react["useMemo"]; const useState = __vite__cjsImport5_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { AppPage, FlexColumn, FlexItem, FlexRow, PageSubtitle, PageTitle, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { RiskFormForwardAnswerActions, RiskFormForwardAnswerCard, RiskFormForwardAnswerCheckModal } from "/src/modules/audit/riskForm/components/index.ts?t=1701096626433";
import RiskFormForwardProgressIndicator from "/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx?t=1701096626433";
import { riskFormForwardService } from "/src/modules/audit/riskForm/services/index.ts";
const RiskFormForwardAnswer = () => {
  _s();
  const theme = useTheme();
  const {
    isLoading: globalLoading,
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  const location = useLocation();
  const {
    colors,
    fontWeight
  } = useTheme();
  const navigate = useNavigate();
  const {
    showNotification
  } = useNotifications();
  const state = useMemo(() => {
    return location.state;
  }, [location]);
  const [isModalOpen, {
    setTrue: openModal,
    setFalse: closeModal
  }] = useBoolean(false);
  const {
    form,
    email
  } = state;
  const [answers, setAnswers] = useState({
    email,
    formularioId: form.id,
    termo: false,
    perguntas: form.perguntas.map((question) => {
      return {
        id: question.id,
        resposta: question.resposta,
        comentario: question.comentario ?? "",
        index: question.index
      };
    })
  });
  useEffect(() => {
    setAnswers({
      email,
      formularioId: form.id,
      termo: false,
      perguntas: form.perguntas?.map((question) => {
        return {
          id: question.id,
          resposta: question.resposta,
          comentario: question.comentario ?? "",
          index: question.index
        };
      })
    });
  }, [email, form]);
  const handleAnswerChange = useCallback((answer, key) => {
    return (_, eventValue) => {
      const answerIndex = answers.perguntas.findIndex((asw) => asw.id === answer.id);
      const localAnswer = [...answers.perguntas];
      localAnswer.splice(answerIndex, 1, {
        ...answer,
        [key]: typeof eventValue !== "string" ? parseInt(eventValue?.key) : eventValue
      });
      setAnswers({
        ...answers,
        perguntas: localAnswer
      });
    };
  }, [answers]);
  const answerQuestions = useCallback(async () => {
    try {
      setGlobalLoading(true);
      await riskFormForwardService.sendAnswer(answers);
      setGlobalLoading(false);
      showNotification({
        message: "Resposta enviada com sucesso!",
        type: MessageBarType.success,
        timeout: 1e4
      });
      navigate(-1);
    } catch (error) {
      setGlobalLoading(false);
      const er = error;
      er.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error
        });
      });
    }
  }, [answers]);
  const saveDraft = useCallback(async () => {
    try {
      setGlobalLoading(true);
      await riskFormForwardService.saveDraft(answers);
      setGlobalLoading(false);
      showNotification({
        message: "Rascunho enviado com sucesso!",
        type: MessageBarType.success,
        timeout: 1e4
      });
      navigate(-1);
    } catch (error) {
      setGlobalLoading(false);
      const er = error;
      er.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error
        });
      });
    }
  }, [answers]);
  const handleCheckboxClick = useCallback((_, checked) => {
    setAnswers((prevState) => {
      return {
        ...prevState,
        termo: checked
      };
    });
  }, []);
  const cancelSendAnswers = useCallback(() => {
    setAnswers((prevState) => {
      return {
        ...prevState,
        termo: false
      };
    });
    closeModal();
  }, []);
  return /* @__PURE__ */ jsxDEV(AppPage, { renderTitle: () => /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "stretch", gap: 8, styles: {
    position: "sticky",
    top: 0,
    left: 0,
    backgroundColor: "#fff",
    zIndex: 9e3
  }, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", children: [
      /* @__PURE__ */ jsxDEV(PageTitle, { children: `Responder ${form.nomeFormulario}` }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
        lineNumber: 157,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(RiskFormForwardAnswerActions, { onGoBack: () => navigate(-1), onSave: openModal, onDraft: saveDraft, disabled: answers.perguntas.some((answer) => answer.resposta === void 0 || answer.resposta === 4), loading: globalLoading }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
        lineNumber: 158,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 156,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(PageSubtitle, { children: form.codigoEnvio ? `Código de envio: ${form.codigoEnvio}` : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 160,
      columnNumber: 11
    }, this),
    form.empresas.length > 0 && /* @__PURE__ */ jsxDEV(FlexRow, { styles: {
      position: "sticky",
      top: 20
    }, children: /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(TooltipHost, { content: `Empresas: ${form.empresas.map((cmp) => cmp?.empresa.razaoSocial).join(", ")}`, children: /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        fontWeight: fontWeight.semibold,
        color: colors.gray[800],
        maxWidth: 500,
        wordWrap: "anywhere",
        overflowWrap: "anywhere"
      }
    }, children: `Empresas: ${form.empresas.map((cmp) => cmp?.empresa.razaoSocial).join(", ")}` }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 167,
      columnNumber: 19
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 166,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 165,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 161,
      columnNumber: 40
    }, this),
    /* @__PURE__ */ jsxDEV(RiskFormForwardProgressIndicator, { answers }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 181,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
    lineNumber: 149,
    columnNumber: 38
  }, this), isTitleFixed: true, hasBackground: true, children: [
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 16, styles: {
      padding: `0 ${theme.spacing.xs}`
    }, children: answers.perguntas?.sort((a, b) => a.index > b.index ? 1 : -1).map((question) => /* @__PURE__ */ jsxDEV(RiskFormForwardAnswerCard, { answer: question, questions: form.perguntas, onAnswerChange: handleAnswerChange }, question.id, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 186,
      columnNumber: 112
    }, this)) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV(RiskFormForwardAnswerCheckModal, { isOpen: isModalOpen, onDismiss: cancelSendAnswers, isChecked: answers.termo, onCheckboxChange: handleCheckboxClick, sendAnswers: answerQuestions }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
      lineNumber: 188,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx",
    lineNumber: 149,
    columnNumber: 10
  }, this);
};
_s(RiskFormForwardAnswer, "rZnoYLMhI1eMT2UiNrsOYsHsJqg=", false, function() {
  return [useTheme, useLocation, useTheme, useNavigate, useNotifications, useBoolean];
});
_c = RiskFormForwardAnswer;
export default RiskFormForwardAnswer;
var _c;
$RefreshReg$(_c, "RiskFormForwardAnswer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForwardAnswer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUtZOzs7Ozs7Ozs7Ozs7Ozs7O0FBaktaLFNBQTZCQSxnQkFBZ0JDLFlBQVk7QUFDekQsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQWFDLGFBQWFDLFlBQVlDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUMxRSxTQUFTQyxhQUFhQyxtQkFBbUI7QUFFekMsU0FBU0MsU0FBU0MsWUFBWUMsVUFBVUMsU0FBU0MsY0FBY0MsV0FBV0MsbUJBQW1CO0FBQzdGLFNBQVNDLDBCQUEwQjtBQUVuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDhCQUE4QkMsMkJBQTJCQyx1Q0FBdUM7QUFDekcsT0FBT0Msc0NBQXNDO0FBQzdDLFNBQVNDLDhCQUE4QjtBQU92QyxNQUFNQyx3QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNQyxRQUFRVCxTQUFTO0FBQ3ZCLFFBQU07QUFBQSxJQUFFVSxXQUFXQztBQUFBQSxJQUFlQyxjQUFjQztBQUFBQSxFQUFpQixJQUFJM0IsV0FBV2Esa0JBQWtCO0FBQ2xHLFFBQU1lLFdBQVd4QixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFeUI7QUFBQUEsSUFBUUM7QUFBQUEsRUFBVyxJQUFJaEIsU0FBUztBQUN4QyxRQUFNaUIsV0FBVzFCLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUUyQjtBQUFBQSxFQUFpQixJQUFJakIsaUJBQWlCO0FBQzlDLFFBQU1rQixRQUFRL0IsUUFBUSxNQUFNO0FBQzFCLFdBQU8wQixTQUFTSztBQUFBQSxFQUNsQixHQUFHLENBQUNMLFFBQVEsQ0FBQztBQUNiLFFBQU0sQ0FDSk0sYUFDQTtBQUFBLElBQUVDLFNBQVNDO0FBQUFBLElBQVdDLFVBQVVDO0FBQUFBLEVBQVcsQ0FBQyxJQUMxQ3hDLFdBQVcsS0FBSztBQUNwQixRQUFNO0FBQUEsSUFBRXlDO0FBQUFBLElBQU1DO0FBQUFBLEVBQU0sSUFBSVA7QUFDeEIsUUFBTSxDQUFDUSxTQUFTQyxVQUFVLElBQUl2QyxTQUE4QjtBQUFBLElBQzFEcUM7QUFBQUEsSUFDQUcsY0FBY0osS0FBS0s7QUFBQUEsSUFDbkJDLE9BQU87QUFBQSxJQUNQQyxXQUFXUCxLQUFLTyxVQUFVQyxJQUFJQyxjQUFZO0FBQ3hDLGFBQU87QUFBQSxRQUNMSixJQUFJSSxTQUFTSjtBQUFBQSxRQUNiSyxVQUFVRCxTQUFTQztBQUFBQSxRQUNuQkMsWUFBWUYsU0FBU0UsY0FBYztBQUFBLFFBQ25DQyxPQUFPSCxTQUFTRztBQUFBQSxNQUNsQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUVEbEQsWUFBVSxNQUFNO0FBQ2R5QyxlQUNFO0FBQUEsTUFDRUY7QUFBQUEsTUFDQUcsY0FBY0osS0FBS0s7QUFBQUEsTUFDbkJDLE9BQU87QUFBQSxNQUNQQyxXQUFXUCxLQUFLTyxXQUFXQyxJQUFJQyxjQUFZO0FBQ3pDLGVBQU87QUFBQSxVQUNMSixJQUFJSSxTQUFTSjtBQUFBQSxVQUNiSyxVQUFVRCxTQUFTQztBQUFBQSxVQUNuQkMsWUFBWUYsU0FBU0UsY0FBYztBQUFBLFVBQ25DQyxPQUFPSCxTQUFTRztBQUFBQSxRQUNsQjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDWCxPQUFPRCxJQUFJLENBQUM7QUFFaEIsUUFBTWEscUJBQXFCckQsWUFBWSxDQUFDc0QsUUFBd0JDLFFBQWdCO0FBQzlFLFdBQU8sQ0FBQ0MsR0FBYUMsZUFBNkM7QUFDaEUsWUFBTUMsY0FBY2hCLFFBQVFLLFVBQVVZLFVBQVVDLFNBQU9BLElBQUlmLE9BQU9TLE9BQU9ULEVBQUU7QUFDM0UsWUFBTWdCLGNBQWMsQ0FBQyxHQUFHbkIsUUFBUUssU0FBUztBQUN6Q2Msa0JBQVlDLE9BQ1ZKLGFBQ0EsR0FDQTtBQUFBLFFBQ0UsR0FBR0o7QUFBQUEsUUFDSCxDQUFDQyxHQUFHLEdBQUcsT0FBT0UsZUFBZSxXQUN6Qk0sU0FBU04sWUFBWUYsR0FBYSxJQUNsQ0U7QUFBQUEsTUFDTixDQUNGO0FBQ0FkLGlCQUFXO0FBQUEsUUFDVCxHQUFHRDtBQUFBQSxRQUNISyxXQUFXYztBQUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUNuQixPQUFPLENBQUM7QUFFWixRQUFNc0Isa0JBQWtCaEUsWUFBWSxZQUFZO0FBQzlDLFFBQUk7QUFDRjRCLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU1QLHVCQUF1QjRDLFdBQVd2QixPQUFPO0FBQy9DZCx1QkFBaUIsS0FBSztBQUN0QkssdUJBQWlCO0FBQUEsUUFDZmlDLFNBQVM7QUFBQSxRQUNUQyxNQUFNdEUsZUFBZXVFO0FBQUFBLFFBQ3JCQyxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQ0RyQyxlQUFTLEVBQUU7QUFBQSxJQUNiLFNBQVNzQyxPQUFQO0FBQ0ExQyx1QkFBaUIsS0FBSztBQUN0QixZQUFNMkMsS0FBS0Q7QUFDWEMsU0FBR0MsUUFBUUMsVUFBVUMsUUFBU0Msa0JBQWlCO0FBQzdDMUMseUJBQWlCO0FBQUEsVUFDZmlDLFNBQVNTLGFBQWFUO0FBQUFBLFVBQ3RCQyxNQUFNdEUsZUFBZXlFO0FBQUFBLFFBQ3ZCLENBQUM7QUFBQSxNQUNILENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUM1QixPQUFPLENBQUM7QUFFWixRQUFNa0MsWUFBWTVFLFlBQVksWUFBWTtBQUN4QyxRQUFJO0FBQ0Y0Qix1QkFBaUIsSUFBSTtBQUNyQixZQUFNUCx1QkFBdUJ1RCxVQUFVbEMsT0FBTztBQUM5Q2QsdUJBQWlCLEtBQUs7QUFDdEJLLHVCQUFpQjtBQUFBLFFBQ2ZpQyxTQUFTO0FBQUEsUUFDVEMsTUFBTXRFLGVBQWV1RTtBQUFBQSxRQUNyQkMsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUNEckMsZUFBUyxFQUFFO0FBQUEsSUFDYixTQUFTc0MsT0FBUDtBQUNBMUMsdUJBQWlCLEtBQUs7QUFDdEIsWUFBTTJDLEtBQUtEO0FBQ1hDLFNBQUdDLFFBQVFDLFVBQVVDLFFBQVNDLGtCQUFpQjtBQUM3QzFDLHlCQUFpQjtBQUFBLFVBQ2ZpQyxTQUFTUyxhQUFhVDtBQUFBQSxVQUN0QkMsTUFBTXRFLGVBQWV5RTtBQUFBQSxRQUN2QixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxDQUFDNUIsT0FBTyxDQUFDO0FBRVosUUFBTW1DLHNCQUFzQjdFLFlBQVksQ0FBQ3dELEdBQVlzQixZQUFrQztBQUNyRm5DLGVBQVdvQyxlQUFhO0FBQ3RCLGFBQU87QUFBQSxRQUFFLEdBQUdBO0FBQUFBLFFBQVdqQyxPQUFPZ0M7QUFBQUEsTUFBbUI7QUFBQSxJQUNuRCxDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFFTCxRQUFNRSxvQkFBb0JoRixZQUFZLE1BQU07QUFDMUMyQyxlQUFXb0MsZUFBYTtBQUN0QixhQUFPO0FBQUEsUUFBRSxHQUFHQTtBQUFBQSxRQUFXakMsT0FBTztBQUFBLE1BQU07QUFBQSxJQUN0QyxDQUFDO0FBQ0RQLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQUVMLFNBQ0UsdUJBQUMsV0FDQyxhQUNFLE1BQU0sdUJBQUMsY0FDTCxpQkFBZ0IsV0FDaEIsS0FBSyxHQUNMLFFBQVE7QUFBQSxJQUNOMEMsVUFBVTtBQUFBLElBQ1ZDLEtBQUs7QUFBQSxJQUNMQyxNQUFNO0FBQUEsSUFDTkMsaUJBQWlCO0FBQUEsSUFDakJDLFFBQVE7QUFBQSxFQUNWLEdBRUE7QUFBQSwyQkFBQyxXQUFRLGlCQUFnQixpQkFDdkI7QUFBQSw2QkFBQyxhQUFZLHVCQUFZN0MsS0FBSzhDLG9CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStDO0FBQUEsTUFDL0MsdUJBQUMsZ0NBQ0MsVUFBVSxNQUFNdEQsU0FBUyxFQUFFLEdBQzNCLFFBQVFLLFdBQ1IsU0FBU3VDLFdBQ1QsVUFBVWxDLFFBQVFLLFVBQVV3QyxLQUFLakMsWUFBVUEsT0FBT0osYUFBYXNDLFVBQWFsQyxPQUFPSixhQUFhLENBQUMsR0FDakcsU0FBU3hCLGlCQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLeUI7QUFBQSxTQVAzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLGdCQUFjYyxlQUFLaUQsY0FBZSxvQkFBbUJqRCxLQUFLaUQsZ0JBQWdCRCxVQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFGO0FBQUEsSUFDcEZoRCxLQUFLa0QsU0FBU0MsU0FBUyxLQUN0Qix1QkFBQyxXQUFRLFFBQVE7QUFBQSxNQUFFVixVQUFVO0FBQUEsTUFBVUMsS0FBSztBQUFBLElBQUcsR0FDN0MsaUNBQUMsWUFDQyxpQ0FBQyxlQUNDLFNBQVUsYUFBWTFDLEtBQUtrRCxTQUFTMUMsSUFBSTRDLFNBQU9BLEtBQUtDLFFBQVFDLFdBQVcsRUFBRUMsS0FBSyxJQUFJLEtBRWxGLGlDQUFDLFFBQ0MsUUFBUTtBQUFBLE1BQ05DLE1BQU07QUFBQSxRQUNKakUsWUFBWUEsV0FBV2tFO0FBQUFBLFFBQ3ZCQyxPQUFPcEUsT0FBT3FFLEtBQUssR0FBRztBQUFBLFFBQ3RCQyxVQUFVO0FBQUEsUUFDVkMsVUFBVTtBQUFBLFFBQ1ZDLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0YsR0FFRSx1QkFBWTlELEtBQUtrRCxTQUFTMUMsSUFBSTRDLFNBQU9BLEtBQUtDLFFBQVFDLFdBQVcsRUFBRUMsS0FBSyxJQUFJLE9BWDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFRix1QkFBQyxvQ0FDQyxXQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDbUI7QUFBQSxPQTlDZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0ROLEdBRUYsY0FBWSxNQUNaLGVBQWEsTUFFYjtBQUFBLDJCQUFDLGNBQ0MsS0FBTSxJQUNOLFFBQVE7QUFBQSxNQUNOUSxTQUFVLEtBQUkvRSxNQUFNZ0YsUUFBUUM7QUFBQUEsSUFDOUIsR0FFQy9ELGtCQUFRSyxXQUFXMkQsS0FBSyxDQUFDQyxHQUFHQyxNQUFPRCxFQUFFdkQsUUFBb0J3RCxFQUFFeEQsUUFBbUIsSUFBSSxFQUFFLEVBQ2xGSixJQUFJQyxjQUFZLHVCQUFDLDZCQUVoQixRQUFRQSxVQUNSLFdBQVdULEtBQUtPLFdBQ2hCLGdCQUFnQk0sc0JBSFhKLFNBQVNKLElBREM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlvQixDQUNuQyxLQVpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0NWLGVBQWUsdUJBQUMsbUNBQ2YsUUFBUUEsYUFDUixXQUFXNkMsbUJBQ1gsV0FBV3RDLFFBQVFJLE9BQ25CLGtCQUFrQitCLHFCQUNsQixhQUFhYixtQkFMQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2U7QUFBQSxPQTFFakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRFQTtBQUVKO0FBQUN6QyxHQTlNS0QsdUJBQXlCO0FBQUEsVUFDZlAsVUFFR1YsYUFDY1UsVUFDZFQsYUFDWVUsa0JBT3pCakIsVUFBVTtBQUFBO0FBQUE4RyxLQWJWdkY7QUFnTk4sZUFBZUE7QUFBcUIsSUFBQXVGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJNZXNzYWdlQmFyVHlwZSIsIlRleHQiLCJ1c2VCb29sZWFuIiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsIkFwcFBhZ2UiLCJGbGV4Q29sdW1uIiwiRmxleEl0ZW0iLCJGbGV4Um93IiwiUGFnZVN1YnRpdGxlIiwiUGFnZVRpdGxlIiwiVG9vbHRpcEhvc3QiLCJMb2FkaW5nRGF0YUNvbnRleHQiLCJ1c2VUaGVtZSIsInVzZU5vdGlmaWNhdGlvbnMiLCJSaXNrRm9ybUZvcndhcmRBbnN3ZXJBY3Rpb25zIiwiUmlza0Zvcm1Gb3J3YXJkQW5zd2VyQ2FyZCIsIlJpc2tGb3JtRm9yd2FyZEFuc3dlckNoZWNrTW9kYWwiLCJSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvciIsInJpc2tGb3JtRm9yd2FyZFNlcnZpY2UiLCJSaXNrRm9ybUZvcndhcmRBbnN3ZXIiLCJfcyIsInRoZW1lIiwiaXNMb2FkaW5nIiwiZ2xvYmFsTG9hZGluZyIsInNldElzTG9hZGluZyIsInNldEdsb2JhbExvYWRpbmciLCJsb2NhdGlvbiIsImNvbG9ycyIsImZvbnRXZWlnaHQiLCJuYXZpZ2F0ZSIsInNob3dOb3RpZmljYXRpb24iLCJzdGF0ZSIsImlzTW9kYWxPcGVuIiwic2V0VHJ1ZSIsIm9wZW5Nb2RhbCIsInNldEZhbHNlIiwiY2xvc2VNb2RhbCIsImZvcm0iLCJlbWFpbCIsImFuc3dlcnMiLCJzZXRBbnN3ZXJzIiwiZm9ybXVsYXJpb0lkIiwiaWQiLCJ0ZXJtbyIsInBlcmd1bnRhcyIsIm1hcCIsInF1ZXN0aW9uIiwicmVzcG9zdGEiLCJjb21lbnRhcmlvIiwiaW5kZXgiLCJoYW5kbGVBbnN3ZXJDaGFuZ2UiLCJhbnN3ZXIiLCJrZXkiLCJfIiwiZXZlbnRWYWx1ZSIsImFuc3dlckluZGV4IiwiZmluZEluZGV4IiwiYXN3IiwibG9jYWxBbnN3ZXIiLCJzcGxpY2UiLCJwYXJzZUludCIsImFuc3dlclF1ZXN0aW9ucyIsInNlbmRBbnN3ZXIiLCJtZXNzYWdlIiwidHlwZSIsInN1Y2Nlc3MiLCJ0aW1lb3V0IiwiZXJyb3IiLCJlciIsImVycm9ycyIsIm1lc3NhZ2VzIiwiZm9yRWFjaCIsImVycm9yTWVzc2FnZSIsInNhdmVEcmFmdCIsImhhbmRsZUNoZWNrYm94Q2xpY2siLCJjaGVja2VkIiwicHJldlN0YXRlIiwiY2FuY2VsU2VuZEFuc3dlcnMiLCJwb3NpdGlvbiIsInRvcCIsImxlZnQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJ6SW5kZXgiLCJub21lRm9ybXVsYXJpbyIsInNvbWUiLCJ1bmRlZmluZWQiLCJjb2RpZ29FbnZpbyIsImVtcHJlc2FzIiwibGVuZ3RoIiwiY21wIiwiZW1wcmVzYSIsInJhemFvU29jaWFsIiwiam9pbiIsInJvb3QiLCJzZW1pYm9sZCIsImNvbG9yIiwiZ3JheSIsIm1heFdpZHRoIiwid29yZFdyYXAiLCJvdmVyZmxvd1dyYXAiLCJwYWRkaW5nIiwic3BhY2luZyIsInhzIiwic29ydCIsImEiLCJiIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSaXNrRm9ybUZvcndhcmRBbnN3ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9yaXNrRm9ybS9wYWdlcy9SaXNrRm9ybUZvcndhcmRBbnN3ZXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNob2ljZUdyb3VwT3B0aW9uLCBNZXNzYWdlQmFyVHlwZSwgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcclxuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IFJpc2tGb3JtQW5zd2VyLCBSaXNrRm9ybUFuc3dlckdyb3VwLCBSaXNrRm9ybUZvcndhcmQgfSBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vUmlza0Zvcm0nXHJcbmltcG9ydCB7IEFwcFBhZ2UsIEZsZXhDb2x1bW4sIEZsZXhJdGVtLCBGbGV4Um93LCBQYWdlU3VidGl0bGUsIFBhZ2VUaXRsZSwgVG9vbHRpcEhvc3QgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IHsgTG9hZGluZ0RhdGFDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbnRleHQvTG9hZGluZ0RhdGFDb250ZXh0J1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lcnJvcnMnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyB1c2VOb3RpZmljYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3N0b3JlL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucydcclxuaW1wb3J0IHsgUmlza0Zvcm1Gb3J3YXJkQW5zd2VyQWN0aW9ucywgUmlza0Zvcm1Gb3J3YXJkQW5zd2VyQ2FyZCwgUmlza0Zvcm1Gb3J3YXJkQW5zd2VyQ2hlY2tNb2RhbCB9IGZyb20gJy4uL2NvbXBvbmVudHMnXHJcbmltcG9ydCBSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvciBmcm9tICcuLi9jb21wb25lbnRzL1Jpc2tGb3JtRm9yd2FyZFByb2dyZXNzSW5kaWNhdG9yJ1xyXG5pbXBvcnQgeyByaXNrRm9ybUZvcndhcmRTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcblxyXG5pbnRlcmZhY2UgTG9jYXRpb25TdGF0ZSB7XHJcbiAgZm9ybTogUmlza0Zvcm1Gb3J3YXJkXHJcbiAgZW1haWw6IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBSaXNrRm9ybUZvcndhcmRBbnN3ZXI6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IHsgaXNMb2FkaW5nOiBnbG9iYWxMb2FkaW5nLCBzZXRJc0xvYWRpbmc6IHNldEdsb2JhbExvYWRpbmcgfSA9IHVzZUNvbnRleHQoTG9hZGluZ0RhdGFDb250ZXh0KVxyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxyXG4gIGNvbnN0IHsgY29sb3JzLCBmb250V2VpZ2h0IH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcbiAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcclxuICBjb25zdCBzdGF0ZSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGxvY2F0aW9uLnN0YXRlIGFzIExvY2F0aW9uU3RhdGVcclxuICB9LCBbbG9jYXRpb25dKVxyXG4gIGNvbnN0IFtcclxuICAgIGlzTW9kYWxPcGVuLFxyXG4gICAgeyBzZXRUcnVlOiBvcGVuTW9kYWwsIHNldEZhbHNlOiBjbG9zZU1vZGFsIH0sXHJcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXHJcbiAgY29uc3QgeyBmb3JtLCBlbWFpbCB9ID0gc3RhdGVcclxuICBjb25zdCBbYW5zd2Vycywgc2V0QW5zd2Vyc10gPSB1c2VTdGF0ZTxSaXNrRm9ybUFuc3dlckdyb3VwPih7XHJcbiAgICBlbWFpbCxcclxuICAgIGZvcm11bGFyaW9JZDogZm9ybS5pZCBhcyBzdHJpbmcsXHJcbiAgICB0ZXJtbzogZmFsc2UsXHJcbiAgICBwZXJndW50YXM6IGZvcm0ucGVyZ3VudGFzLm1hcChxdWVzdGlvbiA9PiB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgaWQ6IHF1ZXN0aW9uLmlkIGFzIHN0cmluZyxcclxuICAgICAgICByZXNwb3N0YTogcXVlc3Rpb24ucmVzcG9zdGEsXHJcbiAgICAgICAgY29tZW50YXJpbzogcXVlc3Rpb24uY29tZW50YXJpbyA/PyAnJyxcclxuICAgICAgICBpbmRleDogcXVlc3Rpb24uaW5kZXgsXHJcbiAgICAgIH1cclxuICAgIH0pLFxyXG4gIH0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRBbnN3ZXJzKFxyXG4gICAgICB7XHJcbiAgICAgICAgZW1haWwsXHJcbiAgICAgICAgZm9ybXVsYXJpb0lkOiBmb3JtLmlkIGFzIHN0cmluZyxcclxuICAgICAgICB0ZXJtbzogZmFsc2UsXHJcbiAgICAgICAgcGVyZ3VudGFzOiBmb3JtLnBlcmd1bnRhcz8ubWFwKHF1ZXN0aW9uID0+IHtcclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGlkOiBxdWVzdGlvbi5pZCBhcyBzdHJpbmcsXHJcbiAgICAgICAgICAgIHJlc3Bvc3RhOiBxdWVzdGlvbi5yZXNwb3N0YSxcclxuICAgICAgICAgICAgY29tZW50YXJpbzogcXVlc3Rpb24uY29tZW50YXJpbyA/PyAnJyxcclxuICAgICAgICAgICAgaW5kZXg6IHF1ZXN0aW9uLmluZGV4LFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgKVxyXG4gIH0sIFtlbWFpbCwgZm9ybV0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUFuc3dlckNoYW5nZSA9IHVzZUNhbGxiYWNrKChhbnN3ZXI6IFJpc2tGb3JtQW5zd2VyLCBrZXk6IHN0cmluZykgPT4ge1xyXG4gICAgcmV0dXJuIChfPzogdW5rbm93biwgZXZlbnRWYWx1ZT86IHN0cmluZyB8IElDaG9pY2VHcm91cE9wdGlvbikgPT4ge1xyXG4gICAgICBjb25zdCBhbnN3ZXJJbmRleCA9IGFuc3dlcnMucGVyZ3VudGFzLmZpbmRJbmRleChhc3cgPT4gYXN3LmlkID09PSBhbnN3ZXIuaWQpXHJcbiAgICAgIGNvbnN0IGxvY2FsQW5zd2VyID0gWy4uLmFuc3dlcnMucGVyZ3VudGFzXVxyXG4gICAgICBsb2NhbEFuc3dlci5zcGxpY2UoXHJcbiAgICAgICAgYW5zd2VySW5kZXgsXHJcbiAgICAgICAgMSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAuLi5hbnN3ZXIsXHJcbiAgICAgICAgICBba2V5XTogdHlwZW9mIGV2ZW50VmFsdWUgIT09ICdzdHJpbmcnXHJcbiAgICAgICAgICAgID8gcGFyc2VJbnQoZXZlbnRWYWx1ZT8ua2V5IGFzIHN0cmluZylcclxuICAgICAgICAgICAgOiBldmVudFZhbHVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIClcclxuICAgICAgc2V0QW5zd2Vycyh7XHJcbiAgICAgICAgLi4uYW5zd2VycyxcclxuICAgICAgICBwZXJndW50YXM6IGxvY2FsQW5zd2VyLFxyXG4gICAgICB9KVxyXG4gICAgfVxyXG4gIH0sIFthbnN3ZXJzXSlcclxuXHJcbiAgY29uc3QgYW5zd2VyUXVlc3Rpb25zID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0R2xvYmFsTG9hZGluZyh0cnVlKVxyXG4gICAgICBhd2FpdCByaXNrRm9ybUZvcndhcmRTZXJ2aWNlLnNlbmRBbnN3ZXIoYW5zd2VycylcclxuICAgICAgc2V0R2xvYmFsTG9hZGluZyhmYWxzZSlcclxuICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgbWVzc2FnZTogJ1Jlc3Bvc3RhIGVudmlhZGEgY29tIHN1Y2Vzc28hJyxcclxuICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5zdWNjZXNzLFxyXG4gICAgICAgIHRpbWVvdXQ6IDEwMDAwLFxyXG4gICAgICB9KVxyXG4gICAgICBuYXZpZ2F0ZSgtMSlcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEdsb2JhbExvYWRpbmcoZmFsc2UpXHJcbiAgICAgIGNvbnN0IGVyID0gZXJyb3IgYXMgQXBpRXJyb3JcclxuICAgICAgZXIuZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaCgoZXJyb3JNZXNzYWdlKSA9PiB7XHJcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UubWVzc2FnZSxcclxuICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcbiAgfSwgW2Fuc3dlcnNdKVxyXG5cclxuICBjb25zdCBzYXZlRHJhZnQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRHbG9iYWxMb2FkaW5nKHRydWUpXHJcbiAgICAgIGF3YWl0IHJpc2tGb3JtRm9yd2FyZFNlcnZpY2Uuc2F2ZURyYWZ0KGFuc3dlcnMpXHJcbiAgICAgIHNldEdsb2JhbExvYWRpbmcoZmFsc2UpXHJcbiAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgIG1lc3NhZ2U6ICdSYXNjdW5obyBlbnZpYWRvIGNvbSBzdWNlc3NvIScsXHJcbiAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuc3VjY2VzcyxcclxuICAgICAgICB0aW1lb3V0OiAxMDAwMCxcclxuICAgICAgfSlcclxuICAgICAgbmF2aWdhdGUoLTEpXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRHbG9iYWxMb2FkaW5nKGZhbHNlKVxyXG4gICAgICBjb25zdCBlciA9IGVycm9yIGFzIEFwaUVycm9yXHJcbiAgICAgIGVyLmVycm9ycz8ubWVzc2FnZXM/LmZvckVhY2goKGVycm9yTWVzc2FnZSkgPT4ge1xyXG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICB9KVxyXG4gICAgICB9KVxyXG4gICAgfVxyXG4gIH0sIFthbnN3ZXJzXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hlY2tib3hDbGljayA9IHVzZUNhbGxiYWNrKChfOiB1bmtub3duLCBjaGVja2VkPzogYm9vbGVhbiB8IHVuZGVmaW5lZCkgPT4ge1xyXG4gICAgc2V0QW5zd2VycyhwcmV2U3RhdGUgPT4ge1xyXG4gICAgICByZXR1cm4geyAuLi5wcmV2U3RhdGUsIHRlcm1vOiBjaGVja2VkIGFzIGJvb2xlYW4gfVxyXG4gICAgfSlcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgY2FuY2VsU2VuZEFuc3dlcnMgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzZXRBbnN3ZXJzKHByZXZTdGF0ZSA9PiB7XHJcbiAgICAgIHJldHVybiB7IC4uLnByZXZTdGF0ZSwgdGVybW86IGZhbHNlIH1cclxuICAgIH0pXHJcbiAgICBjbG9zZU1vZGFsKClcclxuICB9LCBbXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBcHBQYWdlXHJcbiAgICAgIHJlbmRlclRpdGxlPXtcclxuICAgICAgICAoKSA9PiA8RmxleENvbHVtblxyXG4gICAgICAgICAgaG9yaXpvbnRhbEFsaWduPSdzdHJldGNoJ1xyXG4gICAgICAgICAgZ2FwPXs4fVxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnc3RpY2t5JyxcclxuICAgICAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgICAgICBsZWZ0OiAwLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmJyxcclxuICAgICAgICAgICAgekluZGV4OiA5MDAwLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8RmxleFJvdyBob3Jpem9udGFsQWxpZ249J3NwYWNlLWJldHdlZW4nPlxyXG4gICAgICAgICAgICA8UGFnZVRpdGxlPntgUmVzcG9uZGVyICR7Zm9ybS5ub21lRm9ybXVsYXJpb31gfTwvUGFnZVRpdGxlPlxyXG4gICAgICAgICAgICA8Umlza0Zvcm1Gb3J3YXJkQW5zd2VyQWN0aW9uc1xyXG4gICAgICAgICAgICAgIG9uR29CYWNrPXsoKSA9PiBuYXZpZ2F0ZSgtMSl9XHJcbiAgICAgICAgICAgICAgb25TYXZlPXtvcGVuTW9kYWx9XHJcbiAgICAgICAgICAgICAgb25EcmFmdD17c2F2ZURyYWZ0fVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXthbnN3ZXJzLnBlcmd1bnRhcy5zb21lKGFuc3dlciA9PiBhbnN3ZXIucmVzcG9zdGEgPT09IHVuZGVmaW5lZCB8fCBhbnN3ZXIucmVzcG9zdGEgPT09IDQpfVxyXG4gICAgICAgICAgICAgIGxvYWRpbmc9e2dsb2JhbExvYWRpbmd9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgICAgICA8UGFnZVN1YnRpdGxlPntmb3JtLmNvZGlnb0VudmlvID8gYEPDs2RpZ28gZGUgZW52aW86ICR7Zm9ybS5jb2RpZ29FbnZpb31gIDogdW5kZWZpbmVkfTwvUGFnZVN1YnRpdGxlPlxyXG4gICAgICAgICAge2Zvcm0uZW1wcmVzYXMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICA8RmxleFJvdyBzdHlsZXM9e3sgcG9zaXRpb246ICdzdGlja3knLCB0b3A6IDIwIH19PlxyXG4gICAgICAgICAgICAgIDxGbGV4SXRlbT5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwSG9zdFxyXG4gICAgICAgICAgICAgICAgICBjb250ZW50PXtgRW1wcmVzYXM6ICR7Zm9ybS5lbXByZXNhcy5tYXAoY21wID0+IGNtcD8uZW1wcmVzYS5yYXphb1NvY2lhbCkuam9pbignLCAnKX1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnNlbWlib2xkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbODAwXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4V2lkdGg6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgd29yZFdyYXA6ICdhbnl3aGVyZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtgRW1wcmVzYXM6ICR7Zm9ybS5lbXByZXNhcy5tYXAoY21wID0+IGNtcD8uZW1wcmVzYS5yYXphb1NvY2lhbCkuam9pbignLCAnKX1gfVxyXG4gICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gICAgICAgICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgICAgIDwvRmxleFJvdz5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDxSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvclxyXG4gICAgICAgICAgICBhbnN3ZXJzPXthbnN3ZXJzfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgICAgIH1cclxuICAgICAgaXNUaXRsZUZpeGVkXHJcbiAgICAgIGhhc0JhY2tncm91bmRcclxuICAgID5cclxuICAgICAgPEZsZXhDb2x1bW5cclxuICAgICAgICBnYXA9eyAxNiB9XHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICBwYWRkaW5nOiBgMCAke3RoZW1lLnNwYWNpbmcueHN9YCxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge2Fuc3dlcnMucGVyZ3VudGFzPy5zb3J0KChhLCBiKSA9PiAoYS5pbmRleCBhcyBudW1iZXIpID4gKGIuaW5kZXggYXMgbnVtYmVyKSA/IDEgOiAtMSlcclxuICAgICAgICAgIC5tYXAocXVlc3Rpb24gPT4gPFJpc2tGb3JtRm9yd2FyZEFuc3dlckNhcmRcclxuICAgICAgICAgICAga2V5PXtxdWVzdGlvbi5pZH1cclxuICAgICAgICAgICAgYW5zd2VyPXtxdWVzdGlvbn1cclxuICAgICAgICAgICAgcXVlc3Rpb25zPXtmb3JtLnBlcmd1bnRhc31cclxuICAgICAgICAgICAgb25BbnN3ZXJDaGFuZ2U9e2hhbmRsZUFuc3dlckNoYW5nZX1cclxuICAgICAgICAgIC8+KX1cclxuICAgICAgPC9GbGV4Q29sdW1uPlxyXG4gICAgICB7aXNNb2RhbE9wZW4gJiYgPFJpc2tGb3JtRm9yd2FyZEFuc3dlckNoZWNrTW9kYWxcclxuICAgICAgICBpc09wZW49e2lzTW9kYWxPcGVufVxyXG4gICAgICAgIG9uRGlzbWlzcz17Y2FuY2VsU2VuZEFuc3dlcnN9XHJcbiAgICAgICAgaXNDaGVja2VkPXthbnN3ZXJzLnRlcm1vfVxyXG4gICAgICAgIG9uQ2hlY2tib3hDaGFuZ2U9e2hhbmRsZUNoZWNrYm94Q2xpY2t9XHJcbiAgICAgICAgc2VuZEFuc3dlcnM9e2Fuc3dlclF1ZXN0aW9uc31cclxuICAgICAgLz59XHJcbiAgICA8L0FwcFBhZ2U+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSaXNrRm9ybUZvcndhcmRBbnN3ZXJcclxuIl19