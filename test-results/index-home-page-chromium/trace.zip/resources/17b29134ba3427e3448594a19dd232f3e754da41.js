import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/EmailSentPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/EmailSentPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { EmailSent } from "/src/modules/auth/components/index.ts?t=1701096626433";
import AuthPageBoilerplate from "/src/modules/auth/pages/AuthPageBoilerplate.tsx?t=1701096626433";
const EmailSentPage = () => {
  return /* @__PURE__ */ jsxDEV(AuthPageBoilerplate, { children: /* @__PURE__ */ jsxDEV(EmailSent, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/EmailSentPage.tsx",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/EmailSentPage.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = EmailSentPage;
export default EmailSentPage;
var _c;
$RefreshReg$(_c, "EmailSentPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/EmailSentPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTiwyQkFBMEI7QUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXpDLE9BQU9BLHlCQUF5QjtBQUVoQyxNQUFNQyxnQkFBb0JBLE1BQU07QUFDOUIsU0FDRSx1QkFBQyx1QkFDQyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBTktEO0FBUU4sZUFBZUE7QUFBYSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQXV0aFBhZ2VCb2lsZXJwbGF0ZSIsIkVtYWlsU2VudFBhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVtYWlsU2VudFBhZ2UudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdXRoL3BhZ2VzL0VtYWlsU2VudFBhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRW1haWxTZW50IH0gZnJvbSAnLi4vY29tcG9uZW50cydcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQXV0aFBhZ2VCb2lsZXJwbGF0ZSBmcm9tICcuL0F1dGhQYWdlQm9pbGVycGxhdGUnXG5cbmNvbnN0IEVtYWlsU2VudFBhZ2U6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxBdXRoUGFnZUJvaWxlcnBsYXRlID5cbiAgICAgIDxFbWFpbFNlbnQgLz5cbiAgICA8LyBBdXRoUGFnZUJvaWxlcnBsYXRlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEVtYWlsU2VudFBhZ2VcbiJdfQ==