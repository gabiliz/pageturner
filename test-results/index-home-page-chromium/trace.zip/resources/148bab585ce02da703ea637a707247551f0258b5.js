import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { profileQueryService as service, profileService } from "/src/modules/admin/profiles/services/index.ts";
import { ErrorBoundary } from "/node_modules/.vite/deps/react-error-boundary.js?v=9f90a7ff";
import { DataTable, ErrorScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { ProfileActions, ProfileEditDrawer } from "/src/modules/admin/profiles/components/index.ts?t=1701096626433";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
import ProfileDetailsDrawer from "/src/modules/admin/profiles/components/ProfileDetailsDrawer.tsx?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
const ProfileList = (props) => {
  _s();
  const {
    deletePermission,
    createPermission,
    visualizePermission,
    updatePermission
  } = props;
  const [isEditDrawerOpen, {
    setTrue: openEditDrawer,
    setFalse: closeEditDrawer
  }] = useBoolean(false);
  const [isDetailsDrawerOpen, {
    setTrue: openDetailsDrawer,
    setFalse: closeDetailsDrawer
  }] = useBoolean(false);
  const [profileToEdit, setProfileToEdit] = useState({
    nome: "",
    descricao: "",
    permissoes: []
  });
  const [profileToShow, setProfileToShow] = useState();
  const {
    openDialog
  } = useDialogs();
  const {
    error,
    data,
    isLoading
  } = service.useFindAllPaginated();
  const {
    mutateAsync: deleteItem
  } = service.useDelete();
  const [selection, setSelection] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const {
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  useEffect(() => {
    setGlobalLoading(isLoading);
  }, [isLoading]);
  useEffect(() => {
    setSelection([]);
  }, [data]);
  const updateDrawer = useCallback((profile) => {
    setIsCreating(false);
    setProfileToEdit(profileService.queryToCommand(profile));
    openEditDrawer();
  }, []);
  const createDrawer = useCallback(() => {
    setIsCreating(true);
    setProfileToEdit({
      nome: "",
      descricao: "",
      permissoes: []
    });
    openEditDrawer();
  }, []);
  const detailsDrawer = useCallback((profile) => {
    setProfileToShow(profile);
    openDetailsDrawer();
  }, []);
  const removeItems = useCallback(async (toRemove) => {
    await Promise.allSettled(toRemove.map((item) => item.id ? deleteItem(item) : Promise.resolve()));
  }, []);
  const confirmRemoval = useCallback((profile) => {
    const toRemove = profile ? [profile] : selection;
    const description = toRemove.length > 1 ? "Tem certeza que deseja excluir os perfis?" : "Tem certeza que deseja excluir o perfil?";
    openDialog({
      title: "Excluir perfil",
      description,
      acceptLabel: "Excluir",
      style: "danger",
      onAccept: () => removeItems(toRemove)
    });
  }, [selection, removeItems]);
  const menuOptions = useCallback((profile) => {
    const menu = [];
    if (visualizePermission) {
      menu.push({
        key: "detail",
        text: "Detalhar",
        onClick: () => detailsDrawer(profile)
      });
    }
    if (updatePermission) {
      menu.push({
        key: "update",
        text: "Alterar",
        onClick: () => updateDrawer(profile)
      });
    }
    if (deletePermission) {
      menu.push({
        key: "delete",
        text: "Excluir",
        onClick: () => confirmRemoval(profile)
      });
    }
    return menu;
  }, [updateDrawer, confirmRemoval, detailsDrawer, updatePermission, deletePermission, visualizePermission]);
  const actions = useCallback(() => /* @__PURE__ */ jsxDEV(ProfileActions, { onAdd: () => createDrawer(), onRemove: () => confirmRemoval(), disabledRemoveButton: selection.length === 0, createPermission, deletePermission }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
    lineNumber: 121,
    columnNumber: 37
  }, this), [selection, confirmRemoval, createPermission, deletePermission]);
  if (error)
    return /* @__PURE__ */ jsxDEV(ErrorScreen, { error }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
      lineNumber: 122,
      columnNumber: 21
    }, this);
  return /* @__PURE__ */ jsxDEV(ErrorBoundary, { fallbackRender: ({
    error: error2
  }) => /* @__PURE__ */ jsxDEV(ErrorScreen, { error: error2 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
    lineNumber: 125,
    columnNumber: 9
  }, this), children: [
    /* @__PURE__ */ jsxDEV(DataTable, { items: data?.value ?? [], columns, paginated: true, renderActions: actions, hasSearch: true, hasControlsColumn: true, selection, onSelection: setSelection, menuOptions, hasSelection: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
      lineNumber: 126,
      columnNumber: 7
    }, this),
    isEditDrawerOpen && profileToEdit && /* @__PURE__ */ jsxDEV(ProfileEditDrawer, { isOpen: isEditDrawerOpen, onDismiss: closeEditDrawer, profile: profileToEdit, isCreating }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
      lineNumber: 127,
      columnNumber: 45
    }, this),
    isDetailsDrawerOpen && profileToShow && /* @__PURE__ */ jsxDEV(ProfileDetailsDrawer, { isOpen: isDetailsDrawerOpen, onDismiss: closeDetailsDrawer, profile: profileToShow }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
      lineNumber: 128,
      columnNumber: 48
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx",
    lineNumber: 123,
    columnNumber: 10
  }, this);
};
_s(ProfileList, "3ouYeSKiyqlZpzX3O9TvJVjgqBc=", false, function() {
  return [useBoolean, useBoolean, useDialogs, service.useFindAllPaginated, service.useDelete];
});
_c = ProfileList;
const columns = [{
  header: "id",
  field: "id",
  filterable: false,
  sortable: false,
  visible: false,
  blockShowing: true
}, {
  header: "Nome",
  field: "nome",
  filterable: true,
  sortable: true
}, {
  header: "Descrição",
  field: "descricao",
  filterable: true,
  sortable: true
}];
export default ProfileList;
var _c;
$RefreshReg$(_c, "ProfileList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0lJOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0lKLFNBQWFBLGFBQWFDLFlBQVlDLFdBQVdDLGdCQUFnQjtBQUNqRSxTQUFTQyx1QkFBdUJDLFNBQVNDLHNCQUFzQjtBQUUvRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsV0FBNEJDLG1CQUFtQjtBQUV4RCxTQUFTQyxrQkFBa0I7QUFFM0IsU0FBU0MsZ0JBQWdCQyx5QkFBeUI7QUFDbEQsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLDBCQUEwQjtBQUNqQyxTQUFTQywwQkFBMEI7QUFTbkMsTUFBTUMsY0FBcUNDLFdBQVU7QUFBQUMsS0FBQTtBQUNuRCxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJTDtBQUNKLFFBQU0sQ0FDSk0sa0JBQ0E7QUFBQSxJQUFFQyxTQUFTQztBQUFBQSxJQUFnQkMsVUFBVUM7QUFBQUEsRUFBZ0IsQ0FBQyxJQUNwRGpCLFdBQVcsS0FBSztBQUNwQixRQUFNLENBQ0prQixxQkFDQTtBQUFBLElBQUVKLFNBQVNLO0FBQUFBLElBQW1CSCxVQUFVSTtBQUFBQSxFQUFtQixDQUFDLElBQzFEcEIsV0FBVyxLQUFLO0FBRXBCLFFBQU0sQ0FBQ3FCLGVBQWVDLGdCQUFnQixJQUFJN0IsU0FDeEM7QUFBQSxJQUNFOEIsTUFBTTtBQUFBLElBQ05DLFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsRUFDZCxDQUNGO0FBQ0EsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWxDLFNBQXVCO0FBRWpFLFFBQU07QUFBQSxJQUFFbUM7QUFBQUEsRUFBVyxJQUFJekIsV0FBVztBQUVsQyxRQUFNO0FBQUEsSUFBRTBCO0FBQUFBLElBQU9DO0FBQUFBLElBQU1DO0FBQUFBLEVBQVUsSUFBSXBDLFFBQVFxQyxvQkFBb0I7QUFDL0QsUUFBTTtBQUFBLElBQUVDLGFBQWFDO0FBQUFBLEVBQVcsSUFBSXZDLFFBQVF3QyxVQUFVO0FBQ3RELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJNUMsU0FBeUIsRUFBRTtBQUM3RCxRQUFNLENBQUM2QyxZQUFZQyxhQUFhLElBQUk5QyxTQUFrQixLQUFLO0FBQzNELFFBQU07QUFBQSxJQUFFK0MsY0FBY0M7QUFBQUEsRUFBaUIsSUFBSWxELFdBQVdjLGtCQUFrQjtBQUN4RWIsWUFBVSxNQUFNO0FBQ2RpRCxxQkFBaUJWLFNBQVM7QUFBQSxFQUM1QixHQUFHLENBQUNBLFNBQVMsQ0FBQztBQUVkdkMsWUFBVSxNQUFNO0FBQ2Q2QyxpQkFBYSxFQUFFO0FBQUEsRUFDakIsR0FBRyxDQUFDUCxJQUFJLENBQUM7QUFFVCxRQUFNWSxlQUFlcEQsWUFBWSxDQUFDcUQsWUFBMEI7QUFDMURKLGtCQUFjLEtBQUs7QUFDbkJqQixxQkFBaUIxQixlQUFlZ0QsZUFBZUQsT0FBTyxDQUFDO0FBQ3ZENUIsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNOEIsZUFBZXZELFlBQVksTUFBTTtBQUNyQ2lELGtCQUFjLElBQUk7QUFDbEJqQixxQkFDRTtBQUFBLE1BQ0VDLE1BQU07QUFBQSxNQUNOQyxXQUFXO0FBQUEsTUFDWEMsWUFBWTtBQUFBLElBQ2QsQ0FDRjtBQUNBVixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU0rQixnQkFBZ0J4RCxZQUFZLENBQUNxRCxZQUEwQjtBQUMzRGhCLHFCQUFpQmdCLE9BQU87QUFDeEJ4QixzQkFBa0I7QUFBQSxFQUNwQixHQUFHLEVBQUU7QUFFTCxRQUFNNEIsY0FBY3pELFlBQVksT0FBTzBELGFBQTZCO0FBQ2xFLFVBQU1DLFFBQVFDLFdBQ1pGLFNBQVNHLElBQUlDLFVBQVFBLEtBQUtDLEtBQ3RCbkIsV0FBV2tCLElBQUksSUFDZkgsUUFBUUssUUFBUSxDQUNwQixDQUNGO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxpQkFBaUJqRSxZQUNyQixDQUFDcUQsWUFBMkI7QUFDMUIsVUFBTUssV0FBV0wsVUFBVSxDQUFDQSxPQUFPLElBQUlQO0FBQ3ZDLFVBQU1vQixjQUFjUixTQUFTUyxTQUFTLElBQ2xDLDhDQUNBO0FBQ0o3QixlQUFXO0FBQUEsTUFDVDhCLE9BQU87QUFBQSxNQUNQRjtBQUFBQSxNQUNBRyxhQUFhO0FBQUEsTUFDYkMsT0FBTztBQUFBLE1BQ1BDLFVBQVVBLE1BQU1kLFlBQVlDLFFBQVE7QUFBQSxJQUN0QyxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNaLFdBQVdXLFdBQVcsQ0FBQztBQUU3QixRQUFNZSxjQUFjeEUsWUFDbEIsQ0FBQ3FELFlBQWlEO0FBQ2hELFVBQU1vQixPQUFPO0FBQ2IsUUFBSXBELHFCQUFxQjtBQUN2Qm9ELFdBQUtDLEtBQUs7QUFBQSxRQUNSQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLFFBQ05DLFNBQVNBLE1BQU1yQixjQUFjSCxPQUFPO0FBQUEsTUFDdEMsQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJL0Isa0JBQWtCO0FBQ3BCbUQsV0FBS0MsS0FBSztBQUFBLFFBQ1JDLEtBQUs7QUFBQSxRQUNMQyxNQUFNO0FBQUEsUUFDTkMsU0FBU0EsTUFBTXpCLGFBQWFDLE9BQU87QUFBQSxNQUNyQyxDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUlsQyxrQkFBa0I7QUFDcEJzRCxXQUFLQyxLQUFLO0FBQUEsUUFDUkMsS0FBSztBQUFBLFFBQ0xDLE1BQU07QUFBQSxRQUNOQyxTQUFTQSxNQUFNWixlQUFlWixPQUFPO0FBQUEsTUFDdkMsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPb0I7QUFBQUEsRUFDVCxHQUNBLENBQ0VyQixjQUNBYSxnQkFDQVQsZUFDQWxDLGtCQUNBSCxrQkFDQUUsbUJBQW1CLENBQ3BCO0FBRUgsUUFBTXlELFVBQVU5RSxZQUFZLE1BQzFCLHVCQUFDLGtCQUNDLE9BQU8sTUFBTXVELGFBQWEsR0FDMUIsVUFBVSxNQUFNVSxlQUFlLEdBQy9CLHNCQUFzQm5CLFVBQVVxQixXQUFXLEdBQzNDLGtCQUNBLG9CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLcUMsR0FFcEMsQ0FBQ3JCLFdBQVdtQixnQkFBZ0I3QyxrQkFBa0JELGdCQUFnQixDQUFDO0FBRWxFLE1BQUlvQjtBQUFPLFdBQU8sdUJBQUMsZUFBWSxTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFFNUMsU0FDRSx1QkFBQyxpQkFDQyxnQkFBZ0IsQ0FBQztBQUFBLElBQUVBO0FBQUFBLEVBQU0sTUFDdkIsdUJBQUMsZUFBWSxPQUFPQSxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBCLEdBRzVCO0FBQUEsMkJBQUMsYUFDQyxPQUFPQyxNQUFNdUMsU0FBUyxJQUN0QixTQUNBLFdBQVMsTUFDVCxlQUFlRCxTQUNmLFdBQVMsTUFDVCxtQkFBaUIsTUFDakIsV0FDQSxhQUFhL0IsY0FDYixhQUNBLGNBQVksUUFWZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVWM7QUFBQSxJQUVieEIsb0JBQ0RRLGlCQUNFLHVCQUFDLHFCQUNDLFFBQVFSLGtCQUNSLFdBQVdJLGlCQUNYLFNBQVNJLGVBQ1QsY0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXlCO0FBQUEsSUFFMUJILHVCQUNEUSxpQkFDRSx1QkFBQyx3QkFDQyxRQUFRUixxQkFDUixXQUFXRSxvQkFDWCxTQUFTTSxpQkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR3lCO0FBQUEsT0E5QjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDbEIsR0F6S0tGLGFBQWlDO0FBQUEsVUFVakNOLFlBSUFBLFlBV21CRyxZQUVZUixRQUFRcUMscUJBQ1ByQyxRQUFRd0MsU0FBUztBQUFBO0FBQUFtQyxLQTVCakRoRTtBQTJLTixNQUFNaUUsVUFBMkMsQ0FDL0M7QUFBQSxFQUNFQyxRQUFRO0FBQUEsRUFDUkMsT0FBTztBQUFBLEVBQ1BDLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVkMsU0FBUztBQUFBLEVBQ1RDLGNBQWM7QUFDaEIsR0FDQTtBQUFBLEVBQ0VMLFFBQVE7QUFBQSxFQUNSQyxPQUFPO0FBQUEsRUFDUEMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUgsUUFBUTtBQUFBLEVBQ1JDLE9BQU87QUFBQSxFQUNQQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUNaLENBQUM7QUFHSCxlQUFlckU7QUFBVyxJQUFBZ0U7QUFBQVEsYUFBQVIsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwicHJvZmlsZVF1ZXJ5U2VydmljZSIsInNlcnZpY2UiLCJwcm9maWxlU2VydmljZSIsIkVycm9yQm91bmRhcnkiLCJEYXRhVGFibGUiLCJFcnJvclNjcmVlbiIsInVzZUJvb2xlYW4iLCJQcm9maWxlQWN0aW9ucyIsIlByb2ZpbGVFZGl0RHJhd2VyIiwidXNlRGlhbG9ncyIsIlByb2ZpbGVEZXRhaWxzRHJhd2VyIiwiTG9hZGluZ0RhdGFDb250ZXh0IiwiUHJvZmlsZUxpc3QiLCJwcm9wcyIsIl9zIiwiZGVsZXRlUGVybWlzc2lvbiIsImNyZWF0ZVBlcm1pc3Npb24iLCJ2aXN1YWxpemVQZXJtaXNzaW9uIiwidXBkYXRlUGVybWlzc2lvbiIsImlzRWRpdERyYXdlck9wZW4iLCJzZXRUcnVlIiwib3BlbkVkaXREcmF3ZXIiLCJzZXRGYWxzZSIsImNsb3NlRWRpdERyYXdlciIsImlzRGV0YWlsc0RyYXdlck9wZW4iLCJvcGVuRGV0YWlsc0RyYXdlciIsImNsb3NlRGV0YWlsc0RyYXdlciIsInByb2ZpbGVUb0VkaXQiLCJzZXRQcm9maWxlVG9FZGl0Iiwibm9tZSIsImRlc2NyaWNhbyIsInBlcm1pc3NvZXMiLCJwcm9maWxlVG9TaG93Iiwic2V0UHJvZmlsZVRvU2hvdyIsIm9wZW5EaWFsb2ciLCJlcnJvciIsImRhdGEiLCJpc0xvYWRpbmciLCJ1c2VGaW5kQWxsUGFnaW5hdGVkIiwibXV0YXRlQXN5bmMiLCJkZWxldGVJdGVtIiwidXNlRGVsZXRlIiwic2VsZWN0aW9uIiwic2V0U2VsZWN0aW9uIiwiaXNDcmVhdGluZyIsInNldElzQ3JlYXRpbmciLCJzZXRJc0xvYWRpbmciLCJzZXRHbG9iYWxMb2FkaW5nIiwidXBkYXRlRHJhd2VyIiwicHJvZmlsZSIsInF1ZXJ5VG9Db21tYW5kIiwiY3JlYXRlRHJhd2VyIiwiZGV0YWlsc0RyYXdlciIsInJlbW92ZUl0ZW1zIiwidG9SZW1vdmUiLCJQcm9taXNlIiwiYWxsU2V0dGxlZCIsIm1hcCIsIml0ZW0iLCJpZCIsInJlc29sdmUiLCJjb25maXJtUmVtb3ZhbCIsImRlc2NyaXB0aW9uIiwibGVuZ3RoIiwidGl0bGUiLCJhY2NlcHRMYWJlbCIsInN0eWxlIiwib25BY2NlcHQiLCJtZW51T3B0aW9ucyIsIm1lbnUiLCJwdXNoIiwia2V5IiwidGV4dCIsIm9uQ2xpY2siLCJhY3Rpb25zIiwidmFsdWUiLCJfYyIsImNvbHVtbnMiLCJoZWFkZXIiLCJmaWVsZCIsImZpbHRlcmFibGUiLCJzb3J0YWJsZSIsInZpc2libGUiLCJibG9ja1Nob3dpbmciLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlTGlzdC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3Byb2ZpbGVzL2NvbXBvbmVudHMvUHJvZmlsZUxpc3QudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHByb2ZpbGVRdWVyeVNlcnZpY2UgYXMgc2VydmljZSwgcHJvZmlsZVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuaW1wb3J0IHsgSUNvbnRleHR1YWxNZW51SXRlbSB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gJ3JlYWN0LWVycm9yLWJvdW5kYXJ5J1xyXG5pbXBvcnQgeyBEYXRhVGFibGUsIERhdGFUYWJsZUNvbHVtbiwgRXJyb3JTY3JlZW4gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IFByb2ZpbGVRdWVyeSBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vUHJvZmlsZVF1ZXJ5J1xyXG5pbXBvcnQgeyB1c2VCb29sZWFuIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWhvb2tzJ1xyXG5pbXBvcnQgUHJvZmlsZUNvbW1hbmQgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1Byb2ZpbGVDb21tYW5kJ1xyXG5pbXBvcnQgeyBQcm9maWxlQWN0aW9ucywgUHJvZmlsZUVkaXREcmF3ZXIgfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyB1c2VEaWFsb2dzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3N0b3JlL2RpYWxvZ3MvZGlhbG9ncydcclxuaW1wb3J0IFByb2ZpbGVEZXRhaWxzRHJhd2VyIGZyb20gJy4vUHJvZmlsZURldGFpbHNEcmF3ZXInXHJcbmltcG9ydCB7IExvYWRpbmdEYXRhQ29udGV4dCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb250ZXh0L0xvYWRpbmdEYXRhQ29udGV4dCdcclxuXHJcbmludGVyZmFjZSBQcm9maWxlTGlzdFByb3BzIHtcclxuICBkZWxldGVQZXJtaXNzaW9uOiBib29sZWFuXHJcbiAgY3JlYXRlUGVybWlzc2lvbjogYm9vbGVhblxyXG4gIHZpc3VhbGl6ZVBlcm1pc3Npb246IGJvb2xlYW5cclxuICB1cGRhdGVQZXJtaXNzaW9uOiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IFByb2ZpbGVMaXN0OiBGQzxQcm9maWxlTGlzdFByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIGRlbGV0ZVBlcm1pc3Npb24sXHJcbiAgICBjcmVhdGVQZXJtaXNzaW9uLFxyXG4gICAgdmlzdWFsaXplUGVybWlzc2lvbixcclxuICAgIHVwZGF0ZVBlcm1pc3Npb24sXHJcbiAgfSA9IHByb3BzXHJcbiAgY29uc3QgW1xyXG4gICAgaXNFZGl0RHJhd2VyT3BlbixcclxuICAgIHsgc2V0VHJ1ZTogb3BlbkVkaXREcmF3ZXIsIHNldEZhbHNlOiBjbG9zZUVkaXREcmF3ZXIgfSxcclxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcclxuICBjb25zdCBbXHJcbiAgICBpc0RldGFpbHNEcmF3ZXJPcGVuLFxyXG4gICAgeyBzZXRUcnVlOiBvcGVuRGV0YWlsc0RyYXdlciwgc2V0RmFsc2U6IGNsb3NlRGV0YWlsc0RyYXdlciB9LFxyXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG5cclxuICBjb25zdCBbcHJvZmlsZVRvRWRpdCwgc2V0UHJvZmlsZVRvRWRpdF0gPSB1c2VTdGF0ZTxQcm9maWxlQ29tbWFuZD4oXHJcbiAgICB7XHJcbiAgICAgIG5vbWU6ICcnLFxyXG4gICAgICBkZXNjcmljYW86ICcnLFxyXG4gICAgICBwZXJtaXNzb2VzOiBbXSxcclxuICAgIH0sXHJcbiAgKVxyXG4gIGNvbnN0IFtwcm9maWxlVG9TaG93LCBzZXRQcm9maWxlVG9TaG93XSA9IHVzZVN0YXRlPFByb2ZpbGVRdWVyeT4oKVxyXG5cclxuICBjb25zdCB7IG9wZW5EaWFsb2cgfSA9IHVzZURpYWxvZ3MoKVxyXG5cclxuICBjb25zdCB7IGVycm9yLCBkYXRhLCBpc0xvYWRpbmcgfSA9IHNlcnZpY2UudXNlRmluZEFsbFBhZ2luYXRlZCgpXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogZGVsZXRlSXRlbSB9ID0gc2VydmljZS51c2VEZWxldGUoKVxyXG4gIGNvbnN0IFtzZWxlY3Rpb24sIHNldFNlbGVjdGlvbl0gPSB1c2VTdGF0ZTxQcm9maWxlUXVlcnlbXT4oW10pXHJcbiAgY29uc3QgW2lzQ3JlYXRpbmcsIHNldElzQ3JlYXRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXHJcbiAgY29uc3QgeyBzZXRJc0xvYWRpbmc6IHNldEdsb2JhbExvYWRpbmcgfSA9IHVzZUNvbnRleHQoTG9hZGluZ0RhdGFDb250ZXh0KVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRHbG9iYWxMb2FkaW5nKGlzTG9hZGluZylcclxuICB9LCBbaXNMb2FkaW5nXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFNlbGVjdGlvbihbXSlcclxuICB9LCBbZGF0YV0pXHJcblxyXG4gIGNvbnN0IHVwZGF0ZURyYXdlciA9IHVzZUNhbGxiYWNrKChwcm9maWxlOiBQcm9maWxlUXVlcnkpID0+IHtcclxuICAgIHNldElzQ3JlYXRpbmcoZmFsc2UpXHJcbiAgICBzZXRQcm9maWxlVG9FZGl0KHByb2ZpbGVTZXJ2aWNlLnF1ZXJ5VG9Db21tYW5kKHByb2ZpbGUpKVxyXG4gICAgb3BlbkVkaXREcmF3ZXIoKVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBjcmVhdGVEcmF3ZXIgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzZXRJc0NyZWF0aW5nKHRydWUpXHJcbiAgICBzZXRQcm9maWxlVG9FZGl0KFxyXG4gICAgICB7XHJcbiAgICAgICAgbm9tZTogJycsXHJcbiAgICAgICAgZGVzY3JpY2FvOiAnJyxcclxuICAgICAgICBwZXJtaXNzb2VzOiBbXSxcclxuICAgICAgfSxcclxuICAgIClcclxuICAgIG9wZW5FZGl0RHJhd2VyKClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgZGV0YWlsc0RyYXdlciA9IHVzZUNhbGxiYWNrKChwcm9maWxlOiBQcm9maWxlUXVlcnkpID0+IHtcclxuICAgIHNldFByb2ZpbGVUb1Nob3cocHJvZmlsZSlcclxuICAgIG9wZW5EZXRhaWxzRHJhd2VyKClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgcmVtb3ZlSXRlbXMgPSB1c2VDYWxsYmFjayhhc3luYyAodG9SZW1vdmU6IFByb2ZpbGVRdWVyeVtdKSA9PiB7XHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQoXHJcbiAgICAgIHRvUmVtb3ZlLm1hcChpdGVtID0+IGl0ZW0uaWRcclxuICAgICAgICA/IGRlbGV0ZUl0ZW0oaXRlbSlcclxuICAgICAgICA6IFByb21pc2UucmVzb2x2ZSgpLFxyXG4gICAgICApLFxyXG4gICAgKVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBjb25maXJtUmVtb3ZhbCA9IHVzZUNhbGxiYWNrKFxyXG4gICAgKHByb2ZpbGU/OiBQcm9maWxlUXVlcnkpID0+IHtcclxuICAgICAgY29uc3QgdG9SZW1vdmUgPSBwcm9maWxlID8gW3Byb2ZpbGVdIDogc2VsZWN0aW9uXHJcbiAgICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdG9SZW1vdmUubGVuZ3RoID4gMVxyXG4gICAgICAgID8gJ1RlbSBjZXJ0ZXphIHF1ZSBkZXNlamEgZXhjbHVpciBvcyBwZXJmaXM/J1xyXG4gICAgICAgIDogJ1RlbSBjZXJ0ZXphIHF1ZSBkZXNlamEgZXhjbHVpciBvIHBlcmZpbD8nXHJcbiAgICAgIG9wZW5EaWFsb2coe1xyXG4gICAgICAgIHRpdGxlOiAnRXhjbHVpciBwZXJmaWwnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uLFxyXG4gICAgICAgIGFjY2VwdExhYmVsOiAnRXhjbHVpcicsXHJcbiAgICAgICAgc3R5bGU6ICdkYW5nZXInLFxyXG4gICAgICAgIG9uQWNjZXB0OiAoKSA9PiByZW1vdmVJdGVtcyh0b1JlbW92ZSksXHJcbiAgICAgIH0pXHJcbiAgICB9LCBbc2VsZWN0aW9uLCByZW1vdmVJdGVtc10pXHJcblxyXG4gIGNvbnN0IG1lbnVPcHRpb25zID0gdXNlQ2FsbGJhY2soXHJcbiAgICAocHJvZmlsZTogUHJvZmlsZVF1ZXJ5KTogSUNvbnRleHR1YWxNZW51SXRlbVtdID0+IHtcclxuICAgICAgY29uc3QgbWVudSA9IFtdXHJcbiAgICAgIGlmICh2aXN1YWxpemVQZXJtaXNzaW9uKSB7XHJcbiAgICAgICAgbWVudS5wdXNoKHtcclxuICAgICAgICAgIGtleTogJ2RldGFpbCcsXHJcbiAgICAgICAgICB0ZXh0OiAnRGV0YWxoYXInLFxyXG4gICAgICAgICAgb25DbGljazogKCkgPT4gZGV0YWlsc0RyYXdlcihwcm9maWxlKSxcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIGlmICh1cGRhdGVQZXJtaXNzaW9uKSB7XHJcbiAgICAgICAgbWVudS5wdXNoKHtcclxuICAgICAgICAgIGtleTogJ3VwZGF0ZScsXHJcbiAgICAgICAgICB0ZXh0OiAnQWx0ZXJhcicsXHJcbiAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB1cGRhdGVEcmF3ZXIocHJvZmlsZSksXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICBpZiAoZGVsZXRlUGVybWlzc2lvbikge1xyXG4gICAgICAgIG1lbnUucHVzaCh7XHJcbiAgICAgICAgICBrZXk6ICdkZWxldGUnLFxyXG4gICAgICAgICAgdGV4dDogJ0V4Y2x1aXInLFxyXG4gICAgICAgICAgb25DbGljazogKCkgPT4gY29uZmlybVJlbW92YWwocHJvZmlsZSksXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbWVudVxyXG4gICAgfSxcclxuICAgIFtcclxuICAgICAgdXBkYXRlRHJhd2VyLFxyXG4gICAgICBjb25maXJtUmVtb3ZhbCxcclxuICAgICAgZGV0YWlsc0RyYXdlcixcclxuICAgICAgdXBkYXRlUGVybWlzc2lvbixcclxuICAgICAgZGVsZXRlUGVybWlzc2lvbixcclxuICAgICAgdmlzdWFsaXplUGVybWlzc2lvbixcclxuICAgIF0pXHJcblxyXG4gIGNvbnN0IGFjdGlvbnMgPSB1c2VDYWxsYmFjaygoKSA9PiAoXHJcbiAgICA8UHJvZmlsZUFjdGlvbnNcclxuICAgICAgb25BZGQ9eygpID0+IGNyZWF0ZURyYXdlcigpfVxyXG4gICAgICBvblJlbW92ZT17KCkgPT4gY29uZmlybVJlbW92YWwoKX1cclxuICAgICAgZGlzYWJsZWRSZW1vdmVCdXR0b249e3NlbGVjdGlvbi5sZW5ndGggPT09IDB9XHJcbiAgICAgIGNyZWF0ZVBlcm1pc3Npb249e2NyZWF0ZVBlcm1pc3Npb259XHJcbiAgICAgIGRlbGV0ZVBlcm1pc3Npb249e2RlbGV0ZVBlcm1pc3Npb259XHJcbiAgICAvPlxyXG4gICksIFtzZWxlY3Rpb24sIGNvbmZpcm1SZW1vdmFsLCBjcmVhdGVQZXJtaXNzaW9uLCBkZWxldGVQZXJtaXNzaW9uXSlcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPEVycm9yU2NyZWVuIGVycm9yPXtlcnJvcn0gLz5cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxFcnJvckJvdW5kYXJ5XHJcbiAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyBlcnJvciB9KSA9PiAoXHJcbiAgICAgICAgPEVycm9yU2NyZWVuIGVycm9yPXtlcnJvcn0gLz5cclxuICAgICAgKX1cclxuICAgID5cclxuICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgIGl0ZW1zPXtkYXRhPy52YWx1ZSA/PyBbXX1cclxuICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgIHBhZ2luYXRlZFxyXG4gICAgICAgIHJlbmRlckFjdGlvbnM9e2FjdGlvbnN9XHJcbiAgICAgICAgaGFzU2VhcmNoXHJcbiAgICAgICAgaGFzQ29udHJvbHNDb2x1bW5cclxuICAgICAgICBzZWxlY3Rpb249e3NlbGVjdGlvbn1cclxuICAgICAgICBvblNlbGVjdGlvbj17c2V0U2VsZWN0aW9ufVxyXG4gICAgICAgIG1lbnVPcHRpb25zPXttZW51T3B0aW9uc31cclxuICAgICAgICBoYXNTZWxlY3Rpb25cclxuICAgICAgLz5cclxuICAgICAge2lzRWRpdERyYXdlck9wZW4gJiZcclxuICAgICAgcHJvZmlsZVRvRWRpdCAmJlxyXG4gICAgICAgIDxQcm9maWxlRWRpdERyYXdlclxyXG4gICAgICAgICAgaXNPcGVuPXtpc0VkaXREcmF3ZXJPcGVufVxyXG4gICAgICAgICAgb25EaXNtaXNzPXtjbG9zZUVkaXREcmF3ZXJ9XHJcbiAgICAgICAgICBwcm9maWxlPXtwcm9maWxlVG9FZGl0fVxyXG4gICAgICAgICAgaXNDcmVhdGluZz17aXNDcmVhdGluZ31cclxuICAgICAgICAvPn1cclxuICAgICAge2lzRGV0YWlsc0RyYXdlck9wZW4gJiZcclxuICAgICAgcHJvZmlsZVRvU2hvdyAmJlxyXG4gICAgICAgIDxQcm9maWxlRGV0YWlsc0RyYXdlclxyXG4gICAgICAgICAgaXNPcGVuPXtpc0RldGFpbHNEcmF3ZXJPcGVufVxyXG4gICAgICAgICAgb25EaXNtaXNzPXtjbG9zZURldGFpbHNEcmF3ZXJ9XHJcbiAgICAgICAgICBwcm9maWxlPXtwcm9maWxlVG9TaG93fVxyXG4gICAgICAgIC8+fVxyXG4gICAgPC9FcnJvckJvdW5kYXJ5PlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPFByb2ZpbGVRdWVyeT5bXSA9IFtcclxuICB7XHJcbiAgICBoZWFkZXI6ICdpZCcsXHJcbiAgICBmaWVsZDogJ2lkJyxcclxuICAgIGZpbHRlcmFibGU6IGZhbHNlLFxyXG4gICAgc29ydGFibGU6IGZhbHNlLFxyXG4gICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICBibG9ja1Nob3dpbmc6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdOb21lJyxcclxuICAgIGZpZWxkOiAnbm9tZScsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdEZXNjcmnDp8OjbycsXHJcbiAgICBmaWVsZDogJ2Rlc2NyaWNhbycsXHJcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgfSxcclxuXVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvZmlsZUxpc3RcclxuIl19