import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/offices/components/OfficeDetails.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Label, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { UserName } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexItem, FlexRow } from "/src/shared/components/index.ts?t=1701096626433";
const OfficeDetails = (props) => {
  _s();
  const theme = useTheme();
  const {
    data
  } = props;
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nome" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.nome }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Sócio responsável" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserName, { id: data.socioResponsavelId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Gerente responsável" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserName, { id: data.gerenteResponsavelId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "CEP" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.cep }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.xl, children: [
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Endereço" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 34,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: data.endereco }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 35,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Número" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 38,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: data.numero }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 39,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Bairro" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.bairro }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.xl, children: [
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Cidade" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 48,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: data.cidade }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 49,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Estado" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: data.estado }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
          lineNumber: 53,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(OfficeDetails, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
_c = OfficeDetails;
export default OfficeDetails;
var _c;
$RefreshReg$(_c, "OfficeDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/offices/components/OfficeDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkUixTQUFTQSxPQUFPQyxZQUFZO0FBRzVCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWUMsVUFBVUMsZUFBZTtBQUU5QyxNQUFNQyxnQkFBK0NDLFdBQVU7QUFBQUMsS0FBQTtBQUM3RCxRQUFNQyxRQUFRUCxTQUFTO0FBQ3ZCLFFBQU07QUFBQSxJQUFFUTtBQUFBQSxFQUFLLElBQUlIO0FBRWpCLFNBQ0UsdUJBQUMsY0FBVyxLQUFNLElBQ2hCO0FBQUEsMkJBQUMsWUFDQztBQUFBLDZCQUFDLFNBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDWCx1QkFBQyxRQUFNRyxlQUFLQyxRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxTQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxTQUFNLGlDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxZQUFTLElBQUlELEtBQUtFLHNCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsU0FGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSxtQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFDMUIsdUJBQUMsWUFBUyxJQUFJRixLQUFLRyx3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLFNBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsWUFDQztBQUFBLDZCQUFDLFNBQU0sbUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVO0FBQUEsTUFDVix1QkFBQyxRQUFNSCxlQUFLSSxPQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0I7QUFBQSxTQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFdBQVEsS0FBS0wsTUFBTU0sUUFBUUMsSUFDMUI7QUFBQSw2QkFBQyxZQUNDO0FBQUEsK0JBQUMsU0FBTSx3QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFFBQU1OLGVBQUtPLFlBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFdBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFDQztBQUFBLCtCQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQyxRQUFNUCxlQUFLUSxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxXQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFDQztBQUFBLDZCQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhO0FBQUEsTUFDYix1QkFBQyxRQUFNUixlQUFLUyxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUI7QUFBQSxTQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFdBQVEsS0FBS1YsTUFBTU0sUUFBUUMsSUFDMUI7QUFBQSw2QkFBQyxZQUNDO0FBQUEsK0JBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiLHVCQUFDLFFBQU1OLGVBQUtVLFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFdBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFDQztBQUFBLCtCQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQyxRQUFNVixlQUFLVyxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxXQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q0E7QUFFSjtBQUFDYixHQWhES0YsZUFBMkM7QUFBQSxVQUNqQ0osUUFBUTtBQUFBO0FBQUFvQixLQURsQmhCO0FBa0ROLGVBQWVBO0FBQWEsSUFBQWdCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMYWJlbCIsIlRleHQiLCJVc2VyTmFtZSIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsIk9mZmljZURldGFpbHMiLCJwcm9wcyIsIl9zIiwidGhlbWUiLCJkYXRhIiwibm9tZSIsInNvY2lvUmVzcG9uc2F2ZWxJZCIsImdlcmVudGVSZXNwb25zYXZlbElkIiwiY2VwIiwic3BhY2luZyIsInhsIiwiZW5kZXJlY28iLCJudW1lcm8iLCJiYWlycm8iLCJjaWRhZGUiLCJlc3RhZG8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk9mZmljZURldGFpbHMudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9vZmZpY2VzL2NvbXBvbmVudHMvT2ZmaWNlRGV0YWlscy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGFiZWwsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgT2ZmaWNlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9PZmZpY2UnXG5pbXBvcnQgeyBEZXRhaWxzVmlld1Byb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL0RldGFpbHNWaWV3J1xuaW1wb3J0IHsgVXNlck5hbWUgfSBmcm9tICcuLi8uLi91c2Vycy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBGbGV4SXRlbSwgRmxleFJvdyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5jb25zdCBPZmZpY2VEZXRhaWxzOiBGQzxEZXRhaWxzVmlld1Byb3BzPE9mZmljZT4+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxuICBjb25zdCB7IGRhdGEgfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8TGFiZWw+Tm9tZTwvTGFiZWw+XG4gICAgICAgIDxUZXh0PntkYXRhLm5vbWV9PC9UZXh0PlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPlPDs2NpbyByZXNwb25zw6F2ZWw8L0xhYmVsPlxuICAgICAgICA8VXNlck5hbWUgaWQ9e2RhdGEuc29jaW9SZXNwb25zYXZlbElkIGFzIHN0cmluZ30vPlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPkdlcmVudGUgcmVzcG9uc8OhdmVsPC9MYWJlbD5cbiAgICAgICAgPFVzZXJOYW1lIGlkPXtkYXRhLmdlcmVudGVSZXNwb25zYXZlbElkIGFzIHN0cmluZ30vPlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPkNFUDwvTGFiZWw+XG4gICAgICAgIDxUZXh0PntkYXRhLmNlcH08L1RleHQ+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPEZsZXhSb3cgZ2FwPXt0aGVtZS5zcGFjaW5nLnhsfT5cbiAgICAgICAgPEZsZXhJdGVtPlxuICAgICAgICAgIDxMYWJlbD5FbmRlcmXDp288L0xhYmVsPlxuICAgICAgICAgIDxUZXh0PntkYXRhLmVuZGVyZWNvfTwvVGV4dD5cbiAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgICAgPEZsZXhJdGVtPlxuICAgICAgICAgIDxMYWJlbD5Ow7ptZXJvPC9MYWJlbD5cbiAgICAgICAgICA8VGV4dD57ZGF0YS5udW1lcm99PC9UZXh0PlxuICAgICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPC9GbGV4Um93PlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8TGFiZWw+QmFpcnJvPC9MYWJlbD5cbiAgICAgICAgPFRleHQ+e2RhdGEuYmFpcnJvfTwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleFJvdyBnYXA9e3RoZW1lLnNwYWNpbmcueGx9PlxuICAgICAgICA8RmxleEl0ZW0+XG4gICAgICAgICAgPExhYmVsPkNpZGFkZTwvTGFiZWw+XG4gICAgICAgICAgPFRleHQ+e2RhdGEuY2lkYWRlfTwvVGV4dD5cbiAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgICAgPEZsZXhJdGVtPlxuICAgICAgICAgIDxMYWJlbD5Fc3RhZG88L0xhYmVsPlxuICAgICAgICAgIDxUZXh0PntkYXRhLmVzdGFkb308L1RleHQ+XG4gICAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8L0ZsZXhSb3c+XG4gICAgPC9GbGV4Q29sdW1uPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE9mZmljZURldGFpbHNcbiJdfQ==