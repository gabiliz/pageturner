import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AuthRoutes.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Route, useLocation, Routes, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { RiskFormForward, RiskFormForwardAnswer } from "/src/modules/audit/riskForm/pages/index.ts?t=1701096626433";
import { EmailSentPage, ForgotPasswordPage, LoginPage, ChangePasswordPage, ChangePasswordSuccessPage, ConfirmAccountPage } from "/src/modules/auth/pages/index.ts?t=1701096626433";
import { FinancialStatementsPublicPage } from "/src/modules/audit/financialStatements/pages/index.ts?t=1701096626433";
const AuthRoutes = () => {
  _s();
  const lastLocation = useLocation();
  return /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/login", element: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 11,
      columnNumber: 42
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/forgot-password", element: /* @__PURE__ */ jsxDEV(ForgotPasswordPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 12,
      columnNumber: 52
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/email-sent", element: /* @__PURE__ */ jsxDEV(EmailSentPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 13,
      columnNumber: 47
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/change-password", element: /* @__PURE__ */ jsxDEV(ChangePasswordPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 14,
      columnNumber: 52
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/change-success", element: /* @__PURE__ */ jsxDEV(ChangePasswordSuccessPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 15,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/auth/confirm-user", element: /* @__PURE__ */ jsxDEV(ConfirmAccountPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 16,
      columnNumber: 49
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/form-list", element: /* @__PURE__ */ jsxDEV(RiskFormForward, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 17,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/answer", element: /* @__PURE__ */ jsxDEV(RiskFormForwardAnswer, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 18,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/financial-statements", element: /* @__PURE__ */ jsxDEV(FinancialStatementsPublicPage, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 19,
      columnNumber: 52
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { replace: true, to: `/auth/login?redirectTo=${lastLocation.pathname}` }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 20,
      columnNumber: 32
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(AuthRoutes, "7ypifTjL4LA4uu+iySBeUhDQ4YM=", false, function() {
  return [useLocation];
});
_c = AuthRoutes;
export default AuthRoutes;
var _c;
$RefreshReg$(_c, "AuthRoutes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/routes/AuthRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJ5Qzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCekMsU0FBU0EsT0FBT0MsYUFBYUMsUUFBUUMsZ0JBQWdCO0FBQ3JELFNBQVNDLGlCQUFpQkMsNkJBQTZCO0FBQ3ZELFNBQ0VDLGVBQ0FDLG9CQUNBQyxXQUNBQyxvQkFDQUMsMkJBQ0FDLDBCQUNLO0FBQ1AsU0FBU0MscUNBQXFDO0FBRTlDLE1BQU1DLGFBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsZUFBZWQsWUFBWTtBQUNqQyxTQUNFLHVCQUFDLFVBQ0M7QUFBQSwyQkFBQyxTQUFNLE1BQUssZUFBYyxTQUFTLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Q7QUFBQSxJQUNoRCx1QkFBQyxTQUFNLE1BQUsseUJBQXdCLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsSUFDbkUsdUJBQUMsU0FBTSxNQUFLLG9CQUFtQixTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlEO0FBQUEsSUFDekQsdUJBQUMsU0FBTSxNQUFLLHlCQUF3QixTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRTtBQUFBLElBQ25FLHVCQUFDLFNBQU0sTUFBSyx3QkFBdUIsU0FBUyx1QkFBQywrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUU7QUFBQSxJQUN6RSx1QkFBQyxTQUFNLE1BQUssc0JBQXFCLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFDaEUsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQ7QUFBQSxJQUNyRCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RDtBQUFBLElBQ3hELHVCQUFDLFNBQU0sTUFBSyx5QkFBd0IsU0FBUyx1QkFBQyxtQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEU7QUFBQSxJQUM5RSx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLFlBQVMsU0FBTyxNQUFDLElBQUssMEJBQXlCYyxhQUFhQyxjQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFLEtBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUc7QUFBQSxPQVZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDRixHQWhCS0QsWUFBYztBQUFBLFVBQ0daLFdBQVc7QUFBQTtBQUFBZ0IsS0FENUJKO0FBa0JOLGVBQWVBO0FBQVUsSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJvdXRlIiwidXNlTG9jYXRpb24iLCJSb3V0ZXMiLCJOYXZpZ2F0ZSIsIlJpc2tGb3JtRm9yd2FyZCIsIlJpc2tGb3JtRm9yd2FyZEFuc3dlciIsIkVtYWlsU2VudFBhZ2UiLCJGb3Jnb3RQYXNzd29yZFBhZ2UiLCJMb2dpblBhZ2UiLCJDaGFuZ2VQYXNzd29yZFBhZ2UiLCJDaGFuZ2VQYXNzd29yZFN1Y2Nlc3NQYWdlIiwiQ29uZmlybUFjY291bnRQYWdlIiwiRmluYW5jaWFsU3RhdGVtZW50c1B1YmxpY1BhZ2UiLCJBdXRoUm91dGVzIiwiX3MiLCJsYXN0TG9jYXRpb24iLCJwYXRobmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXV0aFJvdXRlcy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9yb3V0ZXMvQXV0aFJvdXRlcy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBSb3V0ZSwgdXNlTG9jYXRpb24sIFJvdXRlcywgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBSaXNrRm9ybUZvcndhcmQsIFJpc2tGb3JtRm9yd2FyZEFuc3dlciB9IGZyb20gJy4uL21vZHVsZXMvYXVkaXQvcmlza0Zvcm0vcGFnZXMnXHJcbmltcG9ydCB7XHJcbiAgRW1haWxTZW50UGFnZSxcclxuICBGb3Jnb3RQYXNzd29yZFBhZ2UsXHJcbiAgTG9naW5QYWdlLFxyXG4gIENoYW5nZVBhc3N3b3JkUGFnZSxcclxuICBDaGFuZ2VQYXNzd29yZFN1Y2Nlc3NQYWdlLFxyXG4gIENvbmZpcm1BY2NvdW50UGFnZSxcclxufSBmcm9tICcuLi9tb2R1bGVzL2F1dGgvcGFnZXMnXHJcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudHNQdWJsaWNQYWdlIH0gZnJvbSAnQG1vZHVsZXMvYXVkaXQvZmluYW5jaWFsU3RhdGVtZW50cy9wYWdlcydcclxuXHJcbmNvbnN0IEF1dGhSb3V0ZXM6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxhc3RMb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcclxuICByZXR1cm4gKFxyXG4gICAgPFJvdXRlcz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aC9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpblBhZ2UvPn0gLz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aC9mb3Jnb3QtcGFzc3dvcmRcIiBlbGVtZW50PXs8Rm9yZ290UGFzc3dvcmRQYWdlLz59IC8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2F1dGgvZW1haWwtc2VudFwiIGVsZW1lbnQ9ezxFbWFpbFNlbnRQYWdlLz59Lz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aC9jaGFuZ2UtcGFzc3dvcmRcIiBlbGVtZW50PXs8Q2hhbmdlUGFzc3dvcmRQYWdlLz59Lz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aC9jaGFuZ2Utc3VjY2Vzc1wiIGVsZW1lbnQ9ezxDaGFuZ2VQYXNzd29yZFN1Y2Nlc3NQYWdlLz59Lz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aC9jb25maXJtLXVzZXJcIiBlbGVtZW50PXs8Q29uZmlybUFjY291bnRQYWdlLz59Lz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvZm9ybS1saXN0XCIgZWxlbWVudD17PFJpc2tGb3JtRm9yd2FyZC8+fS8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2Fuc3dlclwiIGVsZW1lbnQ9ezxSaXNrRm9ybUZvcndhcmRBbnN3ZXIvPn0vPlxyXG4gICAgICA8Um91dGUgcGF0aD1cIi9maW5hbmNpYWwtc3RhdGVtZW50c1wiIGVsZW1lbnQ9ezxGaW5hbmNpYWxTdGF0ZW1lbnRzUHVibGljUGFnZS8+fS8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSByZXBsYWNlIHRvPXtgL2F1dGgvbG9naW4/cmVkaXJlY3RUbz0ke2xhc3RMb2NhdGlvbi5wYXRobmFtZX1gfSAvPn0gLz5cclxuICAgIDwvUm91dGVzPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXV0aFJvdXRlc1xyXG4iXX0=