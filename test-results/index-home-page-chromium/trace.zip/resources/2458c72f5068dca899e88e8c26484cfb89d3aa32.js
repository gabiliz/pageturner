import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/resource/ResourceCreateDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceCreateDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { EditDrawer } from "/src/shared/components/index.ts?t=1701096626433";
import { useHandleRejection } from "/src/shared/hooks/index.ts";
function ResourceCreateDrawer(props) {
  _s();
  const {
    title,
    service: service2,
    isOpen,
    onDismiss,
    serviceParams = [],
    onAfterSave
  } = props;
  const [formData, setFormData] = useState(null);
  const {
    mutateAsync: create,
    isLoading: isCreating
  } = service2.useCreate(...serviceParams);
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  const save = useCallback(async () => {
    if (formData) {
      const res = await create(formData);
      onAfterSave?.(res);
    }
    dismiss();
  }, [formData]);
  const dismiss = useCallback(() => {
    setFormData(null);
    setError(void 0);
    onDismiss();
  }, [onDismiss]);
  return /* @__PURE__ */ jsxDEV(EditDrawer, { title, isOpen, onDismiss: dismiss, onSave: save, disabled: isCreating, loading: isCreating, children: /* @__PURE__ */ jsxDEV(props.editForm, { formData, onChange: setFormData, apiError: error?.reason ? error?.reason : void 0 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceCreateDrawer.tsx",
    lineNumber: 57,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceCreateDrawer.tsx",
    lineNumber: 56,
    columnNumber: 10
  }, this);
}
_s(ResourceCreateDrawer, "O4CtKvGX8i6Y9jpZkvVB/avZ2Yg=", false, function() {
  return [service.useCreate, useHandleRejection];
});
_c = ResourceCreateDrawer;
export default ResourceCreateDrawer;
var _c;
$RefreshReg$(_c, "ResourceCreateDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceCreateDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVNOzs7Ozs7Ozs7Ozs7Ozs7O0FBckVOLFNBQVNBLFVBQVVDLGFBQTJCQyxpQkFBaUI7QUFDL0QsU0FBU0Msa0JBQWtCO0FBSTNCLFNBQVNDLDBCQUEwQjtBQWFuQyxTQUFTQyxxQkFDUEMsT0FDYztBQUFBQyxLQUFBO0FBQ2QsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLGdCQUFnQjtBQUFBLElBQ2hCQztBQUFBQSxFQUNGLElBQUlQO0FBRUosUUFBTSxDQUFDUSxVQUFVQyxXQUFXLElBQUlmLFNBQWlCLElBQUk7QUFFckQsUUFBTTtBQUFBLElBQUVnQixhQUFhQztBQUFBQSxJQUFRQyxXQUFXQztBQUFBQSxFQUFXLElBQUlWLFNBQVFXLFVBQVUsR0FBR1IsYUFBYTtBQUN6RixRQUFNLENBQUNTLE9BQU9DLFFBQVEsSUFBSXRCLFNBQWdDO0FBQzFELFFBQU07QUFBQSxJQUNKdUI7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJcEIsbUJBQW1CO0FBRXZCRixZQUFVLE1BQU07QUFDZHFCLHFCQUFpQkQsUUFBUTtBQUN6QixXQUFPLE1BQU07QUFDWEUseUJBQW1CRixRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUcsT0FBT3hCLFlBQVksWUFBWTtBQUNuQyxRQUFJYSxVQUFVO0FBQ1osWUFBTVksTUFBTSxNQUFNVCxPQUFPSCxRQUFRO0FBQ2pDRCxvQkFBY2EsR0FBUTtBQUFBLElBQ3hCO0FBQ0FDLFlBQVE7QUFBQSxFQUNWLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0FBRWIsUUFBTWEsVUFBVTFCLFlBQVksTUFBTTtBQUNoQ2MsZ0JBQVksSUFBSTtBQUNoQk8sYUFBU00sTUFBUztBQUNsQmpCLGNBQVU7QUFBQSxFQUNaLEdBQUcsQ0FBQ0EsU0FBUyxDQUFDO0FBRWQsU0FDRSx1QkFBQyxjQUNDLE9BQ0EsUUFDQSxXQUFXZ0IsU0FDWCxRQUFRRixNQUNSLFVBQVVOLFlBQ1YsU0FBU0EsWUFFVCxpQ0FBQyxNQUFNLFVBQU4sRUFDQyxVQUNBLFVBQVVKLGFBQ1YsVUFBVU0sT0FBT1EsU0FBU1IsT0FBT1EsU0FBcUJELFVBSHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHa0UsS0FYcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ3JCLEdBMURRRixzQkFBb0I7QUFBQSxVQWM0QkksUUFBUVcsV0FLM0RoQixrQkFBa0I7QUFBQTtBQUFBMEIsS0FuQmZ6QjtBQTREVCxlQUFlQTtBQUFvQixJQUFBeUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJFZGl0RHJhd2VyIiwidXNlSGFuZGxlUmVqZWN0aW9uIiwiUmVzb3VyY2VDcmVhdGVEcmF3ZXIiLCJwcm9wcyIsIl9zIiwidGl0bGUiLCJzZXJ2aWNlIiwiaXNPcGVuIiwib25EaXNtaXNzIiwic2VydmljZVBhcmFtcyIsIm9uQWZ0ZXJTYXZlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm11dGF0ZUFzeW5jIiwiY3JlYXRlIiwiaXNMb2FkaW5nIiwiaXNDcmVhdGluZyIsInVzZUNyZWF0ZSIsImVycm9yIiwic2V0RXJyb3IiLCJyZWdpc3Rlckxpc3RlbmVyIiwidW5yZWdpc3Rlckxpc3RlbmVyIiwic2F2ZSIsInJlcyIsImRpc21pc3MiLCJ1bmRlZmluZWQiLCJyZWFzb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlc291cmNlQ3JlYXRlRHJhd2VyLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3Jlc291cmNlL1Jlc291cmNlQ3JlYXRlRHJhd2VyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgUmVhY3RFbGVtZW50LCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEVkaXREcmF3ZXIgfSBmcm9tICcuLidcbmltcG9ydCBFbnRpdHkgZnJvbSAnLi4vLi4vLi4vZG9tYWluL0VudGl0eSdcbmltcG9ydCB7IFJlc291cmNlUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vYXBpL1Jlc291cmNlUXVlcnlTZXJ2aWNlJ1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi9lcnJvcnMnXG5pbXBvcnQgeyB1c2VIYW5kbGVSZWplY3Rpb24gfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEVkaXRGb3JtIH0gZnJvbSAnLi4vLi4vdHlwZXMvRWRpdEZvcm0nXG5cbmV4cG9ydCBpbnRlcmZhY2UgUmVzb3VyY2VDcmVhdGVEcmF3ZXJQcm9wczxRIGV4dGVuZHMgRW50aXR5LCBDIGV4dGVuZHMgRW50aXR5PiB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgc2VydmljZTogUmVzb3VyY2VRdWVyeVNlcnZpY2U8USwgQz5cbiAgZWRpdEZvcm06IEVkaXRGb3JtPEM+XG4gIGlzT3BlbjogYm9vbGVhblxuICBvbkRpc21pc3M6ICgpID0+IHZvaWRcbiAgb25BZnRlclNhdmU/OiAoaXRlbTogQykgPT4gdm9pZFxuICBzZXJ2aWNlUGFyYW1zPzogc3RyaW5nW11cbn1cblxuZnVuY3Rpb24gUmVzb3VyY2VDcmVhdGVEcmF3ZXI8USBleHRlbmRzIEVudGl0eSwgQyBleHRlbmRzIEVudGl0eT4gKFxuICBwcm9wczogUmVzb3VyY2VDcmVhdGVEcmF3ZXJQcm9wczxRLCBDPixcbik6IFJlYWN0RWxlbWVudCB7XG4gIGNvbnN0IHtcbiAgICB0aXRsZSxcbiAgICBzZXJ2aWNlLFxuICAgIGlzT3BlbixcbiAgICBvbkRpc21pc3MsXG4gICAgc2VydmljZVBhcmFtcyA9IFtdLFxuICAgIG9uQWZ0ZXJTYXZlLFxuICB9ID0gcHJvcHNcblxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPEN8bnVsbD4obnVsbClcblxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBjcmVhdGUsIGlzTG9hZGluZzogaXNDcmVhdGluZyB9ID0gc2VydmljZS51c2VDcmVhdGUoLi4uc2VydmljZVBhcmFtcylcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxQcm9taXNlUmVqZWN0aW9uRXZlbnQ+KClcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyTGlzdGVuZXIsXG4gICAgdW5yZWdpc3Rlckxpc3RlbmVyLFxuICB9ID0gdXNlSGFuZGxlUmVqZWN0aW9uKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHVucmVnaXN0ZXJMaXN0ZW5lcihzZXRFcnJvcilcbiAgICB9XG4gIH0sIFtzZXRFcnJvcl0pXG5cbiAgY29uc3Qgc2F2ZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBpZiAoZm9ybURhdGEpIHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNyZWF0ZShmb3JtRGF0YSlcbiAgICAgIG9uQWZ0ZXJTYXZlPy4ocmVzIGFzIEMpXG4gICAgfVxuICAgIGRpc21pc3MoKVxuICB9LCBbZm9ybURhdGFdKVxuXG4gIGNvbnN0IGRpc21pc3MgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0Rm9ybURhdGEobnVsbClcbiAgICBzZXRFcnJvcih1bmRlZmluZWQpXG4gICAgb25EaXNtaXNzKClcbiAgfSwgW29uRGlzbWlzc10pXG5cbiAgcmV0dXJuIChcbiAgICA8RWRpdERyYXdlclxuICAgICAgdGl0bGU9e3RpdGxlfVxuICAgICAgaXNPcGVuPXtpc09wZW59XG4gICAgICBvbkRpc21pc3M9e2Rpc21pc3N9XG4gICAgICBvblNhdmU9e3NhdmV9XG4gICAgICBkaXNhYmxlZD17aXNDcmVhdGluZ31cbiAgICAgIGxvYWRpbmc9e2lzQ3JlYXRpbmd9XG4gICAgPlxuICAgICAgPHByb3BzLmVkaXRGb3JtXG4gICAgICAgIGZvcm1EYXRhPXtmb3JtRGF0YX1cbiAgICAgICAgb25DaGFuZ2U9e3NldEZvcm1EYXRhfVxuICAgICAgICBhcGlFcnJvcj17ZXJyb3I/LnJlYXNvbiA/IGVycm9yPy5yZWFzb24gYXMgQXBpRXJyb3IgOiB1bmRlZmluZWR9XG4gICAgICAvPlxuICAgIDwvRWRpdERyYXdlcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSZXNvdXJjZUNyZWF0ZURyYXdlclxuIl19