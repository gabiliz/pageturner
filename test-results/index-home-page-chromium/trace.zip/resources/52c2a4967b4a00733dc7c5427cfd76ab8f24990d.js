export var FinancialStatementsSituationEnum = /* @__PURE__ */ ((FinancialStatementsSituationEnum2) => {
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["NOT_STARTED"] = 0] = "NOT_STARTED";
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["IN_PROGRESS"] = 1] = "IN_PROGRESS";
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["IN_REVISION"] = 2] = "IN_REVISION";
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["IN_ADJUST"] = 3] = "IN_ADJUST";
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["REVISED"] = 4] = "REVISED";
  FinancialStatementsSituationEnum2[FinancialStatementsSituationEnum2["WAITING_CLIENT"] = 5] = "WAITING_CLIENT";
  return FinancialStatementsSituationEnum2;
})(FinancialStatementsSituationEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gRmluYW5jaWFsU3RhdGVtZW50c1NpdHVhdGlvbkVudW0ge1xuICBOT1RfU1RBUlRFRCxcbiAgSU5fUFJPR1JFU1MsXG4gIElOX1JFVklTSU9OLFxuICBJTl9BREpVU1QsXG4gIFJFVklTRUQsXG4gIFdBSVRJTkdfQ0xJRU5ULFxufVxuIl0sIm1hcHBpbmdzIjoiQUFBTyxXQUFLLG1DQUFMLGtCQUFLQSxzQ0FBTDtBQUNMLEVBQUFBLG9FQUFBO0FBQ0EsRUFBQUEsb0VBQUE7QUFDQSxFQUFBQSxvRUFBQTtBQUNBLEVBQUFBLG9FQUFBO0FBQ0EsRUFBQUEsb0VBQUE7QUFDQSxFQUFBQSxvRUFBQTtBQU5VLFNBQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6WyJGaW5hbmNpYWxTdGF0ZW1lbnRzU2l0dWF0aW9uRW51bSJdfQ==