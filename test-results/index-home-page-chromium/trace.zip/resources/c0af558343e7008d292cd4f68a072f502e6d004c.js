import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTableSearch.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableSearch.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { SearchBox } from "/src/shared/components/inputs/index.ts?t=1701096626433";
const DataTableSearch = (props) => {
  _s();
  const {
    onChange
  } = props;
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV(SearchBox, { placeholder: "Pesquisar", onChange: (_, value) => onChange(value ?? ""), className: styles }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableSearch.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(DataTableSearch, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = DataTableSearch;
const useStyles = () => {
  return mergeStyles({
    width: 300
  });
};
export default DataTableSearch;
var _c;
$RefreshReg$(_c, "DataTableSearch");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaSixTQUFTQSxtQkFBbUI7QUFFNUIsU0FBU0MsaUJBQWlCO0FBTTFCLE1BQU1DLGtCQUE0Q0EsQ0FBQ0MsVUFBZ0M7QUFBQUMsS0FBQTtBQUNqRixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBUyxJQUFJRjtBQUNyQixRQUFNRyxTQUFTQyxVQUFVO0FBQ3pCLFNBQ0UsdUJBQUMsYUFDQyxhQUFZLGFBQ1osVUFBVSxDQUFDQyxHQUFHQyxVQUFVSixTQUFTSSxTQUFTLEVBQUUsR0FDNUMsV0FBV0gsVUFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR29CO0FBR3hCO0FBQUNGLEdBVktGLGlCQUF5QztBQUFBLFVBRTlCSyxTQUFTO0FBQUE7QUFBQUcsS0FGcEJSO0FBWU4sTUFBTUssWUFBWUEsTUFBTTtBQUN0QixTQUFPUCxZQUFZO0FBQUEsSUFDakJXLE9BQU87QUFBQSxFQUNULENBQUM7QUFDSDtBQUVBLGVBQWVUO0FBQWUsSUFBQVE7QUFBQUUsYUFBQUYsSUFBQSIsIm5hbWVzIjpbIm1lcmdlU3R5bGVzIiwiU2VhcmNoQm94IiwiRGF0YVRhYmxlU2VhcmNoIiwicHJvcHMiLCJfcyIsIm9uQ2hhbmdlIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiXyIsInZhbHVlIiwiX2MiLCJ3aWR0aCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhdGFUYWJsZVNlYXJjaC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kYXRhdGFibGUvRGF0YVRhYmxlU2VhcmNoLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1lcmdlU3R5bGVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBTZWFyY2hCb3ggfSBmcm9tICcuLi9pbnB1dHMnXHJcblxyXG5pbnRlcmZhY2UgRGF0YVRhYmxlU2VhcmNoUHJvcHMge1xyXG4gIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZFxyXG59XHJcblxyXG5jb25zdCBEYXRhVGFibGVTZWFyY2g6IEZDPERhdGFUYWJsZVNlYXJjaFByb3BzPiA9IChwcm9wczogRGF0YVRhYmxlU2VhcmNoUHJvcHMpID0+IHtcclxuICBjb25zdCB7IG9uQ2hhbmdlIH0gPSBwcm9wc1xyXG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcygpXHJcbiAgcmV0dXJuIChcclxuICAgIDxTZWFyY2hCb3hcclxuICAgICAgcGxhY2Vob2xkZXI9XCJQZXNxdWlzYXJcIlxyXG4gICAgICBvbkNoYW5nZT17KF8sIHZhbHVlKSA9PiBvbkNoYW5nZSh2YWx1ZSA/PyAnJyl9XHJcbiAgICAgIGNsYXNzTmFtZT17c3R5bGVzfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICByZXR1cm4gbWVyZ2VTdHlsZXMoe1xyXG4gICAgd2lkdGg6IDMwMCxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXRhVGFibGVTZWFyY2hcclxuIl19