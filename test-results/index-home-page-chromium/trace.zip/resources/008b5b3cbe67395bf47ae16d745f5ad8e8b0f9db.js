import {
  InjectionMode,
  Stylesheet,
  concatStyleSets,
  concatStyleSetsWithProps,
  fontFace,
  keyframes,
  mergeCss,
  mergeCssSets,
  mergeStyleSets,
  mergeStyles,
  setRTL
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";
export {
  InjectionMode,
  Stylesheet,
  concatStyleSets,
  concatStyleSetsWithProps,
  fontFace,
  keyframes,
  mergeCss,
  mergeCssSets,
  mergeStyleSets,
  mergeStyles,
  setRTL
};
//# sourceMappingURL=@fluentui_merge-styles.js.map
