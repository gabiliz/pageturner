import {
  AnimationClassNames,
  getGlobalClassNames,
  getIcon
} from "/node_modules/.vite/deps/chunk-XOB7MPSE.js?v=9f90a7ff";
import {
  useMergedRefs
} from "/node_modules/.vite/deps/chunk-AL35FZVI.js?v=9f90a7ff";
import {
  classNamesFunction,
  css,
  getNativeProps,
  getWindow,
  htmlElementProperties,
  imgProperties,
  memoizeFunction,
  styled,
  useIsomorphicLayoutEffect
} from "/node_modules/.vite/deps/chunk-JYWLVXGS.js?v=9f90a7ff";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  __assign,
  __extends,
  mergeStyleSets
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@fluentui/react/lib/components/Icon/Icon.base.js
var React3 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Icon/Icon.types.js
var IconType;
(function(IconType2) {
  IconType2[IconType2["default"] = 0] = "default";
  IconType2[IconType2["image"] = 1] = "image";
  IconType2[IconType2["Default"] = 1e5] = "Default";
  IconType2[IconType2["Image"] = 100001] = "Image";
})(IconType || (IconType = {}));

// node_modules/@fluentui/react/lib/components/Image/Image.base.js
var React = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Image/Image.types.js
var ImageFit;
(function(ImageFit2) {
  ImageFit2[ImageFit2["center"] = 0] = "center";
  ImageFit2[ImageFit2["contain"] = 1] = "contain";
  ImageFit2[ImageFit2["cover"] = 2] = "cover";
  ImageFit2[ImageFit2["none"] = 3] = "none";
  ImageFit2[ImageFit2["centerCover"] = 4] = "centerCover";
  ImageFit2[ImageFit2["centerContain"] = 5] = "centerContain";
})(ImageFit || (ImageFit = {}));
var ImageCoverStyle;
(function(ImageCoverStyle2) {
  ImageCoverStyle2[ImageCoverStyle2["landscape"] = 0] = "landscape";
  ImageCoverStyle2[ImageCoverStyle2["portrait"] = 1] = "portrait";
})(ImageCoverStyle || (ImageCoverStyle = {}));
var ImageLoadState;
(function(ImageLoadState2) {
  ImageLoadState2[ImageLoadState2["notLoaded"] = 0] = "notLoaded";
  ImageLoadState2[ImageLoadState2["loaded"] = 1] = "loaded";
  ImageLoadState2[ImageLoadState2["error"] = 2] = "error";
  ImageLoadState2[ImageLoadState2["errorLoaded"] = 3] = "errorLoaded";
})(ImageLoadState || (ImageLoadState = {}));

// node_modules/@fluentui/react/lib/components/Image/Image.base.js
var getClassNames = classNamesFunction();
var SVG_REGEX = /\.svg$/i;
var KEY_PREFIX = "fabricImage";
function useLoadState(props, imageElement) {
  var onLoadingStateChange = props.onLoadingStateChange, onLoad = props.onLoad, onError = props.onError, src = props.src;
  var _a = React.useState(ImageLoadState.notLoaded), loadState = _a[0], setLoadState = _a[1];
  useIsomorphicLayoutEffect(function() {
    setLoadState(ImageLoadState.notLoaded);
  }, [src]);
  React.useEffect(function() {
    if (loadState === ImageLoadState.notLoaded) {
      var isLoaded = imageElement.current ? src && imageElement.current.naturalWidth > 0 && imageElement.current.naturalHeight > 0 || imageElement.current.complete && SVG_REGEX.test(src) : false;
      if (isLoaded) {
        setLoadState(ImageLoadState.loaded);
      }
    }
  });
  React.useEffect(function() {
    onLoadingStateChange === null || onLoadingStateChange === void 0 ? void 0 : onLoadingStateChange(loadState);
  }, [loadState]);
  var onImageLoaded = React.useCallback(function(ev) {
    onLoad === null || onLoad === void 0 ? void 0 : onLoad(ev);
    if (src) {
      setLoadState(ImageLoadState.loaded);
    }
  }, [src, onLoad]);
  var onImageError = React.useCallback(function(ev) {
    onError === null || onError === void 0 ? void 0 : onError(ev);
    setLoadState(ImageLoadState.error);
  }, [onError]);
  return [loadState, onImageLoaded, onImageError];
}
var ImageBase = React.forwardRef(function(props, forwardedRef) {
  var frameElement = React.useRef();
  var imageElement = React.useRef();
  var _a = useLoadState(props, imageElement), loadState = _a[0], onImageLoaded = _a[1], onImageError = _a[2];
  var imageProps = getNativeProps(props, imgProperties, [
    "width",
    "height"
  ]);
  var src = props.src, alt = props.alt, width = props.width, height = props.height, _b = props.shouldFadeIn, shouldFadeIn = _b === void 0 ? true : _b, shouldStartVisible = props.shouldStartVisible, className = props.className, imageFit = props.imageFit, role = props.role, maximizeFrame = props.maximizeFrame, styles = props.styles, theme = props.theme, loading = props.loading;
  var coverStyle = useCoverStyle(props, loadState, imageElement, frameElement);
  var classNames2 = getClassNames(styles, {
    theme,
    className,
    width,
    height,
    maximizeFrame,
    shouldFadeIn,
    shouldStartVisible,
    isLoaded: loadState === ImageLoadState.loaded || loadState === ImageLoadState.notLoaded && props.shouldStartVisible,
    isLandscape: coverStyle === ImageCoverStyle.landscape,
    isCenter: imageFit === ImageFit.center,
    isCenterContain: imageFit === ImageFit.centerContain,
    isCenterCover: imageFit === ImageFit.centerCover,
    isContain: imageFit === ImageFit.contain,
    isCover: imageFit === ImageFit.cover,
    isNone: imageFit === ImageFit.none,
    isError: loadState === ImageLoadState.error,
    isNotImageFit: imageFit === void 0
  });
  return React.createElement(
    "div",
    { className: classNames2.root, style: { width, height }, ref: frameElement },
    React.createElement("img", __assign({}, imageProps, { onLoad: onImageLoaded, onError: onImageError, key: KEY_PREFIX + props.src || "", className: classNames2.image, ref: useMergedRefs(imageElement, forwardedRef), src, alt, role, loading }))
  );
});
ImageBase.displayName = "ImageBase";
function useCoverStyle(props, loadState, imageElement, frameElement) {
  var previousLoadState = React.useRef(loadState);
  var coverStyle = React.useRef();
  if (coverStyle === void 0 || previousLoadState.current === ImageLoadState.notLoaded && loadState === ImageLoadState.loaded) {
    coverStyle.current = computeCoverStyle(props, loadState, imageElement, frameElement);
  }
  previousLoadState.current = loadState;
  return coverStyle.current;
}
function computeCoverStyle(props, loadState, imageElement, frameElement) {
  var imageFit = props.imageFit, width = props.width, height = props.height;
  if (props.coverStyle !== void 0) {
    return props.coverStyle;
  } else if (loadState === ImageLoadState.loaded && (imageFit === ImageFit.cover || imageFit === ImageFit.contain || imageFit === ImageFit.centerContain || imageFit === ImageFit.centerCover) && imageElement.current && frameElement.current) {
    var desiredRatio = void 0;
    if (typeof width === "number" && typeof height === "number" && imageFit !== ImageFit.centerContain && imageFit !== ImageFit.centerCover) {
      desiredRatio = width / height;
    } else {
      desiredRatio = frameElement.current.clientWidth / frameElement.current.clientHeight;
    }
    var naturalRatio = imageElement.current.naturalWidth / imageElement.current.naturalHeight;
    if (naturalRatio > desiredRatio) {
      return ImageCoverStyle.landscape;
    }
  }
  return ImageCoverStyle.portrait;
}

// node_modules/@fluentui/react/lib/components/Image/Image.styles.js
var GlobalClassNames = {
  root: "ms-Image",
  rootMaximizeFrame: "ms-Image--maximizeFrame",
  image: "ms-Image-image",
  imageCenter: "ms-Image-image--center",
  imageContain: "ms-Image-image--contain",
  imageCover: "ms-Image-image--cover",
  imageCenterContain: "ms-Image-image--centerContain",
  imageCenterCover: "ms-Image-image--centerCover",
  imageNone: "ms-Image-image--none",
  imageLandscape: "ms-Image-image--landscape",
  imagePortrait: "ms-Image-image--portrait"
};
var getStyles = function(props) {
  var className = props.className, width = props.width, height = props.height, maximizeFrame = props.maximizeFrame, isLoaded = props.isLoaded, shouldFadeIn = props.shouldFadeIn, shouldStartVisible = props.shouldStartVisible, isLandscape = props.isLandscape, isCenter = props.isCenter, isContain = props.isContain, isCover = props.isCover, isCenterContain = props.isCenterContain, isCenterCover = props.isCenterCover, isNone = props.isNone, isError = props.isError, isNotImageFit = props.isNotImageFit, theme = props.theme;
  var classNames2 = getGlobalClassNames(GlobalClassNames, theme);
  var ImageFitStyles = {
    position: "absolute",
    left: "50% /* @noflip */",
    top: "50%",
    transform: "translate(-50%,-50%)"
    // @todo test RTL renders transform: translate(50%,-50%);
  };
  var window = getWindow();
  var supportsObjectFit = window !== void 0 && window.navigator.msMaxTouchPoints === void 0;
  var fallbackObjectFitStyles = isContain && isLandscape || isCover && !isLandscape ? { width: "100%", height: "auto" } : { width: "auto", height: "100%" };
  return {
    root: [
      classNames2.root,
      theme.fonts.medium,
      {
        overflow: "hidden"
      },
      maximizeFrame && [
        classNames2.rootMaximizeFrame,
        {
          height: "100%",
          width: "100%"
        }
      ],
      isLoaded && shouldFadeIn && !shouldStartVisible && AnimationClassNames.fadeIn400,
      (isCenter || isContain || isCover || isCenterContain || isCenterCover) && {
        position: "relative"
      },
      className
    ],
    image: [
      classNames2.image,
      {
        display: "block",
        opacity: 0
      },
      isLoaded && [
        "is-loaded",
        {
          opacity: 1
        }
      ],
      isCenter && [classNames2.imageCenter, ImageFitStyles],
      isContain && [
        classNames2.imageContain,
        supportsObjectFit && {
          width: "100%",
          height: "100%",
          objectFit: "contain"
        },
        !supportsObjectFit && fallbackObjectFitStyles,
        !supportsObjectFit && ImageFitStyles
      ],
      isCover && [
        classNames2.imageCover,
        supportsObjectFit && {
          width: "100%",
          height: "100%",
          objectFit: "cover"
        },
        !supportsObjectFit && fallbackObjectFitStyles,
        !supportsObjectFit && ImageFitStyles
      ],
      isCenterContain && [
        classNames2.imageCenterContain,
        isLandscape && {
          maxWidth: "100%"
        },
        !isLandscape && {
          maxHeight: "100%"
        },
        ImageFitStyles
      ],
      isCenterCover && [
        classNames2.imageCenterCover,
        isLandscape && {
          maxHeight: "100%"
        },
        !isLandscape && {
          maxWidth: "100%"
        },
        ImageFitStyles
      ],
      isNone && [
        classNames2.imageNone,
        {
          width: "auto",
          height: "auto"
        }
      ],
      isNotImageFit && [
        !!width && !height && {
          height: "auto",
          width: "100%"
        },
        !width && !!height && {
          height: "100%",
          width: "auto"
        },
        !!width && !!height && {
          height: "100%",
          width: "100%"
        }
      ],
      isLandscape && classNames2.imageLandscape,
      !isLandscape && classNames2.imagePortrait,
      !isLoaded && "is-notLoaded",
      shouldFadeIn && "is-fadeIn",
      isError && "is-error"
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Image/Image.js
var Image = styled(ImageBase, getStyles, void 0, {
  scope: "Image"
}, true);
Image.displayName = "Image";

// node_modules/@fluentui/react/lib/components/Icon/FontIcon.js
var React2 = __toESM(require_react());

// node_modules/@fluentui/react/lib/components/Icon/Icon.styles.js
var classNames = mergeStyleSets({
  root: {
    display: "inline-block"
  },
  placeholder: [
    "ms-Icon-placeHolder",
    {
      width: "1em"
    }
  ],
  image: [
    "ms-Icon-imageContainer",
    {
      overflow: "hidden"
    }
  ]
});
var MS_ICON = "ms-Icon";
var getStyles2 = function(props) {
  var className = props.className, iconClassName = props.iconClassName, isPlaceholder = props.isPlaceholder, isImage = props.isImage, styles = props.styles;
  return {
    root: [
      isPlaceholder && classNames.placeholder,
      classNames.root,
      isImage && classNames.image,
      iconClassName,
      className,
      styles && styles.root,
      // eslint-disable-next-line deprecation/deprecation
      styles && styles.imageContainer
    ]
  };
};

// node_modules/@fluentui/react/lib/components/Icon/FontIcon.js
var getIconContent = memoizeFunction(
  function(iconName) {
    var _a = getIcon(iconName) || {
      subset: {},
      code: void 0
    }, code = _a.code, subset = _a.subset;
    if (!code) {
      return null;
    }
    return {
      children: code,
      iconClassName: subset.className,
      fontFamily: subset.fontFace && subset.fontFace.fontFamily,
      mergeImageProps: subset.mergeImageProps
    };
  },
  void 0,
  true
  /*ignoreNullOrUndefinedResult */
);
var FontIcon = function(props) {
  var iconName = props.iconName, className = props.className, _a = props.style, style = _a === void 0 ? {} : _a;
  var iconContent = getIconContent(iconName) || {};
  var iconClassName = iconContent.iconClassName, children = iconContent.children, fontFamily = iconContent.fontFamily, mergeImageProps = iconContent.mergeImageProps;
  var nativeProps = getNativeProps(props, htmlElementProperties);
  var accessibleName = props["aria-label"] || props.title;
  var containerProps = props["aria-label"] || props["aria-labelledby"] || props.title ? {
    role: mergeImageProps ? void 0 : "img"
  } : {
    "aria-hidden": true
  };
  var finalChildren = children;
  if (mergeImageProps) {
    if (typeof children === "object" && typeof children.props === "object" && accessibleName) {
      finalChildren = React2.cloneElement(children, { alt: accessibleName });
    }
  }
  return React2.createElement("i", __assign({ "data-icon-name": iconName }, containerProps, nativeProps, mergeImageProps ? {
    title: void 0,
    "aria-label": void 0
  } : {}, {
    className: css(MS_ICON, classNames.root, iconClassName, !iconName && classNames.placeholder, className),
    // Apply the font family this way to ensure it doesn't get overridden by Fabric Core ms-Icon styles
    // https://github.com/microsoft/fluentui/issues/10449
    style: __assign({ fontFamily }, style)
  }), finalChildren);
};
var getFontIcon = memoizeFunction(function(iconName, className, ariaLabel) {
  return FontIcon({ iconName, className, "aria-label": ariaLabel });
});

// node_modules/@fluentui/react/lib/components/Icon/Icon.base.js
var getClassNames2 = classNamesFunction({
  // Icon is used a lot by other components.
  // It's likely to see expected cases which pass different className to the Icon.
  // Therefore setting a larger cache size.
  cacheSize: 100
});
var IconBase = (
  /** @class */
  function(_super) {
    __extends(IconBase2, _super);
    function IconBase2(props) {
      var _this = _super.call(this, props) || this;
      _this._onImageLoadingStateChange = function(state) {
        if (_this.props.imageProps && _this.props.imageProps.onLoadingStateChange) {
          _this.props.imageProps.onLoadingStateChange(state);
        }
        if (state === ImageLoadState.error) {
          _this.setState({ imageLoadError: true });
        }
      };
      _this.state = {
        imageLoadError: false
      };
      return _this;
    }
    IconBase2.prototype.render = function() {
      var _a = this.props, children = _a.children, className = _a.className, styles = _a.styles, iconName = _a.iconName, imageErrorAs = _a.imageErrorAs, theme = _a.theme;
      var isPlaceholder = typeof iconName === "string" && iconName.length === 0;
      var isImage = (
        // eslint-disable-next-line deprecation/deprecation
        !!this.props.imageProps || this.props.iconType === IconType.image || this.props.iconType === IconType.Image
      );
      var iconContent = getIconContent(iconName) || {};
      var iconClassName = iconContent.iconClassName, iconContentChildren = iconContent.children, mergeImageProps = iconContent.mergeImageProps;
      var classNames2 = getClassNames2(styles, {
        theme,
        className,
        iconClassName,
        isImage,
        isPlaceholder
      });
      var RootType = isImage ? "span" : "i";
      var nativeProps = getNativeProps(this.props, htmlElementProperties, [
        "aria-label"
      ]);
      var imageLoadError = this.state.imageLoadError;
      var imageProps = __assign(__assign({}, this.props.imageProps), { onLoadingStateChange: this._onImageLoadingStateChange });
      var ImageType = imageLoadError && imageErrorAs || Image;
      var ariaLabel = this.props["aria-label"] || this.props.ariaLabel;
      var accessibleName = imageProps.alt || ariaLabel || this.props.title;
      var hasName = !!(accessibleName || this.props["aria-labelledby"] || imageProps["aria-label"] || imageProps["aria-labelledby"]);
      var containerProps = hasName ? {
        role: isImage || mergeImageProps ? void 0 : "img",
        "aria-label": isImage || mergeImageProps ? void 0 : accessibleName
      } : {
        "aria-hidden": true
      };
      var finalIconContentChildren = iconContentChildren;
      if (mergeImageProps && iconContentChildren && typeof iconContentChildren === "object" && accessibleName) {
        finalIconContentChildren = React3.cloneElement(iconContentChildren, {
          alt: accessibleName
        });
      }
      return React3.createElement(RootType, __assign({ "data-icon-name": iconName }, containerProps, nativeProps, mergeImageProps ? {
        title: void 0,
        "aria-label": void 0
      } : {}, { className: classNames2.root }), isImage ? React3.createElement(ImageType, __assign({}, imageProps)) : children || finalIconContentChildren);
    };
    return IconBase2;
  }(React3.Component)
);

// node_modules/@fluentui/react/lib/components/Icon/Icon.js
var Icon = styled(IconBase, getStyles2, void 0, {
  scope: "Icon"
}, true);
Icon.displayName = "Icon";

// node_modules/@fluentui/react/lib/components/Icon/ImageIcon.js
var React4 = __toESM(require_react());
var ImageIcon = function(props) {
  var className = props.className, imageProps = props.imageProps;
  var nativeProps = getNativeProps(props, htmlElementProperties, [
    "aria-label",
    "aria-labelledby",
    "title",
    "aria-describedby"
  ]);
  var altText = imageProps.alt || props["aria-label"];
  var hasName = altText || props["aria-labelledby"] || props.title || imageProps["aria-label"] || imageProps["aria-labelledby"] || imageProps.title;
  var imageNameProps = {
    "aria-labelledby": props["aria-labelledby"],
    "aria-describedby": props["aria-describedby"],
    title: props.title
  };
  var containerProps = hasName ? {} : {
    "aria-hidden": true
  };
  return React4.createElement(
    "div",
    __assign({}, containerProps, nativeProps, { className: css(MS_ICON, classNames.root, classNames.image, className) }),
    React4.createElement(Image, __assign({}, imageNameProps, imageProps, { alt: hasName ? altText : "" }))
  );
};

export {
  IconType,
  ImageFit,
  ImageCoverStyle,
  ImageLoadState,
  ImageBase,
  Image,
  getIconContent,
  FontIcon,
  getFontIcon,
  IconBase,
  Icon,
  ImageIcon
};
//# sourceMappingURL=chunk-7CLY36K2.js.map
