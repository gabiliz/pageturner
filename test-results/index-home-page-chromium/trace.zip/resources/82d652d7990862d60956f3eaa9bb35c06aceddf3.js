import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/DefaultButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DefaultButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { DefaultButton as FluentDefaultButton, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
const DefaultButton = ({
  isLargeSize = false,
  ...props
}) => {
  _s();
  const styles = useStyles(isLargeSize, props.backgroundColor);
  return /* @__PURE__ */ jsxDEV(FluentDefaultButton, { className: styles.linkButton, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DefaultButton.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_s(DefaultButton, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = DefaultButton;
const useStyles = (isLargeSize, backgroundColor) => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = mergeStyleSets({
    linkButton: {
      color: colors.gray[600],
      backgroundColor: backgroundColor ?? colors.white,
      border: "none",
      height: 32,
      fontSize: 14,
      lineHeight: 20,
      fontWeight: 600,
      padding: isLargeSize ? "0 20px" : void 0,
      transition: "filter .1s, color .1s, background-color .1s, border-color .1s",
      selectors: {
        ":hover": {
          color: colors.gray[500],
          borderColor: colors.gray[500],
          backgroundColor: colors.gray[200]
        },
        ":active": {
          color: colors.gray[500],
          borderColor: colors.gray[500],
          backgroundColor: colors.gray[200]
        }
      }
    }
  });
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default DefaultButton;
var _c;
$RefreshReg$(_c, "DefaultButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DefaultButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYSixTQUFTQSxpQkFBaUJDLHFCQUFtQ0Msc0JBQXNCO0FBQ25GLFNBQVNDLHNCQUFzQjtBQU8vQixNQUFNSCxnQkFBeUNBLENBQUM7QUFBQSxFQUFFSSxjQUFjO0FBQUEsRUFBTyxHQUFHQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUNwRixRQUFNQyxTQUFTQyxVQUFVSixhQUFhQyxNQUFNSSxlQUFlO0FBQzNELFNBQ0UsdUJBQUMsdUJBQ0MsV0FBV0YsT0FBT0csWUFDbEIsR0FBSUwsU0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRVk7QUFHaEI7QUFBQ0MsR0FSS04sZUFBc0M7QUFBQSxVQUMzQlEsU0FBUztBQUFBO0FBQUFHLEtBRHBCWDtBQVVOLE1BQU1RLFlBQVlBLENBQUNKLGFBQXNCSyxvQkFBNkI7QUFBQUcsTUFBQTtBQUNwRSxRQUFNQyxTQUFTVixlQUFlO0FBQzlCLFFBQU1XLGVBQWVaLGVBQWU7QUFBQSxJQUNsQ1EsWUFBWTtBQUFBLE1BQ1ZLLE9BQU9GLE9BQU9HLEtBQUssR0FBRztBQUFBLE1BQ3RCUCxpQkFBaUJBLG1CQUFtQkksT0FBT0k7QUFBQUEsTUFDM0NDLFFBQVE7QUFBQSxNQUNSQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsU0FBU25CLGNBQWMsV0FBV29CO0FBQUFBLE1BQ2xDQyxZQUFZO0FBQUEsTUFDWkMsV0FBVztBQUFBLFFBQ1QsVUFBVTtBQUFBLFVBQ1JYLE9BQU9GLE9BQU9HLEtBQUssR0FBRztBQUFBLFVBQ3RCVyxhQUFhZCxPQUFPRyxLQUFLLEdBQUc7QUFBQSxVQUM1QlAsaUJBQWlCSSxPQUFPRyxLQUFLLEdBQUc7QUFBQSxRQUNsQztBQUFBLFFBQ0EsV0FBVztBQUFBLFVBQ1RELE9BQU9GLE9BQU9HLEtBQUssR0FBRztBQUFBLFVBQ3RCVyxhQUFhZCxPQUFPRyxLQUFLLEdBQUc7QUFBQSxVQUM1QlAsaUJBQWlCSSxPQUFPRyxLQUFLLEdBQUc7QUFBQSxRQUNsQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBT0Y7QUFDVDtBQUFDRixJQTdCS0osV0FBUztBQUFBLFVBQ0VMLGNBQWM7QUFBQTtBQThCL0IsZUFBZUg7QUFBYSxJQUFBVztBQUFBaUIsYUFBQWpCLElBQUEiLCJuYW1lcyI6WyJEZWZhdWx0QnV0dG9uIiwiRmx1ZW50RGVmYXVsdEJ1dHRvbiIsIm1lcmdlU3R5bGVTZXRzIiwidXNlVGhlbWVDb2xvcnMiLCJpc0xhcmdlU2l6ZSIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJsaW5rQnV0dG9uIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJhY3Rpb25TdHlsZXMiLCJjb2xvciIsImdyYXkiLCJ3aGl0ZSIsImJvcmRlciIsImhlaWdodCIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImZvbnRXZWlnaHQiLCJwYWRkaW5nIiwidW5kZWZpbmVkIiwidHJhbnNpdGlvbiIsInNlbGVjdG9ycyIsImJvcmRlckNvbG9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGVmYXVsdEJ1dHRvbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9idXR0b25zL0RlZmF1bHRCdXR0b24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERlZmF1bHRCdXR0b24gYXMgRmx1ZW50RGVmYXVsdEJ1dHRvbiwgSUJ1dHRvblByb3BzLCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lQ29sb3JzIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5cbmludGVyZmFjZSBJRGVmYXVsdEJ1dHRvblByb3BzIGV4dGVuZHMgSUJ1dHRvblByb3BzIHtcbiAgaXNMYXJnZVNpemU/OiBib29sZWFuXG4gIGJhY2tncm91bmRDb2xvcj86IHN0cmluZyxcbn1cblxuY29uc3QgRGVmYXVsdEJ1dHRvbjogRkM8SURlZmF1bHRCdXR0b25Qcm9wcz4gPSAoeyBpc0xhcmdlU2l6ZSA9IGZhbHNlLCAuLi5wcm9wcyB9KSA9PiB7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcyhpc0xhcmdlU2l6ZSwgcHJvcHMuYmFja2dyb3VuZENvbG9yKVxuICByZXR1cm4gKFxuICAgIDxGbHVlbnREZWZhdWx0QnV0dG9uXG4gICAgICBjbGFzc05hbWU9e3N0eWxlcy5saW5rQnV0dG9ufVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKGlzTGFyZ2VTaXplOiBib29sZWFuLCBiYWNrZ3JvdW5kQ29sb3I/OiBzdHJpbmcpID0+IHtcbiAgY29uc3QgY29sb3JzID0gdXNlVGhlbWVDb2xvcnMoKVxuICBjb25zdCBhY3Rpb25TdHlsZXMgPSBtZXJnZVN0eWxlU2V0cyh7XG4gICAgbGlua0J1dHRvbjoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGJhY2tncm91bmRDb2xvciA/PyBjb2xvcnMud2hpdGUsXG4gICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgIGhlaWdodDogMzIsXG4gICAgICBmb250U2l6ZTogMTQsXG4gICAgICBsaW5lSGVpZ2h0OiAyMCxcbiAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcbiAgICAgIHBhZGRpbmc6IGlzTGFyZ2VTaXplID8gJzAgMjBweCcgOiB1bmRlZmluZWQsXG4gICAgICB0cmFuc2l0aW9uOiAnZmlsdGVyIC4xcywgY29sb3IgLjFzLCBiYWNrZ3JvdW5kLWNvbG9yIC4xcywgYm9yZGVyLWNvbG9yIC4xcycsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNTAwXSxcbiAgICAgICAgICBib3JkZXJDb2xvcjogY29sb3JzLmdyYXlbNTAwXSxcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXG4gICAgICAgIH0sXG4gICAgICAgICc6YWN0aXZlJzoge1xuICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs1MDBdLFxuICAgICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMuZ3JheVs1MDBdLFxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcblxuICByZXR1cm4gYWN0aW9uU3R5bGVzXG59XG5cbmV4cG9ydCBkZWZhdWx0IERlZmF1bHRCdXR0b25cbiJdfQ==