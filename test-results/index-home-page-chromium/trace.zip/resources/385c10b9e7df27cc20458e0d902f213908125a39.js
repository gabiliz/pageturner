import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import.meta.env = {"M_REQUEST_TIMEOUT":"0","M_REFRESH_TOKEN_ENDPOINT":"/api/account/refresh-token","MANPATH":"/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man:/usr/share/man:/usr/local/share/man:/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man::","MallocNanoZone":"0","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AuthRoutes, PageRoutes, SideBarModulesRoutes, SideMenuRoutes } from "/src/routes/index.ts?t=1701096626433";
import { Page } from "/src/shared/components/layout/index.ts?t=1701096626433";
import { AppBar, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { useHandleRejection } from "/src/shared/hooks/index.ts";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { BaseApi } from "/src/shared/api/BaseApi.ts";
import { initializeFileTypeIcons } from "/node_modules/.vite/deps/@fluentui_react-file-type-icons.js?v=9f90a7ff";
import { initializeGlobalization } from "/src/shared/translations/index.ts";
initializeFileTypeIcons();
initializeGlobalization();
const App = () => {
  _s();
  const {
    currentAccount,
    isAuthenticated,
    fetchCurrentAccount
  } = useAuth();
  const {
    showNotification
  } = useNotifications();
  const location = useLocation();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  const notifyOnError = useCallback((error) => {
    if (error.reason.errors) {
      const reason = error.reason;
      reason.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error,
          timeout: 1e4
        });
      });
    }
    if (error.reason.title) {
      showNotification({
        message: error.reason.title,
        type: MessageBarType.error,
        timeout: 1e4
      });
    }
  }, []);
  useEffect(() => {
    fetchCurrentAccount().catch(() => {
    });
  }, []);
  useEffect(() => {
    registerListener(notifyOnError);
    return () => {
      unregisterListener(notifyOnError);
    };
  }, [notifyOnError]);
  useEffect(() => {
    const interval = setInterval(() => {
      const baseApi = new BaseApi(!import.meta.env.DEV ? import.meta.env.M_API_BASE_MODULE_AUTH : "");
      baseApi.regenerateToken();
    }, 9e5);
    return () => clearInterval(interval);
  }, []);
  if (currentAccount.status === "idle" || currentAccount.status === "pending") {
    return /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 68,
      columnNumber: 12
    }, this);
  }
  if (isAuthenticated) {
    return /* @__PURE__ */ jsxDEV(Page, { topBar: /* @__PURE__ */ jsxDEV(AppBar, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 71,
      columnNumber: 26
    }, this), sideBarModules: /* @__PURE__ */ jsxDEV(SideBarModulesRoutes, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 71,
      columnNumber: 54
    }, this), sideBar: /* @__PURE__ */ jsxDEV(SideMenuRoutes, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 71,
      columnNumber: 89
    }, this), pageContent: /* @__PURE__ */ jsxDEV(PageRoutes, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 71,
      columnNumber: 122
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
      lineNumber: 71,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Page, { topBar: location.pathname === "/form-list" || location.pathname === "/answer" || location.pathname === "/financial-statements" ? /* @__PURE__ */ jsxDEV(AppBar, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
    lineNumber: 73,
    columnNumber: 145
  }, this) : void 0, pageContent: /* @__PURE__ */ jsxDEV(AuthRoutes, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
    lineNumber: 73,
    columnNumber: 182
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/App.tsx",
    lineNumber: 73,
    columnNumber: 10
  }, this);
};
_s(App, "6fxOzzcb6dGDfJ5xlX7aCe/Y6/k=", false, function() {
  return [useAuth, useNotifications, useLocation, useHandleRejection];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkVXOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0VYLFNBQWFBLFdBQVdDLG1CQUFtQjtBQUMzQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsWUFBWUMsWUFBWUMsc0JBQXNCQyxzQkFBc0I7QUFDN0UsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msd0JBQXdCO0FBRWpDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQywrQkFBK0I7QUFFeENELHdCQUF3QjtBQUN4QkMsd0JBQXdCO0FBRXhCLE1BQU1DLE1BQVVBLE1BQU07QUFBQUMsS0FBQTtBQUNwQixRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJWCxRQUFRO0FBRVosUUFBTTtBQUFBLElBQUVZO0FBQUFBLEVBQWlCLElBQUlWLGlCQUFpQjtBQUM5QyxRQUFNVyxXQUFXVixZQUFZO0FBRTdCLFFBQU07QUFBQSxJQUNKVztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlkLG1CQUFtQjtBQUV2QixRQUFNZSxnQkFBZ0J6QixZQUFZLENBQUMwQixVQUFpQztBQUNsRSxRQUFJQSxNQUFNQyxPQUFPQyxRQUFRO0FBQ3ZCLFlBQU1ELFNBQVNELE1BQU1DO0FBQ3JCQSxhQUFPQyxRQUFRQyxVQUFVQyxRQUFRQyxrQkFBZ0I7QUFDL0NWLHlCQUFpQjtBQUFBLFVBQ2ZXLFNBQVNELGFBQWFDO0FBQUFBLFVBQ3RCQyxNQUFNaEMsZUFBZXlCO0FBQUFBLFVBQ3JCUSxTQUFTO0FBQUEsUUFDWCxDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUlSLE1BQU1DLE9BQU9RLE9BQU87QUFDdEJkLHVCQUFpQjtBQUFBLFFBQ2ZXLFNBQVNOLE1BQU1DLE9BQU9RO0FBQUFBLFFBQ3RCRixNQUFNaEMsZUFBZXlCO0FBQUFBLFFBQ3JCUSxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxuQyxZQUFVLE1BQU07QUFDZHFCLHdCQUFvQixFQUFFZ0IsTUFBTSxNQUFNO0FBQUEsSUFBRSxDQUF5QztBQUFBLEVBQy9FLEdBQUcsRUFBRTtBQUVMckMsWUFBVSxNQUFNO0FBQ2R3QixxQkFBaUJFLGFBQWE7QUFDOUIsV0FBTyxNQUFNO0FBQ1hELHlCQUFtQkMsYUFBYTtBQUFBLElBQ2xDO0FBQUEsRUFDRixHQUFHLENBQUNBLGFBQWEsQ0FBQztBQUVsQjFCLFlBQVUsTUFBTTtBQUNkLFVBQU1zQyxXQUFXQyxZQUFZLE1BQU07QUFDakMsWUFBTUMsVUFBVSxJQUFJMUIsUUFDbEIsQ0FBQzJCLFlBQVlDLElBQUlDLE1BQ2JGLFlBQVlDLElBQUlFLHlCQUNoQixFQUNOO0FBQ0FKLGNBQVFLLGdCQUFnQjtBQUFBLElBQzFCLEdBQUcsR0FBTTtBQUVULFdBQU8sTUFBTUMsY0FBY1IsUUFBUTtBQUFBLEVBQ3JDLEdBQUcsRUFBRTtBQUVMLE1BQUluQixlQUFlNEIsV0FBVyxVQUFVNUIsZUFBZTRCLFdBQVcsV0FBVztBQUMzRSxXQUFPLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLEVBQ3ZCO0FBRUEsTUFBSTNCLGlCQUFpQjtBQUNuQixXQUNFLHVCQUFDLFFBQ0MsUUFBUSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTyxHQUNmLGdCQUFnQix1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCLEdBQ3JDLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEdBQ3hCLGFBQWEsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXLEtBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJOEI7QUFBQSxFQUdsQztBQUVBLFNBQU8sdUJBQUMsUUFDTixRQUFRRyxTQUFTeUIsYUFBYSxnQkFBZ0J6QixTQUFTeUIsYUFBYSxhQUFhekIsU0FBU3lCLGFBQWEsMEJBQ25HLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPLElBQ1BDLFFBRUosYUFBYSx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVcsS0FMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUt1QjtBQUVoQztBQUFDL0IsR0FqRktELEtBQU87QUFBQSxVQUtQUCxTQUV5QkUsa0JBQ1pDLGFBS2JGLGtCQUFrQjtBQUFBO0FBQUF1QyxLQWJsQmpDO0FBbUZOLGVBQWVBO0FBQUcsSUFBQWlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsIk1lc3NhZ2VCYXJUeXBlIiwiQXV0aFJvdXRlcyIsIlBhZ2VSb3V0ZXMiLCJTaWRlQmFyTW9kdWxlc1JvdXRlcyIsIlNpZGVNZW51Um91dGVzIiwiUGFnZSIsIkFwcEJhciIsIkxvYWRpbmdTY3JlZW4iLCJ1c2VBdXRoIiwidXNlSGFuZGxlUmVqZWN0aW9uIiwidXNlTm90aWZpY2F0aW9ucyIsInVzZUxvY2F0aW9uIiwiQmFzZUFwaSIsImluaXRpYWxpemVGaWxlVHlwZUljb25zIiwiaW5pdGlhbGl6ZUdsb2JhbGl6YXRpb24iLCJBcHAiLCJfcyIsImN1cnJlbnRBY2NvdW50IiwiaXNBdXRoZW50aWNhdGVkIiwiZmV0Y2hDdXJyZW50QWNjb3VudCIsInNob3dOb3RpZmljYXRpb24iLCJsb2NhdGlvbiIsInJlZ2lzdGVyTGlzdGVuZXIiLCJ1bnJlZ2lzdGVyTGlzdGVuZXIiLCJub3RpZnlPbkVycm9yIiwiZXJyb3IiLCJyZWFzb24iLCJlcnJvcnMiLCJtZXNzYWdlcyIsImZvckVhY2giLCJlcnJvck1lc3NhZ2UiLCJtZXNzYWdlIiwidHlwZSIsInRpbWVvdXQiLCJ0aXRsZSIsImNhdGNoIiwiaW50ZXJ2YWwiLCJzZXRJbnRlcnZhbCIsImJhc2VBcGkiLCJpbXBvcnQiLCJlbnYiLCJERVYiLCJNX0FQSV9CQVNFX01PRFVMRV9BVVRIIiwicmVnZW5lcmF0ZVRva2VuIiwiY2xlYXJJbnRlcnZhbCIsInN0YXR1cyIsInBhdGhuYW1lIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvQXBwLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IE1lc3NhZ2VCYXJUeXBlIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBBdXRoUm91dGVzLCBQYWdlUm91dGVzLCBTaWRlQmFyTW9kdWxlc1JvdXRlcywgU2lkZU1lbnVSb3V0ZXMgfSBmcm9tICcuL3JvdXRlcydcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gJy4vc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0J1xyXG5pbXBvcnQgeyBBcHBCYXIsIExvYWRpbmdTY3JlZW4gfSBmcm9tICcuL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9tb2R1bGVzL2F1dGgvc3RvcmUvYXV0aCdcclxuaW1wb3J0IHsgdXNlSGFuZGxlUmVqZWN0aW9uIH0gZnJvbSAnLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuL3NoYXJlZC9zdG9yZS9ub3RpZmljYXRpb25zL25vdGlmaWNhdGlvbnMnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi9zaGFyZWQvZXJyb3JzJ1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IEJhc2VBcGkgfSBmcm9tICcuL3NoYXJlZC9hcGkvQmFzZUFwaSdcclxuaW1wb3J0IHsgaW5pdGlhbGl6ZUZpbGVUeXBlSWNvbnMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtZmlsZS10eXBlLWljb25zJ1xyXG5pbXBvcnQgeyBpbml0aWFsaXplR2xvYmFsaXphdGlvbiB9IGZyb20gJy4vc2hhcmVkL3RyYW5zbGF0aW9ucydcclxuXHJcbmluaXRpYWxpemVGaWxlVHlwZUljb25zKClcclxuaW5pdGlhbGl6ZUdsb2JhbGl6YXRpb24oKVxyXG5cclxuY29uc3QgQXBwOiBGQyA9ICgpID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBjdXJyZW50QWNjb3VudCxcclxuICAgIGlzQXV0aGVudGljYXRlZCxcclxuICAgIGZldGNoQ3VycmVudEFjY291bnQsXHJcbiAgfSA9IHVzZUF1dGgoKVxyXG5cclxuICBjb25zdCB7IHNob3dOb3RpZmljYXRpb24gfSA9IHVzZU5vdGlmaWNhdGlvbnMoKVxyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxyXG5cclxuICBjb25zdCB7XHJcbiAgICByZWdpc3Rlckxpc3RlbmVyLFxyXG4gICAgdW5yZWdpc3Rlckxpc3RlbmVyLFxyXG4gIH0gPSB1c2VIYW5kbGVSZWplY3Rpb24oKVxyXG5cclxuICBjb25zdCBub3RpZnlPbkVycm9yID0gdXNlQ2FsbGJhY2soKGVycm9yOiBQcm9taXNlUmVqZWN0aW9uRXZlbnQpID0+IHtcclxuICAgIGlmIChlcnJvci5yZWFzb24uZXJyb3JzKSB7XHJcbiAgICAgIGNvbnN0IHJlYXNvbiA9IGVycm9yLnJlYXNvbiBhcyBBcGlFcnJvclxyXG4gICAgICByZWFzb24uZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaChlcnJvck1lc3NhZ2UgPT4ge1xyXG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICAgIHRpbWVvdXQ6IDEwMDAwLFxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBpZiAoZXJyb3IucmVhc29uLnRpdGxlKSB7XHJcbiAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlYXNvbi50aXRsZSxcclxuICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICB0aW1lb3V0OiAxMDAwMCxcclxuICAgICAgfSlcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQ3VycmVudEFjY291bnQoKS5jYXRjaCgoKSA9PiB7IC8qIHByZXZlbnQgdW5oYW5kbGVkIHJlamVjdGlvbiBlcnJvciAqLyB9KVxyXG4gIH0sIFtdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgcmVnaXN0ZXJMaXN0ZW5lcihub3RpZnlPbkVycm9yKVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgdW5yZWdpc3Rlckxpc3RlbmVyKG5vdGlmeU9uRXJyb3IpXHJcbiAgICB9XHJcbiAgfSwgW25vdGlmeU9uRXJyb3JdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGJhc2VBcGkgPSBuZXcgQmFzZUFwaShcclxuICAgICAgICAhaW1wb3J0Lm1ldGEuZW52LkRFVlxyXG4gICAgICAgICAgPyBpbXBvcnQubWV0YS5lbnYuTV9BUElfQkFTRV9NT0RVTEVfQVVUSFxyXG4gICAgICAgICAgOiAnJyxcclxuICAgICAgKVxyXG4gICAgICBiYXNlQXBpLnJlZ2VuZXJhdGVUb2tlbigpXHJcbiAgICB9LCA5MDAwMDApXHJcblxyXG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpXHJcbiAgfSwgW10pXHJcblxyXG4gIGlmIChjdXJyZW50QWNjb3VudC5zdGF0dXMgPT09ICdpZGxlJyB8fCBjdXJyZW50QWNjb3VudC5zdGF0dXMgPT09ICdwZW5kaW5nJykge1xyXG4gICAgcmV0dXJuIDxMb2FkaW5nU2NyZWVuIC8+XHJcbiAgfVxyXG5cclxuICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8UGFnZVxyXG4gICAgICAgIHRvcEJhcj17PEFwcEJhciAvPn1cclxuICAgICAgICBzaWRlQmFyTW9kdWxlcz17PFNpZGVCYXJNb2R1bGVzUm91dGVzIC8+fVxyXG4gICAgICAgIHNpZGVCYXI9ezxTaWRlTWVudVJvdXRlcyAvPn1cclxuICAgICAgICBwYWdlQ29udGVudD17PFBhZ2VSb3V0ZXMgLz59XHJcbiAgICAgIC8+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gPFBhZ2VcclxuICAgIHRvcEJhcj17bG9jYXRpb24ucGF0aG5hbWUgPT09ICcvZm9ybS1saXN0JyB8fCBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy9hbnN3ZXInIHx8IGxvY2F0aW9uLnBhdGhuYW1lID09PSAnL2ZpbmFuY2lhbC1zdGF0ZW1lbnRzJ1xyXG4gICAgICA/IDxBcHBCYXIgLz5cclxuICAgICAgOiB1bmRlZmluZWRcclxuICAgIH1cclxuICAgIHBhZ2VDb250ZW50PXs8QXV0aFJvdXRlcyAvPn1cclxuICAvPlxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHBcclxuIl19