import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { IconButton, mergeStyleSets, MessageBarType, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"]; const useMemo = __vite__cjsImport4_react["useMemo"];
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { NotificationsCenterSettingsSection, NotificationsDeadlineDropdown } from "/src/shared/components/notifications/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { DeadlineEnum } from "/src/shared/enums/DeadlineEnum.ts";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { notificationsConfigService } from "/src/shared/services/notificationsServices/index.ts";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { DefaultButton, PrimaryButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import { AppDrawer } from "/src/shared/components/drawer/index.ts?t=1701096626433";
import { FlexColumn, FlexRow } from "/src/shared/components/FlexBox/index.ts";
import NotificationsCenterSettingsCheckboxItem from "/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx";
const NotificationsCenterSettingsContainer = (props) => {
  _s();
  const {
    isOpen,
    onDismiss
  } = props;
  const {
    openDialog
  } = useDialogs();
  const {
    spacing,
    fontSize,
    colors
  } = useTheme();
  const {
    settingsStyles,
    actionStyles
  } = useStyles();
  const {
    currentAccount: {
      value: current
    }
  } = useAuth();
  const userNotificationConfig = useMemo(() => {
    if (current) {
      const currentConfig = {
        id: current.id,
        periodoPrazoNotificacao: current.periodoPrazoNotificacao,
        moduloAdministrativoNotificacao: current.moduloAdministrativoNotificacao,
        moduloContabilNotificacao: current.moduloContabilNotificacao,
        moduloFiscalNotificacao: current.moduloFiscalNotificacao
      };
      return currentConfig;
    }
  }, [current]);
  const {
    formData,
    onCheckboxChange,
    onDropdownChange
  } = useFormData(userNotificationConfig);
  const {
    mutateAsync: updateConfig,
    isLoading
  } = useUpdateNotificationConfig(formData);
  const handleSaveConfig = useCallback(async () => {
    await updateConfig();
  }, [formData]);
  const onRenderNavigationContent = useCallback((props2, defaultRender) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(FlexColumn, { width: "100%", gap: spacing.md, padding: spacing.xl, children: [
      /* @__PURE__ */ jsxDEV(FlexRow, { gap: 10, verticalAlign: "center", children: [
        isOpen && /* @__PURE__ */ jsxDEV(IconButton, { onClick: onDismiss, iconProps: {
          iconName: "Arrow-left",
          styles: {
            root: {
              width: 16,
              height: 16
            }
          }
        }, ariaLabel: "Voltar" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
          lineNumber: 74,
          columnNumber: 24
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { styles: {
          root: {
            fontSize: fontSize.h4,
            fontWeight: 600
          }
        }, children: "Notificações" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
          lineNumber: 84,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
        lineNumber: 73,
        columnNumber: 11
      }, this),
      isOpen && /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          color: colors.gray[400],
          fontSize: fontSize.p16,
          fontWeight: "regular"
        }
      }, children: "Configurações" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
        lineNumber: 94,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 72,
      columnNumber: 9
    }, this),
    defaultRender && defaultRender(props2)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
    lineNumber: 71,
    columnNumber: 105
  }, this), [isOpen, onDismiss]);
  const confirmSave = useCallback(() => {
    openDialog({
      title: "Salvar configurações",
      description: "Caso alterado o período, as notificações com data anterior ao novo valor escolhido vão ser excluídas. Deseja salvar mesmo assim?",
      acceptLabel: "Salvar",
      style: "default",
      onAccept: () => handleSaveConfig()
    });
  }, [handleSaveConfig]);
  const Footer = useMemo(() => /* @__PURE__ */ jsxDEV("div", { className: actionStyles.actions, children: [
    /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Cancelar", onClick: () => onDismiss() }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Salvar", onClick: confirmSave, isLoading }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
    lineNumber: 115,
    columnNumber: 32
  }, this), [handleSaveConfig, isLoading]);
  return /* @__PURE__ */ jsxDEV(AppDrawer, { isOpen, onDismiss, title: "", onRenderNavigationContent, footer: Footer, noPadding: true, children: /* @__PURE__ */ jsxDEV(FlexColumn, { gap: spacing.lg, className: settingsStyles.container, children: [
    /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsSection, { title: "Módulos", subtitle: "Ver notificações dos módulos abaixo", children: [
      /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsCheckboxItem, { id: "admin", description: "Administrativo", checked: formData.moduloAdministrativoNotificacao, onChange: onCheckboxChange("moduloAdministrativoNotificacao") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
        lineNumber: 122,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsCheckboxItem, { id: "audit", description: "Projetos", checked: formData.moduloContabilNotificacao, onChange: onCheckboxChange("moduloContabilNotificacao") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
        lineNumber: 124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsCheckboxItem, { id: "fiscal", description: "Fiscal", checked: formData.moduloFiscalNotificacao, onChange: onCheckboxChange("moduloFiscalNotificacao") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
        lineNumber: 126,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 121,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NotificationsCenterSettingsSection, { title: "Prazo", subtitle: "Ver notificações de até", children: /* @__PURE__ */ jsxDEV(NotificationsDeadlineDropdown, { label: "Período", defaultSelectedKey: formData.periodoPrazoNotificacao || DeadlineEnum.all, onChange: onDropdownChange("periodoPrazoNotificacao") }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 130,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
      lineNumber: 129,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
    lineNumber: 120,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx",
    lineNumber: 119,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterSettingsContainer, "HfVCfJAtFVurjBQRumevGukcbnA=", false, function() {
  return [useDialogs, useTheme, useStyles, useAuth, useFormData, useUpdateNotificationConfig];
});
_c = NotificationsCenterSettingsContainer;
const useStyles = () => {
  _s2();
  const {
    spacing
  } = useTheme();
  const actionStyles = mergeStyleSets({
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    },
    wrapper: {
      height: "65vh",
      position: "relative",
      maxHeight: "inherit"
    }
  });
  const settingsStyles = mergeStyleSets({
    container: {
      paddingLeft: spacing.xl,
      paddingRight: spacing.xl
    }
  });
  return {
    actionStyles,
    settingsStyles
  };
};
_s2(useStyles, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
const useUpdateNotificationConfig = (notification) => {
  _s3();
  const {
    showNotification
  } = useNotifications();
  const {
    fetchCurrentAccount
  } = useAuth();
  return useMutation(() => notificationsConfigService.update(notification), {
    onSuccess: () => {
      showNotification({
        message: "Configuração das notificações atualizadas!",
        type: MessageBarType.success
      });
      fetchCurrentAccount();
    },
    onError: (error) => {
      error.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error
        });
      });
    }
  });
};
_s3(useUpdateNotificationConfig, "8hKDTldobHSv9WRjKZaFy2omjlM=", false, function() {
  return [useNotifications, useAuth, useMutation];
});
export default NotificationsCenterSettingsContainer;
var _c;
$RefreshReg$(_c, "NotificationsCenterSettingsContainer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RNLG1CQUlRLGNBSlI7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0RE4sU0FBU0EsWUFBMENDLGdCQUFnQkMsZ0JBQWdCQyxZQUFZO0FBQy9GLFNBQWFDLGFBQWFDLGVBQWU7QUFDekMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG9DQUFvQ0MscUNBQXFDO0FBRWxGLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msb0JBQW9CO0FBRTdCLFNBQVNDLGFBQWFDLGdCQUFnQjtBQUN0QyxTQUFTQyxrQ0FBa0M7QUFDM0MsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxlQUFlQyxxQkFBcUI7QUFDN0MsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFlBQVlDLGVBQWU7QUFDcEMsT0FBT0MsNkNBQTZDO0FBT3BELE1BQU1DLHVDQUF1RkMsV0FBVTtBQUFBQyxLQUFBO0FBQ3JHLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFRQztBQUFBQSxFQUFVLElBQUlIO0FBQzlCLFFBQU07QUFBQSxJQUFFSTtBQUFBQSxFQUFXLElBQUliLFdBQVc7QUFDbEMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVNDO0FBQUFBLElBQVVDO0FBQUFBLEVBQU8sSUFBSWxCLFNBQVM7QUFDL0MsUUFBTTtBQUFBLElBQUVtQjtBQUFBQSxJQUFnQkM7QUFBQUEsRUFBYSxJQUFJQyxVQUFVO0FBRW5ELFFBQU07QUFBQSxJQUFFQyxnQkFBZ0I7QUFBQSxNQUFFQyxPQUFPQztBQUFBQSxJQUFRO0FBQUEsRUFBRSxJQUFJM0IsUUFBUTtBQUV2RCxRQUFNNEIseUJBQXlCaEMsUUFBUSxNQUFNO0FBQzNDLFFBQUkrQixTQUFTO0FBQ1gsWUFBTUUsZ0JBQW9DO0FBQUEsUUFDeENDLElBQUlILFFBQVFHO0FBQUFBLFFBQ1pDLHlCQUF5QkosUUFBUUk7QUFBQUEsUUFDakNDLGlDQUFpQ0wsUUFBUUs7QUFBQUEsUUFDekNDLDJCQUEyQk4sUUFBUU07QUFBQUEsUUFDbkNDLHlCQUF5QlAsUUFBUU87QUFBQUEsTUFDbkM7QUFFQSxhQUFPTDtBQUFBQSxJQUNUO0FBQUEsRUFDRixHQUFHLENBQUNGLE9BQU8sQ0FBQztBQUVaLFFBQU07QUFBQSxJQUFFUTtBQUFBQSxJQUFVQztBQUFBQSxJQUFrQkM7QUFBQUEsRUFBaUIsSUFBSW5DLFlBQWdDMEIsc0JBQTRDO0FBRXJJLFFBQU07QUFBQSxJQUFFVSxhQUFhQztBQUFBQSxJQUFjQztBQUFBQSxFQUFVLElBQUlDLDRCQUE0Qk4sUUFBUTtBQUVyRixRQUFNTyxtQkFBbUIvQyxZQUFZLFlBQVk7QUFDL0MsVUFBTTRDLGFBQWE7QUFBQSxFQUNyQixHQUFHLENBQUNKLFFBQVEsQ0FBQztBQUViLFFBQU1RLDRCQUEwRGhELFlBQzlELENBQUNtQixRQUFPOEIsa0JBQ04sbUNBQ0U7QUFBQSwyQkFBQyxjQUFXLE9BQU0sUUFBTyxLQUFLekIsUUFBUTBCLElBQUksU0FBUzFCLFFBQVEyQixJQUN6RDtBQUFBLDZCQUFDLFdBQVEsS0FBSyxJQUFJLGVBQWMsVUFDN0I5QjtBQUFBQSxrQkFDQyx1QkFBQyxjQUNDLFNBQVNDLFdBQ1QsV0FBVztBQUFBLFVBQ1Q4QixVQUFVO0FBQUEsVUFDVkMsUUFBUTtBQUFBLFlBQ05DLE1BQU07QUFBQSxjQUNKQyxPQUFPO0FBQUEsY0FDUEMsUUFBUTtBQUFBLFlBQ1Y7QUFBQSxVQUNGO0FBQUEsUUFDRixHQUNBLFdBQVUsWUFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV29CO0FBQUEsUUFJdEIsdUJBQUMsUUFBSyxRQUFRO0FBQUEsVUFDWkYsTUFBTTtBQUFBLFlBQ0o3QixVQUFVQSxTQUFTZ0M7QUFBQUEsWUFDbkJDLFlBQVk7QUFBQSxVQUNkO0FBQUEsUUFDRixHQUNDLDRCQU5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUVDckMsVUFDQyx1QkFBQyxRQUNDLFFBQVE7QUFBQSxRQUNOaUMsTUFBTTtBQUFBLFVBQ0pLLE9BQU9qQyxPQUFPa0MsS0FBSyxHQUFHO0FBQUEsVUFDdEJuQyxVQUFVQSxTQUFTb0M7QUFBQUEsVUFDbkJILFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRixHQUNELDZCQVJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQ0E7QUFBQSxJQUVHVCxpQkFBa0JBLGNBQWM5QixNQUFLO0FBQUEsT0E3QzFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQ0EsR0FFRixDQUFDRSxRQUFRQyxTQUFTLENBQ3BCO0FBRUEsUUFBTXdDLGNBQWM5RCxZQUFZLE1BQU07QUFDcEN1QixlQUFXO0FBQUEsTUFDVHdDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVQSxNQUFNcEIsaUJBQWlCO0FBQUEsSUFDbkMsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDQSxnQkFBZ0IsQ0FBQztBQUVyQixRQUFNcUIsU0FBU25FLFFBQVEsTUFDckIsdUJBQUMsU0FBSSxXQUFXMkIsYUFBYXlDLFNBQzNCO0FBQUEsMkJBQUMsaUJBQ0MsTUFBSyxZQUNMLFNBQVMsTUFBTS9DLFVBQVUsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUU2QjtBQUFBLElBRTdCLHVCQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTd0MsYUFDVCxhQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHdUI7QUFBQSxPQVJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUEsR0FDQyxDQUFDZixrQkFBa0JGLFNBQVMsQ0FBQztBQUVoQyxTQUNFLHVCQUFDLGFBQ0MsUUFDQSxXQUNBLE9BQU0sSUFDTiwyQkFDQSxRQUFRdUIsUUFDUixXQUFTLE1BRVQsaUNBQUMsY0FBVyxLQUFLNUMsUUFBUThDLElBQUksV0FBVzNDLGVBQWU0QyxXQUNyRDtBQUFBLDJCQUFDLHNDQUNDLE9BQU0sV0FDTixVQUFTLHVDQUVUO0FBQUEsNkJBQUMsMkNBQ0MsSUFBRyxTQUNILGFBQVksa0JBQ1osU0FBUy9CLFNBQVNILGlDQUNsQixVQUFVSSxpQkFBaUIsaUNBQWlDLEtBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJZ0U7QUFBQSxNQUdoRSx1QkFBQywyQ0FDQyxJQUFHLFNBQ0gsYUFBWSxZQUNaLFNBQVNELFNBQVNGLDJCQUNsQixVQUFVRyxpQkFBaUIsMkJBQTJCLEtBSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJMEQ7QUFBQSxNQUcxRCx1QkFBQywyQ0FDQyxJQUFHLFVBQ0gsYUFBWSxVQUNaLFNBQVNELFNBQVNELHlCQUNsQixVQUFVRSxpQkFBaUIseUJBQXlCLEtBSnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJd0Q7QUFBQSxTQXRCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLElBRUEsdUJBQUMsc0NBQ0MsT0FBTSxTQUNOLFVBQVMsMkJBRVQsaUNBQUMsaUNBQ0MsT0FBTSxXQUNOLG9CQUFvQkQsU0FBU0osMkJBQTJCOUIsYUFBYWtFLEtBQ3JFLFVBQVU5QixpQkFBaUIseUJBQXlCLEtBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHd0QsS0FQMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQSxLQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBO0FBRUo7QUFBQ3RCLEdBN0pLRixzQ0FBbUY7QUFBQSxVQUVoRVIsWUFDZUYsVUFDR3FCLFdBRU14QixTQWdCVUUsYUFFUnVDLDJCQUEyQjtBQUFBO0FBQUEyQixLQXhCeEV2RDtBQStKTixNQUFNVyxZQUFZQSxNQUFNO0FBQUE2QyxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFbEQ7QUFBQUEsRUFBUSxJQUFJaEIsU0FBUztBQUU3QixRQUFNb0IsZUFBZS9CLGVBQWU7QUFBQSxJQUNsQ3dFLFNBQVM7QUFBQSxNQUNQTSxTQUFTO0FBQUEsTUFDVEMsZ0JBQWdCO0FBQUEsTUFDaEJDLFdBQVc7QUFBQSxRQUNULHlCQUF5QjtBQUFBLFVBQ3ZCQyxhQUFhdEQsUUFBUThDO0FBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBUyxTQUFTO0FBQUEsTUFDUHZCLFFBQVE7QUFBQSxNQUNSd0IsVUFBVTtBQUFBLE1BQ1ZDLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTXRELGlCQUFpQjlCLGVBQWU7QUFBQSxJQUNwQzBFLFdBQVc7QUFBQSxNQUNUVyxhQUFhMUQsUUFBUTJCO0FBQUFBLE1BQ3JCZ0MsY0FBYzNELFFBQVEyQjtBQUFBQSxJQUN4QjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU87QUFBQSxJQUNMdkI7QUFBQUEsSUFDQUQ7QUFBQUEsRUFDRjtBQUNGO0FBQUMrQyxJQS9CSzdDLFdBQVM7QUFBQSxVQUNPckIsUUFBUTtBQUFBO0FBZ0M5QixNQUFNc0MsOEJBQThCQSxDQUFDc0MsaUJBQXFDO0FBQUFDLE1BQUE7QUFDeEUsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQWlCLElBQUkzRSxpQkFBaUI7QUFDOUMsUUFBTTtBQUFBLElBQUU0RTtBQUFBQSxFQUFvQixJQUFJbEYsUUFBUTtBQUV4QyxTQUFPSCxZQUFZLE1BQU1PLDJCQUEyQitFLE9BQU9KLFlBQVksR0FDckU7QUFBQSxJQUNFSyxXQUFXQSxNQUFNO0FBQ2ZILHVCQUFpQjtBQUFBLFFBQ2ZJLFNBQVM7QUFBQSxRQUNUQyxNQUFNN0YsZUFBZThGO0FBQUFBLE1BQ3ZCLENBQUM7QUFDREwsMEJBQW9CO0FBQUEsSUFDdEI7QUFBQSxJQUNBTSxTQUFTQSxDQUFDQyxVQUFvQjtBQUM1QkEsWUFBTUMsUUFBUUMsVUFBVUMsUUFBUUMsa0JBQWdCO0FBQzlDWix5QkFBaUI7QUFBQSxVQUNmSSxTQUFTUSxhQUFhUjtBQUFBQSxVQUN0QkMsTUFBTTdGLGVBQWVnRztBQUFBQSxRQUN2QixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsQ0FBQztBQUNMO0FBQUNULElBdEJLdkMsNkJBQTJCO0FBQUEsVUFDRm5DLGtCQUNHTixTQUV6QkgsV0FBVztBQUFBO0FBb0JwQixlQUFlZ0I7QUFBb0MsSUFBQXVEO0FBQUEwQixhQUFBMUIsSUFBQSIsIm5hbWVzIjpbIkljb25CdXR0b24iLCJtZXJnZVN0eWxlU2V0cyIsIk1lc3NhZ2VCYXJUeXBlIiwiVGV4dCIsInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZU11dGF0aW9uIiwiTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzU2VjdGlvbiIsIk5vdGlmaWNhdGlvbnNEZWFkbGluZURyb3Bkb3duIiwidXNlQXV0aCIsIkRlYWRsaW5lRW51bSIsInVzZUZvcm1EYXRhIiwidXNlVGhlbWUiLCJub3RpZmljYXRpb25zQ29uZmlnU2VydmljZSIsInVzZURpYWxvZ3MiLCJ1c2VOb3RpZmljYXRpb25zIiwiRGVmYXVsdEJ1dHRvbiIsIlByaW1hcnlCdXR0b24iLCJBcHBEcmF3ZXIiLCJGbGV4Q29sdW1uIiwiRmxleFJvdyIsIk5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NoZWNrYm94SXRlbSIsIk5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NvbnRhaW5lciIsInByb3BzIiwiX3MiLCJpc09wZW4iLCJvbkRpc21pc3MiLCJvcGVuRGlhbG9nIiwic3BhY2luZyIsImZvbnRTaXplIiwiY29sb3JzIiwic2V0dGluZ3NTdHlsZXMiLCJhY3Rpb25TdHlsZXMiLCJ1c2VTdHlsZXMiLCJjdXJyZW50QWNjb3VudCIsInZhbHVlIiwiY3VycmVudCIsInVzZXJOb3RpZmljYXRpb25Db25maWciLCJjdXJyZW50Q29uZmlnIiwiaWQiLCJwZXJpb2RvUHJhem9Ob3RpZmljYWNhbyIsIm1vZHVsb0FkbWluaXN0cmF0aXZvTm90aWZpY2FjYW8iLCJtb2R1bG9Db250YWJpbE5vdGlmaWNhY2FvIiwibW9kdWxvRmlzY2FsTm90aWZpY2FjYW8iLCJmb3JtRGF0YSIsIm9uQ2hlY2tib3hDaGFuZ2UiLCJvbkRyb3Bkb3duQ2hhbmdlIiwibXV0YXRlQXN5bmMiLCJ1cGRhdGVDb25maWciLCJpc0xvYWRpbmciLCJ1c2VVcGRhdGVOb3RpZmljYXRpb25Db25maWciLCJoYW5kbGVTYXZlQ29uZmlnIiwib25SZW5kZXJOYXZpZ2F0aW9uQ29udGVudCIsImRlZmF1bHRSZW5kZXIiLCJtZCIsInhsIiwiaWNvbk5hbWUiLCJzdHlsZXMiLCJyb290Iiwid2lkdGgiLCJoZWlnaHQiLCJoNCIsImZvbnRXZWlnaHQiLCJjb2xvciIsImdyYXkiLCJwMTYiLCJjb25maXJtU2F2ZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY2NlcHRMYWJlbCIsInN0eWxlIiwib25BY2NlcHQiLCJGb290ZXIiLCJhY3Rpb25zIiwibGciLCJjb250YWluZXIiLCJhbGwiLCJfYyIsIl9zMiIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsInNlbGVjdG9ycyIsIm1hcmdpblJpZ2h0Iiwid3JhcHBlciIsInBvc2l0aW9uIiwibWF4SGVpZ2h0IiwicGFkZGluZ0xlZnQiLCJwYWRkaW5nUmlnaHQiLCJub3RpZmljYXRpb24iLCJfczMiLCJzaG93Tm90aWZpY2F0aW9uIiwiZmV0Y2hDdXJyZW50QWNjb3VudCIsInVwZGF0ZSIsIm9uU3VjY2VzcyIsIm1lc3NhZ2UiLCJ0eXBlIiwic3VjY2VzcyIsIm9uRXJyb3IiLCJlcnJvciIsImVycm9ycyIsIm1lc3NhZ2VzIiwiZm9yRWFjaCIsImVycm9yTWVzc2FnZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NvbnRhaW5lci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9ub3RpZmljYXRpb25zL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEljb25CdXR0b24sIElQYW5lbFByb3BzLCBJUmVuZGVyRnVuY3Rpb24sIG1lcmdlU3R5bGVTZXRzLCBNZXNzYWdlQmFyVHlwZSwgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uLCBOb3RpZmljYXRpb25zRGVhZGxpbmVEcm9wZG93biB9IGZyb20gJy4nXHJcbmltcG9ydCB7IE5vdGlmaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9BcHBOb3RpZmljYXRpb24nXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi8uLi9tb2R1bGVzL2F1dGgvc3RvcmUvYXV0aCdcclxuaW1wb3J0IHsgRGVhZGxpbmVFbnVtIH0gZnJvbSAnLi4vLi4vLi4vZW51bXMvRGVhZGxpbmVFbnVtJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uL2Vycm9ycydcclxuaW1wb3J0IHsgdXNlRm9ybURhdGEsIHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MnXHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbnNDb25maWdTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvbm90aWZpY2F0aW9uc1NlcnZpY2VzJ1xyXG5pbXBvcnQgeyB1c2VEaWFsb2dzIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvZGlhbG9ncy9kaWFsb2dzJ1xyXG5pbXBvcnQgeyB1c2VOb3RpZmljYXRpb25zIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xyXG5pbXBvcnQgeyBEZWZhdWx0QnV0dG9uLCBQcmltYXJ5QnV0dG9uIH0gZnJvbSAnLi4vLi4vYnV0dG9ucydcclxuaW1wb3J0IHsgQXBwRHJhd2VyIH0gZnJvbSAnLi4vLi4vZHJhd2VyJ1xyXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBGbGV4Um93IH0gZnJvbSAnLi4vLi4vRmxleEJveCdcclxuaW1wb3J0IE5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NoZWNrYm94SXRlbSBmcm9tICcuL05vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NoZWNrYm94SXRlbSdcclxuXHJcbmludGVyZmFjZSBOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDb250YWluZXJQcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuXHJcbiAgb25EaXNtaXNzOiAoKSA9PiB2b2lkXHJcbn1cclxuXHJcbmNvbnN0IE5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NvbnRhaW5lcjogRkM8Tm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBpc09wZW4sIG9uRGlzbWlzcyB9ID0gcHJvcHNcclxuICBjb25zdCB7IG9wZW5EaWFsb2cgfSA9IHVzZURpYWxvZ3MoKVxyXG4gIGNvbnN0IHsgc3BhY2luZywgZm9udFNpemUsIGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IHsgc2V0dGluZ3NTdHlsZXMsIGFjdGlvblN0eWxlcyB9ID0gdXNlU3R5bGVzKClcclxuXHJcbiAgY29uc3QgeyBjdXJyZW50QWNjb3VudDogeyB2YWx1ZTogY3VycmVudCB9IH0gPSB1c2VBdXRoKClcclxuXHJcbiAgY29uc3QgdXNlck5vdGlmaWNhdGlvbkNvbmZpZyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnQpIHtcclxuICAgICAgY29uc3QgY3VycmVudENvbmZpZzogTm90aWZpY2F0aW9uQ29uZmlnID0ge1xyXG4gICAgICAgIGlkOiBjdXJyZW50LmlkLFxyXG4gICAgICAgIHBlcmlvZG9QcmF6b05vdGlmaWNhY2FvOiBjdXJyZW50LnBlcmlvZG9QcmF6b05vdGlmaWNhY2FvLFxyXG4gICAgICAgIG1vZHVsb0FkbWluaXN0cmF0aXZvTm90aWZpY2FjYW86IGN1cnJlbnQubW9kdWxvQWRtaW5pc3RyYXRpdm9Ob3RpZmljYWNhbyxcclxuICAgICAgICBtb2R1bG9Db250YWJpbE5vdGlmaWNhY2FvOiBjdXJyZW50Lm1vZHVsb0NvbnRhYmlsTm90aWZpY2FjYW8sXHJcbiAgICAgICAgbW9kdWxvRmlzY2FsTm90aWZpY2FjYW86IGN1cnJlbnQubW9kdWxvRmlzY2FsTm90aWZpY2FjYW8sXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBjdXJyZW50Q29uZmlnXHJcbiAgICB9XHJcbiAgfSwgW2N1cnJlbnRdKVxyXG5cclxuICBjb25zdCB7IGZvcm1EYXRhLCBvbkNoZWNrYm94Q2hhbmdlLCBvbkRyb3Bkb3duQ2hhbmdlIH0gPSB1c2VGb3JtRGF0YTxOb3RpZmljYXRpb25Db25maWc+KHVzZXJOb3RpZmljYXRpb25Db25maWcgYXMgTm90aWZpY2F0aW9uQ29uZmlnKVxyXG5cclxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiB1cGRhdGVDb25maWcsIGlzTG9hZGluZyB9ID0gdXNlVXBkYXRlTm90aWZpY2F0aW9uQ29uZmlnKGZvcm1EYXRhKVxyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlQ29uZmlnID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgdXBkYXRlQ29uZmlnKClcclxuICB9LCBbZm9ybURhdGFdKVxyXG5cclxuICBjb25zdCBvblJlbmRlck5hdmlnYXRpb25Db250ZW50OiBJUmVuZGVyRnVuY3Rpb248SVBhbmVsUHJvcHM+ID0gdXNlQ2FsbGJhY2soXHJcbiAgICAocHJvcHMsIGRlZmF1bHRSZW5kZXIpID0+IChcclxuICAgICAgPD5cclxuICAgICAgICA8RmxleENvbHVtbiB3aWR0aD1cIjEwMCVcIiBnYXA9e3NwYWNpbmcubWR9IHBhZGRpbmc9e3NwYWNpbmcueGx9PlxyXG4gICAgICAgICAgPEZsZXhSb3cgZ2FwPXsxMH0gdmVydGljYWxBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICB7aXNPcGVuICYmIChcclxuICAgICAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25EaXNtaXNzfVxyXG4gICAgICAgICAgICAgICAgaWNvblByb3BzPXt7XHJcbiAgICAgICAgICAgICAgICAgIGljb25OYW1lOiAnQXJyb3ctbGVmdCcsXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlczoge1xyXG4gICAgICAgICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxNixcclxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTYsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBhcmlhTGFiZWw9XCJWb2x0YXJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8VGV4dCBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udFNpemUuaDQsXHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA2MDAsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIE5vdGlmaWNhw6fDtWVzXHJcbiAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgIDwvRmxleFJvdz5cclxuXHJcbiAgICAgICAgICB7aXNPcGVuICYmIChcclxuICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzQwMF0sXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTYsXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICdyZWd1bGFyJyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENvbmZpZ3VyYcOnw7Vlc1xyXG4gICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvRmxleENvbHVtbj5cclxuICAgICAgICB7XHJcbiAgICAgICAgICAoZGVmYXVsdFJlbmRlcikgJiYgZGVmYXVsdFJlbmRlcihwcm9wcylcclxuICAgICAgICB9XHJcbiAgICAgIDwvPlxyXG4gICAgKSxcclxuICAgIFtpc09wZW4sIG9uRGlzbWlzc10sXHJcbiAgKVxyXG5cclxuICBjb25zdCBjb25maXJtU2F2ZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIG9wZW5EaWFsb2coe1xyXG4gICAgICB0aXRsZTogJ1NhbHZhciBjb25maWd1cmHDp8O1ZXMnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ0Nhc28gYWx0ZXJhZG8gbyBwZXLDrW9kbywgYXMgbm90aWZpY2HDp8O1ZXMgY29tIGRhdGEgYW50ZXJpb3IgYW8gbm92byB2YWxvciBlc2NvbGhpZG8gdsOjbyBzZXIgZXhjbHXDrWRhcy4gRGVzZWphIHNhbHZhciBtZXNtbyBhc3NpbT8nLFxyXG4gICAgICBhY2NlcHRMYWJlbDogJ1NhbHZhcicsXHJcbiAgICAgIHN0eWxlOiAnZGVmYXVsdCcsXHJcbiAgICAgIG9uQWNjZXB0OiAoKSA9PiBoYW5kbGVTYXZlQ29uZmlnKCksXHJcbiAgICB9KVxyXG4gIH0sIFtoYW5kbGVTYXZlQ29uZmlnXSlcclxuXHJcbiAgY29uc3QgRm9vdGVyID0gdXNlTWVtbygoKSA9PiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17YWN0aW9uU3R5bGVzLmFjdGlvbnN9PlxyXG4gICAgICA8RGVmYXVsdEJ1dHRvblxyXG4gICAgICAgIHRleHQ9XCJDYW5jZWxhclwiXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gb25EaXNtaXNzKCl9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxQcmltYXJ5QnV0dG9uXHJcbiAgICAgICAgdGV4dD1cIlNhbHZhclwiXHJcbiAgICAgICAgb25DbGljaz17Y29uZmlybVNhdmV9XHJcbiAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApLCBbaGFuZGxlU2F2ZUNvbmZpZywgaXNMb2FkaW5nXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBcHBEcmF3ZXJcclxuICAgICAgaXNPcGVuPXtpc09wZW59XHJcbiAgICAgIG9uRGlzbWlzcz17b25EaXNtaXNzfVxyXG4gICAgICB0aXRsZT0nJ1xyXG4gICAgICBvblJlbmRlck5hdmlnYXRpb25Db250ZW50PXtvblJlbmRlck5hdmlnYXRpb25Db250ZW50fVxyXG4gICAgICBmb290ZXI9e0Zvb3Rlcn1cclxuICAgICAgbm9QYWRkaW5nXHJcbiAgICA+XHJcbiAgICAgIDxGbGV4Q29sdW1uIGdhcD17c3BhY2luZy5sZ30gY2xhc3NOYW1lPXtzZXR0aW5nc1N0eWxlcy5jb250YWluZXJ9PlxyXG4gICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uXHJcbiAgICAgICAgICB0aXRsZT1cIk3Ds2R1bG9zXCJcclxuICAgICAgICAgIHN1YnRpdGxlPVwiVmVyIG5vdGlmaWNhw6fDtWVzIGRvcyBtw7NkdWxvcyBhYmFpeG9cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW1cclxuICAgICAgICAgICAgaWQ9J2FkbWluJ1xyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj0nQWRtaW5pc3RyYXRpdm8nXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLm1vZHVsb0FkbWluaXN0cmF0aXZvTm90aWZpY2FjYW99XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdtb2R1bG9BZG1pbmlzdHJhdGl2b05vdGlmaWNhY2FvJyl9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW1cclxuICAgICAgICAgICAgaWQ9J2F1ZGl0J1xyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj0nUHJvamV0b3MnXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLm1vZHVsb0NvbnRhYmlsTm90aWZpY2FjYW99XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdtb2R1bG9Db250YWJpbE5vdGlmaWNhY2FvJyl9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW1cclxuICAgICAgICAgICAgaWQ9J2Zpc2NhbCdcclxuICAgICAgICAgICAgZGVzY3JpcHRpb249J0Zpc2NhbCdcclxuICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEubW9kdWxvRmlzY2FsTm90aWZpY2FjYW99XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdtb2R1bG9GaXNjYWxOb3RpZmljYWNhbycpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L05vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc1NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NTZWN0aW9uXHJcbiAgICAgICAgICB0aXRsZT1cIlByYXpvXCJcclxuICAgICAgICAgIHN1YnRpdGxlPVwiVmVyIG5vdGlmaWNhw6fDtWVzIGRlIGF0w6lcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxOb3RpZmljYXRpb25zRGVhZGxpbmVEcm9wZG93blxyXG4gICAgICAgICAgICBsYWJlbD0nUGVyw61vZG8nXHJcbiAgICAgICAgICAgIGRlZmF1bHRTZWxlY3RlZEtleT17Zm9ybURhdGEucGVyaW9kb1ByYXpvTm90aWZpY2FjYW8gfHwgRGVhZGxpbmVFbnVtLmFsbH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9e29uRHJvcGRvd25DaGFuZ2UoJ3BlcmlvZG9QcmF6b05vdGlmaWNhY2FvJyl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzU2VjdGlvbj5cclxuICAgICAgPC9GbGV4Q29sdW1uPlxyXG4gICAgPC9BcHBEcmF3ZXI+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBzcGFjaW5nIH0gPSB1c2VUaGVtZSgpXHJcblxyXG4gIGNvbnN0IGFjdGlvblN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGFjdGlvbnM6IHtcclxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyxcclxuICAgICAgc2VsZWN0b3JzOiB7XHJcbiAgICAgICAgJyYgPiA6bm90KDpsYXN0LWNoaWxkKSc6IHtcclxuICAgICAgICAgIG1hcmdpblJpZ2h0OiBzcGFjaW5nLmxnLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgd3JhcHBlcjoge1xyXG4gICAgICBoZWlnaHQ6ICc2NXZoJyxcclxuICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgIG1heEhlaWdodDogJ2luaGVyaXQnLFxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICBjb25zdCBzZXR0aW5nc1N0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGNvbnRhaW5lcjoge1xyXG4gICAgICBwYWRkaW5nTGVmdDogc3BhY2luZy54bCxcclxuICAgICAgcGFkZGluZ1JpZ2h0OiBzcGFjaW5nLnhsLFxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgYWN0aW9uU3R5bGVzLFxyXG4gICAgc2V0dGluZ3NTdHlsZXMsXHJcbiAgfVxyXG59XHJcblxyXG5jb25zdCB1c2VVcGRhdGVOb3RpZmljYXRpb25Db25maWcgPSAobm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb25Db25maWcpID0+IHtcclxuICBjb25zdCB7IHNob3dOb3RpZmljYXRpb24gfSA9IHVzZU5vdGlmaWNhdGlvbnMoKVxyXG4gIGNvbnN0IHsgZmV0Y2hDdXJyZW50QWNjb3VudCB9ID0gdXNlQXV0aCgpXHJcblxyXG4gIHJldHVybiB1c2VNdXRhdGlvbigoKSA9PiBub3RpZmljYXRpb25zQ29uZmlnU2VydmljZS51cGRhdGUobm90aWZpY2F0aW9uKSxcclxuICAgIHtcclxuICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiAnQ29uZmlndXJhw6fDo28gZGFzIG5vdGlmaWNhw6fDtWVzIGF0dWFsaXphZGFzIScsXHJcbiAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5zdWNjZXNzLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgZmV0Y2hDdXJyZW50QWNjb3VudCgpXHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3I6IChlcnJvcjogQXBpRXJyb3IpID0+IHtcclxuICAgICAgICBlcnJvci5lcnJvcnM/Lm1lc3NhZ2VzPy5mb3JFYWNoKGVycm9yTWVzc2FnZSA9PiB7XHJcbiAgICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICB9KVxyXG4gICAgICB9LFxyXG4gICAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ29udGFpbmVyXHJcbiJdfQ==