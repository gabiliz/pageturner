import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/roles/components/RoleName.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleName.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { roleQueryService } from "/src/modules/admin/roles/services/index.ts";
const RoleName = (props) => {
  _s();
  const {
    id,
    role
  } = props;
  const {
    data
  } = id ? roleQueryService.useFindOne(id) : {
    data: role
  };
  return /* @__PURE__ */ jsxDEV("span", { children: data?.nome ?? "" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleName.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
};
_s(RoleName, "Wchty7I1nzdWzecweP69zIFd1hU=", false, function() {
  return [roleQueryService.useFindOne];
});
_c = RoleName;
export default RoleName;
var _c;
$RefreshReg$(_c, "RoleName");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/roles/components/RoleName.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYVCxTQUFTQSx3QkFBd0I7QUFPakMsTUFBTUMsV0FBK0JDLFdBQVU7QUFBQUMsS0FBQTtBQUM3QyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBSUM7QUFBQUEsRUFBSyxJQUFJSDtBQUNyQixRQUFNO0FBQUEsSUFBRUk7QUFBQUEsRUFBSyxJQUFJRixLQUFLSixpQkFBaUJPLFdBQVdILEVBQUUsSUFBSTtBQUFBLElBQUVFLE1BQU1EO0FBQUFBLEVBQUs7QUFFckUsU0FBTyx1QkFBQyxVQUFNQyxnQkFBTUUsUUFBUSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdCO0FBQ2pDO0FBQUNMLEdBTEtGLFVBQTJCO0FBQUEsVUFFVEQsaUJBQWlCTyxVQUFVO0FBQUE7QUFBQUUsS0FGN0NSO0FBT04sZUFBZUE7QUFBUSxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsicm9sZVF1ZXJ5U2VydmljZSIsIlJvbGVOYW1lIiwicHJvcHMiLCJfcyIsImlkIiwicm9sZSIsImRhdGEiLCJ1c2VGaW5kT25lIiwibm9tZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUm9sZU5hbWUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9yb2xlcy9jb21wb25lbnRzL1JvbGVOYW1lLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUm9sZSBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vUm9sZSdcbmltcG9ydCB7IHJvbGVRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcblxuaW50ZXJmYWNlIFJvbGVOYW1lUHJvcHMge1xuICBpZD86IHN0cmluZ1xuICByb2xlPzogUm9sZVxufVxuXG5jb25zdCBSb2xlTmFtZTogRkM8Um9sZU5hbWVQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBpZCwgcm9sZSB9ID0gcHJvcHNcbiAgY29uc3QgeyBkYXRhIH0gPSBpZCA/IHJvbGVRdWVyeVNlcnZpY2UudXNlRmluZE9uZShpZCkgOiB7IGRhdGE6IHJvbGUgfVxuXG4gIHJldHVybiA8c3Bhbj57ZGF0YT8ubm9tZSA/PyAnJ308L3NwYW4+XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJvbGVOYW1lXG4iXX0=