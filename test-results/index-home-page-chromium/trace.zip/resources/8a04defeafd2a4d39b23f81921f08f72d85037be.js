import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/resource/ResourceEditDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceEditDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { EditDrawer, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { useHandleRejection } from "/src/shared/hooks/index.ts";
function ResourceEditDrawer(props) {
  _s();
  const {
    title,
    service: service2,
    isOpen,
    onDismiss,
    id,
    serviceParams = [],
    onAfterSave
  } = props;
  const [formData, setFormData] = useState(null);
  const {
    isLoading,
    data,
    isSuccess
  } = service2.useFindOne(id, ...serviceParams);
  const {
    mutateAsync: update,
    isLoading: isUpdating
  } = service2.useUpdate(...serviceParams);
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  const createCommand = useCallback(() => {
    if (data) {
      setFormData(service2.resourceService.queryToCommand(data));
    }
  }, [data]);
  useEffect(() => {
    createCommand();
  }, [createCommand]);
  const save = useCallback(async () => {
    if (formData) {
      await update(formData);
    }
    onAfterSave?.();
    dismiss();
  }, [formData]);
  const dismiss = useCallback(() => {
    onDismiss();
    setError(void 0);
  }, [onDismiss, data]);
  return /* @__PURE__ */ jsxDEV(EditDrawer, { title, isOpen, onDismiss: dismiss, onSave: save, disabled: isUpdating, loading: isUpdating, children: [
    isLoading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceEditDrawer.tsx",
      lineNumber: 71,
      columnNumber: 21
    }, this),
    isSuccess && /* @__PURE__ */ jsxDEV(props.editForm, { formData, onChange: setFormData, apiError: error?.reason ? error?.reason : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceEditDrawer.tsx",
      lineNumber: 72,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceEditDrawer.tsx",
    lineNumber: 70,
    columnNumber: 10
  }, this);
}
_s(ResourceEditDrawer, "7ybW7DEUhmX9fThEg7nxCRlY4TM=", false, function() {
  return [service.useFindOne, service.useUpdate, useHandleRejection];
});
_c = ResourceEditDrawer;
export default ResourceEditDrawer;
var _c;
$RefreshReg$(_c, "ResourceEditDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceEditDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZvQjs7Ozs7Ozs7Ozs7Ozs7OztBQWxGcEIsU0FBU0EsVUFBVUMsYUFBYUMsaUJBQStCO0FBQy9ELFNBQVNDLFlBQVlDLHFCQUFxQjtBQUkxQyxTQUFTQywwQkFBMEI7QUFjbkMsU0FBU0MsbUJBQ1BDLE9BQ2M7QUFBQUMsS0FBQTtBQUNkLFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxnQkFBZ0I7QUFBQSxJQUNoQkM7QUFBQUEsRUFDRixJQUFJUjtBQUVKLFFBQU0sQ0FBQ1MsVUFBVUMsV0FBVyxJQUFJakIsU0FBaUIsSUFBSTtBQUVyRCxRQUFNO0FBQUEsSUFBRWtCO0FBQUFBLElBQVdDO0FBQUFBLElBQU1DO0FBQUFBLEVBQVUsSUFBSVYsU0FBUVcsV0FBV1IsSUFBSSxHQUFHQyxhQUFhO0FBRTlFLFFBQU07QUFBQSxJQUFFUSxhQUFhQztBQUFBQSxJQUFRTCxXQUFXTTtBQUFBQSxFQUFXLElBQUlkLFNBQVFlLFVBQVUsR0FBR1gsYUFBYTtBQUN6RixRQUFNLENBQUNZLE9BQU9DLFFBQVEsSUFBSTNCLFNBQWdDO0FBQzFELFFBQU07QUFBQSxJQUNKNEI7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJeEIsbUJBQW1CO0FBRXZCSCxZQUFVLE1BQU07QUFDZDBCLHFCQUFpQkQsUUFBUTtBQUN6QixXQUFPLE1BQU07QUFDWEUseUJBQW1CRixRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUcsZ0JBQWdCN0IsWUFBWSxNQUFNO0FBQ3RDLFFBQUlrQixNQUFNO0FBQ1JGLGtCQUFZUCxTQUFRcUIsZ0JBQWdCQyxlQUFlYixJQUFJLENBQUM7QUFBQSxJQUMxRDtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxJQUFJLENBQUM7QUFFVGpCLFlBQVUsTUFBTTtBQUNkNEIsa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUNBLGFBQWEsQ0FBQztBQUVsQixRQUFNRyxPQUFPaEMsWUFBWSxZQUFZO0FBQ25DLFFBQUllLFVBQVU7QUFDWixZQUFNTyxPQUFPUCxRQUFRO0FBQUEsSUFDdkI7QUFDQUQsa0JBQWM7QUFDZG1CLFlBQVE7QUFBQSxFQUNWLEdBQUcsQ0FBQ2xCLFFBQVEsQ0FBQztBQUViLFFBQU1rQixVQUFVakMsWUFBWSxNQUFNO0FBQ2hDVyxjQUFVO0FBQ1ZlLGFBQVNRLE1BQVM7QUFBQSxFQUNwQixHQUFHLENBQUN2QixXQUFXTyxJQUFJLENBQUM7QUFFcEIsU0FDRSx1QkFBQyxjQUNDLE9BQ0EsUUFDQSxXQUFXZSxTQUNYLFFBQVFELE1BQ1IsVUFBVVQsWUFDVixTQUFTQSxZQUVSTjtBQUFBQSxpQkFBYSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUMzQkUsYUFBYSx1QkFBQyxNQUFNLFVBQU4sRUFDYixVQUNBLFVBQVVILGFBQ1YsVUFBVVMsT0FBT1UsU0FDYlYsT0FBT1UsU0FDUEQsVUFMUTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTVg7QUFBQSxPQWZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDM0IsR0EzRVFGLG9CQUFrQjtBQUFBLFVBZWNJLFFBQVFXLFlBRVFYLFFBQVFlLFdBSzNEcEIsa0JBQWtCO0FBQUE7QUFBQWdDLEtBdEJmL0I7QUE2RVQsZUFBZUE7QUFBa0IsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwiRWRpdERyYXdlciIsIkxvYWRpbmdTY3JlZW4iLCJ1c2VIYW5kbGVSZWplY3Rpb24iLCJSZXNvdXJjZUVkaXREcmF3ZXIiLCJwcm9wcyIsIl9zIiwidGl0bGUiLCJzZXJ2aWNlIiwiaXNPcGVuIiwib25EaXNtaXNzIiwiaWQiLCJzZXJ2aWNlUGFyYW1zIiwib25BZnRlclNhdmUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiaXNMb2FkaW5nIiwiZGF0YSIsImlzU3VjY2VzcyIsInVzZUZpbmRPbmUiLCJtdXRhdGVBc3luYyIsInVwZGF0ZSIsImlzVXBkYXRpbmciLCJ1c2VVcGRhdGUiLCJlcnJvciIsInNldEVycm9yIiwicmVnaXN0ZXJMaXN0ZW5lciIsInVucmVnaXN0ZXJMaXN0ZW5lciIsImNyZWF0ZUNvbW1hbmQiLCJyZXNvdXJjZVNlcnZpY2UiLCJxdWVyeVRvQ29tbWFuZCIsInNhdmUiLCJkaXNtaXNzIiwidW5kZWZpbmVkIiwicmVhc29uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZXNvdXJjZUVkaXREcmF3ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvcmVzb3VyY2UvUmVzb3VyY2VFZGl0RHJhd2VyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCBSZWFjdEVsZW1lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEVkaXREcmF3ZXIsIExvYWRpbmdTY3JlZW4gfSBmcm9tICcuLidcbmltcG9ydCBFbnRpdHkgZnJvbSAnLi4vLi4vLi4vZG9tYWluL0VudGl0eSdcbmltcG9ydCB7IFJlc291cmNlUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vYXBpL1Jlc291cmNlUXVlcnlTZXJ2aWNlJ1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi9lcnJvcnMnXG5pbXBvcnQgeyB1c2VIYW5kbGVSZWplY3Rpb24gfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEVkaXRGb3JtIH0gZnJvbSAnLi4vLi4vdHlwZXMvRWRpdEZvcm0nXG5cbmludGVyZmFjZSBSZXNvdXJjZUVkaXREcmF3ZXJQcm9wczxRIGV4dGVuZHMgRW50aXR5LCBDIGV4dGVuZHMgRW50aXR5PiB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgc2VydmljZTogUmVzb3VyY2VRdWVyeVNlcnZpY2U8USwgQz5cbiAgZWRpdEZvcm06IEVkaXRGb3JtPEM+XG4gIGlzT3BlbjogYm9vbGVhblxuICBvbkRpc21pc3M6ICgpID0+IHZvaWRcbiAgb25BZnRlclNhdmU/OiAoKSA9PiB2b2lkXG4gIGlkOiBzdHJpbmdcbiAgc2VydmljZVBhcmFtcz86IHN0cmluZ1tdXG59XG5cbmZ1bmN0aW9uIFJlc291cmNlRWRpdERyYXdlcjxRIGV4dGVuZHMgRW50aXR5LCBDIGV4dGVuZHMgRW50aXR5PiAoXG4gIHByb3BzOiBSZXNvdXJjZUVkaXREcmF3ZXJQcm9wczxRLCBDPixcbik6IFJlYWN0RWxlbWVudCB7XG4gIGNvbnN0IHtcbiAgICB0aXRsZSxcbiAgICBzZXJ2aWNlLFxuICAgIGlzT3BlbixcbiAgICBvbkRpc21pc3MsXG4gICAgaWQsXG4gICAgc2VydmljZVBhcmFtcyA9IFtdLFxuICAgIG9uQWZ0ZXJTYXZlLFxuICB9ID0gcHJvcHNcblxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPEN8bnVsbD4obnVsbClcblxuICBjb25zdCB7IGlzTG9hZGluZywgZGF0YSwgaXNTdWNjZXNzIH0gPSBzZXJ2aWNlLnVzZUZpbmRPbmUoaWQsIC4uLnNlcnZpY2VQYXJhbXMpXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogdXBkYXRlLCBpc0xvYWRpbmc6IGlzVXBkYXRpbmcgfSA9IHNlcnZpY2UudXNlVXBkYXRlKC4uLnNlcnZpY2VQYXJhbXMpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8UHJvbWlzZVJlamVjdGlvbkV2ZW50PigpXG4gIGNvbnN0IHtcbiAgICByZWdpc3Rlckxpc3RlbmVyLFxuICAgIHVucmVnaXN0ZXJMaXN0ZW5lcixcbiAgfSA9IHVzZUhhbmRsZVJlamVjdGlvbigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZWdpc3Rlckxpc3RlbmVyKHNldEVycm9yKVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB1bnJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXG4gICAgfVxuICB9LCBbc2V0RXJyb3JdKVxuXG4gIGNvbnN0IGNyZWF0ZUNvbW1hbmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKGRhdGEpIHtcbiAgICAgIHNldEZvcm1EYXRhKHNlcnZpY2UucmVzb3VyY2VTZXJ2aWNlLnF1ZXJ5VG9Db21tYW5kKGRhdGEpKVxuICAgIH1cbiAgfSwgW2RhdGFdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY3JlYXRlQ29tbWFuZCgpXG4gIH0sIFtjcmVhdGVDb21tYW5kXSlcblxuICBjb25zdCBzYXZlID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGlmIChmb3JtRGF0YSkge1xuICAgICAgYXdhaXQgdXBkYXRlKGZvcm1EYXRhKVxuICAgIH1cbiAgICBvbkFmdGVyU2F2ZT8uKClcbiAgICBkaXNtaXNzKClcbiAgfSwgW2Zvcm1EYXRhXSlcblxuICBjb25zdCBkaXNtaXNzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIG9uRGlzbWlzcygpXG4gICAgc2V0RXJyb3IodW5kZWZpbmVkKVxuICB9LCBbb25EaXNtaXNzLCBkYXRhXSlcblxuICByZXR1cm4gKFxuICAgIDxFZGl0RHJhd2VyXG4gICAgICB0aXRsZT17dGl0bGV9XG4gICAgICBpc09wZW49e2lzT3Blbn1cbiAgICAgIG9uRGlzbWlzcz17ZGlzbWlzc31cbiAgICAgIG9uU2F2ZT17c2F2ZX1cbiAgICAgIGRpc2FibGVkPXtpc1VwZGF0aW5nfVxuICAgICAgbG9hZGluZz17aXNVcGRhdGluZ31cbiAgICA+XG4gICAgICB7aXNMb2FkaW5nICYmIDxMb2FkaW5nU2NyZWVuIC8+fVxuICAgICAge2lzU3VjY2VzcyAmJiA8cHJvcHMuZWRpdEZvcm1cbiAgICAgICAgZm9ybURhdGE9e2Zvcm1EYXRhfVxuICAgICAgICBvbkNoYW5nZT17c2V0Rm9ybURhdGF9XG4gICAgICAgIGFwaUVycm9yPXtlcnJvcj8ucmVhc29uXG4gICAgICAgICAgPyBlcnJvcj8ucmVhc29uIGFzIEFwaUVycm9yXG4gICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIH1cbiAgICA8L0VkaXREcmF3ZXI+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVzb3VyY2VFZGl0RHJhd2VyXG4iXX0=