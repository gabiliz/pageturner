import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientActions.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useState = __vite__cjsImport3_react["useState"];
import { clientService } from "/src/modules/admin/clients/services/index.ts";
import { downloadFile } from "/src/shared/utils/index.ts";
import { PrimaryButton, CommandButton } from "/src/shared/components/index.ts?t=1701096626433";
import { ExportClientEnum } from "/src/shared/enums/ExportClientEnum.ts";
import ExportClientRecord from "/src/shared/record/ExportClientRecord.ts";
const ClientActions = (props) => {
  _s();
  const {
    disabledRemoveButton,
    onAdd,
    onRemove,
    disabledAddButton,
    deletePermission,
    createPermission,
    visualizePermission
  } = props;
  const [exportFile, setExportFile] = useState(false);
  const download = useCallback((item) => {
    clientService.download(item).then((response) => {
      downloadFile(response);
    }).finally(() => {
      setExportFile(false);
    });
  }, [exportFile]);
  const menuProps = {
    shouldFocusOnMount: true,
    shouldFocusOnContainer: true,
    items: [{
      key: ExportClientEnum.ClientesEmpresas.toString(),
      text: ExportClientRecord[ExportClientEnum.ClientesEmpresas],
      onClick: (_, item) => download(parseInt(item?.key))
    }, {
      key: ExportClientEnum.ClientesContratos.toString(),
      text: ExportClientRecord[ExportClientEnum.ClientesContratos],
      onClick: (_, item) => download(parseInt(item?.key))
    }]
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    createPermission && /* @__PURE__ */ jsxDEV(PrimaryButton, { iconProps: {
      iconName: "Add",
      style: {
        fontSize: 14
      }
    }, text: "Adicionar", onClick: onAdd, disabled: disabledAddButton }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx",
      lineNumber: 51,
      columnNumber: 28
    }, this),
    visualizePermission && /* @__PURE__ */ jsxDEV(CommandButton, { iconProps: {
      iconName: "Download"
    }, text: "Exportar", menuProps }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx",
      lineNumber: 57,
      columnNumber: 31
    }, this),
    deletePermission && /* @__PURE__ */ jsxDEV(CommandButton, { iconProps: {
      iconName: "Trash",
      style: {
        fontSize: 14
      }
    }, text: "Excluir", disabled: disabledRemoveButton, onClick: onRemove }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx",
      lineNumber: 60,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
};
_s(ClientActions, "C8XDwC4gXeXpdOHVDYOYQmyy2gk=");
_c = ClientActions;
export default ClientActions;
var _c;
$RefreshReg$(_c, "ClientActions");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RJLG1CQUN1QixjQUR2Qjs7Ozs7Ozs7Ozs7Ozs7OztBQWxESixTQUFhQSxhQUFhQyxnQkFBZ0I7QUFFMUMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxlQUFlQyxxQkFBcUI7QUFDN0MsU0FBU0Msd0JBQXdCO0FBQ2pDLE9BQU9DLHdCQUF3QjtBQVkvQixNQUFNQyxnQkFBeUNDLFdBQVU7QUFBQUMsS0FBQTtBQUN2RCxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJUjtBQUVKLFFBQU0sQ0FBQ1MsWUFBWUMsYUFBYSxJQUFJbEIsU0FBa0IsS0FBSztBQUUzRCxRQUFNbUIsV0FBV3BCLFlBQVksQ0FBQ3FCLFNBQWlCO0FBQzdDbkIsa0JBQWNrQixTQUFTQyxJQUFjLEVBQ2xDQyxLQUFNQyxjQUFhO0FBQ2xCcEIsbUJBQWFvQixRQUFRO0FBQUEsSUFDdkIsQ0FBQyxFQUFFQyxRQUFRLE1BQU07QUFDZkwsb0JBQWMsS0FBSztBQUFBLElBQ3JCLENBQUM7QUFBQSxFQUNMLEdBQUcsQ0FBQ0QsVUFBVSxDQUFDO0FBRWYsUUFBTU8sWUFBa0M7QUFBQSxJQUN0Q0Msb0JBQW9CO0FBQUEsSUFDcEJDLHdCQUF3QjtBQUFBLElBQ3hCQyxPQUFPLENBQ0w7QUFBQSxNQUFFQyxLQUFLdkIsaUJBQWlCd0IsaUJBQWlCQyxTQUFTO0FBQUEsTUFBR0MsTUFBTXpCLG1CQUFtQkQsaUJBQWlCd0IsZ0JBQWdCO0FBQUEsTUFBR0csU0FBU0EsQ0FBQ0MsR0FBR2IsU0FBU0QsU0FBU2UsU0FBU2QsTUFBTVEsR0FBYSxDQUFDO0FBQUEsSUFBRSxHQUNoTDtBQUFBLE1BQUVBLEtBQUt2QixpQkFBaUI4QixrQkFBa0JMLFNBQVM7QUFBQSxNQUFHQyxNQUFNekIsbUJBQW1CRCxpQkFBaUI4QixpQkFBaUI7QUFBQSxNQUFHSCxTQUFTQSxDQUFDQyxHQUFHYixTQUFTRCxTQUFTZSxTQUFTZCxNQUFNUSxHQUFhLENBQUM7QUFBQSxJQUFFLENBQUM7QUFBQSxFQUV2TDtBQUVBLFNBQ0UsbUNBQ0diO0FBQUFBLHdCQUFvQix1QkFBQyxpQkFDcEIsV0FBVztBQUFBLE1BQUVxQixVQUFVO0FBQUEsTUFBT0MsT0FBTztBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFHO0FBQUEsSUFBRSxHQUN0RCxNQUFLLGFBQ0wsU0FBUzNCLE9BQ1QsVUFBVUUscUJBSlM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlTO0FBQUEsSUFFN0JHLHVCQUNELHVCQUFDLGlCQUNDLFdBQVc7QUFBQSxNQUFFb0IsVUFBVTtBQUFBLElBQVcsR0FDbEMsTUFBSyxZQUNMLGFBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUd1QjtBQUFBLElBRXRCdEIsb0JBQW9CLHVCQUFDLGlCQUNwQixXQUFXO0FBQUEsTUFBRXNCLFVBQVU7QUFBQSxNQUFTQyxPQUFPO0FBQUEsUUFBRUMsVUFBVTtBQUFBLE1BQUc7QUFBQSxJQUFFLEdBQ3hELE1BQUssV0FDTCxVQUFVNUIsc0JBQ1YsU0FBU0UsWUFKVTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUQ7QUFBQSxPQWpCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNILEdBckRLRixlQUFxQztBQUFBZ0MsS0FBckNoQztBQXVETixlQUFlQTtBQUFhLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VTdGF0ZSIsImNsaWVudFNlcnZpY2UiLCJkb3dubG9hZEZpbGUiLCJQcmltYXJ5QnV0dG9uIiwiQ29tbWFuZEJ1dHRvbiIsIkV4cG9ydENsaWVudEVudW0iLCJFeHBvcnRDbGllbnRSZWNvcmQiLCJDbGllbnRBY3Rpb25zIiwicHJvcHMiLCJfcyIsImRpc2FibGVkUmVtb3ZlQnV0dG9uIiwib25BZGQiLCJvblJlbW92ZSIsImRpc2FibGVkQWRkQnV0dG9uIiwiZGVsZXRlUGVybWlzc2lvbiIsImNyZWF0ZVBlcm1pc3Npb24iLCJ2aXN1YWxpemVQZXJtaXNzaW9uIiwiZXhwb3J0RmlsZSIsInNldEV4cG9ydEZpbGUiLCJkb3dubG9hZCIsIml0ZW0iLCJ0aGVuIiwicmVzcG9uc2UiLCJmaW5hbGx5IiwibWVudVByb3BzIiwic2hvdWxkRm9jdXNPbk1vdW50Iiwic2hvdWxkRm9jdXNPbkNvbnRhaW5lciIsIml0ZW1zIiwia2V5IiwiQ2xpZW50ZXNFbXByZXNhcyIsInRvU3RyaW5nIiwidGV4dCIsIm9uQ2xpY2siLCJfIiwicGFyc2VJbnQiLCJDbGllbnRlc0NvbnRyYXRvcyIsImljb25OYW1lIiwic3R5bGUiLCJmb250U2l6ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2xpZW50QWN0aW9ucy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NsaWVudHMvY29tcG9uZW50cy9DbGllbnRBY3Rpb25zLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IElDb250ZXh0dWFsTWVudVByb3BzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9Db250ZXh0dWFsTWVudSdcbmltcG9ydCB7IGNsaWVudFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcbmltcG9ydCB7IGRvd25sb2FkRmlsZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscydcbmltcG9ydCB7IFByaW1hcnlCdXR0b24sIENvbW1hbmRCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IEV4cG9ydENsaWVudEVudW0gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvZW51bXMvRXhwb3J0Q2xpZW50RW51bSdcbmltcG9ydCBFeHBvcnRDbGllbnRSZWNvcmQgZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3JlY29yZC9FeHBvcnRDbGllbnRSZWNvcmQnXG5cbmludGVyZmFjZSBDbGllbnRBY3Rpb25zUHJvcHMge1xuICBkaXNhYmxlZFJlbW92ZUJ1dHRvbjogYm9vbGVhblxuICBkaXNhYmxlZEFkZEJ1dHRvbj86IGJvb2xlYW5cbiAgb25BZGQ6ICgpID0+IHZvaWRcbiAgb25SZW1vdmU6ICgpID0+IHZvaWRcbiAgZGVsZXRlUGVybWlzc2lvbjogYm9vbGVhblxuICBjcmVhdGVQZXJtaXNzaW9uOiBib29sZWFuXG4gIHZpc3VhbGl6ZVBlcm1pc3Npb246IGJvb2xlYW5cbn1cblxuY29uc3QgQ2xpZW50QWN0aW9uczogRkM8Q2xpZW50QWN0aW9uc1Byb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgZGlzYWJsZWRSZW1vdmVCdXR0b24sXG4gICAgb25BZGQsXG4gICAgb25SZW1vdmUsXG4gICAgZGlzYWJsZWRBZGRCdXR0b24sXG4gICAgZGVsZXRlUGVybWlzc2lvbixcbiAgICBjcmVhdGVQZXJtaXNzaW9uLFxuICAgIHZpc3VhbGl6ZVBlcm1pc3Npb24sXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IFtleHBvcnRGaWxlLCBzZXRFeHBvcnRGaWxlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxuXG4gIGNvbnN0IGRvd25sb2FkID0gdXNlQ2FsbGJhY2soKGl0ZW06IG51bWJlcikgPT4ge1xuICAgIGNsaWVudFNlcnZpY2UuZG93bmxvYWQoaXRlbSBhcyBudW1iZXIpXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgZG93bmxvYWRGaWxlKHJlc3BvbnNlKVxuICAgICAgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgICAgIHNldEV4cG9ydEZpbGUoZmFsc2UpXG4gICAgICB9KVxuICB9LCBbZXhwb3J0RmlsZV0pXG5cbiAgY29uc3QgbWVudVByb3BzOiBJQ29udGV4dHVhbE1lbnVQcm9wcyA9IHtcbiAgICBzaG91bGRGb2N1c09uTW91bnQ6IHRydWUsXG4gICAgc2hvdWxkRm9jdXNPbkNvbnRhaW5lcjogdHJ1ZSxcbiAgICBpdGVtczogW1xuICAgICAgeyBrZXk6IEV4cG9ydENsaWVudEVudW0uQ2xpZW50ZXNFbXByZXNhcy50b1N0cmluZygpLCB0ZXh0OiBFeHBvcnRDbGllbnRSZWNvcmRbRXhwb3J0Q2xpZW50RW51bS5DbGllbnRlc0VtcHJlc2FzXSwgb25DbGljazogKF8sIGl0ZW0pID0+IGRvd25sb2FkKHBhcnNlSW50KGl0ZW0/LmtleSBhcyBzdHJpbmcpKSB9LFxuICAgICAgeyBrZXk6IEV4cG9ydENsaWVudEVudW0uQ2xpZW50ZXNDb250cmF0b3MudG9TdHJpbmcoKSwgdGV4dDogRXhwb3J0Q2xpZW50UmVjb3JkW0V4cG9ydENsaWVudEVudW0uQ2xpZW50ZXNDb250cmF0b3NdLCBvbkNsaWNrOiAoXywgaXRlbSkgPT4gZG93bmxvYWQocGFyc2VJbnQoaXRlbT8ua2V5IGFzIHN0cmluZykpIH0sXG4gICAgXSxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtjcmVhdGVQZXJtaXNzaW9uICYmIDxQcmltYXJ5QnV0dG9uXG4gICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0FkZCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICAgIHRleHQ9XCJBZGljaW9uYXJcIlxuICAgICAgICBvbkNsaWNrPXtvbkFkZH1cbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkQWRkQnV0dG9ufVxuICAgICAgLz59XG4gICAgICB7dmlzdWFsaXplUGVybWlzc2lvbiAmJlxuICAgICAgPENvbW1hbmRCdXR0b25cbiAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiAnRG93bmxvYWQnIH19XG4gICAgICAgIHRleHQ9J0V4cG9ydGFyJ1xuICAgICAgICBtZW51UHJvcHM9e21lbnVQcm9wc31cbiAgICAgIC8+fVxuICAgICAge2RlbGV0ZVBlcm1pc3Npb24gJiYgPENvbW1hbmRCdXR0b25cbiAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiAnVHJhc2gnLCBzdHlsZTogeyBmb250U2l6ZTogMTQgfSB9fVxuICAgICAgICB0ZXh0PVwiRXhjbHVpclwiXG4gICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZFJlbW92ZUJ1dHRvbn1cbiAgICAgICAgb25DbGljaz17b25SZW1vdmV9XG4gICAgICAvPn1cbiAgICA8Lz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDbGllbnRBY3Rpb25zXG4iXX0=