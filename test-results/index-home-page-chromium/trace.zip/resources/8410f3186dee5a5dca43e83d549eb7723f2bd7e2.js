export var DeadlineEnum = /* @__PURE__ */ ((DeadlineEnum2) => {
  DeadlineEnum2[DeadlineEnum2["all"] = 0] = "all";
  DeadlineEnum2[DeadlineEnum2["oneMonth"] = 1] = "oneMonth";
  DeadlineEnum2[DeadlineEnum2["twoWeeks"] = 2] = "twoWeeks";
  DeadlineEnum2[DeadlineEnum2["oneWeek"] = 3] = "oneWeek";
  DeadlineEnum2[DeadlineEnum2["oneDay"] = 4] = "oneDay";
  return DeadlineEnum2;
})(DeadlineEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkRlYWRsaW5lRW51bS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xuZXhwb3J0IGVudW0gRGVhZGxpbmVFbnVtIHtcbiAgYWxsLFxuICBvbmVNb250aCxcbiAgdHdvV2Vla3MsXG4gIG9uZVdlZWssXG4gIG9uZURheSxcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ08sV0FBSyxlQUFMLGtCQUFLQSxrQkFBTDtBQUNMLEVBQUFBLDRCQUFBO0FBQ0EsRUFBQUEsNEJBQUE7QUFDQSxFQUFBQSw0QkFBQTtBQUNBLEVBQUFBLDRCQUFBO0FBQ0EsRUFBQUEsNEJBQUE7QUFMVSxTQUFBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiRGVhZGxpbmVFbnVtIl19