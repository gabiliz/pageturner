export default function downloadFile(response) {
  const disposition = response?.headers["content-disposition"];
  const type = response?.headers["content-type"];
  let filename = "";
  if (disposition && disposition.indexOf("attachment") !== -1) {
    const matches = /[^;\n=]*=((['"]).*?\2|[^;\n]*)/.exec(disposition);
    if (matches !== null && matches[1]) {
      filename = matches[1].replace(/['"]/g, "");
    }
  }
  const blob = new Blob([response?.data], { type });
  const newLink = document.createElement("a");
  newLink.download = filename;
  if (window.webkitURL !== null) {
    newLink.href = window.webkitURL.createObjectURL(blob);
  } else {
    newLink.href = window.URL.createObjectURL(blob);
  }
  newLink.click();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvd25sb2FkRmlsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBeGlvc1Jlc3BvbnNlIH0gZnJvbSAnYXhpb3MnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGRvd25sb2FkRmlsZSAocmVzcG9uc2U6IEF4aW9zUmVzcG9uc2UgfCBudWxsKTogdm9pZCB7XG4gIGNvbnN0IGRpc3Bvc2l0aW9uID0gcmVzcG9uc2U/LmhlYWRlcnNbJ2NvbnRlbnQtZGlzcG9zaXRpb24nXVxuICBjb25zdCB0eXBlID0gcmVzcG9uc2U/LmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddXG4gIGxldCBmaWxlbmFtZSA9ICcnXG4gIGlmIChkaXNwb3NpdGlvbiAmJiBkaXNwb3NpdGlvbi5pbmRleE9mKCdhdHRhY2htZW50JykgIT09IC0xKSB7XG4gICAgY29uc3QgbWF0Y2hlcyA9IC9bXjtcXG49XSo9KChbJ1wiXSkuKj9cXDJ8W147XFxuXSopLy5leGVjKGRpc3Bvc2l0aW9uKVxuICAgIGlmIChtYXRjaGVzICE9PSBudWxsICYmIG1hdGNoZXNbMV0pIHtcbiAgICAgIGZpbGVuYW1lID0gbWF0Y2hlc1sxXS5yZXBsYWNlKC9bJ1wiXS9nLCAnJylcbiAgICB9XG4gIH1cbiAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtyZXNwb25zZT8uZGF0YV0sIHsgdHlwZSB9KVxuICBjb25zdCBuZXdMaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gIG5ld0xpbmsuZG93bmxvYWQgPSBmaWxlbmFtZVxuICBpZiAod2luZG93LndlYmtpdFVSTCAhPT0gbnVsbCkge1xuICAgIG5ld0xpbmsuaHJlZiA9IHdpbmRvdy53ZWJraXRVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gIH0gZWxzZSB7XG4gICAgbmV3TGluay5ocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcbiAgfVxuICBuZXdMaW5rLmNsaWNrKClcbn1cbiJdLCJtYXBwaW5ncyI6IkFBRUEsd0JBQXdCLGFBQWMsVUFBc0M7QUFDMUUsUUFBTSxjQUFjLFVBQVUsUUFBUSxxQkFBcUI7QUFDM0QsUUFBTSxPQUFPLFVBQVUsUUFBUSxjQUFjO0FBQzdDLE1BQUksV0FBVztBQUNmLE1BQUksZUFBZSxZQUFZLFFBQVEsWUFBWSxNQUFNLElBQUk7QUFDM0QsVUFBTSxVQUFVLGlDQUFpQyxLQUFLLFdBQVc7QUFDakUsUUFBSSxZQUFZLFFBQVEsUUFBUSxDQUFDLEdBQUc7QUFDbEMsaUJBQVcsUUFBUSxDQUFDLEVBQUUsUUFBUSxTQUFTLEVBQUU7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsVUFBVSxJQUFJLEdBQUcsRUFBRSxLQUFLLENBQUM7QUFDaEQsUUFBTSxVQUFVLFNBQVMsY0FBYyxHQUFHO0FBQzFDLFVBQVEsV0FBVztBQUNuQixNQUFJLE9BQU8sY0FBYyxNQUFNO0FBQzdCLFlBQVEsT0FBTyxPQUFPLFVBQVUsZ0JBQWdCLElBQUk7QUFBQSxFQUN0RCxPQUFPO0FBQ0wsWUFBUSxPQUFPLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtBQUFBLEVBQ2hEO0FBQ0EsVUFBUSxNQUFNO0FBQ2hCOyIsIm5hbWVzIjpbXX0=