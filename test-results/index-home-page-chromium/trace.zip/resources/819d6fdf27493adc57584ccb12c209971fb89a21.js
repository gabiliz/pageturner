import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileEditForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Tree } from "/node_modules/.vite/deps/primereact_tree.js?v=9f90a7ff";
import { permissionService } from "/src/modules/admin/profiles/services/index.ts";
import { Text } from "/node_modules/.vite/deps/@uifabric_experiments.js?v=9f90a7ff";
import { FlexItem, TextField } from "/src/shared/components/index.ts?t=1701096626433";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
import { FontSizes } from "/node_modules/.vite/deps/@fluentui_react_lib_Styling.js?v=9f90a7ff";
const ProfileEditForm = (props) => {
  _s();
  const {
    localFormData,
    setLocalFormData,
    profile,
    onTextChange,
    apiError,
    onFieldError
  } = props;
  const {
    data: permissionModules
  } = permissionService.useFindAllPaginated();
  const permissionsTree = useMemo(() => makeTree(permissionModules ?? []), [permissionModules]);
  const [permissionSelection, setPermissionSelection] = useState({});
  useEffect(() => {
    if (profile) {
      const selection = makeTreeSelection(profile.permissoes, permissionsTree);
      setPermissionSelection(selection);
    }
  }, [profile, permissionsTree]);
  const changePermissionSelection = useCallback((event) => {
    setPermissionSelection(event.value);
  }, []);
  useEffect(() => {
    const permissions = convertSelectionToPermission(permissionSelection);
    setLocalFormData((localFormData2) => ({
      ...localFormData2,
      permissoes: permissions
    }));
  }, [permissionSelection]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome", required: true, value: localFormData.nome, onChange: onTextChange("nome"), maxLength: 40, errorMessage: apiError?.errors?.messages ? onFieldError("nome", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Descrição", required: true, value: localFormData.descricao, onChange: onTextChange("descricao"), multiline: true, rows: 10, resizable: false, maxLength: 255, errorMessage: apiError?.errors?.messages ? onFieldError("descricao", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Text, { variant: "xLarge", children: "Permissões" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Tree, { value: permissionsTree, selectionMode: "checkbox", selectionKeys: permissionSelection, onSelectionChange: changePermissionSelection }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx",
    lineNumber: 55,
    columnNumber: 10
  }, this);
};
_s(ProfileEditForm, "ooHZJzLIyAweKabKNf/h0mHZFII=", false, function() {
  return [permissionService.useFindAllPaginated];
});
_c = ProfileEditForm;
function makeTree(permissionModules) {
  return permissionModules.map((module) => ({
    key: `module${module.modulo}`,
    label: module.modulo.charAt(0).concat(module.modulo.slice(1).toLocaleLowerCase()),
    selectable: false,
    style: {
      fontSize: FontSizes.size16
    },
    children: module.servicos.map((service) => ({
      key: `${service.servico}`,
      label: service.descricao?.charAt(0).concat(service.descricao.slice(1).toLocaleLowerCase()),
      style: {
        fontSize: FontSizes.size16
      },
      children: service.regras.map((permission) => ({
        key: `${service.servico}.${permission.permissao}`,
        label: permission.permissao.charAt(0).concat(permission.permissao.slice(1).toLocaleLowerCase()),
        style: {
          fontSize: FontSizes.size14
        }
      }))
    }))
  }));
}
function makeTreeSelection(profilePermissions, tree) {
  const parents = getParents(tree);
  const childrenPermission = getChildrenPermission(profilePermissions);
  const parentPermission = getParentPermission(childrenPermission, parents);
  return {
    ...parentPermission,
    ...childrenPermission
  };
}
function getChildrenPermission(profilePermissions) {
  return Object.fromEntries(profilePermissions.reduce((p, c) => {
    const entry = [`${c.codigo}.${c.permissao}`, {
      checked: true
    }];
    return [...p, entry];
  }, []) ?? []);
}
function getParentPermission(childrenPermission, parents) {
  return Object.fromEntries(parents.reduce((p, c) => {
    const childrenPermissionKey = Object.keys(childrenPermission).filter((key) => key.includes(c.key));
    if (c.children?.length === childrenPermissionKey.length) {
      const entry2 = [`${c.key}`, {
        checked: true
      }];
      return [...p, entry2];
    } else if (childrenPermissionKey.length === 0) {
      return [...p];
    }
    const entry = [`${c.key}`, {
      partialChecked: true
    }];
    return [...p, entry];
  }, []) ?? []);
}
function getParents(tree) {
  const parents = tree.map((node) => node.children);
  let newParents = [];
  for (const parent of parents) {
    newParents = [...newParents, ...parent];
  }
  return [...newParents];
}
function convertSelectionToPermission(permissionSelection) {
  return Object.entries(permissionSelection).filter(
    ([key, value]) => key.match(/^.+\..+$/) && value.checked
    // TreeSelectionKeysType não contém a estrutura real do objeto
  ).map(([key]) => {
    const [service, permission] = key.split(".");
    return {
      codigo: service,
      permissao: permission
    };
  });
}
export default ProfileEditForm;
var _c;
$RefreshReg$(_c, "ProfileEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUROLFNBQWFBLFVBQVVDLGFBQWFDLFdBQVdDLGVBQXlDO0FBQ3hGLFNBQXFEQyxZQUFZO0FBR2pFLFNBQVNDLHlCQUF5QjtBQUlsQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUNwQyxPQUFPQyxnQkFBZ0I7QUFHdkIsU0FBU0MsaUJBQWlCO0FBVzFCLE1BQU1DLGtCQUE2Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQzNELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFlQztBQUFBQSxJQUFrQkM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBY0M7QUFBQUEsSUFBVUM7QUFBQUEsRUFBYSxJQUFJUDtBQUUzRixRQUFNO0FBQUEsSUFBRVEsTUFBTUM7QUFBQUEsRUFBa0IsSUFBSWhCLGtCQUFrQmlCLG9CQUFvQjtBQUUxRSxRQUFNQyxrQkFBa0JwQixRQUN0QixNQUFNcUIsU0FBU0gscUJBQXFCLEVBQUUsR0FDdEMsQ0FBQ0EsaUJBQWlCLENBQ3BCO0FBRUEsUUFBTSxDQUNKSSxxQkFDQUMsc0JBQXNCLElBQ3BCMUIsU0FBZ0MsQ0FBQyxDQUFDO0FBRXRDRSxZQUFVLE1BQU07QUFDZCxRQUFJYyxTQUFTO0FBQ1gsWUFBTVcsWUFBWUMsa0JBQWtCWixRQUFRYSxZQUFZTixlQUFlO0FBQ3ZFRyw2QkFBdUJDLFNBQVM7QUFBQSxJQUNsQztBQUFBLEVBQ0YsR0FBRyxDQUFDWCxTQUFTTyxlQUFlLENBQUM7QUFFN0IsUUFBTU8sNEJBQTRCN0IsWUFBWSxDQUFDOEIsVUFBK0I7QUFDNUVMLDJCQUF1QkssTUFBTUMsS0FBSztBQUFBLEVBQ3BDLEdBQUcsRUFBRTtBQUVMOUIsWUFBVSxNQUFNO0FBQ2QsVUFBTStCLGNBQTRCQyw2QkFBNkJULG1CQUFtQjtBQUNsRlYscUJBQWlCRCxxQkFBa0I7QUFBQSxNQUNqQyxHQUFHQTtBQUFBQSxNQUNIZSxZQUFZSTtBQUFBQSxJQUNkLEVBQUU7QUFBQSxFQUNKLEdBQUcsQ0FBQ1IsbUJBQW1CLENBQUM7QUFFeEIsU0FDRSx1QkFBQyxjQUFXLEtBQU0sSUFDaEI7QUFBQSwyQkFBQyxhQUNDLE9BQU0sUUFDTixVQUFRLE1BQ1IsT0FBT1gsY0FBY3FCLE1BQ3JCLFVBQVVsQixhQUFhLE1BQU0sR0FDN0IsV0FBVyxJQUNYLGNBQWNDLFVBQVVrQixRQUFRQyxXQUM1QmxCLGFBQWEsUUFBUUQsVUFBVWtCLFFBQVFDLFFBQVEsSUFDL0NDLFVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNHO0FBQUEsSUFFSCx1QkFBQyxhQUNDLE9BQU0sYUFDTixVQUFRLE1BQ1IsT0FBT3hCLGNBQWN5QixXQUNyQixVQUFVdEIsYUFBYSxXQUFXLEdBQ2xDLFdBQVMsTUFDVCxNQUFNLElBQ04sV0FBVyxPQUNYLFdBQVcsS0FDWCxjQUFjQyxVQUFVa0IsUUFBUUMsV0FDNUJsQixhQUFhLGFBQWFELFVBQVVrQixRQUFRQyxRQUFRLElBQ3BEQyxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZRztBQUFBLElBRUgsdUJBQUMsWUFDQztBQUFBLDZCQUFDLFFBQUssU0FBUSxVQUFTLDBCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsUUFDQyxPQUFPZixpQkFDUCxlQUFjLFlBQ2QsZUFBZUUscUJBQ2YsbUJBQW1CSyw2QkFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUkrQztBQUFBLFNBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDakIsR0F4RUtGLGlCQUF5QztBQUFBLFVBR1ROLGtCQUFrQmlCLG1CQUFtQjtBQUFBO0FBQUFrQixLQUhyRTdCO0FBMEVOLFNBQVNhLFNBQVVILG1CQUFtRDtBQUNwRSxTQUFPQSxrQkFBa0JvQixJQUFLQyxhQUFZO0FBQUEsSUFDeENDLEtBQU0sU0FBUUQsT0FBT0U7QUFBQUEsSUFDckJDLE9BQU9ILE9BQU9FLE9BQU9FLE9BQU8sQ0FBQyxFQUFFQyxPQUFPTCxPQUFPRSxPQUFPSSxNQUFNLENBQUMsRUFBRUMsa0JBQWtCLENBQUM7QUFBQSxJQUNoRkMsWUFBWTtBQUFBLElBQ1pDLE9BQU87QUFBQSxNQUFFQyxVQUFVMUMsVUFBVTJDO0FBQUFBLElBQU87QUFBQSxJQUNwQ0MsVUFBVVosT0FBT2EsU0FBU2QsSUFBS2UsY0FBYTtBQUFBLE1BQzFDYixLQUFNLEdBQUVhLFFBQVFDO0FBQUFBLE1BQ2hCWixPQUFPVyxRQUFRakIsV0FBV08sT0FBTyxDQUFDLEVBQUVDLE9BQU9TLFFBQVFqQixVQUFVUyxNQUFNLENBQUMsRUFBRUMsa0JBQWtCLENBQUM7QUFBQSxNQUN6RkUsT0FBTztBQUFBLFFBQUVDLFVBQVUxQyxVQUFVMkM7QUFBQUEsTUFBTztBQUFBLE1BQ3BDQyxVQUFVRSxRQUFRRSxPQUFPakIsSUFBS2tCLGlCQUFnQjtBQUFBLFFBQzVDaEIsS0FBTSxHQUFFYSxRQUFRQyxXQUFXRSxXQUFXQztBQUFBQSxRQUN0Q2YsT0FBT2MsV0FBV0MsVUFBVWQsT0FBTyxDQUFDLEVBQUVDLE9BQU9ZLFdBQVdDLFVBQVVaLE1BQU0sQ0FBQyxFQUFFQyxrQkFBa0IsQ0FBQztBQUFBLFFBQzlGRSxPQUFPO0FBQUEsVUFBRUMsVUFBVTFDLFVBQVVtRDtBQUFBQSxRQUFPO0FBQUEsTUFDdEMsRUFBRTtBQUFBLElBQ0osRUFBRTtBQUFBLEVBQ0osRUFBRTtBQUNKO0FBRUEsU0FBU2pDLGtCQUFtQmtDLG9CQUFrQ0MsTUFBeUM7QUFDckcsUUFBTUMsVUFBVUMsV0FBV0YsSUFBSTtBQUMvQixRQUFNRyxxQkFBcUJDLHNCQUFzQkwsa0JBQWtCO0FBQ25FLFFBQU1NLG1CQUFtQkMsb0JBQW9CSCxvQkFBb0JGLE9BQU87QUFDeEUsU0FBTztBQUFBLElBQUUsR0FBR0k7QUFBQUEsSUFBa0IsR0FBR0Y7QUFBQUEsRUFBbUI7QUFDdEQ7QUFFQSxTQUFTQyxzQkFBdUJMLG9CQUFrQztBQUNoRSxTQUFPUSxPQUFPQyxZQUNaVCxtQkFBbUJVLE9BQ2pCLENBQUNDLEdBQUdDLE1BQU07QUFDUixVQUFNQyxRQUE0QixDQUFFLEdBQUVELEVBQUVFLFVBQVVGLEVBQUVkLGFBQWE7QUFBQSxNQUFFaUIsU0FBUztBQUFBLElBQUssQ0FBQztBQUNsRixXQUFPLENBQUMsR0FBR0osR0FBR0UsS0FBSztBQUFBLEVBQ3JCLEdBQ0EsRUFDRixLQUFLLEVBQ1A7QUFDRjtBQUVBLFNBQVNOLG9CQUFxQkgsb0JBQW1DRixTQUFxQjtBQUNwRixTQUFPTSxPQUFPQyxZQUNaUCxRQUFRUSxPQUNOLENBQUNDLEdBQUdDLE1BQU07QUFDUixVQUFNSSx3QkFBd0JSLE9BQU9TLEtBQUtiLGtCQUFrQixFQUFFYyxPQUFPckMsU0FBT0EsSUFBSXNDLFNBQVNQLEVBQUUvQixHQUFhLENBQUM7QUFDekcsUUFBSStCLEVBQUVwQixVQUFVNEIsV0FBV0osc0JBQXNCSSxRQUFRO0FBQ3ZELFlBQU1QLFNBQTRCLENBQUUsR0FBRUQsRUFBRS9CLE9BQU87QUFBQSxRQUFFa0MsU0FBUztBQUFBLE1BQUssQ0FBQztBQUNoRSxhQUFPLENBQUMsR0FBR0osR0FBR0UsTUFBSztBQUFBLElBQ3JCLFdBQVdHLHNCQUFzQkksV0FBVyxHQUFHO0FBQzdDLGFBQU8sQ0FBQyxHQUFHVCxDQUFDO0FBQUEsSUFDZDtBQUNBLFVBQU1FLFFBQTRCLENBQUUsR0FBRUQsRUFBRS9CLE9BQU87QUFBQSxNQUFFd0MsZ0JBQWdCO0FBQUEsSUFBSyxDQUFDO0FBQ3ZFLFdBQU8sQ0FBQyxHQUFHVixHQUFHRSxLQUFLO0FBQUEsRUFDckIsR0FBRyxFQUNMLEtBQUssRUFDUDtBQUNGO0FBRUEsU0FBU1YsV0FBWUYsTUFBa0I7QUFDckMsUUFBTUMsVUFBVUQsS0FBS3RCLElBQUkyQyxVQUFRQSxLQUFLOUIsUUFBUTtBQUM5QyxNQUFJK0IsYUFBeUI7QUFDN0IsYUFBV0MsVUFBVXRCLFNBQVM7QUFDNUJxQixpQkFBYSxDQUFDLEdBQUdBLFlBQVksR0FBR0MsTUFBTTtBQUFBLEVBQ3hDO0FBQ0EsU0FBTyxDQUFDLEdBQUdELFVBQVU7QUFDdkI7QUFFQSxTQUFTbkQsNkJBQThCVCxxQkFBMEQ7QUFDL0YsU0FBTzZDLE9BQU9pQixRQUFROUQsbUJBQW1CLEVBQ3RDdUQ7QUFBQUEsSUFBTyxDQUFDLENBQUNyQyxLQUFLWCxLQUFLLE1BQ2pCVyxJQUFJNkMsTUFBTSxVQUFVLEtBQU14RCxNQUFtQzZDO0FBQUFBO0FBQUFBLEVBQy9ELEVBQ0FwQyxJQUFJLENBQUMsQ0FBQ0UsR0FBRyxNQUFNO0FBQ2QsVUFBTSxDQUFDYSxTQUFTRyxVQUFVLElBQUloQixJQUFJOEMsTUFBTSxHQUFHO0FBQzNDLFdBQU87QUFBQSxNQUNMYixRQUFRcEI7QUFBQUEsTUFDUkksV0FBV0Q7QUFBQUEsSUFDYjtBQUFBLEVBQ0YsQ0FBQztBQUNMO0FBRUEsZUFBZWhEO0FBQWUsSUFBQTZCO0FBQUFrRCxhQUFBbEQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwiVHJlZSIsInBlcm1pc3Npb25TZXJ2aWNlIiwiVGV4dCIsIkZsZXhJdGVtIiwiVGV4dEZpZWxkIiwiRmxleENvbHVtbiIsIkZvbnRTaXplcyIsIlByb2ZpbGVFZGl0Rm9ybSIsInByb3BzIiwiX3MiLCJsb2NhbEZvcm1EYXRhIiwic2V0TG9jYWxGb3JtRGF0YSIsInByb2ZpbGUiLCJvblRleHRDaGFuZ2UiLCJhcGlFcnJvciIsIm9uRmllbGRFcnJvciIsImRhdGEiLCJwZXJtaXNzaW9uTW9kdWxlcyIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCJwZXJtaXNzaW9uc1RyZWUiLCJtYWtlVHJlZSIsInBlcm1pc3Npb25TZWxlY3Rpb24iLCJzZXRQZXJtaXNzaW9uU2VsZWN0aW9uIiwic2VsZWN0aW9uIiwibWFrZVRyZWVTZWxlY3Rpb24iLCJwZXJtaXNzb2VzIiwiY2hhbmdlUGVybWlzc2lvblNlbGVjdGlvbiIsImV2ZW50IiwidmFsdWUiLCJwZXJtaXNzaW9ucyIsImNvbnZlcnRTZWxlY3Rpb25Ub1Blcm1pc3Npb24iLCJub21lIiwiZXJyb3JzIiwibWVzc2FnZXMiLCJ1bmRlZmluZWQiLCJkZXNjcmljYW8iLCJfYyIsIm1hcCIsIm1vZHVsZSIsImtleSIsIm1vZHVsbyIsImxhYmVsIiwiY2hhckF0IiwiY29uY2F0Iiwic2xpY2UiLCJ0b0xvY2FsZUxvd2VyQ2FzZSIsInNlbGVjdGFibGUiLCJzdHlsZSIsImZvbnRTaXplIiwic2l6ZTE2IiwiY2hpbGRyZW4iLCJzZXJ2aWNvcyIsInNlcnZpY2UiLCJzZXJ2aWNvIiwicmVncmFzIiwicGVybWlzc2lvbiIsInBlcm1pc3NhbyIsInNpemUxNCIsInByb2ZpbGVQZXJtaXNzaW9ucyIsInRyZWUiLCJwYXJlbnRzIiwiZ2V0UGFyZW50cyIsImNoaWxkcmVuUGVybWlzc2lvbiIsImdldENoaWxkcmVuUGVybWlzc2lvbiIsInBhcmVudFBlcm1pc3Npb24iLCJnZXRQYXJlbnRQZXJtaXNzaW9uIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJyZWR1Y2UiLCJwIiwiYyIsImVudHJ5IiwiY29kaWdvIiwiY2hlY2tlZCIsImNoaWxkcmVuUGVybWlzc2lvbktleSIsImtleXMiLCJmaWx0ZXIiLCJpbmNsdWRlcyIsImxlbmd0aCIsInBhcnRpYWxDaGVja2VkIiwibm9kZSIsIm5ld1BhcmVudHMiLCJwYXJlbnQiLCJlbnRyaWVzIiwibWF0Y2giLCJzcGxpdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2ZpbGVFZGl0Rm9ybS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3Byb2ZpbGVzL2NvbXBvbmVudHMvUHJvZmlsZUVkaXRGb3JtLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgU2V0U3RhdGVBY3Rpb24sIERpc3BhdGNoIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IFRyZWVTZWxlY3Rpb25QYXJhbXMsIFRyZWVTZWxlY3Rpb25LZXlzVHlwZSwgVHJlZSB9IGZyb20gJ3ByaW1lcmVhY3QvdHJlZSdcclxuaW1wb3J0IFByb2ZpbGVDb21tYW5kIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Qcm9maWxlQ29tbWFuZCdcclxuaW1wb3J0IFBlcm1pc3Npb24gZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1Blcm1pc3Npb24nXHJcbmltcG9ydCB7IHBlcm1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcbmltcG9ydCBQZXJtaXNzaW9uTW9kdWxlIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9QZXJtaXNzaW9uTW9kdWxlJ1xyXG5pbXBvcnQgeyBUcmVlU2VsZWN0aW9uLCBUcmVlU2VsZWN0aW9uRW50cnksIFRyZWVTZWxlY3Rpb25JdGVtIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL1ByaW1lZmFjZXNUcmVlJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lcnJvcnMnXHJcbmltcG9ydCB7IFRleHQgfSBmcm9tICdAdWlmYWJyaWMvZXhwZXJpbWVudHMnXHJcbmltcG9ydCB7IEZsZXhJdGVtLCBUZXh0RmllbGQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IEZsZXhDb2x1bW4gZnJvbSAnLi8uLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cy9GbGV4Qm94L0ZsZXhDb2x1bW4nXHJcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBpbXBvcnQvbm8tdW5yZXNvbHZlZFxyXG5pbXBvcnQgVHJlZU5vZGUgZnJvbSAncHJpbWVyZWFjdC90cmVlbm9kZS90cmVlbm9kZSdcclxuaW1wb3J0IHsgRm9udFNpemVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9TdHlsaW5nJ1xyXG5cclxuaW50ZXJmYWNlIFByb2ZpbGVFZGl0Rm9ybVByb3BzIHtcclxuICBwcm9maWxlOiBQcm9maWxlQ29tbWFuZFxyXG4gIGxvY2FsRm9ybURhdGE6IFByb2ZpbGVDb21tYW5kLFxyXG4gIHNldExvY2FsRm9ybURhdGE6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFByb2ZpbGVDb21tYW5kPj5cclxuICBvblRleHRDaGFuZ2U6IChrZXk6IGtleW9mIFByb2ZpbGVDb21tYW5kKSA9PiAoXz86IHVua25vd24sIHZhbHVlPzogc3RyaW5nIHwgdW5kZWZpbmVkKSA9PiB2b2lkXHJcbiAgb25GaWVsZEVycm9yOiAoa2V5OiBrZXlvZiBQcm9maWxlQ29tbWFuZCwgZXJyb3JzOiBBcnJheTx1bmtub3duPikgPT4gc3RyaW5nIHwgdW5kZWZpbmVkXHJcbiAgYXBpRXJyb3I/OiBBcGlFcnJvclxyXG59XHJcblxyXG5jb25zdCBQcm9maWxlRWRpdEZvcm06IEZDPFByb2ZpbGVFZGl0Rm9ybVByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgbG9jYWxGb3JtRGF0YSwgc2V0TG9jYWxGb3JtRGF0YSwgcHJvZmlsZSwgb25UZXh0Q2hhbmdlLCBhcGlFcnJvciwgb25GaWVsZEVycm9yIH0gPSBwcm9wc1xyXG5cclxuICBjb25zdCB7IGRhdGE6IHBlcm1pc3Npb25Nb2R1bGVzIH0gPSBwZXJtaXNzaW9uU2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKClcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbnNUcmVlID0gdXNlTWVtbzxUcmVlTm9kZVtdPihcclxuICAgICgpID0+IG1ha2VUcmVlKHBlcm1pc3Npb25Nb2R1bGVzID8/IFtdKSxcclxuICAgIFtwZXJtaXNzaW9uTW9kdWxlc10sXHJcbiAgKVxyXG5cclxuICBjb25zdCBbXHJcbiAgICBwZXJtaXNzaW9uU2VsZWN0aW9uLFxyXG4gICAgc2V0UGVybWlzc2lvblNlbGVjdGlvbixcclxuICBdID0gdXNlU3RhdGU8VHJlZVNlbGVjdGlvbktleXNUeXBlPih7fSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChwcm9maWxlKSB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGlvbiA9IG1ha2VUcmVlU2VsZWN0aW9uKHByb2ZpbGUucGVybWlzc29lcywgcGVybWlzc2lvbnNUcmVlKVxyXG4gICAgICBzZXRQZXJtaXNzaW9uU2VsZWN0aW9uKHNlbGVjdGlvbilcclxuICAgIH1cclxuICB9LCBbcHJvZmlsZSwgcGVybWlzc2lvbnNUcmVlXSlcclxuXHJcbiAgY29uc3QgY2hhbmdlUGVybWlzc2lvblNlbGVjdGlvbiA9IHVzZUNhbGxiYWNrKChldmVudDogVHJlZVNlbGVjdGlvblBhcmFtcykgPT4ge1xyXG4gICAgc2V0UGVybWlzc2lvblNlbGVjdGlvbihldmVudC52YWx1ZSlcclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHBlcm1pc3Npb25zOiBQZXJtaXNzaW9uW10gPSBjb252ZXJ0U2VsZWN0aW9uVG9QZXJtaXNzaW9uKHBlcm1pc3Npb25TZWxlY3Rpb24pXHJcbiAgICBzZXRMb2NhbEZvcm1EYXRhKGxvY2FsRm9ybURhdGEgPT4gKHtcclxuICAgICAgLi4ubG9jYWxGb3JtRGF0YSxcclxuICAgICAgcGVybWlzc29lczogcGVybWlzc2lvbnMsXHJcbiAgICB9KSlcclxuICB9LCBbcGVybWlzc2lvblNlbGVjdGlvbl0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxyXG4gICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgbGFiZWw9XCJOb21lXCJcclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLm5vbWV9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnbm9tZScpfVxyXG4gICAgICAgIG1heExlbmd0aD17NDB9XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ25vbWUnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgbGFiZWw9XCJEZXNjcmnDp8Ojb1wiXHJcbiAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5kZXNjcmljYW99XHJcbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnZGVzY3JpY2FvJyl9XHJcbiAgICAgICAgbXVsdGlsaW5lXHJcbiAgICAgICAgcm93cz17MTB9XHJcbiAgICAgICAgcmVzaXphYmxlPXtmYWxzZX1cclxuICAgICAgICBtYXhMZW5ndGg9ezI1NX1cclxuICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICA/IG9uRmllbGRFcnJvcignZGVzY3JpY2FvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuICAgICAgPEZsZXhJdGVtPlxyXG4gICAgICAgIDxUZXh0IHZhcmlhbnQ9XCJ4TGFyZ2VcIj5QZXJtaXNzw7VlczwvVGV4dD5cclxuICAgICAgICA8VHJlZVxyXG4gICAgICAgICAgdmFsdWU9e3Blcm1pc3Npb25zVHJlZX1cclxuICAgICAgICAgIHNlbGVjdGlvbk1vZGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICBzZWxlY3Rpb25LZXlzPXtwZXJtaXNzaW9uU2VsZWN0aW9ufVxyXG4gICAgICAgICAgb25TZWxlY3Rpb25DaGFuZ2U9e2NoYW5nZVBlcm1pc3Npb25TZWxlY3Rpb259XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9GbGV4SXRlbT5cclxuICAgIDwvIEZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYWtlVHJlZSAocGVybWlzc2lvbk1vZHVsZXM6IFBlcm1pc3Npb25Nb2R1bGVbXSk6IFRyZWVOb2RlW10ge1xyXG4gIHJldHVybiBwZXJtaXNzaW9uTW9kdWxlcy5tYXAoKG1vZHVsZSkgPT4gKHtcclxuICAgIGtleTogYG1vZHVsZSR7bW9kdWxlLm1vZHVsb31gLFxyXG4gICAgbGFiZWw6IG1vZHVsZS5tb2R1bG8uY2hhckF0KDApLmNvbmNhdChtb2R1bGUubW9kdWxvLnNsaWNlKDEpLnRvTG9jYWxlTG93ZXJDYXNlKCkpLFxyXG4gICAgc2VsZWN0YWJsZTogZmFsc2UsXHJcbiAgICBzdHlsZTogeyBmb250U2l6ZTogRm9udFNpemVzLnNpemUxNiB9LFxyXG4gICAgY2hpbGRyZW46IG1vZHVsZS5zZXJ2aWNvcy5tYXAoKHNlcnZpY2UpID0+ICh7XHJcbiAgICAgIGtleTogYCR7c2VydmljZS5zZXJ2aWNvfWAsXHJcbiAgICAgIGxhYmVsOiBzZXJ2aWNlLmRlc2NyaWNhbz8uY2hhckF0KDApLmNvbmNhdChzZXJ2aWNlLmRlc2NyaWNhby5zbGljZSgxKS50b0xvY2FsZUxvd2VyQ2FzZSgpKSxcclxuICAgICAgc3R5bGU6IHsgZm9udFNpemU6IEZvbnRTaXplcy5zaXplMTYgfSxcclxuICAgICAgY2hpbGRyZW46IHNlcnZpY2UucmVncmFzLm1hcCgocGVybWlzc2lvbikgPT4gKHtcclxuICAgICAgICBrZXk6IGAke3NlcnZpY2Uuc2Vydmljb30uJHtwZXJtaXNzaW9uLnBlcm1pc3Nhb31gLFxyXG4gICAgICAgIGxhYmVsOiBwZXJtaXNzaW9uLnBlcm1pc3Nhby5jaGFyQXQoMCkuY29uY2F0KHBlcm1pc3Npb24ucGVybWlzc2FvLnNsaWNlKDEpLnRvTG9jYWxlTG93ZXJDYXNlKCkpLFxyXG4gICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiBGb250U2l6ZXMuc2l6ZTE0IH0sXHJcbiAgICAgIH0pKSxcclxuICAgIH0pKSxcclxuICB9KSlcclxufVxyXG5cclxuZnVuY3Rpb24gbWFrZVRyZWVTZWxlY3Rpb24gKHByb2ZpbGVQZXJtaXNzaW9uczogUGVybWlzc2lvbltdLCB0cmVlOiBUcmVlTm9kZVtdKTogVHJlZVNlbGVjdGlvbktleXNUeXBlIHtcclxuICBjb25zdCBwYXJlbnRzID0gZ2V0UGFyZW50cyh0cmVlKVxyXG4gIGNvbnN0IGNoaWxkcmVuUGVybWlzc2lvbiA9IGdldENoaWxkcmVuUGVybWlzc2lvbihwcm9maWxlUGVybWlzc2lvbnMpXHJcbiAgY29uc3QgcGFyZW50UGVybWlzc2lvbiA9IGdldFBhcmVudFBlcm1pc3Npb24oY2hpbGRyZW5QZXJtaXNzaW9uLCBwYXJlbnRzKVxyXG4gIHJldHVybiB7IC4uLnBhcmVudFBlcm1pc3Npb24sIC4uLmNoaWxkcmVuUGVybWlzc2lvbiB9IGFzIHVua25vd24gYXMgVHJlZVNlbGVjdGlvbktleXNUeXBlXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldENoaWxkcmVuUGVybWlzc2lvbiAocHJvZmlsZVBlcm1pc3Npb25zOiBQZXJtaXNzaW9uW10pIHtcclxuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzPFRyZWVTZWxlY3Rpb25JdGVtPihcclxuICAgIHByb2ZpbGVQZXJtaXNzaW9ucy5yZWR1Y2UoXHJcbiAgICAgIChwLCBjKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZW50cnk6IFRyZWVTZWxlY3Rpb25FbnRyeSA9IFtgJHtjLmNvZGlnb30uJHtjLnBlcm1pc3Nhb31gLCB7IGNoZWNrZWQ6IHRydWUgfV1cclxuICAgICAgICByZXR1cm4gWy4uLnAsIGVudHJ5XVxyXG4gICAgICB9LFxyXG4gICAgICBbXSBhcyBUcmVlU2VsZWN0aW9uRW50cnlbXSxcclxuICAgICkgPz8gW10sXHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRQYXJlbnRQZXJtaXNzaW9uIChjaGlsZHJlblBlcm1pc3Npb246IFRyZWVTZWxlY3Rpb24sIHBhcmVudHM6IFRyZWVOb2RlW10pIHtcclxuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzPFRyZWVTZWxlY3Rpb25JdGVtPihcclxuICAgIHBhcmVudHMucmVkdWNlKFxyXG4gICAgICAocCwgYykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNoaWxkcmVuUGVybWlzc2lvbktleSA9IE9iamVjdC5rZXlzKGNoaWxkcmVuUGVybWlzc2lvbikuZmlsdGVyKGtleSA9PiBrZXkuaW5jbHVkZXMoYy5rZXkgYXMgc3RyaW5nKSlcclxuICAgICAgICBpZiAoYy5jaGlsZHJlbj8ubGVuZ3RoID09PSBjaGlsZHJlblBlcm1pc3Npb25LZXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICBjb25zdCBlbnRyeTogVHJlZVNlbGVjdGlvbkVudHJ5ID0gW2Ake2Mua2V5fWAsIHsgY2hlY2tlZDogdHJ1ZSB9XVxyXG4gICAgICAgICAgcmV0dXJuIFsuLi5wLCBlbnRyeV1cclxuICAgICAgICB9IGVsc2UgaWYgKGNoaWxkcmVuUGVybWlzc2lvbktleS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgIHJldHVybiBbLi4ucF1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZW50cnk6IFRyZWVTZWxlY3Rpb25FbnRyeSA9IFtgJHtjLmtleX1gLCB7IHBhcnRpYWxDaGVja2VkOiB0cnVlIH1dXHJcbiAgICAgICAgcmV0dXJuIFsuLi5wLCBlbnRyeV1cclxuICAgICAgfSwgW10gYXMgVHJlZVNlbGVjdGlvbkVudHJ5W10sXHJcbiAgICApID8/IFtdLFxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0UGFyZW50cyAodHJlZTogVHJlZU5vZGVbXSkge1xyXG4gIGNvbnN0IHBhcmVudHMgPSB0cmVlLm1hcChub2RlID0+IG5vZGUuY2hpbGRyZW4pIGFzIFRyZWVOb2RlW11bXVxyXG4gIGxldCBuZXdQYXJlbnRzOiBUcmVlTm9kZVtdID0gW11cclxuICBmb3IgKGNvbnN0IHBhcmVudCBvZiBwYXJlbnRzKSB7XHJcbiAgICBuZXdQYXJlbnRzID0gWy4uLm5ld1BhcmVudHMsIC4uLnBhcmVudF1cclxuICB9XHJcbiAgcmV0dXJuIFsuLi5uZXdQYXJlbnRzXVxyXG59XHJcblxyXG5mdW5jdGlvbiBjb252ZXJ0U2VsZWN0aW9uVG9QZXJtaXNzaW9uIChwZXJtaXNzaW9uU2VsZWN0aW9uOiBUcmVlU2VsZWN0aW9uS2V5c1R5cGUpOiBQZXJtaXNzaW9uW10ge1xyXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhwZXJtaXNzaW9uU2VsZWN0aW9uKVxyXG4gICAgLmZpbHRlcigoW2tleSwgdmFsdWVdKSA9PiAoXHJcbiAgICAgIChrZXkubWF0Y2goL14uK1xcLi4rJC8pICYmICh2YWx1ZSBhcyB1bmtub3duIGFzIFRyZWVTZWxlY3Rpb24pLmNoZWNrZWQpIC8vIFRyZWVTZWxlY3Rpb25LZXlzVHlwZSBuw6NvIGNvbnTDqW0gYSBlc3RydXR1cmEgcmVhbCBkbyBvYmpldG9cclxuICAgICkpXHJcbiAgICAubWFwKChba2V5XSkgPT4ge1xyXG4gICAgICBjb25zdCBbc2VydmljZSwgcGVybWlzc2lvbl0gPSBrZXkuc3BsaXQoJy4nKVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGNvZGlnbzogc2VydmljZSxcclxuICAgICAgICBwZXJtaXNzYW86IHBlcm1pc3Npb24sXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVFZGl0Rm9ybVxyXG4iXX0=