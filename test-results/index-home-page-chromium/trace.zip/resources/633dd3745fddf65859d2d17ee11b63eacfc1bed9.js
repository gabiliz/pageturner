import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/ErrorScreen/ErrorScreen.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Image, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { ApiError, ForbiddenError } from "/src/shared/errors/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { PrimaryButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import NoPageFoundImg from "/src/shared/components/ErrorScreen/images/NoPage.svg?import";
import ErrorImg from "/src/shared/components/ErrorScreen/images/Error.svg?import";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
const messages = {
  generic: {
    title: "Ocorreu um erro",
    subtitle: "Houve algum problema ao executar a ação",
    icon: ErrorImg
  },
  notFound: {
    title: "Página não encontrada",
    subtitle: "Essa página não foi encontrada em nosso sistema",
    icon: NoPageFoundImg
  },
  forbidden: {
    title: "Ops! Sem permissão de acesso",
    subtitle: "Você não tem permissão para acessar esses dados",
    icon: ErrorImg
  },
  loggedIn: {
    title: "Você está logado no sistema",
    subtitle: "Por favor, faça logout e tente novamente",
    icon: ErrorImg
  },
  noForms: {
    title: "Não há formulários",
    subtitle: "Não existem mais formulários cadastrados",
    icon: ErrorImg
  }
};
const ErrorScreen = ({
  type,
  error
}) => {
  _s();
  const {
    spacing
  } = useTheme();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [icon, setIcon] = useState("");
  useEffect(() => {
    if (type) {
      setTitle(messages[type].title);
      setSubtitle(messages[type].subtitle);
      setIcon(messages[type].icon);
    } else if (error instanceof ForbiddenError) {
      setTitle(messages.forbidden.title);
      setSubtitle(messages.forbidden.subtitle);
      setIcon(messages.forbidden.icon);
    } else if (error instanceof ApiError) {
      setTitle(messages.generic.title);
      setSubtitle(error.title);
      setIcon(messages.generic.icon);
    } else {
      setTitle(messages.generic.title);
      setSubtitle(messages.generic.subtitle);
      setIcon(messages.generic.icon);
    }
  }, [type, error]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", verticalAlign: "center", gap: spacing.xxl, children: [
    /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", gap: spacing.lg, children: [
      /* @__PURE__ */ jsxDEV(Image, { src: icon }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { variant: "xxLarge", children: title }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: subtitle }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this),
    type !== "loggedIn" && /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Tentar novamente", onClick: () => navigate(0) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
      lineNumber: 79,
      columnNumber: 31
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx",
    lineNumber: 73,
    columnNumber: 10
  }, this);
};
_s(ErrorScreen, "bIsfZefesk43bw9KX7sGhlKpXUY=", false, function() {
  return [useTheme, useNavigate];
});
_c = ErrorScreen;
export default ErrorScreen;
var _c;
$RefreshReg$(_c, "ErrorScreen");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/ErrorScreen/ErrorScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZROzs7Ozs7Ozs7Ozs7Ozs7O0FBbEZSLFNBQVNBLE9BQU9DLFlBQVk7QUFDNUIsU0FBYUMsVUFBVUMsaUJBQWlCO0FBQ3hDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxVQUFVQyxzQkFBc0I7QUFDekMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHFCQUFxQjtBQUU5QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsV0FBVztBQUFBLEVBQ2ZDLFNBQVM7QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU1OO0FBQUFBLEVBQ1I7QUFBQSxFQUNBTyxVQUFVO0FBQUEsSUFDUkgsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxNQUFNUDtBQUFBQSxFQUNSO0FBQUEsRUFDQVMsV0FBVztBQUFBLElBQ1RKLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsTUFBTU47QUFBQUEsRUFDUjtBQUFBLEVBQ0FTLFVBQVU7QUFBQSxJQUNSTCxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU1OO0FBQUFBLEVBQ1I7QUFBQSxFQUNBVSxTQUFTO0FBQUEsSUFDUE4sT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxNQUFNTjtBQUFBQSxFQUNSO0FBQ0Y7QUFPQSxNQUFNVyxjQUFvQ0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQU0sTUFBTTtBQUFBQyxLQUFBO0FBQzdELFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFRLElBQUlsQixTQUFTO0FBQzdCLFFBQU1tQixXQUFXdEIsWUFBWTtBQUU3QixRQUFNLENBQUNVLE9BQU9hLFFBQVEsSUFBSXpCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNhLFVBQVVhLFdBQVcsSUFBSTFCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNjLE1BQU1hLE9BQU8sSUFBSTNCLFNBQVMsRUFBRTtBQUVuQ0MsWUFBVSxNQUFNO0FBQ2QsUUFBSW1CLE1BQU07QUFDUkssZUFBU2YsU0FBU1UsSUFBSSxFQUFFUixLQUFLO0FBQzdCYyxrQkFBWWhCLFNBQVNVLElBQUksRUFBRVAsUUFBUTtBQUNuQ2MsY0FBUWpCLFNBQVNVLElBQUksRUFBRU4sSUFBSTtBQUFBLElBQzdCLFdBQVdPLGlCQUFpQmpCLGdCQUFnQjtBQUMxQ3FCLGVBQVNmLFNBQVNNLFVBQVVKLEtBQUs7QUFDakNjLGtCQUFZaEIsU0FBU00sVUFBVUgsUUFBUTtBQUN2Q2MsY0FBUWpCLFNBQVNNLFVBQVVGLElBQUk7QUFBQSxJQUNqQyxXQUFXTyxpQkFBaUJsQixVQUFVO0FBQ3BDc0IsZUFBU2YsU0FBU0MsUUFBUUMsS0FBSztBQUMvQmMsa0JBQVlMLE1BQU1ULEtBQUs7QUFDdkJlLGNBQVFqQixTQUFTQyxRQUFRRyxJQUFJO0FBQUEsSUFDL0IsT0FBTztBQUNMVyxlQUFTZixTQUFTQyxRQUFRQyxLQUFLO0FBQy9CYyxrQkFBWWhCLFNBQVNDLFFBQVFFLFFBQVE7QUFDckNjLGNBQVFqQixTQUFTQyxRQUFRRyxJQUFJO0FBQUEsSUFDL0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sTUFBTUMsS0FBSyxDQUFDO0FBRWhCLFNBQ0UsdUJBQUMsY0FDQyxpQkFBZ0IsVUFDaEIsZUFBYyxVQUNkLEtBQUtFLFFBQVFLLEtBRWI7QUFBQSwyQkFBQyxjQUNDLGlCQUFnQixVQUNoQixLQUFLTCxRQUFRTSxJQUViO0FBQUEsNkJBQUMsU0FDQyxLQUFLZixRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFDWTtBQUFBLE1BRVosdUJBQUMsUUFBSyxTQUFRLFdBQVdGLG1CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDL0IsdUJBQUMsUUFBTUMsc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLFNBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0NPLFNBQVMsY0FBYyx1QkFBQyxpQkFDdkIsTUFBSyxvQkFDTCxTQUFTLE1BQU1JLFNBQVMsQ0FBQyxLQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFSztBQUFBLE9BakIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0YsR0FsREtILGFBQWlDO0FBQUEsVUFDakJkLFVBQ0hILFdBQVc7QUFBQTtBQUFBNEIsS0FGeEJYO0FBb0ROLGVBQWVBO0FBQVcsSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkltYWdlIiwiVGV4dCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTmF2aWdhdGUiLCJBcGlFcnJvciIsIkZvcmJpZGRlbkVycm9yIiwidXNlVGhlbWUiLCJQcmltYXJ5QnV0dG9uIiwiTm9QYWdlRm91bmRJbWciLCJFcnJvckltZyIsIkZsZXhDb2x1bW4iLCJtZXNzYWdlcyIsImdlbmVyaWMiLCJ0aXRsZSIsInN1YnRpdGxlIiwiaWNvbiIsIm5vdEZvdW5kIiwiZm9yYmlkZGVuIiwibG9nZ2VkSW4iLCJub0Zvcm1zIiwiRXJyb3JTY3JlZW4iLCJ0eXBlIiwiZXJyb3IiLCJfcyIsInNwYWNpbmciLCJuYXZpZ2F0ZSIsInNldFRpdGxlIiwic2V0U3VidGl0bGUiLCJzZXRJY29uIiwieHhsIiwibGciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVycm9yU2NyZWVuLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL0Vycm9yU2NyZWVuL0Vycm9yU2NyZWVuLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEltYWdlLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEFwaUVycm9yLCBGb3JiaWRkZW5FcnJvciB9IGZyb20gJy4uLy4uL2Vycm9ycydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5pbXBvcnQgeyBQcmltYXJ5QnV0dG9uIH0gZnJvbSAnLi4vYnV0dG9ucydcblxuaW1wb3J0IE5vUGFnZUZvdW5kSW1nIGZyb20gJy4vaW1hZ2VzL05vUGFnZS5zdmcnXG5pbXBvcnQgRXJyb3JJbWcgZnJvbSAnLi9pbWFnZXMvRXJyb3Iuc3ZnJ1xuaW1wb3J0IEZsZXhDb2x1bW4gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhDb2x1bW4nXG5cbmNvbnN0IG1lc3NhZ2VzID0ge1xuICBnZW5lcmljOiB7XG4gICAgdGl0bGU6ICdPY29ycmV1IHVtIGVycm8nLFxuICAgIHN1YnRpdGxlOiAnSG91dmUgYWxndW0gcHJvYmxlbWEgYW8gZXhlY3V0YXIgYSBhw6fDo28nLFxuICAgIGljb246IEVycm9ySW1nLFxuICB9LFxuICBub3RGb3VuZDoge1xuICAgIHRpdGxlOiAnUMOhZ2luYSBuw6NvIGVuY29udHJhZGEnLFxuICAgIHN1YnRpdGxlOiAnRXNzYSBww6FnaW5hIG7Do28gZm9pIGVuY29udHJhZGEgZW0gbm9zc28gc2lzdGVtYScsXG4gICAgaWNvbjogTm9QYWdlRm91bmRJbWcsXG4gIH0sXG4gIGZvcmJpZGRlbjoge1xuICAgIHRpdGxlOiAnT3BzISBTZW0gcGVybWlzc8OjbyBkZSBhY2Vzc28nLFxuICAgIHN1YnRpdGxlOiAnVm9jw6ogbsOjbyB0ZW0gcGVybWlzc8OjbyBwYXJhIGFjZXNzYXIgZXNzZXMgZGFkb3MnLFxuICAgIGljb246IEVycm9ySW1nLFxuICB9LFxuICBsb2dnZWRJbjoge1xuICAgIHRpdGxlOiAnVm9jw6ogZXN0w6EgbG9nYWRvIG5vIHNpc3RlbWEnLFxuICAgIHN1YnRpdGxlOiAnUG9yIGZhdm9yLCBmYcOnYSBsb2dvdXQgZSB0ZW50ZSBub3ZhbWVudGUnLFxuICAgIGljb246IEVycm9ySW1nLFxuICB9LFxuICBub0Zvcm1zOiB7XG4gICAgdGl0bGU6ICdOw6NvIGjDoSBmb3JtdWzDoXJpb3MnLFxuICAgIHN1YnRpdGxlOiAnTsOjbyBleGlzdGVtIG1haXMgZm9ybXVsw6FyaW9zIGNhZGFzdHJhZG9zJyxcbiAgICBpY29uOiBFcnJvckltZyxcbiAgfSxcbn1cblxudHlwZSBFcnJvclNjcmVlblByb3BzID0ge1xuICB0eXBlPzoga2V5b2YgdHlwZW9mIG1lc3NhZ2VzXG4gIGVycm9yPzogRXJyb3Jcbn1cblxuY29uc3QgRXJyb3JTY3JlZW46IEZDPEVycm9yU2NyZWVuUHJvcHM+ID0gKHsgdHlwZSwgZXJyb3IgfSkgPT4ge1xuICBjb25zdCB7IHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG5cbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3N1YnRpdGxlLCBzZXRTdWJ0aXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2ljb24sIHNldEljb25dID0gdXNlU3RhdGUoJycpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodHlwZSkge1xuICAgICAgc2V0VGl0bGUobWVzc2FnZXNbdHlwZV0udGl0bGUpXG4gICAgICBzZXRTdWJ0aXRsZShtZXNzYWdlc1t0eXBlXS5zdWJ0aXRsZSlcbiAgICAgIHNldEljb24obWVzc2FnZXNbdHlwZV0uaWNvbilcbiAgICB9IGVsc2UgaWYgKGVycm9yIGluc3RhbmNlb2YgRm9yYmlkZGVuRXJyb3IpIHtcbiAgICAgIHNldFRpdGxlKG1lc3NhZ2VzLmZvcmJpZGRlbi50aXRsZSlcbiAgICAgIHNldFN1YnRpdGxlKG1lc3NhZ2VzLmZvcmJpZGRlbi5zdWJ0aXRsZSlcbiAgICAgIHNldEljb24obWVzc2FnZXMuZm9yYmlkZGVuLmljb24pXG4gICAgfSBlbHNlIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yKSB7XG4gICAgICBzZXRUaXRsZShtZXNzYWdlcy5nZW5lcmljLnRpdGxlKVxuICAgICAgc2V0U3VidGl0bGUoZXJyb3IudGl0bGUpXG4gICAgICBzZXRJY29uKG1lc3NhZ2VzLmdlbmVyaWMuaWNvbilcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0VGl0bGUobWVzc2FnZXMuZ2VuZXJpYy50aXRsZSlcbiAgICAgIHNldFN1YnRpdGxlKG1lc3NhZ2VzLmdlbmVyaWMuc3VidGl0bGUpXG4gICAgICBzZXRJY29uKG1lc3NhZ2VzLmdlbmVyaWMuaWNvbilcbiAgICB9XG4gIH0sIFt0eXBlLCBlcnJvcl0pXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtblxuICAgICAgaG9yaXpvbnRhbEFsaWduPVwiY2VudGVyXCJcbiAgICAgIHZlcnRpY2FsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgZ2FwPXtzcGFjaW5nLnh4bH1cbiAgICA+XG4gICAgICA8RmxleENvbHVtblxuICAgICAgICBob3Jpem9udGFsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgICBnYXA9e3NwYWNpbmcubGd9XG4gICAgICA+XG4gICAgICAgIDxJbWFnZVxuICAgICAgICAgIHNyYz17aWNvbn1cbiAgICAgICAgLz5cbiAgICAgICAgPFRleHQgdmFyaWFudD1cInh4TGFyZ2VcIj57dGl0bGV9PC9UZXh0PlxuICAgICAgICA8VGV4dD57c3VidGl0bGV9PC9UZXh0PlxuICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAge3R5cGUgIT09ICdsb2dnZWRJbicgJiYgPFByaW1hcnlCdXR0b25cbiAgICAgICAgdGV4dD1cIlRlbnRhciBub3ZhbWVudGVcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgwKX1cbiAgICAgIC8+fVxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBFcnJvclNjcmVlblxuIl19