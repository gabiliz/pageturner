import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/providers/ReduxProvider.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/ReduxProvider.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { store } from "/src/shared/store/store.ts";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=9f90a7ff";
const ReduxProvider = (props) => {
  return /* @__PURE__ */ jsxDEV(Provider, { store, children: props.children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/ReduxProvider.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = ReduxProvider;
export default ReduxProvider;
var _c;
$RefreshReg$(_c, "ReduxProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/ReduxProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS1M7QUFMVCwyQkFBc0I7QUFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN0QyxTQUFTQSxnQkFBZ0I7QUFHekIsTUFBTUMsZ0JBQThEQyxXQUFVO0FBQzVFLFNBQU8sdUJBQUMsWUFBUyxPQUNkQSxnQkFBTUMsWUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRVA7QUFDRjtBQUFDQyxLQUpLSDtBQU1OLGVBQWVBO0FBQWEsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlByb3ZpZGVyIiwiUmVkdXhQcm92aWRlciIsInByb3BzIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlZHV4UHJvdmlkZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL3Byb3ZpZGVycy9SZWR1eFByb3ZpZGVyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHN0b3JlIH0gZnJvbSAnLi4vc3RvcmUvc3RvcmUnXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHsgRkMsIFByb3BzV2l0aENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IFJlZHV4UHJvdmlkZXI6IEZDPFByb3BzV2l0aENoaWxkcmVuPFJlY29yZDxuZXZlciwgbmV2ZXI+Pj4gPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxuICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgPC9Qcm92aWRlcj5cbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVkdXhQcm92aWRlclxuIl19