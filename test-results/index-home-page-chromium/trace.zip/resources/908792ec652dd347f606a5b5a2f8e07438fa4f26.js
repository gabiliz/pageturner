export var ControlsColumnNameEnum = /* @__PURE__ */ ((ControlsColumnNameEnum2) => {
  ControlsColumnNameEnum2["CONTROLS"] = "controls";
  ControlsColumnNameEnum2["DELETE"] = "delete";
  ControlsColumnNameEnum2["EDIT"] = "edit";
  return ControlsColumnNameEnum2;
})(ControlsColumnNameEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNvbnRyb2xzQ29sdW1uTmFtZUVudW0udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cbmV4cG9ydCBlbnVtIENvbnRyb2xzQ29sdW1uTmFtZUVudW0ge1xuICBDT05UUk9MUyA9ICdjb250cm9scycsXG4gIERFTEVURSA9ICdkZWxldGUnLFxuICBFRElUID0gJ2VkaXQnLFxufVxuIl0sIm1hcHBpbmdzIjoiQUFDTyxXQUFLLHlCQUFMLGtCQUFLQSw0QkFBTDtBQUNMLEVBQUFBLHdCQUFBLGNBQVc7QUFDWCxFQUFBQSx3QkFBQSxZQUFTO0FBQ1QsRUFBQUEsd0JBQUEsVUFBTztBQUhHLFNBQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6WyJDb250cm9sc0NvbHVtbk5hbWVFbnVtIl19