import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/clients/components/ClientCompanyTree.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { FontSizes, FontWeights, SearchBox, SharedColors } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { Tree } from "/node_modules/.vite/deps/primereact_tree.js?v=9f90a7ff";
import { isEqual } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { clientQueryService } from "/src/modules/admin/clients/services/index.ts";
import { formatCnpj } from "/src/shared/utils/index.ts";
import { LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
const ClientCompanyTree = (props) => {
  _s();
  const {
    selection,
    onSelect
  } = props;
  const [filter, setFilter] = useState();
  const filterData = useCallback((value) => {
    setFilter(value);
  }, [setFilter, filter]);
  const {
    data: clients,
    isLoading
  } = clientQueryService.useFindAllPaginated({
    $select: "id,nomeFantasia",
    $expand: "empresas($select=id,cnpj,razaoSocial)",
    $filter: filter ? `${`contains(nomeFantasia, '${filter}')`}` : void 0,
    $orderby: "nomeFantasia asc"
  });
  const [localSelection, setLocalSelection] = useState(
    convertToTreeSelection(selection, [])
    // sem esse convert inicial, entramos em loop infinito
  );
  const clientsTree = useMemo(() => makeTree(clients?.value ?? []), [clients]);
  const changeCompanySelection = useCallback((event) => {
    setLocalSelection(event.value);
  }, []);
  useEffect(() => {
    if (clients) {
      const incomingSelection = convertToTreeSelection(selection, clients.value);
      setLocalSelection((localSelection2) => {
        if (!isEqual(localSelection2, incomingSelection)) {
          return incomingSelection;
        }
        return localSelection2;
      });
    }
  }, [selection, clients]);
  useEffect(() => {
    const outgoingSelection = convertFromTreeSelection(localSelection);
    onSelect(outgoingSelection);
  }, [localSelection]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(SearchBox, { onChange: (_, val) => filterData(val) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    !isLoading && /* @__PURE__ */ jsxDEV(Tree, { value: clientsTree, selectionMode: "checkbox", selectionKeys: localSelection, onSelectionChange: changeCompanySelection }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx",
      lineNumber: 62,
      columnNumber: 22
    }, this),
    isLoading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx",
      lineNumber: 63,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx",
    lineNumber: 60,
    columnNumber: 10
  }, this);
};
_s(ClientCompanyTree, "s6mul0RAgg6ImYaLf6gAl+JbcdU=", false, function() {
  return [clientQueryService.useFindAllPaginated];
});
_c = ClientCompanyTree;
function makeTree(clients) {
  return clients.filter((client) => !!client.empresas?.length).map((client) => ({
    key: client.id,
    label: client.nomeFantasia,
    style: {
      fontSize: FontSizes.size14,
      fontWeight: FontWeights.semibold
    },
    selectable: !!client.empresas?.length,
    children: client.empresas?.map((company) => ({
      key: `${client.id}.${company.id}`,
      label: `${formatCnpj(company.cnpj)} - ${company.razaoSocial}`,
      style: {
        fontWeight: FontWeights.regular,
        color: SharedColors.gray30
      }
    }))
  }));
}
function convertFromTreeSelection(selection) {
  return Object.entries(selection).filter(([key, value]) => key.includes(".") && value.checked).map(([key]) => {
    const [clientId, companyId] = key.split(".");
    return {
      clienteId: clientId,
      empresaId: companyId
    };
  });
}
function convertToTreeSelection(selection, clients) {
  const companiesCount = selection.reduce((p, c) => {
    return {
      ...p,
      [c.clienteId]: (p[c.clienteId] ?? 0) + 1
    };
  }, {});
  return Object.fromEntries(selection.reduce((p, c) => {
    const client = clients.find(({
      id
    }) => id === c.clienteId);
    const clientEntry = [c.clienteId, {
      checked: companiesCount[c.clienteId] === (client?.empresas?.length ?? 0),
      partialChecked: companiesCount[c.clienteId] > 0 && companiesCount[c.clienteId] < (client?.empresas?.length ?? 0)
    }];
    const companyEntry = [`${c.clienteId}.${c.empresaId}`, {
      checked: true
    }];
    return [...p, clientEntry, companyEntry];
  }, []));
}
export default ClientCompanyTree;
var _c;
$RefreshReg$(_c, "ClientCompanyTree");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/clients/components/ClientCompanyTree.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUVJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuRUosU0FBYUEsVUFBVUMsYUFBYUMsU0FBU0MsaUJBQWlCO0FBQzlELFNBQVNDLFdBQVdDLGFBQWFDLFdBQVdDLG9CQUFvQjtBQUNoRSxTQUFTQyxZQUF3RDtBQUNqRSxTQUFTQyxlQUFlO0FBRXhCLFNBQVNDLDBCQUEwQjtBQUduQyxTQUFTQyxrQkFBa0I7QUFFM0IsU0FBU0MscUJBQXFCO0FBUzlCLE1BQU1DLG9CQUFpREMsV0FBVTtBQUFBQyxLQUFBO0FBQy9ELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFXQztBQUFBQSxFQUFTLElBQUlIO0FBQ2hDLFFBQU0sQ0FBQ0ksUUFBUUMsU0FBUyxJQUFJbkIsU0FBaUI7QUFDN0MsUUFBTW9CLGFBQWFuQixZQUFZLENBQUNvQixVQUF3QjtBQUN0REYsY0FBVUUsS0FBSztBQUFBLEVBQ2pCLEdBQUcsQ0FBQ0YsV0FBV0QsTUFBTSxDQUFDO0FBRXRCLFFBQU07QUFBQSxJQUFFSSxNQUFNQztBQUFBQSxJQUFTQztBQUFBQSxFQUFVLElBQUlkLG1CQUFtQmUsb0JBQW9CO0FBQUEsSUFDMUVDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsSUFDVEMsU0FBU1YsU0FBVSxHQUFHLDJCQUEwQkEsZUFBZVc7QUFBQUEsSUFDL0RDLFVBQVU7QUFBQSxFQUNaLENBQWdCO0FBRWhCLFFBQU0sQ0FDSkMsZ0JBQ0FDLGlCQUFpQixJQUNmaEM7QUFBQUEsSUFDRmlDLHVCQUF1QmpCLFdBQVcsRUFBRTtBQUFBO0FBQUEsRUFDdEM7QUFFQSxRQUFNa0IsY0FBY2hDLFFBQ2xCLE1BQU1pQyxTQUFTWixTQUFTRixTQUFTLEVBQUUsR0FDbkMsQ0FBQ0UsT0FBTyxDQUNWO0FBRUEsUUFBTWEseUJBQXlCbkMsWUFBWSxDQUFDb0MsVUFBK0I7QUFDekVMLHNCQUFrQkssTUFBTWhCLEtBQUs7QUFBQSxFQUMvQixHQUFHLEVBQUU7QUFFTGxCLFlBQVUsTUFBTTtBQUNkLFFBQUlvQixTQUFTO0FBQ1gsWUFBTWUsb0JBQW9CTCx1QkFBdUJqQixXQUFXTyxRQUFRRixLQUFLO0FBQ3pFVyx3QkFBa0JELHFCQUFrQjtBQUNsQyxZQUFJLENBQUN0QixRQUFRc0IsaUJBQWdCTyxpQkFBaUIsR0FBRztBQUMvQyxpQkFBT0E7QUFBQUEsUUFDVDtBQUNBLGVBQU9QO0FBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ2YsV0FBV08sT0FBTyxDQUFDO0FBRXZCcEIsWUFBVSxNQUFNO0FBQ2QsVUFBTW9DLG9CQUFvQkMseUJBQXlCVCxjQUFjO0FBQ2pFZCxhQUFTc0IsaUJBQWlCO0FBQUEsRUFDNUIsR0FBRyxDQUFDUixjQUFjLENBQUM7QUFFbkIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLGFBQVUsVUFBVSxDQUFDVSxHQUFHQyxRQUFRdEIsV0FBV3NCLEdBQWEsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRDtBQUFBLElBQzFELENBQUNsQixhQUFhLHVCQUFDLFFBQ2QsT0FBT1UsYUFDUCxlQUFjLFlBQ2QsZUFBZUgsZ0JBQ2YsbUJBQW1CSywwQkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSTZCO0FBQUEsSUFFM0NaLGFBQWEsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsT0FSOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUo7QUFBQ1QsR0EzREtGLG1CQUE2QztBQUFBLFVBT1pILG1CQUFtQmUsbUJBQW1CO0FBQUE7QUFBQWtCLEtBUHZFOUI7QUE2RE4sU0FBU3NCLFNBQVVaLFNBQStCO0FBQ2hELFNBQU9BLFFBQ0pMLE9BQVEwQixZQUFXLENBQUMsQ0FBQ0EsT0FBT0MsVUFBVUMsTUFBTSxFQUM1Q0MsSUFBS0gsYUFBWTtBQUFBLElBQ2hCSSxLQUFLSixPQUFPSztBQUFBQSxJQUNaQyxPQUFPTixPQUFPTztBQUFBQSxJQUNkQyxPQUFPO0FBQUEsTUFDTEMsVUFBVWpELFVBQVVrRDtBQUFBQSxNQUNwQkMsWUFBWWxELFlBQVltRDtBQUFBQSxJQUMxQjtBQUFBLElBQ0FDLFlBQVksQ0FBQyxDQUFDYixPQUFPQyxVQUFVQztBQUFBQSxJQUMvQlksVUFBVWQsT0FBT0MsVUFBVUUsSUFBS1ksY0FBYTtBQUFBLE1BQzNDWCxLQUFNLEdBQUVKLE9BQU9LLE1BQU1VLFFBQVFWO0FBQUFBLE1BQzdCQyxPQUFRLEdBQUV2QyxXQUFXZ0QsUUFBUUMsSUFBSSxPQUFPRCxRQUFRRTtBQUFBQSxNQUNoRFQsT0FBTztBQUFBLFFBQ0xHLFlBQVlsRCxZQUFZeUQ7QUFBQUEsUUFDeEJDLE9BQU94RCxhQUFheUQ7QUFBQUEsTUFDdEI7QUFBQSxJQUNGLEVBQUU7QUFBQSxFQUNKLEVBQUU7QUFDTjtBQUVBLFNBQVN4Qix5QkFBMEJ4QixXQUErRDtBQUNoRyxTQUFPaUQsT0FDSkMsUUFBUWxELFNBQVMsRUFDakJFLE9BQU8sQ0FBQyxDQUFDOEIsS0FBSzNCLEtBQUssTUFDbEIyQixJQUFJbUIsU0FBUyxHQUFHLEtBQU05QyxNQUFtQytDLE9BQzFELEVBQUVyQixJQUFJLENBQUMsQ0FBQ0MsR0FBRyxNQUFNO0FBQ2hCLFVBQU0sQ0FBQ3FCLFVBQVVDLFNBQVMsSUFBSXRCLElBQUl1QixNQUFNLEdBQUc7QUFDM0MsV0FBTztBQUFBLE1BQ0xDLFdBQVdIO0FBQUFBLE1BQ1hJLFdBQVdIO0FBQUFBLElBQ2I7QUFBQSxFQUNGLENBQUM7QUFDTDtBQUVBLFNBQVNyQyx1QkFDUGpCLFdBQ0FPLFNBQ3VCO0FBQ3ZCLFFBQU1tRCxpQkFBaUIxRCxVQUFVMkQsT0FDL0IsQ0FBQ0MsR0FBR0MsTUFBTTtBQUNSLFdBQU87QUFBQSxNQUNMLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQ0MsRUFBRUwsU0FBUyxJQUFJSSxFQUFFQyxFQUFFTCxTQUFTLEtBQUssS0FBSztBQUFBLElBQ3pDO0FBQUEsRUFDRixHQUNBLENBQUMsQ0FDSDtBQUVBLFNBQU9QLE9BQU9hLFlBQ1o5RCxVQUFVMkQsT0FDUixDQUFDQyxHQUFHQyxNQUFNO0FBQ1IsVUFBTWpDLFNBQVNyQixRQUFRd0QsS0FBSyxDQUFDO0FBQUEsTUFBRTlCO0FBQUFBLElBQUcsTUFBTUEsT0FBTzRCLEVBQUVMLFNBQVM7QUFDMUQsVUFBTVEsY0FBa0MsQ0FDdENILEVBQUVMLFdBQ0Y7QUFBQSxNQUNFSixTQUFTTSxlQUFlRyxFQUFFTCxTQUFTLE9BQU81QixRQUFRQyxVQUFVQyxVQUFVO0FBQUEsTUFDdEVtQyxnQkFBZ0JQLGVBQWVHLEVBQUVMLFNBQVMsSUFBSSxLQUMzQ0UsZUFBZUcsRUFBRUwsU0FBUyxLQUFLNUIsUUFBUUMsVUFBVUMsVUFBVTtBQUFBLElBQ2hFLENBQUM7QUFFSCxVQUFNb0MsZUFBbUMsQ0FDdEMsR0FBRUwsRUFBRUwsYUFBYUssRUFBRUosYUFDcEI7QUFBQSxNQUFFTCxTQUFTO0FBQUEsSUFBSyxDQUFDO0FBRW5CLFdBQU8sQ0FBQyxHQUFHUSxHQUFHSSxhQUFhRSxZQUFZO0FBQUEsRUFDekMsR0FDQSxFQUNGLENBQ0Y7QUFDRjtBQUVBLGVBQWVyRTtBQUFpQixJQUFBOEI7QUFBQXdDLGFBQUF4QyxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsInVzZU1lbW8iLCJ1c2VFZmZlY3QiLCJGb250U2l6ZXMiLCJGb250V2VpZ2h0cyIsIlNlYXJjaEJveCIsIlNoYXJlZENvbG9ycyIsIlRyZWUiLCJpc0VxdWFsIiwiY2xpZW50UXVlcnlTZXJ2aWNlIiwiZm9ybWF0Q25waiIsIkxvYWRpbmdTY3JlZW4iLCJDbGllbnRDb21wYW55VHJlZSIsInByb3BzIiwiX3MiLCJzZWxlY3Rpb24iLCJvblNlbGVjdCIsImZpbHRlciIsInNldEZpbHRlciIsImZpbHRlckRhdGEiLCJ2YWx1ZSIsImRhdGEiLCJjbGllbnRzIiwiaXNMb2FkaW5nIiwidXNlRmluZEFsbFBhZ2luYXRlZCIsIiRzZWxlY3QiLCIkZXhwYW5kIiwiJGZpbHRlciIsInVuZGVmaW5lZCIsIiRvcmRlcmJ5IiwibG9jYWxTZWxlY3Rpb24iLCJzZXRMb2NhbFNlbGVjdGlvbiIsImNvbnZlcnRUb1RyZWVTZWxlY3Rpb24iLCJjbGllbnRzVHJlZSIsIm1ha2VUcmVlIiwiY2hhbmdlQ29tcGFueVNlbGVjdGlvbiIsImV2ZW50IiwiaW5jb21pbmdTZWxlY3Rpb24iLCJvdXRnb2luZ1NlbGVjdGlvbiIsImNvbnZlcnRGcm9tVHJlZVNlbGVjdGlvbiIsIl8iLCJ2YWwiLCJfYyIsImNsaWVudCIsImVtcHJlc2FzIiwibGVuZ3RoIiwibWFwIiwia2V5IiwiaWQiLCJsYWJlbCIsIm5vbWVGYW50YXNpYSIsInN0eWxlIiwiZm9udFNpemUiLCJzaXplMTQiLCJmb250V2VpZ2h0Iiwic2VtaWJvbGQiLCJzZWxlY3RhYmxlIiwiY2hpbGRyZW4iLCJjb21wYW55IiwiY25waiIsInJhemFvU29jaWFsIiwicmVndWxhciIsImNvbG9yIiwiZ3JheTMwIiwiT2JqZWN0IiwiZW50cmllcyIsImluY2x1ZGVzIiwiY2hlY2tlZCIsImNsaWVudElkIiwiY29tcGFueUlkIiwic3BsaXQiLCJjbGllbnRlSWQiLCJlbXByZXNhSWQiLCJjb21wYW5pZXNDb3VudCIsInJlZHVjZSIsInAiLCJjIiwiZnJvbUVudHJpZXMiLCJmaW5kIiwiY2xpZW50RW50cnkiLCJwYXJ0aWFsQ2hlY2tlZCIsImNvbXBhbnlFbnRyeSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNsaWVudENvbXBhbnlUcmVlLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY2xpZW50cy9jb21wb25lbnRzL0NsaWVudENvbXBhbnlUcmVlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBGb250U2l6ZXMsIEZvbnRXZWlnaHRzLCBTZWFyY2hCb3gsIFNoYXJlZENvbG9ycyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgVHJlZSwgVHJlZVNlbGVjdGlvblBhcmFtcywgVHJlZVNlbGVjdGlvbktleXNUeXBlIH0gZnJvbSAncHJpbWVyZWFjdC90cmVlJ1xyXG5pbXBvcnQgeyBpc0VxdWFsIH0gZnJvbSAnbG9kYXNoLWVzJ1xyXG5pbXBvcnQgeyBDbGllbnRDb21wYW55UmVsYXRpb25zaGlwIH0gZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXJDbGllbnRDb21wYW55J1xyXG5pbXBvcnQgeyBjbGllbnRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuaW1wb3J0IHsgT0RhdGFQYXJhbXMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdHlwZXMvT0RhdGFQYXJhbXMnXHJcbmltcG9ydCBDbGllbnQgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL0NsaWVudCdcclxuaW1wb3J0IHsgZm9ybWF0Q25waiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgVHJlZVNlbGVjdGlvbiwgVHJlZVNlbGVjdGlvbkVudHJ5LCBUcmVlU2VsZWN0aW9uSXRlbSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC90eXBlcy9QcmltZWZhY2VzVHJlZSdcclxuaW1wb3J0IHsgTG9hZGluZ1NjcmVlbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLXVucmVzb2x2ZWRcclxuaW1wb3J0IFRyZWVOb2RlIGZyb20gJ3ByaW1lcmVhY3QvdHJlZW5vZGUvdHJlZW5vZGUnXHJcblxyXG5pbnRlcmZhY2UgQ2xpZW50Q29tcGFueVRyZWVQcm9wcyB7XHJcbiAgc2VsZWN0aW9uOiBDbGllbnRDb21wYW55UmVsYXRpb25zaGlwW11cclxuICBvblNlbGVjdDogKHNlbGVjdGlvbjogQ2xpZW50Q29tcGFueVJlbGF0aW9uc2hpcFtdKSA9PiB2b2lkXHJcbn1cclxuXHJcbmNvbnN0IENsaWVudENvbXBhbnlUcmVlOiBGQzxDbGllbnRDb21wYW55VHJlZVByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgc2VsZWN0aW9uLCBvblNlbGVjdCB9ID0gcHJvcHNcclxuICBjb25zdCBbZmlsdGVyLCBzZXRGaWx0ZXJdID0gdXNlU3RhdGU8c3RyaW5nPigpXHJcbiAgY29uc3QgZmlsdGVyRGF0YSA9IHVzZUNhbGxiYWNrKCh2YWx1ZTogc3RyaW5nKTogdm9pZCA9PiB7XHJcbiAgICBzZXRGaWx0ZXIodmFsdWUpXHJcbiAgfSwgW3NldEZpbHRlciwgZmlsdGVyXSlcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBjbGllbnRzLCBpc0xvYWRpbmcgfSA9IGNsaWVudFF1ZXJ5U2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKHtcclxuICAgICRzZWxlY3Q6ICdpZCxub21lRmFudGFzaWEnLFxyXG4gICAgJGV4cGFuZDogJ2VtcHJlc2FzKCRzZWxlY3Q9aWQsY25waixyYXphb1NvY2lhbCknLFxyXG4gICAgJGZpbHRlcjogZmlsdGVyID8gYCR7YGNvbnRhaW5zKG5vbWVGYW50YXNpYSwgJyR7ZmlsdGVyfScpYH1gIDogdW5kZWZpbmVkLFxyXG4gICAgJG9yZGVyYnk6ICdub21lRmFudGFzaWEgYXNjJyxcclxuICB9IGFzIE9EYXRhUGFyYW1zKVxyXG5cclxuICBjb25zdCBbXHJcbiAgICBsb2NhbFNlbGVjdGlvbixcclxuICAgIHNldExvY2FsU2VsZWN0aW9uLFxyXG4gIF0gPSB1c2VTdGF0ZTxUcmVlU2VsZWN0aW9uS2V5c1R5cGU+KFxyXG4gICAgY29udmVydFRvVHJlZVNlbGVjdGlvbihzZWxlY3Rpb24sIFtdKSwgLy8gc2VtIGVzc2UgY29udmVydCBpbmljaWFsLCBlbnRyYW1vcyBlbSBsb29wIGluZmluaXRvXHJcbiAgKVxyXG5cclxuICBjb25zdCBjbGllbnRzVHJlZSA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PiBtYWtlVHJlZShjbGllbnRzPy52YWx1ZSA/PyBbXSksXHJcbiAgICBbY2xpZW50c10sXHJcbiAgKVxyXG5cclxuICBjb25zdCBjaGFuZ2VDb21wYW55U2VsZWN0aW9uID0gdXNlQ2FsbGJhY2soKGV2ZW50OiBUcmVlU2VsZWN0aW9uUGFyYW1zKSA9PiB7XHJcbiAgICBzZXRMb2NhbFNlbGVjdGlvbihldmVudC52YWx1ZSlcclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChjbGllbnRzKSB7XHJcbiAgICAgIGNvbnN0IGluY29taW5nU2VsZWN0aW9uID0gY29udmVydFRvVHJlZVNlbGVjdGlvbihzZWxlY3Rpb24sIGNsaWVudHMudmFsdWUpXHJcbiAgICAgIHNldExvY2FsU2VsZWN0aW9uKGxvY2FsU2VsZWN0aW9uID0+IHtcclxuICAgICAgICBpZiAoIWlzRXF1YWwobG9jYWxTZWxlY3Rpb24sIGluY29taW5nU2VsZWN0aW9uKSkge1xyXG4gICAgICAgICAgcmV0dXJuIGluY29taW5nU2VsZWN0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBsb2NhbFNlbGVjdGlvblxyXG4gICAgICB9KVxyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3Rpb24sIGNsaWVudHNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3Qgb3V0Z29pbmdTZWxlY3Rpb24gPSBjb252ZXJ0RnJvbVRyZWVTZWxlY3Rpb24obG9jYWxTZWxlY3Rpb24pXHJcbiAgICBvblNlbGVjdChvdXRnb2luZ1NlbGVjdGlvbilcclxuICB9LCBbbG9jYWxTZWxlY3Rpb25dKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFNlYXJjaEJveCBvbkNoYW5nZT17KF8sIHZhbCkgPT4gZmlsdGVyRGF0YSh2YWwgYXMgc3RyaW5nKX0vPlxyXG4gICAgICB7IWlzTG9hZGluZyAmJiA8VHJlZVxyXG4gICAgICAgIHZhbHVlPXtjbGllbnRzVHJlZX1cclxuICAgICAgICBzZWxlY3Rpb25Nb2RlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgIHNlbGVjdGlvbktleXM9e2xvY2FsU2VsZWN0aW9ufVxyXG4gICAgICAgIG9uU2VsZWN0aW9uQ2hhbmdlPXtjaGFuZ2VDb21wYW55U2VsZWN0aW9ufVxyXG4gICAgICAvPn1cclxuICAgICAge2lzTG9hZGluZyAmJiA8TG9hZGluZ1NjcmVlbiAvPn1cclxuICAgIDwvPlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gbWFrZVRyZWUgKGNsaWVudHM6IENsaWVudFtdKTogVHJlZU5vZGVbXSB7XHJcbiAgcmV0dXJuIGNsaWVudHNcclxuICAgIC5maWx0ZXIoKGNsaWVudCkgPT4gISFjbGllbnQuZW1wcmVzYXM/Lmxlbmd0aClcclxuICAgIC5tYXAoKGNsaWVudCkgPT4gKHtcclxuICAgICAga2V5OiBjbGllbnQuaWQsXHJcbiAgICAgIGxhYmVsOiBjbGllbnQubm9tZUZhbnRhc2lhLFxyXG4gICAgICBzdHlsZToge1xyXG4gICAgICAgIGZvbnRTaXplOiBGb250U2l6ZXMuc2l6ZTE0LFxyXG4gICAgICAgIGZvbnRXZWlnaHQ6IEZvbnRXZWlnaHRzLnNlbWlib2xkLFxyXG4gICAgICB9LFxyXG4gICAgICBzZWxlY3RhYmxlOiAhIWNsaWVudC5lbXByZXNhcz8ubGVuZ3RoLFxyXG4gICAgICBjaGlsZHJlbjogY2xpZW50LmVtcHJlc2FzPy5tYXAoKGNvbXBhbnkpID0+ICh7XHJcbiAgICAgICAga2V5OiBgJHtjbGllbnQuaWR9LiR7Y29tcGFueS5pZH1gLFxyXG4gICAgICAgIGxhYmVsOiBgJHtmb3JtYXRDbnBqKGNvbXBhbnkuY25wail9IC0gJHtjb21wYW55LnJhemFvU29jaWFsfWAsXHJcbiAgICAgICAgc3R5bGU6IHtcclxuICAgICAgICAgIGZvbnRXZWlnaHQ6IEZvbnRXZWlnaHRzLnJlZ3VsYXIsXHJcbiAgICAgICAgICBjb2xvcjogU2hhcmVkQ29sb3JzLmdyYXkzMCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSksXHJcbiAgICB9KSlcclxufVxyXG5cclxuZnVuY3Rpb24gY29udmVydEZyb21UcmVlU2VsZWN0aW9uIChzZWxlY3Rpb246IFRyZWVTZWxlY3Rpb25LZXlzVHlwZSk6IENsaWVudENvbXBhbnlSZWxhdGlvbnNoaXBbXSB7XHJcbiAgcmV0dXJuIE9iamVjdFxyXG4gICAgLmVudHJpZXMoc2VsZWN0aW9uKVxyXG4gICAgLmZpbHRlcigoW2tleSwgdmFsdWVdKSA9PiAoXHJcbiAgICAgIGtleS5pbmNsdWRlcygnLicpICYmICh2YWx1ZSBhcyB1bmtub3duIGFzIFRyZWVTZWxlY3Rpb24pLmNoZWNrZWRcclxuICAgICkpLm1hcCgoW2tleV0pID0+IHtcclxuICAgICAgY29uc3QgW2NsaWVudElkLCBjb21wYW55SWRdID0ga2V5LnNwbGl0KCcuJylcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBjbGllbnRlSWQ6IGNsaWVudElkLFxyXG4gICAgICAgIGVtcHJlc2FJZDogY29tcGFueUlkLFxyXG4gICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5mdW5jdGlvbiBjb252ZXJ0VG9UcmVlU2VsZWN0aW9uIChcclxuICBzZWxlY3Rpb246IENsaWVudENvbXBhbnlSZWxhdGlvbnNoaXBbXSxcclxuICBjbGllbnRzOiBDbGllbnRbXSxcclxuKTogVHJlZVNlbGVjdGlvbktleXNUeXBlIHtcclxuICBjb25zdCBjb21wYW5pZXNDb3VudCA9IHNlbGVjdGlvbi5yZWR1Y2UoXHJcbiAgICAocCwgYykgPT4ge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnAsXHJcbiAgICAgICAgW2MuY2xpZW50ZUlkXTogKHBbYy5jbGllbnRlSWRdID8/IDApICsgMSxcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHt9IGFzIHtbY2xpZW50SWQ6IHN0cmluZ106IG51bWJlcn0sXHJcbiAgKVxyXG5cclxuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzPFRyZWVTZWxlY3Rpb25JdGVtPihcclxuICAgIHNlbGVjdGlvbi5yZWR1Y2UoXHJcbiAgICAgIChwLCBjKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY2xpZW50cy5maW5kKCh7IGlkIH0pID0+IGlkID09PSBjLmNsaWVudGVJZClcclxuICAgICAgICBjb25zdCBjbGllbnRFbnRyeTogVHJlZVNlbGVjdGlvbkVudHJ5ID0gW1xyXG4gICAgICAgICAgYy5jbGllbnRlSWQsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGNoZWNrZWQ6IGNvbXBhbmllc0NvdW50W2MuY2xpZW50ZUlkXSA9PT0gKGNsaWVudD8uZW1wcmVzYXM/Lmxlbmd0aCA/PyAwKSxcclxuICAgICAgICAgICAgcGFydGlhbENoZWNrZWQ6IGNvbXBhbmllc0NvdW50W2MuY2xpZW50ZUlkXSA+IDAgJiZcclxuICAgICAgICAgICAgICAoY29tcGFuaWVzQ291bnRbYy5jbGllbnRlSWRdIDwgKGNsaWVudD8uZW1wcmVzYXM/Lmxlbmd0aCA/PyAwKSksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF1cclxuICAgICAgICBjb25zdCBjb21wYW55RW50cnk6IFRyZWVTZWxlY3Rpb25FbnRyeSA9IFtcclxuICAgICAgICAgIGAke2MuY2xpZW50ZUlkfS4ke2MuZW1wcmVzYUlkfWAsXHJcbiAgICAgICAgICB7IGNoZWNrZWQ6IHRydWUgfSxcclxuICAgICAgICBdXHJcbiAgICAgICAgcmV0dXJuIFsuLi5wLCBjbGllbnRFbnRyeSwgY29tcGFueUVudHJ5XVxyXG4gICAgICB9LFxyXG4gICAgICBbXSBhcyBUcmVlU2VsZWN0aW9uRW50cnlbXSxcclxuICAgICksXHJcbiAgKSBhcyB1bmtub3duIGFzIFRyZWVTZWxlY3Rpb25LZXlzVHlwZVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDbGllbnRDb21wYW55VHJlZVxyXG4iXX0=