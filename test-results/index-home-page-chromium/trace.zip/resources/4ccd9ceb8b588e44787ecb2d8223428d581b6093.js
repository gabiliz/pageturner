export var CompanySizeEnum = /* @__PURE__ */ ((CompanySizeEnum2) => {
  CompanySizeEnum2[CompanySizeEnum2["GRANDE"] = 0] = "GRANDE";
  CompanySizeEnum2[CompanySizeEnum2["PEQUENO"] = 1] = "PEQUENO";
  return CompanySizeEnum2;
})(CompanySizeEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNvbXBhbnlTaXplRW51bS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xuZXhwb3J0IGVudW0gQ29tcGFueVNpemVFbnVtIHtcbiAgR1JBTkRFLFxuICBQRVFVRU5PLFxufVxuIl0sIm1hcHBpbmdzIjoiQUFDTyxXQUFLLGtCQUFMLGtCQUFLQSxxQkFBTDtBQUNMLEVBQUFBLGtDQUFBO0FBQ0EsRUFBQUEsa0NBQUE7QUFGVSxTQUFBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiQ29tcGFueVNpemVFbnVtIl19