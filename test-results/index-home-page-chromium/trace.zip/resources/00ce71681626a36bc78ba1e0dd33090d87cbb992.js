import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditHistoryModal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_dateFns_format_index_js from "/node_modules/.vite/deps/date-fns_format_index__js.js?v=9f90a7ff"; const format = __vite__cjsImport4_dateFns_format_index_js.__esModule ? __vite__cjsImport4_dateFns_format_index_js.default : __vite__cjsImport4_dateFns_format_index_js;
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { DataTable, LoadingScreen, Modal, PrimaryButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { UserName } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { auditHistoryService as service } from "/src/modules/audit/audits/services/index.ts";
const AuditHistoryModal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    auditId
  } = props;
  const [history, setHistory] = useState();
  const styles = useStyles();
  useEffect(() => {
    service.findHistory(auditId).then((res) => setHistory(res));
  }, [auditId]);
  return /* @__PURE__ */ jsxDEV(Modal, { isOpen, onDismiss, title: "Histórico", width: 1e3, children: [
    history && /* @__PURE__ */ jsxDEV(DataTable, { columns, items: history ?? [], hasSelection: false, sortConfig: {
      field: "dataHora",
      descending: false
    }, paginated: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
      lineNumber: 27,
      columnNumber: 19
    }, this),
    !history && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
      lineNumber: 31,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actionStyles.actions, children: /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Fechar", onClick: () => onDismiss() }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
      lineNumber: 33,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(AuditHistoryModal, "BgtGM+k+kF3PWcQ/Azl0Fq/bsIY=", false, function() {
  return [useStyles];
});
_c = AuditHistoryModal;
const useStyles = () => {
  _s2();
  const {
    spacing
  } = useTheme();
  const actionStyles = mergeStyleSets({
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 40,
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
  return {
    actionStyles
  };
};
_s2(useStyles, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
const columns = [{
  header: "Log",
  field: "descricao",
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Justificativa da situação",
  field: "justificativaSituacao",
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Data",
  field: "dataHora",
  format: (item) => {
    if (item?.dataHora) {
      return format(new Date(item?.dataHora), "dd/MM/yyyy HH:mm");
    }
  },
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Usuário",
  field: "usuarioId",
  format: (item) => {
    return item.usuarioId ? /* @__PURE__ */ jsxDEV(UserName, { id: item.usuarioId }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx",
      lineNumber: 101,
      columnNumber: 29
    }, this) : "";
  },
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string"
}];
export default AuditHistoryModal;
var _c;
$RefreshReg$(_c, "AuditHistoryModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditHistoryModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NrQjs7Ozs7Ozs7Ozs7Ozs7OztBQXRDbEIsU0FBU0Esc0JBQXNCO0FBQy9CLE9BQU9DLFlBQVk7QUFDbkIsU0FBYUMsV0FBV0MsZ0JBQWdCO0FBRXhDLFNBQVNDLFdBQTRCQyxlQUFlQyxPQUFtQkMscUJBQXFCO0FBQzVGLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FDRUMsdUJBQXVCQyxlQUNsQjtBQU1QLE1BQU1DLG9CQUFpREMsV0FBVTtBQUFBQyxLQUFBO0FBQy9ELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlKO0FBRUosUUFBTSxDQUFDSyxTQUFTQyxVQUFVLElBQUloQixTQUE4QjtBQUM1RCxRQUFNaUIsU0FBU0MsVUFBVTtBQUV6Qm5CLFlBQVUsTUFBTTtBQUNkUyxZQUFRVyxZQUFZTCxPQUFPLEVBQ3hCTSxLQUFLQyxTQUFPTCxXQUFXSyxHQUFHLENBQzNCO0FBQUEsRUFDSixHQUFHLENBQUNQLE9BQU8sQ0FBQztBQUVaLFNBQ0UsdUJBQUMsU0FDQyxRQUNBLFdBQ0EsT0FBTSxhQUNOLE9BQU8sS0FFTkM7QUFBQUEsZUFBVyx1QkFBQyxhQUNYLFNBQ0EsT0FBT0EsV0FBVyxJQUNsQixjQUFjLE9BQ2QsWUFBWTtBQUFBLE1BQ1ZPLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsSUFDZCxHQUNBLFdBQVMsUUFSQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUQ7QUFBQSxJQUVWLENBQUNSLFdBQVcsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFDM0IsdUJBQUMsU0FBSSxXQUFXRSxPQUFPTyxhQUFhQyxTQUNsQyxpQ0FBQyxpQkFDQyxNQUFLLFVBQ0wsU0FBUyxNQUFNWixVQUFVLEtBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFNkIsS0FIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsT0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUVKO0FBQUNGLEdBMUNLRixtQkFBNkM7QUFBQSxVQVFsQ1MsU0FBUztBQUFBO0FBQUFRLEtBUnBCakI7QUE0Q04sTUFBTVMsWUFBWUEsTUFBTTtBQUFBUyxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFRLElBQUl2QixTQUFTO0FBRTdCLFFBQU1tQixlQUFlM0IsZUFBZTtBQUFBLElBQ2xDNEIsU0FBUztBQUFBLE1BQ1BJLFNBQVM7QUFBQSxNQUNUQyxnQkFBZ0I7QUFBQSxNQUNoQkMsV0FBVztBQUFBLE1BQ1hDLFdBQVc7QUFBQSxRQUNULHlCQUF5QjtBQUFBLFVBQ3ZCQyxhQUFhTCxRQUFRTTtBQUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBTztBQUFBLElBQ0xWO0FBQUFBLEVBQ0Y7QUFDRjtBQUFDRyxJQW5CS1QsV0FBUztBQUFBLFVBQ09iLFFBQVE7QUFBQTtBQW9COUIsTUFBTThCLFVBQTJDLENBQy9DO0FBQUEsRUFDRUMsUUFBUTtBQUFBLEVBQ1JkLE9BQU87QUFBQSxFQUNQZSxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05DLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUwsUUFBUTtBQUFBLEVBQ1JkLE9BQU87QUFBQSxFQUNQZSxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05DLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUwsUUFBUTtBQUFBLEVBQ1JkLE9BQU87QUFBQSxFQUNQeEIsUUFBUUEsQ0FBQzRDLFNBQXVCO0FBQzlCLFFBQUlBLE1BQU1DLFVBQVU7QUFDbEIsYUFBTzdDLE9BQU8sSUFBSThDLEtBQUtGLE1BQU1DLFFBQVEsR0FBRyxrQkFBa0I7QUFBQSxJQUM1RDtBQUFBLEVBQ0Y7QUFBQSxFQUNBTixlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05DLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUwsUUFBUTtBQUFBLEVBQ1JkLE9BQU87QUFBQSxFQUNQeEIsUUFBUzRDLFVBQVM7QUFDaEIsV0FBT0EsS0FBS0csWUFBWSx1QkFBQyxZQUFTLElBQUlILEtBQUtHLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkIsSUFBSztBQUFBLEVBQzVEO0FBQUEsRUFDQVIsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFDUixDQUFDO0FBSUgsZUFBZS9CO0FBQWlCLElBQUFpQjtBQUFBb0IsYUFBQXBCLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsImZvcm1hdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiRGF0YVRhYmxlIiwiTG9hZGluZ1NjcmVlbiIsIk1vZGFsIiwiUHJpbWFyeUJ1dHRvbiIsInVzZVRoZW1lIiwiVXNlck5hbWUiLCJhdWRpdEhpc3RvcnlTZXJ2aWNlIiwic2VydmljZSIsIkF1ZGl0SGlzdG9yeU1vZGFsIiwicHJvcHMiLCJfcyIsImlzT3BlbiIsIm9uRGlzbWlzcyIsImF1ZGl0SWQiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsInN0eWxlcyIsInVzZVN0eWxlcyIsImZpbmRIaXN0b3J5IiwidGhlbiIsInJlcyIsImZpZWxkIiwiZGVzY2VuZGluZyIsImFjdGlvblN0eWxlcyIsImFjdGlvbnMiLCJfYyIsIl9zMiIsInNwYWNpbmciLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Ub3AiLCJzZWxlY3RvcnMiLCJtYXJnaW5SaWdodCIsImxnIiwiY29sdW1ucyIsImhlYWRlciIsImZpbHRlck9wdGlvbnMiLCJxdWVyeVR5cGUiLCJxdWVyeU1vZGUiLCJ0eXBlIiwic29ydGFibGUiLCJpdGVtIiwiZGF0YUhvcmEiLCJEYXRlIiwidXN1YXJpb0lkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXVkaXRIaXN0b3J5TW9kYWwudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cy9BdWRpdEhpc3RvcnlNb2RhbC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IGZvcm1hdCBmcm9tICdkYXRlLWZucy9mb3JtYXQvaW5kZXguanMnXHJcbmltcG9ydCB7IEZDLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEF1ZGl0SGlzdG9yeSB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9BdWRpdCdcclxuaW1wb3J0IHsgRGF0YVRhYmxlLCBEYXRhVGFibGVDb2x1bW4sIExvYWRpbmdTY3JlZW4sIE1vZGFsLCBNb2RhbFByb3BzLCBQcmltYXJ5QnV0dG9uIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBVc2VyTmFtZSB9IGZyb20gJy4uLy4uLy4uL2FkbWluL3VzZXJzL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7XHJcbiAgYXVkaXRIaXN0b3J5U2VydmljZSBhcyBzZXJ2aWNlLFxyXG59IGZyb20gJy4uL3NlcnZpY2VzJ1xyXG5cclxuaW50ZXJmYWNlIEF1ZGl0SGlzdG9yeU1vZGFsUHJvcHMgZXh0ZW5kcyBNb2RhbFByb3Bze1xyXG4gIGF1ZGl0SWQ6IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBBdWRpdEhpc3RvcnlNb2RhbDogRkM8QXVkaXRIaXN0b3J5TW9kYWxQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBpc09wZW4sXHJcbiAgICBvbkRpc21pc3MsXHJcbiAgICBhdWRpdElkLFxyXG4gIH0gPSBwcm9wc1xyXG5cclxuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZTxBdWRpdEhpc3RvcnlbXXxudWxsPigpXHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlcnZpY2UuZmluZEhpc3RvcnkoYXVkaXRJZClcclxuICAgICAgLnRoZW4ocmVzID0+IHNldEhpc3RvcnkocmVzKSxcclxuICAgICAgKVxyXG4gIH0sIFthdWRpdElkXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNb2RhbFxyXG4gICAgICBpc09wZW49e2lzT3Blbn1cclxuICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XHJcbiAgICAgIHRpdGxlPSdIaXN0w7NyaWNvJ1xyXG4gICAgICB3aWR0aD17MTAwMH1cclxuICAgID5cclxuICAgICAge2hpc3RvcnkgJiYgPERhdGFUYWJsZVxyXG4gICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgaXRlbXM9e2hpc3RvcnkgPz8gW119XHJcbiAgICAgICAgaGFzU2VsZWN0aW9uPXtmYWxzZX1cclxuICAgICAgICBzb3J0Q29uZmlnPXt7XHJcbiAgICAgICAgICBmaWVsZDogJ2RhdGFIb3JhJyxcclxuICAgICAgICAgIGRlc2NlbmRpbmc6IGZhbHNlLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgcGFnaW5hdGVkXHJcbiAgICAgIC8+fVxyXG4gICAgICB7IWhpc3RvcnkgJiYgPExvYWRpbmdTY3JlZW4gLz59XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYWN0aW9uU3R5bGVzLmFjdGlvbnN9PlxyXG4gICAgICAgIDxQcmltYXJ5QnV0dG9uXHJcbiAgICAgICAgICB0ZXh0PVwiRmVjaGFyXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGlzbWlzcygpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB7IHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgY29uc3QgYWN0aW9uU3R5bGVzID0gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgYWN0aW9uczoge1xyXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnLFxyXG4gICAgICBtYXJnaW5Ub3A6IDQwLFxyXG4gICAgICBzZWxlY3RvcnM6IHtcclxuICAgICAgICAnJiA+IDpub3QoOmxhc3QtY2hpbGQpJzoge1xyXG4gICAgICAgICAgbWFyZ2luUmlnaHQ6IHNwYWNpbmcubGcsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGFjdGlvblN0eWxlcyxcclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IGNvbHVtbnM6IERhdGFUYWJsZUNvbHVtbjxBdWRpdEhpc3Rvcnk+W10gPSBbXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnTG9nJyxcclxuICAgIGZpZWxkOiAnZGVzY3JpY2FvJyxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGhlYWRlcjogJ0p1c3RpZmljYXRpdmEgZGEgc2l0dWHDp8OjbycsXHJcbiAgICBmaWVsZDogJ2p1c3RpZmljYXRpdmFTaXR1YWNhbycsXHJcbiAgICBmaWx0ZXJPcHRpb25zOiB7XHJcbiAgICAgIHF1ZXJ5VHlwZTogJ3N0cmluZycsXHJcbiAgICAgIHF1ZXJ5TW9kZTogJ2RlZmF1bHQnLFxyXG4gICAgfSxcclxuICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdEYXRhJyxcclxuICAgIGZpZWxkOiAnZGF0YUhvcmEnLFxyXG4gICAgZm9ybWF0OiAoaXRlbTogQXVkaXRIaXN0b3J5KSA9PiB7XHJcbiAgICAgIGlmIChpdGVtPy5kYXRhSG9yYSkge1xyXG4gICAgICAgIHJldHVybiBmb3JtYXQobmV3IERhdGUoaXRlbT8uZGF0YUhvcmEpLCAnZGQvTU0veXl5eSBISDptbScpXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBmaWx0ZXJPcHRpb25zOiB7XHJcbiAgICAgIHF1ZXJ5VHlwZTogJ3N0cmluZycsXHJcbiAgICAgIHF1ZXJ5TW9kZTogJ2RlZmF1bHQnLFxyXG4gICAgfSxcclxuICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdVc3XDoXJpbycsXHJcbiAgICBmaWVsZDogJ3VzdWFyaW9JZCcsXHJcbiAgICBmb3JtYXQ6IChpdGVtKSA9PiB7XHJcbiAgICAgIHJldHVybiBpdGVtLnVzdWFyaW9JZCA/IDxVc2VyTmFtZSBpZD17aXRlbS51c3VhcmlvSWR9Lz4gOiAnJ1xyXG4gICAgfSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgfSxcclxuXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1ZGl0SGlzdG9yeU1vZGFsXHJcbiJdfQ==