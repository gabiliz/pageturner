import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/PrimaryButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/PrimaryButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { PrimaryButton as FluentPrimaryButton, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import SpinningButton from "/src/shared/components/buttons/SpinningButton.tsx?t=1701096626433";
const PrimaryButton = ({
  isLoading,
  isLargeSize = false,
  ...props
}) => {
  _s();
  const styles = useStyles(isLargeSize);
  if (isLoading)
    return /* @__PURE__ */ jsxDEV(SpinningButton, { disabled: true, styles: {
      root: {
        marginTop: 0
      }
    }, ...props }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/PrimaryButton.tsx",
      lineNumber: 18,
      columnNumber: 25
    }, this);
  return /* @__PURE__ */ jsxDEV(FluentPrimaryButton, { className: styles.primaryButton, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/PrimaryButton.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(PrimaryButton, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = PrimaryButton;
const useStyles = (isLargeSize) => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = mergeStyleSets({
    primaryButton: {
      backgroundColor: colors.purple[600],
      border: "none",
      borderRadius: 2,
      height: 32,
      fontSize: 14,
      fontWeight: 600,
      lineHeight: 20,
      padding: isLargeSize ? "0 20px" : void 0,
      transition: "background-color .1s, border-color .1s",
      "&:hover": {
        backgroundColor: colors.purple[500],
        border: "none"
      },
      "&:hover .is-disabled": {
        backgroundColor: colors.purple[800],
        border: "none"
      },
      "&:active": {
        backgroundColor: colors.purple[800],
        border: "none"
      },
      "&.is-disabled": {
        opacity: 0.5,
        border: "none"
      }
    }
  });
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default PrimaryButton;
var _c;
$RefreshReg$(_c, "PrimaryButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/PrimaryButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYXdCOzs7Ozs7Ozs7Ozs7Ozs7O0FBWnhCLFNBQVNBLGlCQUFpQkMscUJBQW1DQyxzQkFBc0I7QUFDbkYsU0FBU0Msc0JBQXNCO0FBQy9CLE9BQU9DLG9CQUFvQjtBQU8zQixNQUFNSixnQkFBeUNBLENBQUM7QUFBQSxFQUFFSztBQUFBQSxFQUFXQyxjQUFjO0FBQUEsRUFBTyxHQUFHQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUMvRixRQUFNQyxTQUFTQyxVQUFVSixXQUFXO0FBRXBDLE1BQUlEO0FBQVcsV0FBTyx1QkFBQyxrQkFBZSxVQUFVLE1BQU0sUUFBUTtBQUFBLE1BQUVNLE1BQU07QUFBQSxRQUFFQyxXQUFXO0FBQUEsTUFBRTtBQUFBLElBQUUsR0FBRyxHQUFLTCxTQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdGO0FBRXRHLFNBQ0UsdUJBQUMsdUJBQ0MsV0FBV0UsT0FBT0ksZUFDbEIsR0FBSU4sU0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRVk7QUFHaEI7QUFBQ0MsR0FYS1IsZUFBc0M7QUFBQSxVQUMzQlUsU0FBUztBQUFBO0FBQUFJLEtBRHBCZDtBQWFOLE1BQU1VLFlBQVlBLENBQUNKLGdCQUF5QjtBQUFBUyxNQUFBO0FBQzFDLFFBQU1DLFNBQVNiLGVBQWU7QUFDOUIsUUFBTWMsZUFBZWYsZUFBZTtBQUFBLElBQ2xDVyxlQUFlO0FBQUEsTUFDYkssaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsUUFBUTtBQUFBLE1BQ1JDLGNBQWM7QUFBQSxNQUNkQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsU0FBU3BCLGNBQWMsV0FBV3FCO0FBQUFBLE1BQ2xDQyxZQUFZO0FBQUEsTUFDWixXQUFXO0FBQUEsUUFDVFYsaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUNsQ0MsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxNQUNBLHdCQUF3QjtBQUFBLFFBQ3RCRixpQkFBaUJGLE9BQU9HLE9BQU8sR0FBRztBQUFBLFFBQ2xDQyxRQUFRO0FBQUEsTUFDVjtBQUFBLE1BQ0EsWUFBWTtBQUFBLFFBQ1ZGLGlCQUFpQkYsT0FBT0csT0FBTyxHQUFHO0FBQUEsUUFDbENDLFFBQVE7QUFBQSxNQUNWO0FBQUEsTUFDQSxpQkFBaUI7QUFBQSxRQUNmUyxTQUFTO0FBQUEsUUFDVFQsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBT0g7QUFDVDtBQUFDRixJQWpDS0wsV0FBUztBQUFBLFVBQ0VQLGNBQWM7QUFBQTtBQWtDL0IsZUFBZUg7QUFBYSxJQUFBYztBQUFBZ0IsYUFBQWhCLElBQUEiLCJuYW1lcyI6WyJQcmltYXJ5QnV0dG9uIiwiRmx1ZW50UHJpbWFyeUJ1dHRvbiIsIm1lcmdlU3R5bGVTZXRzIiwidXNlVGhlbWVDb2xvcnMiLCJTcGlubmluZ0J1dHRvbiIsImlzTG9hZGluZyIsImlzTGFyZ2VTaXplIiwicHJvcHMiLCJfcyIsInN0eWxlcyIsInVzZVN0eWxlcyIsInJvb3QiLCJtYXJnaW5Ub3AiLCJwcmltYXJ5QnV0dG9uIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJhY3Rpb25TdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJoZWlnaHQiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJsaW5lSGVpZ2h0IiwicGFkZGluZyIsInVuZGVmaW5lZCIsInRyYW5zaXRpb24iLCJvcGFjaXR5IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJpbWFyeUJ1dHRvbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9idXR0b25zL1ByaW1hcnlCdXR0b24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFByaW1hcnlCdXR0b24gYXMgRmx1ZW50UHJpbWFyeUJ1dHRvbiwgSUJ1dHRvblByb3BzLCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lQ29sb3JzIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5pbXBvcnQgU3Bpbm5pbmdCdXR0b24gZnJvbSAnLi9TcGlubmluZ0J1dHRvbidcblxuaW50ZXJmYWNlIElQcmltYXJ5QnV0dG9uUHJvcHMgZXh0ZW5kcyBJQnV0dG9uUHJvcHMge1xuICBpc0xhcmdlU2l6ZT86IGJvb2xlYW5cbiAgaXNMb2FkaW5nPzogYm9vbGVhblxufVxuXG5jb25zdCBQcmltYXJ5QnV0dG9uOiBGQzxJUHJpbWFyeUJ1dHRvblByb3BzPiA9ICh7IGlzTG9hZGluZywgaXNMYXJnZVNpemUgPSBmYWxzZSwgLi4ucHJvcHMgfSkgPT4ge1xuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoaXNMYXJnZVNpemUpXG5cbiAgaWYgKGlzTG9hZGluZykgcmV0dXJuIDxTcGlubmluZ0J1dHRvbiBkaXNhYmxlZD17dHJ1ZX0gc3R5bGVzPXt7IHJvb3Q6IHsgbWFyZ2luVG9wOiAwIH0gfX0geyAuLi5wcm9wcyB9IC8+XG5cbiAgcmV0dXJuIChcbiAgICA8Rmx1ZW50UHJpbWFyeUJ1dHRvblxuICAgICAgY2xhc3NOYW1lPXtzdHlsZXMucHJpbWFyeUJ1dHRvbn1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmNvbnN0IHVzZVN0eWxlcyA9IChpc0xhcmdlU2l6ZTogYm9vbGVhbikgPT4ge1xuICBjb25zdCBjb2xvcnMgPSB1c2VUaGVtZUNvbG9ycygpXG4gIGNvbnN0IGFjdGlvblN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcbiAgICBwcmltYXJ5QnV0dG9uOiB7XG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5wdXJwbGVbNjAwXSxcbiAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgYm9yZGVyUmFkaXVzOiAyLFxuICAgICAgaGVpZ2h0OiAzMixcbiAgICAgIGZvbnRTaXplOiAxNCxcbiAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcbiAgICAgIGxpbmVIZWlnaHQ6IDIwLFxuICAgICAgcGFkZGluZzogaXNMYXJnZVNpemUgPyAnMCAyMHB4JyA6IHVuZGVmaW5lZCxcbiAgICAgIHRyYW5zaXRpb246ICdiYWNrZ3JvdW5kLWNvbG9yIC4xcywgYm9yZGVyLWNvbG9yIC4xcycsXG4gICAgICAnJjpob3Zlcic6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgfSxcbiAgICAgICcmOmhvdmVyIC5pcy1kaXNhYmxlZCc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgfSxcbiAgICAgICcmOmFjdGl2ZSc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgfSxcbiAgICAgICcmLmlzLWRpc2FibGVkJzoge1xuICAgICAgICBvcGFjaXR5OiAwLjUsXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxuXG4gIHJldHVybiBhY3Rpb25TdHlsZXNcbn1cblxuZXhwb3J0IGRlZmF1bHQgUHJpbWFyeUJ1dHRvblxuIl19