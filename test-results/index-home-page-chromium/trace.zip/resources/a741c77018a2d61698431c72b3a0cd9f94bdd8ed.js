import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/FlexBox/FlexItem.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const FlexItem = (props) => {
  const {
    children,
    width,
    height,
    grow,
    margin,
    padding,
    shrink,
    basis = "auto",
    order,
    gap,
    columnGap,
    rowGap,
    marginRight,
    styles,
    className
  } = props;
  return /* @__PURE__ */ jsxDEV("div", { style: {
    width,
    height,
    margin,
    marginRight,
    padding,
    flexGrow: grow,
    flexShrink: shrink,
    flexBasis: basis,
    order,
    gap,
    columnGap: columnGap || gap,
    rowGap: rowGap || gap,
    ...styles
  }, className, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexItem.tsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
};
_c = FlexItem;
export default FlexItem;
var _c;
$RefreshReg$(_c, "FlexItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENJO0FBMUNKLDJCQUEwQjtBQUFtQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVCcEQsTUFBTUEsV0FBK0JDLFdBQVU7QUFDN0MsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFFBQVE7QUFBQSxJQUNSQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlmO0FBQ0osU0FDRSx1QkFBQyxTQUNDLE9BQU87QUFBQSxJQUNMRTtBQUFBQSxJQUNBQztBQUFBQSxJQUNBRTtBQUFBQSxJQUNBUTtBQUFBQSxJQUNBUDtBQUFBQSxJQUNBVSxVQUFVWjtBQUFBQSxJQUNWYSxZQUFZVjtBQUFBQSxJQUNaVyxXQUFXVjtBQUFBQSxJQUNYQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxXQUFXQSxhQUFhRDtBQUFBQSxJQUN4QkUsUUFBUUEsVUFBVUY7QUFBQUEsSUFDbEIsR0FBR0k7QUFBQUEsRUFDTCxHQUNBLFdBRUNiLFlBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFDa0IsS0F4Q0twQjtBQTBDTixlQUFlQTtBQUFRLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRmxleEl0ZW0iLCJwcm9wcyIsImNoaWxkcmVuIiwid2lkdGgiLCJoZWlnaHQiLCJncm93IiwibWFyZ2luIiwicGFkZGluZyIsInNocmluayIsImJhc2lzIiwib3JkZXIiLCJnYXAiLCJjb2x1bW5HYXAiLCJyb3dHYXAiLCJtYXJnaW5SaWdodCIsInN0eWxlcyIsImNsYXNzTmFtZSIsImZsZXhHcm93IiwiZmxleFNocmluayIsImZsZXhCYXNpcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmxleEl0ZW0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRmxleEJveC9GbGV4SXRlbS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDU1NQcm9wZXJ0aWVzLCBGQywgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIFNldEZsZXggPSAnaW5oZXJpdCcgfCAnaW5pdGlhbCcgfCAncmV2ZXJ0JyB8ICd1bnNldCdcclxudHlwZSBPcmRlclR5cGUgPSAnaW5oZXJpdCcgfCAnaW5pdGlhbCcgfCAncmV2ZXJ0JyB8ICd1bnNldCdcclxudHlwZSBCYXNpc1R5cGUgPSAnYXV0bycgfCAnbWF4LWNvbnRlbnQnIHwgJ21pbi1jb250ZW50JyB8ICdmaXQtY29udGVudCcgfCAnY29udGVudCcgfCBPcmRlclR5cGVcclxuaW50ZXJmYWNlIElGbGV4SXRlbVByb3BzIHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlXHJcbiAgd2lkdGg/OiBudW1iZXIgfCBzdHJpbmdcclxuICBoZWlnaHQ/OiBudW1iZXIgfCBzdHJpbmdcclxuICBncm93PzogbnVtYmVyIHwgU2V0RmxleFxyXG4gIHNocmluaz86IG51bWJlciB8IFNldEZsZXhcclxuICBtYXJnaW4/OiBudW1iZXIgfCBzdHJpbmdcclxuICBwYWRkaW5nPzogbnVtYmVyIHwgc3RyaW5nXHJcbiAgYmFzaXM/OiBudW1iZXIgfCBCYXNpc1R5cGVcclxuICBvcmRlcj86IG51bWJlciB8IE9yZGVyVHlwZVxyXG4gIGdhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIGNvbHVtbkdhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIHJvd0dhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIG1hcmdpblJpZ2h0PzogbnVtYmVyIHwgc3RyaW5nXHJcbiAgc3R5bGVzPzogQ1NTUHJvcGVydGllc1xyXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBGbGV4SXRlbTpGQzxJRmxleEl0ZW1Qcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBjaGlsZHJlbixcclxuICAgIHdpZHRoLFxyXG4gICAgaGVpZ2h0LFxyXG4gICAgZ3JvdyxcclxuICAgIG1hcmdpbixcclxuICAgIHBhZGRpbmcsXHJcbiAgICBzaHJpbmssXHJcbiAgICBiYXNpcyA9ICdhdXRvJyxcclxuICAgIG9yZGVyLFxyXG4gICAgZ2FwLFxyXG4gICAgY29sdW1uR2FwLFxyXG4gICAgcm93R2FwLFxyXG4gICAgbWFyZ2luUmlnaHQsXHJcbiAgICBzdHlsZXMsXHJcbiAgICBjbGFzc05hbWUsXHJcbiAgfSA9IHByb3BzXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgc3R5bGU9e3tcclxuICAgICAgICB3aWR0aDogd2lkdGgsXHJcbiAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXHJcbiAgICAgICAgbWFyZ2luOiBtYXJnaW4sXHJcbiAgICAgICAgbWFyZ2luUmlnaHQ6IG1hcmdpblJpZ2h0LFxyXG4gICAgICAgIHBhZGRpbmc6IHBhZGRpbmcsXHJcbiAgICAgICAgZmxleEdyb3c6IGdyb3csXHJcbiAgICAgICAgZmxleFNocmluazogc2hyaW5rLFxyXG4gICAgICAgIGZsZXhCYXNpczogYmFzaXMsXHJcbiAgICAgICAgb3JkZXI6IG9yZGVyLFxyXG4gICAgICAgIGdhcDogZ2FwLFxyXG4gICAgICAgIGNvbHVtbkdhcDogY29sdW1uR2FwIHx8IGdhcCxcclxuICAgICAgICByb3dHYXA6IHJvd0dhcCB8fCBnYXAsXHJcbiAgICAgICAgLi4uc3R5bGVzLFxyXG4gICAgICB9fVxyXG4gICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGbGV4SXRlbVxyXG4iXX0=