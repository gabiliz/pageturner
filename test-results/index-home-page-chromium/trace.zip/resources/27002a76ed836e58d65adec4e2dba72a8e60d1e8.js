import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTableFilterGroups.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableFilterGroups.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { FilterGroup } from "/src/shared/components/filter/index.ts?t=1701096626433";
function DataTableFilterGroups({
  columns,
  onQueryChange
}) {
  _s();
  const columnsFilterGroups = useMemo(() => {
    const columnsWithFilterGroups = columns.filter((column) => column.filterOptions?.queryMode === "searchableDropdown" || column.filterOptions?.queryMode === "text");
    const formattedColumnsFilterGroups = columnsWithFilterGroups.map(({
      filterOptions,
      ...column
    }) => {
      const columnField = column.field.toString();
      const queryMode = filterOptions?.queryMode === "default" ? "text" : filterOptions?.queryMode;
      const queryType = filterOptions?.queryType || "none";
      const items = filterOptions?.items || [];
      const filterGroup = {
        field: columnField,
        filterGroupName: column.header,
        isOr: filterOptions?.isOr,
        items,
        replace: filterOptions?.replace,
        color: filterOptions?.groupColor,
        onChangeItems: filterOptions?.groupItemsChange
      };
      filterGroup.queryType = queryType;
      switch (filterGroup.queryType) {
        case "record":
          filterGroup.field = columnField;
          filterGroup.record = filterOptions?.record;
          break;
        default:
          filterGroup.field = columnField;
      }
      filterGroup.queryMode = queryMode;
      if (filterGroup.queryMode === "searchableDropdown") {
        filterGroup.dropdownOptions = filterOptions?.groupDropdownOptions;
      }
      return filterGroup;
    });
    return formattedColumnsFilterGroups;
  }, [columns]);
  return /* @__PURE__ */ jsxDEV(FilterGroup, { groups: columnsFilterGroups, onFilterQueryChange: onQueryChange }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableFilterGroups.tsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
}
_s(DataTableFilterGroups, "xOV9B5tYzgg9iS5tipLCk4lkHSI=");
_c = DataTableFilterGroups;
export default DataTableFilterGroups;
var _c;
$RefreshReg$(_c, "DataTableFilterGroups");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableFilterGroups.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRJOzs7Ozs7Ozs7Ozs7Ozs7O0FBM0RKLFNBQXVCQSxlQUFlO0FBRXRDLFNBQVNDLG1CQUFtQjtBQVM1QixTQUFTQyxzQkFBeUM7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUE2QyxHQUFpQjtBQUFBQyxLQUFBO0FBQ3pILFFBQU1DLHNCQUFzQ04sUUFBUSxNQUFNO0FBQ3hELFVBQU1PLDBCQUEwQkosUUFDN0JLLE9BQU9DLFlBQ05BLE9BQU9DLGVBQWVDLGNBQWMsd0JBQ3BDRixPQUFPQyxlQUFlQyxjQUFjLE1BQ3RDO0FBRUYsVUFBTUMsK0JBQStDTCx3QkFBd0JNLElBQUksQ0FBQztBQUFBLE1BQUVIO0FBQUFBLE1BQWUsR0FBR0Q7QUFBQUEsSUFBTyxNQUFNO0FBQ2pILFlBQU1LLGNBQWNMLE9BQU9NLE1BQU1DLFNBQVM7QUFDMUMsWUFBTUwsWUFBWUQsZUFBZUMsY0FBYyxZQUFZLFNBQVNELGVBQWVDO0FBQ25GLFlBQU1NLFlBQVlQLGVBQWVPLGFBQWE7QUFDOUMsWUFBTUMsUUFBUVIsZUFBZVEsU0FBUztBQUV0QyxZQUFNQyxjQUFxQztBQUFBLFFBQ3pDSixPQUFPRDtBQUFBQSxRQUNQTSxpQkFBaUJYLE9BQU9ZO0FBQUFBLFFBQ3hCQyxNQUFNWixlQUFlWTtBQUFBQSxRQUNyQko7QUFBQUEsUUFDQUssU0FBU2IsZUFBZWE7QUFBQUEsUUFDeEJDLE9BQU9kLGVBQWVlO0FBQUFBLFFBQ3RCQyxlQUFlaEIsZUFBZWlCO0FBQUFBLE1BQ2hDO0FBRUFSLGtCQUFZRixZQUFZQTtBQUV4QixjQUFRRSxZQUFZRixXQUFTO0FBQUEsUUFDM0IsS0FBSztBQUNIRSxzQkFBWUosUUFBUUQ7QUFDcEJLLHNCQUFZUyxTQUFTbEIsZUFBZWtCO0FBQ3BDO0FBQUEsUUFDRjtBQUNFVCxzQkFBWUosUUFBUUQ7QUFBQUEsTUFDeEI7QUFFQUssa0JBQVlSLFlBQVlBO0FBRXhCLFVBQUlRLFlBQVlSLGNBQWMsc0JBQXNCO0FBQ2xEUSxvQkFBWVUsa0JBQWtCbkIsZUFBZW9CO0FBQUFBLE1BQy9DO0FBRUEsYUFBT1g7QUFBQUEsSUFDVCxDQUFDO0FBRUQsV0FBT1A7QUFBQUEsRUFDVCxHQUFHLENBQUNULE9BQU8sQ0FBQztBQUVaLFNBQ0UsdUJBQUMsZUFDQyxRQUFRRyxxQkFDUixxQkFBcUJGLGlCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRXFDO0FBR3pDO0FBQUNDLEdBckRRSCx1QkFBcUI7QUFBQTZCLEtBQXJCN0I7QUF1RFQsZUFBZUE7QUFBcUIsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwiRmlsdGVyR3JvdXAiLCJEYXRhVGFibGVGaWx0ZXJHcm91cHMiLCJjb2x1bW5zIiwib25RdWVyeUNoYW5nZSIsIl9zIiwiY29sdW1uc0ZpbHRlckdyb3VwcyIsImNvbHVtbnNXaXRoRmlsdGVyR3JvdXBzIiwiZmlsdGVyIiwiY29sdW1uIiwiZmlsdGVyT3B0aW9ucyIsInF1ZXJ5TW9kZSIsImZvcm1hdHRlZENvbHVtbnNGaWx0ZXJHcm91cHMiLCJtYXAiLCJjb2x1bW5GaWVsZCIsImZpZWxkIiwidG9TdHJpbmciLCJxdWVyeVR5cGUiLCJpdGVtcyIsImZpbHRlckdyb3VwIiwiZmlsdGVyR3JvdXBOYW1lIiwiaGVhZGVyIiwiaXNPciIsInJlcGxhY2UiLCJjb2xvciIsImdyb3VwQ29sb3IiLCJvbkNoYW5nZUl0ZW1zIiwiZ3JvdXBJdGVtc0NoYW5nZSIsInJlY29yZCIsImRyb3Bkb3duT3B0aW9ucyIsImdyb3VwRHJvcGRvd25PcHRpb25zIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGVGaWx0ZXJHcm91cHMudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZGF0YXRhYmxlL0RhdGFUYWJsZUZpbHRlckdyb3Vwcy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSZWFjdEVsZW1lbnQsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEVudGl0eSBmcm9tICcuLi8uLi8uLi9kb21haW4vRW50aXR5J1xyXG5pbXBvcnQgeyBGaWx0ZXJHcm91cCB9IGZyb20gJy4uL2ZpbHRlcidcclxuaW1wb3J0IHsgSUZpbHRlckdyb3VwIH0gZnJvbSAnLi4vZmlsdGVyL3R5cGVzJ1xyXG5pbXBvcnQgeyBEYXRhVGFibGVDb2x1bW4gfSBmcm9tICcuL3R5cGVzJ1xyXG5cclxuaW50ZXJmYWNlIERhdGFUYWJsZUZpbHRlckdyb3Vwc1Byb3BzPFQgZXh0ZW5kcyBFbnRpdHk+IHtcclxuICBjb2x1bW5zOiBEYXRhVGFibGVDb2x1bW48VD5bXSxcclxuICBvblF1ZXJ5Q2hhbmdlOiAoZmlsdGVyR3JvdXBzOiBJRmlsdGVyR3JvdXBbXSkgPT4gdm9pZFxyXG59XHJcblxyXG5mdW5jdGlvbiBEYXRhVGFibGVGaWx0ZXJHcm91cHM8VCBleHRlbmRzIEVudGl0eT4gKHsgY29sdW1ucywgb25RdWVyeUNoYW5nZSB9OiBEYXRhVGFibGVGaWx0ZXJHcm91cHNQcm9wczxUPik6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgY29sdW1uc0ZpbHRlckdyb3VwczogSUZpbHRlckdyb3VwW10gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGNvbHVtbnNXaXRoRmlsdGVyR3JvdXBzID0gY29sdW1uc1xyXG4gICAgICAuZmlsdGVyKGNvbHVtbiA9PlxyXG4gICAgICAgIGNvbHVtbi5maWx0ZXJPcHRpb25zPy5xdWVyeU1vZGUgPT09ICdzZWFyY2hhYmxlRHJvcGRvd24nIHx8XHJcbiAgICAgICAgY29sdW1uLmZpbHRlck9wdGlvbnM/LnF1ZXJ5TW9kZSA9PT0gJ3RleHQnLFxyXG4gICAgICApXHJcblxyXG4gICAgY29uc3QgZm9ybWF0dGVkQ29sdW1uc0ZpbHRlckdyb3VwczogSUZpbHRlckdyb3VwW10gPSBjb2x1bW5zV2l0aEZpbHRlckdyb3Vwcy5tYXAoKHsgZmlsdGVyT3B0aW9ucywgLi4uY29sdW1uIH0pID0+IHtcclxuICAgICAgY29uc3QgY29sdW1uRmllbGQgPSBjb2x1bW4uZmllbGQudG9TdHJpbmcoKVxyXG4gICAgICBjb25zdCBxdWVyeU1vZGUgPSBmaWx0ZXJPcHRpb25zPy5xdWVyeU1vZGUgPT09ICdkZWZhdWx0JyA/ICd0ZXh0JyA6IGZpbHRlck9wdGlvbnM/LnF1ZXJ5TW9kZVxyXG4gICAgICBjb25zdCBxdWVyeVR5cGUgPSBmaWx0ZXJPcHRpb25zPy5xdWVyeVR5cGUgfHwgJ25vbmUnXHJcbiAgICAgIGNvbnN0IGl0ZW1zID0gZmlsdGVyT3B0aW9ucz8uaXRlbXMgfHwgW11cclxuXHJcbiAgICAgIGNvbnN0IGZpbHRlckdyb3VwOiBQYXJ0aWFsPElGaWx0ZXJHcm91cD4gPSB7XHJcbiAgICAgICAgZmllbGQ6IGNvbHVtbkZpZWxkLFxyXG4gICAgICAgIGZpbHRlckdyb3VwTmFtZTogY29sdW1uLmhlYWRlcixcclxuICAgICAgICBpc09yOiBmaWx0ZXJPcHRpb25zPy5pc09yLFxyXG4gICAgICAgIGl0ZW1zLFxyXG4gICAgICAgIHJlcGxhY2U6IGZpbHRlck9wdGlvbnM/LnJlcGxhY2UsXHJcbiAgICAgICAgY29sb3I6IGZpbHRlck9wdGlvbnM/Lmdyb3VwQ29sb3IsXHJcbiAgICAgICAgb25DaGFuZ2VJdGVtczogZmlsdGVyT3B0aW9ucz8uZ3JvdXBJdGVtc0NoYW5nZSxcclxuICAgICAgfVxyXG5cclxuICAgICAgZmlsdGVyR3JvdXAucXVlcnlUeXBlID0gcXVlcnlUeXBlXHJcblxyXG4gICAgICBzd2l0Y2ggKGZpbHRlckdyb3VwLnF1ZXJ5VHlwZSkge1xyXG4gICAgICAgIGNhc2UgJ3JlY29yZCc6XHJcbiAgICAgICAgICBmaWx0ZXJHcm91cC5maWVsZCA9IGNvbHVtbkZpZWxkXHJcbiAgICAgICAgICBmaWx0ZXJHcm91cC5yZWNvcmQgPSBmaWx0ZXJPcHRpb25zPy5yZWNvcmRcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIGZpbHRlckdyb3VwLmZpZWxkID0gY29sdW1uRmllbGRcclxuICAgICAgfVxyXG5cclxuICAgICAgZmlsdGVyR3JvdXAucXVlcnlNb2RlID0gcXVlcnlNb2RlXHJcblxyXG4gICAgICBpZiAoZmlsdGVyR3JvdXAucXVlcnlNb2RlID09PSAnc2VhcmNoYWJsZURyb3Bkb3duJykge1xyXG4gICAgICAgIGZpbHRlckdyb3VwLmRyb3Bkb3duT3B0aW9ucyA9IGZpbHRlck9wdGlvbnM/Lmdyb3VwRHJvcGRvd25PcHRpb25zXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBmaWx0ZXJHcm91cCBhcyBJRmlsdGVyR3JvdXBcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIGZvcm1hdHRlZENvbHVtbnNGaWx0ZXJHcm91cHNcclxuICB9LCBbY29sdW1uc10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmlsdGVyR3JvdXBcclxuICAgICAgZ3JvdXBzPXtjb2x1bW5zRmlsdGVyR3JvdXBzfVxyXG4gICAgICBvbkZpbHRlclF1ZXJ5Q2hhbmdlPXtvblF1ZXJ5Q2hhbmdlfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhdGFUYWJsZUZpbHRlckdyb3Vwc1xyXG4iXX0=