import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditInternalControlSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditInternalControlSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { AuditApprovalSituationEnum } from "/src/modules/audit/audits/enums/index.ts";
const AuditInternalControlSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/internal-control`;
  const isDisabledTabs = useMemo(() => {
    switch (audit?.situacaoAprovacao) {
      case AuditApprovalSituationEnum.PENDING:
      case AuditApprovalSituationEnum.IN_PROGRESS:
        return true;
    }
    return audit?.situacao === AuditSituationEnum.Cancelado;
  }, [audit?.situacao, audit?.situacaoAprovacao]);
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: isDisabledTabs,
      key: "commercial",
      title: "Comercial",
      name: "Comercial",
      icon: "Tag",
      permission: "Auditoria",
      url: `${path}/commercial`
    }, {
      disabled: isDisabledTabs,
      key: "purchases",
      title: "Compras",
      name: "Compras",
      icon: "ShoppingCart",
      permission: "Auditoria",
      url: `${path}/purchases`
    }, {
      disabled: isDisabledTabs,
      key: "accounting",
      title: "Contábil",
      name: "Contábil",
      icon: "Compare",
      permission: "Auditoria",
      url: `${path}/accounting`
    }, {
      disabled: isDisabledTabs,
      key: "costs",
      title: "Custos",
      name: "Custos",
      icon: "Money",
      permission: "Auditoria",
      url: `${path}/costs`
    }, {
      disabled: isDisabledTabs,
      key: "financial",
      title: "Financeiro",
      name: "Financeiro",
      icon: "Financial",
      permission: "Auditoria",
      url: `${path}/financial`
    }, {
      disabled: isDisabledTabs,
      key: "fiscal",
      title: "Fiscal",
      name: "Fiscal",
      icon: "Calculator",
      permission: "Auditoria",
      url: `${path}/fiscal`
    }, {
      disabled: isDisabledTabs,
      key: "logistics",
      title: "Logística",
      name: "Logística",
      icon: "FlowChart",
      permission: "Auditoria",
      url: `${path}/logistics`
    }, {
      disabled: isDisabledTabs,
      key: "production",
      title: "Produção",
      name: "Produção",
      icon: "ProductRelease",
      permission: "Auditoria",
      url: `${path}/production`
    }, {
      disabled: isDisabledTabs,
      key: "human-resources",
      title: "Recursos humanos",
      name: "Recursos humanos",
      icon: "Commitments",
      permission: "Auditoria",
      url: `${path}/human-resources`
    }, {
      disabled: isDisabledTabs,
      key: "internal-audit",
      title: "Uso da auditoria interna",
      name: "Uso da auditoria interna",
      icon: "SearchData",
      permission: "Auditoria",
      url: `${path}/internal-audit`
    }, {
      disabled: isDisabledTabs,
      key: "engineering",
      title: "Engenharia",
      name: "Engenharia",
      icon: "Repair",
      permission: "Auditoria",
      url: `${path}/engineering`
    }, {
      disabled: isDisabledTabs,
      key: "information-technology",
      title: "TI",
      icon: "PC1",
      name: "TI",
      permission: "Auditoria",
      url: `${path}/information-technology`
    }, {
      disabled: isDisabledTabs,
      key: "import-export",
      title: "Importação e exportação",
      icon: "Commitments",
      name: "Importação e exportação",
      permission: "Auditoria",
      url: `${path}/import-export`
    }]
  }], [isDisabledTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  const handleNavigateBack = useCallback(() => {
    navigate(`/audit/audits/${auditId}/control-panel/dashboard`);
  }, [auditId]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Controles internos", hasErrorWhenDisabled: audit?.situacaoAprovacao === AuditApprovalSituationEnum.ERROR, subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditInternalControlSideMenu.tsx",
    lineNumber: 174,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditInternalControlSideMenu.tsx",
    lineNumber: 173,
    columnNumber: 142
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, goBack: handleNavigateBack }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditInternalControlSideMenu.tsx",
    lineNumber: 173,
    columnNumber: 10
  }, this);
};
_s(AuditInternalControlSideMenu, "j92lezwG1/rvG3YMAv1kBDfPhjU=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditInternalControlSideMenu;
export default AuditInternalControlSideMenu;
var _c;
$RefreshReg$(_c, "AuditInternalControlSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditInternalControlSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBME1VOzs7Ozs7Ozs7Ozs7Ozs7O0FBMU1WLFNBQXlCQSxhQUFhQyxTQUFTQyxnQkFBZ0I7QUFFL0QsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsZ0NBQWdDO0FBQ3ZDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxrQ0FBa0M7QUFFM0MsTUFBTUMsK0JBQW1DQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0MsUUFBTUMsV0FBV2QsWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRWU7QUFBQUEsRUFBUyxJQUFJaEIsWUFBWTtBQUNqQyxRQUFNO0FBQUEsSUFBRWlCO0FBQUFBLEVBQWMsSUFBSWQsZUFBZTtBQUN6QyxRQUFNO0FBQUEsSUFBRWU7QUFBQUEsSUFBUUM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBWUM7QUFBQUEsRUFBUyxJQUFJYixTQUFTO0FBQzNELFFBQU0sQ0FBQ2MsaUJBQWlCQyxrQkFBa0IsSUFBSXhCLFNBQWtCLEtBQUs7QUFFckUsUUFBTTtBQUFBLElBQUV5QixJQUFJQztBQUFBQSxFQUFRLElBQUl2QixVQUFVO0FBRWxDLFFBQU07QUFBQSxJQUFFd0IsTUFBTUM7QUFBQUEsRUFBTSxJQUFJckIsa0JBQWtCc0IsV0FBV0gsT0FBaUI7QUFFdEUsUUFBTUksT0FBUSxpQkFBZ0JKO0FBRTlCLFFBQU1LLGlCQUFpQmhDLFFBQVEsTUFBTTtBQUNuQyxZQUFRNkIsT0FBT0ksbUJBQWlCO0FBQUEsTUFDOUIsS0FBS25CLDJCQUEyQm9CO0FBQUFBLE1BQ2hDLEtBQUtwQiwyQkFBMkJxQjtBQUM5QixlQUFPO0FBQUEsSUFDWDtBQUVBLFdBQU9OLE9BQU9PLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxFQUNoRCxHQUFHLENBQUNSLE9BQU9PLFVBQVVQLE9BQU9JLGlCQUFpQixDQUFDO0FBRTlDLFFBQU1LLGdCQUFpQ3RDLFFBQVEsTUFBTSxDQUNuRDtBQUFBLElBQ0V1QyxPQUFPLENBQ0w7QUFBQSxNQUNFQyxVQUFVUjtBQUFBQSxNQUNWUyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEUsTUFBTTtBQUFBLE1BQ05ELE1BQU07QUFBQSxNQUNORSxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BFLE1BQU07QUFBQSxNQUNORCxNQUFNO0FBQUEsTUFDTkUsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixDQUFDO0FBQUEsRUFFTCxDQUFDLEdBQ0EsQ0FBQ0MsZ0JBQWdCUixlQUFlLENBQUM7QUFFcEMsUUFBTXVCLGdCQUFnQi9DLFFBQVEsTUFBTTtBQUNsQyxVQUFNZ0QsZ0JBQWlDLENBQUMsR0FBR1YsYUFBYTtBQUN4RFUsa0JBQWNDLFFBQVEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN0Q0gsb0JBQWNHLEtBQUssRUFBRVosUUFBUVcsTUFBTVgsTUFBTWEsT0FBT0MsYUFBV2xDLGNBQWNrQyxRQUFRUixZQUE0QixZQUFZLENBQUM7QUFBQSxJQUM1SCxDQUFDO0FBQ0QsV0FBT0c7QUFBQUEsRUFDVCxHQUFHLENBQUNWLGFBQWEsQ0FBQztBQUVsQixRQUFNZ0IsY0FBY3RELFFBQVEsTUFDMUJZLDJCQUEyQk0sVUFBVTZCLGFBQWEsR0FDcEQsQ0FBQzdCLFVBQVU2QixhQUFhLENBQUM7QUFFekIsUUFBTVEsY0FBY0EsQ0FBQ0MsSUFBaUJDLFNBQW9CO0FBQ3hELFFBQUlELE9BQU9FLFVBQWFELFNBQVNDLFFBQVc7QUFDMUNGLFNBQUdHLGVBQWU7QUFDbEIsVUFBSUYsS0FBS2xCLE9BQU87QUFDZGQsMkJBQW1CLENBQUNELGVBQWU7QUFBQSxNQUNyQyxPQUFPO0FBQ0xQLGlCQUFTd0MsS0FBS1gsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNYyxxQkFBcUI3RCxZQUFZLE1BQU07QUFDM0NrQixhQUFVLGlCQUFnQlUsaUNBQWlDO0FBQUEsRUFDN0QsR0FBRyxDQUFDQSxPQUFPLENBQUM7QUFFWixTQUNFLHVCQUFDLFlBQ0MsT0FBTSxzQkFDTixzQkFBc0JFLE9BQU9JLHNCQUFzQm5CLDJCQUEyQitDLE9BQzlFLFVBQ0UsdUJBQUMsUUFDQyxNQUNHLGtCQUFpQmhDLE9BQU9pQyxVQUFVQyx1QkFDakNsQyxPQUFPaUMsVUFBVUUsc0JBQ1osR0FBRW5DLE9BQU9pQyxTQUFTRSxtQ0FBbUNuQyxPQUFPaUMsVUFBVUcsbUJBQ3ZFcEMsT0FBT2lDLFVBQVVwQyxNQUd6QixRQUFPLFNBRVAsaUNBQUMsUUFDQyxRQUFRO0FBQUEsSUFDTndDLE1BQU07QUFBQSxNQUNKQyxPQUFPL0MsT0FBT2dELEtBQUssR0FBRztBQUFBLE1BQ3RCOUMsWUFBWUEsV0FBVytDO0FBQUFBLE1BQ3ZCOUMsVUFBVUEsU0FBUytDO0FBQUFBLE1BQ25CQyxxQkFBcUJuRCxPQUFPZ0QsS0FBSyxHQUFHO0FBQUEsTUFDcENJLFlBQVluRCxRQUFRb0Q7QUFBQUEsTUFDcEJDLFVBQVU7QUFBQSxNQUNWQyxjQUFjdEQsUUFBUXVEO0FBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUTCxxQkFBcUJuRCxPQUFPZ0QsS0FBSyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLE9BQUssTUFFSnZDO0FBQUFBLFdBQU9pQyxVQUFVZTtBQUFBQSxJQUFhO0FBQUEsSUFBSXBFLHFCQUFxQm9CLE9BQU9pQyxVQUFVRyxjQUF3QjtBQUFBLE9BakJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsR0FFRixRQUFRbEIsZUFDUixhQUFhUSxhQUNiLGFBQ0EsUUFBUUssc0JBdENWO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQzZCO0FBR2pDO0FBQUM1QyxHQXhOS0QsOEJBQWdDO0FBQUEsVUFDbkJaLGFBQ0lELGFBQ0tHLGdCQUN3QkssVUFHMUJOLFdBRUFJLGtCQUFrQnNCLFVBQVU7QUFBQTtBQUFBZ0QsS0FUaEQvRDtBQTBOTixlQUFlQTtBQUE0QixJQUFBK0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVBlcm1pc3Npb25zIiwiTGluayIsIlNpZGVNZW51IiwiYXVkaXRRdWVyeVNlcnZpY2UiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsInVzZVRoZW1lIiwiVGV4dCIsImdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzIiwiQXVkaXRTaXR1YXRpb25FbnVtIiwiQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0iLCJBdWRpdEludGVybmFsQ29udHJvbFNpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJpc0dyb3VwRXhwYW5kZWQiLCJzZXRJc0dyb3VwRXhwYW5kZWQiLCJpZCIsImF1ZGl0SWQiLCJkYXRhIiwiYXVkaXQiLCJ1c2VGaW5kT25lIiwicGF0aCIsImlzRGlzYWJsZWRUYWJzIiwic2l0dWFjYW9BcHJvdmFjYW8iLCJQRU5ESU5HIiwiSU5fUFJPR1JFU1MiLCJzaXR1YWNhbyIsIkNhbmNlbGFkbyIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsImRpc2FibGVkIiwia2V5IiwidGl0bGUiLCJuYW1lIiwiaWNvbiIsInBlcm1pc3Npb24iLCJ1cmwiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZU5hdmlnYXRlQmFjayIsIkVSUk9SIiwiY29udHJhdG8iLCJjbGllbnRlSWQiLCJjb250cmF0b1ByaW5jaXBhbElkIiwibnVtZXJvUHJvcG9zdGEiLCJyb290IiwiY29sb3IiLCJncmF5Iiwic2VtaWJvbGQiLCJwMTQiLCJ0ZXh0RGVjb3JhdGlvbkNvbG9yIiwibWFyZ2luTGVmdCIsImxnIiwibWF4V2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJtZCIsIm5vbWVGYW50YXNpYSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgTW91c2VFdmVudCwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElOYXZMaW5rR3JvdXAsIElOYXZMaW5rIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9OYXYnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXHJcbmltcG9ydCB7IExpbmssIFNpZGVNZW51IH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IGF1ZGl0UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vYXVkaXRzL3NlcnZpY2VzJ1xyXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyBmcm9tICcuLi8uLi8uLi9zaGFyZWQvdXRpbHMvZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcbmltcG9ydCB7IEF1ZGl0QXBwcm92YWxTaXR1YXRpb25FbnVtIH0gZnJvbSAnLi4vYXVkaXRzL2VudW1zJ1xyXG5cclxuY29uc3QgQXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudTogRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcbiAgY29uc3QgeyBwYXRobmFtZSB9ID0gdXNlTG9jYXRpb24oKVxyXG4gIGNvbnN0IHsgaGFzUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKVxyXG4gIGNvbnN0IHsgY29sb3JzLCBzcGFjaW5nLCBmb250V2VpZ2h0LCBmb250U2l6ZSB9ID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IFtpc0dyb3VwRXhwYW5kZWQsIHNldElzR3JvdXBFeHBhbmRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSlcclxuXHJcbiAgY29uc3QgeyBpZDogYXVkaXRJZCB9ID0gdXNlUGFyYW1zKClcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBhdWRpdCB9ID0gYXVkaXRRdWVyeVNlcnZpY2UudXNlRmluZE9uZShhdWRpdElkIGFzIHN0cmluZylcclxuXHJcbiAgY29uc3QgcGF0aCA9IGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC9pbnRlcm5hbC1jb250cm9sYFxyXG5cclxuICBjb25zdCBpc0Rpc2FibGVkVGFicyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgc3dpdGNoIChhdWRpdD8uc2l0dWFjYW9BcHJvdmFjYW8pIHtcclxuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5QRU5ESU5HOlxyXG4gICAgICBjYXNlIEF1ZGl0QXBwcm92YWxTaXR1YXRpb25FbnVtLklOX1BST0dSRVNTOlxyXG4gICAgICAgIHJldHVybiB0cnVlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkb1xyXG4gIH0sIFthdWRpdD8uc2l0dWFjYW8sIGF1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhb10pXHJcblxyXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcclxuICAgICAgICAgIGtleTogJ2NvbW1lcmNpYWwnLFxyXG4gICAgICAgICAgdGl0bGU6ICdDb21lcmNpYWwnLFxyXG4gICAgICAgICAgbmFtZTogJ0NvbWVyY2lhbCcsXHJcbiAgICAgICAgICBpY29uOiAnVGFnJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9jb21tZXJjaWFsYCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcclxuICAgICAgICAgIGtleTogJ3B1cmNoYXNlcycsXHJcbiAgICAgICAgICB0aXRsZTogJ0NvbXByYXMnLFxyXG4gICAgICAgICAgbmFtZTogJ0NvbXByYXMnLFxyXG4gICAgICAgICAgaWNvbjogJ1Nob3BwaW5nQ2FydCcsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vcHVyY2hhc2VzYCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcclxuICAgICAgICAgIGtleTogJ2FjY291bnRpbmcnLFxyXG4gICAgICAgICAgdGl0bGU6ICdDb250w6FiaWwnLFxyXG4gICAgICAgICAgbmFtZTogJ0NvbnTDoWJpbCcsXHJcbiAgICAgICAgICBpY29uOiAnQ29tcGFyZScsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vYWNjb3VudGluZ2AsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBrZXk6ICdjb3N0cycsXHJcbiAgICAgICAgICB0aXRsZTogJ0N1c3RvcycsXHJcbiAgICAgICAgICBuYW1lOiAnQ3VzdG9zJyxcclxuICAgICAgICAgIGljb246ICdNb25leScsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vY29zdHNgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAga2V5OiAnZmluYW5jaWFsJyxcclxuICAgICAgICAgIHRpdGxlOiAnRmluYW5jZWlybycsXHJcbiAgICAgICAgICBuYW1lOiAnRmluYW5jZWlybycsXHJcbiAgICAgICAgICBpY29uOiAnRmluYW5jaWFsJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9maW5hbmNpYWxgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAga2V5OiAnZmlzY2FsJyxcclxuICAgICAgICAgIHRpdGxlOiAnRmlzY2FsJyxcclxuICAgICAgICAgIG5hbWU6ICdGaXNjYWwnLFxyXG4gICAgICAgICAgaWNvbjogJ0NhbGN1bGF0b3InLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2Zpc2NhbGAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBrZXk6ICdsb2dpc3RpY3MnLFxyXG4gICAgICAgICAgdGl0bGU6ICdMb2fDrXN0aWNhJyxcclxuICAgICAgICAgIG5hbWU6ICdMb2fDrXN0aWNhJyxcclxuICAgICAgICAgIGljb246ICdGbG93Q2hhcnQnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2xvZ2lzdGljc2AsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBrZXk6ICdwcm9kdWN0aW9uJyxcclxuICAgICAgICAgIHRpdGxlOiAnUHJvZHXDp8OjbycsXHJcbiAgICAgICAgICBuYW1lOiAnUHJvZHXDp8OjbycsXHJcbiAgICAgICAgICBpY29uOiAnUHJvZHVjdFJlbGVhc2UnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3Byb2R1Y3Rpb25gLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAga2V5OiAnaHVtYW4tcmVzb3VyY2VzJyxcclxuICAgICAgICAgIHRpdGxlOiAnUmVjdXJzb3MgaHVtYW5vcycsXHJcbiAgICAgICAgICBuYW1lOiAnUmVjdXJzb3MgaHVtYW5vcycsXHJcbiAgICAgICAgICBpY29uOiAnQ29tbWl0bWVudHMnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2h1bWFuLXJlc291cmNlc2AsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBrZXk6ICdpbnRlcm5hbC1hdWRpdCcsXHJcbiAgICAgICAgICB0aXRsZTogJ1VzbyBkYSBhdWRpdG9yaWEgaW50ZXJuYScsXHJcbiAgICAgICAgICBuYW1lOiAnVXNvIGRhIGF1ZGl0b3JpYSBpbnRlcm5hJyxcclxuICAgICAgICAgIGljb246ICdTZWFyY2hEYXRhJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9pbnRlcm5hbC1hdWRpdGAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXHJcbiAgICAgICAgICBrZXk6ICdlbmdpbmVlcmluZycsXHJcbiAgICAgICAgICB0aXRsZTogJ0VuZ2VuaGFyaWEnLFxyXG4gICAgICAgICAgbmFtZTogJ0VuZ2VuaGFyaWEnLFxyXG4gICAgICAgICAgaWNvbjogJ1JlcGFpcicsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vZW5naW5lZXJpbmdgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxyXG4gICAgICAgICAga2V5OiAnaW5mb3JtYXRpb24tdGVjaG5vbG9neScsXHJcbiAgICAgICAgICB0aXRsZTogJ1RJJyxcclxuICAgICAgICAgIGljb246ICdQQzEnLFxyXG4gICAgICAgICAgbmFtZTogJ1RJJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9pbmZvcm1hdGlvbi10ZWNobm9sb2d5YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcclxuICAgICAgICAgIGtleTogJ2ltcG9ydC1leHBvcnQnLFxyXG4gICAgICAgICAgdGl0bGU6ICdJbXBvcnRhw6fDo28gZSBleHBvcnRhw6fDo28nLFxyXG4gICAgICAgICAgaWNvbjogJ0NvbW1pdG1lbnRzJyxcclxuICAgICAgICAgIG5hbWU6ICdJbXBvcnRhw6fDo28gZSBleHBvcnRhw6fDo28nLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2ltcG9ydC1leHBvcnRgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gIF0sIFtpc0Rpc2FibGVkVGFicywgaXNHcm91cEV4cGFuZGVkXSlcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbk5hdiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gWy4uLm5hdkxpbmtHcm91cHNdXHJcbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyb3VwLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5wZXJtaXNzaW9uIGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInKSlcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZmlsdGVyZWRHcm91cFxyXG4gIH0sIFtuYXZMaW5rR3JvdXBzXSlcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRLZXkgPSB1c2VNZW1vKCgpID0+XHJcbiAgICBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyhwYXRobmFtZSwgcGVybWlzc2lvbk5hdiksXHJcbiAgW3BhdGhuYW1lLCBwZXJtaXNzaW9uTmF2XSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoZXY/OiBNb3VzZUV2ZW50LCBpdGVtPzogSU5hdkxpbmspID0+IHtcclxuICAgIGlmIChldiAhPT0gdW5kZWZpbmVkICYmIGl0ZW0gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgIGlmIChpdGVtLmxpbmtzKSB7XHJcbiAgICAgICAgc2V0SXNHcm91cEV4cGFuZGVkKCFpc0dyb3VwRXhwYW5kZWQpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5hdmlnYXRlQmFjayA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIG5hdmlnYXRlKGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC9kYXNoYm9hcmRgKVxyXG4gIH0sIFthdWRpdElkXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTaWRlTWVudVxyXG4gICAgICB0aXRsZT0nQ29udHJvbGVzIGludGVybm9zJ1xyXG4gICAgICBoYXNFcnJvcldoZW5EaXNhYmxlZD17YXVkaXQ/LnNpdHVhY2FvQXByb3ZhY2FvID09PSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5FUlJPUn1cclxuICAgICAgc3VidGl0bGU9e1xyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICBocmVmPXtcclxuICAgICAgICAgICAgYC9hZG1pbi9jbGllbnRzLyR7YXVkaXQ/LmNvbnRyYXRvPy5jbGllbnRlSWR9L2NvbnRyYWN0cy8ke1xyXG4gICAgICAgICAgICAgIGF1ZGl0Py5jb250cmF0bz8uY29udHJhdG9QcmluY2lwYWxJZFxyXG4gICAgICAgICAgICAgICAgPyBgJHthdWRpdD8uY29udHJhdG8uY29udHJhdG9QcmluY2lwYWxJZH0/c3ViY29udHJhY3Q9JHthdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhfWBcclxuICAgICAgICAgICAgICAgIDogYXVkaXQ/LmNvbnRyYXRvPy5pZFxyXG4gICAgICAgICAgICB9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGFyZ2V0PVwiYmxhbmtcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXHJcbiAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAyMDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXHJcbiAgICAgICAgICAgICAgICAnOjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2F1ZGl0Py5jb250cmF0bz8ubm9tZUZhbnRhc2lhfSAtIHtmb3JtYXRQcm9wb3NhbE51bWJlcihhdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhIGFzIHN0cmluZyl9XHJcbiAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICB9XHJcbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cclxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBzZWxlY3RlZEtleT17c2VsZWN0ZWRLZXl9XHJcbiAgICAgIGdvQmFjaz17aGFuZGxlTmF2aWdhdGVCYWNrfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1ZGl0SW50ZXJuYWxDb250cm9sU2lkZU1lbnVcclxuIl19