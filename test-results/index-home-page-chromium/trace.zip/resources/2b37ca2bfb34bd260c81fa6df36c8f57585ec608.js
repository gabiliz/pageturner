import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditFinancialStatementImportSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId,
    financialId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/test-process/financial-statements`;
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      key: "details",
      title: "Importar",
      name: "Importar",
      icon: "Upload",
      permission: "Auditoria",
      url: `${path}/details/${financialId}`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      key: "teste",
      title: "Teste",
      name: "Teste",
      icon: "Upload",
      permission: "Auditoria",
      url: `${path}/details/${financialId}/teste`
    }]
  }], [disableTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  const handleNavigateBack = useCallback(() => {
    navigate(`${path}`);
  }, [path]);
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Demonstrações financeiras", subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx",
    lineNumber: 83,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx",
    lineNumber: 82,
    columnNumber: 64
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, goBack: handleNavigateBack, disabledCollapse: true }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
};
_s(AuditFinancialStatementImportSideMenu, "qMXhe1/pgMTRz3Waqz6sYgsw6f0=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditFinancialStatementImportSideMenu;
export default AuditFinancialStatementImportSideMenu;
var _c;
$RefreshReg$(_c, "AuditFinancialStatementImportSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementImportSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0dVOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEdWLFNBQXlCQSxhQUFhQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFMUUsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsZ0NBQWdDO0FBQ3ZDLFNBQVNDLDBCQUEwQjtBQUVuQyxNQUFNQyx3Q0FBNENBLE1BQU07QUFBQUMsS0FBQTtBQUN0RCxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFjLElBQUliLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSVosU0FBUztBQUMzRCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBa0IsS0FBSztBQUVyRSxRQUFNO0FBQUEsSUFBRTBCLElBQUlDO0FBQUFBLElBQVNDO0FBQUFBLEVBQVksSUFBSXpCLFVBQVU7QUFFL0MsUUFBTTtBQUFBLElBQUUwQixNQUFNQztBQUFBQSxFQUFNLElBQUl2QixrQkFBa0J3QixXQUFXSixPQUFpQjtBQUV0RSxRQUFNSyxPQUFRLGlCQUFnQkw7QUFDOUIsUUFBTU0sZ0JBQWlDbEMsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRW1DLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLFVBQVVMLE9BQU9NLGFBQWF4QixtQkFBbUJ5QjtBQUFBQSxNQUNqREMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYLGdCQUFnQko7QUFBQUEsSUFDMUIsR0FDQTtBQUFBLE1BQ0VPLFVBQVVMLE9BQU9NLGFBQWF4QixtQkFBbUJ5QjtBQUFBQSxNQUNqREMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYLGdCQUFnQko7QUFBQUEsSUFDMUIsQ0FBQztBQUFBLEVBRUwsQ0FBQyxHQUNBLENBQUNOLGFBQWFFLGVBQWUsQ0FBQztBQUVqQyxRQUFNb0IsZ0JBQWdCN0MsUUFBUSxNQUFNO0FBQ2xDLFVBQU04QyxnQkFBaUMsQ0FBQyxHQUFHWixhQUFhO0FBQ3hEWSxrQkFBY0MsUUFBUSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3RDSCxvQkFBY0csS0FBSyxFQUFFZCxRQUFRYSxNQUFNYixNQUFNZSxPQUFPQyxhQUFXakMsY0FBY2lDLFFBQVFSLFlBQTRCLFlBQVksQ0FBQztBQUFBLElBQzVILENBQUM7QUFDRCxXQUFPRztBQUFBQSxFQUNULEdBQUcsQ0FBQ1osYUFBYSxDQUFDO0FBRWxCLFFBQU1rQixjQUFjcEQsUUFBUSxNQUMxQlksMkJBQTJCSyxVQUFVNEIsYUFBYSxHQUNwRCxDQUFDNUIsVUFBVTRCLGFBQWEsQ0FBQztBQUV6QixRQUFNUSxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQixVQUFJRixLQUFLcEIsT0FBTztBQUNkVCwyQkFBbUIsQ0FBQ0QsZUFBZTtBQUFBLE1BQ3JDLE9BQU87QUFDTFQsaUJBQVN1QyxLQUFLWCxHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1jLHFCQUFxQjVELFlBQVksTUFBTTtBQUMzQ2tCLGFBQVUsR0FBRWlCLE1BQU07QUFBQSxFQUNwQixHQUFHLENBQUNBLElBQUksQ0FBQztBQUVUbEMsWUFBVSxNQUFNO0FBQ2QsVUFBTTRELGtCQUFrQjVCLE9BQU82QixTQUFTQyxLQUFLQyxhQUFXQSxRQUFRQyxxQkFBcUIsSUFBSSxFQUFFO0FBQzNGdkMsbUJBQWVtQyxtQkFBbUI1QixPQUFPTSxhQUFhLENBQUM7QUFBQSxFQUN6RCxHQUFHLENBQUNOLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLDZCQUNOLFVBQ0UsdUJBQUMsUUFDQyxNQUNHLGtCQUFpQkEsT0FBT2lDLFVBQVVDLHVCQUNqQ2xDLE9BQU9pQyxVQUFVRSxzQkFDWixHQUFFbkMsT0FBT2lDLFNBQVNFLG1DQUFtQ25DLE9BQU9pQyxVQUFVRyxtQkFDdkVwQyxPQUFPaUMsVUFBVXJDLE1BR3pCLFFBQU8sU0FFUCxpQ0FBQyxRQUNDLFFBQVE7QUFBQSxJQUNOeUMsTUFBTTtBQUFBLE1BQ0pDLE9BQU9sRCxPQUFPbUQsS0FBSyxHQUFHO0FBQUEsTUFDdEJqRCxZQUFZQSxXQUFXa0Q7QUFBQUEsTUFDdkJqRCxVQUFVQSxTQUFTa0Q7QUFBQUEsTUFDbkJDLHFCQUFxQnRELE9BQU9tRCxLQUFLLEdBQUc7QUFBQSxNQUNwQ0ksWUFBWXRELFFBQVF1RDtBQUFBQSxNQUNwQkMsVUFBVTtBQUFBLE1BQ1ZDLGNBQWN6RCxRQUFRMEQ7QUFBQUEsTUFDdEIsV0FBVztBQUFBLFFBQ1RMLHFCQUFxQnRELE9BQU9tRCxLQUFLLEdBQUc7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsT0FBSyxNQUVKdkM7QUFBQUEsV0FBT2lDLFVBQVVlO0FBQUFBLElBQWE7QUFBQSxJQUFJdEUscUJBQXFCc0IsT0FBT2lDLFVBQVVHLGNBQXdCO0FBQUEsT0FqQm5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQSxHQUVGLFFBQVF0QixlQUNSLGFBQWFRLGFBQ2IsYUFDQSxRQUFRSyxvQkFDUixrQkFBZ0IsUUF0Q2xCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ2tCO0FBR3RCO0FBQUMzQyxHQWhIS0QsdUNBQXlDO0FBQUEsVUFDNUJYLGFBQ0lELGFBQ0tHLGdCQUN3QkssVUFJYk4sV0FFYkksa0JBQWtCd0IsVUFBVTtBQUFBO0FBQUFnRCxLQVZoRGxFO0FBa0hOLGVBQWVBO0FBQXFDLElBQUFrRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlUGVybWlzc2lvbnMiLCJMaW5rIiwiU2lkZU1lbnUiLCJhdWRpdFF1ZXJ5U2VydmljZSIsImZvcm1hdFByb3Bvc2FsTnVtYmVyIiwidXNlVGhlbWUiLCJUZXh0IiwiZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MiLCJBdWRpdFNpdHVhdGlvbkVudW0iLCJBdWRpdEZpbmFuY2lhbFN0YXRlbWVudEltcG9ydFNpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJkaXNhYmxlVGFicyIsInNldERpc2FibGVUYWJzIiwiaXNHcm91cEV4cGFuZGVkIiwic2V0SXNHcm91cEV4cGFuZGVkIiwiaWQiLCJhdWRpdElkIiwiZmluYW5jaWFsSWQiLCJkYXRhIiwiYXVkaXQiLCJ1c2VGaW5kT25lIiwicGF0aCIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsImRpc2FibGVkIiwic2l0dWFjYW8iLCJDYW5jZWxhZG8iLCJrZXkiLCJ0aXRsZSIsIm5hbWUiLCJpY29uIiwicGVybWlzc2lvbiIsInVybCIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXJlZEdyb3VwIiwiZm9yRWFjaCIsImdyb3VwIiwiaW5kZXgiLCJmaWx0ZXIiLCJuYXZMaW5rIiwic2VsZWN0ZWRLZXkiLCJoYW5kbGVDbGljayIsImV2IiwiaXRlbSIsInVuZGVmaW5lZCIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlTmF2aWdhdGVCYWNrIiwidmVyaWZ5U2l0dWF0aW9uIiwiZW1wcmVzYXMiLCJzb21lIiwiZW1wcmVzYSIsInNpdHVhY2FvUmV2aXNhbyIsImNvbnRyYXRvIiwiY2xpZW50ZUlkIiwiY29udHJhdG9QcmluY2lwYWxJZCIsIm51bWVyb1Byb3Bvc3RhIiwicm9vdCIsImNvbG9yIiwiZ3JheSIsInNlbWlib2xkIiwicDE0IiwidGV4dERlY29yYXRpb25Db2xvciIsIm1hcmdpbkxlZnQiLCJsZyIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwibWQiLCJub21lRmFudGFzaWEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0RmluYW5jaWFsU3RhdGVtZW50SW1wb3J0U2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzL0F1ZGl0RmluYW5jaWFsU3RhdGVtZW50SW1wb3J0U2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElOYXZMaW5rR3JvdXAsIElOYXZMaW5rIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9OYXYnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXHJcbmltcG9ydCB7IExpbmssIFNpZGVNZW51IH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IGF1ZGl0UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vYXVkaXRzL3NlcnZpY2VzJ1xyXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyBmcm9tICcuLi8uLi8uLi9zaGFyZWQvdXRpbHMvZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcblxyXG5jb25zdCBBdWRpdEZpbmFuY2lhbFN0YXRlbWVudEltcG9ydFNpZGVNZW51OiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXHJcbiAgY29uc3QgeyBjb2xvcnMsIHNwYWNpbmcsIGZvbnRXZWlnaHQsIGZvbnRTaXplIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgW2Rpc2FibGVUYWJzLCBzZXREaXNhYmxlVGFic10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNHcm91cEV4cGFuZGVkLCBzZXRJc0dyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXHJcblxyXG4gIGNvbnN0IHsgaWQ6IGF1ZGl0SWQsIGZpbmFuY2lhbElkIH0gPSB1c2VQYXJhbXMoKVxyXG5cclxuICBjb25zdCB7IGRhdGE6IGF1ZGl0IH0gPSBhdWRpdFF1ZXJ5U2VydmljZS51c2VGaW5kT25lKGF1ZGl0SWQgYXMgc3RyaW5nKVxyXG5cclxuICBjb25zdCBwYXRoID0gYC9hdWRpdC9hdWRpdHMvJHthdWRpdElkfS9jb250cm9sLXBhbmVsL3Rlc3QtcHJvY2Vzcy9maW5hbmNpYWwtc3RhdGVtZW50c2BcclxuICBjb25zdCBuYXZMaW5rR3JvdXBzOiBJTmF2TGlua0dyb3VwW10gPSB1c2VNZW1vKCgpID0+IFtcclxuICAgIHtcclxuICAgICAgbGlua3M6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAga2V5OiAnZGV0YWlscycsXHJcbiAgICAgICAgICB0aXRsZTogJ0ltcG9ydGFyJyxcclxuICAgICAgICAgIG5hbWU6ICdJbXBvcnRhcicsXHJcbiAgICAgICAgICBpY29uOiAnVXBsb2FkJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9kZXRhaWxzLyR7ZmluYW5jaWFsSWR9YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBrZXk6ICd0ZXN0ZScsXHJcbiAgICAgICAgICB0aXRsZTogJ1Rlc3RlJyxcclxuICAgICAgICAgIG5hbWU6ICdUZXN0ZScsXHJcbiAgICAgICAgICBpY29uOiAnVXBsb2FkJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9kZXRhaWxzLyR7ZmluYW5jaWFsSWR9L3Rlc3RlYCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICBdLCBbZGlzYWJsZVRhYnMsIGlzR3JvdXBFeHBhbmRlZF0pXHJcblxyXG4gIGNvbnN0IHBlcm1pc3Npb25OYXYgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkR3JvdXA6IElOYXZMaW5rR3JvdXBbXSA9IFsuLi5uYXZMaW5rR3JvdXBzXVxyXG4gICAgZmlsdGVyZWRHcm91cC5mb3JFYWNoKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgZmlsdGVyZWRHcm91cFtpbmRleF0ubGlua3MgPSBncm91cC5saW5rcy5maWx0ZXIobmF2TGluayA9PiBoYXNQZXJtaXNzaW9uKG5hdkxpbmsucGVybWlzc2lvbiBhcyBzZXJ2aWNlQ29kZXMsICdWaXN1YWxpemFyJykpXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGZpbHRlcmVkR3JvdXBcclxuICB9LCBbbmF2TGlua0dyb3Vwc10pXHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkS2V5ID0gdXNlTWVtbygoKSA9PlxyXG4gICAgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MocGF0aG5hbWUsIHBlcm1pc3Npb25OYXYpLFxyXG4gIFtwYXRobmFtZSwgcGVybWlzc2lvbk5hdl0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XHJcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxyXG4gICAgICBpZiAoaXRlbS5saW5rcykge1xyXG4gICAgICAgIHNldElzR3JvdXBFeHBhbmRlZCghaXNHcm91cEV4cGFuZGVkKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVOYXZpZ2F0ZUJhY2sgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBuYXZpZ2F0ZShgJHtwYXRofWApXHJcbiAgfSwgW3BhdGhdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdmVyaWZ5U2l0dWF0aW9uID0gYXVkaXQ/LmVtcHJlc2FzLnNvbWUoZW1wcmVzYSA9PiBlbXByZXNhLnNpdHVhY2FvUmV2aXNhbyA9PT0gKDAgfCAxKSkgYXMgYm9vbGVhblxyXG4gICAgc2V0RGlzYWJsZVRhYnModmVyaWZ5U2l0dWF0aW9uIHx8IGF1ZGl0Py5zaXR1YWNhbyA9PT0gMClcclxuICB9LCBbYXVkaXRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNpZGVNZW51XHJcbiAgICAgIHRpdGxlPSdEZW1vbnN0cmHDp8O1ZXMgZmluYW5jZWlyYXMnXHJcbiAgICAgIHN1YnRpdGxlPXtcclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17XHJcbiAgICAgICAgICAgIGAvYWRtaW4vY2xpZW50cy8ke2F1ZGl0Py5jb250cmF0bz8uY2xpZW50ZUlkfS9jb250cmFjdHMvJHtcclxuICAgICAgICAgICAgICBhdWRpdD8uY29udHJhdG8/LmNvbnRyYXRvUHJpbmNpcGFsSWRcclxuICAgICAgICAgICAgICAgID8gYCR7YXVkaXQ/LmNvbnRyYXRvLmNvbnRyYXRvUHJpbmNpcGFsSWR9P3N1YmNvbnRyYWN0PSR7YXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YX1gXHJcbiAgICAgICAgICAgICAgICA6IGF1ZGl0Py5jb250cmF0bz8uaWRcclxuICAgICAgICAgICAgfWBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRhcmdldD1cImJsYW5rXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxyXG4gICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IHNwYWNpbmcubGcsXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogMjAwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLm1kLFxyXG4gICAgICAgICAgICAgICAgJzo6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthdWRpdD8uY29udHJhdG8/Lm5vbWVGYW50YXNpYX0gLSB7Zm9ybWF0UHJvcG9zYWxOdW1iZXIoYXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YSBhcyBzdHJpbmcpfVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgfVxyXG4gICAgICBncm91cHM9e3Blcm1pc3Npb25OYXZ9XHJcbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cclxuICAgICAgc2VsZWN0ZWRLZXk9e3NlbGVjdGVkS2V5fVxyXG4gICAgICBnb0JhY2s9e2hhbmRsZU5hdmlnYXRlQmFja31cclxuICAgICAgZGlzYWJsZWRDb2xsYXBzZVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1ZGl0RmluYW5jaWFsU3RhdGVtZW50SW1wb3J0U2lkZU1lbnVcclxuIl19