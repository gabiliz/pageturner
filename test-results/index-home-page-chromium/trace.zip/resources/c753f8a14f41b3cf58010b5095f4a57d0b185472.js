import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/profiles/components/ProfileEditDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { ProfileEditForm } from "/src/modules/admin/profiles/components/index.ts?t=1701096626433";
import { EditDrawer } from "/src/shared/components/index.ts?t=1701096626433";
import { useFormData, useHandleRejection } from "/src/shared/hooks/index.ts";
import { profileQueryService } from "/src/modules/admin/profiles/services/index.ts";
const ProfileEditDrawer = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    profile,
    isCreating
  } = props;
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange,
    onFieldError
  } = useFormData(profile);
  const {
    mutateAsync: save,
    isLoading: isSaving
  } = profileQueryService.useUpdate();
  const {
    mutateAsync: create,
    isLoading: loadingCreating
  } = profileQueryService.useCreate();
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  const updateProfile = useCallback(async () => {
    await save(localFormData);
    onDismiss();
  }, [localFormData]);
  const createProfile = useCallback(async () => {
    await create(localFormData);
    onDismiss();
  }, [localFormData]);
  const dismiss = useCallback(() => {
    onDismiss();
  }, [onDismiss]);
  return /* @__PURE__ */ jsxDEV(EditDrawer, { title: isCreating ? "Adicionar perfil" : "Alterar perfil", isOpen, onDismiss: dismiss, onSave: isCreating ? createProfile : updateProfile, disabled: isSaving || loadingCreating, loading: isSaving || loadingCreating, children: /* @__PURE__ */ jsxDEV(ProfileEditForm, { localFormData, setLocalFormData, profile, onTextChange, onFieldError, apiError: error?.reason ? error?.reason : void 0 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditDrawer.tsx",
    lineNumber: 59,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditDrawer.tsx",
    lineNumber: 58,
    columnNumber: 10
  }, this);
};
_s(ProfileEditDrawer, "QtJ7QdJt748+oGoXKB8mgWhUTY0=", false, function() {
  return [useFormData, profileQueryService.useUpdate, profileQueryService.useCreate, useHandleRejection];
});
_c = ProfileEditDrawer;
export default ProfileEditDrawer;
var _c;
$RefreshReg$(_c, "ProfileEditDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/profiles/components/ProfileEditDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVNOzs7Ozs7Ozs7Ozs7Ozs7O0FBakVOLFNBQWFBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUNyRCxTQUFTQyx1QkFBdUI7QUFFaEMsU0FBU0Msa0JBQWtCO0FBRzNCLFNBQVNDLGFBQWFDLDBCQUEwQjtBQUNoRCxTQUFTQywyQkFBMkI7QUFVcEMsTUFBTUMsb0JBQTJDQyxXQUFVO0FBQUFDLEtBQUE7QUFDekQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVdDO0FBQUFBLElBQVNDO0FBQUFBLEVBQVcsSUFBSUw7QUFFbkQsUUFBTTtBQUFBLElBQ0pNLFVBQVVDO0FBQUFBLElBQ1ZDLGFBQWFDO0FBQUFBLElBQ2JDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSWYsWUFBNEJRLE9BQXlCO0FBRXpELFFBQU07QUFBQSxJQUFFUSxhQUFhQztBQUFBQSxJQUFNQyxXQUFXQztBQUFBQSxFQUFTLElBQUlqQixvQkFBb0JrQixVQUFVO0FBQ2pGLFFBQU07QUFBQSxJQUFFSixhQUFhSztBQUFBQSxJQUFRSCxXQUFXSTtBQUFBQSxFQUFnQixJQUFJcEIsb0JBQW9CcUIsVUFBVTtBQUMxRixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSTVCLFNBQWdDO0FBQzFELFFBQU07QUFBQSxJQUNKNkI7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJMUIsbUJBQW1CO0FBRXZCTCxZQUFVLE1BQU07QUFDZDhCLHFCQUFpQkQsUUFBUTtBQUN6QixXQUFPLE1BQU07QUFDWEUseUJBQW1CRixRQUFRO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUcsZ0JBQWdCakMsWUFBWSxZQUFZO0FBQzVDLFVBQU1zQixLQUFLTixhQUFhO0FBQ3hCSixjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNJLGFBQWEsQ0FBQztBQUVsQixRQUFNa0IsZ0JBQWdCbEMsWUFBWSxZQUFZO0FBQzVDLFVBQU0wQixPQUFPVixhQUFhO0FBQzFCSixjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNJLGFBQWEsQ0FBQztBQUVsQixRQUFNbUIsVUFBVW5DLFlBQVksTUFBTTtBQUNoQ1ksY0FBVTtBQUFBLEVBQ1osR0FBRyxDQUFDQSxTQUFTLENBQUM7QUFFZCxTQUNFLHVCQUFDLGNBQ0MsT0FBT0UsYUFBYSxxQkFBcUIsa0JBQ3pDLFFBQ0EsV0FBV3FCLFNBQ1gsUUFBUXJCLGFBQWFvQixnQkFBZ0JELGVBQ3JDLFVBQVVULFlBQVlHLGlCQUN0QixTQUFTSCxZQUFZRyxpQkFFckIsaUNBQUMsbUJBQ0MsZUFDQSxrQkFDQSxTQUNBLGNBQ0EsY0FDQSxVQUFVRSxPQUFPTyxTQUFTUCxPQUFPTyxTQUFxQkMsVUFOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1rRSxLQWRwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBQzNCLEdBMURLRixtQkFBdUM7QUFBQSxVQVF2Q0gsYUFFK0NFLG9CQUFvQmtCLFdBQ1hsQixvQkFBb0JxQixXQUs1RXRCLGtCQUFrQjtBQUFBO0FBQUFnQyxLQWhCbEI5QjtBQTRETixlQUFlQTtBQUFpQixJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJQcm9maWxlRWRpdEZvcm0iLCJFZGl0RHJhd2VyIiwidXNlRm9ybURhdGEiLCJ1c2VIYW5kbGVSZWplY3Rpb24iLCJwcm9maWxlUXVlcnlTZXJ2aWNlIiwiUHJvZmlsZUVkaXREcmF3ZXIiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwicHJvZmlsZSIsImlzQ3JlYXRpbmciLCJmb3JtRGF0YSIsImxvY2FsRm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldExvY2FsRm9ybURhdGEiLCJvblRleHRDaGFuZ2UiLCJvbkZpZWxkRXJyb3IiLCJtdXRhdGVBc3luYyIsInNhdmUiLCJpc0xvYWRpbmciLCJpc1NhdmluZyIsInVzZVVwZGF0ZSIsImNyZWF0ZSIsImxvYWRpbmdDcmVhdGluZyIsInVzZUNyZWF0ZSIsImVycm9yIiwic2V0RXJyb3IiLCJyZWdpc3Rlckxpc3RlbmVyIiwidW5yZWdpc3Rlckxpc3RlbmVyIiwidXBkYXRlUHJvZmlsZSIsImNyZWF0ZVByb2ZpbGUiLCJkaXNtaXNzIiwicmVhc29uIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlRWRpdERyYXdlci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3Byb2ZpbGVzL2NvbXBvbmVudHMvUHJvZmlsZUVkaXREcmF3ZXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBQcm9maWxlRWRpdEZvcm0gfSBmcm9tICcuJ1xuaW1wb3J0IFByb2ZpbGVDb21tYW5kIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Qcm9maWxlQ29tbWFuZCdcbmltcG9ydCB7IEVkaXREcmF3ZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IEFwcERyYXdlclByb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMvZHJhd2VyL0FwcERyYXdlcidcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2Vycm9ycydcbmltcG9ydCB7IHVzZUZvcm1EYXRhLCB1c2VIYW5kbGVSZWplY3Rpb24gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXG5pbXBvcnQgeyBwcm9maWxlUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5cbmludGVyZmFjZSBQcm9maWxlRWRpdFByb3BzIGV4dGVuZHMgUGljazxcbkFwcERyYXdlclByb3BzLFxuJ2lzT3Blbid8J29uRGlzbWlzcydcbj4ge1xuICBwcm9maWxlOiBQcm9maWxlQ29tbWFuZFxuICBpc0NyZWF0aW5nOiBib29sZWFuXG59XG5cbmNvbnN0IFByb2ZpbGVFZGl0RHJhd2VyOiBGQzxQcm9maWxlRWRpdFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGlzT3Blbiwgb25EaXNtaXNzLCBwcm9maWxlLCBpc0NyZWF0aW5nIH0gPSBwcm9wc1xuXG4gIGNvbnN0IHtcbiAgICBmb3JtRGF0YTogbG9jYWxGb3JtRGF0YSxcbiAgICBzZXRGb3JtRGF0YTogc2V0TG9jYWxGb3JtRGF0YSxcbiAgICBvblRleHRDaGFuZ2UsXG4gICAgb25GaWVsZEVycm9yLFxuICB9ID0gdXNlRm9ybURhdGE8UHJvZmlsZUNvbW1hbmQ+KHByb2ZpbGUgYXMgUHJvZmlsZUNvbW1hbmQpXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogc2F2ZSwgaXNMb2FkaW5nOiBpc1NhdmluZyB9ID0gcHJvZmlsZVF1ZXJ5U2VydmljZS51c2VVcGRhdGUoKVxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBjcmVhdGUsIGlzTG9hZGluZzogbG9hZGluZ0NyZWF0aW5nIH0gPSBwcm9maWxlUXVlcnlTZXJ2aWNlLnVzZUNyZWF0ZSgpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8UHJvbWlzZVJlamVjdGlvbkV2ZW50PigpXG4gIGNvbnN0IHtcbiAgICByZWdpc3Rlckxpc3RlbmVyLFxuICAgIHVucmVnaXN0ZXJMaXN0ZW5lcixcbiAgfSA9IHVzZUhhbmRsZVJlamVjdGlvbigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZWdpc3Rlckxpc3RlbmVyKHNldEVycm9yKVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB1bnJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXG4gICAgfVxuICB9LCBbc2V0RXJyb3JdKVxuXG4gIGNvbnN0IHVwZGF0ZVByb2ZpbGUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgc2F2ZShsb2NhbEZvcm1EYXRhKVxuICAgIG9uRGlzbWlzcygpXG4gIH0sIFtsb2NhbEZvcm1EYXRhXSlcblxuICBjb25zdCBjcmVhdGVQcm9maWxlID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNyZWF0ZShsb2NhbEZvcm1EYXRhKVxuICAgIG9uRGlzbWlzcygpXG4gIH0sIFtsb2NhbEZvcm1EYXRhXSlcblxuICBjb25zdCBkaXNtaXNzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIG9uRGlzbWlzcygpXG4gIH0sIFtvbkRpc21pc3NdKVxuXG4gIHJldHVybiAoXG4gICAgPEVkaXREcmF3ZXJcbiAgICAgIHRpdGxlPXtpc0NyZWF0aW5nID8gJ0FkaWNpb25hciBwZXJmaWwnIDogJ0FsdGVyYXIgcGVyZmlsJ31cbiAgICAgIGlzT3Blbj17aXNPcGVufVxuICAgICAgb25EaXNtaXNzPXtkaXNtaXNzfVxuICAgICAgb25TYXZlPXtpc0NyZWF0aW5nID8gY3JlYXRlUHJvZmlsZSA6IHVwZGF0ZVByb2ZpbGV9XG4gICAgICBkaXNhYmxlZD17aXNTYXZpbmcgfHwgbG9hZGluZ0NyZWF0aW5nfVxuICAgICAgbG9hZGluZz17aXNTYXZpbmcgfHwgbG9hZGluZ0NyZWF0aW5nfVxuICAgID5cbiAgICAgIDxQcm9maWxlRWRpdEZvcm1cbiAgICAgICAgbG9jYWxGb3JtRGF0YT17bG9jYWxGb3JtRGF0YX1cbiAgICAgICAgc2V0TG9jYWxGb3JtRGF0YT17c2V0TG9jYWxGb3JtRGF0YX1cbiAgICAgICAgcHJvZmlsZT17cHJvZmlsZX1cbiAgICAgICAgb25UZXh0Q2hhbmdlPXtvblRleHRDaGFuZ2V9XG4gICAgICAgIG9uRmllbGRFcnJvcj17b25GaWVsZEVycm9yfVxuICAgICAgICBhcGlFcnJvcj17ZXJyb3I/LnJlYXNvbiA/IGVycm9yPy5yZWFzb24gYXMgQXBpRXJyb3IgOiB1bmRlZmluZWR9XG4gICAgICAvPlxuICAgIDwvRWRpdERyYXdlcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBQcm9maWxlRWRpdERyYXdlclxuIl19