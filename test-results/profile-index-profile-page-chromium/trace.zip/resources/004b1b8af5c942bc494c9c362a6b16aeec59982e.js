import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/ChipInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChipInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Chips } from "/node_modules/.vite/deps/primereact_chips.js?v=9f90a7ff";
import styled from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
const ChipInput = (props) => {
  const {
    value,
    onChange,
    placeholder,
    disabledValues,
    ...otherProps
  } = props;
  const itemTemplate = (item) => {
    if (disabledValues?.includes(item)) {
      return /* @__PURE__ */ jsxDEV("div", { className: "chips-disabled-item", children: item }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChipInput.tsx",
        lineNumber: 19,
        columnNumber: 14
      }, this);
    }
    return item;
  };
  return /* @__PURE__ */ jsxDEV(ChipsStyles, { placeholder, value, onChange, separator: ",", itemTemplate, ...otherProps }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChipInput.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_c = ChipInput;
const ChipsStyles = styled(Chips)`
  .p-chips-token:has(.p-chips-token-label > .chips-disabled-item) {
    background-color: ${({
  theme
}) => theme.colors.neutralLight[300]};
    color: ${({
  theme
}) => theme.colors.gray[600]};

    .p-chips-token-icon {
      display: none;
    }
  }
`;
_c2 = ChipsStyles;
export default ChipInput;
var _c, _c2;
$RefreshReg$(_c, "ChipInput");
$RefreshReg$(_c2, "ChipsStyles");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChipInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJhO0FBckJiLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGFBQTRDO0FBQ3JELE9BQU9DLFlBQVk7QUFRbkIsTUFBTUMsWUFBaUNDLFdBQVU7QUFDL0MsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0EsR0FBR0M7QUFBQUEsRUFDTCxJQUFJTDtBQUVKLFFBQU1NLGVBQWVBLENBQUNDLFNBQWlCO0FBQ3JDLFFBQUlILGdCQUFnQkksU0FBU0QsSUFBSSxHQUFHO0FBQ2xDLGFBQU8sdUJBQUMsU0FBSSxXQUFVLHVCQUF1QkEsa0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxJQUNwRDtBQUNBLFdBQU9BO0FBQUFBLEVBQ1Q7QUFFQSxTQUNFLHVCQUFDLGVBQ0MsYUFDQSxPQUNBLFVBQ0EsV0FBVSxLQUVWLGNBRUEsR0FBSUYsY0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUWlCO0FBR3JCO0FBQUNJLEtBNUJLVjtBQThCTixNQUFNVyxjQUFjWixPQUFPRCxLQUFLO0FBQUE7QUFBQSx3QkFFUixDQUFDO0FBQUEsRUFBRWM7QUFBTSxNQUFNQSxNQUFNQyxPQUFPQyxhQUFhLEdBQUc7QUFBQSxhQUN2RCxDQUFDO0FBQUEsRUFBRUY7QUFBTSxNQUFNQSxNQUFNQyxPQUFPRSxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNaERDLE1BVEtMO0FBV04sZUFBZVg7QUFBUyxJQUFBVSxJQUFBTTtBQUFBQyxhQUFBUCxJQUFBO0FBQUFPLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJDaGlwcyIsInN0eWxlZCIsIkNoaXBJbnB1dCIsInByb3BzIiwidmFsdWUiLCJvbkNoYW5nZSIsInBsYWNlaG9sZGVyIiwiZGlzYWJsZWRWYWx1ZXMiLCJvdGhlclByb3BzIiwiaXRlbVRlbXBsYXRlIiwiaXRlbSIsImluY2x1ZGVzIiwiX2MiLCJDaGlwc1N0eWxlcyIsInRoZW1lIiwiY29sb3JzIiwibmV1dHJhbExpZ2h0IiwiZ3JheSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNoaXBJbnB1dC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9pbnB1dHMvQ2hpcElucHV0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDaGlwcywgQ2hpcHNDaGFuZ2VQYXJhbXMsIENoaXBzUHJvcHMgfSBmcm9tICdwcmltZXJlYWN0L2NoaXBzJ1xuaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcblxuaW50ZXJmYWNlIENoaXBJbnB1dFByb3BzIGV4dGVuZHMgT21pdDxDaGlwc1Byb3BzLCAndmFsdWUnIHwgJ29uQ2hhbmdlJz4ge1xuICB2YWx1ZT86IHN0cmluZ1tdXG4gIG9uQ2hhbmdlPzogKGU6IENoaXBzQ2hhbmdlUGFyYW1zLCB2YWx1ZT86IHN0cmluZykgPT4gdm9pZFxuICBkaXNhYmxlZFZhbHVlcz86IHN0cmluZ1tdXG59XG5cbmNvbnN0IENoaXBJbnB1dDogRkM8Q2hpcElucHV0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICB2YWx1ZSxcbiAgICBvbkNoYW5nZSxcbiAgICBwbGFjZWhvbGRlcixcbiAgICBkaXNhYmxlZFZhbHVlcyxcbiAgICAuLi5vdGhlclByb3BzXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IGl0ZW1UZW1wbGF0ZSA9IChpdGVtOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoZGlzYWJsZWRWYWx1ZXM/LmluY2x1ZGVzKGl0ZW0pKSB7XG4gICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9J2NoaXBzLWRpc2FibGVkLWl0ZW0nPntpdGVtfTwvZGl2PlxuICAgIH1cbiAgICByZXR1cm4gaXRlbVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Q2hpcHNTdHlsZXNcbiAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cbiAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX1cbiAgICAgIHNlcGFyYXRvcj0nLCdcblxuICAgICAgaXRlbVRlbXBsYXRlPXtpdGVtVGVtcGxhdGV9XG5cbiAgICAgIHsuLi5vdGhlclByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgQ2hpcHNTdHlsZXMgPSBzdHlsZWQoQ2hpcHMpYFxuICAucC1jaGlwcy10b2tlbjpoYXMoLnAtY2hpcHMtdG9rZW4tbGFiZWwgPiAuY2hpcHMtZGlzYWJsZWQtaXRlbSkge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUuY29sb3JzLm5ldXRyYWxMaWdodFszMDBdfTtcbiAgICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5jb2xvcnMuZ3JheVs2MDBdfTtcblxuICAgIC5wLWNoaXBzLXRva2VuLWljb24ge1xuICAgICAgZGlzcGxheTogbm9uZTtcbiAgICB9XG4gIH1cbmBcblxuZXhwb3J0IGRlZmF1bHQgQ2hpcElucHV0XG4iXX0=