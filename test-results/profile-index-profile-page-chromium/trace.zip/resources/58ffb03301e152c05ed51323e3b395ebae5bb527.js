import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { DropdownMenuItemType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport4_react["useState"];
import { Checkbox } from "/src/shared/components/checkbox/index.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
import FlexItem from "/src/shared/components/FlexBox/FlexItem.tsx";
const SelectAllMultiselectComboBox = (props) => {
  _s();
  const [searchText, setSearchText] = useState("");
  function renderOption(option) {
    return option.itemType === DropdownMenuItemType.Header && option.key === "MultiselectHeader" ? /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Selecionar todos", onChange: props.onSelectAll, checked: props.checked, styles: {
      root: {
        marginTop: 14
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx",
      lineNumber: 16,
      columnNumber: 100
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: option.text }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx",
      lineNumber: 22,
      columnNumber: 21
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(ComboBox, { ...props, options: [{
    key: "MultiselectHeader",
    text: "-",
    itemType: DropdownMenuItemType.Header
  }, {
    key: "divider_multiselectHeader",
    text: "-",
    itemType: DropdownMenuItemType.Divider
  }, ...props.options?.map((option) => !option.disabled && option.text.toLowerCase().indexOf(searchText.toLowerCase()) > -1 ? option : {
    ...option,
    hidden: true
  })], onRenderOption: renderOption, onDismiss: () => setSearchText("") }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_s(SelectAllMultiselectComboBox, "lpZkT7pWeo+MC0liMHDzSFPwEJc=");
_c = SelectAllMultiselectComboBox;
export default SelectAllMultiselectComboBox;
var _c;
$RefreshReg$(_c, "SelectAllMultiselectComboBox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SelectAllMultiselectComboBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JRLFNBT0EsVUFQQTs7Ozs7Ozs7Ozs7Ozs7OztBQWxCUixTQUFTQSw0QkFBaUc7QUFDMUcsU0FBd0JDLGdCQUFnQjtBQUN4QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGNBQWM7QUFRckIsTUFBTUMsK0JBQTZEQyxXQUFVO0FBQUFDLEtBQUE7QUFDM0UsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlSLFNBQWlCLEVBQUU7QUFFdkQsV0FBU1MsYUFBY0MsUUFBeUI7QUFDOUMsV0FBUUEsT0FBT0MsYUFBYVoscUJBQXFCYSxVQUFVRixPQUFPRyxRQUFRLHNCQUN0RSx1QkFBQyxZQUFTLE1BQU0sR0FDaEIsaUNBQUMsWUFDQyxPQUFNLG9CQUNOLFVBQVVSLE1BQU1TLGFBQ2hCLFNBQVNULE1BQU1VLFNBQ2YsUUFBUTtBQUFBLE1BQUVDLE1BQU07QUFBQSxRQUFFQyxXQUFXO0FBQUEsTUFBRztBQUFBLElBQUUsS0FKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlzQyxLQUx0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0YsSUFDRSxtQ0FBR1AsaUJBQU9RLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDckI7QUFFQSxTQUNFLHVCQUFDLFlBQ0MsR0FBSWIsT0FDSixTQUFTLENBQ1A7QUFBQSxJQUFFUSxLQUFLO0FBQUEsSUFBcUJLLE1BQU07QUFBQSxJQUFLUCxVQUFVWixxQkFBcUJhO0FBQUFBLEVBQU8sR0FDN0U7QUFBQSxJQUFFQyxLQUFLO0FBQUEsSUFBNkJLLE1BQU07QUFBQSxJQUFLUCxVQUFVWixxQkFBcUJvQjtBQUFBQSxFQUFRLEdBQ3RGLEdBQUdkLE1BQU1lLFNBQVNDLElBQUlYLFlBQVUsQ0FBQ0EsT0FBT1ksWUFBWVosT0FBT1EsS0FBS0ssWUFBWSxFQUFFQyxRQUFRakIsV0FBV2dCLFlBQVksQ0FBQyxJQUFJLEtBQzlHYixTQUNBO0FBQUEsSUFBRSxHQUFHQTtBQUFBQSxJQUFRZSxRQUFRO0FBQUEsRUFBSyxDQUM5QixDQUFDLEdBRUgsZ0JBQWdCaEIsY0FDaEIsV0FBVyxNQUFNRCxjQUFjLEVBQUUsS0FYbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdxQztBQUd6QztBQUFDRixHQS9CS0YsOEJBQXlEO0FBQUFzQixLQUF6RHRCO0FBaUNOLGVBQWVBO0FBQTRCLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRHJvcGRvd25NZW51SXRlbVR5cGUiLCJ1c2VTdGF0ZSIsIkNoZWNrYm94IiwiQ29tYm9Cb3giLCJGbGV4SXRlbSIsIlNlbGVjdEFsbE11bHRpc2VsZWN0Q29tYm9Cb3giLCJwcm9wcyIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJyZW5kZXJPcHRpb24iLCJvcHRpb24iLCJpdGVtVHlwZSIsIkhlYWRlciIsImtleSIsIm9uU2VsZWN0QWxsIiwiY2hlY2tlZCIsInJvb3QiLCJtYXJnaW5Ub3AiLCJ0ZXh0IiwiRGl2aWRlciIsIm9wdGlvbnMiLCJtYXAiLCJkaXNhYmxlZCIsInRvTG93ZXJDYXNlIiwiaW5kZXhPZiIsImhpZGRlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2VsZWN0QWxsTXVsdGlzZWxlY3RDb21ib0JveC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kcm9wZG93bnNDb21ib0JveGVzL1NlbGVjdEFsbE11bHRpc2VsZWN0Q29tYm9Cb3gudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRHJvcGRvd25NZW51SXRlbVR5cGUsIElDb21ib0JveE9wdGlvbiwgSUNvbWJvQm94UHJvcHMsIElSZW5kZXJGdW5jdGlvbiwgSVNlbGVjdGFibGVPcHRpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCBGb3JtRXZlbnQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IENoZWNrYm94IH0gZnJvbSAnLi4vY2hlY2tib3gnXHJcbmltcG9ydCB7IENvbWJvQm94IH0gZnJvbSAnLi4vY29tYm9Cb3gnXHJcbmltcG9ydCBGbGV4SXRlbSBmcm9tICcuLy4uL0ZsZXhCb3gvRmxleEl0ZW0nXHJcblxyXG5pbnRlcmZhY2UgU2VhcmNoYWJsZURyb3Bkb3duUHJvcHMgZXh0ZW5kcyBJQ29tYm9Cb3hQcm9wc3tcclxuICBhdXRvRHJvcGRvd25XaWR0aD86IGJvb2xlYW5cclxuICBvblNlbGVjdEFsbD86ICgoZXY/OiBGb3JtRXZlbnQ8SFRNTEVsZW1lbnQgfCBIVE1MSW5wdXRFbGVtZW50PiB8IHVuZGVmaW5lZCwgY2hlY2tlZD86IGJvb2xlYW4gfCB1bmRlZmluZWQpID0+IHZvaWQpIHwgdW5kZWZpbmVkXHJcbiAgY2hlY2tlZDogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBTZWxlY3RBbGxNdWx0aXNlbGVjdENvbWJvQm94OiBGQzxTZWFyY2hhYmxlRHJvcGRvd25Qcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKVxyXG5cclxuICBmdW5jdGlvbiByZW5kZXJPcHRpb24gKG9wdGlvbjogSUNvbWJvQm94T3B0aW9uKSB7XHJcbiAgICByZXR1cm4gKG9wdGlvbi5pdGVtVHlwZSA9PT0gRHJvcGRvd25NZW51SXRlbVR5cGUuSGVhZGVyICYmIG9wdGlvbi5rZXkgPT09ICdNdWx0aXNlbGVjdEhlYWRlcicpXHJcbiAgICAgID8gPEZsZXhJdGVtIGdyb3c9ezF9PlxyXG4gICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgbGFiZWw9J1NlbGVjaW9uYXIgdG9kb3MnXHJcbiAgICAgICAgICBvbkNoYW5nZT17cHJvcHMub25TZWxlY3RBbGx9XHJcbiAgICAgICAgICBjaGVja2VkPXtwcm9wcy5jaGVja2VkfVxyXG4gICAgICAgICAgc3R5bGVzPXt7IHJvb3Q6IHsgbWFyZ2luVG9wOiAxNCB9IH19XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9GbGV4SXRlbT5cclxuICAgICAgOiA8PntvcHRpb24udGV4dH08Lz5cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29tYm9Cb3hcclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdNdWx0aXNlbGVjdEhlYWRlcicsIHRleHQ6ICctJywgaXRlbVR5cGU6IERyb3Bkb3duTWVudUl0ZW1UeXBlLkhlYWRlciB9LFxyXG4gICAgICAgIHsga2V5OiAnZGl2aWRlcl9tdWx0aXNlbGVjdEhlYWRlcicsIHRleHQ6ICctJywgaXRlbVR5cGU6IERyb3Bkb3duTWVudUl0ZW1UeXBlLkRpdmlkZXIgfSxcclxuICAgICAgICAuLi5wcm9wcy5vcHRpb25zPy5tYXAob3B0aW9uID0+ICFvcHRpb24uZGlzYWJsZWQgJiYgb3B0aW9uLnRleHQudG9Mb3dlckNhc2UoKS5pbmRleE9mKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSkgPiAtMVxyXG4gICAgICAgICAgPyBvcHRpb25cclxuICAgICAgICAgIDogeyAuLi5vcHRpb24sIGhpZGRlbjogdHJ1ZSB9LFxyXG4gICAgICAgICksXHJcbiAgICAgIF19XHJcbiAgICAgIG9uUmVuZGVyT3B0aW9uPXtyZW5kZXJPcHRpb24gYXMgSVJlbmRlckZ1bmN0aW9uPElTZWxlY3RhYmxlT3B0aW9uPn1cclxuICAgICAgb25EaXNtaXNzPXsoKSA9PiBzZXRTZWFyY2hUZXh0KCcnKX1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWxlY3RBbGxNdWx0aXNlbGVjdENvbWJvQm94XHJcbiJdfQ==