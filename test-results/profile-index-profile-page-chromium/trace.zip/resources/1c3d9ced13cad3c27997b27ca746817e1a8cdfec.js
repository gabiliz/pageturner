import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAccountConfigurationModal.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { mergeStyleSets, Label, Text, FontIcon, MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { Link, Modal, PrimaryButton, DefaultButton, FlexColumn, FlexItem, FlexRow } from "/src/shared/components/index.ts?t=1701096626433";
import { userService } from "/src/modules/admin/users/services/index.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { UserAccountConfigurationForgotPasswordFormForm, UserAccountConfigurationForm } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { authService } from "/src/modules/auth/services/index.ts";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
const UserAccountConfigurationModal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    onAccept,
    setImage
  } = props;
  const styles = useStyles();
  const {
    currentAccount
  } = useAuth();
  const [data] = useState({
    id: currentAccount.value?.id,
    nome: currentAccount.value?.nome,
    email: currentAccount.value?.email,
    image: currentAccount.value?.image,
    apelido: currentAccount.value?.apelido,
    desenvolvedor: currentAccount.value?.desenvolvedor,
    cargos: [{
      cargo: {
        nome: currentAccount.value?.cargo
      }
    }]
  });
  const [isUpdating, setIsUpdating] = useState(false);
  const {
    formData: userFormData,
    onTextChange: onNameChange,
    setFormData: setUserFormData
  } = useFormData({
    id: data.id,
    image: data.image,
    nome: data.nome
  });
  const {
    formData: passwordFormData,
    onTextChange: onPasswordChange,
    setFormData: setPasswordChange
  } = useFormData({
    currentPassword: "",
    newPassword: "",
    repeatNewPassword: ""
  });
  const {
    showNotification
  } = useNotifications();
  const [changePasswordVisible, {
    toggle: toggleChangePaswordVisible
  }] = useBoolean(false);
  useEffect(() => {
    setUserFormData({
      ...data,
      id: data.id,
      image: data.image,
      nome: data.nome
    });
    setImage(data?.image);
  }, [data]);
  const removeImage = useCallback(() => {
    setUserFormData({
      ...userFormData,
      image: ""
    });
  }, [userFormData]);
  const saveUser = useCallback(async () => {
    setIsUpdating(true);
    await userService.updateConfig(userFormData);
    setIsUpdating(false);
    showNotification({
      message: "Atualizado com sucesso!",
      type: MessageBarType.success,
      timeout: 1e4
    });
    onDismiss();
    onAccept?.();
  }, [userFormData]);
  const savePassword = useCallback(async () => {
    await authService.changePasswordLogged({
      ...passwordFormData,
      id: currentAccount.value?.id
    });
    setPasswordChange({
      currentPassword: "",
      newPassword: "",
      repeatNewPassword: ""
    });
    toggleChangePaswordVisible();
    showNotification({
      message: "Senha alterada com sucesso",
      type: MessageBarType.success,
      timeout: 1e4
    });
    onAccept?.();
  }, [passwordFormData]);
  const dismiss = useCallback(() => {
    if (changePasswordVisible) {
      toggleChangePaswordVisible();
      setPasswordChange({
        currentPassword: "",
        newPassword: "",
        repeatNewPassword: ""
      });
    } else {
      setUserFormData((oldUser) => {
        return {
          ...oldUser,
          image: currentAccount.value?.image
        };
      });
      onDismiss();
    }
  }, [changePasswordVisible]);
  const disableSave = useCallback(() => {
    if (!changePasswordVisible) {
      return isUpdating;
    } else {
      return passwordFormData.currentPassword.length === 0 || !/([a-z])/.test(passwordFormData.newPassword) || !/([A-Z])/.test(passwordFormData.newPassword) || !/([0-9])/.test(passwordFormData.newPassword) || !/[-+_!@#$%^&*., ?]/.test(passwordFormData.newPassword) || passwordFormData.newPassword !== passwordFormData.repeatNewPassword || passwordFormData.newPassword.length < 6;
    }
  }, [isUpdating, passwordFormData, changePasswordVisible]);
  return /* @__PURE__ */ jsxDEV(Modal, { isOpen, onDismiss: dismiss, title: changePasswordVisible ? "Alterar senha" : "Minhas configurações", children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    !changePasswordVisible && /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
      /* @__PURE__ */ jsxDEV(UserAccountConfigurationForm, { userFormData, onTextChange: onNameChange, removeImage }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 144,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Senha" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 146,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { onClick: toggleChangePaswordVisible, children: "Alterar a senha" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 147,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 145,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
      lineNumber: 143,
      columnNumber: 36
    }, this),
    changePasswordVisible && /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, verticalAlign: "flex-start", width: "100%", children: [
      /* @__PURE__ */ jsxDEV(UserAccountConfigurationForgotPasswordFormForm, { passwordFormData, onTextChange: onPasswordChange }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 153,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Label, { children: "Como criar uma senha mais segura" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 154,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: !/([0-9])/.test(passwordFormData.newPassword) ? "LocationCircle" : "SkypeCircleCheck", className: !/([0-9])/.test(passwordFormData.newPassword) ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 156,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Pelo menos 1 número" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 157,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 155,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: !/([a-z])/.test(passwordFormData.newPassword) ? "LocationCircle" : "SkypeCircleCheck", className: !/([a-z])/.test(passwordFormData.newPassword) ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 162,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Pelo menos 1 letra minúscula" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 163,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 161,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: !/([A-Z])/.test(passwordFormData.newPassword) ? "LocationCircle" : "SkypeCircleCheck", className: !/([A-Z])/.test(passwordFormData.newPassword) ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 168,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Pelo menos 1 letra maiúscula" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 169,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 167,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: !/[-+_!@#$%^&*., ?]/.test(passwordFormData.newPassword) ? "LocationCircle" : "SkypeCircleCheck", className: !/[-+_!@#$%^&*., ?]/.test(passwordFormData.newPassword) ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 174,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Pelo menos 1 símbolo" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 175,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 173,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: passwordFormData.newPassword.length < 6 ? "LocationCircle" : "SkypeCircleCheck", className: passwordFormData.newPassword.length < 6 ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 180,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Pelo menos 6 caracteres" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 181,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 179,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, children: [
        /* @__PURE__ */ jsxDEV(FontIcon, { iconName: passwordFormData.newPassword !== passwordFormData.repeatNewPassword || passwordFormData.newPassword.length === 0 ? "LocationCircle" : "SkypeCircleCheck", className: passwordFormData.newPassword !== passwordFormData.repeatNewPassword || passwordFormData.newPassword.length === 0 ? styles.uncheckedIcon : styles.checkedIcon }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 186,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: "Nova senha = confirmação de nova senha" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
          lineNumber: 187,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 185,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
      lineNumber: 152,
      columnNumber: 35
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actions, children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Cancelar", onClick: () => dismiss(), disabled: isUpdating }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Salvar", onClick: changePasswordVisible ? savePassword : saveUser, disabled: disableSave() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
        lineNumber: 194,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
      lineNumber: 192,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
    lineNumber: 142,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx",
    lineNumber: 141,
    columnNumber: 10
  }, this);
};
_s(UserAccountConfigurationModal, "JHeN/EwmHhvOx/CL0csfSOopR44=", false, function() {
  return [useStyles, useAuth, useFormData, useFormData, useNotifications, useBoolean];
});
_c = UserAccountConfigurationModal;
export default UserAccountConfigurationModal;
const useStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    paragraph: {
      color: colors.gray[600],
      display: "block",
      marginBottom: spacing.lg,
      selectors: {
        "&:last-of-type": {
          marginBottom: spacing.xxl
        }
      }
    },
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 12,
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    },
    checkedIcon: {
      color: colors.green[500],
      width: 12,
      height: 12
    },
    uncheckedIcon: {
      borderRadius: "50%",
      width: 12,
      height: 12
    }
  });
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
var _c;
$RefreshReg$(_c, "UserAccountConfigurationModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0lNLG1CQUdNLGNBSE47Ozs7Ozs7Ozs7Ozs7Ozs7QUEvSU4sU0FBdUNBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUMvRSxTQUFTQyxnQkFBZ0JDLE9BQU9DLE1BQU1DLFVBQVVDLHNCQUFzQjtBQUN0RSxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsTUFBTUMsT0FBbUJDLGVBQWVDLGVBQWVDLFlBQVlDLFVBQVVDLGVBQWU7QUFDckcsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLGdEQUFnREMsb0NBQW9DO0FBRTdGLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyx3QkFBd0I7QUFZakMsTUFBTUMsZ0NBQXlFQyxXQUFVO0FBQUFDLEtBQUE7QUFDdkYsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVdDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVMsSUFBSUw7QUFDbEQsUUFBTU0sU0FBU0MsVUFBVTtBQUN6QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBZSxJQUFJaEIsUUFBUTtBQUVuQyxRQUFNLENBQUNpQixJQUFJLElBQUloQyxTQUNiO0FBQUEsSUFDRWlDLElBQUlGLGVBQWVHLE9BQU9EO0FBQUFBLElBQzFCRSxNQUFNSixlQUFlRyxPQUFPQztBQUFBQSxJQUM1QkMsT0FBT0wsZUFBZUcsT0FBT0U7QUFBQUEsSUFDN0JDLE9BQU9OLGVBQWVHLE9BQU9HO0FBQUFBLElBQzdCQyxTQUFTUCxlQUFlRyxPQUFPSTtBQUFBQSxJQUMvQkMsZUFBZVIsZUFBZUcsT0FBT0s7QUFBQUEsSUFDckNDLFFBQVEsQ0FBQztBQUFBLE1BQ1BDLE9BQU87QUFBQSxRQUNMTixNQUFNSixlQUFlRyxPQUFPTztBQUFBQSxNQUM5QjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBa0I7QUFDcEIsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUkzQyxTQUFrQixLQUFLO0FBRTNELFFBQU07QUFBQSxJQUNKNEMsVUFBVUM7QUFBQUEsSUFDVkMsY0FBY0M7QUFBQUEsSUFDZEMsYUFBYUM7QUFBQUEsRUFDZixJQUFJakMsWUFBWTtBQUFBLElBQUVpQixJQUFJRCxLQUFLQztBQUFBQSxJQUFJSSxPQUFPTCxLQUFLSztBQUFBQSxJQUFPRixNQUFNSCxLQUFLRztBQUFBQSxFQUFLLENBQWtCO0FBQ3BGLFFBQU07QUFBQSxJQUNKUyxVQUFVTTtBQUFBQSxJQUNWSixjQUFjSztBQUFBQSxJQUNkSCxhQUFhSTtBQUFBQSxFQUNmLElBQUlwQyxZQUFZO0FBQUEsSUFDZHFDLGlCQUFpQjtBQUFBLElBQ2pCQyxhQUFhO0FBQUEsSUFDYkMsbUJBQW1CO0FBQUEsRUFDckIsQ0FBNEI7QUFDNUIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQWlCLElBQUluQyxpQkFBaUI7QUFFOUMsUUFBTSxDQUNKb0MsdUJBQ0E7QUFBQSxJQUFFQyxRQUFRQztBQUFBQSxFQUEyQixDQUFDLElBQ3BDckQsV0FBVyxLQUFLO0FBRXBCUCxZQUFVLE1BQU07QUFDZGtELG9CQUFnQjtBQUFBLE1BQUUsR0FBR2pCO0FBQUFBLE1BQU1DLElBQUlELEtBQUtDO0FBQUFBLE1BQUlJLE9BQU9MLEtBQUtLO0FBQUFBLE1BQU9GLE1BQU1ILEtBQUtHO0FBQUFBLElBQUssQ0FBQztBQUM1RVAsYUFBU0ksTUFBTUssS0FBZTtBQUFBLEVBQ2hDLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDO0FBRVQsUUFBTTRCLGNBQWM5RCxZQUFZLE1BQU07QUFDcENtRCxvQkFBZ0I7QUFBQSxNQUNkLEdBQUdKO0FBQUFBLE1BQ0hSLE9BQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ1EsWUFBWSxDQUFDO0FBRWpCLFFBQU1nQixXQUFXL0QsWUFBWSxZQUFZO0FBQ3ZDNkMsa0JBQWMsSUFBSTtBQUNsQixVQUFNN0IsWUFBWWdELGFBQWFqQixZQUFvQjtBQUNuREYsa0JBQWMsS0FBSztBQUNuQmEscUJBQWlCO0FBQUEsTUFDZk8sU0FBUztBQUFBLE1BQ1RDLE1BQU0zRCxlQUFlNEQ7QUFBQUEsTUFDckJDLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRHhDLGNBQVU7QUFDVkMsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDa0IsWUFBWSxDQUFDO0FBRWpCLFFBQU1zQixlQUFlckUsWUFBWSxZQUFZO0FBQzNDLFVBQU1zQixZQUFZZ0QscUJBQXFCO0FBQUEsTUFBRSxHQUFHbEI7QUFBQUEsTUFBa0JqQixJQUFJRixlQUFlRyxPQUFPRDtBQUFBQSxJQUFHLENBQUM7QUFDNUZtQixzQkFBa0I7QUFBQSxNQUNoQkMsaUJBQWlCO0FBQUEsTUFDakJDLGFBQWE7QUFBQSxNQUNiQyxtQkFBbUI7QUFBQSxJQUNyQixDQUE0QjtBQUM1QkksK0JBQTJCO0FBQzNCSCxxQkFBaUI7QUFBQSxNQUNmTyxTQUFTO0FBQUEsTUFDVEMsTUFBTTNELGVBQWU0RDtBQUFBQSxNQUNyQkMsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNEdkMsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDdUIsZ0JBQWdCLENBQUM7QUFFckIsUUFBTW1CLFVBQVV2RSxZQUFZLE1BQU07QUFDaEMsUUFBSTJELHVCQUF1QjtBQUN6QkUsaUNBQTJCO0FBQzNCUCx3QkFBa0I7QUFBQSxRQUNoQkMsaUJBQWlCO0FBQUEsUUFDakJDLGFBQWE7QUFBQSxRQUNiQyxtQkFBbUI7QUFBQSxNQUNyQixDQUE0QjtBQUFBLElBQzlCLE9BQU87QUFDTE4sc0JBQWdCcUIsYUFBVztBQUN6QixlQUFPO0FBQUEsVUFBRSxHQUFHQTtBQUFBQSxVQUFTakMsT0FBT04sZUFBZUcsT0FBT0c7QUFBQUEsUUFBTTtBQUFBLE1BQzFELENBQUM7QUFDRFgsZ0JBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRixHQUFHLENBQUMrQixxQkFBcUIsQ0FBQztBQUUxQixRQUFNYyxjQUFjekUsWUFBWSxNQUFNO0FBQ3BDLFFBQUksQ0FBQzJELHVCQUF1QjtBQUMxQixhQUFPZjtBQUFBQSxJQUNULE9BQU87QUFDTCxhQUFRUSxpQkFBaUJHLGdCQUFnQm1CLFdBQVcsS0FDcEQsQ0FBRSxVQUFXQyxLQUFLdkIsaUJBQWlCSSxXQUFXLEtBQzlDLENBQUUsVUFBV21CLEtBQUt2QixpQkFBaUJJLFdBQVcsS0FDOUMsQ0FBRSxVQUFXbUIsS0FBS3ZCLGlCQUFpQkksV0FBVyxLQUM5QyxDQUFFLG9CQUFxQm1CLEtBQUt2QixpQkFBaUJJLFdBQVcsS0FDeERKLGlCQUFpQkksZ0JBQWdCSixpQkFBaUJLLHFCQUFxQkwsaUJBQWlCSSxZQUFZa0IsU0FBUztBQUFBLElBQy9HO0FBQUEsRUFDRixHQUFHLENBQUM5QixZQUFZUSxrQkFBa0JPLHFCQUFxQixDQUFDO0FBRXhELFNBQ0csdUJBQUMsU0FDQSxRQUNBLFdBQVdZLFNBQ1gsT0FBT1osd0JBQ0gsa0JBQ0Esd0JBRUosNkNBQ0c7QUFBQSxLQUFDQSx5QkFDQSx1QkFBQyxjQUFXLEtBQU0sSUFDaEI7QUFBQSw2QkFBQyxnQ0FDQyxjQUNBLGNBQWNWLGNBQ2QsZUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzJCO0FBQUEsTUFFM0IsdUJBQUMsWUFDQztBQUFBLCtCQUFDLFNBQU0scUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFDWix1QkFBQyxRQUFLLFNBQVNZLDRCQUE0QiwrQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0RGLHlCQUNDLHVCQUFDLGNBQVcsS0FBTSxJQUFLLGVBQWMsY0FBYSxPQUFPLFFBQ3ZEO0FBQUEsNkJBQUMsa0RBQ0Msa0JBQ0EsY0FBY04sb0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFaUM7QUFBQSxNQUVqQyx1QkFBQyxTQUFNLGdEQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUN2Qyx1QkFBQyxXQUNDLGVBQWMsVUFDZCxLQUFNLElBRU47QUFBQSwrQkFBQyxZQUNDLFVBQ0UsQ0FBRSxVQUFXc0IsS0FBS3ZCLGlCQUFpQkksV0FBVyxJQUMxQyxtQkFDQSxvQkFFTixXQUNFLENBQUUsVUFBV21CLEtBQUt2QixpQkFBaUJJLFdBQVcsSUFDMUN6QixPQUFPNkMsZ0JBQ1A3QyxPQUFPOEMsZUFUZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUc7QUFBQSxRQUVILHVCQUFDLFFBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BQ0EsdUJBQUMsV0FDQyxlQUFjLFVBQ2QsS0FBTSxJQUVOO0FBQUEsK0JBQUMsWUFDQyxVQUNFLENBQUUsVUFBV0YsS0FBS3ZCLGlCQUFpQkksV0FBVyxJQUMxQyxtQkFDQSxvQkFFTixXQUNFLENBQUUsVUFBV21CLEtBQUt2QixpQkFBaUJJLFdBQVcsSUFDMUN6QixPQUFPNkMsZ0JBQ1A3QyxPQUFPOEMsZUFUZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUc7QUFBQSxRQUVILHVCQUFDLFFBQUssNENBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BQ0EsdUJBQUMsV0FDQyxlQUFjLFVBQ2QsS0FBTSxJQUVOO0FBQUEsK0JBQUMsWUFDQyxVQUNFLENBQUUsVUFBV0YsS0FBS3ZCLGlCQUFpQkksV0FBVyxJQUMxQyxtQkFDQSxvQkFFTixXQUNFLENBQUUsVUFBV21CLEtBQUt2QixpQkFBaUJJLFdBQVcsSUFDMUN6QixPQUFPNkMsZ0JBQ1A3QyxPQUFPOEMsZUFUZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUc7QUFBQSxRQUVILHVCQUFDLFFBQUssNENBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BQ0EsdUJBQUMsV0FDQyxlQUFjLFVBQ2QsS0FBTSxJQUVOO0FBQUEsK0JBQUMsWUFDQyxVQUNFLENBQUUsb0JBQXFCRixLQUFLdkIsaUJBQWlCSSxXQUFXLElBQ3BELG1CQUNBLG9CQUVOLFdBQ0UsQ0FBRSxvQkFBcUJtQixLQUFLdkIsaUJBQWlCSSxXQUFXLElBQ3BEekIsT0FBTzZDLGdCQUNQN0MsT0FBTzhDLGVBVGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVHO0FBQUEsUUFFSCx1QkFBQyxRQUFLLG9DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxNQUNBLHVCQUFDLFdBQ0MsZUFBYyxVQUNkLEtBQU0sSUFFTjtBQUFBLCtCQUFDLFlBQ0MsVUFDRXpCLGlCQUFpQkksWUFBWWtCLFNBQVMsSUFDbEMsbUJBQ0Esb0JBRU4sV0FDRXRCLGlCQUFpQkksWUFBWWtCLFNBQVMsSUFDbEMzQyxPQUFPNkMsZ0JBQ1A3QyxPQUFPOEMsZUFUZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUc7QUFBQSxRQUVILHVCQUFDLFFBQUssdUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BQ0EsdUJBQUMsV0FDQyxlQUFjLFVBQ2QsS0FBTSxJQUVOO0FBQUEsK0JBQUMsWUFDQyxVQUNFekIsaUJBQWlCSSxnQkFBZ0JKLGlCQUFpQksscUJBQ2xETCxpQkFBaUJJLFlBQVlrQixXQUFXLElBQ3BDLG1CQUNBLG9CQUVOLFdBQ0V0QixpQkFBaUJJLGdCQUFnQkosaUJBQWlCSyxxQkFDbERMLGlCQUFpQkksWUFBWWtCLFdBQVcsSUFDcEMzQyxPQUFPNkMsZ0JBQ1A3QyxPQUFPOEMsZUFYZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUc7QUFBQSxRQUVILHVCQUFDLFFBQUssc0RBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBL0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnSUE7QUFBQSxJQUNGLHVCQUFDLFNBQUksV0FBVzlDLE9BQU8rQyxTQUNyQjtBQUFBLDZCQUFDLGlCQUNDLE1BQU8sWUFDUCxTQUFXLE1BQU1QLFFBQVEsR0FDekIsVUFBVTNCLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUd1QjtBQUFBLE1BRXZCLHVCQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTZSx3QkFBd0JVLGVBQWVOLFVBQ2hELFVBQVVVLFlBQVksS0FIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUcwQjtBQUFBLFNBVDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLE9BNUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2SkEsS0FwS0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFLRDtBQUVKO0FBQUMvQyxHQXhSS0YsK0JBQXFFO0FBQUEsVUFFMURRLFdBQ1lmLFNBc0J2QkMsYUFLQUEsYUFLeUJLLGtCQUt6QmYsVUFBVTtBQUFBO0FBQUF1RSxLQXhDVnZEO0FBMFJOLGVBQWVBO0FBRWYsTUFBTVEsWUFBWUEsTUFBTTtBQUFBZ0QsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBU0M7QUFBQUEsRUFBTyxJQUFJL0QsU0FBUztBQUVyQyxTQUFPaEIsZUFBZTtBQUFBLElBQ3BCZ0YsV0FBVztBQUFBLE1BQ1RDLE9BQU9GLE9BQU9HLEtBQUssR0FBRztBQUFBLE1BQ3RCQyxTQUFTO0FBQUEsTUFDVEMsY0FBY04sUUFBUU87QUFBQUEsTUFDdEJDLFdBQVc7QUFBQSxRQUNULGtCQUFrQjtBQUFBLFVBQ2hCRixjQUFjTixRQUFRUztBQUFBQSxRQUN4QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQVosU0FBUztBQUFBLE1BQ1BRLFNBQVM7QUFBQSxNQUNUSyxnQkFBZ0I7QUFBQSxNQUNoQkMsV0FBVztBQUFBLE1BQ1hILFdBQVc7QUFBQSxRQUNULHlCQUF5QjtBQUFBLFVBQ3ZCSSxhQUFhWixRQUFRTztBQUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQVgsYUFBYTtBQUFBLE1BQ1hPLE9BQU9GLE9BQU9ZLE1BQU0sR0FBRztBQUFBLE1BQ3ZCQyxPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBcEIsZUFBZTtBQUFBLE1BQ2JxQixjQUFjO0FBQUEsTUFDZEYsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ2hCLElBbkNLaEQsV0FBUztBQUFBLFVBQ2ViLFFBQVE7QUFBQTtBQUFBLElBQUE0RDtBQUFBbUIsYUFBQW5CLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwibWVyZ2VTdHlsZVNldHMiLCJMYWJlbCIsIlRleHQiLCJGb250SWNvbiIsIk1lc3NhZ2VCYXJUeXBlIiwidXNlQm9vbGVhbiIsIkxpbmsiLCJNb2RhbCIsIlByaW1hcnlCdXR0b24iLCJEZWZhdWx0QnV0dG9uIiwiRmxleENvbHVtbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsInVzZXJTZXJ2aWNlIiwidXNlQXV0aCIsInVzZUZvcm1EYXRhIiwidXNlVGhlbWUiLCJVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3Jnb3RQYXNzd29yZEZvcm1Gb3JtIiwiVXNlckFjY291bnRDb25maWd1cmF0aW9uRm9ybSIsImF1dGhTZXJ2aWNlIiwidXNlTm90aWZpY2F0aW9ucyIsIlVzZXJBY2NvdW50Q29uZmlndXJhdGlvbk1vZGFsIiwicHJvcHMiLCJfcyIsImlzT3BlbiIsIm9uRGlzbWlzcyIsIm9uQWNjZXB0Iiwic2V0SW1hZ2UiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJjdXJyZW50QWNjb3VudCIsImRhdGEiLCJpZCIsInZhbHVlIiwibm9tZSIsImVtYWlsIiwiaW1hZ2UiLCJhcGVsaWRvIiwiZGVzZW52b2x2ZWRvciIsImNhcmdvcyIsImNhcmdvIiwiaXNVcGRhdGluZyIsInNldElzVXBkYXRpbmciLCJmb3JtRGF0YSIsInVzZXJGb3JtRGF0YSIsIm9uVGV4dENoYW5nZSIsIm9uTmFtZUNoYW5nZSIsInNldEZvcm1EYXRhIiwic2V0VXNlckZvcm1EYXRhIiwicGFzc3dvcmRGb3JtRGF0YSIsIm9uUGFzc3dvcmRDaGFuZ2UiLCJzZXRQYXNzd29yZENoYW5nZSIsImN1cnJlbnRQYXNzd29yZCIsIm5ld1Bhc3N3b3JkIiwicmVwZWF0TmV3UGFzc3dvcmQiLCJzaG93Tm90aWZpY2F0aW9uIiwiY2hhbmdlUGFzc3dvcmRWaXNpYmxlIiwidG9nZ2xlIiwidG9nZ2xlQ2hhbmdlUGFzd29yZFZpc2libGUiLCJyZW1vdmVJbWFnZSIsInNhdmVVc2VyIiwidXBkYXRlQ29uZmlnIiwibWVzc2FnZSIsInR5cGUiLCJzdWNjZXNzIiwidGltZW91dCIsInNhdmVQYXNzd29yZCIsImNoYW5nZVBhc3N3b3JkTG9nZ2VkIiwiZGlzbWlzcyIsIm9sZFVzZXIiLCJkaXNhYmxlU2F2ZSIsImxlbmd0aCIsInRlc3QiLCJ1bmNoZWNrZWRJY29uIiwiY2hlY2tlZEljb24iLCJhY3Rpb25zIiwiX2MiLCJfczIiLCJzcGFjaW5nIiwiY29sb3JzIiwicGFyYWdyYXBoIiwiY29sb3IiLCJncmF5IiwiZGlzcGxheSIsIm1hcmdpbkJvdHRvbSIsImxnIiwic2VsZWN0b3JzIiwieHhsIiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Ub3AiLCJtYXJnaW5SaWdodCIsImdyZWVuIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Nb2RhbC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlckFjY291bnRDb25maWd1cmF0aW9uTW9kYWwudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlzcGF0Y2gsIEZDLCBTZXRTdGF0ZUFjdGlvbiwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMsIExhYmVsLCBUZXh0LCBGb250SWNvbiwgTWVzc2FnZUJhclR5cGUgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZUJvb2xlYW4gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtaG9va3MnXHJcbmltcG9ydCB7IExpbmssIE1vZGFsLCBNb2RhbFByb3BzLCBQcmltYXJ5QnV0dG9uLCBEZWZhdWx0QnV0dG9uLCBGbGV4Q29sdW1uLCBGbGV4SXRlbSwgRmxleFJvdyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VyU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zdG9yZS9hdXRoJ1xyXG5pbXBvcnQgeyB1c2VGb3JtRGF0YSwgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybUZvcm0sIFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcm0gfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyBDaGFuZ2VQYXNzd29yZExvZ2dlZERUTyB9IGZyb20gJy4uLy4uLy4uL2F1dGgvZW50aXRpZXMnXHJcbmltcG9ydCB7IGF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zZXJ2aWNlcydcclxuaW1wb3J0IFVzZXIgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXInXHJcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xyXG5pbXBvcnQgVXNlclJvbGUgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXJSb2xlJ1xyXG5cclxuaW50ZXJmYWNlIFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbk1vZGFsUHJvcHMgZXh0ZW5kcyBQaWNrPFxyXG5Nb2RhbFByb3BzLFxyXG4naXNPcGVuJ3wnb25EaXNtaXNzJ1xyXG4+IHtcclxuICBvblJlamVjdD86ICgpID0+IHZvaWRcclxuICBvbkFjY2VwdD86ICgpID0+IHZvaWRcclxuICBzZXRJbWFnZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj5cclxufVxyXG5cclxuY29uc3QgVXNlckFjY291bnRDb25maWd1cmF0aW9uTW9kYWw6IEZDPFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbk1vZGFsUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBpc09wZW4sIG9uRGlzbWlzcywgb25BY2NlcHQsIHNldEltYWdlIH0gPSBwcm9wc1xyXG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcygpXHJcbiAgY29uc3QgeyBjdXJyZW50QWNjb3VudCB9ID0gdXNlQXV0aCgpXHJcblxyXG4gIGNvbnN0IFtkYXRhXSA9IHVzZVN0YXRlKFxyXG4gICAge1xyXG4gICAgICBpZDogY3VycmVudEFjY291bnQudmFsdWU/LmlkLFxyXG4gICAgICBub21lOiBjdXJyZW50QWNjb3VudC52YWx1ZT8ubm9tZSxcclxuICAgICAgZW1haWw6IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5lbWFpbCxcclxuICAgICAgaW1hZ2U6IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5pbWFnZSxcclxuICAgICAgYXBlbGlkbzogY3VycmVudEFjY291bnQudmFsdWU/LmFwZWxpZG8sXHJcbiAgICAgIGRlc2Vudm9sdmVkb3I6IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5kZXNlbnZvbHZlZG9yLFxyXG4gICAgICBjYXJnb3M6IFt7XHJcbiAgICAgICAgY2FyZ286IHtcclxuICAgICAgICAgIG5vbWU6IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5jYXJnbyxcclxuICAgICAgICB9LFxyXG4gICAgICB9XSBhcyBVc2VyUm9sZVtdLFxyXG4gICAgfSBhcyBQYXJ0aWFsPFVzZXI+KVxyXG4gIGNvbnN0IFtpc1VwZGF0aW5nLCBzZXRJc1VwZGF0aW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxyXG5cclxuICBjb25zdCB7XHJcbiAgICBmb3JtRGF0YTogdXNlckZvcm1EYXRhLFxyXG4gICAgb25UZXh0Q2hhbmdlOiBvbk5hbWVDaGFuZ2UsXHJcbiAgICBzZXRGb3JtRGF0YTogc2V0VXNlckZvcm1EYXRhLFxyXG4gIH0gPSB1c2VGb3JtRGF0YSh7IGlkOiBkYXRhLmlkLCBpbWFnZTogZGF0YS5pbWFnZSwgbm9tZTogZGF0YS5ub21lIH0gYXMgUGFydGlhbDxVc2VyPilcclxuICBjb25zdCB7XHJcbiAgICBmb3JtRGF0YTogcGFzc3dvcmRGb3JtRGF0YSxcclxuICAgIG9uVGV4dENoYW5nZTogb25QYXNzd29yZENoYW5nZSxcclxuICAgIHNldEZvcm1EYXRhOiBzZXRQYXNzd29yZENoYW5nZSxcclxuICB9ID0gdXNlRm9ybURhdGEoe1xyXG4gICAgY3VycmVudFBhc3N3b3JkOiAnJyxcclxuICAgIG5ld1Bhc3N3b3JkOiAnJyxcclxuICAgIHJlcGVhdE5ld1Bhc3N3b3JkOiAnJyxcclxuICB9IGFzIENoYW5nZVBhc3N3b3JkTG9nZ2VkRFRPKVxyXG4gIGNvbnN0IHsgc2hvd05vdGlmaWNhdGlvbiB9ID0gdXNlTm90aWZpY2F0aW9ucygpXHJcblxyXG4gIGNvbnN0IFtcclxuICAgIGNoYW5nZVBhc3N3b3JkVmlzaWJsZSxcclxuICAgIHsgdG9nZ2xlOiB0b2dnbGVDaGFuZ2VQYXN3b3JkVmlzaWJsZSB9LFxyXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0VXNlckZvcm1EYXRhKHsgLi4uZGF0YSwgaWQ6IGRhdGEuaWQsIGltYWdlOiBkYXRhLmltYWdlLCBub21lOiBkYXRhLm5vbWUgfSlcclxuICAgIHNldEltYWdlKGRhdGE/LmltYWdlIGFzIHN0cmluZylcclxuICB9LCBbZGF0YV0pXHJcblxyXG4gIGNvbnN0IHJlbW92ZUltYWdlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgc2V0VXNlckZvcm1EYXRhKHtcclxuICAgICAgLi4udXNlckZvcm1EYXRhLFxyXG4gICAgICBpbWFnZTogJycsXHJcbiAgICB9KVxyXG4gIH0sIFt1c2VyRm9ybURhdGFdKVxyXG5cclxuICBjb25zdCBzYXZlVXNlciA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIHNldElzVXBkYXRpbmcodHJ1ZSlcclxuICAgIGF3YWl0IHVzZXJTZXJ2aWNlLnVwZGF0ZUNvbmZpZyh1c2VyRm9ybURhdGEgYXMgVXNlcilcclxuICAgIHNldElzVXBkYXRpbmcoZmFsc2UpXHJcbiAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgbWVzc2FnZTogJ0F0dWFsaXphZG8gY29tIHN1Y2Vzc28hJyxcclxuICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuc3VjY2VzcyxcclxuICAgICAgdGltZW91dDogMTAwMDAsXHJcbiAgICB9KVxyXG4gICAgb25EaXNtaXNzKClcclxuICAgIG9uQWNjZXB0Py4oKVxyXG4gIH0sIFt1c2VyRm9ybURhdGFdKVxyXG5cclxuICBjb25zdCBzYXZlUGFzc3dvcmQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBhdXRoU2VydmljZS5jaGFuZ2VQYXNzd29yZExvZ2dlZCh7IC4uLnBhc3N3b3JkRm9ybURhdGEsIGlkOiBjdXJyZW50QWNjb3VudC52YWx1ZT8uaWQgfSlcclxuICAgIHNldFBhc3N3b3JkQ2hhbmdlKHtcclxuICAgICAgY3VycmVudFBhc3N3b3JkOiAnJyxcclxuICAgICAgbmV3UGFzc3dvcmQ6ICcnLFxyXG4gICAgICByZXBlYXROZXdQYXNzd29yZDogJycsXHJcbiAgICB9IGFzIENoYW5nZVBhc3N3b3JkTG9nZ2VkRFRPKVxyXG4gICAgdG9nZ2xlQ2hhbmdlUGFzd29yZFZpc2libGUoKVxyXG4gICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgIG1lc3NhZ2U6ICdTZW5oYSBhbHRlcmFkYSBjb20gc3VjZXNzbycsXHJcbiAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLnN1Y2Nlc3MsXHJcbiAgICAgIHRpbWVvdXQ6IDEwMDAwLFxyXG4gICAgfSlcclxuICAgIG9uQWNjZXB0Py4oKVxyXG4gIH0sIFtwYXNzd29yZEZvcm1EYXRhXSlcclxuXHJcbiAgY29uc3QgZGlzbWlzcyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmIChjaGFuZ2VQYXNzd29yZFZpc2libGUpIHtcclxuICAgICAgdG9nZ2xlQ2hhbmdlUGFzd29yZFZpc2libGUoKVxyXG4gICAgICBzZXRQYXNzd29yZENoYW5nZSh7XHJcbiAgICAgICAgY3VycmVudFBhc3N3b3JkOiAnJyxcclxuICAgICAgICBuZXdQYXNzd29yZDogJycsXHJcbiAgICAgICAgcmVwZWF0TmV3UGFzc3dvcmQ6ICcnLFxyXG4gICAgICB9IGFzIENoYW5nZVBhc3N3b3JkTG9nZ2VkRFRPKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0VXNlckZvcm1EYXRhKG9sZFVzZXIgPT4ge1xyXG4gICAgICAgIHJldHVybiB7IC4uLm9sZFVzZXIsIGltYWdlOiBjdXJyZW50QWNjb3VudC52YWx1ZT8uaW1hZ2UgfVxyXG4gICAgICB9KVxyXG4gICAgICBvbkRpc21pc3MoKVxyXG4gICAgfVxyXG4gIH0sIFtjaGFuZ2VQYXNzd29yZFZpc2libGVdKVxyXG5cclxuICBjb25zdCBkaXNhYmxlU2F2ZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmICghY2hhbmdlUGFzc3dvcmRWaXNpYmxlKSB7XHJcbiAgICAgIHJldHVybiBpc1VwZGF0aW5nXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gKHBhc3N3b3JkRm9ybURhdGEuY3VycmVudFBhc3N3b3JkLmxlbmd0aCA9PT0gMCB8fFxyXG4gICAgICAhKC8oW2Etel0pLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKSB8fFxyXG4gICAgICAhKC8oW0EtWl0pLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKSB8fFxyXG4gICAgICAhKC8oWzAtOV0pLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKSB8fFxyXG4gICAgICAhKC9bLStfIUAjJCVeJiouLCA/XS8pLnRlc3QocGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZCkgfHxcclxuICAgICAgcGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZCAhPT0gcGFzc3dvcmRGb3JtRGF0YS5yZXBlYXROZXdQYXNzd29yZCB8fCBwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkLmxlbmd0aCA8IDYpXHJcbiAgICB9XHJcbiAgfSwgW2lzVXBkYXRpbmcsIHBhc3N3b3JkRm9ybURhdGEsIGNoYW5nZVBhc3N3b3JkVmlzaWJsZV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICAoPE1vZGFsXHJcbiAgICAgIGlzT3Blbj17aXNPcGVufVxyXG4gICAgICBvbkRpc21pc3M9e2Rpc21pc3N9XHJcbiAgICAgIHRpdGxlPXtjaGFuZ2VQYXNzd29yZFZpc2libGVcclxuICAgICAgICA/ICdBbHRlcmFyIHNlbmhhJ1xyXG4gICAgICAgIDogJ01pbmhhcyBjb25maWd1cmHDp8O1ZXMnfVxyXG4gICAgPlxyXG4gICAgICA8PlxyXG4gICAgICAgIHshY2hhbmdlUGFzc3dvcmRWaXNpYmxlICYmXHJcbiAgICAgICAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxyXG4gICAgICAgICAgICA8VXNlckFjY291bnRDb25maWd1cmF0aW9uRm9ybVxyXG4gICAgICAgICAgICAgIHVzZXJGb3JtRGF0YT17dXNlckZvcm1EYXRhIGFzIFVzZXJ9XHJcbiAgICAgICAgICAgICAgb25UZXh0Q2hhbmdlPXtvbk5hbWVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgcmVtb3ZlSW1hZ2U9e3JlbW92ZUltYWdlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8RmxleEl0ZW0+XHJcbiAgICAgICAgICAgICAgPExhYmVsPlNlbmhhPC9MYWJlbD5cclxuICAgICAgICAgICAgICA8TGluayBvbkNsaWNrPXt0b2dnbGVDaGFuZ2VQYXN3b3JkVmlzaWJsZX0+XHJcbiAgICAgICAgICAgICAgICBBbHRlcmFyIGEgc2VuaGFcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgICA8L0ZsZXhDb2x1bW4+fVxyXG4gICAgICAgIHtjaGFuZ2VQYXNzd29yZFZpc2libGUgJiZcclxuICAgICAgICAgIDxGbGV4Q29sdW1uIGdhcD17IDEyIH0gdmVydGljYWxBbGlnbj1cImZsZXgtc3RhcnRcIiB3aWR0aD17JzEwMCUnfT5cclxuICAgICAgICAgICAgPFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybUZvcm1cclxuICAgICAgICAgICAgICBwYXNzd29yZEZvcm1EYXRhPXtwYXNzd29yZEZvcm1EYXRhfVxyXG4gICAgICAgICAgICAgIG9uVGV4dENoYW5nZT17b25QYXNzd29yZENoYW5nZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPExhYmVsPkNvbW8gY3JpYXIgdW1hIHNlbmhhIG1haXMgc2VndXJhPC9MYWJlbD5cclxuICAgICAgICAgICAgPEZsZXhSb3dcclxuICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXHJcbiAgICAgICAgICAgICAgZ2FwPXsgMTIgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEZvbnRJY29uXHJcbiAgICAgICAgICAgICAgICBpY29uTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICEoLyhbMC05XSkvKS50ZXN0KHBhc3N3b3JkRm9ybURhdGEubmV3UGFzc3dvcmQpXHJcbiAgICAgICAgICAgICAgICAgICAgPyAnTG9jYXRpb25DaXJjbGUnXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnU2t5cGVDaXJjbGVDaGVjaydcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICEoLyhbMC05XSkvKS50ZXN0KHBhc3N3b3JkRm9ybURhdGEubmV3UGFzc3dvcmQpXHJcbiAgICAgICAgICAgICAgICAgICAgPyBzdHlsZXMudW5jaGVja2VkSWNvblxyXG4gICAgICAgICAgICAgICAgICAgIDogc3R5bGVzLmNoZWNrZWRJY29uXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8VGV4dD5cclxuICAgICAgICAgICAgICAgIFBlbG8gbWVub3MgMSBuw7ptZXJvXHJcbiAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgICAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgICAgICAgdmVydGljYWxBbGlnbj0nY2VudGVyJ1xyXG4gICAgICAgICAgICAgIGdhcD17IDEyIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxGb250SWNvblxyXG4gICAgICAgICAgICAgICAgaWNvbk5hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAhKC8oW2Etel0pLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKVxyXG4gICAgICAgICAgICAgICAgICAgID8gJ0xvY2F0aW9uQ2lyY2xlJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogJ1NreXBlQ2lyY2xlQ2hlY2snXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAhKC8oW2Etel0pLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKVxyXG4gICAgICAgICAgICAgICAgICAgID8gc3R5bGVzLnVuY2hlY2tlZEljb25cclxuICAgICAgICAgICAgICAgICAgICA6IHN0eWxlcy5jaGVja2VkSWNvblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFRleHQ+XHJcbiAgICAgICAgICAgICAgICBQZWxvIG1lbm9zIDEgbGV0cmEgbWluw7pzY3VsYVxyXG4gICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgICAgICA8RmxleFJvd1xyXG4gICAgICAgICAgICAgIHZlcnRpY2FsQWxpZ249J2NlbnRlcidcclxuICAgICAgICAgICAgICBnYXA9eyAxMiB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Rm9udEljb25cclxuICAgICAgICAgICAgICAgIGljb25OYW1lPXtcclxuICAgICAgICAgICAgICAgICAgISgvKFtBLVpdKS8pLnRlc3QocGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZClcclxuICAgICAgICAgICAgICAgICAgICA/ICdMb2NhdGlvbkNpcmNsZSdcclxuICAgICAgICAgICAgICAgICAgICA6ICdTa3lwZUNpcmNsZUNoZWNrJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgISgvKFtBLVpdKS8pLnRlc3QocGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZClcclxuICAgICAgICAgICAgICAgICAgICA/IHN0eWxlcy51bmNoZWNrZWRJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgOiBzdHlsZXMuY2hlY2tlZEljb25cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxUZXh0PlxyXG4gICAgICAgICAgICAgICAgUGVsbyBtZW5vcyAxIGxldHJhIG1hacO6c2N1bGFcclxuICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgIDwvRmxleFJvdz5cclxuICAgICAgICAgICAgPEZsZXhSb3dcclxuICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInXHJcbiAgICAgICAgICAgICAgZ2FwPXsgMTIgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEZvbnRJY29uXHJcbiAgICAgICAgICAgICAgICBpY29uTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICEoL1stK18hQCMkJV4mKi4sID9dLykudGVzdChwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkKVxyXG4gICAgICAgICAgICAgICAgICAgID8gJ0xvY2F0aW9uQ2lyY2xlJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogJ1NreXBlQ2lyY2xlQ2hlY2snXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAhKC9bLStfIUAjJCVeJiouLCA/XS8pLnRlc3QocGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZClcclxuICAgICAgICAgICAgICAgICAgICA/IHN0eWxlcy51bmNoZWNrZWRJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgOiBzdHlsZXMuY2hlY2tlZEljb25cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxUZXh0PlxyXG4gICAgICAgICAgICAgICAgUGVsbyBtZW5vcyAxIHPDrW1ib2xvXHJcbiAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgICAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgICAgICAgdmVydGljYWxBbGlnbj0nY2VudGVyJ1xyXG4gICAgICAgICAgICAgIGdhcD17IDEyIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxGb250SWNvblxyXG4gICAgICAgICAgICAgICAgaWNvbk5hbWU9e1xyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkLmxlbmd0aCA8IDZcclxuICAgICAgICAgICAgICAgICAgICA/ICdMb2NhdGlvbkNpcmNsZSdcclxuICAgICAgICAgICAgICAgICAgICA6ICdTa3lwZUNpcmNsZUNoZWNrJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZC5sZW5ndGggPCA2XHJcbiAgICAgICAgICAgICAgICAgICAgPyBzdHlsZXMudW5jaGVja2VkSWNvblxyXG4gICAgICAgICAgICAgICAgICAgIDogc3R5bGVzLmNoZWNrZWRJY29uXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8VGV4dD5cclxuICAgICAgICAgICAgICAgIFBlbG8gbWVub3MgNiBjYXJhY3RlcmVzXHJcbiAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgICAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgICAgICAgdmVydGljYWxBbGlnbj0nY2VudGVyJ1xyXG4gICAgICAgICAgICAgIGdhcD17IDEyIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxGb250SWNvblxyXG4gICAgICAgICAgICAgICAgaWNvbk5hbWU9e1xyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZEZvcm1EYXRhLm5ld1Bhc3N3b3JkICE9PSBwYXNzd29yZEZvcm1EYXRhLnJlcGVhdE5ld1Bhc3N3b3JkIHx8XHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkRm9ybURhdGEubmV3UGFzc3dvcmQubGVuZ3RoID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgPyAnTG9jYXRpb25DaXJjbGUnXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnU2t5cGVDaXJjbGVDaGVjaydcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkRm9ybURhdGEubmV3UGFzc3dvcmQgIT09IHBhc3N3b3JkRm9ybURhdGEucmVwZWF0TmV3UGFzc3dvcmQgfHxcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmRGb3JtRGF0YS5uZXdQYXNzd29yZC5sZW5ndGggPT09IDBcclxuICAgICAgICAgICAgICAgICAgICA/IHN0eWxlcy51bmNoZWNrZWRJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgOiBzdHlsZXMuY2hlY2tlZEljb25cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxUZXh0PlxyXG4gICAgICAgICAgICAgICAgTm92YSBzZW5oYSA9IGNvbmZpcm1hw6fDo28gZGUgbm92YSBzZW5oYVxyXG4gICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgICAgPC9GbGV4Q29sdW1uPn1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFjdGlvbnN9PlxyXG4gICAgICAgICAgPERlZmF1bHRCdXR0b25cclxuICAgICAgICAgICAgdGV4dCA9IFwiQ2FuY2VsYXJcIlxyXG4gICAgICAgICAgICBvbkNsaWNrID0geygpID0+IGRpc21pc3MoKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVXBkYXRpbmd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFByaW1hcnlCdXR0b25cclxuICAgICAgICAgICAgdGV4dD1cIlNhbHZhclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2NoYW5nZVBhc3N3b3JkVmlzaWJsZSA/IHNhdmVQYXNzd29yZCA6IHNhdmVVc2VyfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZVNhdmUoKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvPlxyXG4gICAgPC9Nb2RhbD4pXHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Nb2RhbFxyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXHJcblxyXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBwYXJhZ3JhcGg6IHtcclxuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgIGRpc3BsYXk6ICdibG9jaycsXHJcbiAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy5sZyxcclxuICAgICAgc2VsZWN0b3JzOiB7XHJcbiAgICAgICAgJyY6bGFzdC1vZi10eXBlJzoge1xyXG4gICAgICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLnh4bCxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIGFjdGlvbnM6IHtcclxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyxcclxuICAgICAgbWFyZ2luVG9wOiAxMixcclxuICAgICAgc2VsZWN0b3JzOiB7XHJcbiAgICAgICAgJyYgPiA6bm90KDpsYXN0LWNoaWxkKSc6IHtcclxuICAgICAgICAgIG1hcmdpblJpZ2h0OiBzcGFjaW5nLmxnLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgY2hlY2tlZEljb246IHtcclxuICAgICAgY29sb3I6IGNvbG9ycy5ncmVlbls1MDBdLFxyXG4gICAgICB3aWR0aDogMTIsXHJcbiAgICAgIGhlaWdodDogMTIsXHJcbiAgICB9LFxyXG4gICAgdW5jaGVja2VkSWNvbjoge1xyXG4gICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxyXG4gICAgICB3aWR0aDogMTIsXHJcbiAgICAgIGhlaWdodDogMTIsXHJcbiAgICB9LFxyXG4gIH0pXHJcbn1cclxuIl19