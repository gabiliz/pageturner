import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/NotificationsLayer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/NotificationsLayer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Layer, MessageBar } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { formatTextInBoldHTMLString } from "/src/shared/utils/index.ts";
const Notifications = () => {
  _s();
  const {
    notifications,
    hideNotification
  } = useNotifications();
  const icons = {
    0: {
      name: "InfoSolid",
      color: "#00749F"
    },
    // info
    1: {
      color: "#C80A2D",
      name: "ErrorBadge"
    },
    // error
    2: {
      color: "#FDE7E9",
      name: "Blocked2"
    },
    // blocked
    3: {
      name: "Warning",
      color: "#FED9CC"
    },
    // severeWarning
    4: {
      color: "#168A2F",
      name: "SkypeCircleCheck"
    },
    // success
    5: {
      color: "#FFD23E",
      name: "WarningSolid"
    }
    // warning
  };
  const backgroundColors = {
    0: "#D1EFFC",
    // info
    1: "#F5C3CD",
    // error
    2: "#F9F1D6",
    // blocked
    3: "#F5C3CD",
    // severeWarning
    4: "#D0F4D8",
    // success
    5: "#F9F1D6"
    // warning
  };
  return /* @__PURE__ */ jsxDEV(Layer, { styles: {
    content: {
      position: "fixed",
      bottom: 0,
      right: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-end",
      visibility: "hidden",
      zIndex: 999
    }
  }, eventBubblingEnabled: false, children: notifications?.map(({
    id,
    message,
    type
  }) => /* @__PURE__ */ jsxDEV(MessageBar, { messageBarIconProps: {
    iconName: type ? icons[type].name : icons[0].name,
    styles: {
      root: {
        color: type ? icons[type].color : icons[0].color
      }
    }
  }, onDismiss: () => hideNotification(id), styles: {
    root: {
      backgroundColor: type ? backgroundColors[type] : backgroundColors[0],
      visibility: "visible",
      width: 300,
      marginLeft: "40px",
      color: "#201F1E",
      marginRight: "40px",
      selectors: {
        "&:first-child": {
          marginTop: "40px"
        },
        "&:not(:last-child)": {
          marginBottom: "8px"
        },
        "&:last-child": {
          marginBottom: "40px"
        }
      }
    }
  }, children: /* @__PURE__ */ jsxDEV("span", { dangerouslySetInnerHTML: {
    __html: formatTextInBoldHTMLString(message)
  } }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/NotificationsLayer.tsx",
    lineNumber: 106,
    columnNumber: 11
  }, this) }, id, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/NotificationsLayer.tsx",
    lineNumber: 78,
    columnNumber: 11
  }, this)) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/NotificationsLayer.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
};
_s(Notifications, "KZr5s9scVWPesJDtgWe63zFs1mk=", false, function() {
  return [useNotifications];
});
_c = Notifications;
export default Notifications;
var _c;
$RefreshReg$(_c, "Notifications");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/NotificationsLayer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUZWLFNBQVNBLE9BQU9DLGtCQUFrQjtBQUNsQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msa0NBQWtDO0FBTTNDLE1BQU1DLGdCQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFlQztBQUFBQSxFQUFpQixJQUFJTCxpQkFBaUI7QUFDN0QsUUFBTU0sUUFBcUM7QUFBQSxJQUN6QyxHQUFHO0FBQUEsTUFDREMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxJQUNBLEdBQUc7QUFBQSxNQUNEQSxPQUFPO0FBQUEsTUFDUEQsTUFBTTtBQUFBLElBQ1I7QUFBQTtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RDLE9BQU87QUFBQSxNQUNQRCxNQUFNO0FBQUEsSUFDUjtBQUFBO0FBQUEsSUFDQSxHQUFHO0FBQUEsTUFDREEsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxJQUNBLEdBQUc7QUFBQSxNQUNEQSxPQUFPO0FBQUEsTUFDUEQsTUFBTTtBQUFBLElBQ1I7QUFBQTtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RDLE9BQU87QUFBQSxNQUNQRCxNQUFNO0FBQUEsSUFDUjtBQUFBO0FBQUEsRUFDRjtBQUNBLFFBQU1FLG1CQUEyQztBQUFBLElBQy9DLEdBQUc7QUFBQTtBQUFBLElBQ0gsR0FBRztBQUFBO0FBQUEsSUFDSCxHQUFHO0FBQUE7QUFBQSxJQUNILEdBQUc7QUFBQTtBQUFBLElBQ0gsR0FBRztBQUFBO0FBQUEsSUFDSCxHQUFHO0FBQUE7QUFBQSxFQUNMO0FBQ0EsU0FDRSx1QkFBQyxTQUNDLFFBQVE7QUFBQSxJQUNOQyxTQUFTO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLGVBQWU7QUFBQSxNQUNmQyxZQUFZO0FBQUEsTUFDWkMsWUFBWTtBQUFBLE1BQ1pDLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRixHQUNBLHNCQUFzQixPQUVyQmQseUJBQWVlLElBQUksQ0FBQztBQUFBLElBQUVDO0FBQUFBLElBQUlDO0FBQUFBLElBQVNDO0FBQUFBLEVBQUssTUFDdkMsdUJBQUMsY0FFQyxxQkFBcUI7QUFBQSxJQUNuQkMsVUFBVUQsT0FBT2hCLE1BQU1nQixJQUFJLEVBQUVmLE9BQU9ELE1BQU0sQ0FBQyxFQUFFQztBQUFBQSxJQUM3Q2lCLFFBQVE7QUFBQSxNQUNOQyxNQUFNO0FBQUEsUUFDSmpCLE9BQU9jLE9BQU9oQixNQUFNZ0IsSUFBSSxFQUFFZCxRQUFRRixNQUFNLENBQUMsRUFBRUU7QUFBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLFdBQVcsTUFBTUgsaUJBQWlCZSxFQUFFLEdBQ3BDLFFBQVE7QUFBQSxJQUNOSyxNQUFNO0FBQUEsTUFDSkMsaUJBQWlCSixPQUFPYixpQkFBaUJhLElBQUksSUFBSWIsaUJBQWlCLENBQUM7QUFBQSxNQUNuRVEsWUFBWTtBQUFBLE1BQ1pVLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWnBCLE9BQU87QUFBQSxNQUNQcUIsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxRQUNULGlCQUFpQjtBQUFBLFVBQ2ZDLFdBQVc7QUFBQSxRQUNiO0FBQUEsUUFDQSxzQkFBc0I7QUFBQSxVQUNwQkMsY0FBYztBQUFBLFFBQ2hCO0FBQUEsUUFDQSxnQkFBZ0I7QUFBQSxVQUNkQSxjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FFQSxpQ0FBQyxVQUNDLHlCQUNFO0FBQUEsSUFBRUMsUUFBUWhDLDJCQUEyQm9CLE9BQU87QUFBQSxFQUFFLEtBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHRyxLQW5DRUQsSUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBLENBQ0QsS0F2REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdEQTtBQUVKO0FBQUNqQixHQS9GS0QsZUFBaUI7QUFBQSxVQUN1QkYsZ0JBQWdCO0FBQUE7QUFBQWtDLEtBRHhEaEM7QUFpR04sZUFBZUE7QUFBYSxJQUFBZ0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxheWVyIiwiTWVzc2FnZUJhciIsInVzZU5vdGlmaWNhdGlvbnMiLCJmb3JtYXRUZXh0SW5Cb2xkSFRNTFN0cmluZyIsIk5vdGlmaWNhdGlvbnMiLCJfcyIsIm5vdGlmaWNhdGlvbnMiLCJoaWRlTm90aWZpY2F0aW9uIiwiaWNvbnMiLCJuYW1lIiwiY29sb3IiLCJiYWNrZ3JvdW5kQ29sb3JzIiwiY29udGVudCIsInBvc2l0aW9uIiwiYm90dG9tIiwicmlnaHQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJ2aXNpYmlsaXR5IiwiekluZGV4IiwibWFwIiwiaWQiLCJtZXNzYWdlIiwidHlwZSIsImljb25OYW1lIiwic3R5bGVzIiwicm9vdCIsImJhY2tncm91bmRDb2xvciIsIndpZHRoIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0Iiwic2VsZWN0b3JzIiwibWFyZ2luVG9wIiwibWFyZ2luQm90dG9tIiwiX19odG1sIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zTGF5ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9Ob3RpZmljYXRpb25zTGF5ZXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgTGF5ZXIsIE1lc3NhZ2VCYXIgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi8uLi9zdG9yZS9ub3RpZmljYXRpb25zL25vdGlmaWNhdGlvbnMnXHJcbmltcG9ydCB7IGZvcm1hdFRleHRJbkJvbGRIVE1MU3RyaW5nIH0gZnJvbSAnLi4vLi4vdXRpbHMnXHJcblxyXG5pbnRlcmZhY2UgTWVzc2FnZVR5cGV7XHJcbiAgY29sb3I6IHN0cmluZ1xyXG4gIG5hbWU6IHN0cmluZ1xyXG59XHJcbmNvbnN0IE5vdGlmaWNhdGlvbnM6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgbm90aWZpY2F0aW9ucywgaGlkZU5vdGlmaWNhdGlvbiB9ID0gdXNlTm90aWZpY2F0aW9ucygpXHJcbiAgY29uc3QgaWNvbnM6IFJlY29yZDxudW1iZXIsIE1lc3NhZ2VUeXBlPiA9IHtcclxuICAgIDA6IHtcclxuICAgICAgbmFtZTogJ0luZm9Tb2xpZCcsXHJcbiAgICAgIGNvbG9yOiAnIzAwNzQ5RicsXHJcbiAgICB9LCAvLyBpbmZvXHJcbiAgICAxOiB7XHJcbiAgICAgIGNvbG9yOiAnI0M4MEEyRCcsXHJcbiAgICAgIG5hbWU6ICdFcnJvckJhZGdlJyxcclxuICAgIH0sIC8vIGVycm9yXHJcbiAgICAyOiB7XHJcbiAgICAgIGNvbG9yOiAnI0ZERTdFOScsXHJcbiAgICAgIG5hbWU6ICdCbG9ja2VkMicsXHJcbiAgICB9LCAvLyBibG9ja2VkXHJcbiAgICAzOiB7XHJcbiAgICAgIG5hbWU6ICdXYXJuaW5nJyxcclxuICAgICAgY29sb3I6ICcjRkVEOUNDJyxcclxuICAgIH0sIC8vIHNldmVyZVdhcm5pbmdcclxuICAgIDQ6IHtcclxuICAgICAgY29sb3I6ICcjMTY4QTJGJyxcclxuICAgICAgbmFtZTogJ1NreXBlQ2lyY2xlQ2hlY2snLFxyXG4gICAgfSwgLy8gc3VjY2Vzc1xyXG4gICAgNToge1xyXG4gICAgICBjb2xvcjogJyNGRkQyM0UnLFxyXG4gICAgICBuYW1lOiAnV2FybmluZ1NvbGlkJyxcclxuICAgIH0sIC8vIHdhcm5pbmdcclxuICB9XHJcbiAgY29uc3QgYmFja2dyb3VuZENvbG9yczogUmVjb3JkPG51bWJlciwgc3RyaW5nPiA9IHtcclxuICAgIDA6ICcjRDFFRkZDJywgLy8gaW5mb1xyXG4gICAgMTogJyNGNUMzQ0QnLCAvLyBlcnJvclxyXG4gICAgMjogJyNGOUYxRDYnLCAvLyBibG9ja2VkXHJcbiAgICAzOiAnI0Y1QzNDRCcsIC8vIHNldmVyZVdhcm5pbmdcclxuICAgIDQ6ICcjRDBGNEQ4JywgLy8gc3VjY2Vzc1xyXG4gICAgNTogJyNGOUYxRDYnLCAvLyB3YXJuaW5nXHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8TGF5ZXJcclxuICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgY29udGVudDoge1xyXG4gICAgICAgICAgcG9zaXRpb246ICdmaXhlZCcsXHJcbiAgICAgICAgICBib3R0b206IDAsXHJcbiAgICAgICAgICByaWdodDogMCxcclxuICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxyXG4gICAgICAgICAgYWxpZ25JdGVtczogJ2ZsZXgtZW5kJyxcclxuICAgICAgICAgIHZpc2liaWxpdHk6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgekluZGV4OiA5OTksXHJcbiAgICAgICAgfSxcclxuICAgICAgfX1cclxuICAgICAgZXZlbnRCdWJibGluZ0VuYWJsZWQ9e2ZhbHNlfVxyXG4gICAgPlxyXG4gICAgICB7bm90aWZpY2F0aW9ucz8ubWFwKCh7IGlkLCBtZXNzYWdlLCB0eXBlIH0pID0+IChcclxuICAgICAgICA8TWVzc2FnZUJhclxyXG4gICAgICAgICAga2V5PXtpZH1cclxuICAgICAgICAgIG1lc3NhZ2VCYXJJY29uUHJvcHM9e3tcclxuICAgICAgICAgICAgaWNvbk5hbWU6IHR5cGUgPyBpY29uc1t0eXBlXS5uYW1lIDogaWNvbnNbMF0ubmFtZSxcclxuICAgICAgICAgICAgc3R5bGVzOiB7XHJcbiAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHR5cGUgPyBpY29uc1t0eXBlXS5jb2xvciA6IGljb25zWzBdLmNvbG9yLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgb25EaXNtaXNzPXsoKSA9PiBoaWRlTm90aWZpY2F0aW9uKGlkKX1cclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0eXBlID8gYmFja2dyb3VuZENvbG9yc1t0eXBlXSA6IGJhY2tncm91bmRDb2xvcnNbMF0sXHJcbiAgICAgICAgICAgICAgdmlzaWJpbGl0eTogJ3Zpc2libGUnLFxyXG4gICAgICAgICAgICAgIHdpZHRoOiAzMDAsXHJcbiAgICAgICAgICAgICAgbWFyZ2luTGVmdDogJzQwcHgnLFxyXG4gICAgICAgICAgICAgIGNvbG9yOiAnIzIwMUYxRScsXHJcbiAgICAgICAgICAgICAgbWFyZ2luUmlnaHQ6ICc0MHB4JyxcclxuICAgICAgICAgICAgICBzZWxlY3RvcnM6IHtcclxuICAgICAgICAgICAgICAgICcmOmZpcnN0LWNoaWxkJzoge1xyXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6ICc0MHB4JyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAnJjpub3QoOmxhc3QtY2hpbGQpJzoge1xyXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICcmOmxhc3QtY2hpbGQnOiB7XHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzQwcHgnLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17XHJcbiAgICAgICAgICAgICAgeyBfX2h0bWw6IGZvcm1hdFRleHRJbkJvbGRIVE1MU3RyaW5nKG1lc3NhZ2UpIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L01lc3NhZ2VCYXI+XHJcbiAgICAgICkpfVxyXG4gICAgPC9MYXllcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbnNcclxuIl19