import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dialog/ConfirmLogout.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmLogout.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { DangerButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import ConfirmDialog from "/src/shared/components/dialog/ConfirmDialog.tsx?t=1701096626433";
const ConfirmLogout = (props) => {
  const {
    hidden,
    onDismiss,
    onConfirm
  } = props;
  return /* @__PURE__ */ jsxDEV(ConfirmDialog, { hidden, onDismiss, title: "Sair do sistema", description: "Você tem certeza que deseja sair?", actions: () => [/* @__PURE__ */ jsxDEV(DefaultButton, { onClick: onDismiss, children: "Cancelar" }, "cancel", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmLogout.tsx",
    lineNumber: 15,
    columnNumber: 151
  }, this), /* @__PURE__ */ jsxDEV(DangerButton, { onClick: onConfirm, children: "Sair" }, "confirm", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmLogout.tsx",
    lineNumber: 17,
    columnNumber: 27
  }, this)] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmLogout.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_c = ConfirmLogout;
export default ConfirmLogout;
var _c;
$RefreshReg$(_c, "ConfirmLogout");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmLogout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JRO0FBcEJSLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGNBQWNDLHFCQUFxQjtBQUM1QyxPQUFPQyxtQkFBbUI7QUFRMUIsTUFBTUMsZ0JBQXlDQyxXQUFVO0FBQ3ZELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFRQztBQUFBQSxJQUFXQztBQUFBQSxFQUFVLElBQUlIO0FBRXpDLFNBQ0UsdUJBQUMsaUJBQ0MsUUFDQSxXQUNBLE9BQU0sbUJBQ04sYUFBWSxxQ0FDWixTQUFTLE1BQU0sQ0FDYix1QkFBQyxpQkFFQyxTQUFTRSxXQUFVLHdCQURmLFVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBLEdBQ0EsdUJBQUMsZ0JBRUMsU0FBU0MsV0FBVSxvQkFEZixXQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxDQUFlLEtBakJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JJO0FBR1I7QUFBQ0MsS0F6QktMO0FBMkJOLGVBQWVBO0FBQWEsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRhbmdlckJ1dHRvbiIsIkRlZmF1bHRCdXR0b24iLCJDb25maXJtRGlhbG9nIiwiQ29uZmlybUxvZ291dCIsInByb3BzIiwiaGlkZGVuIiwib25EaXNtaXNzIiwib25Db25maXJtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb25maXJtTG9nb3V0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2RpYWxvZy9Db25maXJtTG9nb3V0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBEYW5nZXJCdXR0b24sIERlZmF1bHRCdXR0b24gfSBmcm9tICcuLi8nXG5pbXBvcnQgQ29uZmlybURpYWxvZyBmcm9tICcuL0NvbmZpcm1EaWFsb2cnXG5cbmludGVyZmFjZSBDb25maXJtTG9nb3V0UHJvcHMge1xuICBoaWRkZW4/OiBib29sZWFuXG4gIG9uRGlzbWlzcz86ICgpID0+IHZvaWRcbiAgb25Db25maXJtPzogKCkgPT4gdm9pZFxufVxuXG5jb25zdCBDb25maXJtTG9nb3V0OiBGQzxDb25maXJtTG9nb3V0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgaGlkZGVuLCBvbkRpc21pc3MsIG9uQ29uZmlybSB9ID0gcHJvcHNcblxuICByZXR1cm4gKFxuICAgIDxDb25maXJtRGlhbG9nXG4gICAgICBoaWRkZW49e2hpZGRlbn1cbiAgICAgIG9uRGlzbWlzcz17b25EaXNtaXNzfVxuICAgICAgdGl0bGU9XCJTYWlyIGRvIHNpc3RlbWFcIlxuICAgICAgZGVzY3JpcHRpb249XCJWb2PDqiB0ZW0gY2VydGV6YSBxdWUgZGVzZWphIHNhaXI/XCJcbiAgICAgIGFjdGlvbnM9eygpID0+IFtcbiAgICAgICAgPERlZmF1bHRCdXR0b25cbiAgICAgICAgICBrZXk9XCJjYW5jZWxcIlxuICAgICAgICAgIG9uQ2xpY2s9e29uRGlzbWlzc31cbiAgICAgICAgPlxuICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgIDwvRGVmYXVsdEJ1dHRvbj4sXG4gICAgICAgIDxEYW5nZXJCdXR0b25cbiAgICAgICAgICBrZXk9XCJjb25maXJtXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19XG4gICAgICAgID5cbiAgICAgICAgICBTYWlyXG4gICAgICAgIDwvRGFuZ2VyQnV0dG9uPixcbiAgICAgIF19XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb25maXJtTG9nb3V0XG4iXX0=