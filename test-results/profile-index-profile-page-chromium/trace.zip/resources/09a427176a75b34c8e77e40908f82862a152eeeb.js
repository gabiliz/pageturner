import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/DangerButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DangerButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import PrimaryButton from "/src/shared/components/buttons/PrimaryButton.tsx?t=1701096626433";
import { useThemeColors } from "/src/shared/hooks/index.ts";
const DangerButton = (props) => {
  _s();
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV(PrimaryButton, { className: styles.dangerButton, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DangerButton.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(DangerButton, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = DangerButton;
const useStyles = () => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = mergeStyleSets({
    dangerButton: {
      backgroundColor: colors.red[500],
      borderColor: colors.red[500],
      borderRadius: 2,
      height: 32,
      fontSize: 14,
      fontWeight: 600,
      lineHeight: 20,
      transition: "background-color .1s, border-color .1s",
      "&:hover": {
        backgroundColor: colors.red[300],
        borderColor: colors.red[300]
      },
      "&:focus": {
        backgroundColor: colors.red[600],
        borderColor: colors.red[600],
        color: colors.gray[800]
      },
      "&:active": {
        backgroundColor: colors.red[600],
        borderColor: colors.red[600],
        color: colors.gray[800]
      },
      "&.is-disabled": {
        opacity: 0.5,
        border: "none"
      }
    }
  });
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
export default DangerButton;
var _c;
$RefreshReg$(_c, "DangerButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/DangerButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQSixTQUF1QkEsc0JBQXNCO0FBQzdDLE9BQU9DLG1CQUFtQjtBQUMxQixTQUFTQyxzQkFBc0I7QUFFL0IsTUFBTUMsZUFBa0NDLFdBQVU7QUFBQUMsS0FBQTtBQUNoRCxRQUFNQyxTQUFTQyxVQUFVO0FBQ3pCLFNBQ0UsdUJBQUMsaUJBQ0MsV0FBV0QsT0FBT0UsY0FDbEIsR0FBSUosU0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRVk7QUFHaEI7QUFBQ0MsR0FSS0YsY0FBOEI7QUFBQSxVQUNuQkksU0FBUztBQUFBO0FBQUFFLEtBRHBCTjtBQVVOLE1BQU1JLFlBQVlBLE1BQU07QUFBQUcsTUFBQTtBQUN0QixRQUFNQyxTQUFTVCxlQUFlO0FBQzlCLFFBQU1VLGVBQWVaLGVBQWU7QUFBQSxJQUNsQ1EsY0FBYztBQUFBLE1BQ1pLLGlCQUFpQkYsT0FBT0csSUFBSSxHQUFHO0FBQUEsTUFDL0JDLGFBQWFKLE9BQU9HLElBQUksR0FBRztBQUFBLE1BQzNCRSxjQUFjO0FBQUEsTUFDZEMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsWUFBWTtBQUFBLE1BQ1pDLFlBQVk7QUFBQSxNQUNaLFdBQVc7QUFBQSxRQUNUUixpQkFBaUJGLE9BQU9HLElBQUksR0FBRztBQUFBLFFBQy9CQyxhQUFhSixPQUFPRyxJQUFJLEdBQUc7QUFBQSxNQUM3QjtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1RELGlCQUFpQkYsT0FBT0csSUFBSSxHQUFHO0FBQUEsUUFDL0JDLGFBQWFKLE9BQU9HLElBQUksR0FBRztBQUFBLFFBQzNCUSxPQUFPWCxPQUFPWSxLQUFLLEdBQUc7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsWUFBWTtBQUFBLFFBQ1ZWLGlCQUFpQkYsT0FBT0csSUFBSSxHQUFHO0FBQUEsUUFDL0JDLGFBQWFKLE9BQU9HLElBQUksR0FBRztBQUFBLFFBQzNCUSxPQUFPWCxPQUFPWSxLQUFLLEdBQUc7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsaUJBQWlCO0FBQUEsUUFDZkMsU0FBUztBQUFBLFFBQ1RDLFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU9iO0FBQ1Q7QUFBQ0YsSUFsQ0tILFdBQVM7QUFBQSxVQUNFTCxjQUFjO0FBQUE7QUFtQy9CLGVBQWVDO0FBQVksSUFBQU07QUFBQWlCLGFBQUFqQixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJQcmltYXJ5QnV0dG9uIiwidXNlVGhlbWVDb2xvcnMiLCJEYW5nZXJCdXR0b24iLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiZGFuZ2VyQnV0dG9uIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJhY3Rpb25TdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJyZWQiLCJib3JkZXJDb2xvciIsImJvcmRlclJhZGl1cyIsImhlaWdodCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImxpbmVIZWlnaHQiLCJ0cmFuc2l0aW9uIiwiY29sb3IiLCJncmF5Iiwib3BhY2l0eSIsImJvcmRlciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhbmdlckJ1dHRvbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9idXR0b25zL0RhbmdlckJ1dHRvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSUJ1dHRvblByb3BzLCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCBQcmltYXJ5QnV0dG9uIGZyb20gJy4vUHJpbWFyeUJ1dHRvbidcbmltcG9ydCB7IHVzZVRoZW1lQ29sb3JzIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5cbmNvbnN0IERhbmdlckJ1dHRvbjogRkM8SUJ1dHRvblByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoKVxuICByZXR1cm4gKFxuICAgIDxQcmltYXJ5QnV0dG9uXG4gICAgICBjbGFzc05hbWU9e3N0eWxlcy5kYW5nZXJCdXR0b259XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcbiAgY29uc3QgYWN0aW9uU3R5bGVzID0gbWVyZ2VTdHlsZVNldHMoe1xuICAgIGRhbmdlckJ1dHRvbjoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucmVkWzUwMF0sXG4gICAgICBib3JkZXJDb2xvcjogY29sb3JzLnJlZFs1MDBdLFxuICAgICAgYm9yZGVyUmFkaXVzOiAyLFxuICAgICAgaGVpZ2h0OiAzMixcbiAgICAgIGZvbnRTaXplOiAxNCxcbiAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcbiAgICAgIGxpbmVIZWlnaHQ6IDIwLFxuICAgICAgdHJhbnNpdGlvbjogJ2JhY2tncm91bmQtY29sb3IgLjFzLCBib3JkZXItY29sb3IgLjFzJyxcbiAgICAgICcmOmhvdmVyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5yZWRbMzAwXSxcbiAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5yZWRbMzAwXSxcbiAgICAgIH0sXG4gICAgICAnJjpmb2N1cyc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucmVkWzYwMF0sXG4gICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucmVkWzYwMF0sXG4gICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs4MDBdLFxuICAgICAgfSxcbiAgICAgICcmOmFjdGl2ZSc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucmVkWzYwMF0sXG4gICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucmVkWzYwMF0sXG4gICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs4MDBdLFxuICAgICAgfSxcbiAgICAgICcmLmlzLWRpc2FibGVkJzoge1xuICAgICAgICBvcGFjaXR5OiAwLjUsXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxuXG4gIHJldHVybiBhY3Rpb25TdHlsZXNcbn1cblxuZXhwb3J0IGRlZmF1bHQgRGFuZ2VyQnV0dG9uXG4iXX0=