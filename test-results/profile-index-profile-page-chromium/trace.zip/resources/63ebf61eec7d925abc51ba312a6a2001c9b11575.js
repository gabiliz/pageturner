import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditFinancialStatementsSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/test-process/financial-statements`;
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      key: "financial-statements",
      title: "DFs modelo novo",
      name: "DFs modelo novo",
      permission: "Auditoria",
      url: `${path}`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      key: "old",
      title: "DFs modelo antigo",
      name: "DFs modelo antigo",
      permission: "Auditoria",
      url: `${path}/old`
    }]
  }], [disableTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  const handleNavigateBack = useCallback(() => {
    navigate(`/audit/audits/${auditId}/control-panel/dashboard`);
  }, [auditId]);
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Demonstrações financeiras", subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx",
    lineNumber: 80,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx",
    lineNumber: 79,
    columnNumber: 64
  }, this), groups: permissionNav, onLinkClick: handleClick, disabledCollapse: true, defaultCollapsed: false, selectedKey, goBack: handleNavigateBack }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx",
    lineNumber: 79,
    columnNumber: 10
  }, this);
};
_s(AuditFinancialStatementsSideMenu, "2IYVqbLXE5PResZgaJg64BQ0GZY=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditFinancialStatementsSideMenu;
export default AuditFinancialStatementsSideMenu;
var _c;
$RefreshReg$(_c, "AuditFinancialStatementsSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditFinancialStatementSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0ZWLFNBQXlCQSxhQUFhQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFMUUsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsZ0NBQWdDO0FBQ3ZDLFNBQVNDLDBCQUEwQjtBQUVuQyxNQUFNQyxtQ0FBdUNBLE1BQU07QUFBQUMsS0FBQTtBQUNqRCxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFjLElBQUliLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSVosU0FBUztBQUMzRCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBa0IsS0FBSztBQUVyRSxRQUFNO0FBQUEsSUFBRTBCLElBQUlDO0FBQUFBLEVBQVEsSUFBSXhCLFVBQVU7QUFFbEMsUUFBTTtBQUFBLElBQUV5QixNQUFNQztBQUFBQSxFQUFNLElBQUl0QixrQkFBa0J1QixXQUFXSCxPQUFpQjtBQUV0RSxRQUFNSSxPQUFRLGlCQUFnQko7QUFFOUIsUUFBTUssZ0JBQWlDakMsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRWtDLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRVY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRUcsVUFBVUwsT0FBT00sYUFBYXZCLG1CQUFtQndCO0FBQUFBLE1BQ2pEQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFVjtBQUFBQSxJQUNWLENBQUM7QUFBQSxFQUVMLENBQUMsR0FDQSxDQUFDVCxhQUFhRSxlQUFlLENBQUM7QUFFakMsUUFBTWtCLGdCQUFnQjNDLFFBQVEsTUFBTTtBQUNsQyxVQUFNNEMsZ0JBQWlDLENBQUMsR0FBR1gsYUFBYTtBQUN4RFcsa0JBQWNDLFFBQVEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN0Q0gsb0JBQWNHLEtBQUssRUFBRWIsUUFBUVksTUFBTVosTUFBTWMsT0FBT0MsYUFBVy9CLGNBQWMrQixRQUFRUixZQUE0QixZQUFZLENBQUM7QUFBQSxJQUM1SCxDQUFDO0FBQ0QsV0FBT0c7QUFBQUEsRUFDVCxHQUFHLENBQUNYLGFBQWEsQ0FBQztBQUVsQixRQUFNaUIsY0FBY2xELFFBQVEsTUFDMUJZLDJCQUEyQkssVUFBVTBCLGFBQWEsR0FDcEQsQ0FBQzFCLFVBQVUwQixhQUFhLENBQUM7QUFFekIsUUFBTVEsY0FBY0EsQ0FBQ0MsSUFBaUJDLFNBQW9CO0FBQ3hELFFBQUlELE9BQU9FLFVBQWFELFNBQVNDLFFBQVc7QUFDMUNGLFNBQUdHLGVBQWU7QUFDbEIsVUFBSUYsS0FBS25CLE9BQU87QUFDZFIsMkJBQW1CLENBQUNELGVBQWU7QUFBQSxNQUNyQyxPQUFPO0FBQ0xULGlCQUFTcUMsS0FBS1gsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNYyxxQkFBcUIxRCxZQUFZLE1BQU07QUFDM0NrQixhQUFVLGlCQUFnQlksaUNBQWlDO0FBQUEsRUFDN0QsR0FBRyxDQUFDQSxPQUFPLENBQUM7QUFFWjdCLFlBQVUsTUFBTTtBQUNkLFVBQU0wRCxrQkFBa0IzQixPQUFPNEIsU0FBU0MsS0FBS0MsYUFBV0EsUUFBUUMscUJBQXFCLElBQUksRUFBRTtBQUMzRnJDLG1CQUFlaUMsbUJBQW1CM0IsT0FBT00sYUFBYSxDQUFDO0FBQUEsRUFDekQsR0FBRyxDQUFDTixLQUFLLENBQUM7QUFFVixTQUNFLHVCQUFDLFlBQ0MsT0FBTSw2QkFDTixVQUNFLHVCQUFDLFFBQ0MsTUFDRyxrQkFBaUJBLE9BQU9nQyxVQUFVQyx1QkFDakNqQyxPQUFPZ0MsVUFBVUUsc0JBQ1osR0FBRWxDLE9BQU9nQyxTQUFTRSxtQ0FBbUNsQyxPQUFPZ0MsVUFBVUcsbUJBQ3ZFbkMsT0FBT2dDLFVBQVVuQyxNQUd6QixRQUFPLFNBRVAsaUNBQUMsUUFDQyxRQUFRO0FBQUEsSUFDTnVDLE1BQU07QUFBQSxNQUNKQyxPQUFPaEQsT0FBT2lELEtBQUssR0FBRztBQUFBLE1BQ3RCL0MsWUFBWUEsV0FBV2dEO0FBQUFBLE1BQ3ZCL0MsVUFBVUEsU0FBU2dEO0FBQUFBLE1BQ25CQyxxQkFBcUJwRCxPQUFPaUQsS0FBSyxHQUFHO0FBQUEsTUFDcENJLFlBQVlwRCxRQUFRcUQ7QUFBQUEsTUFDcEJDLFVBQVU7QUFBQSxNQUNWQyxjQUFjdkQsUUFBUXdEO0FBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUTCxxQkFBcUJwRCxPQUFPaUQsS0FBSyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLE9BQUssTUFFSnRDO0FBQUFBLFdBQU9nQyxVQUFVZTtBQUFBQSxJQUFhO0FBQUEsSUFBSXBFLHFCQUFxQnFCLE9BQU9nQyxVQUFVRyxjQUF3QjtBQUFBLE9BakJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsR0FFRixRQUFRdEIsZUFDUixhQUFhUSxhQUNiLGtCQUFnQixNQUNoQixrQkFBa0IsT0FDbEIsYUFDQSxRQUFRSyxzQkF2Q1Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDNkI7QUFHakM7QUFBQ3pDLEdBaEhLRCxrQ0FBb0M7QUFBQSxVQUN2QlgsYUFDSUQsYUFDS0csZ0JBQ3dCSyxVQUkxQk4sV0FFQUksa0JBQWtCdUIsVUFBVTtBQUFBO0FBQUErQyxLQVZoRGhFO0FBa0hOLGVBQWVBO0FBQWdDLElBQUFnRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlUGVybWlzc2lvbnMiLCJMaW5rIiwiU2lkZU1lbnUiLCJhdWRpdFF1ZXJ5U2VydmljZSIsImZvcm1hdFByb3Bvc2FsTnVtYmVyIiwidXNlVGhlbWUiLCJUZXh0IiwiZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MiLCJBdWRpdFNpdHVhdGlvbkVudW0iLCJBdWRpdEZpbmFuY2lhbFN0YXRlbWVudHNTaWRlTWVudSIsIl9zIiwibmF2aWdhdGUiLCJwYXRobmFtZSIsImhhc1Blcm1pc3Npb24iLCJjb2xvcnMiLCJzcGFjaW5nIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwiZGlzYWJsZVRhYnMiLCJzZXREaXNhYmxlVGFicyIsImlzR3JvdXBFeHBhbmRlZCIsInNldElzR3JvdXBFeHBhbmRlZCIsImlkIiwiYXVkaXRJZCIsImRhdGEiLCJhdWRpdCIsInVzZUZpbmRPbmUiLCJwYXRoIiwibmF2TGlua0dyb3VwcyIsImxpbmtzIiwiZGlzYWJsZWQiLCJzaXR1YWNhbyIsIkNhbmNlbGFkbyIsImtleSIsInRpdGxlIiwibmFtZSIsInBlcm1pc3Npb24iLCJ1cmwiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZU5hdmlnYXRlQmFjayIsInZlcmlmeVNpdHVhdGlvbiIsImVtcHJlc2FzIiwic29tZSIsImVtcHJlc2EiLCJzaXR1YWNhb1JldmlzYW8iLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsInJvb3QiLCJjb2xvciIsImdyYXkiLCJzZW1pYm9sZCIsInAxNCIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJtYXJnaW5MZWZ0IiwibGciLCJtYXhXaWR0aCIsIm1hcmdpbkJvdHRvbSIsIm1kIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdEZpbmFuY2lhbFN0YXRlbWVudFNpZGVNZW51LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYXVkaXQvY29tcG9uZW50cy9BdWRpdEZpbmFuY2lhbFN0YXRlbWVudFNpZGVNZW51LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBNb3VzZUV2ZW50LCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJTmF2TGlua0dyb3VwLCBJTmF2TGluayB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC9saWIvTmF2J1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHNlcnZpY2VDb2RlcywgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xyXG5pbXBvcnQgeyBMaW5rLCBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBhdWRpdFF1ZXJ5U2VydmljZSB9IGZyb20gJy4uL2F1ZGl0cy9zZXJ2aWNlcydcclxuaW1wb3J0IHsgZm9ybWF0UHJvcG9zYWxOdW1iZXIgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvdXRpbHMnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MgZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzL2dldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzJ1xyXG5pbXBvcnQgeyBBdWRpdFNpdHVhdGlvbkVudW0gfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvZW51bXMvQXVkaXRTaXR1YXRpb25FbnVtJ1xyXG5cclxuY29uc3QgQXVkaXRGaW5hbmNpYWxTdGF0ZW1lbnRzU2lkZU1lbnU6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcclxuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZywgZm9udFdlaWdodCwgZm9udFNpemUgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBbZGlzYWJsZVRhYnMsIHNldERpc2FibGVUYWJzXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtpc0dyb3VwRXhwYW5kZWQsIHNldElzR3JvdXBFeHBhbmRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSlcclxuXHJcbiAgY29uc3QgeyBpZDogYXVkaXRJZCB9ID0gdXNlUGFyYW1zKClcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBhdWRpdCB9ID0gYXVkaXRRdWVyeVNlcnZpY2UudXNlRmluZE9uZShhdWRpdElkIGFzIHN0cmluZylcclxuXHJcbiAgY29uc3QgcGF0aCA9IGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC90ZXN0LXByb2Nlc3MvZmluYW5jaWFsLXN0YXRlbWVudHNgXHJcblxyXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBrZXk6ICdmaW5hbmNpYWwtc3RhdGVtZW50cycsXHJcbiAgICAgICAgICB0aXRsZTogJ0RGcyBtb2RlbG8gbm92bycsXHJcbiAgICAgICAgICBuYW1lOiAnREZzIG1vZGVsbyBub3ZvJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAga2V5OiAnb2xkJyxcclxuICAgICAgICAgIHRpdGxlOiAnREZzIG1vZGVsbyBhbnRpZ28nLFxyXG4gICAgICAgICAgbmFtZTogJ0RGcyBtb2RlbG8gYW50aWdvJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9vbGRgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gIF0sIFtkaXNhYmxlVGFicywgaXNHcm91cEV4cGFuZGVkXSlcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbk5hdiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gWy4uLm5hdkxpbmtHcm91cHNdXHJcbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyb3VwLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5wZXJtaXNzaW9uIGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInKSlcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZmlsdGVyZWRHcm91cFxyXG4gIH0sIFtuYXZMaW5rR3JvdXBzXSlcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRLZXkgPSB1c2VNZW1vKCgpID0+XHJcbiAgICBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyhwYXRobmFtZSwgcGVybWlzc2lvbk5hdiksXHJcbiAgW3BhdGhuYW1lLCBwZXJtaXNzaW9uTmF2XSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoZXY/OiBNb3VzZUV2ZW50LCBpdGVtPzogSU5hdkxpbmspID0+IHtcclxuICAgIGlmIChldiAhPT0gdW5kZWZpbmVkICYmIGl0ZW0gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgIGlmIChpdGVtLmxpbmtzKSB7XHJcbiAgICAgICAgc2V0SXNHcm91cEV4cGFuZGVkKCFpc0dyb3VwRXhwYW5kZWQpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5hdmlnYXRlQmFjayA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIG5hdmlnYXRlKGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC9kYXNoYm9hcmRgKVxyXG4gIH0sIFthdWRpdElkXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHZlcmlmeVNpdHVhdGlvbiA9IGF1ZGl0Py5lbXByZXNhcy5zb21lKGVtcHJlc2EgPT4gZW1wcmVzYS5zaXR1YWNhb1JldmlzYW8gPT09ICgwIHwgMSkpIGFzIGJvb2xlYW5cclxuICAgIHNldERpc2FibGVUYWJzKHZlcmlmeVNpdHVhdGlvbiB8fCBhdWRpdD8uc2l0dWFjYW8gPT09IDApXHJcbiAgfSwgW2F1ZGl0XSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTaWRlTWVudVxyXG4gICAgICB0aXRsZT0nRGVtb25zdHJhw6fDtWVzIGZpbmFuY2VpcmFzJ1xyXG4gICAgICBzdWJ0aXRsZT17XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIGhyZWY9e1xyXG4gICAgICAgICAgICBgL2FkbWluL2NsaWVudHMvJHthdWRpdD8uY29udHJhdG8/LmNsaWVudGVJZH0vY29udHJhY3RzLyR7XHJcbiAgICAgICAgICAgICAgYXVkaXQ/LmNvbnRyYXRvPy5jb250cmF0b1ByaW5jaXBhbElkXHJcbiAgICAgICAgICAgICAgICA/IGAke2F1ZGl0Py5jb250cmF0by5jb250cmF0b1ByaW5jaXBhbElkfT9zdWJjb250cmFjdD0ke2F1ZGl0Py5jb250cmF0bz8ubnVtZXJvUHJvcG9zdGF9YFxyXG4gICAgICAgICAgICAgICAgOiBhdWRpdD8uY29udHJhdG8/LmlkXHJcbiAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0YXJnZXQ9XCJibGFua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnNlbWlib2xkLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnRTaXplLnAxNCxcclxuICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiBzcGFjaW5nLmxnLFxyXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6IDIwMCxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy5tZCxcclxuICAgICAgICAgICAgICAgICc6OmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7YXVkaXQ/LmNvbnRyYXRvPy5ub21lRmFudGFzaWF9IC0ge2Zvcm1hdFByb3Bvc2FsTnVtYmVyKGF1ZGl0Py5jb250cmF0bz8ubnVtZXJvUHJvcG9zdGEgYXMgc3RyaW5nKX1cclxuICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIH1cclxuICAgICAgZ3JvdXBzPXtwZXJtaXNzaW9uTmF2fVxyXG4gICAgICBvbkxpbmtDbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgIGRpc2FibGVkQ29sbGFwc2VcclxuICAgICAgZGVmYXVsdENvbGxhcHNlZD17ZmFsc2V9XHJcbiAgICAgIHNlbGVjdGVkS2V5PXtzZWxlY3RlZEtleX1cclxuICAgICAgZ29CYWNrPXtoYW5kbGVOYXZpZ2F0ZUJhY2t9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRGaW5hbmNpYWxTdGF0ZW1lbnRzU2lkZU1lbnVcclxuIl19