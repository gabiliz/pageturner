import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Label, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useId } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Checkbox } from "/src/shared/components/checkbox/index.ts";
import { FlexRow } from "/src/shared/components/FlexBox/index.ts";
const NotificationsCenterSettingsCheckboxItem = (props) => {
  _s();
  const {
    id,
    description
  } = props;
  const theme = useTheme();
  const fieldKey = useId(id);
  return /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 8, children: [
    /* @__PURE__ */ jsxDEV(Checkbox, { id: fieldKey, ...props }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Label, { htmlFor: fieldKey, children: /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        fontSize: theme.fontSize.p14
      }
    }, children: description }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterSettingsCheckboxItem, "qDf8Mfvk86+XPuE2s6tHXClSz3Q=", false, function() {
  return [useTheme, useId];
});
_c = NotificationsCenterSettingsCheckboxItem;
export default NotificationsCenterSettingsCheckboxItem;
var _c;
$RefreshReg$(_c, "NotificationsCenterSettingsCheckboxItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterSettingsCheckboxItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJOLFNBQXlCQSxPQUFPQyxZQUFZO0FBQzVDLFNBQVNDLGFBQWE7QUFFdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBTXhCLE1BQU1DLDBDQUE2RkMsV0FBVTtBQUFBQyxLQUFBO0FBQzNHLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFJQztBQUFBQSxFQUFZLElBQUlIO0FBQzVCLFFBQU1JLFFBQVFSLFNBQVM7QUFDdkIsUUFBTVMsV0FBV1YsTUFBTU8sRUFBRTtBQUV6QixTQUNFLHVCQUFDLFdBQVEsZUFBYyxVQUFTLEtBQUssR0FDbkM7QUFBQSwyQkFBQyxZQUNDLElBQUlHLFVBQ0osR0FBSUwsU0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRVk7QUFBQSxJQUVaLHVCQUFDLFNBQU0sU0FBU0ssVUFDZCxpQ0FBQyxRQUFLLFFBQVE7QUFBQSxNQUNaQyxNQUFNO0FBQUEsUUFDSkMsVUFBVUgsTUFBTUcsU0FBU0M7QUFBQUEsTUFDM0I7QUFBQSxJQUNGLEdBRUdMLHlCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ0YsR0F2QktGLHlDQUF5RjtBQUFBLFVBRS9FSCxVQUNHRCxLQUFLO0FBQUE7QUFBQWMsS0FIbEJWO0FBeUJOLGVBQWVBO0FBQXVDLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMYWJlbCIsIlRleHQiLCJ1c2VJZCIsInVzZVRoZW1lIiwiQ2hlY2tib3giLCJGbGV4Um93IiwiTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ2hlY2tib3hJdGVtIiwicHJvcHMiLCJfcyIsImlkIiwiZGVzY3JpcHRpb24iLCJ0aGVtZSIsImZpZWxkS2V5Iiwicm9vdCIsImZvbnRTaXplIiwicDE0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9jb21wb25lbnRzL05vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NoZWNrYm94SXRlbS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJQ2hlY2tib3hQcm9wcywgTGFiZWwsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VJZCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzJ1xuaW1wb3J0IHsgQ2hlY2tib3ggfSBmcm9tICcuLi8uLi9jaGVja2JveCdcbmltcG9ydCB7IEZsZXhSb3cgfSBmcm9tICcuLi8uLi9GbGV4Qm94J1xuXG5pbnRlcmZhY2UgTm90aWZpY2F0aW9uc0NlbnRlclNldHRpbmdzQ2hlY2tib3hJdGVtUHJvcHMgZXh0ZW5kcyBJQ2hlY2tib3hQcm9wc3tcbiAgZGVzY3JpcHRpb246IHN0cmluZ1xufVxuXG5jb25zdCBOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW06IEZDPE5vdGlmaWNhdGlvbnNDZW50ZXJTZXR0aW5nc0NoZWNrYm94SXRlbVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGlkLCBkZXNjcmlwdGlvbiB9ID0gcHJvcHNcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXG4gIGNvbnN0IGZpZWxkS2V5ID0gdXNlSWQoaWQpXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleFJvdyB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInIGdhcD17OH0+XG4gICAgICA8Q2hlY2tib3hcbiAgICAgICAgaWQ9e2ZpZWxkS2V5fVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgICAgPExhYmVsIGh0bWxGb3I9e2ZpZWxkS2V5fT5cbiAgICAgICAgPFRleHQgc3R5bGVzPXt7XG4gICAgICAgICAgcm9vdDoge1xuICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLnAxNCxcbiAgICAgICAgICB9LFxuICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge2Rlc2NyaXB0aW9ufVxuICAgICAgICA8L1RleHQ+XG4gICAgICA8L0xhYmVsPlxuICAgIDwvRmxleFJvdz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25zQ2VudGVyU2V0dGluZ3NDaGVja2JveEl0ZW1cbiJdfQ==