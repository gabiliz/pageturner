const navLinkGroups = [
  {
    links: [
      {
        key: "profiles",
        name: "Perfis",
        permission: "Perfil",
        icon: "ContactInfo",
        url: "/admin/profiles",
        onlyAdmin: true
      },
      {
        key: "roles",
        name: "Cargos",
        icon: "AccountManagement",
        permission: "Cargo",
        url: "/admin/roles"
      },
      {
        key: "users",
        name: "Usuários",
        icon: "People",
        permission: "Usuario",
        url: "/admin/users",
        onlyAdmin: true
      },
      {
        key: "offices",
        name: "Escritórios",
        icon: "CityNext",
        permission: "Escritorio",
        url: "/admin/offices",
        onlyAdmin: true
      },
      {
        key: "layoutBalance",
        name: "Layout balancete",
        icon: "MapLayers",
        permission: "LayoutBalancete",
        url: "/admin/layoutBalance"
      },
      {
        key: "clients",
        name: "Clientes",
        icon: "ShopServer",
        permission: "Cliente",
        url: "/admin/clients"
      }
    ]
  }
];
export default navLinkGroups;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpbmtzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElOYXZMaW5rR3JvdXAgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5cbmNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IFtcbiAge1xuICAgIGxpbmtzOiBbXG4gICAgICB7XG4gICAgICAgIGtleTogJ3Byb2ZpbGVzJyxcbiAgICAgICAgbmFtZTogJ1BlcmZpcycsXG4gICAgICAgIHBlcm1pc3Npb246ICdQZXJmaWwnLFxuICAgICAgICBpY29uOiAnQ29udGFjdEluZm8nLFxuICAgICAgICB1cmw6ICcvYWRtaW4vcHJvZmlsZXMnLFxuICAgICAgICBvbmx5QWRtaW46IHRydWUsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBrZXk6ICdyb2xlcycsXG4gICAgICAgIG5hbWU6ICdDYXJnb3MnLFxuICAgICAgICBpY29uOiAnQWNjb3VudE1hbmFnZW1lbnQnLFxuICAgICAgICBwZXJtaXNzaW9uOiAnQ2FyZ28nLFxuICAgICAgICB1cmw6ICcvYWRtaW4vcm9sZXMnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAga2V5OiAndXNlcnMnLFxuICAgICAgICBuYW1lOiAnVXN1w6FyaW9zJyxcbiAgICAgICAgaWNvbjogJ1Blb3BsZScsXG4gICAgICAgIHBlcm1pc3Npb246ICdVc3VhcmlvJyxcbiAgICAgICAgdXJsOiAnL2FkbWluL3VzZXJzJyxcbiAgICAgICAgb25seUFkbWluOiB0cnVlLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAga2V5OiAnb2ZmaWNlcycsXG4gICAgICAgIG5hbWU6ICdFc2NyaXTDs3Jpb3MnLFxuICAgICAgICBpY29uOiAnQ2l0eU5leHQnLFxuICAgICAgICBwZXJtaXNzaW9uOiAnRXNjcml0b3JpbycsXG4gICAgICAgIHVybDogJy9hZG1pbi9vZmZpY2VzJyxcbiAgICAgICAgb25seUFkbWluOiB0cnVlLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAga2V5OiAnbGF5b3V0QmFsYW5jZScsXG4gICAgICAgIG5hbWU6ICdMYXlvdXQgYmFsYW5jZXRlJyxcbiAgICAgICAgaWNvbjogJ01hcExheWVycycsXG4gICAgICAgIHBlcm1pc3Npb246ICdMYXlvdXRCYWxhbmNldGUnLFxuICAgICAgICB1cmw6ICcvYWRtaW4vbGF5b3V0QmFsYW5jZScsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBrZXk6ICdjbGllbnRzJyxcbiAgICAgICAgbmFtZTogJ0NsaWVudGVzJyxcbiAgICAgICAgaWNvbjogJ1Nob3BTZXJ2ZXInLFxuICAgICAgICBwZXJtaXNzaW9uOiAnQ2xpZW50ZScsXG4gICAgICAgIHVybDogJy9hZG1pbi9jbGllbnRzJyxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbl1cblxuZXhwb3J0IGRlZmF1bHQgbmF2TGlua0dyb3Vwc1xuIl0sIm1hcHBpbmdzIjoiQUFFQSxNQUFNLGdCQUFpQztBQUFBLEVBQ3JDO0FBQUEsSUFDRSxPQUFPO0FBQUEsTUFDTDtBQUFBLFFBQ0UsS0FBSztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sWUFBWTtBQUFBLFFBQ1osTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBLFFBQ0wsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRSxLQUFLO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixNQUFNO0FBQUEsUUFDTixZQUFZO0FBQUEsUUFDWixLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQ0E7QUFBQSxRQUNFLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFlBQVk7QUFBQSxRQUNaLEtBQUs7QUFBQSxRQUNMLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFDQTtBQUFBLFFBQ0UsS0FBSztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLFFBQ04sWUFBWTtBQUFBLFFBQ1osS0FBSztBQUFBLFFBQ0wsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRSxLQUFLO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixNQUFNO0FBQUEsUUFDTixZQUFZO0FBQUEsUUFDWixLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQ0E7QUFBQSxRQUNFLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFlBQVk7QUFBQSxRQUNaLEtBQUs7QUFBQSxNQUNQO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==