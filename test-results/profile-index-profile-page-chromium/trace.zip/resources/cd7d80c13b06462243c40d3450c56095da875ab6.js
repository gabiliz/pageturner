import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTableContent.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { DetailsList, DetailsListLayoutMode, Selection, SelectionMode, IconButton, DirectionalHint, DetailsRow, ConstrainMode, StickyPositionType, Sticky, TooltipOverflowMode, DetailsHeader, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useCallback = __vite__cjsImport4_react["useCallback"]; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"]; const useLayoutEffect = __vite__cjsImport4_react["useLayoutEffect"];
import { get } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
import { TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { ControlsColumnNameEnum } from "/src/shared/enums/ControlsColumnNameEnum.ts";
function DataTableContent(props) {
  _s();
  const {
    columns,
    items,
    multipleSelection = true,
    selection,
    onSelection,
    onHeaderClick,
    sortConfig,
    hasControlsColumn = false,
    menuOptions,
    onRenderMenuItem,
    hasSelection = true,
    groups,
    compact,
    onRenderFooter,
    notScrollable,
    isHeaderVisible,
    externalRowStyles,
    paginated,
    controlsColumnName,
    onSingleActionControlClick,
    disableMenu,
    disableMenuText,
    onMenuOpened,
    onMenuDismissed
  } = props;
  const tableSizeRef = useRef(null);
  const [tableWidth, setTableWidth] = useState(tableSizeRef.current?.clientWidth);
  const [mappedColumns, setMappedColumns] = useState([]);
  const {
    listHeader,
    checkBox
  } = useStyles();
  useLayoutEffect(() => {
    setMappedColumns(convertColumns(columns, hasControlsColumn, controlsColumnName, sortConfig));
  }, [columns, controlsColumnName, hasControlsColumn]);
  const resizeTable = useCallback(() => {
    setTableWidth(tableSizeRef.current?.clientWidth);
  }, [tableSizeRef]);
  useEffect(() => {
    window.addEventListener("resize", resizeTable);
    return () => window.removeEventListener("resize", resizeTable);
  }, [resizeTable]);
  useEffect(() => {
    resizeTable();
  }, [resizeTable]);
  const localSelection = useMemo(() => new Selection({
    canSelectItem: () => true,
    onSelectionChanged: () => {
      onSelection?.(localSelection.getSelection());
    },
    getKey: (item) => item.id ?? "",
    selectionMode: multipleSelection ? SelectionMode.multiple : SelectionMode.single
  }), [multipleSelection]);
  useEffect(() => {
    if (selection && (selection.length !== localSelection.getSelectedCount() || selection.some(({
      id
    }) => id && !localSelection.isKeySelected(id)))) {
      localSelection.setChangeEvents(false);
      selection.forEach(({
        id
      }) => id && localSelection.setKeySelected(id, true, true));
      localSelection.setChangeEvents(true);
    }
  }, [selection]);
  useEffect(() => {
    if (selection?.some((selected) => items.some((item) => item.id !== selected.id))) {
      localSelection.setAllSelected(false);
      return;
    }
    onSelection?.(localSelection.getSelection());
  }, [items]);
  const handleHeaderClick = useCallback((_, column) => {
    const isSortedDescending = !column?.isSorted || !column?.isSortedDescending;
    setMappedColumns((mappedColumns2) => mappedColumns2.map((col) => {
      const isSorted = col.key === column?.key;
      return {
        ...col,
        isSorted,
        isSortedDescending: isSorted && isSortedDescending
      };
    }));
    onHeaderClick?.({
      field: column?.fieldName ?? "",
      descending: isSortedDescending
    });
  }, [onHeaderClick]);
  const renderItemColumn = useCallback((disableMenu2) => (
    // eslint-disable-next-line react/display-name
    (item, _, column) => {
      const fieldName = column?.fieldName ?? "";
      const changeMenuOpened = () => {
        if (onMenuOpened)
          onMenuOpened(item);
      };
      const changeMenuDismissed = () => {
        if (onMenuDismissed)
          onMenuDismissed(item);
      };
      if (fieldName === ControlsColumnNameEnum.CONTROLS) {
        const menuProps = (item2) => ({
          items: menuOptions?.(item2) ?? [],
          onRenderContextualMenuItem: onRenderMenuItem,
          directionalHint: DirectionalHint.bottomRightEdge,
          onMenuOpened: changeMenuOpened,
          onMenuDismissed: changeMenuDismissed
        });
        return /* @__PURE__ */ jsxDEV(TooltipHost, { content: disableMenuText, children: /* @__PURE__ */ jsxDEV(IconButton, { menuProps: menuProps(item), onRenderMenuIcon: () => /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
          lineNumber: 146,
          columnNumber: 75
        }, this), iconProps: {
          iconName: controlIcon[fieldName]
        }, disabled: disableMenu2, style: {
          marginTop: "-6px",
          marginBottom: "-6px"
        } }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
          lineNumber: 146,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
          lineNumber: 145,
          columnNumber: 14
        }, this);
      }
      if (Object.values(ControlsColumnNameEnum).includes(fieldName) && fieldName !== ControlsColumnNameEnum.CONTROLS) {
        return /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
          iconName: controlIcon[fieldName]
        }, onClick: () => onSingleActionControlClick ? onSingleActionControlClick(item) : {}, disabled: disableMenu2, style: {
          marginTop: "-6px",
          marginBottom: "-6px"
        } }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
          lineNumber: 155,
          columnNumber: 14
        }, this);
      }
      return /* @__PURE__ */ jsxDEV(TooltipHost, { content: item[fieldName], overflowMode: TooltipOverflowMode.Parent, children: item[fieldName] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
        lineNumber: 162,
        columnNumber: 12
      }, this);
    }
  ), [menuOptions, onSingleActionControlClick, onRenderMenuItem, disableMenuText]);
  const colors = useThemeColors();
  const onRenderRow = useCallback((props2) => {
    return props2 && /* @__PURE__ */ jsxDEV(DetailsRow, { ...props2, styles: externalRowStyles || {
      root: {
        color: colors.black,
        userSelect: "auto",
        borderBottomWidth: "1px",
        borderBottomStyle: "solid",
        borderBottomColor: `${colors.gray[300]}`
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
      lineNumber: 168,
      columnNumber: 21
    }, this);
  }, []);
  const onRenderHeader = useCallback((headerProps) => {
    return /* @__PURE__ */ jsxDEV(Sticky, { stickyPosition: StickyPositionType.Header, isScrollSynced: true, stickyBackgroundColor: "transparent", children: /* @__PURE__ */ jsxDEV(DetailsHeader, { ...headerProps, className: listHeader }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
      lineNumber: 180,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
      lineNumber: 179,
      columnNumber: 12
    }, this);
  }, []);
  const textFieldStyles = {
    root: {
      maxWidth: tableWidth,
      overflowX: notScrollable ? "visible" : "auto"
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { ref: tableSizeRef, style: {
    zIndex: 0
  }, children: /* @__PURE__ */ jsxDEV(DetailsList, { disableSelectionZone: disableMenu, columns: mappedColumns, items, setKey: "id", groups, styles: textFieldStyles, className: checkBox, constrainMode: paginated ? void 0 : ConstrainMode.unconstrained, layoutMode: DetailsListLayoutMode.justified, selectionMode: hasSelection ? SelectionMode.multiple : SelectionMode.none, selection: localSelection, selectionPreservedOnEmptyClick: true, onColumnHeaderClick: handleHeaderClick, onRenderItemColumn: (item, _, column) => renderItemColumn(disableMenu)(item, _, column), compact, isHeaderVisible, groupProps: {
    onRenderFooter
  }, onRenderRow, onRenderDetailsHeader: onRenderHeader }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
    lineNumber: 192,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
    lineNumber: 189,
    columnNumber: 10
  }, this);
}
_s(DataTableContent, "3zpUbli+ZvtYBo/oSoUpDff2Z14=", false, function() {
  return [useStyles, useThemeColors];
});
_c = DataTableContent;
function convertColumns(columns, hasControls = false, controlsColumnName, sortConfig) {
  const result = columns.filter((column) => !column.blockShowing).map((column, index, list) => {
    const resultColumn = {
      key: `${index}`,
      name: column.header || "",
      isSorted: !column.sortable ? false : sortConfig?.field === column.field || sortConfig === void 0 && index === 0,
      isSortedDescending: sortConfig?.descending ?? false,
      isResizable: true,
      minWidth: column.minWidth || 150,
      maxWidth: column.maxWidth ?? index < list.length - 1 ? column.minWidth ? column.minWidth : 300 : void 0,
      columnActionsMode: column.sortable ? 1 : 0,
      headerClassName: "headerStyle",
      styles: {
        root: {
          selectors: {
            ".ms-DetailsHeader-cellTitle": {
              justifyContent: column.alignTableItems ?? "start"
            }
          }
        }
      }
    };
    resultColumn.fieldName = column.field;
    if (column.format) {
      resultColumn.onRender = column.format;
    } else {
      if (/[.[]/.test(column.field)) {
        resultColumn.onRender = (item) => /* @__PURE__ */ jsxDEV("span", { style: {
          display: "block",
          textAlign: column.alignTableItems ?? "start"
        }, children: get(item, column.field) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx",
          lineNumber: 228,
          columnNumber: 46
        }, this);
      }
    }
    return resultColumn;
  });
  if (hasControls) {
    result.push({
      key: `${result.length}`,
      name: "",
      fieldName: controlsColumnName,
      minWidth: 32,
      maxWidth: 32
    });
  }
  return result;
}
const useStyles = () => {
  _s2();
  const colors = useThemeColors();
  const actionStyles = mergeStyleSets({
    listHeader: {
      padding: 0,
      "&>div": {
        backgroundColor: colors.gray[200]
      }
    },
    checkBox: {
      ".is-checked::before": {
        background: `${colors.purple[800]} none repeat scroll 0% 0%`
      }
    }
  });
  return actionStyles;
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
const controlIcon = {
  controls: "More",
  delete: "Delete",
  edit: "Edit"
};
export default DataTableContent;
var _c;
$RefreshReg$(_c, "DataTableContent");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableContent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBME1vQzs7Ozs7Ozs7Ozs7Ozs7OztBQTFNcEMsU0FDRUEsYUFFQUMsdUJBQ0FDLFdBQ0FDLGVBQ0FDLFlBR0FDLGlCQUVBQyxZQU1BQyxlQUNBQyxvQkFDQUMsUUFDQUMscUJBRUFDLGVBQ0FDLHNCQUVLO0FBQ1AsU0FFRUMsU0FDQUMsYUFDQUMsVUFFQUMsV0FDQUMsUUFDQUMsdUJBQ0s7QUFDUCxTQUFTQyxXQUFXO0FBR3BCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsOEJBQThCO0FBNEJ2QyxTQUFTQyxpQkFBb0NDLE9BQStDO0FBQUFDLEtBQUE7QUFDMUYsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLG9CQUFvQjtBQUFBLElBQ3BCQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxvQkFBb0I7QUFBQSxJQUNwQkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsZUFBZTtBQUFBLElBQ2ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSXpCO0FBRUosUUFBTTBCLGVBQWVqQyxPQUF1QixJQUFJO0FBQ2hELFFBQU0sQ0FBQ2tDLFlBQVlDLGFBQWEsSUFBSXJDLFNBQVNtQyxhQUFhRyxTQUFTQyxXQUFXO0FBQzlFLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUl6QyxTQUFvQixFQUFFO0FBRWhFLFFBQU07QUFBQSxJQUFFMEM7QUFBQUEsSUFBWUM7QUFBQUEsRUFBUyxJQUFJQyxVQUFVO0FBRTNDekMsa0JBQWdCLE1BQU07QUFDcEJzQyxxQkFBaUJJLGVBQ2ZsQyxTQUNBTyxtQkFDQVcsb0JBQ0FaLFVBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDTixTQUFTa0Isb0JBQW9CWCxpQkFBaUIsQ0FBQztBQUVuRCxRQUFNNEIsY0FBYy9DLFlBQVksTUFBTTtBQUNwQ3NDLGtCQUFjRixhQUFhRyxTQUFTQyxXQUFXO0FBQUEsRUFDakQsR0FBRyxDQUFDSixZQUFZLENBQUM7QUFFakJsQyxZQUFVLE1BQU07QUFDZDhDLFdBQU9DLGlCQUFpQixVQUFVRixXQUFXO0FBQzdDLFdBQU8sTUFBTUMsT0FBT0Usb0JBQW9CLFVBQVVILFdBQVc7QUFBQSxFQUMvRCxHQUFHLENBQUNBLFdBQVcsQ0FBQztBQUVoQjdDLFlBQVUsTUFBTTtBQUNkNkMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ0EsV0FBVyxDQUFDO0FBRWhCLFFBQU1JLGlCQUE0QnBELFFBQVEsTUFBTSxJQUFJWCxVQUFVO0FBQUEsSUFDNURnRSxlQUFlQSxNQUFNO0FBQUEsSUFDckJDLG9CQUFvQkEsTUFBTTtBQUN4QnJDLG9CQUFjbUMsZUFBZUcsYUFBYSxDQUFRO0FBQUEsSUFDcEQ7QUFBQSxJQUNBQyxRQUFTQyxVQUFVQSxLQUFXQyxNQUFNO0FBQUEsSUFDcENDLGVBQWU1QyxvQkFDWHpCLGNBQWNzRSxXQUNkdEUsY0FBY3VFO0FBQUFBLEVBQ3BCLENBQUMsR0FBRyxDQUFDOUMsaUJBQWlCLENBQUM7QUFFdkJaLFlBQVUsTUFBTTtBQUNkLFFBQUlhLGNBQ0ZBLFVBQVU4QyxXQUFXVixlQUFlVyxpQkFBaUIsS0FDckQvQyxVQUFVZ0QsS0FDUixDQUFDO0FBQUEsTUFBRU47QUFBQUEsSUFBRyxNQUFNQSxNQUFNLENBQUNOLGVBQWVhLGNBQWNQLEVBQUUsQ0FDcEQsSUFDQztBQUNETixxQkFBZWMsZ0JBQWdCLEtBQUs7QUFFcENsRCxnQkFBVW1ELFFBQ1IsQ0FBQztBQUFBLFFBQUVUO0FBQUFBLE1BQUcsTUFBTUEsTUFBTU4sZUFBZWdCLGVBQWVWLElBQUksTUFBTSxJQUFJLENBQ2hFO0FBQ0FOLHFCQUFlYyxnQkFBZ0IsSUFBSTtBQUFBLElBQ3JDO0FBQUEsRUFDRixHQUFHLENBQUNsRCxTQUFTLENBQUM7QUFFZGIsWUFBVSxNQUFNO0FBQ2QsUUFDRWEsV0FBV2dELEtBQ1JLLGNBQWF2RCxNQUFNa0QsS0FBS1AsVUFBUUEsS0FBS0MsT0FBT1csU0FBU1gsRUFBRSxDQUMxRCxHQUNBO0FBQ0FOLHFCQUFla0IsZUFBZSxLQUFLO0FBQ25DO0FBQUEsSUFDRjtBQUVBckQsa0JBQWNtQyxlQUFlRyxhQUFhLENBQVE7QUFBQSxFQUNwRCxHQUFHLENBQUN6QyxLQUFLLENBQUM7QUFFVixRQUFNeUQsb0JBQW9CdEUsWUFBWSxDQUFDdUUsR0FBNkJDLFdBQXFCO0FBQ3ZGLFVBQU1DLHFCQUFxQixDQUFDRCxRQUFRRSxZQUFZLENBQUNGLFFBQVFDO0FBQ3pEL0IscUJBQWlCRCxvQkFBaUJBLGVBQWNrQyxJQUFJQyxTQUFPO0FBQ3pELFlBQU1GLFdBQVdFLElBQUlDLFFBQVFMLFFBQVFLO0FBQ3JDLGFBQU87QUFBQSxRQUNMLEdBQUdEO0FBQUFBLFFBQ0hGO0FBQUFBLFFBQ0FELG9CQUFvQkMsWUFBWUQ7QUFBQUEsTUFDbEM7QUFBQSxJQUNGLENBQUMsQ0FBQztBQUNGeEQsb0JBQWdCO0FBQUEsTUFDZDZELE9BQU9OLFFBQVFPLGFBQWE7QUFBQSxNQUM1QkMsWUFBWVA7QUFBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUN4RCxhQUFhLENBQUM7QUFFbEIsUUFBTWdFLG1CQUFtQmpGLFlBQVksQ0FBQ2dDO0FBQUFBO0FBQUFBLElBRXBDLENBQUN3QixNQUFTZSxHQUFZQyxXQUFxQjtBQUN6QyxZQUFNTyxZQUFZUCxRQUFRTyxhQUFhO0FBQ3ZDLFlBQU1HLG1CQUFtQkEsTUFBTTtBQUM3QixZQUFJaEQ7QUFBY0EsdUJBQWFzQixJQUFJO0FBQUEsTUFDckM7QUFDQSxZQUFNMkIsc0JBQXNCQSxNQUFNO0FBQ2hDLFlBQUloRDtBQUFpQkEsMEJBQWdCcUIsSUFBSTtBQUFBLE1BQzNDO0FBQ0EsVUFBSXVCLGNBQWN2RSx1QkFBdUI0RSxVQUFVO0FBQ2pELGNBQU1DLFlBQVlBLENBQUM3QixXQUFtQztBQUFBLFVBQ3BEM0MsT0FBT08sY0FBY29DLEtBQUksS0FBSztBQUFBLFVBQzlCOEIsNEJBQTRCakU7QUFBQUEsVUFDNUJrRSxpQkFBaUJoRyxnQkFBZ0JpRztBQUFBQSxVQUNqQ3RELGNBQWNnRDtBQUFBQSxVQUNkL0MsaUJBQWlCZ0Q7QUFBQUEsUUFDbkI7QUFDQSxlQUFPLHVCQUFDLGVBQVksU0FBU2xELGlCQUMzQixpQ0FBQyxjQUNDLFdBQVdvRCxVQUFVN0IsSUFBSSxHQUN6QixrQkFBa0IsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUUsR0FDMUIsV0FBVztBQUFBLFVBQUVpQyxVQUFVQyxZQUFZWCxTQUFTO0FBQUEsUUFBRSxHQUM5QyxVQUFVL0MsY0FDVixPQUFPO0FBQUEsVUFDTDJELFdBQVc7QUFBQSxVQUNYQyxjQUFjO0FBQUEsUUFDaEIsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUksS0FUQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV1A7QUFBQSxNQUNGO0FBRUEsVUFDRUMsT0FBT0MsT0FBT3RGLHNCQUFzQixFQUFFdUYsU0FBU2hCLFNBQW1DLEtBQ2xGQSxjQUFjdkUsdUJBQXVCNEUsVUFDckM7QUFDQSxlQUFPLHVCQUFDLGNBQ04sV0FBVztBQUFBLFVBQUVLLFVBQVVDLFlBQVlYLFNBQW1DO0FBQUEsUUFBRSxHQUN4RSxTQUFTLE1BQU1oRCw2QkFBNkJBLDJCQUEyQnlCLElBQUksSUFBSSxDQUFDLEdBQ2hGLFVBQVV4QixjQUNWLE9BQU87QUFBQSxVQUNMMkQsV0FBVztBQUFBLFVBQ1hDLGNBQWM7QUFBQSxRQUNoQixLQVBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPSDtBQUFBLE1BRU47QUFFQSxhQUFPLHVCQUFDLGVBQ04sU0FBU3BDLEtBQUt1QixTQUFTLEdBQ3ZCLGNBQWNuRixvQkFBb0JvRyxRQUVqQ3hDLGVBQUt1QixTQUFTLEtBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtQO0FBQUEsSUFDRjtBQUFBLEtBQ0YsQ0FDRTNELGFBQ0FXLDRCQUNBVixrQkFDQVksZUFBZSxDQUVqQjtBQUVBLFFBQU1nRSxTQUFTM0YsZUFBZTtBQUU5QixRQUFNNEYsY0FBY2xHLFlBQVksQ0FBQ1UsV0FBd0M7QUFDdkUsV0FBT0EsVUFBUyx1QkFBQyxjQUNmLEdBQUlBLFFBQ0osUUFBUWtCLHFCQUFxQjtBQUFBLE1BQzNCdUUsTUFBTTtBQUFBLFFBQ0pDLE9BQU9ILE9BQU9JO0FBQUFBLFFBQ2RDLFlBQVk7QUFBQSxRQUNaQyxtQkFBbUI7QUFBQSxRQUNuQkMsbUJBQW1CO0FBQUEsUUFDbkJDLG1CQUFvQixHQUFFUixPQUFPUyxLQUFLLEdBQUc7QUFBQSxNQUN2QztBQUFBLElBQ0YsS0FWYztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVVo7QUFBQSxFQUVOLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGlCQUFpQjNHLFlBQWE0RyxpQkFBZ0I7QUFDbEQsV0FDRSx1QkFBQyxVQUNDLGdCQUFnQmxILG1CQUFtQm1ILFFBQ25DLGdCQUFnQixNQUNoQix1QkFBc0IsZUFFdEIsaUNBQUMsaUJBQ0MsR0FBSUQsYUFDSixXQUFXakUsY0FGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXdCLEtBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLEVBRUosR0FBRyxFQUFFO0FBRUwsUUFBTW1FLGtCQUErQztBQUFBLElBQ25EWCxNQUFNO0FBQUEsTUFDSlksVUFBVTFFO0FBQUFBLE1BQ1YyRSxXQUFXdEYsZ0JBQWdCLFlBQVk7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQ0MsS0FBS1UsY0FDTCxPQUFPO0FBQUEsSUFBRTZFLFFBQVE7QUFBQSxFQUFFLEdBRW5CLGlDQUFDLGVBQ0Msc0JBQXNCakYsYUFDdEIsU0FBU1MsZUFDVCxPQUNBLFFBQU8sTUFDUCxRQUNBLFFBQVFxRSxpQkFDUixXQUFXbEUsVUFDWCxlQUFlZixZQUFZcUYsU0FBWXpILGNBQWMwSCxlQUNyRCxZQUFZaEksc0JBQXNCaUksV0FDbEMsZUFBZTlGLGVBQWVqQyxjQUFjc0UsV0FBV3RFLGNBQWNnSSxNQUNyRSxXQUFXbEUsZ0JBQ1gsZ0NBQWdDLE1BQ2hDLHFCQUFxQm1CLG1CQUNyQixvQkFBb0IsQ0FBQ2QsTUFBU2UsR0FBR0MsV0FBV1MsaUJBQWlCakQsV0FBVyxFQUFFd0IsTUFBTWUsR0FBR0MsTUFBTSxHQUN6RixTQUNBLGlCQUNBLFlBQVk7QUFBQSxJQUNWL0M7QUFBQUEsRUFDRixHQUNBLGFBQ0EsdUJBQXVCa0Ysa0JBckJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJ3QyxLQXpCMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVKO0FBQUNoRyxHQW5QUUYsa0JBQWdCO0FBQUEsVUFnQ1VvQyxXQThJbEJ2QyxjQUFjO0FBQUE7QUFBQWdILEtBOUt0QjdHO0FBcVBULFNBQVNxQyxlQUNQbEMsU0FDQTJHLGNBQWMsT0FDZHpGLG9CQUNBWixZQUNXO0FBQ1gsUUFBTXNHLFNBQW9CNUcsUUFBUTZHLE9BQU9qRCxZQUFVLENBQUNBLE9BQU9rRCxZQUFZLEVBQ3BFL0MsSUFBSSxDQUFDSCxRQUFRbUQsT0FBT0MsU0FBUztBQUM1QixVQUFNQyxlQUF3QjtBQUFBLE1BQzVCaEQsS0FBTSxHQUFFOEM7QUFBQUEsTUFDUkcsTUFBTXRELE9BQU91RCxVQUFVO0FBQUEsTUFDdkJyRCxVQUFVLENBQUNGLE9BQU93RCxXQUNkLFFBQ0E5RyxZQUFZNEQsVUFBVU4sT0FBT00sU0FBVTVELGVBQWVnRyxVQUFhUyxVQUFVO0FBQUEsTUFDakZsRCxvQkFBb0J2RCxZQUFZOEQsY0FBYztBQUFBLE1BQzlDaUQsYUFBYTtBQUFBLE1BQ2JDLFVBQVUxRCxPQUFPMEQsWUFBWTtBQUFBLE1BQzdCbkIsVUFBVXZDLE9BQU91QyxZQUFZWSxRQUFRQyxLQUFLL0QsU0FBUyxJQUFLVyxPQUFPMEQsV0FBVzFELE9BQU8wRCxXQUFXLE1BQU9oQjtBQUFBQSxNQUNuR2lCLG1CQUFtQjNELE9BQU93RCxXQUFXLElBQUk7QUFBQSxNQUN6Q0ksaUJBQWlCO0FBQUEsTUFDakJDLFFBQVE7QUFBQSxRQUNObEMsTUFBTTtBQUFBLFVBQ0ptQyxXQUFXO0FBQUEsWUFDVCwrQkFBK0I7QUFBQSxjQUM3QkMsZ0JBQWdCL0QsT0FBT2dFLG1CQUFtQjtBQUFBLFlBQzVDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBWCxpQkFBYTlDLFlBQVlQLE9BQU9NO0FBQ2hDLFFBQUlOLE9BQU9pRSxRQUFRO0FBQ2pCWixtQkFBYWEsV0FBV2xFLE9BQU9pRTtBQUFBQSxJQUNqQyxPQUFPO0FBQ0wsVUFBSSxPQUFPRSxLQUFLbkUsT0FBT00sS0FBZSxHQUFHO0FBQ3ZDK0MscUJBQWFhLFdBQVcsQ0FBQ2xGLFNBQVksdUJBQUMsVUFDcEMsT0FBTztBQUFBLFVBQ0xvRixTQUFTO0FBQUEsVUFDVEMsV0FBV3JFLE9BQU9nRSxtQkFBbUI7QUFBQSxRQUN2QyxHQUNDbkksY0FBSW1ELE1BQU1nQixPQUFPTSxLQUFlLEtBTEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1yQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsV0FBTytDO0FBQUFBLEVBQ1QsQ0FBQztBQUVILE1BQUlOLGFBQWE7QUFDZkMsV0FBT3NCLEtBQUs7QUFBQSxNQUNWakUsS0FBTSxHQUFFMkMsT0FBTzNEO0FBQUFBLE1BQ2ZpRSxNQUFNO0FBQUEsTUFDTi9DLFdBQVdqRDtBQUFBQSxNQUNYb0csVUFBVTtBQUFBLE1BQ1ZuQixVQUFVO0FBQUEsSUFDWixDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQU9TO0FBQ1Q7QUFFQSxNQUFNM0UsWUFBWUEsTUFBTTtBQUFBa0csTUFBQTtBQUN0QixRQUFNOUMsU0FBUzNGLGVBQWU7QUFDOUIsUUFBTTBJLGVBQWVsSixlQUFlO0FBQUEsSUFDbEM2QyxZQUFZO0FBQUEsTUFDVnNHLFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxRQUNQQyxpQkFBaUJqRCxPQUFPUyxLQUFLLEdBQUc7QUFBQSxNQUNsQztBQUFBLElBQ0Y7QUFBQSxJQUNBOUQsVUFBVTtBQUFBLE1BQ1IsdUJBQXVCO0FBQUEsUUFDckJ1RyxZQUFhLEdBQUVsRCxPQUFPbUQsT0FBTyxHQUFHO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBT0o7QUFDVDtBQUFDRCxJQWpCS2xHLFdBQVM7QUFBQSxVQUNFdkMsY0FBYztBQUFBO0FBa0IvQixNQUFNb0YsY0FBc0Q7QUFBQSxFQUMxRDJELFVBQVU7QUFBQSxFQUNWQyxRQUFRO0FBQUEsRUFDUkMsTUFBTTtBQUNSO0FBRUEsZUFBZTlJO0FBQWdCLElBQUE2RztBQUFBa0MsYUFBQWxDLElBQUEiLCJuYW1lcyI6WyJEZXRhaWxzTGlzdCIsIkRldGFpbHNMaXN0TGF5b3V0TW9kZSIsIlNlbGVjdGlvbiIsIlNlbGVjdGlvbk1vZGUiLCJJY29uQnV0dG9uIiwiRGlyZWN0aW9uYWxIaW50IiwiRGV0YWlsc1JvdyIsIkNvbnN0cmFpbk1vZGUiLCJTdGlja3lQb3NpdGlvblR5cGUiLCJTdGlja3kiLCJUb29sdGlwT3ZlcmZsb3dNb2RlIiwiRGV0YWlsc0hlYWRlciIsIm1lcmdlU3R5bGVTZXRzIiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VMYXlvdXRFZmZlY3QiLCJnZXQiLCJ1c2VUaGVtZUNvbG9ycyIsIlRvb2x0aXBIb3N0IiwiQ29udHJvbHNDb2x1bW5OYW1lRW51bSIsIkRhdGFUYWJsZUNvbnRlbnQiLCJwcm9wcyIsIl9zIiwiY29sdW1ucyIsIml0ZW1zIiwibXVsdGlwbGVTZWxlY3Rpb24iLCJzZWxlY3Rpb24iLCJvblNlbGVjdGlvbiIsIm9uSGVhZGVyQ2xpY2siLCJzb3J0Q29uZmlnIiwiaGFzQ29udHJvbHNDb2x1bW4iLCJtZW51T3B0aW9ucyIsIm9uUmVuZGVyTWVudUl0ZW0iLCJoYXNTZWxlY3Rpb24iLCJncm91cHMiLCJjb21wYWN0Iiwib25SZW5kZXJGb290ZXIiLCJub3RTY3JvbGxhYmxlIiwiaXNIZWFkZXJWaXNpYmxlIiwiZXh0ZXJuYWxSb3dTdHlsZXMiLCJwYWdpbmF0ZWQiLCJjb250cm9sc0NvbHVtbk5hbWUiLCJvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljayIsImRpc2FibGVNZW51IiwiZGlzYWJsZU1lbnVUZXh0Iiwib25NZW51T3BlbmVkIiwib25NZW51RGlzbWlzc2VkIiwidGFibGVTaXplUmVmIiwidGFibGVXaWR0aCIsInNldFRhYmxlV2lkdGgiLCJjdXJyZW50IiwiY2xpZW50V2lkdGgiLCJtYXBwZWRDb2x1bW5zIiwic2V0TWFwcGVkQ29sdW1ucyIsImxpc3RIZWFkZXIiLCJjaGVja0JveCIsInVzZVN0eWxlcyIsImNvbnZlcnRDb2x1bW5zIiwicmVzaXplVGFibGUiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImxvY2FsU2VsZWN0aW9uIiwiY2FuU2VsZWN0SXRlbSIsIm9uU2VsZWN0aW9uQ2hhbmdlZCIsImdldFNlbGVjdGlvbiIsImdldEtleSIsIml0ZW0iLCJpZCIsInNlbGVjdGlvbk1vZGUiLCJtdWx0aXBsZSIsInNpbmdsZSIsImxlbmd0aCIsImdldFNlbGVjdGVkQ291bnQiLCJzb21lIiwiaXNLZXlTZWxlY3RlZCIsInNldENoYW5nZUV2ZW50cyIsImZvckVhY2giLCJzZXRLZXlTZWxlY3RlZCIsInNlbGVjdGVkIiwic2V0QWxsU2VsZWN0ZWQiLCJoYW5kbGVIZWFkZXJDbGljayIsIl8iLCJjb2x1bW4iLCJpc1NvcnRlZERlc2NlbmRpbmciLCJpc1NvcnRlZCIsIm1hcCIsImNvbCIsImtleSIsImZpZWxkIiwiZmllbGROYW1lIiwiZGVzY2VuZGluZyIsInJlbmRlckl0ZW1Db2x1bW4iLCJjaGFuZ2VNZW51T3BlbmVkIiwiY2hhbmdlTWVudURpc21pc3NlZCIsIkNPTlRST0xTIiwibWVudVByb3BzIiwib25SZW5kZXJDb250ZXh0dWFsTWVudUl0ZW0iLCJkaXJlY3Rpb25hbEhpbnQiLCJib3R0b21SaWdodEVkZ2UiLCJpY29uTmFtZSIsImNvbnRyb2xJY29uIiwibWFyZ2luVG9wIiwibWFyZ2luQm90dG9tIiwiT2JqZWN0IiwidmFsdWVzIiwiaW5jbHVkZXMiLCJQYXJlbnQiLCJjb2xvcnMiLCJvblJlbmRlclJvdyIsInJvb3QiLCJjb2xvciIsImJsYWNrIiwidXNlclNlbGVjdCIsImJvcmRlckJvdHRvbVdpZHRoIiwiYm9yZGVyQm90dG9tU3R5bGUiLCJib3JkZXJCb3R0b21Db2xvciIsImdyYXkiLCJvblJlbmRlckhlYWRlciIsImhlYWRlclByb3BzIiwiSGVhZGVyIiwidGV4dEZpZWxkU3R5bGVzIiwibWF4V2lkdGgiLCJvdmVyZmxvd1giLCJ6SW5kZXgiLCJ1bmRlZmluZWQiLCJ1bmNvbnN0cmFpbmVkIiwianVzdGlmaWVkIiwibm9uZSIsIl9jIiwiaGFzQ29udHJvbHMiLCJyZXN1bHQiLCJmaWx0ZXIiLCJibG9ja1Nob3dpbmciLCJpbmRleCIsImxpc3QiLCJyZXN1bHRDb2x1bW4iLCJuYW1lIiwiaGVhZGVyIiwic29ydGFibGUiLCJpc1Jlc2l6YWJsZSIsIm1pbldpZHRoIiwiY29sdW1uQWN0aW9uc01vZGUiLCJoZWFkZXJDbGFzc05hbWUiLCJzdHlsZXMiLCJzZWxlY3RvcnMiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduVGFibGVJdGVtcyIsImZvcm1hdCIsIm9uUmVuZGVyIiwidGVzdCIsImRpc3BsYXkiLCJ0ZXh0QWxpZ24iLCJwdXNoIiwiX3MyIiwiYWN0aW9uU3R5bGVzIiwicGFkZGluZyIsImJhY2tncm91bmRDb2xvciIsImJhY2tncm91bmQiLCJwdXJwbGUiLCJjb250cm9scyIsImRlbGV0ZSIsImVkaXQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGVDb250ZW50LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2RhdGF0YWJsZS9EYXRhVGFibGVDb250ZW50LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgRGV0YWlsc0xpc3QsXHJcbiAgSUNvbHVtbixcclxuICBEZXRhaWxzTGlzdExheW91dE1vZGUsXHJcbiAgU2VsZWN0aW9uLFxyXG4gIFNlbGVjdGlvbk1vZGUsXHJcbiAgSWNvbkJ1dHRvbixcclxuICBJQ29udGV4dHVhbE1lbnVQcm9wcyxcclxuICBJQ29udGV4dHVhbE1lbnVJdGVtLFxyXG4gIERpcmVjdGlvbmFsSGludCxcclxuICBJR3JvdXAsXHJcbiAgRGV0YWlsc1JvdyxcclxuICBJRGV0YWlsc1Jvd1Byb3BzLFxyXG4gIElEZXRhaWxzR3JvdXBEaXZpZGVyUHJvcHMsXHJcbiAgSVN0eWxlRnVuY3Rpb25Pck9iamVjdCxcclxuICBJRGV0YWlsc1Jvd1N0eWxlUHJvcHMsXHJcbiAgSURldGFpbHNSb3dTdHlsZXMsXHJcbiAgQ29uc3RyYWluTW9kZSxcclxuICBTdGlja3lQb3NpdGlvblR5cGUsXHJcbiAgU3RpY2t5LFxyXG4gIFRvb2x0aXBPdmVyZmxvd01vZGUsXHJcbiAgSURldGFpbHNMaXN0U3R5bGVzLFxyXG4gIERldGFpbHNIZWFkZXIsXHJcbiAgbWVyZ2VTdHlsZVNldHMsXHJcbiAgSVJlbmRlckZ1bmN0aW9uLFxyXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHtcclxuICBSZWFjdEVsZW1lbnQsXHJcbiAgdXNlTWVtbyxcclxuICB1c2VDYWxsYmFjayxcclxuICB1c2VTdGF0ZSxcclxuICBNb3VzZUV2ZW50LFxyXG4gIHVzZUVmZmVjdCxcclxuICB1c2VSZWYsXHJcbiAgdXNlTGF5b3V0RWZmZWN0LFxyXG59IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBnZXQgfSBmcm9tICdsb2Rhc2gtZXMnXHJcbmltcG9ydCB7IERhdGFUYWJsZUNvbHVtbiwgRGF0YVRhYmxlU29ydENvbmZpZyB9IGZyb20gJy4nXHJcbmltcG9ydCBFbnRpdHkgZnJvbSAnLi4vLi4vLi4vZG9tYWluL0VudGl0eSdcclxuaW1wb3J0IHsgdXNlVGhlbWVDb2xvcnMgfSBmcm9tICcuLi8uLi9ob29rcydcclxuaW1wb3J0IHsgVG9vbHRpcEhvc3QgfSBmcm9tICcuLidcclxuaW1wb3J0IHsgQ29udHJvbHNDb2x1bW5OYW1lRW51bSB9IGZyb20gJy4uLy4uL2VudW1zL0NvbnRyb2xzQ29sdW1uTmFtZUVudW0nXHJcbmludGVyZmFjZSBEYXRhVGFibGVDb250ZW50UHJvcHM8VCBleHRlbmRzIEVudGl0eT4ge1xyXG4gIGNvbHVtbnM6IERhdGFUYWJsZUNvbHVtbjxUPltdXHJcbiAgaXRlbXM6IFRbXVxyXG4gIG11bHRpcGxlU2VsZWN0aW9uPzogYm9vbGVhblxyXG4gIHNlbGVjdGlvbj86IFRbXVxyXG4gIG9uU2VsZWN0aW9uPzogKGl0ZW1zOiBUW10pID0+IHZvaWRcclxuICBvbkhlYWRlckNsaWNrPzogKGNvbHVtbjogRGF0YVRhYmxlU29ydENvbmZpZykgPT4gdm9pZFxyXG4gIHNvcnRDb25maWc/OiBEYXRhVGFibGVTb3J0Q29uZmlnXHJcbiAgaGFzQ29udHJvbHNDb2x1bW4/OiBib29sZWFuXHJcbiAgbWVudU9wdGlvbnM/OiAoaXRlbTogVCkgPT4gSUNvbnRleHR1YWxNZW51SXRlbVtdXHJcbiAgb25SZW5kZXJNZW51SXRlbT86IElSZW5kZXJGdW5jdGlvbjxJQ29udGV4dHVhbE1lbnVJdGVtPlxyXG4gIGhhc1NlbGVjdGlvbj86IGJvb2xlYW5cclxuICBncm91cHM/OiBJR3JvdXBbXVxyXG4gIGNvbXBhY3Q/OiBib29sZWFuXHJcbiAgb25SZW5kZXJGb290ZXI/OiAocHJvcHM6IElEZXRhaWxzR3JvdXBEaXZpZGVyUHJvcHMgfCB1bmRlZmluZWQpID0+IFJlYWN0RWxlbWVudCB8IHVuZGVmaW5lZFxyXG4gIG5vdFNjcm9sbGFibGU/OiBib29sZWFuXHJcbiAgaXNIZWFkZXJWaXNpYmxlPzogYm9vbGVhblxyXG4gIHBhZ2luYXRlZD86IGJvb2xlYW5cclxuICBleHRlcm5hbFJvd1N0eWxlcz86IElTdHlsZUZ1bmN0aW9uT3JPYmplY3Q8SURldGFpbHNSb3dTdHlsZVByb3BzLCBJRGV0YWlsc1Jvd1N0eWxlcz5cclxuICBjb250cm9sc0NvbHVtbk5hbWU6IENvbnRyb2xzQ29sdW1uTmFtZUVudW1cclxuICBvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljaz86IChpdGVtOiBUKSA9PiB2b2lkXHJcbiAgZGlzYWJsZU1lbnU/OiBib29sZWFuXHJcbiAgZGlzYWJsZU1lbnVUZXh0Pzogc3RyaW5nXHJcbiAgb25NZW51T3BlbmVkPzogKGl0ZW0/OiBUKSA9PiB2b2lkXHJcbiAgb25NZW51RGlzbWlzc2VkPzogKGl0ZW0/OiBUKSA9PiB2b2lkXHJcbn1cclxuXHJcbmZ1bmN0aW9uIERhdGFUYWJsZUNvbnRlbnQ8VCBleHRlbmRzIEVudGl0eT4gKHByb3BzOiBEYXRhVGFibGVDb250ZW50UHJvcHM8VD4pOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHtcclxuICAgIGNvbHVtbnMsXHJcbiAgICBpdGVtcyxcclxuICAgIG11bHRpcGxlU2VsZWN0aW9uID0gdHJ1ZSxcclxuICAgIHNlbGVjdGlvbixcclxuICAgIG9uU2VsZWN0aW9uLFxyXG4gICAgb25IZWFkZXJDbGljayxcclxuICAgIHNvcnRDb25maWcsXHJcbiAgICBoYXNDb250cm9sc0NvbHVtbiA9IGZhbHNlLFxyXG4gICAgbWVudU9wdGlvbnMsXHJcbiAgICBvblJlbmRlck1lbnVJdGVtLFxyXG4gICAgaGFzU2VsZWN0aW9uID0gdHJ1ZSxcclxuICAgIGdyb3VwcyxcclxuICAgIGNvbXBhY3QsXHJcbiAgICBvblJlbmRlckZvb3RlcixcclxuICAgIG5vdFNjcm9sbGFibGUsXHJcbiAgICBpc0hlYWRlclZpc2libGUsXHJcbiAgICBleHRlcm5hbFJvd1N0eWxlcyxcclxuICAgIHBhZ2luYXRlZCxcclxuICAgIGNvbnRyb2xzQ29sdW1uTmFtZSxcclxuICAgIG9uU2luZ2xlQWN0aW9uQ29udHJvbENsaWNrLFxyXG4gICAgZGlzYWJsZU1lbnUsXHJcbiAgICBkaXNhYmxlTWVudVRleHQsXHJcbiAgICBvbk1lbnVPcGVuZWQsXHJcbiAgICBvbk1lbnVEaXNtaXNzZWQsXHJcbiAgfSA9IHByb3BzXHJcblxyXG4gIGNvbnN0IHRhYmxlU2l6ZVJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbClcclxuICBjb25zdCBbdGFibGVXaWR0aCwgc2V0VGFibGVXaWR0aF0gPSB1c2VTdGF0ZSh0YWJsZVNpemVSZWYuY3VycmVudD8uY2xpZW50V2lkdGgpXHJcbiAgY29uc3QgW21hcHBlZENvbHVtbnMsIHNldE1hcHBlZENvbHVtbnNdID0gdXNlU3RhdGU8SUNvbHVtbltdPihbXSlcclxuXHJcbiAgY29uc3QgeyBsaXN0SGVhZGVyLCBjaGVja0JveCB9ID0gdXNlU3R5bGVzKClcclxuXHJcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcclxuICAgIHNldE1hcHBlZENvbHVtbnMoY29udmVydENvbHVtbnMoXHJcbiAgICAgIGNvbHVtbnMsXHJcbiAgICAgIGhhc0NvbnRyb2xzQ29sdW1uLFxyXG4gICAgICBjb250cm9sc0NvbHVtbk5hbWUsXHJcbiAgICAgIHNvcnRDb25maWcsXHJcbiAgICApKVxyXG4gIH0sIFtjb2x1bW5zLCBjb250cm9sc0NvbHVtbk5hbWUsIGhhc0NvbnRyb2xzQ29sdW1uXSlcclxuXHJcbiAgY29uc3QgcmVzaXplVGFibGUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzZXRUYWJsZVdpZHRoKHRhYmxlU2l6ZVJlZi5jdXJyZW50Py5jbGllbnRXaWR0aClcclxuICB9LCBbdGFibGVTaXplUmVmXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCByZXNpemVUYWJsZSlcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVzaXplVGFibGUpXHJcbiAgfSwgW3Jlc2l6ZVRhYmxlXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlc2l6ZVRhYmxlKClcclxuICB9LCBbcmVzaXplVGFibGVdKVxyXG5cclxuICBjb25zdCBsb2NhbFNlbGVjdGlvbjogU2VsZWN0aW9uID0gdXNlTWVtbygoKSA9PiBuZXcgU2VsZWN0aW9uKHtcclxuICAgIGNhblNlbGVjdEl0ZW06ICgpID0+IHRydWUsXHJcbiAgICBvblNlbGVjdGlvbkNoYW5nZWQ6ICgpID0+IHtcclxuICAgICAgb25TZWxlY3Rpb24/Lihsb2NhbFNlbGVjdGlvbi5nZXRTZWxlY3Rpb24oKSBhcyBUW10pXHJcbiAgICB9LFxyXG4gICAgZ2V0S2V5OiAoaXRlbSkgPT4gKGl0ZW0gYXMgVCkuaWQgPz8gJycsXHJcbiAgICBzZWxlY3Rpb25Nb2RlOiBtdWx0aXBsZVNlbGVjdGlvblxyXG4gICAgICA/IFNlbGVjdGlvbk1vZGUubXVsdGlwbGVcclxuICAgICAgOiBTZWxlY3Rpb25Nb2RlLnNpbmdsZSxcclxuICB9KSwgW211bHRpcGxlU2VsZWN0aW9uXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3Rpb24gJiYgKFxyXG4gICAgICBzZWxlY3Rpb24ubGVuZ3RoICE9PSBsb2NhbFNlbGVjdGlvbi5nZXRTZWxlY3RlZENvdW50KCkgfHxcclxuICAgICAgc2VsZWN0aW9uLnNvbWUoXHJcbiAgICAgICAgKHsgaWQgfSkgPT4gaWQgJiYgIWxvY2FsU2VsZWN0aW9uLmlzS2V5U2VsZWN0ZWQoaWQpLFxyXG4gICAgICApXHJcbiAgICApKSB7XHJcbiAgICAgIGxvY2FsU2VsZWN0aW9uLnNldENoYW5nZUV2ZW50cyhmYWxzZSlcclxuICAgICAgLy8gbG9jYWxTZWxlY3Rpb24uc2V0QWxsU2VsZWN0ZWQoZmFsc2UpIEZJWE1FIHZlcmZpY2FyIHBvcnF1ZSBuw6MgZnVuY2lvbmEgbmEgdGFiZWxhIGRlIG5vdGFzIGZpc2NhaXNcclxuICAgICAgc2VsZWN0aW9uLmZvckVhY2goXHJcbiAgICAgICAgKHsgaWQgfSkgPT4gaWQgJiYgbG9jYWxTZWxlY3Rpb24uc2V0S2V5U2VsZWN0ZWQoaWQsIHRydWUsIHRydWUpLFxyXG4gICAgICApXHJcbiAgICAgIGxvY2FsU2VsZWN0aW9uLnNldENoYW5nZUV2ZW50cyh0cnVlKVxyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3Rpb25dKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBzZWxlY3Rpb24/LnNvbWUoXHJcbiAgICAgICAgKHNlbGVjdGVkKSA9PiBpdGVtcy5zb21lKGl0ZW0gPT4gaXRlbS5pZCAhPT0gc2VsZWN0ZWQuaWQpLFxyXG4gICAgICApXHJcbiAgICApIHtcclxuICAgICAgbG9jYWxTZWxlY3Rpb24uc2V0QWxsU2VsZWN0ZWQoZmFsc2UpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIG9uU2VsZWN0aW9uPy4obG9jYWxTZWxlY3Rpb24uZ2V0U2VsZWN0aW9uKCkgYXMgVFtdKVxyXG4gIH0sIFtpdGVtc10pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUhlYWRlckNsaWNrID0gdXNlQ2FsbGJhY2soKF8/OiBNb3VzZUV2ZW50PEhUTUxFbGVtZW50PiwgY29sdW1uPzogSUNvbHVtbikgPT4ge1xyXG4gICAgY29uc3QgaXNTb3J0ZWREZXNjZW5kaW5nID0gIWNvbHVtbj8uaXNTb3J0ZWQgfHwgIWNvbHVtbj8uaXNTb3J0ZWREZXNjZW5kaW5nXHJcbiAgICBzZXRNYXBwZWRDb2x1bW5zKG1hcHBlZENvbHVtbnMgPT4gbWFwcGVkQ29sdW1ucy5tYXAoY29sID0+IHtcclxuICAgICAgY29uc3QgaXNTb3J0ZWQgPSBjb2wua2V5ID09PSBjb2x1bW4/LmtleVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLmNvbCxcclxuICAgICAgICBpc1NvcnRlZCxcclxuICAgICAgICBpc1NvcnRlZERlc2NlbmRpbmc6IGlzU29ydGVkICYmIGlzU29ydGVkRGVzY2VuZGluZyxcclxuICAgICAgfVxyXG4gICAgfSkpXHJcbiAgICBvbkhlYWRlckNsaWNrPy4oe1xyXG4gICAgICBmaWVsZDogY29sdW1uPy5maWVsZE5hbWUgPz8gJycsXHJcbiAgICAgIGRlc2NlbmRpbmc6IGlzU29ydGVkRGVzY2VuZGluZyxcclxuICAgIH0pXHJcbiAgfSwgW29uSGVhZGVyQ2xpY2tdKVxyXG5cclxuICBjb25zdCByZW5kZXJJdGVtQ29sdW1uID0gdXNlQ2FsbGJhY2soKGRpc2FibGVNZW51PzogYm9vbGVhbikgPT5cclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC9kaXNwbGF5LW5hbWVcclxuICAgIChpdGVtOiBULCBfPzogbnVtYmVyLCBjb2x1bW4/OiBJQ29sdW1uKSA9PiB7XHJcbiAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IGNvbHVtbj8uZmllbGROYW1lID8/ICcnXHJcbiAgICAgIGNvbnN0IGNoYW5nZU1lbnVPcGVuZWQgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKG9uTWVudU9wZW5lZCkgb25NZW51T3BlbmVkKGl0ZW0pXHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgY2hhbmdlTWVudURpc21pc3NlZCA9ICgpID0+IHtcclxuICAgICAgICBpZiAob25NZW51RGlzbWlzc2VkKSBvbk1lbnVEaXNtaXNzZWQoaXRlbSlcclxuICAgICAgfVxyXG4gICAgICBpZiAoZmllbGROYW1lID09PSBDb250cm9sc0NvbHVtbk5hbWVFbnVtLkNPTlRST0xTKSB7XHJcbiAgICAgICAgY29uc3QgbWVudVByb3BzID0gKGl0ZW06IFQpOiBJQ29udGV4dHVhbE1lbnVQcm9wcyA9PiAoe1xyXG4gICAgICAgICAgaXRlbXM6IG1lbnVPcHRpb25zPy4oaXRlbSkgPz8gW10sXHJcbiAgICAgICAgICBvblJlbmRlckNvbnRleHR1YWxNZW51SXRlbTogb25SZW5kZXJNZW51SXRlbSxcclxuICAgICAgICAgIGRpcmVjdGlvbmFsSGludDogRGlyZWN0aW9uYWxIaW50LmJvdHRvbVJpZ2h0RWRnZSxcclxuICAgICAgICAgIG9uTWVudU9wZW5lZDogY2hhbmdlTWVudU9wZW5lZCxcclxuICAgICAgICAgIG9uTWVudURpc21pc3NlZDogY2hhbmdlTWVudURpc21pc3NlZCxcclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiA8VG9vbHRpcEhvc3QgY29udGVudD17ZGlzYWJsZU1lbnVUZXh0fT5cclxuICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIG1lbnVQcm9wcz17bWVudVByb3BzKGl0ZW0pfVxyXG4gICAgICAgICAgICBvblJlbmRlck1lbnVJY29uPXsoKSA9PiA8PjwvPn1cclxuICAgICAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiBjb250cm9sSWNvbltmaWVsZE5hbWVdIH19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlTWVudX1cclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICBtYXJnaW5Ub3A6ICctNnB4JyxcclxuICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICctNnB4JyxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9Ub29sdGlwSG9zdD5cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKFxyXG4gICAgICAgIE9iamVjdC52YWx1ZXMoQ29udHJvbHNDb2x1bW5OYW1lRW51bSkuaW5jbHVkZXMoZmllbGROYW1lIGFzIENvbnRyb2xzQ29sdW1uTmFtZUVudW0pICYmXHJcbiAgICAgICAgZmllbGROYW1lICE9PSBDb250cm9sc0NvbHVtbk5hbWVFbnVtLkNPTlRST0xTXHJcbiAgICAgICkge1xyXG4gICAgICAgIHJldHVybiA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiBjb250cm9sSWNvbltmaWVsZE5hbWUgYXMgQ29udHJvbHNDb2x1bW5OYW1lRW51bV0gfX1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2luZ2xlQWN0aW9uQ29udHJvbENsaWNrID8gb25TaW5nbGVBY3Rpb25Db250cm9sQ2xpY2soaXRlbSkgOiB7fX1cclxuICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlTWVudX1cclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIG1hcmdpblRvcDogJy02cHgnLFxyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206ICctNnB4JyxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIDxUb29sdGlwSG9zdFxyXG4gICAgICAgIGNvbnRlbnQ9e2l0ZW1bZmllbGROYW1lXX1cclxuICAgICAgICBvdmVyZmxvd01vZGU9e1Rvb2x0aXBPdmVyZmxvd01vZGUuUGFyZW50fVxyXG4gICAgICA+XHJcbiAgICAgICAge2l0ZW1bZmllbGROYW1lXX1cclxuICAgICAgPC9Ub29sdGlwSG9zdD5cclxuICAgIH0sXHJcbiAgW1xyXG4gICAgbWVudU9wdGlvbnMsXHJcbiAgICBvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljayxcclxuICAgIG9uUmVuZGVyTWVudUl0ZW0sXHJcbiAgICBkaXNhYmxlTWVudVRleHQsXHJcbiAgXSxcclxuICApXHJcblxyXG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcclxuXHJcbiAgY29uc3Qgb25SZW5kZXJSb3cgPSB1c2VDYWxsYmFjaygocHJvcHM6IElEZXRhaWxzUm93UHJvcHMgfCB1bmRlZmluZWQpID0+IHtcclxuICAgIHJldHVybiBwcm9wcyAmJiA8RGV0YWlsc1Jvd1xyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAgIHN0eWxlcz17ZXh0ZXJuYWxSb3dTdHlsZXMgfHwge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgIGNvbG9yOiBjb2xvcnMuYmxhY2ssXHJcbiAgICAgICAgICB1c2VyU2VsZWN0OiAnYXV0bycsXHJcbiAgICAgICAgICBib3JkZXJCb3R0b21XaWR0aDogJzFweCcsXHJcbiAgICAgICAgICBib3JkZXJCb3R0b21TdHlsZTogJ3NvbGlkJyxcclxuICAgICAgICAgIGJvcmRlckJvdHRvbUNvbG9yOiBgJHtjb2xvcnMuZ3JheVszMDBdfWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfX1cclxuICAgIC8+XHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG9uUmVuZGVySGVhZGVyID0gdXNlQ2FsbGJhY2soKGhlYWRlclByb3BzKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8U3RpY2t5XHJcbiAgICAgICAgc3RpY2t5UG9zaXRpb249e1N0aWNreVBvc2l0aW9uVHlwZS5IZWFkZXJ9XHJcbiAgICAgICAgaXNTY3JvbGxTeW5jZWQ9e3RydWV9XHJcbiAgICAgICAgc3RpY2t5QmFja2dyb3VuZENvbG9yPVwidHJhbnNwYXJlbnRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPERldGFpbHNIZWFkZXJcclxuICAgICAgICAgIHsuLi5oZWFkZXJQcm9wc31cclxuICAgICAgICAgIGNsYXNzTmFtZT17bGlzdEhlYWRlcn1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1N0aWNreT5cclxuICAgIClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgdGV4dEZpZWxkU3R5bGVzOiBQYXJ0aWFsPElEZXRhaWxzTGlzdFN0eWxlcz4gPSB7XHJcbiAgICByb290OiB7XHJcbiAgICAgIG1heFdpZHRoOiB0YWJsZVdpZHRoLFxyXG4gICAgICBvdmVyZmxvd1g6IG5vdFNjcm9sbGFibGUgPyAndmlzaWJsZScgOiAnYXV0bycsXHJcbiAgICB9LFxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgcmVmPXt0YWJsZVNpemVSZWZ9XHJcbiAgICAgIHN0eWxlPXt7IHpJbmRleDogMCB9fVxyXG4gICAgPlxyXG4gICAgICA8RGV0YWlsc0xpc3RcclxuICAgICAgICBkaXNhYmxlU2VsZWN0aW9uWm9uZT17ZGlzYWJsZU1lbnV9XHJcbiAgICAgICAgY29sdW1ucz17bWFwcGVkQ29sdW1uc31cclxuICAgICAgICBpdGVtcz17aXRlbXN9XHJcbiAgICAgICAgc2V0S2V5PVwiaWRcIlxyXG4gICAgICAgIGdyb3Vwcz17Z3JvdXBzfVxyXG4gICAgICAgIHN0eWxlcz17dGV4dEZpZWxkU3R5bGVzfVxyXG4gICAgICAgIGNsYXNzTmFtZT17Y2hlY2tCb3h9XHJcbiAgICAgICAgY29uc3RyYWluTW9kZT17cGFnaW5hdGVkID8gdW5kZWZpbmVkIDogQ29uc3RyYWluTW9kZS51bmNvbnN0cmFpbmVkIH1cclxuICAgICAgICBsYXlvdXRNb2RlPXtEZXRhaWxzTGlzdExheW91dE1vZGUuanVzdGlmaWVkfVxyXG4gICAgICAgIHNlbGVjdGlvbk1vZGU9e2hhc1NlbGVjdGlvbiA/IFNlbGVjdGlvbk1vZGUubXVsdGlwbGUgOiBTZWxlY3Rpb25Nb2RlLm5vbmV9XHJcbiAgICAgICAgc2VsZWN0aW9uPXtsb2NhbFNlbGVjdGlvbn1cclxuICAgICAgICBzZWxlY3Rpb25QcmVzZXJ2ZWRPbkVtcHR5Q2xpY2s9e3RydWV9XHJcbiAgICAgICAgb25Db2x1bW5IZWFkZXJDbGljaz17aGFuZGxlSGVhZGVyQ2xpY2t9XHJcbiAgICAgICAgb25SZW5kZXJJdGVtQ29sdW1uPXsoaXRlbTogVCwgXywgY29sdW1uKSA9PiByZW5kZXJJdGVtQ29sdW1uKGRpc2FibGVNZW51KShpdGVtLCBfLCBjb2x1bW4pfVxyXG4gICAgICAgIGNvbXBhY3Q9e2NvbXBhY3R9XHJcbiAgICAgICAgaXNIZWFkZXJWaXNpYmxlPXtpc0hlYWRlclZpc2libGV9XHJcbiAgICAgICAgZ3JvdXBQcm9wcz17e1xyXG4gICAgICAgICAgb25SZW5kZXJGb290ZXI6IG9uUmVuZGVyRm9vdGVyIGFzIHVua25vd24gYXMgSVJlbmRlckZ1bmN0aW9uPElEZXRhaWxzR3JvdXBEaXZpZGVyUHJvcHM+LFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgb25SZW5kZXJSb3c9e29uUmVuZGVyUm93IGFzIHVua25vd24gYXMgSVJlbmRlckZ1bmN0aW9uPElEZXRhaWxzUm93UHJvcHM+fVxyXG4gICAgICAgIG9uUmVuZGVyRGV0YWlsc0hlYWRlcj17b25SZW5kZXJIZWFkZXJ9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNvbnZlcnRDb2x1bW5zPFQ+IChcclxuICBjb2x1bW5zOiBEYXRhVGFibGVDb2x1bW48VD5bXSxcclxuICBoYXNDb250cm9scyA9IGZhbHNlLFxyXG4gIGNvbnRyb2xzQ29sdW1uTmFtZTogQ29udHJvbHNDb2x1bW5OYW1lRW51bSxcclxuICBzb3J0Q29uZmlnPzogRGF0YVRhYmxlU29ydENvbmZpZyxcclxuKTogSUNvbHVtbltdIHtcclxuICBjb25zdCByZXN1bHQ6IElDb2x1bW5bXSA9IGNvbHVtbnMuZmlsdGVyKGNvbHVtbiA9PiAhY29sdW1uLmJsb2NrU2hvd2luZylcclxuICAgIC5tYXAoKGNvbHVtbiwgaW5kZXgsIGxpc3QpID0+IHtcclxuICAgICAgY29uc3QgcmVzdWx0Q29sdW1uOiBJQ29sdW1uID0ge1xyXG4gICAgICAgIGtleTogYCR7aW5kZXh9YCxcclxuICAgICAgICBuYW1lOiBjb2x1bW4uaGVhZGVyIHx8ICcnLFxyXG4gICAgICAgIGlzU29ydGVkOiAhY29sdW1uLnNvcnRhYmxlXHJcbiAgICAgICAgICA/IGZhbHNlXHJcbiAgICAgICAgICA6IHNvcnRDb25maWc/LmZpZWxkID09PSBjb2x1bW4uZmllbGQgfHwgKHNvcnRDb25maWcgPT09IHVuZGVmaW5lZCAmJiBpbmRleCA9PT0gMCksXHJcbiAgICAgICAgaXNTb3J0ZWREZXNjZW5kaW5nOiBzb3J0Q29uZmlnPy5kZXNjZW5kaW5nID8/IGZhbHNlLFxyXG4gICAgICAgIGlzUmVzaXphYmxlOiB0cnVlLFxyXG4gICAgICAgIG1pbldpZHRoOiBjb2x1bW4ubWluV2lkdGggfHwgMTUwLFxyXG4gICAgICAgIG1heFdpZHRoOiBjb2x1bW4ubWF4V2lkdGggPz8gaW5kZXggPCBsaXN0Lmxlbmd0aCAtIDEgPyAoY29sdW1uLm1pbldpZHRoID8gY29sdW1uLm1pbldpZHRoIDogMzAwKSA6IHVuZGVmaW5lZCxcclxuICAgICAgICBjb2x1bW5BY3Rpb25zTW9kZTogY29sdW1uLnNvcnRhYmxlID8gMSA6IDAsXHJcbiAgICAgICAgaGVhZGVyQ2xhc3NOYW1lOiAnaGVhZGVyU3R5bGUnLFxyXG4gICAgICAgIHN0eWxlczoge1xyXG4gICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBzZWxlY3RvcnM6IHtcclxuICAgICAgICAgICAgICAnLm1zLURldGFpbHNIZWFkZXItY2VsbFRpdGxlJzoge1xyXG4gICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IGNvbHVtbi5hbGlnblRhYmxlSXRlbXMgPz8gJ3N0YXJ0JyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXN1bHRDb2x1bW4uZmllbGROYW1lID0gY29sdW1uLmZpZWxkIGFzIHN0cmluZ1xyXG4gICAgICBpZiAoY29sdW1uLmZvcm1hdCkge1xyXG4gICAgICAgIHJlc3VsdENvbHVtbi5vblJlbmRlciA9IGNvbHVtbi5mb3JtYXRcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoL1suW10vLnRlc3QoY29sdW1uLmZpZWxkIGFzIHN0cmluZykpIHtcclxuICAgICAgICAgIHJlc3VsdENvbHVtbi5vblJlbmRlciA9IChpdGVtOiBUKSA9PiA8c3BhblxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXHJcbiAgICAgICAgICAgICAgdGV4dEFsaWduOiBjb2x1bW4uYWxpZ25UYWJsZUl0ZW1zID8/ICdzdGFydCcsXHJcbiAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICB7Z2V0KGl0ZW0sIGNvbHVtbi5maWVsZCBhcyBzdHJpbmcpfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHJlc3VsdENvbHVtblxyXG4gICAgfSlcclxuXHJcbiAgaWYgKGhhc0NvbnRyb2xzKSB7XHJcbiAgICByZXN1bHQucHVzaCh7XHJcbiAgICAgIGtleTogYCR7cmVzdWx0Lmxlbmd0aH1gLFxyXG4gICAgICBuYW1lOiAnJyxcclxuICAgICAgZmllbGROYW1lOiBjb250cm9sc0NvbHVtbk5hbWUsXHJcbiAgICAgIG1pbldpZHRoOiAzMixcclxuICAgICAgbWF4V2lkdGg6IDMyLFxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIHJldHVybiByZXN1bHRcclxufVxyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IGNvbG9ycyA9IHVzZVRoZW1lQ29sb3JzKClcclxuICBjb25zdCBhY3Rpb25TdHlsZXMgPSBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBsaXN0SGVhZGVyOiB7XHJcbiAgICAgIHBhZGRpbmc6IDAsXHJcbiAgICAgICcmPmRpdic6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgY2hlY2tCb3g6IHtcclxuICAgICAgJy5pcy1jaGVja2VkOjpiZWZvcmUnOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogYCR7Y29sb3JzLnB1cnBsZVs4MDBdfSBub25lIHJlcGVhdCBzY3JvbGwgMCUgMCVgLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICByZXR1cm4gYWN0aW9uU3R5bGVzXHJcbn1cclxuXHJcbmNvbnN0IGNvbnRyb2xJY29uOiBSZWNvcmQ8Q29udHJvbHNDb2x1bW5OYW1lRW51bSwgc3RyaW5nPiA9IHtcclxuICBjb250cm9sczogJ01vcmUnLFxyXG4gIGRlbGV0ZTogJ0RlbGV0ZScsXHJcbiAgZWRpdDogJ0VkaXQnLFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXRhVGFibGVDb250ZW50XHJcbiJdfQ==