import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/components/AdminSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/components/AdminSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { navLinkGroups } from "/src/modules/admin/components/index.ts?t=1701096626433";
import { SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
const AdminSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    hasPermission
  } = usePermissions();
  const {
    pathname
  } = useLocation();
  const permissionNav = useMemo(() => {
    const filteredGroup = navLinkGroups;
    navLinkGroups.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar", navLink?.onlyAdmin));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(item.url);
    }
  };
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Administrativo", groups: permissionNav, onLinkClick: handleClick, selectedKey }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/components/AdminSideMenu.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
};
_s(AdminSideMenu, "Bsj2PyJibQU3XCVSl+hs6RaMJ3o=", false, function() {
  return [useNavigate, usePermissions, useLocation];
});
_c = AdminSideMenu;
export default AdminSideMenu;
var _c;
$RefreshReg$(_c, "AdminSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/components/AdminSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNJOzs7Ozs7Ozs7Ozs7Ozs7O0FBakNKLFNBQXlCQSxlQUFlO0FBRXhDLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxTQUF1QkMsc0JBQXNCO0FBQzdDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsZ0NBQWdDO0FBRXZDLE1BQU1DLGdCQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU1DLFdBQVdQLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVRO0FBQUFBLEVBQWMsSUFBSVAsZUFBZTtBQUN6QyxRQUFNO0FBQUEsSUFBRVE7QUFBQUEsRUFBUyxJQUFJVixZQUFZO0FBRWpDLFFBQU1XLGdCQUFnQlosUUFBUSxNQUFNO0FBQ2xDLFVBQU1hLGdCQUFpQ1Q7QUFDdkNBLGtCQUFjVSxRQUFRLENBQUNDLE9BQU9DLFVBQVU7QUFDdENILG9CQUFjRyxLQUFLLEVBQUVDLFFBQVFGLE1BQU1FLE1BQU1DLE9BQU9DLGFBQVdULGNBQWNTLFFBQVFDLFlBQTRCLGNBQWNELFNBQVNFLFNBQVMsQ0FBQztBQUFBLElBQ2hKLENBQUM7QUFDRCxXQUFPUjtBQUFBQSxFQUNULEdBQUcsQ0FBQ1QsYUFBYSxDQUFDO0FBRWxCLFFBQU1rQixjQUFjdEIsUUFBUSxNQUMxQk0sMkJBQTJCSyxVQUFVQyxhQUFhLEdBQ3BELENBQUNELFVBQVVDLGFBQWEsQ0FBQztBQUV6QixRQUFNVyxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQmxCLGVBQVNnQixLQUFLRyxHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxZQUNDLE9BQU0sa0JBQ04sUUFBUWhCLGVBQ1IsYUFBYVcsYUFDYixlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJMkI7QUFHL0I7QUFBQ2YsR0FoQ0tELGVBQWlCO0FBQUEsVUFDSkwsYUFDU0MsZ0JBQ0xGLFdBQVc7QUFBQTtBQUFBNEIsS0FINUJ0QjtBQWtDTixlQUFlQTtBQUFhLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQZXJtaXNzaW9ucyIsIm5hdkxpbmtHcm91cHMiLCJTaWRlTWVudSIsImdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzIiwiQWRtaW5TaWRlTWVudSIsIl9zIiwibmF2aWdhdGUiLCJoYXNQZXJtaXNzaW9uIiwicGF0aG5hbWUiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwibGlua3MiLCJmaWx0ZXIiLCJuYXZMaW5rIiwicGVybWlzc2lvbiIsIm9ubHlBZG1pbiIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsInVybCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWRtaW5TaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbXBvbmVudHMvQWRtaW5TaWRlTWVudS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgTW91c2VFdmVudCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSU5hdkxpbmssIElOYXZMaW5rR3JvdXAgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QvbGliL05hdidcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBzZXJ2aWNlQ29kZXMsIHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vYXV0aC9ob29rcy9wZXJtaXNzaW9ucydcbmltcG9ydCB7IG5hdkxpbmtHcm91cHMgfSBmcm9tICcuJ1xuaW1wb3J0IHsgU2lkZU1lbnUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCBnZXRTZWxlY3RlZEtleUZyb21OYXZMaW5rcyBmcm9tICcuLi8uLi8uLi9zaGFyZWQvdXRpbHMvZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MnXG5cbmNvbnN0IEFkbWluU2lkZU1lbnU6IEZDID0gKCkgPT4ge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcblxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gbmF2TGlua0dyb3Vwc1xuICAgIG5hdkxpbmtHcm91cHMuZm9yRWFjaCgoZ3JvdXAsIGluZGV4KSA9PiB7XG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyb3VwLmxpbmtzLmZpbHRlcihuYXZMaW5rID0+IGhhc1Blcm1pc3Npb24obmF2TGluay5wZXJtaXNzaW9uIGFzIHNlcnZpY2VDb2RlcywgJ1Zpc3VhbGl6YXInLCBuYXZMaW5rPy5vbmx5QWRtaW4pKVxuICAgIH0pXG4gICAgcmV0dXJuIGZpbHRlcmVkR3JvdXBcbiAgfSwgW25hdkxpbmtHcm91cHNdKVxuXG4gIGNvbnN0IHNlbGVjdGVkS2V5ID0gdXNlTWVtbygoKSA9PlxuICAgIGdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzKHBhdGhuYW1lLCBwZXJtaXNzaW9uTmF2KSxcbiAgW3BhdGhuYW1lLCBwZXJtaXNzaW9uTmF2XSlcblxuICBjb25zdCBoYW5kbGVDbGljayA9IChldj86IE1vdXNlRXZlbnQsIGl0ZW0/OiBJTmF2TGluaykgPT4ge1xuICAgIGlmIChldiAhPT0gdW5kZWZpbmVkICYmIGl0ZW0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxuICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8U2lkZU1lbnVcbiAgICAgIHRpdGxlPSdBZG1pbmlzdHJhdGl2bydcbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgIHNlbGVjdGVkS2V5PXtzZWxlY3RlZEtleX1cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFkbWluU2lkZU1lbnVcbiJdfQ==