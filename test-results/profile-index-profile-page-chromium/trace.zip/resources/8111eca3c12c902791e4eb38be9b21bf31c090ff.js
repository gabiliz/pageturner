import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/resource/ResourceDetailsDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceDetailsDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { AppDrawer, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
function ResourceDetails(props) {
  _s();
  const {
    title,
    isOpen,
    onDismiss,
    service: service2,
    id
  } = props;
  const {
    isLoading,
    data
  } = service2.useFindOne(id);
  return /* @__PURE__ */ jsxDEV(AppDrawer, { title, isOpen, onDismiss, children: [
    isLoading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceDetailsDrawer.tsx",
      lineNumber: 30,
      columnNumber: 21
    }, this),
    data && /* @__PURE__ */ jsxDEV(props.detailsView, { data }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceDetailsDrawer.tsx",
      lineNumber: 31,
      columnNumber: 16
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceDetailsDrawer.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
}
_s(ResourceDetails, "oytrynSpK8RNi4uLZARsbUFR+Ks=", false, function() {
  return [service.useFindOne];
});
_c = ResourceDetails;
export default ResourceDetails;
var _c;
$RefreshReg$(_c, "ResourceDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceDetailsDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJvQjs7Ozs7Ozs7Ozs7Ozs7OztBQXpCcEIsU0FBU0EsV0FBV0MscUJBQXFCO0FBWXpDLFNBQVNDLGdCQUNQQyxPQUNjO0FBQUFDLEtBQUE7QUFDZCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsSUFBUUM7QUFBQUEsSUFBV0M7QUFBQUEsSUFBU0M7QUFBQUEsRUFBRyxJQUFJTjtBQUVsRCxRQUFNO0FBQUEsSUFBRU87QUFBQUEsSUFBV0M7QUFBQUEsRUFBSyxJQUFJSCxTQUFRSSxXQUFXSCxFQUFFO0FBRWpELFNBQ0UsdUJBQUMsYUFDQyxPQUNBLFFBQ0EsV0FFQ0M7QUFBQUEsaUJBQWEsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFDM0JDLFFBQVEsdUJBQUMsTUFBTSxhQUFOLEVBQ1IsUUFETztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQ0k7QUFBQSxPQVBmO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNQLEdBbkJRRixpQkFBZTtBQUFBLFVBS01NLFFBQVFJLFVBQVU7QUFBQTtBQUFBQyxLQUx2Q1g7QUFxQlQsZUFBZUE7QUFBZSxJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQXBwRHJhd2VyIiwiTG9hZGluZ1NjcmVlbiIsIlJlc291cmNlRGV0YWlscyIsInByb3BzIiwiX3MiLCJ0aXRsZSIsImlzT3BlbiIsIm9uRGlzbWlzcyIsInNlcnZpY2UiLCJpZCIsImlzTG9hZGluZyIsImRhdGEiLCJ1c2VGaW5kT25lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZXNvdXJjZURldGFpbHNEcmF3ZXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvcmVzb3VyY2UvUmVzb3VyY2VEZXRhaWxzRHJhd2VyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJlYWN0RWxlbWVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEVudGl0eSBmcm9tICcuLi8uLi8uLi9kb21haW4vRW50aXR5J1xuaW1wb3J0IHsgRGV0YWlsc1ZpZXcgfSBmcm9tICcuLi8uLi90eXBlcy9EZXRhaWxzVmlldydcbmltcG9ydCB7IFJlc291cmNlUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vYXBpL1Jlc291cmNlUXVlcnlTZXJ2aWNlJ1xuaW1wb3J0IHsgQXBwRHJhd2VyLCBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnLi4nXG5cbmludGVyZmFjZSBSZXNvdXJjZURldGFpbHNQcm9wczxRIGV4dGVuZHMgRW50aXR5PiB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgc2VydmljZTogUmVzb3VyY2VRdWVyeVNlcnZpY2U8USwgYW55PlxuICBpZDogc3RyaW5nXG4gIGRldGFpbHNWaWV3OiBEZXRhaWxzVmlldzxRPlxuICBpc09wZW46IGJvb2xlYW5cbiAgb25EaXNtaXNzOiAoKSA9PiB2b2lkXG59XG5cbmZ1bmN0aW9uIFJlc291cmNlRGV0YWlsczxRIGV4dGVuZHMgRW50aXR5PiAoXG4gIHByb3BzOiBSZXNvdXJjZURldGFpbHNQcm9wczxRPixcbik6IFJlYWN0RWxlbWVudCB7XG4gIGNvbnN0IHsgdGl0bGUsIGlzT3Blbiwgb25EaXNtaXNzLCBzZXJ2aWNlLCBpZCB9ID0gcHJvcHNcblxuICBjb25zdCB7IGlzTG9hZGluZywgZGF0YSB9ID0gc2VydmljZS51c2VGaW5kT25lKGlkKVxuXG4gIHJldHVybiAoXG4gICAgPEFwcERyYXdlclxuICAgICAgdGl0bGU9e3RpdGxlfVxuICAgICAgaXNPcGVuPXtpc09wZW59XG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cbiAgICA+XG4gICAgICB7aXNMb2FkaW5nICYmIDxMb2FkaW5nU2NyZWVuIC8+fVxuICAgICAge2RhdGEgJiYgPHByb3BzLmRldGFpbHNWaWV3XG4gICAgICAgIGRhdGE9e2RhdGF9XG4gICAgICAvPn1cbiAgICA8L0FwcERyYXdlcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSZXNvdXJjZURldGFpbHNcbiJdfQ==