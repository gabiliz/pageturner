import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/drawer/AppDrawer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"];
import { mergeStyleSets, Panel, PanelType, ScrollablePane } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
const AppDrawer = (props) => {
  _s();
  const {
    title,
    children,
    isOpen,
    onDismiss,
    footer,
    renderTitle,
    large,
    onRenderNavigationContent,
    noPadding
  } = props;
  const drawerStyles = useDrawerStyles(noPadding);
  const scrollBarStyles = useScrollBarStyles();
  const classNames = useClassNames();
  const renderPanelFooter = useCallback(() => {
    if (!footer)
      return null;
    return footer;
  }, [footer]);
  return /* @__PURE__ */ jsxDEV(Panel, { layerProps: {
    styles: {
      root: {
        zIndex: 996
      }
    }
  }, headerText: title, onRenderHeader: renderTitle ? () => /* @__PURE__ */ jsxDEV("header", { className: classNames.header, children: renderTitle() }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx",
    lineNumber: 44,
    columnNumber: 61
  }, this) : void 0, onRenderNavigationContent, isOpen, onDismiss, onOuterClick: () => {
  }, onRenderFooterContent: footer && renderPanelFooter, isFooterAtBottom: true, styles: drawerStyles, type: large ? PanelType.custom : PanelType.medium, customWidth: large ? "1000px" : void 0, children: /* @__PURE__ */ jsxDEV("div", { className: classNames.wrapper, children: /* @__PURE__ */ jsxDEV(ScrollablePane, { styles: scrollBarStyles, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx",
    lineNumber: 48,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx",
    lineNumber: 47,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx",
    lineNumber: 38,
    columnNumber: 10
  }, this);
};
_s(AppDrawer, "+fD/3J10h6aBqjluyceSqh7tinQ=", false, function() {
  return [useDrawerStyles, useScrollBarStyles, useClassNames];
});
_c = AppDrawer;
const useClassNames = () => {
  _s2();
  const {
    spacing
  } = useTheme();
  return mergeStyleSets({
    wrapper: {
      height: "100%",
      position: "relative",
      zIndex: 996
    },
    header: {
      display: "flex",
      alignItems: "center",
      flex: 1,
      paddingRight: spacing.xl,
      paddingLeft: spacing.xl,
      marginBottom: spacing.xs
    },
    footerBox: {
      height: 100
    }
  });
};
_s2(useClassNames, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
const useScrollBarStyles = () => {
  _s3();
  const {
    colors
  } = useTheme();
  return () => ({
    root: {
      selectors: {
        ".ms-ScrollablePane--contentContainer": {
          scrollbarWidth: "5px",
          borderRadius: "4px",
          scrollbarColor: `${colors.gray[300]} ${colors.gray[200]}`
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar": {
          width: "5px"
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar-track": {
          background: colors.gray[200]
        },
        ".ms-ScrollablePane--contentContainer::-webkit-scrollbar-thumb": {
          background: colors.gray[300]
        }
      }
    },
    stickyAbove: void 0,
    stickyBelow: void 0,
    stickyBelowItems: void 0,
    contentContainer: void 0
  });
};
_s3(useScrollBarStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
const useDrawerStyles = (noPadding) => {
  _s4();
  const {
    colors
  } = useTheme();
  return () => ({
    root: {
      overflowWrap: "anywhere",
      height: "auto"
    },
    commands: {
      zIndex: 1
    },
    scrollableContent: {
      overflow: "visible"
    },
    navigation: {
      height: "auto",
      alignItems: "flex-start",
      "> button": {
        height: 40
      }
    },
    content: {
      padding: noPadding ? 0 : void 0,
      paddingTop: 0,
      paddingBottom: 0,
      "@media (min-height: 20px)": {
        flexGrow: 1
      }
    },
    // FIXME - Código abaixo parou de funcionar no servidor (scroll do footer), porém funciona em DEV
    //         É preciso verificar o que houve no servidor e retornar esta versão
    //         Pois o que foi feito aqui é uma solução temporária
    // props.isFooterAtBottom && {
    //   selectors: {
    //     '@media(min-height: 480px)': {
    //       height: 'auto',
    //       minHeight: 'calc(100% - 115px)',
    //       display: 'flex',
    //       flexDirection: 'column',
    //     },
    //   },
    // },,
    footer: {
      background: colors.white,
      borderTopColor: colors.gray[200],
      zIndex: 997
    }
  });
};
_s4(useDrawerStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default AppDrawer;
var _c;
$RefreshReg$(_c, "AppDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/AppDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNVOzs7Ozs7Ozs7Ozs7Ozs7O0FBakNWLFNBQWdDQSxtQkFBNEM7QUFDNUUsU0FBOENDLGdCQUFnQkMsT0FBT0MsV0FBV0Msc0JBQW9EO0FBQ3BJLFNBQVNDLGdCQUFnQjtBQWF6QixNQUFNQyxZQUFvREMsV0FBVTtBQUFBQyxLQUFBO0FBQ2xFLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFPQztBQUFBQSxJQUFVQztBQUFBQSxJQUFRQztBQUFBQSxJQUFXQztBQUFBQSxJQUFRQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUEyQkM7QUFBQUEsRUFBVSxJQUFJVjtBQUVqSCxRQUFNVyxlQUFlQyxnQkFBZ0JGLFNBQVM7QUFDOUMsUUFBTUcsa0JBQWtCQyxtQkFBbUI7QUFDM0MsUUFBTUMsYUFBYUMsY0FBYztBQUVqQyxRQUFNQyxvQkFBb0J4QixZQUFZLE1BQU07QUFDMUMsUUFBSSxDQUFDYTtBQUFRLGFBQU87QUFDcEIsV0FBT0E7QUFBQUEsRUFDVCxHQUFHLENBQUNBLE1BQU0sQ0FBQztBQUVYLFNBQ0UsdUJBQUMsU0FDQyxZQUFZO0FBQUEsSUFBRVksUUFBUTtBQUFBLE1BQUVDLE1BQU07QUFBQSxRQUFFQyxRQUFRO0FBQUEsTUFBSTtBQUFBLElBQUU7QUFBQSxFQUFFLEdBQ2hELFlBQVlsQixPQUNaLGdCQUFnQkssY0FDWixNQUNBLHVCQUFDLFlBQU8sV0FBV1EsV0FBV00sUUFDM0JkLHNCQUFZLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLElBQ0FlLFFBRUosMkJBQ0EsUUFDQSxXQUNBLGNBQWMsTUFBTTtBQUFBLEVBQUMsR0FDckIsdUJBQXVCaEIsVUFBVVcsbUJBQ2pDLGtCQUFrQixNQUNsQixRQUFRTixjQUNSLE1BQU1ILFFBQVFaLFVBQVUyQixTQUFTM0IsVUFBVTRCLFFBQzNDLGFBQWFoQixRQUFRLFdBQVdjLFFBRWhDLGlDQUFDLFNBQUksV0FBV1AsV0FBV1UsU0FDekIsaUNBQUMsa0JBQWUsUUFBUVosaUJBQ3JCVixZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBQ0YsR0F4Q0tGLFdBQWdEO0FBQUEsVUFHL0JhLGlCQUNHRSxvQkFDTEUsYUFBYTtBQUFBO0FBQUFVLEtBTDVCM0I7QUEwQ04sTUFBTWlCLGdCQUFnQkEsTUFBTTtBQUFBVyxNQUFBO0FBQzFCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFRLElBQUk5QixTQUFTO0FBRTdCLFNBQU9KLGVBQWU7QUFBQSxJQUNwQitCLFNBQVM7QUFBQSxNQUNQSSxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZWLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQUMsUUFBUTtBQUFBLE1BQ05VLFNBQVM7QUFBQSxNQUNUQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLGNBQWNOLFFBQVFPO0FBQUFBLE1BQ3RCQyxhQUFhUixRQUFRTztBQUFBQSxNQUNyQkUsY0FBY1QsUUFBUVU7QUFBQUEsSUFDeEI7QUFBQSxJQUNBQyxXQUFXO0FBQUEsTUFDVFYsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDRixJQXJCS1gsZUFBYTtBQUFBLFVBQ0dsQixRQUFRO0FBQUE7QUFzQjlCLE1BQU1nQixxQkFBcUJBLE1BQU07QUFBQTBCLE1BQUE7QUFDL0IsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSTNDLFNBQVM7QUFFNUIsU0FBTyxPQUF1QztBQUFBLElBQzVDcUIsTUFBTTtBQUFBLE1BQ0p1QixXQUFXO0FBQUEsUUFDVCx3Q0FBd0M7QUFBQSxVQUN0Q0MsZ0JBQWdCO0FBQUEsVUFDaEJDLGNBQWM7QUFBQSxVQUNkQyxnQkFBaUIsR0FBRUosT0FBT0ssS0FBSyxHQUFHLEtBQUtMLE9BQU9LLEtBQUssR0FBRztBQUFBLFFBQ3hEO0FBQUEsUUFDQSwyREFBMkQ7QUFBQSxVQUN6REMsT0FBTztBQUFBLFFBQ1Q7QUFBQSxRQUNBLGlFQUFpRTtBQUFBLFVBQy9EQyxZQUFZUCxPQUFPSyxLQUFLLEdBQUc7QUFBQSxRQUM3QjtBQUFBLFFBQ0EsaUVBQWlFO0FBQUEsVUFDL0RFLFlBQVlQLE9BQU9LLEtBQUssR0FBRztBQUFBLFFBQzdCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBRyxhQUFhM0I7QUFBQUEsSUFDYjRCLGFBQWE1QjtBQUFBQSxJQUNiNkIsa0JBQWtCN0I7QUFBQUEsSUFDbEI4QixrQkFBa0I5QjtBQUFBQSxFQUNwQjtBQUNGO0FBQUNrQixJQTNCSzFCLG9CQUFrQjtBQUFBLFVBQ0hoQixRQUFRO0FBQUE7QUE0QjdCLE1BQU1jLGtCQUFrQkEsQ0FBQ0YsY0FBd0I7QUFBQTJDLE1BQUE7QUFDL0MsUUFBTTtBQUFBLElBQUVaO0FBQUFBLEVBQU8sSUFBSTNDLFNBQVM7QUFFNUIsU0FBTyxPQUE4QjtBQUFBLElBQ25DcUIsTUFBTTtBQUFBLE1BQ0ptQyxjQUFjO0FBQUEsTUFDZHpCLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTBCLFVBQVU7QUFBQSxNQUNSbkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBb0MsbUJBQW1CO0FBQUEsTUFDakJDLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQUMsWUFBWTtBQUFBLE1BQ1Y3QixRQUFRO0FBQUEsTUFDUkcsWUFBWTtBQUFBLE1BQ1osWUFBWTtBQUFBLFFBQ1ZILFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBLElBRUE4QixTQUFTO0FBQUEsTUFDUEMsU0FBU2xELFlBQVksSUFBSVk7QUFBQUEsTUFDekJ1QyxZQUFZO0FBQUEsTUFDWkMsZUFBZTtBQUFBLE1BQ2YsNkJBQTZCO0FBQUEsUUFDM0JDLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQXpELFFBQVE7QUFBQSxNQUNOMEMsWUFBWVAsT0FBT3VCO0FBQUFBLE1BQ25CQyxnQkFBZ0J4QixPQUFPSyxLQUFLLEdBQUc7QUFBQSxNQUMvQjFCLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNGO0FBQUNpQyxJQWpES3pDLGlCQUFlO0FBQUEsVUFDQWQsUUFBUTtBQUFBO0FBa0Q3QixlQUFlQztBQUFTLElBQUEyQjtBQUFBd0MsYUFBQXhDLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsIm1lcmdlU3R5bGVTZXRzIiwiUGFuZWwiLCJQYW5lbFR5cGUiLCJTY3JvbGxhYmxlUGFuZSIsInVzZVRoZW1lIiwiQXBwRHJhd2VyIiwicHJvcHMiLCJfcyIsInRpdGxlIiwiY2hpbGRyZW4iLCJpc09wZW4iLCJvbkRpc21pc3MiLCJmb290ZXIiLCJyZW5kZXJUaXRsZSIsImxhcmdlIiwib25SZW5kZXJOYXZpZ2F0aW9uQ29udGVudCIsIm5vUGFkZGluZyIsImRyYXdlclN0eWxlcyIsInVzZURyYXdlclN0eWxlcyIsInNjcm9sbEJhclN0eWxlcyIsInVzZVNjcm9sbEJhclN0eWxlcyIsImNsYXNzTmFtZXMiLCJ1c2VDbGFzc05hbWVzIiwicmVuZGVyUGFuZWxGb290ZXIiLCJzdHlsZXMiLCJyb290IiwiekluZGV4IiwiaGVhZGVyIiwidW5kZWZpbmVkIiwiY3VzdG9tIiwibWVkaXVtIiwid3JhcHBlciIsIl9jIiwiX3MyIiwic3BhY2luZyIsImhlaWdodCIsInBvc2l0aW9uIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJmbGV4IiwicGFkZGluZ1JpZ2h0IiwieGwiLCJwYWRkaW5nTGVmdCIsIm1hcmdpbkJvdHRvbSIsInhzIiwiZm9vdGVyQm94IiwiX3MzIiwiY29sb3JzIiwic2VsZWN0b3JzIiwic2Nyb2xsYmFyV2lkdGgiLCJib3JkZXJSYWRpdXMiLCJzY3JvbGxiYXJDb2xvciIsImdyYXkiLCJ3aWR0aCIsImJhY2tncm91bmQiLCJzdGlja3lBYm92ZSIsInN0aWNreUJlbG93Iiwic3RpY2t5QmVsb3dJdGVtcyIsImNvbnRlbnRDb250YWluZXIiLCJfczQiLCJvdmVyZmxvd1dyYXAiLCJjb21tYW5kcyIsInNjcm9sbGFibGVDb250ZW50Iiwib3ZlcmZsb3ciLCJuYXZpZ2F0aW9uIiwiY29udGVudCIsInBhZGRpbmciLCJwYWRkaW5nVG9wIiwicGFkZGluZ0JvdHRvbSIsImZsZXhHcm93Iiwid2hpdGUiLCJib3JkZXJUb3BDb2xvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcERyYXdlci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kcmF3ZXIvQXBwRHJhd2VyLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBQcm9wc1dpdGhDaGlsZHJlbiwgdXNlQ2FsbGJhY2ssIFJlYWN0RWxlbWVudCwgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElQYW5lbFN0eWxlcywgSVNjcm9sbGFibGVQYW5lU3R5bGVzLCBtZXJnZVN0eWxlU2V0cywgUGFuZWwsIFBhbmVsVHlwZSwgU2Nyb2xsYWJsZVBhbmUsIElQYW5lbFByb3BzLCBJUmVuZGVyRnVuY3Rpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEFwcERyYXdlclByb3BzIHtcclxuICB0aXRsZT86IHN0cmluZ1xyXG4gIGlzT3BlbjogYm9vbGVhbixcclxuICBvbkRpc21pc3M6ICgpID0+IHZvaWQsXHJcbiAgcmVuZGVyVGl0bGU/OiAoKSA9PiBSZWFjdE5vZGVcclxuICBmb290ZXI/OiBSZWFjdEVsZW1lbnRcclxuICBsYXJnZT86IGJvb2xlYW5cclxuICBvblJlbmRlck5hdmlnYXRpb25Db250ZW50PzogSVJlbmRlckZ1bmN0aW9uPElQYW5lbFByb3BzPlxyXG4gIG5vUGFkZGluZz86IGJvb2xlYW4sXHJcbn1cclxuXHJcbmNvbnN0IEFwcERyYXdlcjogRkM8UHJvcHNXaXRoQ2hpbGRyZW48QXBwRHJhd2VyUHJvcHM+PiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgdGl0bGUsIGNoaWxkcmVuLCBpc09wZW4sIG9uRGlzbWlzcywgZm9vdGVyLCByZW5kZXJUaXRsZSwgbGFyZ2UsIG9uUmVuZGVyTmF2aWdhdGlvbkNvbnRlbnQsIG5vUGFkZGluZyB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgZHJhd2VyU3R5bGVzID0gdXNlRHJhd2VyU3R5bGVzKG5vUGFkZGluZylcclxuICBjb25zdCBzY3JvbGxCYXJTdHlsZXMgPSB1c2VTY3JvbGxCYXJTdHlsZXMoKVxyXG4gIGNvbnN0IGNsYXNzTmFtZXMgPSB1c2VDbGFzc05hbWVzKClcclxuXHJcbiAgY29uc3QgcmVuZGVyUGFuZWxGb290ZXIgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBpZiAoIWZvb3RlcikgcmV0dXJuIG51bGxcclxuICAgIHJldHVybiBmb290ZXJcclxuICB9LCBbZm9vdGVyXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxQYW5lbFxyXG4gICAgICBsYXllclByb3BzPXt7IHN0eWxlczogeyByb290OiB7IHpJbmRleDogOTk2IH0gfSB9fVxyXG4gICAgICBoZWFkZXJUZXh0PXt0aXRsZX1cclxuICAgICAgb25SZW5kZXJIZWFkZXI9e3JlbmRlclRpdGxlXHJcbiAgICAgICAgPyAoKSA9PlxyXG4gICAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9e2NsYXNzTmFtZXMuaGVhZGVyfT5cclxuICAgICAgICAgICAge3JlbmRlclRpdGxlKCl9XHJcbiAgICAgICAgICA8L2hlYWRlcj5cclxuICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICB9XHJcbiAgICAgIG9uUmVuZGVyTmF2aWdhdGlvbkNvbnRlbnQ9e29uUmVuZGVyTmF2aWdhdGlvbkNvbnRlbnR9XHJcbiAgICAgIGlzT3Blbj17aXNPcGVufVxyXG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cclxuICAgICAgb25PdXRlckNsaWNrPXsoKSA9PiB7fX1cclxuICAgICAgb25SZW5kZXJGb290ZXJDb250ZW50PXtmb290ZXIgJiYgcmVuZGVyUGFuZWxGb290ZXJ9XHJcbiAgICAgIGlzRm9vdGVyQXRCb3R0b209e3RydWV9XHJcbiAgICAgIHN0eWxlcz17ZHJhd2VyU3R5bGVzfVxyXG4gICAgICB0eXBlPXtsYXJnZSA/IFBhbmVsVHlwZS5jdXN0b20gOiBQYW5lbFR5cGUubWVkaXVtfVxyXG4gICAgICBjdXN0b21XaWR0aD17bGFyZ2UgPyAnMTAwMHB4JyA6IHVuZGVmaW5lZH1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzTmFtZXMud3JhcHBlcn0+XHJcbiAgICAgICAgPFNjcm9sbGFibGVQYW5lIHN0eWxlcz17c2Nyb2xsQmFyU3R5bGVzfT5cclxuICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L1Njcm9sbGFibGVQYW5lPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvUGFuZWw+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VDbGFzc05hbWVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxyXG5cclxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgd3JhcHBlcjoge1xyXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgIHpJbmRleDogOTk2LFxyXG4gICAgfSxcclxuICAgIGhlYWRlcjoge1xyXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICBmbGV4OiAxLFxyXG4gICAgICBwYWRkaW5nUmlnaHQ6IHNwYWNpbmcueGwsXHJcbiAgICAgIHBhZGRpbmdMZWZ0OiBzcGFjaW5nLnhsLFxyXG4gICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcueHMsXHJcbiAgICB9LFxyXG4gICAgZm9vdGVyQm94OiB7XHJcbiAgICAgIGhlaWdodDogMTAwLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5jb25zdCB1c2VTY3JvbGxCYXJTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgcmV0dXJuICgpOiBQYXJ0aWFsPElTY3JvbGxhYmxlUGFuZVN0eWxlcz4gPT4gKHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgc2VsZWN0b3JzOiB7XHJcbiAgICAgICAgJy5tcy1TY3JvbGxhYmxlUGFuZS0tY29udGVudENvbnRhaW5lcic6IHtcclxuICAgICAgICAgIHNjcm9sbGJhcldpZHRoOiAnNXB4JyxcclxuICAgICAgICAgIGJvcmRlclJhZGl1czogJzRweCcsXHJcbiAgICAgICAgICBzY3JvbGxiYXJDb2xvcjogYCR7Y29sb3JzLmdyYXlbMzAwXX0gJHtjb2xvcnMuZ3JheVsyMDBdfWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnLm1zLVNjcm9sbGFibGVQYW5lLS1jb250ZW50Q29udGFpbmVyOjotd2Via2l0LXNjcm9sbGJhcic6IHtcclxuICAgICAgICAgIHdpZHRoOiAnNXB4JyxcclxuICAgICAgICB9LFxyXG4gICAgICAgICcubXMtU2Nyb2xsYWJsZVBhbmUtLWNvbnRlbnRDb250YWluZXI6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrJzoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLmdyYXlbMjAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICAgICcubXMtU2Nyb2xsYWJsZVBhbmUtLWNvbnRlbnRDb250YWluZXI6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iJzoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLmdyYXlbMzAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHN0aWNreUFib3ZlOiB1bmRlZmluZWQsXHJcbiAgICBzdGlja3lCZWxvdzogdW5kZWZpbmVkLFxyXG4gICAgc3RpY2t5QmVsb3dJdGVtczogdW5kZWZpbmVkLFxyXG4gICAgY29udGVudENvbnRhaW5lcjogdW5kZWZpbmVkLFxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IHVzZURyYXdlclN0eWxlcyA9IChub1BhZGRpbmc/OiBib29sZWFuKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgcmV0dXJuICgpOiBQYXJ0aWFsPElQYW5lbFN0eWxlcz4gPT4gKHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICBoZWlnaHQ6ICdhdXRvJyxcclxuICAgIH0sXHJcbiAgICBjb21tYW5kczoge1xyXG4gICAgICB6SW5kZXg6IDEsXHJcbiAgICB9LFxyXG4gICAgc2Nyb2xsYWJsZUNvbnRlbnQ6IHtcclxuICAgICAgb3ZlcmZsb3c6ICd2aXNpYmxlJyxcclxuICAgIH0sXHJcbiAgICBuYXZpZ2F0aW9uOiB7XHJcbiAgICAgIGhlaWdodDogJ2F1dG8nLFxyXG4gICAgICBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcsXHJcbiAgICAgICc+IGJ1dHRvbic6IHtcclxuICAgICAgICBoZWlnaHQ6IDQwLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICBjb250ZW50OiB7XHJcbiAgICAgIHBhZGRpbmc6IG5vUGFkZGluZyA/IDAgOiB1bmRlZmluZWQsXHJcbiAgICAgIHBhZGRpbmdUb3A6IDAsXHJcbiAgICAgIHBhZGRpbmdCb3R0b206IDAsXHJcbiAgICAgICdAbWVkaWEgKG1pbi1oZWlnaHQ6IDIwcHgpJzoge1xyXG4gICAgICAgIGZsZXhHcm93OiAxLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIC8vIEZJWE1FIC0gQ8OzZGlnbyBhYmFpeG8gcGFyb3UgZGUgZnVuY2lvbmFyIG5vIHNlcnZpZG9yIChzY3JvbGwgZG8gZm9vdGVyKSwgcG9yw6ltIGZ1bmNpb25hIGVtIERFVlxyXG4gICAgLy8gICAgICAgICDDiSBwcmVjaXNvIHZlcmlmaWNhciBvIHF1ZSBob3V2ZSBubyBzZXJ2aWRvciBlIHJldG9ybmFyIGVzdGEgdmVyc8Ojb1xyXG4gICAgLy8gICAgICAgICBQb2lzIG8gcXVlIGZvaSBmZWl0byBhcXVpIMOpIHVtYSBzb2x1w6fDo28gdGVtcG9yw6FyaWFcclxuICAgIC8vIHByb3BzLmlzRm9vdGVyQXRCb3R0b20gJiYge1xyXG4gICAgLy8gICBzZWxlY3RvcnM6IHtcclxuICAgIC8vICAgICAnQG1lZGlhKG1pbi1oZWlnaHQ6IDQ4MHB4KSc6IHtcclxuICAgIC8vICAgICAgIGhlaWdodDogJ2F1dG8nLFxyXG4gICAgLy8gICAgICAgbWluSGVpZ2h0OiAnY2FsYygxMDAlIC0gMTE1cHgpJyxcclxuICAgIC8vICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgIC8vICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgIH0sXHJcbiAgICAvLyB9LCxcclxuICAgIGZvb3Rlcjoge1xyXG4gICAgICBiYWNrZ3JvdW5kOiBjb2xvcnMud2hpdGUsXHJcbiAgICAgIGJvcmRlclRvcENvbG9yOiBjb2xvcnMuZ3JheVsyMDBdLFxyXG4gICAgICB6SW5kZXg6IDk5NyxcclxuICAgIH0sXHJcbiAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwRHJhd2VyXHJcbiJdfQ==