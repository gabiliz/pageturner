import.meta.env = {"M_REQUEST_TIMEOUT":"0","M_REFRESH_TOKEN_ENDPOINT":"/api/account/refresh-token","MANPATH":"/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man:/usr/share/man:/usr/local/share/man:/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man::","MallocNanoZone":"0","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import __vite__cjsImport2_reactDom from "/node_modules/.vite/deps/react-dom.js?v=9f90a7ff"; const ReactDOM = __vite__cjsImport2_reactDom.__esModule ? __vite__cjsImport2_reactDom.default : __vite__cjsImport2_reactDom;
import { initializeIcons, LayerHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AppProvider } from "/src/shared/providers/index.tsx";
import { setBodyStyles } from "/src/shared/style/styleReset.ts";
import { DialogsLayer } from "/src/shared/components/index.ts?t=1701096626433";
import App from "/src/App.tsx?t=1701096626433";
import { registerLicense } from "/node_modules/.vite/deps/@syncfusion_ej2-base.js?v=9f90a7ff";
import "/node_modules/primereact/resources/themes/fluent-light/theme.css";
import "/node_modules/primereact/resources/primereact.min.css";
import "/node_modules/primeicons/primeicons.css";
import "/node_modules/primeflex/primeflex.css";
import "/src/primefaces-override.css";
import "/src/App.css";
import { NotificationsLayer } from "/src/shared/components/notifications/index.ts";
import createCustomIcons from "/src/shared/style/customIcons.tsx";
setBodyStyles();
createCustomIcons();
initializeIcons();
registerLicense("ORg4AjUWIQA/Gnt2VlhhQlVEfV5AQmBIYVp/TGpJfl96cVxMZVVBJAtUQF1hSn9Td0RiWXpecHdSQGRa");
if (!import.meta.env.PROD) {
  document.title = `[${import.meta.env.MODE.toUpperCase()}] ${document.title}`;
}
ReactDOM.render(/* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(AppProvider, { children: [
  /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
    lineNumber: 26,
    columnNumber: 7
  }, this),
  /* @__PURE__ */ jsxDEV(LayerHost, { id: "drawersHost" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this),
  /* @__PURE__ */ jsxDEV(DialogsLayer, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this),
  /* @__PURE__ */ jsxDEV(NotificationsLayer, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this)
] }, void 0, true, {
  fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
  lineNumber: 25,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/Users/gabiliz/Documents/auditor_frontend/src/index.tsx",
  lineNumber: 24,
  columnNumber: 17
}, this), document.getElementById("root"));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNO0FBOUJOLFNBQVNBLGtCQUFrQjtBQUMzQixPQUFPQyxjQUFjO0FBQ3JCLFNBQVNDLGlCQUFpQkMsaUJBQWlCO0FBQzNDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsdUJBQXVCO0FBRWhDLE9BQU87QUFDUCxPQUFPO0FBQ1AsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPO0FBQ1AsT0FBTztBQUNQLFNBQVNDLDBCQUEwQjtBQUNuQyxPQUFPQyx1QkFBdUI7QUFFOUJMLGNBQWM7QUFDZEssa0JBQWtCO0FBQ2xCUixnQkFBZ0I7QUFDaEJNLGdCQUFnQixrRkFBa0Y7QUFFbEcsSUFBSSxDQUFDRyxZQUFZQyxJQUFJQyxNQUFNO0FBQ3pCQyxXQUFTQyxRQUFTLElBQUdKLFlBQVlDLElBQUlJLEtBQUtDLFlBQVksTUFBTUgsU0FBU0M7QUFDdkU7QUFFQWQsU0FBU2lCLE9BQ1AsdUJBQUMsY0FDQyxpQ0FBQyxlQUNDO0FBQUEseUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUk7QUFBQSxFQUNKLHVCQUFDLGFBQVUsSUFBRyxpQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJCO0FBQUEsRUFDM0IsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhO0FBQUEsRUFDYix1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1CO0FBQUEsS0FKckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQU9BLEdBQ0FKLFNBQVNLLGVBQWUsTUFBTSxDQUNoQyIsIm5hbWVzIjpbIlN0cmljdE1vZGUiLCJSZWFjdERPTSIsImluaXRpYWxpemVJY29ucyIsIkxheWVySG9zdCIsIkFwcFByb3ZpZGVyIiwic2V0Qm9keVN0eWxlcyIsIkRpYWxvZ3NMYXllciIsIkFwcCIsInJlZ2lzdGVyTGljZW5zZSIsIk5vdGlmaWNhdGlvbnNMYXllciIsImNyZWF0ZUN1c3RvbUljb25zIiwiaW1wb3J0IiwiZW52IiwiUFJPRCIsImRvY3VtZW50IiwidGl0bGUiLCJNT0RFIiwidG9VcHBlckNhc2UiLCJyZW5kZXIiLCJnZXRFbGVtZW50QnlJZCJdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL2luZGV4LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSdcclxuaW1wb3J0IHsgaW5pdGlhbGl6ZUljb25zLCBMYXllckhvc3QgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEFwcFByb3ZpZGVyIH0gZnJvbSAnLi9zaGFyZWQvcHJvdmlkZXJzJ1xyXG5pbXBvcnQgeyBzZXRCb2R5U3R5bGVzIH0gZnJvbSAnLi9zaGFyZWQvc3R5bGUvc3R5bGVSZXNldCdcclxuaW1wb3J0IHsgRGlhbG9nc0xheWVyIH0gZnJvbSAnLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IEFwcCBmcm9tICcuL0FwcCdcclxuaW1wb3J0IHsgcmVnaXN0ZXJMaWNlbnNlIH0gZnJvbSAnQHN5bmNmdXNpb24vZWoyLWJhc2UnXHJcblxyXG5pbXBvcnQgJ3ByaW1lcmVhY3QvcmVzb3VyY2VzL3RoZW1lcy9mbHVlbnQtbGlnaHQvdGhlbWUuY3NzJ1xyXG5pbXBvcnQgJ3ByaW1lcmVhY3QvcmVzb3VyY2VzL3ByaW1lcmVhY3QubWluLmNzcydcclxuaW1wb3J0ICdwcmltZWljb25zL3ByaW1laWNvbnMuY3NzJ1xyXG5pbXBvcnQgJ3ByaW1lZmxleC9wcmltZWZsZXguY3NzJ1xyXG5pbXBvcnQgJy4vcHJpbWVmYWNlcy1vdmVycmlkZS5jc3MnXHJcbmltcG9ydCAnLi9BcHAuY3NzJ1xyXG5pbXBvcnQgeyBOb3RpZmljYXRpb25zTGF5ZXIgfSBmcm9tICcuL3NoYXJlZC9jb21wb25lbnRzL25vdGlmaWNhdGlvbnMnXHJcbmltcG9ydCBjcmVhdGVDdXN0b21JY29ucyBmcm9tICcuL3NoYXJlZC9zdHlsZS9jdXN0b21JY29ucydcclxuXHJcbnNldEJvZHlTdHlsZXMoKVxyXG5jcmVhdGVDdXN0b21JY29ucygpXHJcbmluaXRpYWxpemVJY29ucygpXHJcbnJlZ2lzdGVyTGljZW5zZSgnT1JnNEFqVVdJUUEvR250MlZsaGhRbFZFZlY1QVFtQklZVnAvVEdwSmZsOTZjVnhNWlZWQkpBdFVRRjFoU245VGQwUmlXWHBlY0hkU1FHUmEnKVxyXG5cclxuaWYgKCFpbXBvcnQubWV0YS5lbnYuUFJPRCkge1xyXG4gIGRvY3VtZW50LnRpdGxlID0gYFske2ltcG9ydC5tZXRhLmVudi5NT0RFLnRvVXBwZXJDYXNlKCl9XSAke2RvY3VtZW50LnRpdGxlfWBcclxufVxyXG5cclxuUmVhY3RET00ucmVuZGVyKFxyXG4gIDxTdHJpY3RNb2RlPlxyXG4gICAgPEFwcFByb3ZpZGVyPlxyXG4gICAgICA8QXBwIC8+XHJcbiAgICAgIDxMYXllckhvc3QgaWQ9XCJkcmF3ZXJzSG9zdFwiIC8+XHJcbiAgICAgIDxEaWFsb2dzTGF5ZXIgLz5cclxuICAgICAgPE5vdGlmaWNhdGlvbnNMYXllciAvPlxyXG4gICAgPC9BcHBQcm92aWRlcj5cclxuICA8L1N0cmljdE1vZGU+LFxyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JyksXHJcbilcclxuIl19