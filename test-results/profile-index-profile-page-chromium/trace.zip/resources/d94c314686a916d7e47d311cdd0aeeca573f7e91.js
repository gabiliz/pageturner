import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditExecutionTestSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useLocation, useNavigate, useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { Link, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { analyticalRevisionTestQueryService } from "/src/modules/audit/analyticalRevision/components/patrimonial/service/index.ts";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
const AuditExecutionTestSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const [searchParams] = useSearchParams();
  const {
    auditId,
    codeAcc,
    companyId,
    visionType,
    revisionType,
    testId,
    groupToShow
  } = useParams();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const {
    data: audit,
    isLoading: loadingAudit
  } = auditQueryService.useFindOne(auditId);
  const {
    data,
    isLoading
  } = analyticalRevisionTestQueryService.useFindAll(auditId, codeAcc, companyId);
  const testDescription = searchParams.get("description") || "";
  const navLinkGroups = useMemo(() => {
    if (data) {
      return [{
        links: data?.map((link) => ({
          name: `${link.codCadastro} - ${link.nome}`,
          permission: "Auditoria",
          key: link.id,
          url: `${pathname.split(visionType)[0]}${visionType}/${link.id}?description=${searchParams.get("description")}`
        }))
      }];
    }
  }, [data, testId, isLoading]);
  const permissionNav = useMemo(() => {
    const filteredGroup = navLinkGroups ? [...navLinkGroups] : [];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups, testId]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(`${pathname.split(visionType)[0]}details/${item.key}?description=${searchParams.get("description")}`);
    }
  };
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: testDescription, isLoading: loadingAudit || isLoading, defaultCollapsed: false, disabledCollapse: true, subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestSideMenu.tsx",
    lineNumber: 73,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestSideMenu.tsx",
    lineNumber: 72,
    columnNumber: 141
  }, this), selectedKey: testId, groups: permissionNav, onLinkClick: handleClick, goBack: () => navigate(`/audit/audits/${auditId}/control-panel/analysis/${revisionType}/${groupToShow}/${companyId}/${codeAcc}/tests?&description=${searchParams.get("description")}`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestSideMenu.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
};
_s(AuditExecutionTestSideMenu, "BUtwxHFw+a2sRAhMVpySE3DkYU4=", false, function() {
  return [useNavigate, useLocation, useSearchParams, useParams, usePermissions, useTheme, auditQueryService.useFindOne, analyticalRevisionTestQueryService.useFindAll];
});
_c = AuditExecutionTestSideMenu;
export default AuditExecutionTestSideMenu;
var _c;
$RefreshReg$(_c, "AuditExecutionTestSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditExecutionTestSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVVOzs7Ozs7Ozs7Ozs7Ozs7O0FBekVWLFNBQXlCQSxlQUFlO0FBRXhDLFNBQVNDLGFBQWFDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUNyRSxTQUF1QkMsc0JBQXNCO0FBQzdDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxNQUFNQyxZQUFZO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQywwQ0FBMEM7QUFDbkQsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDRCQUE0QjtBQUVyQyxNQUFNQyw2QkFBaUNBLE1BQU07QUFBQUMsS0FBQTtBQUMzQyxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTSxDQUFDZ0IsWUFBWSxJQUFJYixnQkFBZ0I7QUFDdkMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVNDO0FBQUFBLElBQVNDO0FBQUFBLElBQVdDO0FBQUFBLElBQVlDO0FBQUFBLElBQWNDO0FBQUFBLElBQVFDO0FBQUFBLEVBQVksSUFBSXJCLFVBQXFDO0FBQzVILFFBQU07QUFBQSxJQUFFc0I7QUFBQUEsRUFBYyxJQUFJcEIsZUFBZTtBQUN6QyxRQUFNO0FBQUEsSUFBRXFCO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSXBCLFNBQVM7QUFDM0QsUUFBTTtBQUFBLElBQUVxQixNQUFNQztBQUFBQSxJQUFPQyxXQUFXQztBQUFBQSxFQUFhLElBQUl0QixrQkFBa0J1QixXQUFXaEIsT0FBaUI7QUFFL0YsUUFBTTtBQUFBLElBQUVZO0FBQUFBLElBQU1FO0FBQUFBLEVBQVUsSUFBSXRCLG1DQUFtQ3lCLFdBQVdqQixTQUFTQyxTQUFTQyxTQUFTO0FBRXJHLFFBQU1nQixrQkFBa0JuQixhQUFhb0IsSUFBSSxhQUFhLEtBQUs7QUFFM0QsUUFBTUMsZ0JBQTZDdEMsUUFBUSxNQUFNO0FBQy9ELFFBQUk4QixNQUFNO0FBQ1IsYUFBTyxDQUNMO0FBQUEsUUFDRVMsT0FBT1QsTUFBTVUsSUFBSUMsV0FBVTtBQUFBLFVBQ3pCQyxNQUFPLEdBQUVELEtBQUtFLGlCQUFpQkYsS0FBS0c7QUFBQUEsVUFDcENDLFlBQVk7QUFBQSxVQUNaQyxLQUFLTCxLQUFLTTtBQUFBQSxVQUNWQyxLQUFNLEdBQUVoQyxTQUFTaUMsTUFBTTVCLFVBQW9CLEVBQUUsQ0FBQyxJQUFJQSxjQUFjb0IsS0FBS00sa0JBQWtCOUIsYUFBYW9CLElBQUksYUFBYTtBQUFBLFFBQ3ZILEVBQWU7QUFBQSxNQUNqQixDQUFDO0FBQUEsSUFFTDtBQUFBLEVBQ0YsR0FBRyxDQUFDUCxNQUFNUCxRQUFRUyxTQUFTLENBQUM7QUFFNUIsUUFBTWtCLGdCQUFnQmxELFFBQVEsTUFBTTtBQUNsQyxVQUFNbUQsZ0JBQWlDYixnQkFBZ0IsQ0FBQyxHQUFHQSxhQUFhLElBQUk7QUFDNUVhLGtCQUFjQyxRQUFRLENBQUNDLE9BQU9DLFVBQVU7QUFDdENILG9CQUFjRyxLQUFLLEVBQUVmLFFBQVFjLE1BQU1kLE1BQU1nQixPQUFPQyxhQUFXL0IsY0FBYytCLFFBQVFYLFlBQTRCLFlBQVksQ0FBQztBQUFBLElBQzVILENBQUM7QUFDRCxXQUFPTTtBQUFBQSxFQUNULEdBQUcsQ0FBQ2IsZUFBZWYsTUFBTSxDQUFDO0FBRTFCLFFBQU1rQyxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUVsQjlDLGVBQVUsR0FBRUMsU0FBU2lDLE1BQU01QixVQUFvQixFQUFFLENBQUMsWUFBWXNDLEtBQUtiLG1CQUFtQjdCLGFBQWFvQixJQUFJLGFBQWEsR0FBRztBQUFBLElBQ3pIO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsWUFDQyxPQUFPRCxpQkFDUCxXQUFXSCxnQkFBZ0JELFdBQzNCLGtCQUFrQixPQUNsQixrQkFBa0IsTUFDbEIsVUFDRSx1QkFBQyxRQUNDLE1BQ0csa0JBQWlCRCxPQUFPK0IsVUFBVUMsdUJBQ2pDaEMsT0FBTytCLFVBQVVFLHNCQUNaLEdBQUVqQyxPQUFPK0IsU0FBU0UsbUNBQW1DakMsT0FBTytCLFVBQVVHLG1CQUN2RWxDLE9BQU8rQixVQUFVZixNQUd6QixRQUFPLFNBRVAsaUNBQUMsUUFDQyxRQUFRO0FBQUEsSUFDTm1CLE1BQU07QUFBQSxNQUNKQyxPQUFPekMsT0FBTzBDLEtBQUssR0FBRztBQUFBLE1BQ3RCeEMsWUFBWUEsV0FBV3lDO0FBQUFBLE1BQ3ZCeEMsVUFBVUEsU0FBU3lDO0FBQUFBLE1BQ25CQyxxQkFBcUI3QyxPQUFPMEMsS0FBSyxHQUFHO0FBQUEsTUFDcENJLFlBQVk3QyxRQUFROEM7QUFBQUEsTUFDcEJDLFVBQVU7QUFBQSxNQUNWQyxjQUFjaEQsUUFBUWlEO0FBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUTCxxQkFBcUI3QyxPQUFPMEMsS0FBSyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLE9BQUssTUFFSnJDO0FBQUFBLFdBQU8rQixVQUFVZTtBQUFBQSxJQUFhO0FBQUEsSUFBSWpFLHFCQUFxQm1CLE9BQU8rQixVQUFVRyxjQUF3QjtBQUFBLE9BakJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsR0FFRixhQUFhMUMsUUFDYixRQUFRMkIsZUFDUixhQUFhTyxhQUNiLFFBQVEsTUFBTTFDLFNBQVUsaUJBQWdCRyxrQ0FBa0NJLGdCQUFnQkUsZUFBZUosYUFBYUQsOEJBQThCRixhQUFhb0IsSUFBSSxhQUFhLEdBQUcsS0F4Q3ZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q3lMO0FBRzdMO0FBQUN2QixHQXhGS0QsNEJBQThCO0FBQUEsVUFDakJYLGFBQ0lELGFBQ0VHLGlCQUNnRUQsV0FDN0RFLGdCQUN3QkksVUFDREUsa0JBQWtCdUIsWUFFdkN4QixtQ0FBbUN5QixVQUFVO0FBQUE7QUFBQTJDLEtBVHJFakU7QUEwRk4sZUFBZUE7QUFBMEIsSUFBQWlFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsInVzZVBlcm1pc3Npb25zIiwiU2lkZU1lbnUiLCJMaW5rIiwiVGV4dCIsInVzZVRoZW1lIiwiYW5hbHl0aWNhbFJldmlzaW9uVGVzdFF1ZXJ5U2VydmljZSIsImF1ZGl0UXVlcnlTZXJ2aWNlIiwiZm9ybWF0UHJvcG9zYWxOdW1iZXIiLCJBdWRpdEV4ZWN1dGlvblRlc3RTaWRlTWVudSIsIl9zIiwibmF2aWdhdGUiLCJwYXRobmFtZSIsInNlYXJjaFBhcmFtcyIsImF1ZGl0SWQiLCJjb2RlQWNjIiwiY29tcGFueUlkIiwidmlzaW9uVHlwZSIsInJldmlzaW9uVHlwZSIsInRlc3RJZCIsImdyb3VwVG9TaG93IiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJkYXRhIiwiYXVkaXQiLCJpc0xvYWRpbmciLCJsb2FkaW5nQXVkaXQiLCJ1c2VGaW5kT25lIiwidXNlRmluZEFsbCIsInRlc3REZXNjcmlwdGlvbiIsImdldCIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsIm1hcCIsImxpbmsiLCJuYW1lIiwiY29kQ2FkYXN0cm8iLCJub21lIiwicGVybWlzc2lvbiIsImtleSIsImlkIiwidXJsIiwic3BsaXQiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsImhhbmRsZUNsaWNrIiwiZXYiLCJpdGVtIiwidW5kZWZpbmVkIiwicHJldmVudERlZmF1bHQiLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsInJvb3QiLCJjb2xvciIsImdyYXkiLCJzZW1pYm9sZCIsInAxNCIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJtYXJnaW5MZWZ0IiwibGciLCJtYXhXaWR0aCIsIm1hcmdpbkJvdHRvbSIsIm1kIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdEV4ZWN1dGlvblRlc3RTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRFeGVjdXRpb25UZXN0U2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSU5hdkxpbmtHcm91cCwgSU5hdkxpbmsgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QvbGliL05hdidcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHNlcnZpY2VDb2RlcywgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xyXG5pbXBvcnQgeyBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBMaW5rLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgSUV4ZWN1dGlvblRlc3RzUGFnZVBhcmFtcyB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC90eXBlcy9wYWdlUm91dGVzUGFyYW1zJ1xyXG5pbXBvcnQgeyBhbmFseXRpY2FsUmV2aXNpb25UZXN0UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vYW5hbHl0aWNhbFJldmlzaW9uL2NvbXBvbmVudHMvcGF0cmltb25pYWwvc2VydmljZSdcclxuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9hdWRpdHMvc2VydmljZXMnXHJcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xyXG5cclxuY29uc3QgQXVkaXRFeGVjdXRpb25UZXN0U2lkZU1lbnU6IEZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpXHJcbiAgY29uc3QgeyBhdWRpdElkLCBjb2RlQWNjLCBjb21wYW55SWQsIHZpc2lvblR5cGUsIHJldmlzaW9uVHlwZSwgdGVzdElkLCBncm91cFRvU2hvdyB9ID0gdXNlUGFyYW1zPElFeGVjdXRpb25UZXN0c1BhZ2VQYXJhbXM+KClcclxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcclxuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZywgZm9udFdlaWdodCwgZm9udFNpemUgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCB7IGRhdGE6IGF1ZGl0LCBpc0xvYWRpbmc6IGxvYWRpbmdBdWRpdCB9ID0gYXVkaXRRdWVyeVNlcnZpY2UudXNlRmluZE9uZShhdWRpdElkIGFzIHN0cmluZylcclxuXHJcbiAgY29uc3QgeyBkYXRhLCBpc0xvYWRpbmcgfSA9IGFuYWx5dGljYWxSZXZpc2lvblRlc3RRdWVyeVNlcnZpY2UudXNlRmluZEFsbChhdWRpdElkLCBjb2RlQWNjLCBjb21wYW55SWQpXHJcblxyXG4gIGNvbnN0IHRlc3REZXNjcmlwdGlvbiA9IHNlYXJjaFBhcmFtcy5nZXQoJ2Rlc2NyaXB0aW9uJykgfHwgJydcclxuXHJcbiAgY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdIHwgdW5kZWZpbmVkID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoZGF0YSkge1xyXG4gICAgICByZXR1cm4gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGxpbmtzOiBkYXRhPy5tYXAobGluayA9PiAoKHtcclxuICAgICAgICAgICAgbmFtZTogYCR7bGluay5jb2RDYWRhc3Ryb30gLSAke2xpbmsubm9tZX1gLFxyXG4gICAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgICAga2V5OiBsaW5rLmlkLFxyXG4gICAgICAgICAgICB1cmw6IGAke3BhdGhuYW1lLnNwbGl0KHZpc2lvblR5cGUgYXMgc3RyaW5nKVswXX0ke3Zpc2lvblR5cGV9LyR7bGluay5pZH0/ZGVzY3JpcHRpb249JHtzZWFyY2hQYXJhbXMuZ2V0KCdkZXNjcmlwdGlvbicpfWAsXHJcbiAgICAgICAgICB9KSBhcyBJTmF2TGluaykpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF1cclxuICAgIH1cclxuICB9LCBbZGF0YSwgdGVzdElkLCBpc0xvYWRpbmddKVxyXG5cclxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZEdyb3VwOiBJTmF2TGlua0dyb3VwW10gPSBuYXZMaW5rR3JvdXBzID8gWy4uLm5hdkxpbmtHcm91cHNdIDogW11cclxuICAgIGZpbHRlcmVkR3JvdXAuZm9yRWFjaCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgIGZpbHRlcmVkR3JvdXBbaW5kZXhdLmxpbmtzID0gZ3JvdXAubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gaGFzUGVybWlzc2lvbihuYXZMaW5rLnBlcm1pc3Npb24gYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicpKVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmaWx0ZXJlZEdyb3VwXHJcbiAgfSwgW25hdkxpbmtHcm91cHMsIHRlc3RJZF0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XHJcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxyXG5cclxuICAgICAgbmF2aWdhdGUoYCR7cGF0aG5hbWUuc3BsaXQodmlzaW9uVHlwZSBhcyBzdHJpbmcpWzBdfWRldGFpbHMvJHtpdGVtLmtleX0/ZGVzY3JpcHRpb249JHtzZWFyY2hQYXJhbXMuZ2V0KCdkZXNjcmlwdGlvbicpfWApXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNpZGVNZW51XHJcbiAgICAgIHRpdGxlPXt0ZXN0RGVzY3JpcHRpb259XHJcbiAgICAgIGlzTG9hZGluZz17bG9hZGluZ0F1ZGl0IHx8IGlzTG9hZGluZ31cclxuICAgICAgZGVmYXVsdENvbGxhcHNlZD17ZmFsc2V9XHJcbiAgICAgIGRpc2FibGVkQ29sbGFwc2U9e3RydWV9XHJcbiAgICAgIHN1YnRpdGxlPXtcclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17XHJcbiAgICAgICAgICAgIGAvYWRtaW4vY2xpZW50cy8ke2F1ZGl0Py5jb250cmF0bz8uY2xpZW50ZUlkfS9jb250cmFjdHMvJHtcclxuICAgICAgICAgICAgICBhdWRpdD8uY29udHJhdG8/LmNvbnRyYXRvUHJpbmNpcGFsSWRcclxuICAgICAgICAgICAgICAgID8gYCR7YXVkaXQ/LmNvbnRyYXRvLmNvbnRyYXRvUHJpbmNpcGFsSWR9P3N1YmNvbnRyYWN0PSR7YXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YX1gXHJcbiAgICAgICAgICAgICAgICA6IGF1ZGl0Py5jb250cmF0bz8uaWRcclxuICAgICAgICAgICAgfWBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRhcmdldD1cImJsYW5rXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxyXG4gICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IHNwYWNpbmcubGcsXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogMjAwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLm1kLFxyXG4gICAgICAgICAgICAgICAgJzo6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthdWRpdD8uY29udHJhdG8/Lm5vbWVGYW50YXNpYX0gLSB7Zm9ybWF0UHJvcG9zYWxOdW1iZXIoYXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YSBhcyBzdHJpbmcpfVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgfVxyXG4gICAgICBzZWxlY3RlZEtleT17dGVzdElkfVxyXG4gICAgICBncm91cHM9e3Blcm1pc3Npb25OYXZ9XHJcbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cclxuICAgICAgZ29CYWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2F1ZGl0L2F1ZGl0cy8ke2F1ZGl0SWR9L2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvJHtyZXZpc2lvblR5cGV9LyR7Z3JvdXBUb1Nob3d9LyR7Y29tcGFueUlkfS8ke2NvZGVBY2N9L3Rlc3RzPyZkZXNjcmlwdGlvbj0ke3NlYXJjaFBhcmFtcy5nZXQoJ2Rlc2NyaXB0aW9uJyl9YCl9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRFeGVjdXRpb25UZXN0U2lkZU1lbnVcclxuIl19