export var AuditSituationEnum = /* @__PURE__ */ ((AuditSituationEnum2) => {
  AuditSituationEnum2[AuditSituationEnum2["Pendente"] = 0] = "Pendente";
  AuditSituationEnum2[AuditSituationEnum2["EmAndamento"] = 1] = "EmAndamento";
  AuditSituationEnum2[AuditSituationEnum2["Finalizado"] = 2] = "Finalizado";
  AuditSituationEnum2[AuditSituationEnum2["Cancelado"] = 3] = "Cancelado";
  AuditSituationEnum2[AuditSituationEnum2["Suspenso"] = 4] = "Suspenso";
  AuditSituationEnum2[AuditSituationEnum2["EmSolicitacao"] = 5] = "EmSolicitacao";
  AuditSituationEnum2[AuditSituationEnum2["Conferencia"] = 6] = "Conferencia";
  AuditSituationEnum2[AuditSituationEnum2["EmLevantamento"] = 7] = "EmLevantamento";
  AuditSituationEnum2[AuditSituationEnum2["Apresentacao"] = 8] = "Apresentacao";
  AuditSituationEnum2[AuditSituationEnum2["Implementacao"] = 9] = "Implementacao";
  AuditSituationEnum2[AuditSituationEnum2["Recorrente"] = 10] = "Recorrente";
  AuditSituationEnum2[AuditSituationEnum2["Faturamento"] = 11] = "Faturamento";
  AuditSituationEnum2[AuditSituationEnum2["AIniciar"] = 12] = "AIniciar";
  AuditSituationEnum2[AuditSituationEnum2["Restituicao"] = 13] = "Restituicao";
  AuditSituationEnum2[AuditSituationEnum2["AcaoJudicial"] = 14] = "AcaoJudicial";
  AuditSituationEnum2[AuditSituationEnum2["StandBy"] = 15] = "StandBy";
  AuditSituationEnum2[AuditSituationEnum2["Planejamento"] = 16] = "Planejamento";
  AuditSituationEnum2[AuditSituationEnum2["Acompanhamento"] = 17] = "Acompanhamento";
  return AuditSituationEnum2;
})(AuditSituationEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkF1ZGl0U2l0dWF0aW9uRW51bS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBBdWRpdFNpdHVhdGlvbkVudW0ge1xuICBQZW5kZW50ZSA9IDAsXG4gIEVtQW5kYW1lbnRvID0gMSxcbiAgRmluYWxpemFkbyA9IDIsXG4gIENhbmNlbGFkbyA9IDMsXG4gIFN1c3BlbnNvID0gNCxcbiAgRW1Tb2xpY2l0YWNhbyA9IDUsXG4gIENvbmZlcmVuY2lhID0gNixcbiAgRW1MZXZhbnRhbWVudG8gPSA3LFxuICBBcHJlc2VudGFjYW8gPSA4LFxuICBJbXBsZW1lbnRhY2FvID0gOSxcbiAgUmVjb3JyZW50ZSA9IDEwLFxuICBGYXR1cmFtZW50byA9IDExLFxuICBBSW5pY2lhciA9IDEyLFxuICBSZXN0aXR1aWNhbyA9IDEzLFxuICBBY2FvSnVkaWNpYWwgPSAxNCxcbiAgU3RhbmRCeSA9IDE1LFxuICBQbGFuZWphbWVudG8gPSAxNixcbiAgQWNvbXBhbmhhbWVudG8gPSAxNyxcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQU8sV0FBSyxxQkFBTCxrQkFBS0Esd0JBQUw7QUFDTCxFQUFBQSx3Q0FBQSxjQUFXLEtBQVg7QUFDQSxFQUFBQSx3Q0FBQSxpQkFBYyxLQUFkO0FBQ0EsRUFBQUEsd0NBQUEsZ0JBQWEsS0FBYjtBQUNBLEVBQUFBLHdDQUFBLGVBQVksS0FBWjtBQUNBLEVBQUFBLHdDQUFBLGNBQVcsS0FBWDtBQUNBLEVBQUFBLHdDQUFBLG1CQUFnQixLQUFoQjtBQUNBLEVBQUFBLHdDQUFBLGlCQUFjLEtBQWQ7QUFDQSxFQUFBQSx3Q0FBQSxvQkFBaUIsS0FBakI7QUFDQSxFQUFBQSx3Q0FBQSxrQkFBZSxLQUFmO0FBQ0EsRUFBQUEsd0NBQUEsbUJBQWdCLEtBQWhCO0FBQ0EsRUFBQUEsd0NBQUEsZ0JBQWEsTUFBYjtBQUNBLEVBQUFBLHdDQUFBLGlCQUFjLE1BQWQ7QUFDQSxFQUFBQSx3Q0FBQSxjQUFXLE1BQVg7QUFDQSxFQUFBQSx3Q0FBQSxpQkFBYyxNQUFkO0FBQ0EsRUFBQUEsd0NBQUEsa0JBQWUsTUFBZjtBQUNBLEVBQUFBLHdDQUFBLGFBQVUsTUFBVjtBQUNBLEVBQUFBLHdDQUFBLGtCQUFlLE1BQWY7QUFDQSxFQUFBQSx3Q0FBQSxvQkFBaUIsTUFBakI7QUFsQlUsU0FBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbIkF1ZGl0U2l0dWF0aW9uRW51bSJdfQ==