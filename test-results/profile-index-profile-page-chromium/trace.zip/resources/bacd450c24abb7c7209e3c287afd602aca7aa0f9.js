import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/resource/ResourceListActions.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceListActions.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { CommandButton, PrimaryButton } from "/src/shared/components/index.ts?t=1701096626433";
const ResourceListActions = (props) => {
  const {
    disabledRemoveButton,
    onAddClick,
    onRemoveClick,
    deletePermission,
    createPermission
  } = props;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    createPermission && /* @__PURE__ */ jsxDEV(PrimaryButton, { iconProps: {
      iconName: "Add",
      style: {
        fontSize: 14
      }
    }, text: "Adicionar", onClick: onAddClick }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceListActions.tsx",
      lineNumber: 19,
      columnNumber: 28
    }, this),
    deletePermission && /* @__PURE__ */ jsxDEV(CommandButton, { iconProps: {
      iconName: "Trash",
      style: {
        fontSize: 14
      }
    }, text: "Excluir", disabled: disabledRemoveButton, onClick: onRemoveClick }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceListActions.tsx",
      lineNumber: 25,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceListActions.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = ResourceListActions;
export default ResourceListActions;
var _c;
$RefreshReg$(_c, "ResourceListActions");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceListActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0ksbUJBQ3VCLGNBRHZCO0FBZEosMkJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDMUIsU0FBU0EsZUFBZUMscUJBQXFCO0FBVTdDLE1BQU1DLHNCQUFxREMsV0FBVTtBQUNuRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBc0JDO0FBQUFBLElBQVlDO0FBQUFBLElBQWVDO0FBQUFBLElBQWtCQztBQUFBQSxFQUFpQixJQUFJTDtBQUNoRyxTQUNFLG1DQUNHSztBQUFBQSx3QkFBb0IsdUJBQUMsaUJBQ3BCLFdBQVc7QUFBQSxNQUFFQyxVQUFVO0FBQUEsTUFBT0MsT0FBTztBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFHO0FBQUEsSUFBRSxHQUN0RCxNQUFLLGFBQ0wsU0FBU04sY0FIVTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0M7QUFBQSxJQUVyQkUsb0JBQW9CLHVCQUFDLGlCQUNwQixXQUFXO0FBQUEsTUFBRUUsVUFBVTtBQUFBLE1BQVNDLE9BQU87QUFBQSxRQUFFQyxVQUFVO0FBQUEsTUFBRztBQUFBLElBQUUsR0FDeEQsTUFBSyxXQUNMLFVBQVVQLHNCQUNWLFNBQVNFLGlCQUpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJSTtBQUFBLE9BVjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBQUNNLEtBakJLVjtBQW1CTixlQUFlQTtBQUFtQixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29tbWFuZEJ1dHRvbiIsIlByaW1hcnlCdXR0b24iLCJSZXNvdXJjZUxpc3RBY3Rpb25zIiwicHJvcHMiLCJkaXNhYmxlZFJlbW92ZUJ1dHRvbiIsIm9uQWRkQ2xpY2siLCJvblJlbW92ZUNsaWNrIiwiZGVsZXRlUGVybWlzc2lvbiIsImNyZWF0ZVBlcm1pc3Npb24iLCJpY29uTmFtZSIsInN0eWxlIiwiZm9udFNpemUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlc291cmNlTGlzdEFjdGlvbnMudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvcmVzb3VyY2UvUmVzb3VyY2VMaXN0QWN0aW9ucy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQ29tbWFuZEJ1dHRvbiwgUHJpbWFyeUJ1dHRvbiB9IGZyb20gJy4uJ1xuXG5pbnRlcmZhY2UgUmVzb3VyY2VMaXN0QWN0aW9uc1Byb3BzIHtcbiAgZGlzYWJsZWRSZW1vdmVCdXR0b246IGJvb2xlYW5cbiAgb25BZGRDbGljazogKCkgPT4gdm9pZFxuICBvblJlbW92ZUNsaWNrOiAoKSA9PiB2b2lkXG4gIGRlbGV0ZVBlcm1pc3Npb246IGJvb2xlYW5cbiAgY3JlYXRlUGVybWlzc2lvbjogYm9vbGVhblxufVxuXG5jb25zdCBSZXNvdXJjZUxpc3RBY3Rpb25zOiBGQzxSZXNvdXJjZUxpc3RBY3Rpb25zUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgZGlzYWJsZWRSZW1vdmVCdXR0b24sIG9uQWRkQ2xpY2ssIG9uUmVtb3ZlQ2xpY2ssIGRlbGV0ZVBlcm1pc3Npb24sIGNyZWF0ZVBlcm1pc3Npb24gfSA9IHByb3BzXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtjcmVhdGVQZXJtaXNzaW9uICYmIDxQcmltYXJ5QnV0dG9uXG4gICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0FkZCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICAgIHRleHQ9XCJBZGljaW9uYXJcIlxuICAgICAgICBvbkNsaWNrPXtvbkFkZENsaWNrfVxuICAgICAgLz59XG4gICAgICB7ZGVsZXRlUGVybWlzc2lvbiAmJiA8Q29tbWFuZEJ1dHRvblxuICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdUcmFzaCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICAgIHRleHQ9XCJFeGNsdWlyXCJcbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkUmVtb3ZlQnV0dG9ufVxuICAgICAgICBvbkNsaWNrPXtvblJlbW92ZUNsaWNrfVxuICAgICAgLz59XG4gICAgPC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVzb3VyY2VMaXN0QWN0aW9uc1xuIl19