export function formatTextInBoldHTMLString(text) {
  return text.replace(/\*([^*]+?)\*(?!\*)/gm, "<b>$1</b>");
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm1hdFRleHRJbkJvbGRIVE1MU3RyaW5nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBmb3JtYXRUZXh0SW5Cb2xkSFRNTFN0cmluZyAodGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHQucmVwbGFjZSgvXFwqKFteKl0rPylcXCooPyFcXCopL2dtLCAnPGI+JDE8L2I+Jylcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQU8sZ0JBQVMsMkJBQTRCLE1BQXNCO0FBQ2hFLFNBQU8sS0FBSyxRQUFRLHdCQUF3QixXQUFXO0FBQ3pEOyIsIm5hbWVzIjpbXX0=