import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"];
import { ContractSituation } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
import { FlexItem, FlexRow, PageTitle } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { ContractConfigurationContext } from "/src/modules/admin/contracts/context/ContractConfigurationPageContext.ts";
const ContractConfigurationTitle = () => {
  _s();
  const theme = useTheme();
  const {
    client,
    contract
  } = useContext(ContractConfigurationContext);
  if (!client || !contract)
    return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
      lineNumber: 15,
      columnNumber: 36
    }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: client && contract && /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: theme.spacing.lg, children: [
    /* @__PURE__ */ jsxDEV(PageTitle, { children: `${client.nomeFantasia} - Contrato ${formatProposalNumber(contract.numeroProposta)}` }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: contract.situacao !== void 0 && /* @__PURE__ */ jsxDEV(ContractSituation, { situation: contract.situacao }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
      lineNumber: 22,
      columnNumber: 47
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
      lineNumber: 21,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
    lineNumber: 17,
    columnNumber: 28
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_s(ContractConfigurationTitle, "p7jZA2+FSUbEgJYUJosaYx1wrkM=", false, function() {
  return [useTheme];
});
_c = ContractConfigurationTitle;
export default ContractConfigurationTitle;
var _c;
$RefreshReg$(_c, "ContractConfigurationTitle");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationTitle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV21DOzs7Ozs7Ozs7Ozs7Ozs7O0FBWG5DLFNBQWFBLGtCQUFrQjtBQUMvQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsVUFBVUMsU0FBU0MsaUJBQWlCO0FBQzdDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0Msb0NBQW9DO0FBRTdDLE1BQU1DLDZCQUFpQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzNDLFFBQU1DLFFBQVFMLFNBQVM7QUFDdkIsUUFBTTtBQUFBLElBQUVNO0FBQUFBLElBQVFDO0FBQUFBLEVBQVMsSUFBSVosV0FBV08sNEJBQTRCO0FBRXBFLE1BQUksQ0FBQ0ksVUFBVSxDQUFDQztBQUFVLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFFO0FBRW5DLFNBQU8sbUNBQ0pELG9CQUFVQyxZQUNULHVCQUFDLFdBQ0MsZUFBYyxVQUNkLEtBQU1GLE1BQU1HLFFBQVFDLElBRXBCO0FBQUEsMkJBQUMsYUFDRyxhQUFFSCxPQUFPSSwyQkFBMkJULHFCQUFxQk0sU0FBU0ksY0FBYyxPQURwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFlBQ0VKLG1CQUFTSyxhQUFhQyxVQUNyQix1QkFBQyxxQkFBa0IsV0FBV04sU0FBU0ssWUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRCxLQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQSxLQWRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQlA7QUFDRjtBQUFDUixHQXZCS0QsNEJBQThCO0FBQUEsVUFDcEJILFFBQVE7QUFBQTtBQUFBYyxLQURsQlg7QUF5Qk4sZUFBZUE7QUFBMEIsSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNvbnRleHQiLCJDb250cmFjdFNpdHVhdGlvbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsIlBhZ2VUaXRsZSIsInVzZVRoZW1lIiwiZm9ybWF0UHJvcG9zYWxOdW1iZXIiLCJDb250cmFjdENvbmZpZ3VyYXRpb25Db250ZXh0IiwiQ29udHJhY3RDb25maWd1cmF0aW9uVGl0bGUiLCJfcyIsInRoZW1lIiwiY2xpZW50IiwiY29udHJhY3QiLCJzcGFjaW5nIiwibGciLCJub21lRmFudGFzaWEiLCJudW1lcm9Qcm9wb3N0YSIsInNpdHVhY2FvIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cmFjdENvbmZpZ3VyYXRpb25UaXRsZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0Q29uZmlndXJhdGlvblRpdGxlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDb250cmFjdFNpdHVhdGlvbiB9IGZyb20gJy4nXG5pbXBvcnQgeyBGbGV4SXRlbSwgRmxleFJvdywgUGFnZVRpdGxlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xuaW1wb3J0IHsgQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvQ29udHJhY3RDb25maWd1cmF0aW9uUGFnZUNvbnRleHQnXG5cbmNvbnN0IENvbnRyYWN0Q29uZmlndXJhdGlvblRpdGxlOiBGQyA9ICgpID0+IHtcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXG4gIGNvbnN0IHsgY2xpZW50LCBjb250cmFjdCB9ID0gdXNlQ29udGV4dChDb250cmFjdENvbmZpZ3VyYXRpb25Db250ZXh0KVxuXG4gIGlmICghY2xpZW50IHx8ICFjb250cmFjdCkgcmV0dXJuIDw+PC8+XG5cbiAgcmV0dXJuIDw+XG4gICAge2NsaWVudCAmJiBjb250cmFjdCAmJiAoXG4gICAgICA8RmxleFJvd1xuICAgICAgICB2ZXJ0aWNhbEFsaWduPVwiY2VudGVyXCJcbiAgICAgICAgZ2FwPXsgdGhlbWUuc3BhY2luZy5sZyB9XG4gICAgICA+XG4gICAgICAgIDxQYWdlVGl0bGU+XG4gICAgICAgICAge2Ake2NsaWVudC5ub21lRmFudGFzaWF9IC0gQ29udHJhdG8gJHtmb3JtYXRQcm9wb3NhbE51bWJlcihjb250cmFjdC5udW1lcm9Qcm9wb3N0YSl9YH1cbiAgICAgICAgPC9QYWdlVGl0bGU+XG4gICAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgICB7Y29udHJhY3Quc2l0dWFjYW8gIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgICAgICA8Q29udHJhY3RTaXR1YXRpb24gc2l0dWF0aW9uPXtjb250cmFjdC5zaXR1YWNhb30gLz5cbiAgICAgICAgICApfVxuICAgICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPC9GbGV4Um93PlxuICAgICl9XG4gIDwvPlxufVxuXG5leHBvcnQgZGVmYXVsdCBDb250cmFjdENvbmZpZ3VyYXRpb25UaXRsZVxuIl19