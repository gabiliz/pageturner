import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/TaxRegimeDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TaxRegimeDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TaxRegimeEnum } from "/src/shared/enums/TaxRegimeEnum.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const TaxRegimeDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Regime de tributação", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione o regime de tributação", styles: {
    root: {
      minWidth: 100
    }
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TaxRegimeDropdown.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = TaxRegimeDropdown;
const months = [{
  key: TaxRegimeEnum.SIMPLES,
  text: "Simples"
}, {
  key: TaxRegimeEnum.LUCRO_REAL,
  text: "Lucro real"
}, {
  key: TaxRegimeEnum.LUCRO_PRESUMIDO,
  text: "Lucro presumido"
}];
export default TaxRegimeDropdown;
var _c;
$RefreshReg$(_c, "TaxRegimeDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/TaxRegimeDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsb0JBQWtEQyxXQUFVO0FBQ2hFLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLHdCQUNOLFNBQVNDLFFBQ1QsZUFBZSxNQUNmLGNBQWEsTUFDYixhQUFZLG9DQUNaLFFBQVE7QUFBQSxJQUNOQyxNQUFNO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQUk7QUFBQSxFQUN4QixHQUNBLEdBQUlILFNBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNZO0FBR2hCO0FBQUNJLEtBZEtMO0FBZ0JOLE1BQU1FLFNBQTRCLENBQ2hDO0FBQUEsRUFBRUksS0FBS1IsY0FBY1M7QUFBQUEsRUFBU0MsTUFBTTtBQUFVLEdBQzlDO0FBQUEsRUFBRUYsS0FBS1IsY0FBY1c7QUFBQUEsRUFBWUQsTUFBTTtBQUFhLEdBQ3BEO0FBQUEsRUFBRUYsS0FBS1IsY0FBY1k7QUFBQUEsRUFBaUJGLE1BQU07QUFBa0IsQ0FBQztBQUdqRSxlQUFlUjtBQUFpQixJQUFBSztBQUFBTSxhQUFBTixJQUFBIiwibmFtZXMiOlsiSUNvbWJvQm94UHJvcHMiLCJUYXhSZWdpbWVFbnVtIiwiQ29tYm9Cb3giLCJUYXhSZWdpbWVEcm9wZG93biIsInByb3BzIiwibW9udGhzIiwicm9vdCIsIm1pbldpZHRoIiwiX2MiLCJrZXkiLCJTSU1QTEVTIiwidGV4dCIsIkxVQ1JPX1JFQUwiLCJMVUNST19QUkVTVU1JRE8iLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUYXhSZWdpbWVEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kcm9wZG93bnNDb21ib0JveGVzL1RheFJlZ2ltZURyb3Bkb3duLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIElDb21ib0JveE9wdGlvbixcbiAgSUNvbWJvQm94UHJvcHMsXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBUYXhSZWdpbWVFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvVGF4UmVnaW1lRW51bSdcbmltcG9ydCB7IENvbWJvQm94IH0gZnJvbSAnLi4vY29tYm9Cb3gnXG5cbmNvbnN0IFRheFJlZ2ltZURyb3Bkb3duOiBGQzxQYXJ0aWFsPElDb21ib0JveFByb3BzPj4gPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q29tYm9Cb3hcbiAgICAgIGxhYmVsPVwiUmVnaW1lIGRlIHRyaWJ1dGHDp8Ojb1wiXG4gICAgICBvcHRpb25zPXttb250aHN9XG4gICAgICBhbGxvd0ZyZWVmb3JtPXt0cnVlfVxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcbiAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNpb25lIG8gcmVnaW1lIGRlIHRyaWJ1dGHDp8Ojb1wiXG4gICAgICBzdHlsZXM9e3tcbiAgICAgICAgcm9vdDogeyBtaW5XaWR0aDogMTAwIH0sXG4gICAgICB9fVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgbW9udGhzOiBJQ29tYm9Cb3hPcHRpb25bXSA9IFtcbiAgeyBrZXk6IFRheFJlZ2ltZUVudW0uU0lNUExFUywgdGV4dDogJ1NpbXBsZXMnIH0sXG4gIHsga2V5OiBUYXhSZWdpbWVFbnVtLkxVQ1JPX1JFQUwsIHRleHQ6ICdMdWNybyByZWFsJyB9LFxuICB7IGtleTogVGF4UmVnaW1lRW51bS5MVUNST19QUkVTVU1JRE8sIHRleHQ6ICdMdWNybyBwcmVzdW1pZG8nIH0sXG5dXG5cbmV4cG9ydCBkZWZhdWx0IFRheFJlZ2ltZURyb3Bkb3duXG4iXX0=