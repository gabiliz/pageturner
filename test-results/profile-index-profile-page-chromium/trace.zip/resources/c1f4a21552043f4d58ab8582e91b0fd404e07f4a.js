export default function resizeImage(source, maxWidth = 200, quality = 0.9, format = "jpeg") {
  return new Promise((resolve) => {
    let mimeType;
    if (format === "png") {
      mimeType = "image/png";
    } else if (format === "webp") {
      mimeType = "image/webp";
    } else {
      mimeType = "image/jpeg";
    }
    const image = new Image();
    image.src = source;
    image.onload = () => {
      const scale = maxWidth / image.width;
      const canvas = document.createElement("canvas");
      canvas.width = maxWidth;
      canvas.height = image.height * scale;
      canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL(mimeType, quality));
    };
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc2l6ZUltYWdlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlc2l6ZUltYWdlIChcbiAgc291cmNlOiBzdHJpbmcsXG4gIG1heFdpZHRoID0gMjAwLFxuICBxdWFsaXR5ID0gMC45LFxuICBmb3JtYXQgPSAnanBlZycsXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBsZXQgbWltZVR5cGU6IHN0cmluZ1xuICAgIGlmIChmb3JtYXQgPT09ICdwbmcnKSB7XG4gICAgICBtaW1lVHlwZSA9ICdpbWFnZS9wbmcnXG4gICAgfSBlbHNlIGlmIChmb3JtYXQgPT09ICd3ZWJwJykge1xuICAgICAgbWltZVR5cGUgPSAnaW1hZ2Uvd2VicCdcbiAgICB9IGVsc2Uge1xuICAgICAgbWltZVR5cGUgPSAnaW1hZ2UvanBlZydcbiAgICB9XG5cbiAgICBjb25zdCBpbWFnZSA9IG5ldyBJbWFnZSgpXG4gICAgaW1hZ2Uuc3JjID0gc291cmNlXG5cbiAgICBpbWFnZS5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICBjb25zdCBzY2FsZSA9IG1heFdpZHRoIC8gaW1hZ2Uud2lkdGhcblxuICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJylcbiAgICAgIGNhbnZhcy53aWR0aCA9IG1heFdpZHRoXG4gICAgICBjYW52YXMuaGVpZ2h0ID0gaW1hZ2UuaGVpZ2h0ICogc2NhbGVcblxuICAgICAgY2FudmFzLmdldENvbnRleHQoJzJkJyk/LmRyYXdJbWFnZShpbWFnZSwgMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KVxuICAgICAgcmVzb2x2ZShjYW52YXMudG9EYXRhVVJMKG1pbWVUeXBlLCBxdWFsaXR5KSlcbiAgICB9XG4gIH0pXG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixZQUN0QixRQUNBLFdBQVcsS0FDWCxVQUFVLEtBQ1YsU0FBUyxRQUNRO0FBQ2pCLFNBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixRQUFJO0FBQ0osUUFBSSxXQUFXLE9BQU87QUFDcEIsaUJBQVc7QUFBQSxJQUNiLFdBQVcsV0FBVyxRQUFRO0FBQzVCLGlCQUFXO0FBQUEsSUFDYixPQUFPO0FBQ0wsaUJBQVc7QUFBQSxJQUNiO0FBRUEsVUFBTSxRQUFRLElBQUksTUFBTTtBQUN4QixVQUFNLE1BQU07QUFFWixVQUFNLFNBQVMsTUFBTTtBQUNuQixZQUFNLFFBQVEsV0FBVyxNQUFNO0FBRS9CLFlBQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtBQUM5QyxhQUFPLFFBQVE7QUFDZixhQUFPLFNBQVMsTUFBTSxTQUFTO0FBRS9CLGFBQU8sV0FBVyxJQUFJLEdBQUcsVUFBVSxPQUFPLEdBQUcsR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNO0FBQzNFLGNBQVEsT0FBTyxVQUFVLFVBQVUsT0FBTyxDQUFDO0FBQUEsSUFDN0M7QUFBQSxFQUNGLENBQUM7QUFDSDsiLCJuYW1lcyI6W119