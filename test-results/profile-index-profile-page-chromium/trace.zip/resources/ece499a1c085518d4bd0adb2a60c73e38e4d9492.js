import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditControlPanelSideMenu.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { FlexColumn, Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AuditChangeSituation } from "/src/modules/audit/audits/components/index.ts?t=1701096626433";
import { ContractTypeEnum } from "/src/shared/enums/ContractTypeEnum.ts";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { AuditApprovalSituationEnum } from "/src/modules/audit/audits/enums/index.ts";
const AuditControlPanelSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel`;
  const isDisabledTabs = useMemo(() => {
    switch (audit?.situacaoAprovacao) {
      case AuditApprovalSituationEnum.PENDING:
      case AuditApprovalSituationEnum.IN_PROGRESS:
        return true;
    }
    return audit?.situacao === AuditSituationEnum.Cancelado;
  }, [audit?.situacao, audit?.situacaoAprovacao]);
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: isDisabledTabs,
      icon: "ViewDashboard",
      key: "opinion",
      title: "Dashboard de opinião",
      name: "Dashboard de opinião",
      permission: "Auditoria",
      url: `${path}/opinion`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "BIDashboard",
      key: "dashboard",
      title: "Dashboard de testes",
      name: "Dashboard de testes",
      permission: "Auditoria",
      url: `${path}/dashboard`
    }, {
      disabled: isDisabledTabs,
      icon: "CalendarDay",
      key: "planning",
      title: "Planejamento",
      name: "Planejamento",
      permission: "Auditoria",
      url: `${path}/planning/parameters`
    }, {
      disabled: isDisabledTabs,
      icon: "Group",
      key: "team-communication",
      title: "Comunicação com a equipe",
      name: "Comunicação com a equipe",
      permission: "Auditoria",
      url: `${path}/communication/adjustment-ballot`
    }, {
      disabled: isDisabledTabs,
      icon: "Communications",
      key: "client-communication",
      title: "Comunicação com o cliente",
      name: "Comunicação com o cliente",
      permission: "Auditoria",
      url: `${path}/test-process/client-communication`
    }, {
      disabled: isDisabledTabs,
      icon: "Play",
      key: "analysis",
      title: "Análises contábeis",
      name: "Análises contábeis",
      permission: "Auditoria",
      url: `${path}/analysis/dashboard`
    }, {
      disabled: isDisabledTabs,
      icon: "ClipboardList",
      key: "internal-control",
      title: "Controles internos",
      name: "Controles internos",
      permission: "Auditoria",
      url: `${path}/internal-control/commercial`
    }, {
      disabled: isDisabledTabs,
      icon: "Person-note",
      key: "specialist-work",
      title: "Trabalho de especialista",
      name: "Trabalho de especialista",
      permission: "Auditoria",
      url: `${path}/test-process/specialist-work`
    }, {
      disabled: isDisabledTabs,
      icon: "Document-table",
      key: "component-revision",
      title: "Revisão de componentes",
      name: "Revisão de componentes",
      permission: "Auditoria",
      url: `${path}/test-process/component-revision`
    }, {
      disabled: isDisabledTabs,
      icon: "Arrow-clockwise",
      key: "operational-continuity",
      title: "Continuidade operacional",
      name: "Continuidade operacional",
      permission: "Auditoria",
      url: `${path}/test-process/operational-continuity`
    }, {
      disabled: isDisabledTabs,
      icon: "Arrow-next",
      key: "subsequent-event",
      title: "Evento subsequente",
      name: "Evento subsequente",
      permission: "Auditoria",
      url: `${path}/test-process/subsequent-event`
    }, {
      disabled: isDisabledTabs,
      icon: "Money-calculator",
      key: "financial-statements",
      title: "Demonstrações financeiras",
      name: "Demonstrações financeiras",
      permission: "Auditoria",
      url: `${path}/test-process/financial-statements`
    }, {
      disabled: isDisabledTabs,
      icon: "Split",
      key: "audit-sampling",
      title: "Amostragem de auditoria",
      name: "Amostragem de auditoria",
      permission: "Auditoria",
      url: `${path}/test-process/audit-sampling`
    }, {
      disabled: isDisabledTabs,
      icon: "Ribbon",
      key: "quality-control",
      title: "Controle de qualidade",
      name: "Controle de qualidade",
      permission: "Auditoria",
      url: `${path}/test-process/quality-control`
    }, {
      disabled: isDisabledTabs,
      icon: "Teamwork",
      key: "societary-acts",
      title: "Análise dos atos societários",
      name: "Análise dos atos societários",
      permission: "Auditoria",
      url: `${path}/test-process/societary-acts`
    }, {
      disabled: isDisabledTabs,
      icon: "Org",
      key: "service-provider-org",
      title: "Entidade que utiliza organização prestadora de serviço",
      name: "Entidade que utiliza organização prestadora de serviço",
      permission: "Auditoria",
      url: `${path}/test-process/service-provider-org`
    }]
  }], [isDisabledTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(SideMenu, { hasErrorWhenDisabled: audit?.situacaoAprovacao === AuditApprovalSituationEnum.ERROR, title: "Projetos", subtitle: /* @__PURE__ */ jsxDEV(FlexColumn, { margin: `0 0 ${spacing.sm} 0`, children: [
    /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        color: colors.gray[600],
        fontWeight: fontWeight.semibold,
        fontSize: fontSize.p14,
        textDecorationColor: colors.gray[600],
        marginLeft: spacing.lg,
        maxWidth: 200,
        marginBottom: spacing.md,
        "::hover": {
          textDecorationColor: colors.gray[600]
        }
      }
    }, block: true, children: audit && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      audit?.contrato?.nomeFantasia,
      " - ",
      formatProposalNumber(audit?.contrato?.numeroProposta)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
      lineNumber: 212,
      columnNumber: 25
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
      lineNumber: 198,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
      lineNumber: 197,
      columnNumber: 11
    }, this),
    auditId && audit?.contrato?.tipoContrato !== ContractTypeEnum.AudDemFin && /* @__PURE__ */ jsxDEV(AuditChangeSituation, { auditId }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
      lineNumber: 217,
      columnNumber: 87
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
    lineNumber: 196,
    columnNumber: 132
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, defaultCollapsed: selectedKey === "opinion", goBack: () => navigate("/audit") }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx",
    lineNumber: 196,
    columnNumber: 10
  }, this);
};
_s(AuditControlPanelSideMenu, "k/qkoxhqDTmExG99ColpdCkMZYc=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditControlPanelSideMenu;
export default AuditControlPanelSideMenu;
var _c;
$RefreshReg$(_c, "AuditControlPanelSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditControlPanelSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd1B5Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXhQekIsU0FBeUJBLFNBQVNDLGdCQUFnQjtBQUVsRCxTQUFTQyxhQUFhQyxhQUFhQyxpQkFBaUI7QUFDcEQsU0FBdUJDLHNCQUFzQjtBQUM3QyxTQUFTQyxZQUFZQyxNQUFNQyxnQkFBZ0I7QUFDM0MsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0Msd0JBQXdCO0FBQ2pDLE9BQU9DLGdDQUFnQztBQUN2QyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msa0NBQWtDO0FBRTNDLE1BQU1DLDRCQUFnQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzFDLFFBQU1DLFdBQVdqQixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFa0I7QUFBQUEsRUFBUyxJQUFJbkIsWUFBWTtBQUNqQyxRQUFNO0FBQUEsSUFBRW9CO0FBQUFBLEVBQWMsSUFBSWpCLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVrQjtBQUFBQSxJQUFRQztBQUFBQSxJQUFTQztBQUFBQSxJQUFZQztBQUFBQSxFQUFTLElBQUlmLFNBQVM7QUFDM0QsUUFBTSxDQUFDZ0IsaUJBQWlCQyxrQkFBa0IsSUFBSTNCLFNBQWtCLEtBQUs7QUFFckUsUUFBTTtBQUFBLElBQUU0QixJQUFJQztBQUFBQSxFQUFRLElBQUkxQixVQUFVO0FBRWxDLFFBQU07QUFBQSxJQUFFMkIsTUFBTUM7QUFBQUEsRUFBTSxJQUFJdkIsa0JBQWtCd0IsV0FBV0gsT0FBaUI7QUFFdEUsUUFBTUksT0FBUSxpQkFBZ0JKO0FBRTlCLFFBQU1LLGlCQUFpQm5DLFFBQVEsTUFBTTtBQUNuQyxZQUFRZ0MsT0FBT0ksbUJBQWlCO0FBQUEsTUFDOUIsS0FBS25CLDJCQUEyQm9CO0FBQUFBLE1BQ2hDLEtBQUtwQiwyQkFBMkJxQjtBQUM5QixlQUFPO0FBQUEsSUFDWDtBQUVBLFdBQU9OLE9BQU9PLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxFQUNoRCxHQUFHLENBQUNSLE9BQU9PLFVBQVVQLE9BQU9JLGlCQUFpQixDQUFDO0FBRTlDLFFBQU1LLGdCQUFpQ3pDLFFBQVEsTUFBTSxDQUNuRDtBQUFBLElBQ0UwQyxPQUFPLENBQ0w7QUFBQSxNQUNFQyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFFVixHQUNBO0FBQUEsTUFDRVMsVUFBVVgsT0FBT08sYUFBYXZCLG1CQUFtQndCO0FBQUFBLE1BQ2pESSxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLEdBQ0E7QUFBQSxNQUNFUyxVQUFVUjtBQUFBQSxNQUNWUyxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsWUFBWTtBQUFBLE1BQ1pDLEtBQU0sR0FBRWY7QUFBQUEsSUFDVixHQUNBO0FBQUEsTUFDRVMsVUFBVVI7QUFBQUEsTUFDVlMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVmO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VTLFVBQVVSO0FBQUFBLE1BQ1ZTLE1BQU07QUFBQSxNQUNOQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxZQUFZO0FBQUEsTUFDWkMsS0FBTSxHQUFFZjtBQUFBQSxJQUNWLENBQUM7QUFBQSxFQUVMLENBQUMsR0FDbUIsQ0FBQ0MsZ0JBQWdCUixlQUFlLENBQUM7QUFFdkQsUUFBTXVCLGdCQUFnQmxELFFBQVEsTUFBTTtBQUNsQyxVQUFNbUQsZ0JBQWlDLENBQUMsR0FBR1YsYUFBYTtBQUN4RFUsa0JBQWNDLFFBQVEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN0Q0gsb0JBQWNHLEtBQUssRUFBRVosUUFBUVcsTUFBTVgsTUFBTWEsT0FBT0MsYUFBV2xDLGNBQWNrQyxRQUFRUixZQUE0QixZQUFZLENBQUM7QUFBQSxJQUM1SCxDQUFDO0FBQ0QsV0FBT0c7QUFBQUEsRUFDVCxHQUFHLENBQUNWLGFBQWEsQ0FBQztBQUVsQixRQUFNZ0IsY0FBY3pELFFBQVEsTUFDMUJlLDJCQUEyQk0sVUFBVTZCLGFBQWEsR0FDcEQsQ0FBQzdCLFVBQVU2QixhQUFhLENBQUM7QUFFekIsUUFBTVEsY0FBY0EsQ0FBQ0MsSUFBaUJDLFNBQW9CO0FBQ3hELFFBQUlELE9BQU9FLFVBQWFELFNBQVNDLFFBQVc7QUFDMUNGLFNBQUdHLGVBQWU7QUFDbEIsVUFBSUYsS0FBS2xCLE9BQU87QUFDZGQsMkJBQW1CLENBQUNELGVBQWU7QUFBQSxNQUNyQyxPQUFPO0FBQ0xQLGlCQUFTd0MsS0FBS1gsR0FBRztBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFlBQ0Msc0JBQXNCakIsT0FBT0ksc0JBQXNCbkIsMkJBQTJCOEMsT0FDOUUsT0FBTSxZQUNOLFVBQ0UsdUJBQUMsY0FDQyxRQUFTLE9BQU12QyxRQUFRd0MsUUFFdkI7QUFBQSwyQkFBQyxRQUNDLE1BQ0csa0JBQWlCaEMsT0FBT2lDLFVBQVVDLHVCQUNqQ2xDLE9BQU9pQyxVQUFVRSxzQkFDWixHQUFFbkMsT0FBT2lDLFNBQVNFLG1DQUFtQ25DLE9BQU9pQyxVQUFVRyxtQkFDdkVwQyxPQUFPaUMsVUFBVXBDLE1BR3pCLFFBQU8sU0FFUCxpQ0FBQyxRQUNDLFFBQVE7QUFBQSxNQUNOd0MsTUFBTTtBQUFBLFFBQ0pDLE9BQU8vQyxPQUFPZ0QsS0FBSyxHQUFHO0FBQUEsUUFDdEI5QyxZQUFZQSxXQUFXK0M7QUFBQUEsUUFDdkI5QyxVQUFVQSxTQUFTK0M7QUFBQUEsUUFDbkJDLHFCQUFxQm5ELE9BQU9nRCxLQUFLLEdBQUc7QUFBQSxRQUNwQ0ksWUFBWW5ELFFBQVFvRDtBQUFBQSxRQUNwQkMsVUFBVTtBQUFBLFFBQ1ZDLGNBQWN0RCxRQUFRdUQ7QUFBQUEsUUFDdEIsV0FBVztBQUFBLFVBQ1RMLHFCQUFxQm5ELE9BQU9nRCxLQUFLLEdBQUc7QUFBQSxRQUN0QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLEdBQ0EsT0FBSyxNQUVKdkMsbUJBQVUsbUNBQ1JBO0FBQUFBLGFBQU9pQyxVQUFVZTtBQUFBQSxNQUFhO0FBQUEsTUFBSXRFLHFCQUFxQnNCLE9BQU9pQyxVQUFVRyxjQUF3QjtBQUFBLFNBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFWCxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBLEtBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQkE7QUFBQSxJQUVFdEMsV0FDQUUsT0FBT2lDLFVBQVVnQixpQkFBaUJuRSxpQkFBaUJvRSxhQUFhLHVCQUFDLHdCQUMvRCxXQUQ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQ25DO0FBQUEsT0F0Q2pDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q0EsR0FFRixRQUFRaEMsZUFDUixhQUFhUSxhQUNiLGFBQ0Esa0JBQWtCRCxnQkFBZ0IsV0FDbEMsUUFBUSxNQUFNckMsU0FBUyxRQUFRLEtBbkRqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbURtQztBQUd2QztBQUFDRCxHQTdQS0QsMkJBQTZCO0FBQUEsVUFDaEJmLGFBQ0lELGFBQ0tHLGdCQUN3Qk0sVUFHMUJQLFdBRUFLLGtCQUFrQndCLFVBQVU7QUFBQTtBQUFBa0QsS0FUaERqRTtBQStQTixlQUFlQTtBQUF5QixJQUFBaUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ1c2VQZXJtaXNzaW9ucyIsIkZsZXhDb2x1bW4iLCJMaW5rIiwiU2lkZU1lbnUiLCJhdWRpdFF1ZXJ5U2VydmljZSIsImZvcm1hdFByb3Bvc2FsTnVtYmVyIiwidXNlVGhlbWUiLCJUZXh0IiwiQXVkaXRDaGFuZ2VTaXR1YXRpb24iLCJDb250cmFjdFR5cGVFbnVtIiwiZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MiLCJBdWRpdFNpdHVhdGlvbkVudW0iLCJBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bSIsIkF1ZGl0Q29udHJvbFBhbmVsU2lkZU1lbnUiLCJfcyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJoYXNQZXJtaXNzaW9uIiwiY29sb3JzIiwic3BhY2luZyIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImlzR3JvdXBFeHBhbmRlZCIsInNldElzR3JvdXBFeHBhbmRlZCIsImlkIiwiYXVkaXRJZCIsImRhdGEiLCJhdWRpdCIsInVzZUZpbmRPbmUiLCJwYXRoIiwiaXNEaXNhYmxlZFRhYnMiLCJzaXR1YWNhb0Fwcm92YWNhbyIsIlBFTkRJTkciLCJJTl9QUk9HUkVTUyIsInNpdHVhY2FvIiwiQ2FuY2VsYWRvIiwibmF2TGlua0dyb3VwcyIsImxpbmtzIiwiZGlzYWJsZWQiLCJpY29uIiwia2V5IiwidGl0bGUiLCJuYW1lIiwicGVybWlzc2lvbiIsInVybCIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXJlZEdyb3VwIiwiZm9yRWFjaCIsImdyb3VwIiwiaW5kZXgiLCJmaWx0ZXIiLCJuYXZMaW5rIiwic2VsZWN0ZWRLZXkiLCJoYW5kbGVDbGljayIsImV2IiwiaXRlbSIsInVuZGVmaW5lZCIsInByZXZlbnREZWZhdWx0IiwiRVJST1IiLCJzbSIsImNvbnRyYXRvIiwiY2xpZW50ZUlkIiwiY29udHJhdG9QcmluY2lwYWxJZCIsIm51bWVyb1Byb3Bvc3RhIiwicm9vdCIsImNvbG9yIiwiZ3JheSIsInNlbWlib2xkIiwicDE0IiwidGV4dERlY29yYXRpb25Db2xvciIsIm1hcmdpbkxlZnQiLCJsZyIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwibWQiLCJub21lRmFudGFzaWEiLCJ0aXBvQ29udHJhdG8iLCJBdWREZW1GaW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0Q29udHJvbFBhbmVsU2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzL0F1ZGl0Q29udHJvbFBhbmVsU2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBJTmF2TGlua0dyb3VwLCBJTmF2TGluayB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC9saWIvTmF2J1xuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBMaW5rLCBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9hdWRpdHMvc2VydmljZXMnXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC91dGlscydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEF1ZGl0Q2hhbmdlU2l0dWF0aW9uIH0gZnJvbSAnLi4vYXVkaXRzL2NvbXBvbmVudHMnXG5pbXBvcnQgeyBDb250cmFjdFR5cGVFbnVtIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2VudW1zL0NvbnRyYWN0VHlwZUVudW0nXG5pbXBvcnQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MgZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzL2dldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzJ1xuaW1wb3J0IHsgQXVkaXRTaXR1YXRpb25FbnVtIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2VudW1zL0F1ZGl0U2l0dWF0aW9uRW51bSdcbmltcG9ydCB7IEF1ZGl0QXBwcm92YWxTaXR1YXRpb25FbnVtIH0gZnJvbSAnLi4vYXVkaXRzL2VudW1zJ1xuXG5jb25zdCBBdWRpdENvbnRyb2xQYW5lbFNpZGVNZW51OiBGQyA9ICgpID0+IHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXG4gIGNvbnN0IHsgY29sb3JzLCBzcGFjaW5nLCBmb250V2VpZ2h0LCBmb250U2l6ZSB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCBbaXNHcm91cEV4cGFuZGVkLCBzZXRJc0dyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXG5cbiAgY29uc3QgeyBpZDogYXVkaXRJZCB9ID0gdXNlUGFyYW1zKClcblxuICBjb25zdCB7IGRhdGE6IGF1ZGl0IH0gPSBhdWRpdFF1ZXJ5U2VydmljZS51c2VGaW5kT25lKGF1ZGl0SWQgYXMgc3RyaW5nKVxuXG4gIGNvbnN0IHBhdGggPSBgL2F1ZGl0L2F1ZGl0cy8ke2F1ZGl0SWR9L2NvbnRyb2wtcGFuZWxgXG5cbiAgY29uc3QgaXNEaXNhYmxlZFRhYnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBzd2l0Y2ggKGF1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhbykge1xuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5QRU5ESU5HOlxuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5JTl9QUk9HUkVTUzpcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG5cbiAgICByZXR1cm4gYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvXG4gIH0sIFthdWRpdD8uc2l0dWFjYW8sIGF1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhb10pXG5cbiAgY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdID0gdXNlTWVtbygoKSA9PiBbXG4gICAge1xuICAgICAgbGlua3M6IFtcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnVmlld0Rhc2hib2FyZCcsXG4gICAgICAgICAga2V5OiAnb3BpbmlvbicsXG4gICAgICAgICAgdGl0bGU6ICdEYXNoYm9hcmQgZGUgb3BpbmnDo28nLFxuICAgICAgICAgIG5hbWU6ICdEYXNoYm9hcmQgZGUgb3BpbmnDo28nLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxuICAgICAgICAgIHVybDogYCR7cGF0aH0vb3BpbmlvbmAsXG5cbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXG4gICAgICAgICAgaWNvbjogJ0JJRGFzaGJvYXJkJyxcbiAgICAgICAgICBrZXk6ICdkYXNoYm9hcmQnLFxuICAgICAgICAgIHRpdGxlOiAnRGFzaGJvYXJkIGRlIHRlc3RlcycsXG4gICAgICAgICAgbmFtZTogJ0Rhc2hib2FyZCBkZSB0ZXN0ZXMnLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxuICAgICAgICAgIHVybDogYCR7cGF0aH0vZGFzaGJvYXJkYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnQ2FsZW5kYXJEYXknLFxuICAgICAgICAgIGtleTogJ3BsYW5uaW5nJyxcbiAgICAgICAgICB0aXRsZTogJ1BsYW5lamFtZW50bycsXG4gICAgICAgICAgbmFtZTogJ1BsYW5lamFtZW50bycsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9wbGFubmluZy9wYXJhbWV0ZXJzYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnR3JvdXAnLFxuICAgICAgICAgIGtleTogJ3RlYW0tY29tbXVuaWNhdGlvbicsXG4gICAgICAgICAgdGl0bGU6ICdDb211bmljYcOnw6NvIGNvbSBhIGVxdWlwZScsXG4gICAgICAgICAgbmFtZTogJ0NvbXVuaWNhw6fDo28gY29tIGEgZXF1aXBlJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2NvbW11bmljYXRpb24vYWRqdXN0bWVudC1iYWxsb3RgLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxuICAgICAgICAgIGljb246ICdDb21tdW5pY2F0aW9ucycsXG4gICAgICAgICAga2V5OiAnY2xpZW50LWNvbW11bmljYXRpb24nLFxuICAgICAgICAgIHRpdGxlOiAnQ29tdW5pY2HDp8OjbyBjb20gbyBjbGllbnRlJyxcbiAgICAgICAgICBuYW1lOiAnQ29tdW5pY2HDp8OjbyBjb20gbyBjbGllbnRlJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3Rlc3QtcHJvY2Vzcy9jbGllbnQtY29tbXVuaWNhdGlvbmAsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXG4gICAgICAgICAgaWNvbjogJ1BsYXknLFxuICAgICAgICAgIGtleTogJ2FuYWx5c2lzJyxcbiAgICAgICAgICB0aXRsZTogJ0Fuw6FsaXNlcyBjb250w6FiZWlzJyxcbiAgICAgICAgICBuYW1lOiAnQW7DoWxpc2VzIGNvbnTDoWJlaXMnLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxuICAgICAgICAgIHVybDogYCR7cGF0aH0vYW5hbHlzaXMvZGFzaGJvYXJkYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnQ2xpcGJvYXJkTGlzdCcsXG4gICAgICAgICAga2V5OiAnaW50ZXJuYWwtY29udHJvbCcsXG4gICAgICAgICAgdGl0bGU6ICdDb250cm9sZXMgaW50ZXJub3MnLFxuICAgICAgICAgIG5hbWU6ICdDb250cm9sZXMgaW50ZXJub3MnLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxuICAgICAgICAgIHVybDogYCR7cGF0aH0vaW50ZXJuYWwtY29udHJvbC9jb21tZXJjaWFsYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnUGVyc29uLW5vdGUnLFxuICAgICAgICAgIGtleTogJ3NwZWNpYWxpc3Qtd29yaycsXG4gICAgICAgICAgdGl0bGU6ICdUcmFiYWxobyBkZSBlc3BlY2lhbGlzdGEnLFxuICAgICAgICAgIG5hbWU6ICdUcmFiYWxobyBkZSBlc3BlY2lhbGlzdGEnLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxuICAgICAgICAgIHVybDogYCR7cGF0aH0vdGVzdC1wcm9jZXNzL3NwZWNpYWxpc3Qtd29ya2AsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXG4gICAgICAgICAgaWNvbjogJ0RvY3VtZW50LXRhYmxlJyxcbiAgICAgICAgICBrZXk6ICdjb21wb25lbnQtcmV2aXNpb24nLFxuICAgICAgICAgIHRpdGxlOiAnUmV2aXPDo28gZGUgY29tcG9uZW50ZXMnLFxuICAgICAgICAgIG5hbWU6ICdSZXZpc8OjbyBkZSBjb21wb25lbnRlcycsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS90ZXN0LXByb2Nlc3MvY29tcG9uZW50LXJldmlzaW9uYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnQXJyb3ctY2xvY2t3aXNlJyxcbiAgICAgICAgICBrZXk6ICdvcGVyYXRpb25hbC1jb250aW51aXR5JyxcbiAgICAgICAgICB0aXRsZTogJ0NvbnRpbnVpZGFkZSBvcGVyYWNpb25hbCcsXG4gICAgICAgICAgbmFtZTogJ0NvbnRpbnVpZGFkZSBvcGVyYWNpb25hbCcsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS90ZXN0LXByb2Nlc3Mvb3BlcmF0aW9uYWwtY29udGludWl0eWAsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXG4gICAgICAgICAgaWNvbjogJ0Fycm93LW5leHQnLFxuICAgICAgICAgIGtleTogJ3N1YnNlcXVlbnQtZXZlbnQnLFxuICAgICAgICAgIHRpdGxlOiAnRXZlbnRvIHN1YnNlcXVlbnRlJyxcbiAgICAgICAgICBuYW1lOiAnRXZlbnRvIHN1YnNlcXVlbnRlJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3Rlc3QtcHJvY2Vzcy9zdWJzZXF1ZW50LWV2ZW50YCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnTW9uZXktY2FsY3VsYXRvcicsXG4gICAgICAgICAga2V5OiAnZmluYW5jaWFsLXN0YXRlbWVudHMnLFxuICAgICAgICAgIHRpdGxlOiAnRGVtb25zdHJhw6fDtWVzIGZpbmFuY2VpcmFzJyxcbiAgICAgICAgICBuYW1lOiAnRGVtb25zdHJhw6fDtWVzIGZpbmFuY2VpcmFzJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3Rlc3QtcHJvY2Vzcy9maW5hbmNpYWwtc3RhdGVtZW50c2AsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXG4gICAgICAgICAgaWNvbjogJ1NwbGl0JyxcbiAgICAgICAgICBrZXk6ICdhdWRpdC1zYW1wbGluZycsXG4gICAgICAgICAgdGl0bGU6ICdBbW9zdHJhZ2VtIGRlIGF1ZGl0b3JpYScsXG4gICAgICAgICAgbmFtZTogJ0Ftb3N0cmFnZW0gZGUgYXVkaXRvcmlhJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3Rlc3QtcHJvY2Vzcy9hdWRpdC1zYW1wbGluZ2AsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZFRhYnMsXG4gICAgICAgICAgaWNvbjogJ1JpYmJvbicsXG4gICAgICAgICAga2V5OiAncXVhbGl0eS1jb250cm9sJyxcbiAgICAgICAgICB0aXRsZTogJ0NvbnRyb2xlIGRlIHF1YWxpZGFkZScsXG4gICAgICAgICAgbmFtZTogJ0NvbnRyb2xlIGRlIHF1YWxpZGFkZScsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS90ZXN0LXByb2Nlc3MvcXVhbGl0eS1jb250cm9sYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGRpc2FibGVkOiBpc0Rpc2FibGVkVGFicyxcbiAgICAgICAgICBpY29uOiAnVGVhbXdvcmsnLFxuICAgICAgICAgIGtleTogJ3NvY2lldGFyeS1hY3RzJyxcbiAgICAgICAgICB0aXRsZTogJ0Fuw6FsaXNlIGRvcyBhdG9zIHNvY2lldMOhcmlvcycsXG4gICAgICAgICAgbmFtZTogJ0Fuw6FsaXNlIGRvcyBhdG9zIHNvY2lldMOhcmlvcycsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS90ZXN0LXByb2Nlc3Mvc29jaWV0YXJ5LWFjdHNgLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgZGlzYWJsZWQ6IGlzRGlzYWJsZWRUYWJzLFxuICAgICAgICAgIGljb246ICdPcmcnLFxuICAgICAgICAgIGtleTogJ3NlcnZpY2UtcHJvdmlkZXItb3JnJyxcbiAgICAgICAgICB0aXRsZTogJ0VudGlkYWRlIHF1ZSB1dGlsaXphIG9yZ2FuaXphw6fDo28gcHJlc3RhZG9yYSBkZSBzZXJ2acOnbycsXG4gICAgICAgICAgbmFtZTogJ0VudGlkYWRlIHF1ZSB1dGlsaXphIG9yZ2FuaXphw6fDo28gcHJlc3RhZG9yYSBkZSBzZXJ2acOnbycsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS90ZXN0LXByb2Nlc3Mvc2VydmljZS1wcm92aWRlci1vcmdgLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9LFxuICBdIGFzIElOYXZMaW5rR3JvdXBbXSwgW2lzRGlzYWJsZWRUYWJzLCBpc0dyb3VwRXhwYW5kZWRdKVxuXG4gIGNvbnN0IHBlcm1pc3Npb25OYXYgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBmaWx0ZXJlZEdyb3VwOiBJTmF2TGlua0dyb3VwW10gPSBbLi4ubmF2TGlua0dyb3Vwc11cbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyb3VwLCBpbmRleCkgPT4ge1xuICAgICAgZmlsdGVyZWRHcm91cFtpbmRleF0ubGlua3MgPSBncm91cC5saW5rcy5maWx0ZXIobmF2TGluayA9PiBoYXNQZXJtaXNzaW9uKG5hdkxpbmsucGVybWlzc2lvbiBhcyBzZXJ2aWNlQ29kZXMsICdWaXN1YWxpemFyJykpXG4gICAgfSlcbiAgICByZXR1cm4gZmlsdGVyZWRHcm91cFxuICB9LCBbbmF2TGlua0dyb3Vwc10pXG5cbiAgY29uc3Qgc2VsZWN0ZWRLZXkgPSB1c2VNZW1vKCgpID0+XG4gICAgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MocGF0aG5hbWUsIHBlcm1pc3Npb25OYXYpLFxuICBbcGF0aG5hbWUsIHBlcm1pc3Npb25OYXZdKVxuXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XG4gICAgaWYgKGV2ICE9PSB1bmRlZmluZWQgJiYgaXRlbSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICBpZiAoaXRlbS5saW5rcykge1xuICAgICAgICBzZXRJc0dyb3VwRXhwYW5kZWQoIWlzR3JvdXBFeHBhbmRlZClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPFNpZGVNZW51XG4gICAgICBoYXNFcnJvcldoZW5EaXNhYmxlZD17YXVkaXQ/LnNpdHVhY2FvQXByb3ZhY2FvID09PSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5FUlJPUn1cbiAgICAgIHRpdGxlPSdQcm9qZXRvcydcbiAgICAgIHN1YnRpdGxlPXtcbiAgICAgICAgPEZsZXhDb2x1bW5cbiAgICAgICAgICBtYXJnaW49e2AwIDAgJHtzcGFjaW5nLnNtfSAwYH1cbiAgICAgICAgPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICBocmVmPXtcbiAgICAgICAgICAgICAgYC9hZG1pbi9jbGllbnRzLyR7YXVkaXQ/LmNvbnRyYXRvPy5jbGllbnRlSWR9L2NvbnRyYWN0cy8ke1xuICAgICAgICAgICAgICAgIGF1ZGl0Py5jb250cmF0bz8uY29udHJhdG9QcmluY2lwYWxJZFxuICAgICAgICAgICAgICAgICAgPyBgJHthdWRpdD8uY29udHJhdG8uY29udHJhdG9QcmluY2lwYWxJZH0/c3ViY29udHJhY3Q9JHthdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhfWBcbiAgICAgICAgICAgICAgICAgIDogYXVkaXQ/LmNvbnRyYXRvPy5pZFxuICAgICAgICAgICAgICB9YFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFyZ2V0PVwiYmxhbmtcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUZXh0XG4gICAgICAgICAgICAgIHN0eWxlcz17e1xuICAgICAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXG4gICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcbiAgICAgICAgICAgICAgICAgIG1heFdpZHRoOiAyMDAsXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXG4gICAgICAgICAgICAgICAgICAnOjpob3Zlcic6IHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2F1ZGl0ICYmICg8PlxuICAgICAgICAgICAgICAgIHthdWRpdD8uY29udHJhdG8/Lm5vbWVGYW50YXNpYX0gLSB7Zm9ybWF0UHJvcG9zYWxOdW1iZXIoYXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YSBhcyBzdHJpbmcpfVxuICAgICAgICAgICAgICA8Lz4pfVxuICAgICAgICAgICAgPC9UZXh0PlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICB7XG4gICAgICAgICAgICBhdWRpdElkICYmXG4gICAgICAgICAgICBhdWRpdD8uY29udHJhdG8/LnRpcG9Db250cmF0byAhPT0gQ29udHJhY3RUeXBlRW51bS5BdWREZW1GaW4gJiYgPEF1ZGl0Q2hhbmdlU2l0dWF0aW9uXG4gICAgICAgICAgICAgIGF1ZGl0SWQ9e2F1ZGl0SWQgYXMgc3RyaW5nfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICB9XG4gICAgICAgIDwvRmxleENvbHVtbj5cbiAgICAgIH1cbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgIHNlbGVjdGVkS2V5PXtzZWxlY3RlZEtleX1cbiAgICAgIGRlZmF1bHRDb2xsYXBzZWQ9e3NlbGVjdGVkS2V5ID09PSAnb3Bpbmlvbid9XG4gICAgICBnb0JhY2s9eygpID0+IG5hdmlnYXRlKCcvYXVkaXQnKX1cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEF1ZGl0Q29udHJvbFBhbmVsU2lkZU1lbnVcbiJdfQ==