import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractSituation.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractSituation.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyles, FontWeights, FontSizes } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const memo = __vite__cjsImport4_react["memo"];
import { useTagsColors } from "/src/shared/hooks/index.ts";
const ContractSituation = (props) => {
  _s();
  const styles = useStyles(props);
  return /* @__PURE__ */ jsxDEV("div", { className: styles, children: SITUATION[props.situation] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractSituation.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(ContractSituation, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = ContractSituation;
const useStyles = (props) => {
  _s2();
  const {
    background,
    color
  } = useTagsColors(props.situation, ListTags);
  return mergeStyles({
    display: "inline-block",
    whiteSpace: "nowrap",
    fontSize: FontSizes.mini,
    fontWeight: FontWeights.semibold,
    backgroundColor: background,
    color,
    padding: "6px 8px",
    borderRadius: "4px"
  });
};
_s2(useStyles, "yAqk/mHsCk1OPWDYazbBUeiAsGM=", false, function() {
  return [useTagsColors];
});
const SITUATION = {
  0: "Pendente aprovação",
  1: "Recusado",
  2: "Em andamento",
  3: "Finalizado",
  4: "Cancelado",
  5: "Suspenso",
  6: "Não gera projeto"
};
const ListTags = [{
  value: 0,
  type: "Pendente"
}, {
  value: 1,
  type: "Recusado"
}, {
  value: 2,
  type: "Andamento"
}, {
  value: 3,
  type: "Concluido"
}, {
  value: 4,
  type: "Cancelado"
}, {
  value: 3,
  type: "Suspenso"
}, {
  value: 6,
  type: "Pendente"
}];
export default _c2 = memo(ContractSituation);
var _c, _c2;
$RefreshReg$(_c, "ContractSituation");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractSituation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFiSixTQUFTQSxhQUFhQyxhQUFhQyxpQkFBaUI7QUFDcEQsU0FBYUMsWUFBWTtBQUN6QixTQUFTQyxxQkFBcUI7QUFROUIsTUFBTUMsb0JBQWlEQyxXQUFVO0FBQUFDLEtBQUE7QUFDL0QsUUFBTUMsU0FBU0MsVUFBVUgsS0FBSztBQUM5QixTQUNFLHVCQUFDLFNBQUksV0FBV0UsUUFBU0Usb0JBQVVKLE1BQU1LLFNBQVMsS0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvRDtBQUV4RDtBQUFDSixHQUxLRixtQkFBNkM7QUFBQSxVQUNsQ0ksU0FBUztBQUFBO0FBQUFHLEtBRHBCUDtBQU9OLE1BQU1JLFlBQVlBLENBQUNILFVBQWtDO0FBQUFPLE1BQUE7QUFDbkQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVlDO0FBQUFBLEVBQU0sSUFBSVgsY0FBY0UsTUFBTUssV0FBV0ssUUFBUTtBQUNyRSxTQUFPaEIsWUFBWTtBQUFBLElBQ2pCaUIsU0FBUztBQUFBLElBQ1RDLFlBQVk7QUFBQSxJQUNaQyxVQUFVakIsVUFBVWtCO0FBQUFBLElBQ3BCQyxZQUFZcEIsWUFBWXFCO0FBQUFBLElBQ3hCQyxpQkFBaUJUO0FBQUFBLElBQ2pCQztBQUFBQSxJQUNBUyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFDSDtBQUFDWixJQVpLSixXQUFTO0FBQUEsVUFDaUJMLGFBQWE7QUFBQTtBQWE3QyxNQUFNTSxZQUFtRDtBQUFBLEVBQ3ZELEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFDTDtBQUVBLE1BQU1NLFdBQVcsQ0FDZjtBQUFBLEVBQ0VVLE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsR0FDQTtBQUFBLEVBQ0VELE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsQ0FBQztBQUdILGVBQUFDLE1BQWV6QixLQUFLRSxpQkFBaUI7QUFBQyxJQUFBTyxJQUFBZ0I7QUFBQUMsYUFBQWpCLElBQUE7QUFBQWlCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlcyIsIkZvbnRXZWlnaHRzIiwiRm9udFNpemVzIiwibWVtbyIsInVzZVRhZ3NDb2xvcnMiLCJDb250cmFjdFNpdHVhdGlvbiIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJTSVRVQVRJT04iLCJzaXR1YXRpb24iLCJfYyIsIl9zMiIsImJhY2tncm91bmQiLCJjb2xvciIsIkxpc3RUYWdzIiwiZGlzcGxheSIsIndoaXRlU3BhY2UiLCJmb250U2l6ZSIsIm1pbmkiLCJmb250V2VpZ2h0Iiwic2VtaWJvbGQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwidmFsdWUiLCJ0eXBlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJhY3RTaXR1YXRpb24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jb250cmFjdHMvY29tcG9uZW50cy9Db250cmFjdFNpdHVhdGlvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtZXJnZVN0eWxlcywgRm9udFdlaWdodHMsIEZvbnRTaXplcyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMsIG1lbW8gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlVGFnc0NvbG9ycyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgVGFnc0NvbXBvc2l0aW9uTW9kdWxlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzL3RhZ3NDb2xvcnMnXHJcbmltcG9ydCB7IENvbnRyYWN0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9Db250cmFjdFNpdHVhdGlvbkVudW0nXHJcblxyXG5pbnRlcmZhY2UgQ29udHJhY3RTaXR1YXRpb25Qcm9wcyB7XHJcbiAgc2l0dWF0aW9uOiBDb250cmFjdFNpdHVhdGlvbkVudW1cclxufVxyXG5cclxuY29uc3QgQ29udHJhY3RTaXR1YXRpb246IEZDPENvbnRyYWN0U2l0dWF0aW9uUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKHByb3BzKVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzfT57U0lUVUFUSU9OW3Byb3BzLnNpdHVhdGlvbl19PC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAocHJvcHM6IENvbnRyYWN0U2l0dWF0aW9uUHJvcHMpID0+IHtcclxuICBjb25zdCB7IGJhY2tncm91bmQsIGNvbG9yIH0gPSB1c2VUYWdzQ29sb3JzKHByb3BzLnNpdHVhdGlvbiwgTGlzdFRhZ3MpXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVzKHtcclxuICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxyXG4gICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXHJcbiAgICBmb250U2l6ZTogRm9udFNpemVzLm1pbmksXHJcbiAgICBmb250V2VpZ2h0OiBGb250V2VpZ2h0cy5zZW1pYm9sZCxcclxuICAgIGJhY2tncm91bmRDb2xvcjogYmFja2dyb3VuZCxcclxuICAgIGNvbG9yOiBjb2xvcixcclxuICAgIHBhZGRpbmc6ICc2cHggOHB4JyxcclxuICAgIGJvcmRlclJhZGl1czogJzRweCcsXHJcbiAgfSlcclxufVxyXG5cclxuY29uc3QgU0lUVUFUSU9OOiBSZWNvcmQ8Q29udHJhY3RTaXR1YXRpb25FbnVtLCBzdHJpbmc+ID0ge1xyXG4gIDA6ICdQZW5kZW50ZSBhcHJvdmHDp8OjbycsXHJcbiAgMTogJ1JlY3VzYWRvJyxcclxuICAyOiAnRW0gYW5kYW1lbnRvJyxcclxuICAzOiAnRmluYWxpemFkbycsXHJcbiAgNDogJ0NhbmNlbGFkbycsXHJcbiAgNTogJ1N1c3BlbnNvJyxcclxuICA2OiAnTsOjbyBnZXJhIHByb2pldG8nLFxyXG59XHJcblxyXG5jb25zdCBMaXN0VGFncyA9IFtcclxuICB7XHJcbiAgICB2YWx1ZTogMCxcclxuICAgIHR5cGU6ICdQZW5kZW50ZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogMSxcclxuICAgIHR5cGU6ICdSZWN1c2FkbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogMixcclxuICAgIHR5cGU6ICdBbmRhbWVudG8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IDMsXHJcbiAgICB0eXBlOiAnQ29uY2x1aWRvJyxcclxuICB9LFxyXG4gIHtcclxuICAgIHZhbHVlOiA0LFxyXG4gICAgdHlwZTogJ0NhbmNlbGFkbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogMyxcclxuICAgIHR5cGU6ICdTdXNwZW5zbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogNixcclxuICAgIHR5cGU6ICdQZW5kZW50ZScsXHJcbiAgfSxcclxuXSBhcyBUYWdzQ29tcG9zaXRpb25Nb2R1bGVbXVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbWVtbyhDb250cmFjdFNpdHVhdGlvbilcclxuIl19