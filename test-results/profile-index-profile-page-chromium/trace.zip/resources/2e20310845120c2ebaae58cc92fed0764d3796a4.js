import {
  buildForAccountList,
  buildForBoolean,
  buildForCompanyName,
  buildForDate,
  buildForHasRestriction,
  buildForId,
  buildForLate,
  buildForManyIds,
  buildForManyString,
  buildForManyUserNames,
  buildForNumber,
  buildForRecordManyKeys,
  buildForString
} from "/src/shared/utils/buildQueryFilter/queries.ts";
export default function buildQueryFilterGroup(filterGroups) {
  if (!filterGroups)
    return void 0;
  const activeFilterItems = filterGroups.filter(
    (filterGroup) => filterGroup.items.length && filterGroup.queryType !== "none"
  );
  if (!activeFilterItems)
    return void 0;
  return activeFilterItems.map((group) => {
    const field = String(group.field).replaceAll(".", "/");
    const isOrCondition = group.isOr;
    if (group.queryType === "id" && group.items.length === 0) {
      return `${field} eq null`;
    }
    switch (group?.queryType) {
      case "id": {
        return buildForManyIds(field, group.items);
      }
      case "string": {
        return buildForManyString(field, group.items, group.replace);
      }
      case "record": {
        return buildForRecordManyKeys(field, group.items, group?.record);
      }
      case "userObjectList": {
        return buildForManyUserNames(field, group.items);
      }
    }
    const groupItemsQuery = group.items.map(({ text, key }) => {
      const id = key;
      switch (group?.queryType) {
        case "boolean":
          return buildForBoolean(field, key);
        case "number":
          return buildForNumber(field, key);
        case "date":
          return buildForDate(field, text);
        case "listConta":
          return buildForAccountList(field, text);
        case "companyObjList":
          return buildForCompanyName(field, text);
        case "id":
          return group.allItemsSelected ? null : buildForId(field, id);
        case "restriction":
          return buildForHasRestriction(field, text);
        case "late":
          return buildForLate(field, text);
        default:
          return buildForString(field, text, group.replace);
      }
    }).filter((item) => item !== null).join(isOrCondition ? " or " : " and ");
    return !groupItemsQuery ? null : `(${groupItemsQuery})`;
  }).filter((item) => item !== null).join(" and ");
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdyb3VwRmlsdGVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElGaWx0ZXJHcm91cCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvZmlsdGVyL3R5cGVzJ1xuaW1wb3J0IHtcbiAgYnVpbGRGb3JBY2NvdW50TGlzdCxcbiAgYnVpbGRGb3JCb29sZWFuLFxuICBidWlsZEZvckNvbXBhbnlOYW1lLFxuICBidWlsZEZvckRhdGUsXG4gIGJ1aWxkRm9ySGFzUmVzdHJpY3Rpb24sXG4gIGJ1aWxkRm9ySWQsXG4gIGJ1aWxkRm9yTGF0ZSxcbiAgYnVpbGRGb3JNYW55SWRzLFxuICBidWlsZEZvck1hbnlTdHJpbmcsXG4gIGJ1aWxkRm9yTWFueVVzZXJOYW1lcyxcbiAgYnVpbGRGb3JOdW1iZXIsXG4gIGJ1aWxkRm9yUmVjb3JkTWFueUtleXMsXG4gIGJ1aWxkRm9yU3RyaW5nLFxufSBmcm9tICcuL3F1ZXJpZXMnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJ1aWxkUXVlcnlGaWx0ZXJHcm91cCAoZmlsdGVyR3JvdXBzOiBJRmlsdGVyR3JvdXBbXSk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmICghZmlsdGVyR3JvdXBzKSByZXR1cm4gdW5kZWZpbmVkXG5cbiAgY29uc3QgYWN0aXZlRmlsdGVySXRlbXMgPSBmaWx0ZXJHcm91cHMuZmlsdGVyKGZpbHRlckdyb3VwID0+XG4gICAgKGZpbHRlckdyb3VwLml0ZW1zLmxlbmd0aCkgJiZcbiAgICBmaWx0ZXJHcm91cC5xdWVyeVR5cGUgIT09ICdub25lJyxcbiAgKVxuICBpZiAoIWFjdGl2ZUZpbHRlckl0ZW1zKSByZXR1cm4gdW5kZWZpbmVkXG5cbiAgcmV0dXJuIGFjdGl2ZUZpbHRlckl0ZW1zLm1hcChncm91cCA9PiB7XG4gICAgY29uc3QgZmllbGQgPSBTdHJpbmcoZ3JvdXAuZmllbGQpLnJlcGxhY2VBbGwoJy4nLCAnLycpXG4gICAgY29uc3QgaXNPckNvbmRpdGlvbiA9IGdyb3VwLmlzT3JcblxuICAgIGlmIChncm91cC5xdWVyeVR5cGUgPT09ICdpZCcgJiYgZ3JvdXAuaXRlbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCR7ZmllbGR9IGVxIG51bGxgXG4gICAgfVxuXG4gICAgc3dpdGNoIChncm91cD8ucXVlcnlUeXBlKSB7XG4gICAgICBjYXNlICdpZCc6IHtcbiAgICAgICAgcmV0dXJuIGJ1aWxkRm9yTWFueUlkcyhmaWVsZCwgZ3JvdXAuaXRlbXMpXG4gICAgICB9XG4gICAgICBjYXNlICdzdHJpbmcnOiB7XG4gICAgICAgIHJldHVybiBidWlsZEZvck1hbnlTdHJpbmcoZmllbGQsIGdyb3VwLml0ZW1zLCBncm91cC5yZXBsYWNlKVxuICAgICAgfVxuICAgICAgY2FzZSAncmVjb3JkJzoge1xuICAgICAgICByZXR1cm4gYnVpbGRGb3JSZWNvcmRNYW55S2V5cyhmaWVsZCwgZ3JvdXAuaXRlbXMsIGdyb3VwPy5yZWNvcmQpXG4gICAgICB9XG4gICAgICBjYXNlICd1c2VyT2JqZWN0TGlzdCc6IHtcbiAgICAgICAgcmV0dXJuIGJ1aWxkRm9yTWFueVVzZXJOYW1lcyhmaWVsZCwgZ3JvdXAuaXRlbXMpXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgZ3JvdXBJdGVtc1F1ZXJ5ID0gZ3JvdXAuaXRlbXMubWFwKCh7IHRleHQsIGtleSB9KSA9PiB7XG4gICAgICBjb25zdCBpZCA9IGtleVxuXG4gICAgICBzd2l0Y2ggKGdyb3VwPy5xdWVyeVR5cGUpIHtcbiAgICAgICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICAgICAgcmV0dXJuIGJ1aWxkRm9yQm9vbGVhbihmaWVsZCwga2V5KVxuICAgICAgICBjYXNlICdudW1iZXInOlxuICAgICAgICAgIHJldHVybiBidWlsZEZvck51bWJlcihmaWVsZCwga2V5KVxuICAgICAgICBjYXNlICdkYXRlJzpcbiAgICAgICAgICByZXR1cm4gYnVpbGRGb3JEYXRlKGZpZWxkLCB0ZXh0KVxuICAgICAgICBjYXNlICdsaXN0Q29udGEnOlxuICAgICAgICAgIHJldHVybiBidWlsZEZvckFjY291bnRMaXN0KGZpZWxkLCB0ZXh0KVxuICAgICAgICBjYXNlICdjb21wYW55T2JqTGlzdCc6XG4gICAgICAgICAgcmV0dXJuIGJ1aWxkRm9yQ29tcGFueU5hbWUoZmllbGQsIHRleHQpXG4gICAgICAgIGNhc2UgJ2lkJzpcbiAgICAgICAgICByZXR1cm4gZ3JvdXAuYWxsSXRlbXNTZWxlY3RlZFxuICAgICAgICAgICAgPyBudWxsXG4gICAgICAgICAgICA6IGJ1aWxkRm9ySWQoZmllbGQsIGlkKVxuICAgICAgICBjYXNlICdyZXN0cmljdGlvbic6XG4gICAgICAgICAgcmV0dXJuIGJ1aWxkRm9ySGFzUmVzdHJpY3Rpb24oZmllbGQsIHRleHQpXG4gICAgICAgIGNhc2UgJ2xhdGUnOlxuICAgICAgICAgIHJldHVybiBidWlsZEZvckxhdGUoZmllbGQsIHRleHQpXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuIGJ1aWxkRm9yU3RyaW5nKGZpZWxkLCB0ZXh0LCBncm91cC5yZXBsYWNlKVxuICAgICAgfVxuICAgIH0pLmZpbHRlcihpdGVtID0+IGl0ZW0gIT09IG51bGwpLmpvaW4oaXNPckNvbmRpdGlvbiA/ICcgb3IgJyA6ICcgYW5kICcpXG5cbiAgICByZXR1cm4gIWdyb3VwSXRlbXNRdWVyeSA/IG51bGwgOiBgKCR7Z3JvdXBJdGVtc1F1ZXJ5fSlgXG4gIH0pLmZpbHRlcihpdGVtID0+IGl0ZW0gIT09IG51bGwpLmpvaW4oJyBhbmQgJylcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ0E7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUVQLHdCQUF3QixzQkFBdUIsY0FBa0Q7QUFDL0YsTUFBSSxDQUFDO0FBQWMsV0FBTztBQUUxQixRQUFNLG9CQUFvQixhQUFhO0FBQUEsSUFBTyxpQkFDM0MsWUFBWSxNQUFNLFVBQ25CLFlBQVksY0FBYztBQUFBLEVBQzVCO0FBQ0EsTUFBSSxDQUFDO0FBQW1CLFdBQU87QUFFL0IsU0FBTyxrQkFBa0IsSUFBSSxXQUFTO0FBQ3BDLFVBQU0sUUFBUSxPQUFPLE1BQU0sS0FBSyxFQUFFLFdBQVcsS0FBSyxHQUFHO0FBQ3JELFVBQU0sZ0JBQWdCLE1BQU07QUFFNUIsUUFBSSxNQUFNLGNBQWMsUUFBUSxNQUFNLE1BQU0sV0FBVyxHQUFHO0FBQ3hELGFBQU8sR0FBRztBQUFBLElBQ1o7QUFFQSxZQUFRLE9BQU8sV0FBVztBQUFBLE1BQ3hCLEtBQUssTUFBTTtBQUNULGVBQU8sZ0JBQWdCLE9BQU8sTUFBTSxLQUFLO0FBQUEsTUFDM0M7QUFBQSxNQUNBLEtBQUssVUFBVTtBQUNiLGVBQU8sbUJBQW1CLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTztBQUFBLE1BQzdEO0FBQUEsTUFDQSxLQUFLLFVBQVU7QUFDYixlQUFPLHVCQUF1QixPQUFPLE1BQU0sT0FBTyxPQUFPLE1BQU07QUFBQSxNQUNqRTtBQUFBLE1BQ0EsS0FBSyxrQkFBa0I7QUFDckIsZUFBTyxzQkFBc0IsT0FBTyxNQUFNLEtBQUs7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixNQUFNLE1BQU0sSUFBSSxDQUFDLEVBQUUsTUFBTSxJQUFJLE1BQU07QUFDekQsWUFBTSxLQUFLO0FBRVgsY0FBUSxPQUFPLFdBQVc7QUFBQSxRQUN4QixLQUFLO0FBQ0gsaUJBQU8sZ0JBQWdCLE9BQU8sR0FBRztBQUFBLFFBQ25DLEtBQUs7QUFDSCxpQkFBTyxlQUFlLE9BQU8sR0FBRztBQUFBLFFBQ2xDLEtBQUs7QUFDSCxpQkFBTyxhQUFhLE9BQU8sSUFBSTtBQUFBLFFBQ2pDLEtBQUs7QUFDSCxpQkFBTyxvQkFBb0IsT0FBTyxJQUFJO0FBQUEsUUFDeEMsS0FBSztBQUNILGlCQUFPLG9CQUFvQixPQUFPLElBQUk7QUFBQSxRQUN4QyxLQUFLO0FBQ0gsaUJBQU8sTUFBTSxtQkFDVCxPQUNBLFdBQVcsT0FBTyxFQUFFO0FBQUEsUUFDMUIsS0FBSztBQUNILGlCQUFPLHVCQUF1QixPQUFPLElBQUk7QUFBQSxRQUMzQyxLQUFLO0FBQ0gsaUJBQU8sYUFBYSxPQUFPLElBQUk7QUFBQSxRQUNqQztBQUNFLGlCQUFPLGVBQWUsT0FBTyxNQUFNLE1BQU0sT0FBTztBQUFBLE1BQ3BEO0FBQUEsSUFDRixDQUFDLEVBQUUsT0FBTyxVQUFRLFNBQVMsSUFBSSxFQUFFLEtBQUssZ0JBQWdCLFNBQVMsT0FBTztBQUV0RSxXQUFPLENBQUMsa0JBQWtCLE9BQU8sSUFBSTtBQUFBLEVBQ3ZDLENBQUMsRUFBRSxPQUFPLFVBQVEsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQy9DOyIsIm5hbWVzIjpbXX0=