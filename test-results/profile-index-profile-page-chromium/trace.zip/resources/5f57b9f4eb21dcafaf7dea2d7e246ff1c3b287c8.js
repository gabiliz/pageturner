import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/AppBar.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { IconButton, mergeStyleSets, DirectionalHint, Image, Icon } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useMemo = __vite__cjsImport5_react["useMemo"]; const useState = __vite__cjsImport5_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { UserAccountConfigurationModal } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import UserControl from "/src/modules/auth/components/UserControl.tsx?t=1701096626433";
import { authService } from "/src/modules/auth/services/index.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { useTheme } from "/src/shared/hooks/theme.ts";
import { notificationsQueryService } from "/src/shared/services/notificationsServices/index.ts";
import { PrimaryButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import ConfirmLogout from "/src/shared/components/dialog/ConfirmLogout.tsx?t=1701096626433";
import { FlexColumn } from "/src/shared/components/FlexBox/index.ts";
import { ModulesMenu } from "/src/shared/components/modules/index.ts?t=1701096626433";
import { DrawerNotificationsCenter } from "/src/shared/components/notifications/components/index.ts?t=1701096626433";
import { TooltipHost } from "/src/shared/components/tooltip/index.ts";
const AppBar = () => {
  _s();
  const navigate = useNavigate();
  const appBarStyles = useAppBarStyles();
  const auth = authService;
  const {
    currentAccount,
    isAuthenticated
  } = useAuth();
  const [, setImage] = useState(currentAccount.value?.image);
  const [hideConfirmLogout, {
    setTrue: closeConfirmLogout,
    setFalse: openConfirmLogout
  }] = useBoolean(true);
  const [isOpenUserConfig, {
    setTrue: openUserConfig,
    setFalse: closeUserConfig
  }] = useBoolean(false);
  const [isOpenNotficationCenter, {
    setTrue: openNotficationCenter,
    setFalse: closeNotficationCenter
  }] = useBoolean(false);
  const [isOpenSlideMenu, {
    setTrue: openSlideMenu,
    setFalse: closeSlideMenu
  }] = useBoolean(false);
  const {
    data: interval
  } = notificationsQueryService.useFindAllRefetchInterval(1e3 * 60 * 5);
  const countNotifications = useMemo(() => {
    const convertInterval = interval?.value;
    return convertInterval?.filter((notification) => notification.pendente === true).length;
  }, [interval]);
  const logOut = useCallback(async () => {
    try {
      await auth.logout();
      return window.location.reload();
    } catch (error) {
      return window.location.reload();
    }
  }, []);
  const menuProps = {
    items: [{
      key: "configuracao usuario",
      text: "Minhas configurações",
      iconProps: {
        iconName: "PlayerSettings"
      },
      onClick: () => openUserConfig()
    }, {
      key: "sair",
      text: "Sair do sistema",
      iconProps: {
        iconName: "SignOut"
      },
      onClick: () => openConfirmLogout()
    }],
    directionalHint: DirectionalHint.bottomRightEdge
  };
  return /* @__PURE__ */ jsxDEV("div", { className: appBarStyles.container, children: [
    /* @__PURE__ */ jsxDEV("div", { className: appBarStyles.start, children: [
      isAuthenticated && /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
        iconName: "WaffleOffice365"
      }, className: appBarStyles.modulesMenuIcon, onClick: openSlideMenu }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 82,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV(Image, { className: appBarStyles.logo, src: "/logo-white.svg", onClick: () => navigate("/backlog-monitor") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: appBarStyles.middle }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: appBarStyles.end, children: [
      /* @__PURE__ */ jsxDEV(
        IconButton,
        {
          className: appBarStyles.notificationButton,
          onClick: openNotficationCenter,
          onRenderMenuIcon: () => /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 91,
            columnNumber: 63
          }, this),
          onRenderIcon: () => /* @__PURE__ */ jsxDEV(FlexColumn, { verticalAlign: "center", children: [
            /* @__PURE__ */ jsxDEV(Icon, { iconName: "ringer", style: {
              fontSize: 20
            } }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
              lineNumber: 92,
              columnNumber: 15
            }, this),
            countNotifications > 0 && /* @__PURE__ */ jsxDEV("div", { className: appBarStyles.countNotifications }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
              lineNumber: 95,
              columnNumber: 42
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 91,
            columnNumber: 90
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 89,
          columnNumber: 9
        },
        this
      ),
      isAuthenticated && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(TooltipHost, { content: "Abrir documentação", children: /* @__PURE__ */ jsxDEV(IconButton, { className: appBarStyles.documentationButton, iconProps: {
          iconName: "Unknown",
          styles: {
            root: {
              fontSize: 20
            }
          }
        }, onClick: () => window.open("https://auditordocs.martinellilabs.com.br/") }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 99,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(IconButton, { menuProps, onRenderMenuIcon: () => /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 108,
          columnNumber: 69
        }, this), className: appBarStyles.button, onRenderIcon: () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "avatar", children: /* @__PURE__ */ jsxDEV(UserControl, {}, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 110,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 109,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "icone", children: /* @__PURE__ */ jsxDEV(Icon, { iconName: "CollapseMenu" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 113,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
            lineNumber: 112,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 108,
          columnNumber: 128
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
          lineNumber: 108,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 97,
        columnNumber: 29
      }, this),
      !isAuthenticated && /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Entrar", onClick: () => navigate("/") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 117,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV(UserAccountConfigurationModal, { isOpen: isOpenUserConfig, onDismiss: closeUserConfig, setImage }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ConfirmLogout, { hidden: hideConfirmLogout, onDismiss: closeConfirmLogout, onConfirm: logOut }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 119,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ModulesMenu, { isOpen: isOpenSlideMenu, onDismiss: closeSlideMenu }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      isOpenNotficationCenter && /* @__PURE__ */ jsxDEV(DrawerNotificationsCenter, { notifications: interval?.value, isOpen: isOpenNotficationCenter, onDismiss: closeNotficationCenter }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
        lineNumber: 122,
        columnNumber: 37
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx",
    lineNumber: 80,
    columnNumber: 10
  }, this);
};
_s(AppBar, "vyHdvCb1Tp4xUhc039uIYvEqpV0=", false, function() {
  return [useNavigate, useAppBarStyles, useAuth, useBoolean, useBoolean, useBoolean, useBoolean, notificationsQueryService.useFindAllRefetchInterval];
});
_c = AppBar;
const useAppBarStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    container: {
      display: "flex",
      backgroundColor: colors.purple[600],
      color: colors.white,
      padding: "12px 24px"
    },
    start: {
      flex: 1,
      display: "flex",
      alignItems: "center"
    },
    middle: {
      flex: 0,
      display: "flex",
      alignItems: "center"
    },
    end: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: spacing.md,
      "> .ms-layer": {
        display: "none"
      },
      ".icone": {
        display: "none"
      },
      "@media(max-width: 500px)": {
        ".avatar": {
          display: "none"
        },
        ".icone": {
          display: "flex"
        }
      }
    },
    modulesMenuIcon: {
      color: colors.white,
      ":hover": {
        backgroundColor: colors.purple[500],
        color: colors.white
      },
      ":active": {
        backgroundColor: colors.purple[800],
        color: colors.white
      }
    },
    logo: {
      marginLeft: spacing.lg,
      ":hover": {
        cursor: "pointer"
      }
    },
    button: {
      order: 3,
      width: "40px",
      height: "40px",
      color: colors.white,
      backgroundColor: "transparent",
      ":hover": {
        backgroundColor: "transparent",
        color: colors.white
      },
      ":active": {
        backgroundColor: "transparent",
        color: colors.white
      }
    },
    notificationButton: {
      position: "relative",
      order: 2,
      color: colors.white,
      backgroundColor: "transparent",
      ":hover": {
        backgroundColor: colors.purple[500],
        color: colors.white
      },
      ":active": {
        backgroundColor: colors.purple[800],
        color: colors.white,
        "> *": {
          position: "initial"
        }
      }
    },
    countNotifications: {
      position: "absolute",
      top: 5,
      right: 7,
      background: colors.yellow[500],
      height: 8,
      width: 8,
      borderRadius: "50%"
    },
    documentationButton: {
      order: 1,
      color: colors.white,
      ":hover": {
        backgroundColor: colors.purple[500],
        color: colors.white
      },
      ":active": {
        backgroundColor: colors.purple[800],
        color: colors.white
      }
    },
    allNotifications: {
      marginLeft: 10,
      color: colors.blue[800],
      "&:hover": {
        textDecoration: "underline"
      }
    }
  });
};
_s2(useAppBarStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
export default AppBar;
var _c;
$RefreshReg$(_c, "AppBar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/AppBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0Y0QixTQWlCTSxVQWpCTjs7Ozs7Ozs7Ozs7Ozs7OztBQWxGNUIsU0FBU0EsWUFBWUMsZ0JBQXNDQyxpQkFBaUJDLE9BQU9DLFlBQVk7QUFDL0YsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQWFDLGFBQWFDLFNBQVNDLGdCQUFnQjtBQUNuRCxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MscUNBQXFDO0FBQzlDLE9BQU9DLGlCQUFpQjtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLHFCQUFxQjtBQUM5QixPQUFPQyxtQkFBbUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQ0FBaUM7QUFDMUMsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU1DLFNBQWFBLE1BQU07QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXZixZQUFZO0FBQzdCLFFBQU1nQixlQUFlQyxnQkFBZ0I7QUFDckMsUUFBTUMsT0FBT2Y7QUFDYixRQUFNO0FBQUEsSUFBRWdCO0FBQUFBLElBQWdCQztBQUFBQSxFQUFnQixJQUFJaEIsUUFBUTtBQUNwRCxRQUFNLEdBQUdpQixRQUFRLElBQUl0QixTQUFpQm9CLGVBQWVHLE9BQU9DLEtBQWU7QUFFM0UsUUFBTSxDQUNKQyxtQkFDQTtBQUFBLElBQUVDLFNBQVNDO0FBQUFBLElBQW9CQyxVQUFVQztBQUFBQSxFQUFrQixDQUFDLElBQzFEaEMsV0FBVyxJQUFJO0FBRW5CLFFBQU0sQ0FDSmlDLGtCQUNBO0FBQUEsSUFBRUosU0FBU0s7QUFBQUEsSUFBZ0JILFVBQVVJO0FBQUFBLEVBQWdCLENBQUMsSUFDcERuQyxXQUFXLEtBQUs7QUFFcEIsUUFBTSxDQUNKb0MseUJBQ0E7QUFBQSxJQUFFUCxTQUFTUTtBQUFBQSxJQUF1Qk4sVUFBVU87QUFBQUEsRUFBdUIsQ0FBQyxJQUNsRXRDLFdBQVcsS0FBSztBQUVwQixRQUFNLENBQ0p1QyxpQkFDQTtBQUFBLElBQUVWLFNBQVNXO0FBQUFBLElBQWVULFVBQVVVO0FBQUFBLEVBQWUsQ0FBQyxJQUNsRHpDLFdBQVcsS0FBSztBQUVwQixRQUFNO0FBQUEsSUFBRTBDLE1BQU1DO0FBQUFBLEVBQVMsSUFBSWpDLDBCQUEwQmtDLDBCQUEwQixNQUFPLEtBQUssQ0FBQztBQUU1RixRQUFNQyxxQkFBNkIzQyxRQUFRLE1BQU07QUFDL0MsVUFBTTRDLGtCQUFrQkgsVUFBVWpCO0FBQ2xDLFdBQU9vQixpQkFBaUJDLE9BQU9DLGtCQUFnQkEsYUFBYUMsYUFBYSxJQUFJLEVBQUVDO0FBQUFBLEVBQ2pGLEdBQUcsQ0FBQ1AsUUFBUSxDQUFDO0FBRWIsUUFBTVEsU0FBU2xELFlBQVksWUFBWTtBQUNyQyxRQUFJO0FBQ0YsWUFBTXFCLEtBQUs4QixPQUFPO0FBQ2xCLGFBQU9DLE9BQU9DLFNBQVNDLE9BQU87QUFBQSxJQUNoQyxTQUFTQyxPQUFQO0FBQ0EsYUFBT0gsT0FBT0MsU0FBU0MsT0FBTztBQUFBLElBQ2hDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNRSxZQUFrQztBQUFBLElBQ3RDQyxPQUFPLENBQ0w7QUFBQSxNQUNFQyxLQUFLO0FBQUEsTUFDTEMsTUFBTTtBQUFBLE1BQ05DLFdBQVc7QUFBQSxRQUFFQyxVQUFVO0FBQUEsTUFBaUI7QUFBQSxNQUN4Q0MsU0FBU0EsTUFBTTdCLGVBQWU7QUFBQSxJQUNoQyxHQUNBO0FBQUEsTUFDRXlCLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsV0FBVztBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFVO0FBQUEsTUFDakNDLFNBQVNBLE1BQU0vQixrQkFBa0I7QUFBQSxJQUNuQyxDQUFDO0FBQUEsSUFFSGdDLGlCQUFpQm5FLGdCQUFnQm9FO0FBQUFBLEVBQ25DO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVc3QyxhQUFhOEMsV0FDM0I7QUFBQSwyQkFBQyxTQUFJLFdBQVc5QyxhQUFhK0MsT0FDMUIzQztBQUFBQSx5QkFBbUIsdUJBQUMsY0FDbkIsV0FBVztBQUFBLFFBQUVzQyxVQUFVO0FBQUEsTUFBa0IsR0FDekMsV0FBVzFDLGFBQWFnRCxpQkFDeEIsU0FBUzVCLGlCQUhTO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHSztBQUFBLE1BRXpCLHVCQUFDLFNBQ0MsV0FBV3BCLGFBQWFpRCxNQUN4QixLQUFJLG1CQUNKLFNBQVMsTUFBTWxELFNBQVMsa0JBQWtCLEtBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHOEM7QUFBQSxTQVRoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0MsYUFBYWtELFVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUNyQyx1QkFBQyxTQUFJLFdBQVdsRCxhQUFhbUQsS0FDM0I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV25ELGFBQWFvRDtBQUFBQSxVQUV4QixTQUFTbkM7QUFBQUEsVUFDVCxrQkFBa0IsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFFO0FBQUEsVUFDMUIsY0FBYyxNQUNaLHVCQUFDLGNBQVcsZUFBYyxVQUN4QjtBQUFBLG1DQUFDLFFBQ0MsVUFBUyxVQUNULE9BQU87QUFBQSxjQUFFb0MsVUFBVTtBQUFBLFlBQUcsS0FGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFMEI7QUFBQSxZQUV6QjVCLHFCQUFxQixLQUNwQix1QkFBQyxTQUFJLFdBQVd6QixhQUFheUIsc0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsZUFOcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBO0FBQUEsUUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlSTtBQUFBLE1BRUhyQixtQkFBbUIsbUNBQ2xCO0FBQUEsK0JBQUMsZUFDQyxTQUFRLHNCQUVSLGlDQUFDLGNBQ0MsV0FBV0osYUFBYXNELHFCQUN4QixXQUFXO0FBQUEsVUFDVFosVUFBVTtBQUFBLFVBQ1ZhLFFBQVE7QUFBQSxZQUNOQyxNQUFNO0FBQUEsY0FDSkgsVUFBVTtBQUFBLFlBQ1o7QUFBQSxVQUNGO0FBQUEsUUFDRixHQUNBLFNBQVMsTUFBTXBCLE9BQU93QixLQUFLLDRDQUE0QyxLQVZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVTJFLEtBYjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsY0FDQyxXQUNBLGtCQUFrQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRSxHQUMxQixXQUFXekQsYUFBYTBELFFBQ3hCLGNBQWMsTUFDWixtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYixpQ0FBQyxRQUFLLFVBQVMsa0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BLEtBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFJO0FBQUEsV0E5QmM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDcEI7QUFBQSxNQUNDLENBQUN0RCxtQkFBbUIsdUJBQUMsaUJBQ3BCLE1BQUssVUFDTCxTQUFTLE1BQU1MLFNBQVMsR0FBRyxLQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFVTtBQUFBLE1BRS9CLHVCQUFDLGlDQUNDLFFBQVFjLGtCQUNSLFdBQVdFLGlCQUNYLFlBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdxQjtBQUFBLE1BRXJCLHVCQUFDLGlCQUNDLFFBQVFQLG1CQUNSLFdBQVdFLG9CQUNYLFdBQVdxQixVQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHb0I7QUFBQSxNQUVwQix1QkFBQyxlQUNDLFFBQVFaLGlCQUNSLFdBQVdFLGtCQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFNEI7QUFBQSxNQUczQkwsMkJBQ0MsdUJBQUMsNkJBQ0MsZUFBZU8sVUFBVWpCLE9BQ3pCLFFBQVFVLHlCQUNSLFdBQVdFLDBCQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHb0M7QUFBQSxTQTFFeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZFQTtBQUFBLE9BM0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0RkE7QUFFSjtBQUFDcEIsR0E1SktELFFBQVU7QUFBQSxVQUNHYixhQUNJaUIsaUJBRXVCYixTQU14Q1IsWUFLQUEsWUFLQUEsWUFLQUEsWUFFdUJVLDBCQUEwQmtDLHlCQUF5QjtBQUFBO0FBQUFtQyxLQTNCMUU5RDtBQThKTixNQUFNSSxrQkFBa0JBLE1BQU07QUFBQTJELE1BQUE7QUFDNUIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVNDO0FBQUFBLEVBQU8sSUFBSXpFLFNBQVM7QUFFckMsU0FBT2IsZUFBZTtBQUFBLElBQ3BCc0UsV0FBVztBQUFBLE1BQ1RpQixTQUFTO0FBQUEsTUFDVEMsaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsT0FBT0osT0FBT0s7QUFBQUEsTUFDZEMsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBckIsT0FBTztBQUFBLE1BQ0xzQixNQUFNO0FBQUEsTUFDTk4sU0FBUztBQUFBLE1BQ1RPLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQXBCLFFBQVE7QUFBQSxNQUNObUIsTUFBTTtBQUFBLE1BQ05OLFNBQVM7QUFBQSxNQUNUTyxZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0FuQixLQUFLO0FBQUEsTUFDSGtCLE1BQU07QUFBQSxNQUNOTixTQUFTO0FBQUEsTUFDVE8sWUFBWTtBQUFBLE1BQ1pDLGdCQUFnQjtBQUFBLE1BQ2hCQyxLQUFLWCxRQUFRWTtBQUFBQSxNQUNiLGVBQWU7QUFBQSxRQUNiVixTQUFTO0FBQUEsTUFDWDtBQUFBLE1BQ0EsVUFBVTtBQUFBLFFBQ1JBLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQSw0QkFBNEI7QUFBQSxRQUMxQixXQUFXO0FBQUEsVUFBRUEsU0FBUztBQUFBLFFBQU87QUFBQSxRQUM3QixVQUFVO0FBQUEsVUFBRUEsU0FBUztBQUFBLFFBQU87QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFBQSxJQUNBZixpQkFBaUI7QUFBQSxNQUNma0IsT0FBT0osT0FBT0s7QUFBQUEsTUFDZCxVQUFVO0FBQUEsUUFDUkgsaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUNsQ0MsT0FBT0osT0FBT0s7QUFBQUEsTUFDaEI7QUFBQSxNQUNBLFdBQVc7QUFBQSxRQUNUSCxpQkFBaUJGLE9BQU9HLE9BQU8sR0FBRztBQUFBLFFBQ2xDQyxPQUFPSixPQUFPSztBQUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBbEIsTUFBTTtBQUFBLE1BQ0p5QixZQUFZYixRQUFRYztBQUFBQSxNQUNwQixVQUFVO0FBQUEsUUFDUkMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsSUFDQWxCLFFBQVE7QUFBQSxNQUNObUIsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUmIsT0FBT0osT0FBT0s7QUFBQUEsTUFDZEgsaUJBQWlCO0FBQUEsTUFDakIsVUFBVTtBQUFBLFFBQ1JBLGlCQUFpQjtBQUFBLFFBQ2pCRSxPQUFPSixPQUFPSztBQUFBQSxNQUNoQjtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1RILGlCQUFpQjtBQUFBLFFBQ2pCRSxPQUFPSixPQUFPSztBQUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBZixvQkFBb0I7QUFBQSxNQUNsQjRCLFVBQVU7QUFBQSxNQUNWSCxPQUFPO0FBQUEsTUFDUFgsT0FBT0osT0FBT0s7QUFBQUEsTUFDZEgsaUJBQWlCO0FBQUEsTUFDakIsVUFBVTtBQUFBLFFBQ1JBLGlCQUFpQkYsT0FBT0csT0FBTyxHQUFHO0FBQUEsUUFDbENDLE9BQU9KLE9BQU9LO0FBQUFBLE1BQ2hCO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVEgsaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUNsQ0MsT0FBT0osT0FBT0s7QUFBQUEsUUFDZCxPQUFPO0FBQUEsVUFDTGEsVUFBVTtBQUFBLFFBQ1o7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0F2RCxvQkFBb0I7QUFBQSxNQUNsQnVELFVBQVU7QUFBQSxNQUNWQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLFlBQVlyQixPQUFPc0IsT0FBTyxHQUFHO0FBQUEsTUFDN0JMLFFBQVE7QUFBQSxNQUNSRCxPQUFPO0FBQUEsTUFDUE8sY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQS9CLHFCQUFxQjtBQUFBLE1BQ25CdUIsT0FBTztBQUFBLE1BQ1BYLE9BQU9KLE9BQU9LO0FBQUFBLE1BQ2QsVUFBVTtBQUFBLFFBQ1JILGlCQUFpQkYsT0FBT0csT0FBTyxHQUFHO0FBQUEsUUFDbENDLE9BQU9KLE9BQU9LO0FBQUFBLE1BQ2hCO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVEgsaUJBQWlCRixPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUNsQ0MsT0FBT0osT0FBT0s7QUFBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQW1CLGtCQUFrQjtBQUFBLE1BQ2hCWixZQUFZO0FBQUEsTUFDWlIsT0FBT0osT0FBT3lCLEtBQUssR0FBRztBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUQyxnQkFBZ0I7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDNUIsSUFuSEszRCxpQkFBZTtBQUFBLFVBQ1NaLFFBQVE7QUFBQTtBQW9IdEMsZUFBZVE7QUFBTSxJQUFBOEQ7QUFBQThCLGFBQUE5QixJQUFBIiwibmFtZXMiOlsiSWNvbkJ1dHRvbiIsIm1lcmdlU3R5bGVTZXRzIiwiRGlyZWN0aW9uYWxIaW50IiwiSW1hZ2UiLCJJY29uIiwidXNlQm9vbGVhbiIsInVzZUNhbGxiYWNrIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Nb2RhbCIsIlVzZXJDb250cm9sIiwiYXV0aFNlcnZpY2UiLCJ1c2VBdXRoIiwidXNlVGhlbWUiLCJub3RpZmljYXRpb25zUXVlcnlTZXJ2aWNlIiwiUHJpbWFyeUJ1dHRvbiIsIkNvbmZpcm1Mb2dvdXQiLCJGbGV4Q29sdW1uIiwiTW9kdWxlc01lbnUiLCJEcmF3ZXJOb3RpZmljYXRpb25zQ2VudGVyIiwiVG9vbHRpcEhvc3QiLCJBcHBCYXIiLCJfcyIsIm5hdmlnYXRlIiwiYXBwQmFyU3R5bGVzIiwidXNlQXBwQmFyU3R5bGVzIiwiYXV0aCIsImN1cnJlbnRBY2NvdW50IiwiaXNBdXRoZW50aWNhdGVkIiwic2V0SW1hZ2UiLCJ2YWx1ZSIsImltYWdlIiwiaGlkZUNvbmZpcm1Mb2dvdXQiLCJzZXRUcnVlIiwiY2xvc2VDb25maXJtTG9nb3V0Iiwic2V0RmFsc2UiLCJvcGVuQ29uZmlybUxvZ291dCIsImlzT3BlblVzZXJDb25maWciLCJvcGVuVXNlckNvbmZpZyIsImNsb3NlVXNlckNvbmZpZyIsImlzT3Blbk5vdGZpY2F0aW9uQ2VudGVyIiwib3Blbk5vdGZpY2F0aW9uQ2VudGVyIiwiY2xvc2VOb3RmaWNhdGlvbkNlbnRlciIsImlzT3BlblNsaWRlTWVudSIsIm9wZW5TbGlkZU1lbnUiLCJjbG9zZVNsaWRlTWVudSIsImRhdGEiLCJpbnRlcnZhbCIsInVzZUZpbmRBbGxSZWZldGNoSW50ZXJ2YWwiLCJjb3VudE5vdGlmaWNhdGlvbnMiLCJjb252ZXJ0SW50ZXJ2YWwiLCJmaWx0ZXIiLCJub3RpZmljYXRpb24iLCJwZW5kZW50ZSIsImxlbmd0aCIsImxvZ091dCIsImxvZ291dCIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwiZXJyb3IiLCJtZW51UHJvcHMiLCJpdGVtcyIsImtleSIsInRleHQiLCJpY29uUHJvcHMiLCJpY29uTmFtZSIsIm9uQ2xpY2siLCJkaXJlY3Rpb25hbEhpbnQiLCJib3R0b21SaWdodEVkZ2UiLCJjb250YWluZXIiLCJzdGFydCIsIm1vZHVsZXNNZW51SWNvbiIsImxvZ28iLCJtaWRkbGUiLCJlbmQiLCJub3RpZmljYXRpb25CdXR0b24iLCJmb250U2l6ZSIsImRvY3VtZW50YXRpb25CdXR0b24iLCJzdHlsZXMiLCJyb290Iiwib3BlbiIsImJ1dHRvbiIsIl9jIiwiX3MyIiwic3BhY2luZyIsImNvbG9ycyIsImRpc3BsYXkiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJjb2xvciIsIndoaXRlIiwicGFkZGluZyIsImZsZXgiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJnYXAiLCJtZCIsIm1hcmdpbkxlZnQiLCJsZyIsImN1cnNvciIsIm9yZGVyIiwid2lkdGgiLCJoZWlnaHQiLCJwb3NpdGlvbiIsInRvcCIsInJpZ2h0IiwiYmFja2dyb3VuZCIsInllbGxvdyIsImJvcmRlclJhZGl1cyIsImFsbE5vdGlmaWNhdGlvbnMiLCJibHVlIiwidGV4dERlY29yYXRpb24iLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHBCYXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0L0FwcEJhci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJY29uQnV0dG9uLCBtZXJnZVN0eWxlU2V0cywgSUNvbnRleHR1YWxNZW51UHJvcHMsIERpcmVjdGlvbmFsSGludCwgSW1hZ2UsIEljb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VCb29sZWFuIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWhvb2tzJ1xuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IEFwcE5vdGlmaWNhdGlvbiBmcm9tICcuLi8uLi8uLi9kb21haW4vQXBwTm90aWZpY2F0aW9uJ1xuaW1wb3J0IHsgVXNlckFjY291bnRDb25maWd1cmF0aW9uTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMnXG5pbXBvcnQgVXNlckNvbnRyb2wgZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9hdXRoL2NvbXBvbmVudHMvVXNlckNvbnRyb2wnXG5pbXBvcnQgeyBhdXRoU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvYXV0aC9zZXJ2aWNlcydcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2F1dGgvc3RvcmUvYXV0aCdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MvdGhlbWUnXG5pbXBvcnQgeyBub3RpZmljYXRpb25zUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvbm90aWZpY2F0aW9uc1NlcnZpY2VzJ1xuaW1wb3J0IHsgUHJpbWFyeUJ1dHRvbiB9IGZyb20gJy4uL2J1dHRvbnMnXG5pbXBvcnQgQ29uZmlybUxvZ291dCBmcm9tICcuLi9kaWFsb2cvQ29uZmlybUxvZ291dCdcbmltcG9ydCB7IEZsZXhDb2x1bW4gfSBmcm9tICcuLi9GbGV4Qm94J1xuaW1wb3J0IHsgTW9kdWxlc01lbnUgfSBmcm9tICcuLi9tb2R1bGVzJ1xuaW1wb3J0IHsgRHJhd2VyTm90aWZpY2F0aW9uc0NlbnRlciB9IGZyb20gJy4uL25vdGlmaWNhdGlvbnMvY29tcG9uZW50cydcbmltcG9ydCB7IFRvb2x0aXBIb3N0IH0gZnJvbSAnLi4vdG9vbHRpcCdcblxuY29uc3QgQXBwQmFyOiBGQyA9ICgpID0+IHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IGFwcEJhclN0eWxlcyA9IHVzZUFwcEJhclN0eWxlcygpXG4gIGNvbnN0IGF1dGggPSBhdXRoU2VydmljZVxuICBjb25zdCB7IGN1cnJlbnRBY2NvdW50LCBpc0F1dGhlbnRpY2F0ZWQgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbLCBzZXRJbWFnZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KGN1cnJlbnRBY2NvdW50LnZhbHVlPy5pbWFnZSBhcyBzdHJpbmcpXG5cbiAgY29uc3QgW1xuICAgIGhpZGVDb25maXJtTG9nb3V0LFxuICAgIHsgc2V0VHJ1ZTogY2xvc2VDb25maXJtTG9nb3V0LCBzZXRGYWxzZTogb3BlbkNvbmZpcm1Mb2dvdXQgfSxcbiAgXSA9IHVzZUJvb2xlYW4odHJ1ZSlcblxuICBjb25zdCBbXG4gICAgaXNPcGVuVXNlckNvbmZpZyxcbiAgICB7IHNldFRydWU6IG9wZW5Vc2VyQ29uZmlnLCBzZXRGYWxzZTogY2xvc2VVc2VyQ29uZmlnIH0sXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxuXG4gIGNvbnN0IFtcbiAgICBpc09wZW5Ob3RmaWNhdGlvbkNlbnRlcixcbiAgICB7IHNldFRydWU6IG9wZW5Ob3RmaWNhdGlvbkNlbnRlciwgc2V0RmFsc2U6IGNsb3NlTm90ZmljYXRpb25DZW50ZXIgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG5cbiAgY29uc3QgW1xuICAgIGlzT3BlblNsaWRlTWVudSxcbiAgICB7IHNldFRydWU6IG9wZW5TbGlkZU1lbnUsIHNldEZhbHNlOiBjbG9zZVNsaWRlTWVudSB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcblxuICBjb25zdCB7IGRhdGE6IGludGVydmFsIH0gPSBub3RpZmljYXRpb25zUXVlcnlTZXJ2aWNlLnVzZUZpbmRBbGxSZWZldGNoSW50ZXJ2YWwoMTAwMCAqIDYwICogNSlcblxuICBjb25zdCBjb3VudE5vdGlmaWNhdGlvbnM6IG51bWJlciA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IGNvbnZlcnRJbnRlcnZhbCA9IGludGVydmFsPy52YWx1ZSBhcyBBcHBOb3RpZmljYXRpb25bXVxuICAgIHJldHVybiBjb252ZXJ0SW50ZXJ2YWw/LmZpbHRlcihub3RpZmljYXRpb24gPT4gbm90aWZpY2F0aW9uLnBlbmRlbnRlID09PSB0cnVlKS5sZW5ndGggYXMgbnVtYmVyXG4gIH0sIFtpbnRlcnZhbF0pXG5cbiAgY29uc3QgbG9nT3V0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7IC8vIEZJWE1FIFJldGlyYXIgdHJ5L2NhdGNoIHF1YW5kbyBlcnJvIDQwMSBmb3IgdHJhdGFkbyBnbG9iYWxtZW50ZVxuICAgICAgYXdhaXQgYXV0aC5sb2dvdXQoKVxuICAgICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBtZW51UHJvcHM6IElDb250ZXh0dWFsTWVudVByb3BzID0ge1xuICAgIGl0ZW1zOiBbXG4gICAgICB7XG4gICAgICAgIGtleTogJ2NvbmZpZ3VyYWNhbyB1c3VhcmlvJyxcbiAgICAgICAgdGV4dDogJ01pbmhhcyBjb25maWd1cmHDp8O1ZXMnLFxuICAgICAgICBpY29uUHJvcHM6IHsgaWNvbk5hbWU6ICdQbGF5ZXJTZXR0aW5ncycgfSxcbiAgICAgICAgb25DbGljazogKCkgPT4gb3BlblVzZXJDb25maWcoKSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGtleTogJ3NhaXInLFxuICAgICAgICB0ZXh0OiAnU2FpciBkbyBzaXN0ZW1hJyxcbiAgICAgICAgaWNvblByb3BzOiB7IGljb25OYW1lOiAnU2lnbk91dCcgfSxcbiAgICAgICAgb25DbGljazogKCkgPT4gb3BlbkNvbmZpcm1Mb2dvdXQoKSxcbiAgICAgIH0sXG4gICAgXSxcbiAgICBkaXJlY3Rpb25hbEhpbnQ6IERpcmVjdGlvbmFsSGludC5ib3R0b21SaWdodEVkZ2UsXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMuY29udGFpbmVyfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMuc3RhcnR9PlxuICAgICAgICB7aXNBdXRoZW50aWNhdGVkICYmIDxJY29uQnV0dG9uXG4gICAgICAgICAgaWNvblByb3BzPXt7IGljb25OYW1lOiAnV2FmZmxlT2ZmaWNlMzY1JyB9fVxuICAgICAgICAgIGNsYXNzTmFtZT17YXBwQmFyU3R5bGVzLm1vZHVsZXNNZW51SWNvbn1cbiAgICAgICAgICBvbkNsaWNrPXtvcGVuU2xpZGVNZW51fVxuICAgICAgICAvPn1cbiAgICAgICAgPEltYWdlXG4gICAgICAgICAgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMubG9nb31cbiAgICAgICAgICBzcmM9XCIvbG9nby13aGl0ZS5zdmdcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvYmFja2xvZy1tb25pdG9yJyl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMubWlkZGxlfT48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMuZW5kfT5cbiAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICBjbGFzc05hbWU9e2FwcEJhclN0eWxlcy5ub3RpZmljYXRpb25CdXR0b259XG4gICAgICAgICAgLy8gbWVudVByb3BzPXtub3RpZmljYXRpb25zfVxuICAgICAgICAgIG9uQ2xpY2s9e29wZW5Ob3RmaWNhdGlvbkNlbnRlcn1cbiAgICAgICAgICBvblJlbmRlck1lbnVJY29uPXsoKSA9PiA8PjwvPn1cbiAgICAgICAgICBvblJlbmRlckljb249eygpID0+IChcbiAgICAgICAgICAgIDxGbGV4Q29sdW1uIHZlcnRpY2FsQWxpZ249J2NlbnRlcic+XG4gICAgICAgICAgICAgIDxJY29uXG4gICAgICAgICAgICAgICAgaWNvbk5hbWU9J3JpbmdlcidcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogMjAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAge2NvdW50Tm90aWZpY2F0aW9ucyA+IDAgJiZcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YXBwQmFyU3R5bGVzLmNvdW50Tm90aWZpY2F0aW9uc30vPlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L0ZsZXhDb2x1bW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgLz5cbiAgICAgICAge2lzQXV0aGVudGljYXRlZCAmJiA8PlxuICAgICAgICAgIDxUb29sdGlwSG9zdFxuICAgICAgICAgICAgY29udGVudD0nQWJyaXIgZG9jdW1lbnRhw6fDo28nXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXthcHBCYXJTdHlsZXMuZG9jdW1lbnRhdGlvbkJ1dHRvbn1cbiAgICAgICAgICAgICAgaWNvblByb3BzPXt7XG4gICAgICAgICAgICAgICAgaWNvbk5hbWU6ICdVbmtub3duJyxcbiAgICAgICAgICAgICAgICBzdHlsZXM6IHtcbiAgICAgICAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDIwLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cub3BlbignaHR0cHM6Ly9hdWRpdG9yZG9jcy5tYXJ0aW5lbGxpbGFicy5jb20uYnIvJyl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvVG9vbHRpcEhvc3Q+XG4gICAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICAgIG1lbnVQcm9wcz17bWVudVByb3BzfVxuICAgICAgICAgICAgb25SZW5kZXJNZW51SWNvbj17KCkgPT4gPD48Lz59XG4gICAgICAgICAgICBjbGFzc05hbWU9e2FwcEJhclN0eWxlcy5idXR0b259XG4gICAgICAgICAgICBvblJlbmRlckljb249eygpID0+IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nYXZhdGFyJz5cbiAgICAgICAgICAgICAgICAgIDxVc2VyQ29udHJvbCAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvbmVcIj5cbiAgICAgICAgICAgICAgICAgIDxJY29uIGljb25OYW1lPSdDb2xsYXBzZU1lbnUnLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvPn1cbiAgICAgICAgeyFpc0F1dGhlbnRpY2F0ZWQgJiYgPFByaW1hcnlCdXR0b25cbiAgICAgICAgICB0ZXh0PSdFbnRyYXInXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX1cbiAgICAgICAgLz59XG4gICAgICAgIDxVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Nb2RhbFxuICAgICAgICAgIGlzT3Blbj17aXNPcGVuVXNlckNvbmZpZ31cbiAgICAgICAgICBvbkRpc21pc3M9e2Nsb3NlVXNlckNvbmZpZ31cbiAgICAgICAgICBzZXRJbWFnZT17c2V0SW1hZ2V9XG4gICAgICAgIC8+XG4gICAgICAgIDxDb25maXJtTG9nb3V0XG4gICAgICAgICAgaGlkZGVuPXtoaWRlQ29uZmlybUxvZ291dH1cbiAgICAgICAgICBvbkRpc21pc3M9e2Nsb3NlQ29uZmlybUxvZ291dH1cbiAgICAgICAgICBvbkNvbmZpcm09e2xvZ091dH1cbiAgICAgICAgLz5cbiAgICAgICAgPE1vZHVsZXNNZW51XG4gICAgICAgICAgaXNPcGVuPXtpc09wZW5TbGlkZU1lbnV9XG4gICAgICAgICAgb25EaXNtaXNzPXtjbG9zZVNsaWRlTWVudX1cbiAgICAgICAgLz5cblxuICAgICAgICB7aXNPcGVuTm90ZmljYXRpb25DZW50ZXIgJiZcbiAgICAgICAgICA8RHJhd2VyTm90aWZpY2F0aW9uc0NlbnRlclxuICAgICAgICAgICAgbm90aWZpY2F0aW9ucz17aW50ZXJ2YWw/LnZhbHVlIGFzIEFwcE5vdGlmaWNhdGlvbltdfVxuICAgICAgICAgICAgaXNPcGVuPXtpc09wZW5Ob3RmaWNhdGlvbkNlbnRlcn1cbiAgICAgICAgICAgIG9uRGlzbWlzcz17Y2xvc2VOb3RmaWNhdGlvbkNlbnRlcn1cbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5jb25zdCB1c2VBcHBCYXJTdHlsZXMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG5cbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcbiAgICBjb250YWluZXI6IHtcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs2MDBdLFxuICAgICAgY29sb3I6IGNvbG9ycy53aGl0ZSxcbiAgICAgIHBhZGRpbmc6ICcxMnB4IDI0cHgnLFxuICAgIH0sXG4gICAgc3RhcnQ6IHtcbiAgICAgIGZsZXg6IDEsXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICB9LFxuICAgIG1pZGRsZToge1xuICAgICAgZmxleDogMCxcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIH0sXG4gICAgZW5kOiB7XG4gICAgICBmbGV4OiAxLFxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyxcbiAgICAgIGdhcDogc3BhY2luZy5tZCxcbiAgICAgICc+IC5tcy1sYXllcic6IHtcbiAgICAgICAgZGlzcGxheTogJ25vbmUnLFxuICAgICAgfSxcbiAgICAgICcuaWNvbmUnOiB7XG4gICAgICAgIGRpc3BsYXk6ICdub25lJyxcbiAgICAgIH0sXG4gICAgICAnQG1lZGlhKG1heC13aWR0aDogNTAwcHgpJzoge1xuICAgICAgICAnLmF2YXRhcic6IHsgZGlzcGxheTogJ25vbmUnIH0sXG4gICAgICAgICcuaWNvbmUnOiB7IGRpc3BsYXk6ICdmbGV4JyB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIG1vZHVsZXNNZW51SWNvbjoge1xuICAgICAgY29sb3I6IGNvbG9ycy53aGl0ZSxcbiAgICAgICc6aG92ZXInOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxuICAgICAgICBjb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgfSxcbiAgICAgICc6YWN0aXZlJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5wdXJwbGVbODAwXSxcbiAgICAgICAgY29sb3I6IGNvbG9ycy53aGl0ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBsb2dvOiB7XG4gICAgICBtYXJnaW5MZWZ0OiBzcGFjaW5nLmxnLFxuICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICB9LFxuICAgIH0sXG4gICAgYnV0dG9uOiB7XG4gICAgICBvcmRlcjogMyxcbiAgICAgIHdpZHRoOiAnNDBweCcsXG4gICAgICBoZWlnaHQ6ICc0MHB4JyxcbiAgICAgIGNvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICAnOmhvdmVyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgIGNvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICB9LFxuICAgICAgJzphY3RpdmUnOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcbiAgICAgICAgY29sb3I6IGNvbG9ycy53aGl0ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBub3RpZmljYXRpb25CdXR0b246IHtcbiAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgb3JkZXI6IDIsXG4gICAgICBjb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXG4gICAgICAgIGNvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICB9LFxuICAgICAgJzphY3RpdmUnOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxuICAgICAgICBjb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgICAnPiAqJzoge1xuICAgICAgICAgIHBvc2l0aW9uOiAnaW5pdGlhbCcsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgY291bnROb3RpZmljYXRpb25zOiB7XG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIHRvcDogNSxcbiAgICAgIHJpZ2h0OiA3LFxuICAgICAgYmFja2dyb3VuZDogY29sb3JzLnllbGxvd1s1MDBdLFxuICAgICAgaGVpZ2h0OiA4LFxuICAgICAgd2lkdGg6IDgsXG4gICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxuICAgIH0sXG4gICAgZG9jdW1lbnRhdGlvbkJ1dHRvbjoge1xuICAgICAgb3JkZXI6IDEsXG4gICAgICBjb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXG4gICAgICAgIGNvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICB9LFxuICAgICAgJzphY3RpdmUnOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxuICAgICAgICBjb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFsbE5vdGlmaWNhdGlvbnM6IHtcbiAgICAgIG1hcmdpbkxlZnQ6IDEwLFxuICAgICAgY29sb3I6IGNvbG9ycy5ibHVlWzgwMF0sXG4gICAgICAnJjpob3Zlcic6IHtcbiAgICAgICAgdGV4dERlY29yYXRpb246ICd1bmRlcmxpbmUnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBCYXJcbiJdfQ==