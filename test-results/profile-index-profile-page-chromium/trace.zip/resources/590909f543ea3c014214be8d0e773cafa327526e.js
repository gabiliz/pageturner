export function findRecordKeys(record, receivedSearchTerm) {
  if (!record)
    return [];
  const searchTerm = receivedSearchTerm.toUpperCase();
  const objectEntries = Object.entries(record);
  const keyIndex = 0;
  const affirmationIndex = 1;
  const result = objectEntries.filter((object) => object[affirmationIndex].toUpperCase().includes(searchTerm)).map((object) => Number(object[keyIndex].toString().replace(/[^0-9-]/g, "")));
  return result;
}
const WITH_RESTRICTION_TEXT = "com restrição";
const WITHOUT_RESTRICTION_TEXT = "sem restrição";
const LATE_TEXT = "atrasado";
const NOT_LATE_TEXT = "sem atraso";
export function buildForBoolean(field, value) {
  return `${field} eq ${value === "1" ? "true" : "false"}`;
}
export function buildForHasRestriction(field, value) {
  return WITH_RESTRICTION_TEXT.includes(value?.toLowerCase()) && value?.toLowerCase().charAt(0) === "c" ? `${field} eq ${true}` : WITHOUT_RESTRICTION_TEXT.includes(value?.toLowerCase()) && value?.toLowerCase().charAt(0) === "s" ? `${field} eq ${false}` : null;
}
export function buildForLate(field, value) {
  return LATE_TEXT.includes(value?.toLowerCase()) && value?.toLowerCase().charAt(0) === "a" ? `${field} eq ${true}` : NOT_LATE_TEXT.includes(value?.toLowerCase()) && value?.toLowerCase().charAt(0) === "s" ? `${field} eq ${false}` : null;
}
export function buildForUserName(field, value, isEmpty) {
  return isEmpty ? `not ${field}/any()` : `${field}/any(user: contains(user/nome, '${value}'))`;
}
export function buildForAccountList(field, value) {
  return `${field}/any(conta: contains(conta/codConta, '${value}'))`;
}
export function buildForCnpj(field, value, inContract) {
  return `${field}/any(company: contains(company${inContract ? "/empresa" : ""}/cnpj, '${value.replace(/[-./]/gi, "")}'))`;
}
export function buildForCompanyName(field, value, inContract) {
  return `${field}/any(company: contains(company${inContract ? "/empresa" : ""}/razaoSocial, '${value}'))`;
}
export function buildForString(field, value, replace) {
  return `contains(tolower(${field}), tolower('${replace ? replace(value) : value}'))`;
}
export function buildForId(field, id) {
  return id ? `${field} eq ${id}` : null;
}
export function buildForNumber(field, value) {
  const number = Number(value.toString().replace(/[^0-9-]/g, ""));
  return number || number === 0 ? `${field} eq ${number}` : null;
}
export function buildForDate(field, value) {
  let date = value;
  if (value.includes("/"))
    date = value.split("/").reverse().join("-");
  const newDate = new Date(date);
  const isValidDate = date.length === 10 && newDate instanceof Date && !isNaN(newDate.valueOf());
  return isValidDate ? `${field} eq ${date}` : null;
}
const MIN_DIGITS_TO_FIND_RECORD = 1;
export function buildForRecord(field, value, record) {
  if (value.length <= MIN_DIGITS_TO_FIND_RECORD)
    return null;
  let recordKeys = [];
  recordKeys = findRecordKeys(record, value);
  if (recordKeys.length > 0) {
    if (field?.includes("enfoque")) {
      return recordKeys.map((key) => `${field}/any(enf: enf/enfoque eq ${key})`).join(" or ");
    }
    if (field?.includes("afirmacoes")) {
      return recordKeys.map((key) => `${field}/any(aff: aff/afirmacao eq ${key} and aff/ativo eq true)`).join(" or ");
    }
    if (field?.includes("visitas")) {
      return recordKeys.map((key) => `${field}/any(visit: visit/titulo eq ${key})`).join(" or ");
    }
    return recordKeys.map((key) => `${field} eq ${key}`).join(" or ");
  }
  return null;
}
export function buildForRecordManyKeys(field, values, record) {
  const recordKeys = [];
  const emptyValue = values.find((value) => value.key === "");
  const notEmptyValues = values.filter((value) => value.key !== "").map((value) => value.text);
  notEmptyValues.forEach((item) => {
    recordKeys.push(...findRecordKeys(record, item));
  });
  const keys = recordKeys.join(", ");
  if (recordKeys.length > 0) {
    if (field?.includes("enfoque")) {
      return `${field}/any(enf: enf/enfoque in (${keys}))`;
    }
    if (field?.includes("afirmacoes")) {
      return `${field}/any(aff: aff/afirmacao in (${keys}) and aff/ativo eq true)`;
    }
    if (field?.includes("visitas")) {
      return `${field}/any(visit: visit/titulo in (${keys}))`;
    }
    return `${field} in (${keys})`;
  }
  if (!recordKeys.length && emptyValue) {
    if (field?.includes("afirmacoes")) {
      return `${field}/all(aff: aff/ativo eq false)`;
    }
  }
  return null;
}
export function buildForManyUserNames(field, values) {
  const emptyValue = values.find((value) => value.key === "");
  const notEmptyValues = values.filter((value) => value.key !== "").map((value) => `'${value.text}'`).join(", ");
  return `${field}/any(user: user/nome in (${notEmptyValues}))${emptyValue ? ` or not ${field}/any()` : ""}`;
}
export function buildForManyString(field, values, replace) {
  const keys = values.map((value) => replace ? replace(`'${value.text.toLowerCase()}'`) : `'${value.text.toLowerCase()}'`).join(", ");
  return `tolower(${field}) in (${keys})`;
}
export function buildForManyIds(field, ids) {
  const keys = ids.map((value) => `'${value.key}'`).join(", ");
  return `${field} in (${keys})`;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInF1ZXJpZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUZpbHRlckdyb3VwSXRlbSB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvZmlsdGVyL3R5cGVzJ1xuXG5leHBvcnQgZnVuY3Rpb24gZmluZFJlY29yZEtleXMgKHJlY29yZDogUmVjb3JkPHN0cmluZyB8IG51bWJlciB8IHN5bWJvbCwgc3RyaW5nPiB8IHVuZGVmaW5lZCwgcmVjZWl2ZWRTZWFyY2hUZXJtOiBzdHJpbmcpOiBudW1iZXJbXSB7XG4gIGlmICghcmVjb3JkKSByZXR1cm4gW11cbiAgY29uc3Qgc2VhcmNoVGVybSA9IHJlY2VpdmVkU2VhcmNoVGVybS50b1VwcGVyQ2FzZSgpXG4gIGNvbnN0IG9iamVjdEVudHJpZXMgPSBPYmplY3QuZW50cmllcyhyZWNvcmQpXG4gIGNvbnN0IGtleUluZGV4ID0gMFxuICBjb25zdCBhZmZpcm1hdGlvbkluZGV4ID0gMVxuICBjb25zdCByZXN1bHQgPSBvYmplY3RFbnRyaWVzXG4gICAgLmZpbHRlcihvYmplY3QgPT4gb2JqZWN0W2FmZmlybWF0aW9uSW5kZXhdLnRvVXBwZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybSkpXG4gICAgLm1hcChvYmplY3QgPT4gTnVtYmVyKG9iamVjdFtrZXlJbmRleF0udG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS1dL2csICcnKSkpXG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5jb25zdCBXSVRIX1JFU1RSSUNUSU9OX1RFWFQgPSAnY29tIHJlc3RyacOnw6NvJ1xuY29uc3QgV0lUSE9VVF9SRVNUUklDVElPTl9URVhUID0gJ3NlbSByZXN0cmnDp8OjbydcbmNvbnN0IExBVEVfVEVYVCA9ICdhdHJhc2FkbydcbmNvbnN0IE5PVF9MQVRFX1RFWFQgPSAnc2VtIGF0cmFzbydcblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRm9yQm9vbGVhbiAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gYCR7ZmllbGR9IGVxICR7dmFsdWUgPT09ICcxJyA/ICd0cnVlJyA6ICdmYWxzZSd9YFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JIYXNSZXN0cmljdGlvbiAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gV0lUSF9SRVNUUklDVElPTl9URVhULmluY2x1ZGVzKHZhbHVlPy50b0xvd2VyQ2FzZSgpKSAmJiB2YWx1ZT8udG9Mb3dlckNhc2UoKS5jaGFyQXQoMCkgPT09ICdjJ1xuICAgID8gYCR7ZmllbGR9IGVxICR7dHJ1ZX1gXG4gICAgOiBXSVRIT1VUX1JFU1RSSUNUSU9OX1RFWFQuaW5jbHVkZXModmFsdWU/LnRvTG93ZXJDYXNlKCkpICYmIHZhbHVlPy50b0xvd2VyQ2FzZSgpLmNoYXJBdCgwKSA9PT0gJ3MnXG4gICAgICA/IGAke2ZpZWxkfSBlcSAke2ZhbHNlfWBcbiAgICAgIDogbnVsbFxufVxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRm9yTGF0ZSAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gTEFURV9URVhULmluY2x1ZGVzKHZhbHVlPy50b0xvd2VyQ2FzZSgpKSAmJiB2YWx1ZT8udG9Mb3dlckNhc2UoKS5jaGFyQXQoMCkgPT09ICdhJ1xuICAgID8gYCR7ZmllbGR9IGVxICR7dHJ1ZX1gXG4gICAgOiBOT1RfTEFURV9URVhULmluY2x1ZGVzKHZhbHVlPy50b0xvd2VyQ2FzZSgpKSAmJiB2YWx1ZT8udG9Mb3dlckNhc2UoKS5jaGFyQXQoMCkgPT09ICdzJ1xuICAgICAgPyBgJHtmaWVsZH0gZXEgJHtmYWxzZX1gXG4gICAgICA6IG51bGxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRm9yVXNlck5hbWUgKGZpZWxkOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcsIGlzRW1wdHk/OiBib29sZWFuKTogc3RyaW5nIHtcbiAgcmV0dXJuIGlzRW1wdHlcbiAgICA/IGBub3QgJHtmaWVsZH0vYW55KClgXG4gICAgOiBgJHtmaWVsZH0vYW55KHVzZXI6IGNvbnRhaW5zKHVzZXIvbm9tZSwgJyR7dmFsdWV9JykpYFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JBY2NvdW50TGlzdCAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBgJHtmaWVsZH0vYW55KGNvbnRhOiBjb250YWlucyhjb250YS9jb2RDb250YSwgJyR7dmFsdWV9JykpYFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JDbnBqIChmaWVsZDogc3RyaW5nLCB2YWx1ZTogc3RyaW5nLCBpbkNvbnRyYWN0PzogYm9vbGVhbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtmaWVsZH0vYW55KGNvbXBhbnk6IGNvbnRhaW5zKGNvbXBhbnkke2luQ29udHJhY3QgPyAnL2VtcHJlc2EnIDogJyd9L2NucGosICcke3ZhbHVlLnJlcGxhY2UoL1stLi9dL2dpLCAnJyl9JykpYFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JDb21wYW55TmFtZSAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZywgaW5Db250cmFjdD86IGJvb2xlYW4pOiBzdHJpbmcge1xuICByZXR1cm4gYCR7ZmllbGR9L2FueShjb21wYW55OiBjb250YWlucyhjb21wYW55JHtpbkNvbnRyYWN0ID8gJy9lbXByZXNhJyA6ICcnfS9yYXphb1NvY2lhbCwgJyR7dmFsdWV9JykpYFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JTdHJpbmcgKGZpZWxkOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcsIHJlcGxhY2U/OiAodmFsdWU6IHN0cmluZykgPT4gc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBjb250YWlucyh0b2xvd2VyKCR7ZmllbGR9KSwgdG9sb3dlcignJHtyZXBsYWNlID8gcmVwbGFjZSh2YWx1ZSkgOiB2YWx1ZX0nKSlgXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZvcklkIChmaWVsZDogc3RyaW5nLCBpZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIHJldHVybiBpZCA/IGAke2ZpZWxkfSBlcSAke2lkfWAgOiBudWxsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZvck51bWJlciAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBudW1iZXIgPSBOdW1iZXIodmFsdWUudG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS1dL2csICcnKSlcbiAgcmV0dXJuIG51bWJlciB8fCBudW1iZXIgPT09IDAgPyBgJHtmaWVsZH0gZXEgJHtudW1iZXJ9YCA6IG51bGxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRm9yRGF0ZSAoZmllbGQ6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBsZXQgZGF0ZSA9IHZhbHVlXG5cbiAgaWYgKHZhbHVlLmluY2x1ZGVzKCcvJykpIGRhdGUgPSB2YWx1ZS5zcGxpdCgnLycpLnJldmVyc2UoKS5qb2luKCctJylcblxuICBjb25zdCBuZXdEYXRlID0gbmV3IERhdGUoZGF0ZSlcbiAgY29uc3QgaXNWYWxpZERhdGUgPSBkYXRlLmxlbmd0aCA9PT0gMTAgJiYgbmV3RGF0ZSBpbnN0YW5jZW9mIERhdGUgJiYgIWlzTmFOKG5ld0RhdGUudmFsdWVPZigpKVxuXG4gIHJldHVybiBpc1ZhbGlkRGF0ZSA/IGAke2ZpZWxkfSBlcSAke2RhdGV9YCA6IG51bGxcbn1cblxuY29uc3QgTUlOX0RJR0lUU19UT19GSU5EX1JFQ09SRCA9IDFcblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRm9yUmVjb3JkIChmaWVsZDogc3RyaW5nLCB2YWx1ZTogc3RyaW5nLCByZWNvcmQ/OiBSZWNvcmQ8c3RyaW5nIHwgbnVtYmVyIHwgc3ltYm9sLCBzdHJpbmc+KTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh2YWx1ZS5sZW5ndGggPD0gTUlOX0RJR0lUU19UT19GSU5EX1JFQ09SRCkgcmV0dXJuIG51bGxcbiAgbGV0IHJlY29yZEtleXMgPSBbXVxuXG4gIHJlY29yZEtleXMgPSBmaW5kUmVjb3JkS2V5cyhyZWNvcmQsIHZhbHVlKVxuICBpZiAocmVjb3JkS2V5cy5sZW5ndGggPiAwKSB7XG4gICAgaWYgKGZpZWxkPy5pbmNsdWRlcygnZW5mb3F1ZScpKSB7XG4gICAgICByZXR1cm4gcmVjb3JkS2V5c1xuICAgICAgICAubWFwKGtleSA9PiBgJHtmaWVsZH0vYW55KGVuZjogZW5mL2VuZm9xdWUgZXEgJHtrZXl9KWApXG4gICAgICAgIC5qb2luKCcgb3IgJylcbiAgICB9XG4gICAgaWYgKGZpZWxkPy5pbmNsdWRlcygnYWZpcm1hY29lcycpKSB7XG4gICAgICByZXR1cm4gcmVjb3JkS2V5c1xuICAgICAgICAubWFwKGtleSA9PiBgJHtmaWVsZH0vYW55KGFmZjogYWZmL2FmaXJtYWNhbyBlcSAke2tleX0gYW5kIGFmZi9hdGl2byBlcSB0cnVlKWApXG4gICAgICAgIC5qb2luKCcgb3IgJylcbiAgICB9XG4gICAgaWYgKGZpZWxkPy5pbmNsdWRlcygndmlzaXRhcycpKSB7XG4gICAgICByZXR1cm4gcmVjb3JkS2V5c1xuICAgICAgICAubWFwKGtleSA9PiBgJHtmaWVsZH0vYW55KHZpc2l0OiB2aXNpdC90aXR1bG8gZXEgJHtrZXl9KWApXG4gICAgICAgIC5qb2luKCcgb3IgJylcbiAgICB9XG4gICAgcmV0dXJuIHJlY29yZEtleXNcbiAgICAgIC5tYXAoa2V5ID0+IGAke2ZpZWxkfSBlcSAke2tleX1gKVxuICAgICAgLmpvaW4oJyBvciAnKVxuICB9XG4gIHJldHVybiBudWxsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZvclJlY29yZE1hbnlLZXlzIChmaWVsZDogc3RyaW5nLCB2YWx1ZXM6IElGaWx0ZXJHcm91cEl0ZW1bXSwgcmVjb3JkPzogUmVjb3JkPHN0cmluZyB8IG51bWJlciB8IHN5bWJvbCwgc3RyaW5nPik6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCByZWNvcmRLZXlzOiBudW1iZXJbXSA9IFtdXG4gIGNvbnN0IGVtcHR5VmFsdWUgPSB2YWx1ZXMuZmluZCh2YWx1ZSA9PiB2YWx1ZS5rZXkgPT09ICcnKVxuXG4gIGNvbnN0IG5vdEVtcHR5VmFsdWVzID0gdmFsdWVzXG4gICAgLmZpbHRlcih2YWx1ZSA9PiB2YWx1ZS5rZXkgIT09ICcnKVxuICAgIC5tYXAodmFsdWUgPT4gdmFsdWUudGV4dClcblxuICBub3RFbXB0eVZhbHVlcy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgIHJlY29yZEtleXMucHVzaCguLi5maW5kUmVjb3JkS2V5cyhyZWNvcmQsIGl0ZW0pKVxuICB9KVxuXG4gIGNvbnN0IGtleXMgPSByZWNvcmRLZXlzLmpvaW4oJywgJylcblxuICBpZiAocmVjb3JkS2V5cy5sZW5ndGggPiAwKSB7XG4gICAgaWYgKGZpZWxkPy5pbmNsdWRlcygnZW5mb3F1ZScpKSB7XG4gICAgICByZXR1cm4gYCR7ZmllbGR9L2FueShlbmY6IGVuZi9lbmZvcXVlIGluICgke2tleXN9KSlgXG4gICAgfVxuICAgIGlmIChmaWVsZD8uaW5jbHVkZXMoJ2FmaXJtYWNvZXMnKSkge1xuICAgICAgcmV0dXJuIGAke2ZpZWxkfS9hbnkoYWZmOiBhZmYvYWZpcm1hY2FvIGluICgke2tleXN9KSBhbmQgYWZmL2F0aXZvIGVxIHRydWUpYFxuICAgIH1cbiAgICBpZiAoZmllbGQ/LmluY2x1ZGVzKCd2aXNpdGFzJykpIHtcbiAgICAgIHJldHVybiBgJHtmaWVsZH0vYW55KHZpc2l0OiB2aXNpdC90aXR1bG8gaW4gKCR7a2V5c30pKWBcbiAgICB9XG4gICAgcmV0dXJuIGAke2ZpZWxkfSBpbiAoJHtrZXlzfSlgXG4gIH1cblxuICBpZiAoIXJlY29yZEtleXMubGVuZ3RoICYmIGVtcHR5VmFsdWUpIHtcbiAgICBpZiAoZmllbGQ/LmluY2x1ZGVzKCdhZmlybWFjb2VzJykpIHtcbiAgICAgIHJldHVybiBgJHtmaWVsZH0vYWxsKGFmZjogYWZmL2F0aXZvIGVxIGZhbHNlKWBcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbnVsbFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JNYW55VXNlck5hbWVzIChmaWVsZDogc3RyaW5nLCB2YWx1ZXM6IElGaWx0ZXJHcm91cEl0ZW1bXSk6IHN0cmluZyB7XG4gIGNvbnN0IGVtcHR5VmFsdWUgPSB2YWx1ZXMuZmluZCh2YWx1ZSA9PiB2YWx1ZS5rZXkgPT09ICcnKVxuXG4gIGNvbnN0IG5vdEVtcHR5VmFsdWVzID0gdmFsdWVzXG4gICAgLmZpbHRlcih2YWx1ZSA9PiB2YWx1ZS5rZXkgIT09ICcnKVxuICAgIC5tYXAodmFsdWUgPT4gYCcke3ZhbHVlLnRleHR9J2ApXG4gICAgLmpvaW4oJywgJylcblxuICByZXR1cm4gYCR7ZmllbGR9L2FueSh1c2VyOiB1c2VyL25vbWUgaW4gKCR7bm90RW1wdHlWYWx1ZXN9KSkke1xuICAgIGVtcHR5VmFsdWUgPyBgIG9yIG5vdCAke2ZpZWxkfS9hbnkoKWAgOiAnJ31gXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZvck1hbnlTdHJpbmcgKGZpZWxkOiBzdHJpbmcsIHZhbHVlczogSUZpbHRlckdyb3VwSXRlbVtdLCByZXBsYWNlPzogKHZhbHVlOiBzdHJpbmcpID0+IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGtleXMgPSB2YWx1ZXNcbiAgICAubWFwKHZhbHVlID0+IHJlcGxhY2UgPyByZXBsYWNlKGAnJHt2YWx1ZS50ZXh0LnRvTG93ZXJDYXNlKCl9J2ApIDogYCcke3ZhbHVlLnRleHQudG9Mb3dlckNhc2UoKX0nYClcbiAgICAuam9pbignLCAnKVxuXG4gIHJldHVybiBgdG9sb3dlcigke2ZpZWxkfSkgaW4gKCR7a2V5c30pYFxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRGb3JNYW55SWRzIChmaWVsZDogc3RyaW5nLCBpZHM6IElGaWx0ZXJHcm91cEl0ZW1bXSk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBrZXlzID0gaWRzXG4gICAgLm1hcCh2YWx1ZSA9PiBgJyR7dmFsdWUua2V5fSdgKVxuICAgIC5qb2luKCcsICcpXG5cbiAgcmV0dXJuIGAke2ZpZWxkfSBpbiAoJHtrZXlzfSlgXG59XG4iXSwibWFwcGluZ3MiOiJBQUVPLGdCQUFTLGVBQWdCLFFBQThELG9CQUFzQztBQUNsSSxNQUFJLENBQUM7QUFBUSxXQUFPLENBQUM7QUFDckIsUUFBTSxhQUFhLG1CQUFtQixZQUFZO0FBQ2xELFFBQU0sZ0JBQWdCLE9BQU8sUUFBUSxNQUFNO0FBQzNDLFFBQU0sV0FBVztBQUNqQixRQUFNLG1CQUFtQjtBQUN6QixRQUFNLFNBQVMsY0FDWixPQUFPLFlBQVUsT0FBTyxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUMsRUFDNUUsSUFBSSxZQUFVLE9BQU8sT0FBTyxRQUFRLEVBQUUsU0FBUyxFQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQztBQUU1RSxTQUFPO0FBQ1Q7QUFFQSxNQUFNLHdCQUF3QjtBQUM5QixNQUFNLDJCQUEyQjtBQUNqQyxNQUFNLFlBQVk7QUFDbEIsTUFBTSxnQkFBZ0I7QUFFZixnQkFBUyxnQkFBaUIsT0FBZSxPQUE4QjtBQUM1RSxTQUFPLEdBQUcsWUFBWSxVQUFVLE1BQU0sU0FBUztBQUNqRDtBQUVPLGdCQUFTLHVCQUF3QixPQUFlLE9BQThCO0FBQ25GLFNBQU8sc0JBQXNCLFNBQVMsT0FBTyxZQUFZLENBQUMsS0FBSyxPQUFPLFlBQVksRUFBRSxPQUFPLENBQUMsTUFBTSxNQUM5RixHQUFHLFlBQVksU0FDZix5QkFBeUIsU0FBUyxPQUFPLFlBQVksQ0FBQyxLQUFLLE9BQU8sWUFBWSxFQUFFLE9BQU8sQ0FBQyxNQUFNLE1BQzVGLEdBQUcsWUFBWSxVQUNmO0FBQ1I7QUFDTyxnQkFBUyxhQUFjLE9BQWUsT0FBOEI7QUFDekUsU0FBTyxVQUFVLFNBQVMsT0FBTyxZQUFZLENBQUMsS0FBSyxPQUFPLFlBQVksRUFBRSxPQUFPLENBQUMsTUFBTSxNQUNsRixHQUFHLFlBQVksU0FDZixjQUFjLFNBQVMsT0FBTyxZQUFZLENBQUMsS0FBSyxPQUFPLFlBQVksRUFBRSxPQUFPLENBQUMsTUFBTSxNQUNqRixHQUFHLFlBQVksVUFDZjtBQUNSO0FBRU8sZ0JBQVMsaUJBQWtCLE9BQWUsT0FBZSxTQUEyQjtBQUN6RixTQUFPLFVBQ0gsT0FBTyxnQkFDUCxHQUFHLHdDQUF3QztBQUNqRDtBQUVPLGdCQUFTLG9CQUFxQixPQUFlLE9BQXVCO0FBQ3pFLFNBQU8sR0FBRyw4Q0FBOEM7QUFDMUQ7QUFFTyxnQkFBUyxhQUFjLE9BQWUsT0FBZSxZQUE4QjtBQUN4RixTQUFPLEdBQUcsc0NBQXNDLGFBQWEsYUFBYSxhQUFhLE1BQU0sUUFBUSxXQUFXLEVBQUU7QUFDcEg7QUFFTyxnQkFBUyxvQkFBcUIsT0FBZSxPQUFlLFlBQThCO0FBQy9GLFNBQU8sR0FBRyxzQ0FBc0MsYUFBYSxhQUFhLG9CQUFvQjtBQUNoRztBQUVPLGdCQUFTLGVBQWdCLE9BQWUsT0FBZSxTQUE2QztBQUN6RyxTQUFPLG9CQUFvQixvQkFBb0IsVUFBVSxRQUFRLEtBQUssSUFBSTtBQUM1RTtBQUVPLGdCQUFTLFdBQVksT0FBZSxJQUEyQjtBQUNwRSxTQUFPLEtBQUssR0FBRyxZQUFZLE9BQU87QUFDcEM7QUFFTyxnQkFBUyxlQUFnQixPQUFlLE9BQThCO0FBQzNFLFFBQU0sU0FBUyxPQUFPLE1BQU0sU0FBUyxFQUFFLFFBQVEsWUFBWSxFQUFFLENBQUM7QUFDOUQsU0FBTyxVQUFVLFdBQVcsSUFBSSxHQUFHLFlBQVksV0FBVztBQUM1RDtBQUVPLGdCQUFTLGFBQWMsT0FBZSxPQUE4QjtBQUN6RSxNQUFJLE9BQU87QUFFWCxNQUFJLE1BQU0sU0FBUyxHQUFHO0FBQUcsV0FBTyxNQUFNLE1BQU0sR0FBRyxFQUFFLFFBQVEsRUFBRSxLQUFLLEdBQUc7QUFFbkUsUUFBTSxVQUFVLElBQUksS0FBSyxJQUFJO0FBQzdCLFFBQU0sY0FBYyxLQUFLLFdBQVcsTUFBTSxtQkFBbUIsUUFBUSxDQUFDLE1BQU0sUUFBUSxRQUFRLENBQUM7QUFFN0YsU0FBTyxjQUFjLEdBQUcsWUFBWSxTQUFTO0FBQy9DO0FBRUEsTUFBTSw0QkFBNEI7QUFFM0IsZ0JBQVMsZUFBZ0IsT0FBZSxPQUFlLFFBQWtFO0FBQzlILE1BQUksTUFBTSxVQUFVO0FBQTJCLFdBQU87QUFDdEQsTUFBSSxhQUFhLENBQUM7QUFFbEIsZUFBYSxlQUFlLFFBQVEsS0FBSztBQUN6QyxNQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLFFBQUksT0FBTyxTQUFTLFNBQVMsR0FBRztBQUM5QixhQUFPLFdBQ0osSUFBSSxTQUFPLEdBQUcsaUNBQWlDLE1BQU0sRUFDckQsS0FBSyxNQUFNO0FBQUEsSUFDaEI7QUFDQSxRQUFJLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDakMsYUFBTyxXQUNKLElBQUksU0FBTyxHQUFHLG1DQUFtQyw0QkFBNEIsRUFDN0UsS0FBSyxNQUFNO0FBQUEsSUFDaEI7QUFDQSxRQUFJLE9BQU8sU0FBUyxTQUFTLEdBQUc7QUFDOUIsYUFBTyxXQUNKLElBQUksU0FBTyxHQUFHLG9DQUFvQyxNQUFNLEVBQ3hELEtBQUssTUFBTTtBQUFBLElBQ2hCO0FBQ0EsV0FBTyxXQUNKLElBQUksU0FBTyxHQUFHLFlBQVksS0FBSyxFQUMvQixLQUFLLE1BQU07QUFBQSxFQUNoQjtBQUNBLFNBQU87QUFDVDtBQUVPLGdCQUFTLHVCQUF3QixPQUFlLFFBQTRCLFFBQWtFO0FBQ25KLFFBQU0sYUFBdUIsQ0FBQztBQUM5QixRQUFNLGFBQWEsT0FBTyxLQUFLLFdBQVMsTUFBTSxRQUFRLEVBQUU7QUFFeEQsUUFBTSxpQkFBaUIsT0FDcEIsT0FBTyxXQUFTLE1BQU0sUUFBUSxFQUFFLEVBQ2hDLElBQUksV0FBUyxNQUFNLElBQUk7QUFFMUIsaUJBQWUsUUFBUSxVQUFRO0FBQzdCLGVBQVcsS0FBSyxHQUFHLGVBQWUsUUFBUSxJQUFJLENBQUM7QUFBQSxFQUNqRCxDQUFDO0FBRUQsUUFBTSxPQUFPLFdBQVcsS0FBSyxJQUFJO0FBRWpDLE1BQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsUUFBSSxPQUFPLFNBQVMsU0FBUyxHQUFHO0FBQzlCLGFBQU8sR0FBRyxrQ0FBa0M7QUFBQSxJQUM5QztBQUNBLFFBQUksT0FBTyxTQUFTLFlBQVksR0FBRztBQUNqQyxhQUFPLEdBQUcsb0NBQW9DO0FBQUEsSUFDaEQ7QUFDQSxRQUFJLE9BQU8sU0FBUyxTQUFTLEdBQUc7QUFDOUIsYUFBTyxHQUFHLHFDQUFxQztBQUFBLElBQ2pEO0FBQ0EsV0FBTyxHQUFHLGFBQWE7QUFBQSxFQUN6QjtBQUVBLE1BQUksQ0FBQyxXQUFXLFVBQVUsWUFBWTtBQUNwQyxRQUFJLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDakMsYUFBTyxHQUFHO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFFQSxTQUFPO0FBQ1Q7QUFFTyxnQkFBUyxzQkFBdUIsT0FBZSxRQUFvQztBQUN4RixRQUFNLGFBQWEsT0FBTyxLQUFLLFdBQVMsTUFBTSxRQUFRLEVBQUU7QUFFeEQsUUFBTSxpQkFBaUIsT0FDcEIsT0FBTyxXQUFTLE1BQU0sUUFBUSxFQUFFLEVBQ2hDLElBQUksV0FBUyxJQUFJLE1BQU0sT0FBTyxFQUM5QixLQUFLLElBQUk7QUFFWixTQUFPLEdBQUcsaUNBQWlDLG1CQUN6QyxhQUFhLFdBQVcsZ0JBQWdCO0FBQzVDO0FBRU8sZ0JBQVMsbUJBQW9CLE9BQWUsUUFBNEIsU0FBNkM7QUFDMUgsUUFBTSxPQUFPLE9BQ1YsSUFBSSxXQUFTLFVBQVUsUUFBUSxJQUFJLE1BQU0sS0FBSyxZQUFZLElBQUksSUFBSSxJQUFJLE1BQU0sS0FBSyxZQUFZLElBQUksRUFDakcsS0FBSyxJQUFJO0FBRVosU0FBTyxXQUFXLGNBQWM7QUFDbEM7QUFFTyxnQkFBUyxnQkFBaUIsT0FBZSxLQUF3QztBQUN0RixRQUFNLE9BQU8sSUFDVixJQUFJLFdBQVMsSUFBSSxNQUFNLE1BQU0sRUFDN0IsS0FBSyxJQUFJO0FBRVosU0FBTyxHQUFHLGFBQWE7QUFDekI7IiwibmFtZXMiOltdfQ==