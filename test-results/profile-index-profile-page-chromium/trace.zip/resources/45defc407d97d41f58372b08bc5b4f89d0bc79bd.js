import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/LoginPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/LoginPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { LoginForm } from "/src/modules/auth/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import AuthPageBoilerplate from "/src/modules/auth/pages/AuthPageBoilerplate.tsx?t=1701096626433";
const LoginPage = () => {
  _s();
  const {
    login,
    loggingIn
  } = useAuth();
  return /* @__PURE__ */ jsxDEV(AuthPageBoilerplate, { children: /* @__PURE__ */ jsxDEV(LoginForm, { submitForm: login, loading: loggingIn === "pending" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/LoginPage.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/LoginPage.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(LoginPage, "y1b4aCDteLZfMYq3IP3qfVdAVH8=", false, function() {
  return [useAuth];
});
_c = LoginPage;
export default LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFWTixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsZUFBZTtBQUV4QixPQUFPQyx5QkFBeUI7QUFFaEMsTUFBTUMsWUFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsRUFBVSxJQUFJTCxRQUFRO0FBRXJDLFNBQ0UsdUJBQUMsdUJBQ0MsaUNBQUMsYUFDQyxZQUFZSSxPQUNaLFNBQVNDLGNBQWMsYUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVtQyxLQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDRixHQVhLRCxXQUFhO0FBQUEsVUFDWUYsT0FBTztBQUFBO0FBQUFNLEtBRGhDSjtBQWFOLGVBQWVBO0FBQVMsSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxvZ2luRm9ybSIsInVzZUF1dGgiLCJBdXRoUGFnZUJvaWxlcnBsYXRlIiwiTG9naW5QYWdlIiwiX3MiLCJsb2dpbiIsImxvZ2dpbmdJbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5QYWdlLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYXV0aC9wYWdlcy9Mb2dpblBhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTG9naW5Gb3JtIH0gZnJvbSAnLi4vY29tcG9uZW50cydcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9zdG9yZS9hdXRoJ1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBBdXRoUGFnZUJvaWxlcnBsYXRlIGZyb20gJy4vQXV0aFBhZ2VCb2lsZXJwbGF0ZSdcblxuY29uc3QgTG9naW5QYWdlOiBGQyA9ICgpID0+IHtcbiAgY29uc3QgeyBsb2dpbiwgbG9nZ2luZ0luIH0gPSB1c2VBdXRoKClcblxuICByZXR1cm4gKFxuICAgIDxBdXRoUGFnZUJvaWxlcnBsYXRlID5cbiAgICAgIDxMb2dpbkZvcm1cbiAgICAgICAgc3VibWl0Rm9ybT17bG9naW59XG4gICAgICAgIGxvYWRpbmc9e2xvZ2dpbmdJbiA9PT0gJ3BlbmRpbmcnfVxuICAgICAgLz5cbiAgICA8LyBBdXRoUGFnZUJvaWxlcnBsYXRlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luUGFnZVxuIl19