import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/charts/ProgressBarChart.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/ProgressBarChart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { keyframes, mergeStyleSets, TooltipHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useConst, useId } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const ProgressBarChart = ({
  percentage,
  color,
  hint
}) => {
  _s();
  const tooltipId = useId("tooltip");
  const progressId = useId("target");
  const styles = useStyles(percentage, color);
  const calloutProps = useConst({
    gapSpace: 0,
    target: `#${progressId}`
  });
  return /* @__PURE__ */ jsxDEV("div", { className: styles.progressBar, children: /* @__PURE__ */ jsxDEV(TooltipHost, { content: hint, closeDelay: 20, id: tooltipId, calloutProps, children: /* @__PURE__ */ jsxDEV("div", { className: styles.progressBarIndicator, id: progressId, "aria-describedby": tooltipId }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/ProgressBarChart.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/ProgressBarChart.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/ProgressBarChart.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_s(ProgressBarChart, "Hy2bTAC8pTbNa+q8627m4iIVmpc=", false, function() {
  return [useId, useId, useStyles, useConst];
});
_c = ProgressBarChart;
const useStyles = (percentage, color) => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    progressBar: {
      width: "100%",
      height: "6px",
      display: "flex",
      borderRadius: "4px",
      overflow: "hidden",
      background: theme.colors.neutralLight[300],
      position: "relative"
    },
    progressBarIndicator: {
      width: `${percentage * 1}%`,
      borderRadius: "4px",
      height: "100%",
      backgroundColor: color || theme.colors.purple[500],
      content: "''",
      animation: `${progress} 1s ease-out forwards`,
      position: "absolute",
      display: "block",
      "&:hover": {
        filter: "brightness(0.9)",
        cursor: "pointer"
      }
    }
  });
};
_s2(useStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
const progress = keyframes({
  "0%": {
    width: "0"
  }
});
export default ProgressBarChart;
var _c;
$RefreshReg$(_c, "ProgressBarChart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/ProgressBarChart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkJOLFNBQVNBLFdBQVdDLGdCQUFnQkMsbUJBQW1CO0FBQ3ZELFNBQVNDLFVBQVVDLGFBQWE7QUFFaEMsU0FBU0MsZ0JBQWdCO0FBT3pCLE1BQU1DLG1CQUE4Q0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVlDO0FBQUFBLEVBQU9DO0FBQUssTUFBTTtBQUFBQyxLQUFBO0FBQ25GLFFBQU1DLFlBQVlQLE1BQU0sU0FBUztBQUNqQyxRQUFNUSxhQUFhUixNQUFNLFFBQVE7QUFDakMsUUFBTVMsU0FBU0MsVUFBVVAsWUFBWUMsS0FBSztBQUMxQyxRQUFNTyxlQUFlWixTQUFTO0FBQUEsSUFDNUJhLFVBQVU7QUFBQSxJQUNWQyxRQUFTLElBQUdMO0FBQUFBLEVBQ2QsQ0FBQztBQUVELFNBQU8sdUJBQUMsU0FDTixXQUFXQyxPQUFPSyxhQUVsQixpQ0FBQyxlQUFZLFNBQVNULE1BQU0sWUFBWSxJQUFJLElBQUlFLFdBQVcsY0FDekQsaUNBQUMsU0FDQyxXQUFXRSxPQUFPTSxzQkFDbEIsSUFBSVAsWUFDSixvQkFBa0JELGFBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHOEIsS0FKaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBVEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVQO0FBQ0Y7QUFBQ0QsR0FwQktKLGtCQUEyQztBQUFBLFVBQzdCRixPQUNDQSxPQUNKVSxXQUNNWCxRQUFRO0FBQUE7QUFBQWlCLEtBSnpCZDtBQXNCTixNQUFNUSxZQUFZQSxDQUFDUCxZQUFvQkMsVUFBbUI7QUFBQWEsTUFBQTtBQUN4RCxRQUFNQyxRQUFRakIsU0FBUztBQUV2QixTQUFPSixlQUFlO0FBQUEsSUFDcEJpQixhQUFhO0FBQUEsTUFDWEssT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxNQUNSQyxTQUFTO0FBQUEsTUFDVEMsY0FBYztBQUFBLE1BQ2RDLFVBQVU7QUFBQSxNQUNWQyxZQUFZTixNQUFNTyxPQUFPQyxhQUFhLEdBQUc7QUFBQSxNQUN6Q0MsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBWixzQkFBc0I7QUFBQSxNQUNwQkksT0FBUSxHQUFFaEIsYUFBYTtBQUFBLE1BQ3ZCbUIsY0FBYztBQUFBLE1BQ2RGLFFBQVE7QUFBQSxNQUNSUSxpQkFBaUJ4QixTQUFTYyxNQUFNTyxPQUFPSSxPQUFPLEdBQUc7QUFBQSxNQUNqREMsU0FBUztBQUFBLE1BQ1RDLFdBQVksR0FBRUM7QUFBQUEsTUFDZEwsVUFBVTtBQUFBLE1BQ1ZOLFNBQVM7QUFBQSxNQUVULFdBQVc7QUFBQSxRQUNUWSxRQUFRO0FBQUEsUUFDUkMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ2pCLElBN0JLUCxXQUFTO0FBQUEsVUFDQ1QsUUFBUTtBQUFBO0FBOEJ4QixNQUFNK0IsV0FBV3BDLFVBQVU7QUFBQSxFQUN6QixNQUFNO0FBQUEsSUFDSnVCLE9BQU87QUFBQSxFQUNUO0FBQ0YsQ0FBQztBQUVELGVBQWVqQjtBQUFnQixJQUFBYztBQUFBbUIsYUFBQW5CLElBQUEiLCJuYW1lcyI6WyJrZXlmcmFtZXMiLCJtZXJnZVN0eWxlU2V0cyIsIlRvb2x0aXBIb3N0IiwidXNlQ29uc3QiLCJ1c2VJZCIsInVzZVRoZW1lIiwiUHJvZ3Jlc3NCYXJDaGFydCIsInBlcmNlbnRhZ2UiLCJjb2xvciIsImhpbnQiLCJfcyIsInRvb2x0aXBJZCIsInByb2dyZXNzSWQiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJjYWxsb3V0UHJvcHMiLCJnYXBTcGFjZSIsInRhcmdldCIsInByb2dyZXNzQmFyIiwicHJvZ3Jlc3NCYXJJbmRpY2F0b3IiLCJfYyIsIl9zMiIsInRoZW1lIiwid2lkdGgiLCJoZWlnaHQiLCJkaXNwbGF5IiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJiYWNrZ3JvdW5kIiwiY29sb3JzIiwibmV1dHJhbExpZ2h0IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJjb250ZW50IiwiYW5pbWF0aW9uIiwicHJvZ3Jlc3MiLCJmaWx0ZXIiLCJjdXJzb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9ncmVzc0JhckNoYXJ0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2NoYXJ0cy9Qcm9ncmVzc0JhckNoYXJ0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGtleWZyYW1lcywgbWVyZ2VTdHlsZVNldHMsIFRvb2x0aXBIb3N0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VDb25zdCwgdXNlSWQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtaG9va3MnXHJcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXHJcblxyXG5pbnRlcmZhY2UgUHJvZ3Jlc3NCYXJDaGFydFByb3BzIHtcclxuICBwZXJjZW50YWdlOiBudW1iZXJcclxuICBjb2xvcj86IHN0cmluZ1xyXG4gIGhpbnQ/OiBzdHJpbmdcclxufVxyXG5jb25zdCBQcm9ncmVzc0JhckNoYXJ0OiBGQzxQcm9ncmVzc0JhckNoYXJ0UHJvcHM+ID0gKHsgcGVyY2VudGFnZSwgY29sb3IsIGhpbnQgfSkgPT4ge1xyXG4gIGNvbnN0IHRvb2x0aXBJZCA9IHVzZUlkKCd0b29sdGlwJylcclxuICBjb25zdCBwcm9ncmVzc0lkID0gdXNlSWQoJ3RhcmdldCcpXHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKHBlcmNlbnRhZ2UsIGNvbG9yKVxyXG4gIGNvbnN0IGNhbGxvdXRQcm9wcyA9IHVzZUNvbnN0KHtcclxuICAgIGdhcFNwYWNlOiAwLFxyXG4gICAgdGFyZ2V0OiBgIyR7cHJvZ3Jlc3NJZH1gLFxyXG4gIH0pXHJcblxyXG4gIHJldHVybiA8ZGl2XHJcbiAgICBjbGFzc05hbWU9e3N0eWxlcy5wcm9ncmVzc0Jhcn1cclxuICA+XHJcbiAgICA8VG9vbHRpcEhvc3QgY29udGVudD17aGludH0gY2xvc2VEZWxheT17MjB9IGlkPXt0b29sdGlwSWR9IGNhbGxvdXRQcm9wcz17Y2FsbG91dFByb3BzfSA+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5wcm9ncmVzc0JhckluZGljYXRvcn1cclxuICAgICAgICBpZD17cHJvZ3Jlc3NJZH1cclxuICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXt0b29sdGlwSWR9XHJcbiAgICAgIC8+XHJcbiAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gIDwvZGl2PlxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAocGVyY2VudGFnZTogbnVtYmVyLCBjb2xvcj86IHN0cmluZykgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxyXG5cclxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgcHJvZ3Jlc3NCYXI6IHtcclxuICAgICAgd2lkdGg6ICcxMDAlJyxcclxuICAgICAgaGVpZ2h0OiAnNnB4JyxcclxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICBib3JkZXJSYWRpdXM6ICc0cHgnLFxyXG4gICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXHJcbiAgICAgIGJhY2tncm91bmQ6IHRoZW1lLmNvbG9ycy5uZXV0cmFsTGlnaHRbMzAwXSxcclxuICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICB9LFxyXG4gICAgcHJvZ3Jlc3NCYXJJbmRpY2F0b3I6IHtcclxuICAgICAgd2lkdGg6IGAke3BlcmNlbnRhZ2UgKiAxfSVgLFxyXG4gICAgICBib3JkZXJSYWRpdXM6ICc0cHgnLFxyXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvciB8fCB0aGVtZS5jb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgIGNvbnRlbnQ6IFwiJydcIixcclxuICAgICAgYW5pbWF0aW9uOiBgJHtwcm9ncmVzc30gMXMgZWFzZS1vdXQgZm9yd2FyZHNgLFxyXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcclxuXHJcbiAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgIGZpbHRlcjogJ2JyaWdodG5lc3MoMC45KScsXHJcbiAgICAgICAgY3Vyc29yOiAncG9pbnRlcicsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IHByb2dyZXNzID0ga2V5ZnJhbWVzKHtcclxuICAnMCUnOiB7XHJcbiAgICB3aWR0aDogJzAnLFxyXG4gIH0sXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9ncmVzc0JhckNoYXJ0XHJcbiJdfQ==