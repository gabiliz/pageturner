import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { AppPage, FlexColumn, FlexRow, LoadingScreen, PageTitle } from "/src/shared/components/index.ts?t=1701096626433";
import { financialStatementsFilesQueryService, financialStatementsFilesService, financialStatementsQueryService } from "/src/modules/audit/financialStatements/services/index.ts";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { FinancialStatementsImportPageContext } from "/src/modules/audit/financialStatements/contexts/FinancialStatementsImportPageContext.ts";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { MessageBarType, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { selectFile } from "/src/shared/utils/index.ts";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { useTheme } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { FinancialStatementsSituationEnum } from "/src/modules/audit/financialStatements/enums/FinancialStatementsSituation.ts";
import { FinancialStatementsBreadcrumb, FinancialStatementsImportPageActions, FinancialStatementsSituation, FinancialStatementsImportNewFileSection, FinancialStatementsImportVersionsSection } from "/src/modules/audit/financialStatements/components/index.ts?t=1701096626433";
const ACCEPTED_FILES_TO_IMPORT = "application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const FinancialStatementsImportPage = () => {
  _s();
  const abortController = useRef(null);
  const {
    financialId,
    auditId
  } = useParams();
  const {
    fontWeight,
    colors,
    fontSize,
    spacing
  } = useTheme();
  const {
    showNotification
  } = useNotifications();
  const {
    setMenuCollapsed
  } = useContext(LoadingDataContext);
  const [progressUpload, setProgressUpload] = useState(0);
  const [selectedFile, setSelectedFile] = useState(null);
  const [hasError, {
    setTrue: showError,
    setFalse: hideError
  }] = useBoolean(false);
  const {
    data: financialStatement,
    isLoading
  } = financialStatementsQueryService.useFindOne(auditId, financialId);
  const {
    data: financialStatementFiles,
    isLoading: isLoadingFiles
  } = financialStatementsFilesQueryService.useFindAll(auditId, financialId);
  const enabledEditFinancialStatement = [FinancialStatementsSituationEnum.NOT_STARTED, FinancialStatementsSituationEnum.IN_PROGRESS, FinancialStatementsSituationEnum.IN_ADJUST, FinancialStatementsSituationEnum.WAITING_CLIENT].includes(financialStatement?.situacao);
  const handleAbortImportation = () => {
    abortController.current && abortController.current?.abort();
    financialStatementsQueryService.invalidateQueries();
  };
  const updateProgress = (data) => {
    setProgressUpload(data);
  };
  const upload = useCallback(async (file) => {
    if (!file) {
      showError();
      return;
    }
    try {
      setSelectedFile(file);
      abortController.current = new AbortController();
      await financialStatementsFilesService.upload(file, auditId, financialId, (data) => {
        updateProgress(Math.round(100 * data.loaded / data.total) / 100);
      }, abortController.current.signal);
      showNotification({
        message: "Versão adicionada com sucesso!",
        type: MessageBarType.success
      });
      hideError();
    } catch (error) {
      const er = error;
      er.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error
        });
      });
      if (!er.message) {
        showNotification({
          message: "Erro ao importar arquivo.",
          type: MessageBarType.error
        });
      }
    } finally {
      setSelectedFile(null);
      updateProgress(0);
    }
    financialStatementsFilesQueryService.invalidateQueries();
    financialStatementsQueryService.invalidateQueries();
  }, [selectedFile, updateProgress, abortController.current]);
  const handleImport = useCallback(async () => {
    try {
      const files = await selectFile(false, ACCEPTED_FILES_TO_IMPORT);
      const isImportedFileTypeAccepted = ACCEPTED_FILES_TO_IMPORT.split(",").includes(files[0].type);
      const isFileNameExceeded = files[0].name !== void 0 && files[0].name.length > 200;
      if (isFileNameExceeded) {
        showNotification({
          message: "Nome do arquivo com mais de 200 caracteres.",
          type: MessageBarType.error,
          timeout: 5e3
        });
      } else if (!isImportedFileTypeAccepted) {
        showNotification({
          message: "O formato do arquivo não é suportado.",
          type: MessageBarType.error,
          timeout: 5e3
        });
      } else {
        const fileWithVersion = getFileWithVersionedName(files[0], financialStatement?.ultimaVersao);
        await upload(fileWithVersion);
      }
    } catch (error) {
      const er = error;
      er.errors?.messages?.forEach((errorMessage) => {
        showNotification({
          message: errorMessage.message,
          type: MessageBarType.error
        });
      });
    }
  }, [upload]);
  const toggleMenu = useCallback(() => {
    if (!financialStatementFiles)
      return;
    if (financialStatementFiles?.length === 0) {
      setMenuCollapsed(false);
    }
    if (financialStatementFiles?.length > 0) {
      setMenuCollapsed(true);
    }
  }, [financialStatementFiles]);
  useEffect(() => {
    toggleMenu();
    return () => setMenuCollapsed(void 0);
  }, [toggleMenu]);
  if (isLoadingFiles || isLoading)
    return /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 139,
      columnNumber: 43
    }, this);
  const situation = financialStatement?.situacao ?? 0;
  return /* @__PURE__ */ jsxDEV(FinancialStatementsImportPageContext.Provider, { value: {
    financialStatement,
    selectedFile,
    setSelectedFile,
    progressUpload,
    setProgressUpload,
    handleImport,
    hasError,
    lastVersion: financialStatement?.ultimaVersao,
    abortFileImportation: handleAbortImportation,
    enabledEditFinancialStatement,
    situation
  }, children: /* @__PURE__ */ jsxDEV(AppPage, { renderTitle: () => /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: spacing.md, rowGap: spacing.xs, children: [
      /* @__PURE__ */ jsxDEV(PageTitle, { wrap: true, children: [
        /* @__PURE__ */ jsxDEV("span", { children: financialStatement?.empresa.razaoSocial }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
          lineNumber: 157,
          columnNumber: 15
        }, this),
        " ",
        " "
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
        lineNumber: 156,
        columnNumber: 13
      }, this),
      financialStatement?.situacao !== void 0 && /* @__PURE__ */ jsxDEV(FinancialStatementsSituation, { situation: financialStatement?.situacao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
        lineNumber: 162,
        columnNumber: 60
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 155,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        fontWeight: fontWeight.regular,
        fontSize: fontSize.h4,
        color: colors.gray[400]
      }
    }, children: "Demonstrações financeiras" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 164,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
    lineNumber: 154,
    columnNumber: 35
  }, this), topRightCorner: /* @__PURE__ */ jsxDEV(FinancialStatementsImportPageActions, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
    lineNumber: 173,
    columnNumber: 40
  }, this), renderBreadCrumb: () => /* @__PURE__ */ jsxDEV(FinancialStatementsBreadcrumb, { companyName: financialStatement?.empresa.razaoSocial }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
    lineNumber: 173,
    columnNumber: 106
  }, this), children: [
    !financialStatementFiles && isLoadingFiles && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 175,
      columnNumber: 56
    }, this),
    financialStatementFiles?.length === 0 && /* @__PURE__ */ jsxDEV(FinancialStatementsImportNewFileSection, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 177,
      columnNumber: 51
    }, this),
    financialStatementFiles && financialStatementFiles.length > 0 && /* @__PURE__ */ jsxDEV(FinancialStatementsImportVersionsSection, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
      lineNumber: 179,
      columnNumber: 75
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
    lineNumber: 154,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx",
    lineNumber: 141,
    columnNumber: 10
  }, this);
};
_s(FinancialStatementsImportPage, "wQVBEd4125fNhrr7KlRypQLwXHw=", false, function() {
  return [useParams, useTheme, useNotifications, useBoolean, financialStatementsQueryService.useFindOne, financialStatementsFilesQueryService.useFindAll];
});
_c = FinancialStatementsImportPage;
function getFileWithVersionedName(file, version) {
  const fileExtension = file.name.split(".").pop();
  const fileName = file.name.split(`.${fileExtension}`)[0];
  const fileVersion = version ? version + 1 : 1;
  const fileWithVersion = new File([file], `${fileName}_v${fileVersion}.${fileExtension.toLowerCase()}`, {
    type: file.type
  });
  return fileWithVersion;
}
export default FinancialStatementsImportPage;
var _c;
$RefreshReg$(_c, "FinancialStatementsImportPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsImportPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEowQzs7Ozs7Ozs7Ozs7Ozs7OztBQTlKMUMsU0FBYUEsYUFBYUMsWUFBWUMsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQ3pFLFNBQVNDLFNBQVNDLFlBQVlDLFNBQVNDLGVBQWVDLGlCQUFpQjtBQUN2RSxTQUFTQyxzQ0FBc0NDLGlDQUFpQ0MsdUNBQXVDO0FBQ3ZILFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyw0Q0FBNEM7QUFDckQsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxnQkFBZ0JDLFlBQVk7QUFFckMsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msd0NBQXdDO0FBQ2pELFNBQVNDLCtCQUErQkMsc0NBQXNDQyw4QkFBOEJDLHlDQUF5Q0MsZ0RBQWdEO0FBRXJNLE1BQU1DLDJCQUEyQjtBQUVqQyxNQUFNQyxnQ0FBb0NBLE1BQU07QUFBQUMsS0FBQTtBQUM5QyxRQUFNQyxrQkFBa0I1QixPQUErQixJQUFJO0FBQzNELFFBQU07QUFBQSxJQUFFNkI7QUFBQUEsSUFBYUM7QUFBQUEsRUFBUSxJQUFJcEIsVUFBVTtBQUMzQyxRQUFNO0FBQUEsSUFBRXFCO0FBQUFBLElBQVlDO0FBQUFBLElBQVFDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVEsSUFBSWhCLFNBQVM7QUFDM0QsUUFBTTtBQUFBLElBQUVpQjtBQUFBQSxFQUFpQixJQUFJdEIsaUJBQWlCO0FBQzlDLFFBQU07QUFBQSxJQUFFdUI7QUFBQUEsRUFBaUIsSUFBSXRDLFdBQVdtQixrQkFBa0I7QUFFMUQsUUFBTSxDQUFDb0IsZ0JBQWdCQyxpQkFBaUIsSUFBSXJDLFNBQWlCLENBQUM7QUFDOUQsUUFBTSxDQUFDc0MsY0FBY0MsZUFBZSxJQUFJdkMsU0FBc0IsSUFBSTtBQUVsRSxRQUFNLENBQ0p3QyxVQUNBO0FBQUEsSUFBRUMsU0FBU0M7QUFBQUEsSUFBV0MsVUFBVUM7QUFBQUEsRUFBVSxDQUFDLElBQ3pDakMsV0FBVyxLQUFLO0FBRXBCLFFBQU07QUFBQSxJQUFFa0MsTUFBTUM7QUFBQUEsSUFBb0JDO0FBQUFBLEVBQVUsSUFBSXZDLGdDQUFnQ3dDLFdBQVduQixTQUFtQkQsV0FBcUI7QUFFbkksUUFBTTtBQUFBLElBQ0ppQixNQUFNSTtBQUFBQSxJQUNORixXQUFXRztBQUFBQSxFQUNiLElBQUk1QyxxQ0FBcUM2QyxXQUN2Q3RCLFNBQ0FELFdBQ0Y7QUFFQSxRQUFNd0IsZ0NBQWdDLENBQ3BDbEMsaUNBQWlDbUMsYUFDakNuQyxpQ0FBaUNvQyxhQUNqQ3BDLGlDQUFpQ3FDLFdBQ2pDckMsaUNBQWlDc0MsY0FBYyxFQUMvQ0MsU0FBU1gsb0JBQW9CWSxRQUE0QztBQUUzRSxRQUFNQyx5QkFBeUJBLE1BQU07QUFDbkNoQyxvQkFBZ0JpQyxXQUFXakMsZ0JBQWdCaUMsU0FBU0MsTUFBTTtBQUMxRHJELG9DQUFnQ3NELGtCQUFrQjtBQUFBLEVBQ3BEO0FBRUEsUUFBTUMsaUJBQWlCQSxDQUFDbEIsU0FBaUI7QUFDdkNSLHNCQUFrQlEsSUFBSTtBQUFBLEVBQ3hCO0FBRUEsUUFBTW1CLFNBQVNwRSxZQUFZLE9BQU9xRSxTQUFzQjtBQUN0RCxRQUFJLENBQUNBLE1BQU07QUFDVHZCLGdCQUFVO0FBQ1Y7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNGSCxzQkFBZ0IwQixJQUFJO0FBQ3BCdEMsc0JBQWdCaUMsVUFBVSxJQUFJTSxnQkFBZ0I7QUFDOUMsWUFBTTNELGdDQUFnQ3lELE9BQ3BDQyxNQUNBcEMsU0FDQUQsYUFDQ2lCLFVBQVM7QUFDUmtCLHVCQUFnQkksS0FBS0MsTUFBTyxNQUFNdkIsS0FBS3dCLFNBQVV4QixLQUFLeUIsS0FBSyxJQUFLLEdBQUc7QUFBQSxNQUNyRSxHQUNBM0MsZ0JBQWdCaUMsUUFBUVcsTUFDMUI7QUFDQXJDLHVCQUFpQjtBQUFBLFFBQ2ZzQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTVELGVBQWU2RDtBQUFBQSxNQUN2QixDQUFDO0FBQ0Q5QixnQkFBVTtBQUFBLElBQ1osU0FBUytCLE9BQVA7QUFDQSxZQUFNQyxLQUFLRDtBQUNYQyxTQUFHQyxRQUFRQyxVQUFVQyxRQUFTQyxrQkFBaUI7QUFDN0M5Qyx5QkFBaUI7QUFBQSxVQUNmc0MsU0FBU1EsYUFBYVI7QUFBQUEsVUFDdEJDLE1BQU01RCxlQUFlOEQ7QUFBQUEsUUFDdkIsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUNELFVBQUksQ0FBQ0MsR0FBR0osU0FBUztBQUNmdEMseUJBQWlCO0FBQUEsVUFDZnNDLFNBQVM7QUFBQSxVQUNUQyxNQUFNNUQsZUFBZThEO0FBQUFBLFFBQ3ZCLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixVQUFDO0FBQ0NwQyxzQkFBZ0IsSUFBSTtBQUNwQndCLHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUNBekQseUNBQXFDd0Qsa0JBQWtCO0FBQ3ZEdEQsb0NBQWdDc0Qsa0JBQWtCO0FBQUEsRUFDcEQsR0FBRyxDQUFDeEIsY0FBY3lCLGdCQUFnQnBDLGdCQUFnQmlDLE9BQU8sQ0FBQztBQUUxRCxRQUFNcUIsZUFBZXJGLFlBQVksWUFBWTtBQUMzQyxRQUFJO0FBQ0YsWUFBTXNGLFFBQVEsTUFBTW5FLFdBQVcsT0FBT1Msd0JBQXdCO0FBQzlELFlBQU0yRCw2QkFBNkIzRCx5QkFBeUI0RCxNQUFNLEdBQUcsRUFDbEUzQixTQUFTeUIsTUFBTSxDQUFDLEVBQUVULElBQUk7QUFFekIsWUFBTVkscUJBQXFCSCxNQUFNLENBQUMsRUFBRUksU0FBU0MsVUFBYUwsTUFBTSxDQUFDLEVBQUVJLEtBQUtFLFNBQVM7QUFFakYsVUFBSUgsb0JBQW9CO0FBQ3RCbkQseUJBQWlCO0FBQUEsVUFDZnNDLFNBQVM7QUFBQSxVQUNUQyxNQUFNNUQsZUFBZThEO0FBQUFBLFVBQ3JCYyxTQUFTO0FBQUEsUUFDWCxDQUFDO0FBQUEsTUFDSCxXQUFXLENBQUNOLDRCQUE0QjtBQUN0Q2pELHlCQUFpQjtBQUFBLFVBQ2ZzQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTVELGVBQWU4RDtBQUFBQSxVQUNyQmMsU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLGNBQU1DLGtCQUFrQkMseUJBQ3RCVCxNQUFNLENBQUMsR0FDUHBDLG9CQUFvQjhDLFlBQ3RCO0FBRUEsY0FBTTVCLE9BQU8wQixlQUFlO0FBQUEsTUFDOUI7QUFBQSxJQUNGLFNBQVNmLE9BQVA7QUFDQSxZQUFNQyxLQUFLRDtBQUNYQyxTQUFHQyxRQUFRQyxVQUFVQyxRQUFTQyxrQkFBaUI7QUFDN0M5Qyx5QkFBaUI7QUFBQSxVQUNmc0MsU0FBU1EsYUFBYVI7QUFBQUEsVUFDdEJDLE1BQU01RCxlQUFlOEQ7QUFBQUEsUUFDdkIsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ1gsTUFBTSxDQUFDO0FBRVgsUUFBTTZCLGFBQWFqRyxZQUFZLE1BQU07QUFDbkMsUUFBSSxDQUFDcUQ7QUFBeUI7QUFFOUIsUUFBSUEseUJBQXlCdUMsV0FBVyxHQUFHO0FBQ3pDckQsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUVBLFFBQUljLHlCQUF5QnVDLFNBQVMsR0FBRztBQUN2Q3JELHVCQUFpQixJQUFJO0FBQUEsSUFDdkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ2MsdUJBQXVCLENBQUM7QUFFNUJuRCxZQUFVLE1BQU07QUFDZCtGLGVBQVc7QUFDWCxXQUFPLE1BQU0xRCxpQkFBaUJvRCxNQUFTO0FBQUEsRUFDekMsR0FBRyxDQUFDTSxVQUFVLENBQUM7QUFFZixNQUFJM0Msa0JBQWtCSDtBQUFXLFdBQU8sdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBRXRELFFBQU0rQyxZQUFhaEQsb0JBQW9CWSxZQUFZO0FBRW5ELFNBQ0UsdUJBQUMscUNBQXFDLFVBQXJDLEVBQ0MsT0FBTztBQUFBLElBQ0xaO0FBQUFBLElBQ0FSO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FIO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0E0QztBQUFBQSxJQUNBekM7QUFBQUEsSUFDQXVELGFBQWFqRCxvQkFBb0I4QztBQUFBQSxJQUNqQ0ksc0JBQXNCckM7QUFBQUEsSUFDdEJQO0FBQUFBLElBQ0EwQztBQUFBQSxFQUNGLEdBRUEsaUNBQUMsV0FDQyxhQUFhLE1BQU0sdUJBQUMsY0FDbEI7QUFBQSwyQkFBQyxXQUFRLGVBQWMsVUFBUyxLQUFLN0QsUUFBUWdFLElBQUksUUFBUWhFLFFBQVFpRSxJQUMvRDtBQUFBLDZCQUFDLGFBQVUsTUFBSSxNQUNiO0FBQUEsK0JBQUMsVUFDRXBELDhCQUFvQnFELFFBQVFDLGVBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQU87QUFBQSxRQUFFO0FBQUEsV0FIWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVDdEQsb0JBQW9CWSxhQUFhNkIsVUFDaEMsdUJBQUMsZ0NBQ0MsV0FBV3pDLG9CQUFvQlksWUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUMwQztBQUFBLFNBVDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsUUFBSyxRQUFRO0FBQUEsTUFDWjJDLE1BQU07QUFBQSxRQUNKdkUsWUFBWUEsV0FBV3dFO0FBQUFBLFFBQ3ZCdEUsVUFBVUEsU0FBU3VFO0FBQUFBLFFBQ25CQyxPQUFPekUsT0FBTzBFLEtBQUssR0FBRztBQUFBLE1BQ3hCO0FBQUEsSUFDRixHQUFFLHlDQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BdEJpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJuQixHQUNBLGdCQUFnQix1QkFBQywwQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDLEdBQ3JELGtCQUNFLE1BQU0sdUJBQUMsaUNBQ0wsYUFBYTNELG9CQUFvQnFELFFBQVFDLGVBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FDaUQsR0FLeEQ7QUFBQSxLQUFDbkQsMkJBQTJCQyxrQkFBa0IsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFFNURELHlCQUF5QnVDLFdBQVcsS0FDbkMsdUJBQUMsNkNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QztBQUFBLElBR3pDdkMsMkJBQTJCQSx3QkFBd0J1QyxTQUFTLEtBQzNELHVCQUFDLDhDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxPQXhDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBDQSxLQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMERBO0FBRUo7QUFBQzlELEdBOU1LRCwrQkFBaUM7QUFBQSxVQUVKaEIsV0FDaUJRLFVBQ3JCTCxrQkFTekJELFlBRTRDSCxnQ0FBZ0N3QyxZQUs1RTFDLHFDQUFxQzZDLFVBQVU7QUFBQTtBQUFBdUQsS0FwQi9DakY7QUFnTk4sU0FBU2tFLHlCQUEwQjFCLE1BQVkwQyxTQUFrQjtBQUMvRCxRQUFNQyxnQkFBZ0IzQyxLQUFLcUIsS0FBS0YsTUFBTSxHQUFHLEVBQUV5QixJQUFJO0FBQy9DLFFBQU1DLFdBQVc3QyxLQUFLcUIsS0FBS0YsTUFBTyxJQUFHd0IsZUFBZSxFQUFFLENBQUM7QUFDdkQsUUFBTUcsY0FBY0osVUFBVUEsVUFBVSxJQUFJO0FBRTVDLFFBQU1qQixrQkFBa0IsSUFBSXNCLEtBQzFCLENBQUMvQyxJQUFJLEdBQ0osR0FBRTZDLGFBQWFDLGVBQWVILGNBQWNLLFlBQVksS0FDekQ7QUFBQSxJQUFFeEMsTUFBTVIsS0FBS1E7QUFBQUEsRUFBSyxDQUNwQjtBQUVBLFNBQU9pQjtBQUNUO0FBRUEsZUFBZWpFO0FBQTZCLElBQUFpRjtBQUFBUSxhQUFBUixJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJBcHBQYWdlIiwiRmxleENvbHVtbiIsIkZsZXhSb3ciLCJMb2FkaW5nU2NyZWVuIiwiUGFnZVRpdGxlIiwiZmluYW5jaWFsU3RhdGVtZW50c0ZpbGVzUXVlcnlTZXJ2aWNlIiwiZmluYW5jaWFsU3RhdGVtZW50c0ZpbGVzU2VydmljZSIsImZpbmFuY2lhbFN0YXRlbWVudHNRdWVyeVNlcnZpY2UiLCJ1c2VQYXJhbXMiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZUNvbnRleHQiLCJ1c2VCb29sZWFuIiwidXNlTm90aWZpY2F0aW9ucyIsIk1lc3NhZ2VCYXJUeXBlIiwiVGV4dCIsInNlbGVjdEZpbGUiLCJMb2FkaW5nRGF0YUNvbnRleHQiLCJ1c2VUaGVtZSIsIkZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtIiwiRmluYW5jaWFsU3RhdGVtZW50c0JyZWFkY3J1bWIiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZUFjdGlvbnMiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzU2l0dWF0aW9uIiwiRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydE5ld0ZpbGVTZWN0aW9uIiwiRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFZlcnNpb25zU2VjdGlvbiIsIkFDQ0VQVEVEX0ZJTEVTX1RPX0lNUE9SVCIsIkZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnRQYWdlIiwiX3MiLCJhYm9ydENvbnRyb2xsZXIiLCJmaW5hbmNpYWxJZCIsImF1ZGl0SWQiLCJmb250V2VpZ2h0IiwiY29sb3JzIiwiZm9udFNpemUiLCJzcGFjaW5nIiwic2hvd05vdGlmaWNhdGlvbiIsInNldE1lbnVDb2xsYXBzZWQiLCJwcm9ncmVzc1VwbG9hZCIsInNldFByb2dyZXNzVXBsb2FkIiwic2VsZWN0ZWRGaWxlIiwic2V0U2VsZWN0ZWRGaWxlIiwiaGFzRXJyb3IiLCJzZXRUcnVlIiwic2hvd0Vycm9yIiwic2V0RmFsc2UiLCJoaWRlRXJyb3IiLCJkYXRhIiwiZmluYW5jaWFsU3RhdGVtZW50IiwiaXNMb2FkaW5nIiwidXNlRmluZE9uZSIsImZpbmFuY2lhbFN0YXRlbWVudEZpbGVzIiwiaXNMb2FkaW5nRmlsZXMiLCJ1c2VGaW5kQWxsIiwiZW5hYmxlZEVkaXRGaW5hbmNpYWxTdGF0ZW1lbnQiLCJOT1RfU1RBUlRFRCIsIklOX1BST0dSRVNTIiwiSU5fQURKVVNUIiwiV0FJVElOR19DTElFTlQiLCJpbmNsdWRlcyIsInNpdHVhY2FvIiwiaGFuZGxlQWJvcnRJbXBvcnRhdGlvbiIsImN1cnJlbnQiLCJhYm9ydCIsImludmFsaWRhdGVRdWVyaWVzIiwidXBkYXRlUHJvZ3Jlc3MiLCJ1cGxvYWQiLCJmaWxlIiwiQWJvcnRDb250cm9sbGVyIiwiTWF0aCIsInJvdW5kIiwibG9hZGVkIiwidG90YWwiLCJzaWduYWwiLCJtZXNzYWdlIiwidHlwZSIsInN1Y2Nlc3MiLCJlcnJvciIsImVyIiwiZXJyb3JzIiwibWVzc2FnZXMiLCJmb3JFYWNoIiwiZXJyb3JNZXNzYWdlIiwiaGFuZGxlSW1wb3J0IiwiZmlsZXMiLCJpc0ltcG9ydGVkRmlsZVR5cGVBY2NlcHRlZCIsInNwbGl0IiwiaXNGaWxlTmFtZUV4Y2VlZGVkIiwibmFtZSIsInVuZGVmaW5lZCIsImxlbmd0aCIsInRpbWVvdXQiLCJmaWxlV2l0aFZlcnNpb24iLCJnZXRGaWxlV2l0aFZlcnNpb25lZE5hbWUiLCJ1bHRpbWFWZXJzYW8iLCJ0b2dnbGVNZW51Iiwic2l0dWF0aW9uIiwibGFzdFZlcnNpb24iLCJhYm9ydEZpbGVJbXBvcnRhdGlvbiIsIm1kIiwieHMiLCJlbXByZXNhIiwicmF6YW9Tb2NpYWwiLCJyb290IiwicmVndWxhciIsImg0IiwiY29sb3IiLCJncmF5IiwiX2MiLCJ2ZXJzaW9uIiwiZmlsZUV4dGVuc2lvbiIsInBvcCIsImZpbGVOYW1lIiwiZmlsZVZlcnNpb24iLCJGaWxlIiwidG9Mb3dlckNhc2UiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2ZpbmFuY2lhbFN0YXRlbWVudHMvcGFnZXMvRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEFwcFBhZ2UsIEZsZXhDb2x1bW4sIEZsZXhSb3csIExvYWRpbmdTY3JlZW4sIFBhZ2VUaXRsZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgZmluYW5jaWFsU3RhdGVtZW50c0ZpbGVzUXVlcnlTZXJ2aWNlLCBmaW5hbmNpYWxTdGF0ZW1lbnRzRmlsZXNTZXJ2aWNlLCBmaW5hbmNpYWxTdGF0ZW1lbnRzUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2VDb250ZXh0IH0gZnJvbSAnLi4vY29udGV4dHMvRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2VDb250ZXh0J1xuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xuaW1wb3J0IHsgTWVzc2FnZUJhclR5cGUsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lcnJvcnMnXG5pbXBvcnQgeyBzZWxlY3RGaWxlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xuaW1wb3J0IHsgTG9hZGluZ0RhdGFDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbnRleHQvTG9hZGluZ0RhdGFDb250ZXh0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtIH0gZnJvbSAnLi4vZW51bXMvRmluYW5jaWFsU3RhdGVtZW50c1NpdHVhdGlvbidcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudHNCcmVhZGNydW1iLCBGaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZUFjdGlvbnMsIEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb24sIEZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnROZXdGaWxlU2VjdGlvbiwgRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFZlcnNpb25zU2VjdGlvbiB9IGZyb20gJy4uL2NvbXBvbmVudHMnXG5cbmNvbnN0IEFDQ0VQVEVEX0ZJTEVTX1RPX0lNUE9SVCA9ICdhcHBsaWNhdGlvbi9wZGYsYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LndvcmRwcm9jZXNzaW5nbWwuZG9jdW1lbnQsLGFwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0J1xuXG5jb25zdCBGaW5hbmNpYWxTdGF0ZW1lbnRzSW1wb3J0UGFnZTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IHVzZVJlZjxBYm9ydENvbnRyb2xsZXIgfCBudWxsPihudWxsKVxuICBjb25zdCB7IGZpbmFuY2lhbElkLCBhdWRpdElkIH0gPSB1c2VQYXJhbXMoKVxuICBjb25zdCB7IGZvbnRXZWlnaHQsIGNvbG9ycywgZm9udFNpemUsIHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcbiAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcbiAgY29uc3QgeyBzZXRNZW51Q29sbGFwc2VkIH0gPSB1c2VDb250ZXh0KExvYWRpbmdEYXRhQ29udGV4dClcblxuICBjb25zdCBbcHJvZ3Jlc3NVcGxvYWQsIHNldFByb2dyZXNzVXBsb2FkXSA9IHVzZVN0YXRlPG51bWJlcj4oMClcbiAgY29uc3QgW3NlbGVjdGVkRmlsZSwgc2V0U2VsZWN0ZWRGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKVxuXG4gIGNvbnN0IFtcbiAgICBoYXNFcnJvcixcbiAgICB7IHNldFRydWU6IHNob3dFcnJvciwgc2V0RmFsc2U6IGhpZGVFcnJvciB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcblxuICBjb25zdCB7IGRhdGE6IGZpbmFuY2lhbFN0YXRlbWVudCwgaXNMb2FkaW5nIH0gPSBmaW5hbmNpYWxTdGF0ZW1lbnRzUXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoYXVkaXRJZCBhcyBzdHJpbmcsIGZpbmFuY2lhbElkIGFzIHN0cmluZylcblxuICBjb25zdCB7XG4gICAgZGF0YTogZmluYW5jaWFsU3RhdGVtZW50RmlsZXMsXG4gICAgaXNMb2FkaW5nOiBpc0xvYWRpbmdGaWxlcyxcbiAgfSA9IGZpbmFuY2lhbFN0YXRlbWVudHNGaWxlc1F1ZXJ5U2VydmljZS51c2VGaW5kQWxsKFxuICAgIGF1ZGl0SWQgYXMgc3RyaW5nLFxuICAgIGZpbmFuY2lhbElkIGFzIHN0cmluZyxcbiAgKVxuXG4gIGNvbnN0IGVuYWJsZWRFZGl0RmluYW5jaWFsU3RhdGVtZW50ID0gW1xuICAgIEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtLk5PVF9TVEFSVEVELFxuICAgIEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtLklOX1BST0dSRVNTLFxuICAgIEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtLklOX0FESlVTVCxcbiAgICBGaW5hbmNpYWxTdGF0ZW1lbnRzU2l0dWF0aW9uRW51bS5XQUlUSU5HX0NMSUVOVCxcbiAgXS5pbmNsdWRlcyhmaW5hbmNpYWxTdGF0ZW1lbnQ/LnNpdHVhY2FvIGFzIEZpbmFuY2lhbFN0YXRlbWVudHNTaXR1YXRpb25FbnVtKVxuXG4gIGNvbnN0IGhhbmRsZUFib3J0SW1wb3J0YXRpb24gPSAoKSA9PiB7XG4gICAgYWJvcnRDb250cm9sbGVyLmN1cnJlbnQgJiYgYWJvcnRDb250cm9sbGVyLmN1cnJlbnQ/LmFib3J0KClcbiAgICBmaW5hbmNpYWxTdGF0ZW1lbnRzUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKClcbiAgfVxuXG4gIGNvbnN0IHVwZGF0ZVByb2dyZXNzID0gKGRhdGE6IG51bWJlcikgPT4ge1xuICAgIHNldFByb2dyZXNzVXBsb2FkKGRhdGEpXG4gIH1cblxuICBjb25zdCB1cGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoZmlsZTogRmlsZSB8IG51bGwpID0+IHtcbiAgICBpZiAoIWZpbGUpIHtcbiAgICAgIHNob3dFcnJvcigpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHNldFNlbGVjdGVkRmlsZShmaWxlKVxuICAgICAgYWJvcnRDb250cm9sbGVyLmN1cnJlbnQgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgICAgIGF3YWl0IGZpbmFuY2lhbFN0YXRlbWVudHNGaWxlc1NlcnZpY2UudXBsb2FkKFxuICAgICAgICBmaWxlLFxuICAgICAgICBhdWRpdElkIGFzIHN0cmluZyxcbiAgICAgICAgZmluYW5jaWFsSWQgYXMgc3RyaW5nLFxuICAgICAgICAoZGF0YSkgPT4ge1xuICAgICAgICAgIHVwZGF0ZVByb2dyZXNzKChNYXRoLnJvdW5kKCgxMDAgKiBkYXRhLmxvYWRlZCkgLyBkYXRhLnRvdGFsKSkgLyAxMDApXG4gICAgICAgIH0sXG4gICAgICAgIGFib3J0Q29udHJvbGxlci5jdXJyZW50LnNpZ25hbCxcbiAgICAgIClcbiAgICAgIHNob3dOb3RpZmljYXRpb24oe1xuICAgICAgICBtZXNzYWdlOiAnVmVyc8OjbyBhZGljaW9uYWRhIGNvbSBzdWNlc3NvIScsXG4gICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLnN1Y2Nlc3MsXG4gICAgICB9KVxuICAgICAgaGlkZUVycm9yKClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgZXIgPSBlcnJvciBhcyBBcGlFcnJvclxuICAgICAgZXIuZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaCgoZXJyb3JNZXNzYWdlKSA9PiB7XG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xuICAgICAgICAgIG1lc3NhZ2U6IGVycm9yTWVzc2FnZS5tZXNzYWdlLFxuICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICAgIGlmICghZXIubWVzc2FnZSkge1xuICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgICBtZXNzYWdlOiAnRXJybyBhbyBpbXBvcnRhciBhcnF1aXZvLicsXG4gICAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuZXJyb3IsXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNlbGVjdGVkRmlsZShudWxsKVxuICAgICAgdXBkYXRlUHJvZ3Jlc3MoMClcbiAgICB9XG4gICAgZmluYW5jaWFsU3RhdGVtZW50c0ZpbGVzUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKClcbiAgICBmaW5hbmNpYWxTdGF0ZW1lbnRzUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKClcbiAgfSwgW3NlbGVjdGVkRmlsZSwgdXBkYXRlUHJvZ3Jlc3MsIGFib3J0Q29udHJvbGxlci5jdXJyZW50XSlcblxuICBjb25zdCBoYW5kbGVJbXBvcnQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZpbGVzID0gYXdhaXQgc2VsZWN0RmlsZShmYWxzZSwgQUNDRVBURURfRklMRVNfVE9fSU1QT1JUKVxuICAgICAgY29uc3QgaXNJbXBvcnRlZEZpbGVUeXBlQWNjZXB0ZWQgPSBBQ0NFUFRFRF9GSUxFU19UT19JTVBPUlQuc3BsaXQoJywnKVxuICAgICAgICAuaW5jbHVkZXMoZmlsZXNbMF0udHlwZSlcblxuICAgICAgY29uc3QgaXNGaWxlTmFtZUV4Y2VlZGVkID0gZmlsZXNbMF0ubmFtZSAhPT0gdW5kZWZpbmVkICYmIGZpbGVzWzBdLm5hbWUubGVuZ3RoID4gMjAwXG5cbiAgICAgIGlmIChpc0ZpbGVOYW1lRXhjZWVkZWQpIHtcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XG4gICAgICAgICAgbWVzc2FnZTogJ05vbWUgZG8gYXJxdWl2byBjb20gbWFpcyBkZSAyMDAgY2FyYWN0ZXJlcy4nLFxuICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxuICAgICAgICAgIHRpbWVvdXQ6IDUwMDAsXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2UgaWYgKCFpc0ltcG9ydGVkRmlsZVR5cGVBY2NlcHRlZCkge1xuICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgICBtZXNzYWdlOiAnTyBmb3JtYXRvIGRvIGFycXVpdm8gbsOjbyDDqSBzdXBvcnRhZG8uJyxcbiAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcbiAgICAgICAgICB0aW1lb3V0OiA1MDAwLFxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgZmlsZVdpdGhWZXJzaW9uID0gZ2V0RmlsZVdpdGhWZXJzaW9uZWROYW1lKFxuICAgICAgICAgIGZpbGVzWzBdLFxuICAgICAgICAgIGZpbmFuY2lhbFN0YXRlbWVudD8udWx0aW1hVmVyc2FvLFxuICAgICAgICApXG5cbiAgICAgICAgYXdhaXQgdXBsb2FkKGZpbGVXaXRoVmVyc2lvbilcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgZXIgPSBlcnJvciBhcyBBcGlFcnJvclxuICAgICAgZXIuZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaCgoZXJyb3JNZXNzYWdlKSA9PiB7XG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xuICAgICAgICAgIG1lc3NhZ2U6IGVycm9yTWVzc2FnZS5tZXNzYWdlLFxuICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICB9XG4gIH0sIFt1cGxvYWRdKVxuXG4gIGNvbnN0IHRvZ2dsZU1lbnUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFmaW5hbmNpYWxTdGF0ZW1lbnRGaWxlcykgcmV0dXJuXG5cbiAgICBpZiAoZmluYW5jaWFsU3RhdGVtZW50RmlsZXM/Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgc2V0TWVudUNvbGxhcHNlZChmYWxzZSlcbiAgICB9XG5cbiAgICBpZiAoZmluYW5jaWFsU3RhdGVtZW50RmlsZXM/Lmxlbmd0aCA+IDApIHtcbiAgICAgIHNldE1lbnVDb2xsYXBzZWQodHJ1ZSlcbiAgICB9XG4gIH0sIFtmaW5hbmNpYWxTdGF0ZW1lbnRGaWxlc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB0b2dnbGVNZW51KClcbiAgICByZXR1cm4gKCkgPT4gc2V0TWVudUNvbGxhcHNlZCh1bmRlZmluZWQpXG4gIH0sIFt0b2dnbGVNZW51XSlcblxuICBpZiAoaXNMb2FkaW5nRmlsZXMgfHwgaXNMb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTY3JlZW4gLz5cblxuICBjb25zdCBzaXR1YXRpb24gPSAoZmluYW5jaWFsU3RhdGVtZW50Py5zaXR1YWNhbyA/PyAwKVxuXG4gIHJldHVybiAoXG4gICAgPEZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnRQYWdlQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgZmluYW5jaWFsU3RhdGVtZW50LFxuICAgICAgICBzZWxlY3RlZEZpbGUsXG4gICAgICAgIHNldFNlbGVjdGVkRmlsZSxcbiAgICAgICAgcHJvZ3Jlc3NVcGxvYWQsXG4gICAgICAgIHNldFByb2dyZXNzVXBsb2FkLFxuICAgICAgICBoYW5kbGVJbXBvcnQsXG4gICAgICAgIGhhc0Vycm9yLFxuICAgICAgICBsYXN0VmVyc2lvbjogZmluYW5jaWFsU3RhdGVtZW50Py51bHRpbWFWZXJzYW8sXG4gICAgICAgIGFib3J0RmlsZUltcG9ydGF0aW9uOiBoYW5kbGVBYm9ydEltcG9ydGF0aW9uLFxuICAgICAgICBlbmFibGVkRWRpdEZpbmFuY2lhbFN0YXRlbWVudCxcbiAgICAgICAgc2l0dWF0aW9uLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8QXBwUGFnZVxuICAgICAgICByZW5kZXJUaXRsZT17KCkgPT4gPEZsZXhDb2x1bW4+XG4gICAgICAgICAgPEZsZXhSb3cgdmVydGljYWxBbGlnbj0nY2VudGVyJyBnYXA9e3NwYWNpbmcubWR9IHJvd0dhcD17c3BhY2luZy54c30gPlxuICAgICAgICAgICAgPFBhZ2VUaXRsZSB3cmFwPlxuICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICB7ZmluYW5jaWFsU3RhdGVtZW50Py5lbXByZXNhLnJhemFvU29jaWFsfVxuICAgICAgICAgICAgICA8L3NwYW4+IHsnICd9XG4gICAgICAgICAgICA8L1BhZ2VUaXRsZT5cblxuICAgICAgICAgICAge2ZpbmFuY2lhbFN0YXRlbWVudD8uc2l0dWFjYW8gIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgICAgICAgIDxGaW5hbmNpYWxTdGF0ZW1lbnRzU2l0dWF0aW9uXG4gICAgICAgICAgICAgICAgc2l0dWF0aW9uPXtmaW5hbmNpYWxTdGF0ZW1lbnQ/LnNpdHVhY2FvfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0ZsZXhSb3c+XG4gICAgICAgICAgPFRleHQgc3R5bGVzPXt7XG4gICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQucmVndWxhcixcbiAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnRTaXplLmg0LFxuICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNDAwXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfX0+XG4gICAgICAgICAgICBEZW1vbnN0cmHDp8O1ZXMgZmluYW5jZWlyYXNcbiAgICAgICAgICA8L1RleHQ+XG4gICAgICAgIDwvRmxleENvbHVtbj59XG4gICAgICAgIHRvcFJpZ2h0Q29ybmVyPXs8RmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2VBY3Rpb25zLz59XG4gICAgICAgIHJlbmRlckJyZWFkQ3J1bWI9e1xuICAgICAgICAgICgpID0+IDxGaW5hbmNpYWxTdGF0ZW1lbnRzQnJlYWRjcnVtYlxuICAgICAgICAgICAgY29tcGFueU5hbWU9e2ZpbmFuY2lhbFN0YXRlbWVudD8uZW1wcmVzYS5yYXphb1NvY2lhbH1cbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICA+XG5cbiAgICAgICAgeyFmaW5hbmNpYWxTdGF0ZW1lbnRGaWxlcyAmJiBpc0xvYWRpbmdGaWxlcyAmJiA8TG9hZGluZ1NjcmVlbiAvPn1cblxuICAgICAgICB7ZmluYW5jaWFsU3RhdGVtZW50RmlsZXM/Lmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgPEZpbmFuY2lhbFN0YXRlbWVudHNJbXBvcnROZXdGaWxlU2VjdGlvbiAvPlxuICAgICAgICApfVxuXG4gICAgICAgIHtmaW5hbmNpYWxTdGF0ZW1lbnRGaWxlcyAmJiBmaW5hbmNpYWxTdGF0ZW1lbnRGaWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8RmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFZlcnNpb25zU2VjdGlvbiAvPlxuICAgICAgICApfVxuICAgICAgPC9BcHBQYWdlPlxuICAgIDwvRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2VDb250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmZ1bmN0aW9uIGdldEZpbGVXaXRoVmVyc2lvbmVkTmFtZSAoZmlsZTogRmlsZSwgdmVyc2lvbj86IG51bWJlcikge1xuICBjb25zdCBmaWxlRXh0ZW5zaW9uID0gZmlsZS5uYW1lLnNwbGl0KCcuJykucG9wKCkgYXMgc3RyaW5nXG4gIGNvbnN0IGZpbGVOYW1lID0gZmlsZS5uYW1lLnNwbGl0KGAuJHtmaWxlRXh0ZW5zaW9ufWApWzBdXG4gIGNvbnN0IGZpbGVWZXJzaW9uID0gdmVyc2lvbiA/IHZlcnNpb24gKyAxIDogMVxuXG4gIGNvbnN0IGZpbGVXaXRoVmVyc2lvbiA9IG5ldyBGaWxlKFxuICAgIFtmaWxlXSxcbiAgICBgJHtmaWxlTmFtZX1fdiR7ZmlsZVZlcnNpb259LiR7ZmlsZUV4dGVuc2lvbi50b0xvd2VyQ2FzZSgpfWAsXG4gICAgeyB0eXBlOiBmaWxlLnR5cGUgfSxcbiAgKVxuXG4gIHJldHVybiBmaWxlV2l0aFZlcnNpb25cbn1cblxuZXhwb3J0IGRlZmF1bHQgRmluYW5jaWFsU3RhdGVtZW50c0ltcG9ydFBhZ2VcbiJdfQ==