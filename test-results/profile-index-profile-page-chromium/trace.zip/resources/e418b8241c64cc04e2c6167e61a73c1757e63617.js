import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/ForgotPasswordPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ForgotPasswordPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ForgotPasswordForm } from "/src/modules/auth/components/index.ts?t=1701096626433";
import AuthPageBoilerplate from "/src/modules/auth/pages/AuthPageBoilerplate.tsx?t=1701096626433";
const ForgotPasswordPage = () => {
  return /* @__PURE__ */ jsxDEV(AuthPageBoilerplate, { children: /* @__PURE__ */ jsxDEV(ForgotPasswordForm, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ForgotPasswordPage.tsx",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ForgotPasswordPage.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = ForgotPasswordPage;
export default ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ForgotPasswordPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTiwyQkFBMkI7QUFBUTtBQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWxELE9BQU9BLHlCQUF5QjtBQUVoQyxNQUFNQyxxQkFBeUJBLE1BQU07QUFDbkMsU0FDRSx1QkFBQyx1QkFDQyxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBTktEO0FBUU4sZUFBZUE7QUFBa0IsSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkF1dGhQYWdlQm9pbGVycGxhdGUiLCJGb3Jnb3RQYXNzd29yZFBhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZvcmdvdFBhc3N3b3JkUGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1dGgvcGFnZXMvRm9yZ290UGFzc3dvcmRQYWdlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZvcmdvdFBhc3N3b3JkRm9ybSB9IGZyb20gJy4uL2NvbXBvbmVudHMnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEF1dGhQYWdlQm9pbGVycGxhdGUgZnJvbSAnLi9BdXRoUGFnZUJvaWxlcnBsYXRlJ1xuXG5jb25zdCBGb3Jnb3RQYXNzd29yZFBhZ2U6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxBdXRoUGFnZUJvaWxlcnBsYXRlID5cbiAgICAgIDxGb3Jnb3RQYXNzd29yZEZvcm0gLz5cbiAgICA8LyBBdXRoUGFnZUJvaWxlcnBsYXRlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEZvcmdvdFBhc3N3b3JkUGFnZVxuIl19