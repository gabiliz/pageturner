import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/RegulatoryBodyDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/RegulatoryBodyDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { RegulatoryBodyEnum } from "/src/shared/enums/RegulatoryBodyEnum.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const RegulatoryBodyDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Órgão regulador", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione o órgão regulador", styles: {
    root: {
      minWidth: 100
    }
  }, calloutProps: {
    calloutMinWidth: 180
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/RegulatoryBodyDropdown.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = RegulatoryBodyDropdown;
const months = [{
  key: RegulatoryBodyEnum.CVM,
  text: "CVM"
}, {
  key: RegulatoryBodyEnum.ANS,
  text: "ANS"
}, {
  key: RegulatoryBodyEnum.ANEEL,
  text: "ANEEL"
}, {
  key: RegulatoryBodyEnum.SUSEP,
  text: "SUSEP"
}, {
  key: RegulatoryBodyEnum.ANTT,
  text: "ANTT"
}, {
  key: RegulatoryBodyEnum.BACEN,
  text: "BACEN"
}, {
  key: RegulatoryBodyEnum.CFC,
  text: "CFC"
}];
export default RegulatoryBodyDropdown;
var _c;
$RefreshReg$(_c, "RegulatoryBodyDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/RegulatoryBodyDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMseUJBQXVEQyxXQUFVO0FBQ3JFLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLG1CQUNOLFNBQVNDLFFBQ1QsZUFBZSxNQUNmLGNBQWEsTUFDYixhQUFZLCtCQUNaLFFBQVE7QUFBQSxJQUNOQyxNQUFNO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQUk7QUFBQSxFQUN4QixHQUNBLGNBQWM7QUFBQSxJQUNaQyxpQkFBaUI7QUFBQSxFQUNuQixHQUNBLEdBQUlKLFNBWk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlZO0FBR2hCO0FBQUNLLEtBakJLTjtBQW1CTixNQUFNRSxTQUE0QixDQUNoQztBQUFBLEVBQUVLLEtBQUtULG1CQUFtQlU7QUFBQUEsRUFBS0MsTUFBTTtBQUFNLEdBQzNDO0FBQUEsRUFBRUYsS0FBS1QsbUJBQW1CWTtBQUFBQSxFQUFLRCxNQUFNO0FBQU0sR0FDM0M7QUFBQSxFQUFFRixLQUFLVCxtQkFBbUJhO0FBQUFBLEVBQU9GLE1BQU07QUFBUSxHQUMvQztBQUFBLEVBQUVGLEtBQUtULG1CQUFtQmM7QUFBQUEsRUFBT0gsTUFBTTtBQUFRLEdBQy9DO0FBQUEsRUFBRUYsS0FBS1QsbUJBQW1CZTtBQUFBQSxFQUFNSixNQUFNO0FBQU8sR0FDN0M7QUFBQSxFQUFFRixLQUFLVCxtQkFBbUJnQjtBQUFBQSxFQUFPTCxNQUFNO0FBQVEsR0FDL0M7QUFBQSxFQUFFRixLQUFLVCxtQkFBbUJpQjtBQUFBQSxFQUFLTixNQUFNO0FBQU0sQ0FBQztBQUk5QyxlQUFlVDtBQUFzQixJQUFBTTtBQUFBVSxhQUFBVixJQUFBIiwibmFtZXMiOlsiSUNvbWJvQm94UHJvcHMiLCJSZWd1bGF0b3J5Qm9keUVudW0iLCJDb21ib0JveCIsIlJlZ3VsYXRvcnlCb2R5RHJvcGRvd24iLCJwcm9wcyIsIm1vbnRocyIsInJvb3QiLCJtaW5XaWR0aCIsImNhbGxvdXRNaW5XaWR0aCIsIl9jIiwia2V5IiwiQ1ZNIiwidGV4dCIsIkFOUyIsIkFORUVMIiwiU1VTRVAiLCJBTlRUIiwiQkFDRU4iLCJDRkMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZWd1bGF0b3J5Qm9keURyb3Bkb3duLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2Ryb3Bkb3duc0NvbWJvQm94ZXMvUmVndWxhdG9yeUJvZHlEcm9wZG93bi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIElDb21ib0JveE9wdGlvbixcclxuICBJQ29tYm9Cb3hQcm9wcyxcclxufSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IFJlZ3VsYXRvcnlCb2R5RW51bSB9IGZyb20gJy4uLy4uL2VudW1zL1JlZ3VsYXRvcnlCb2R5RW51bSdcclxuaW1wb3J0IHsgQ29tYm9Cb3ggfSBmcm9tICcuLi9jb21ib0JveCdcclxuXHJcbmNvbnN0IFJlZ3VsYXRvcnlCb2R5RHJvcGRvd246IEZDPFBhcnRpYWw8SUNvbWJvQm94UHJvcHM+PiA9IChwcm9wcykgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Q29tYm9Cb3hcclxuICAgICAgbGFiZWw9XCLDk3Jnw6NvIHJlZ3VsYWRvclwiXHJcbiAgICAgIG9wdGlvbnM9e21vbnRoc31cclxuICAgICAgYWxsb3dGcmVlZm9ybT17dHJ1ZX1cclxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcclxuICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY2lvbmUgbyDDs3Jnw6NvIHJlZ3VsYWRvclwiXHJcbiAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgIHJvb3Q6IHsgbWluV2lkdGg6IDEwMCB9LFxyXG4gICAgICB9fVxyXG4gICAgICBjYWxsb3V0UHJvcHM9e3tcclxuICAgICAgICBjYWxsb3V0TWluV2lkdGg6IDE4MCxcclxuICAgICAgfX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IG1vbnRoczogSUNvbWJvQm94T3B0aW9uW10gPSBbXHJcbiAgeyBrZXk6IFJlZ3VsYXRvcnlCb2R5RW51bS5DVk0sIHRleHQ6ICdDVk0nIH0sXHJcbiAgeyBrZXk6IFJlZ3VsYXRvcnlCb2R5RW51bS5BTlMsIHRleHQ6ICdBTlMnIH0sXHJcbiAgeyBrZXk6IFJlZ3VsYXRvcnlCb2R5RW51bS5BTkVFTCwgdGV4dDogJ0FORUVMJyB9LFxyXG4gIHsga2V5OiBSZWd1bGF0b3J5Qm9keUVudW0uU1VTRVAsIHRleHQ6ICdTVVNFUCcgfSxcclxuICB7IGtleTogUmVndWxhdG9yeUJvZHlFbnVtLkFOVFQsIHRleHQ6ICdBTlRUJyB9LFxyXG4gIHsga2V5OiBSZWd1bGF0b3J5Qm9keUVudW0uQkFDRU4sIHRleHQ6ICdCQUNFTicgfSxcclxuICB7IGtleTogUmVndWxhdG9yeUJvZHlFbnVtLkNGQywgdGV4dDogJ0NGQycgfSxcclxuXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlZ3VsYXRvcnlCb2R5RHJvcGRvd25cclxuIl19