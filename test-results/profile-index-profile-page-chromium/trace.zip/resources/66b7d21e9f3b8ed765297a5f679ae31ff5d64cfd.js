import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/pages/ConfirmAccountPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ConfirmAccountPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { ChangePasswordForm } from "/src/modules/auth/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import AuthPageBoilerplate from "/src/modules/auth/pages/AuthPageBoilerplate.tsx?t=1701096626433";
const ConfirmAccountPage = () => {
  _s();
  const {
    login
  } = useAuth();
  return /* @__PURE__ */ jsxDEV(AuthPageBoilerplate, { children: /* @__PURE__ */ jsxDEV(ChangePasswordForm, { firstLogin: true, title: "Crie sua senha", subtitle: "", submitForm: login }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ConfirmAccountPage.tsx",
    lineNumber: 12,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ConfirmAccountPage.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
};
_s(ConfirmAccountPage, "UHkfWqKqWotCJBriqTc0XaXAMSw=", false, function() {
  return [useAuth];
});
_c = ConfirmAccountPage;
export default ConfirmAccountPage;
var _c;
$RefreshReg$(_c, "ConfirmAccountPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/pages/ConfirmAccountPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFSTixTQUFTQSwwQkFBMEI7QUFDbkMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyx5QkFBeUI7QUFFaEMsTUFBTUMscUJBQXlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU0sSUFBSUosUUFBUTtBQUMxQixTQUNFLHVCQUFDLHVCQUNDLGlDQUFDLHNCQUNDLFlBQVksTUFDWixPQUFNLGtCQUNOLFVBQVMsSUFDVCxZQUFZSSxTQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJb0IsS0FMdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0QsR0FaS0Qsb0JBQXNCO0FBQUEsVUFDUkYsT0FBTztBQUFBO0FBQUFLLEtBRHJCSDtBQWNOLGVBQWVBO0FBQWtCLElBQUFHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDaGFuZ2VQYXNzd29yZEZvcm0iLCJ1c2VBdXRoIiwiQXV0aFBhZ2VCb2lsZXJwbGF0ZSIsIkNvbmZpcm1BY2NvdW50UGFnZSIsIl9zIiwibG9naW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbmZpcm1BY2NvdW50UGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1dGgvcGFnZXMvQ29uZmlybUFjY291bnRQYWdlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDaGFuZ2VQYXNzd29yZEZvcm0gfSBmcm9tICcuLi9jb21wb25lbnRzJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL3N0b3JlL2F1dGgnXG5pbXBvcnQgQXV0aFBhZ2VCb2lsZXJwbGF0ZSBmcm9tICcuL0F1dGhQYWdlQm9pbGVycGxhdGUnXG5cbmNvbnN0IENvbmZpcm1BY2NvdW50UGFnZTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgbG9naW4gfSA9IHVzZUF1dGgoKVxuICByZXR1cm4gKFxuICAgIDxBdXRoUGFnZUJvaWxlcnBsYXRlID5cbiAgICAgIDxDaGFuZ2VQYXNzd29yZEZvcm1cbiAgICAgICAgZmlyc3RMb2dpbj17dHJ1ZX1cbiAgICAgICAgdGl0bGU9J0NyaWUgc3VhIHNlbmhhJ1xuICAgICAgICBzdWJ0aXRsZT0nJ1xuICAgICAgICBzdWJtaXRGb3JtPXtsb2dpbn1cbiAgICAgIC8+XG4gICAgPC8gQXV0aFBhZ2VCb2lsZXJwbGF0ZT5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb25maXJtQWNjb3VudFBhZ2VcbiJdfQ==