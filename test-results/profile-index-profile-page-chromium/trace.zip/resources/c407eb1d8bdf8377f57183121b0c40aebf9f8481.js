import "/node_modules/.vite/deps/chunk-5LGHICQB.js?v=9f90a7ff";
import {
  Adaptor,
  CacheAdaptor,
  CustomDataAdaptor,
  DataManager,
  DataUtil,
  Deferred,
  GraphQLAdaptor,
  JsonAdaptor,
  ODataAdaptor,
  ODataV4Adaptor,
  Predicate,
  Query,
  RemoteSaveAdaptor,
  UrlAdaptor,
  WebApiAdaptor,
  WebMethodAdaptor
} from "/node_modules/.vite/deps/chunk-4PYC4G6P.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-VAAK7ILH.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";
export {
  Adaptor,
  CacheAdaptor,
  CustomDataAdaptor,
  DataManager,
  DataUtil,
  Deferred,
  GraphQLAdaptor,
  JsonAdaptor,
  ODataAdaptor,
  ODataV4Adaptor,
  Predicate,
  Query,
  RemoteSaveAdaptor,
  UrlAdaptor,
  WebApiAdaptor,
  WebMethodAdaptor
};
//# sourceMappingURL=@syncfusion_ej2-data.js.map
