import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/SecondarySideMenu.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SecondarySideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Nav } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const SecondarySideMenu = (props) => {
  _s();
  const navStyles = useNavStyles();
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(Nav, { styles: navStyles, groups: props.groups, onLinkClick: props.onLinkClick, selectedKey: props.selectedKey }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SecondarySideMenu.tsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SecondarySideMenu.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_s(SecondarySideMenu, "Ph+FSn6ziGsX/DWvVpdSJxZkzTw=", false, function() {
  return [useNavStyles];
});
_c = SecondarySideMenu;
const useNavStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return () => ({
    root: {
      width: 260
    },
    chevronButton: {
      fontSize: 14,
      borderBottom: "none"
    },
    groupContent: {
      margin: 0
    },
    link: {
      color: colors.gray[400],
      "&> * > .ms-Button-icon:not(:empty)": {
        marginLeft: "28px",
        color: colors.black
      },
      "&.is-selected .flexContainer .linkText": {
        color: colors.purple[600],
        fontWeight: 600
      },
      "::after": {
        borderLeft: "none"
      },
      ".ms-Nav-linkText": {
        color: colors.gray[600]
      }
    },
    compositeLink: {
      "> button": {
        padding: 0
      },
      "&.is-selected .ms-Nav-linkText": {
        color: colors.purple[600]
      },
      "&.is-selected > .ms-Nav-link": {
        backgroundColor: "#f5f5f5"
      },
      ".ms-Nav-link:hover .ms-Nav-linkText": {
        color: colors.purple[300]
      },
      "&.is-selected .ms-Nav-link .ms-Icon": {
        color: colors.purple[300]
      },
      "& > button.is-disabled .ms-Icon": {
        color: colors.gray[300]
      },
      "& > button.is-disabled .ms-Nav-linkText": {
        color: colors.gray[300]
      },
      ".ms-Nav-link:hover .ms-Icon": {
        color: colors.purple[300]
      },
      "&:not(.is-selected):hover .ms-Nav-link": {
        filter: "brightness(0.98)",
        backgroundColor: colors.gray[200]
      }
    }
  });
};
_s2(useNavStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default SecondarySideMenu;
var _c;
$RefreshReg$(_c, "SecondarySideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SecondarySideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0ksbUJBQ0UsY0FERjs7Ozs7Ozs7Ozs7Ozs7OztBQVBKLFNBQWdDQSxXQUFXO0FBRTNDLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxvQkFBb0NDLFdBQVU7QUFBQUMsS0FBQTtBQUNsRCxRQUFNQyxZQUFZQyxhQUFhO0FBQy9CLFNBQ0UsbUNBQ0UsaUNBQUMsT0FDQyxRQUFRRCxXQUNSLFFBQVFGLE1BQU1JLFFBQ2QsYUFBYUosTUFBTUssYUFDbkIsYUFBYUwsTUFBTU0sZUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlpQyxLQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDTCxHQVpLRixtQkFBZ0M7QUFBQSxVQUNsQkksWUFBWTtBQUFBO0FBQUFJLEtBRDFCUjtBQWNOLE1BQU1JLGVBQWVBLE1BQU07QUFBQUssTUFBQTtBQUN6QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJWCxTQUFTO0FBRTVCLFNBQU8sT0FBNEI7QUFBQSxJQUNqQ1ksTUFBTTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQUMsZUFBZTtBQUFBLE1BQ2JDLFVBQVU7QUFBQSxNQUNWQyxjQUFjO0FBQUEsSUFDaEI7QUFBQSxJQUNBQyxjQUFjO0FBQUEsTUFDWkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBQyxNQUFNO0FBQUEsTUFDSkMsT0FBT1QsT0FBT1UsS0FBSyxHQUFHO0FBQUEsTUFDdEIsc0NBQXNDO0FBQUEsUUFDcENDLFlBQVk7QUFBQSxRQUNaRixPQUFPVCxPQUFPWTtBQUFBQSxNQUNoQjtBQUFBLE1BQ0EsMENBQTBDO0FBQUEsUUFDeENILE9BQU9ULE9BQU9hLE9BQU8sR0FBRztBQUFBLFFBQ3hCQyxZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1RDLFlBQVk7QUFBQSxNQUNkO0FBQUEsTUFDQSxvQkFBb0I7QUFBQSxRQUNsQk4sT0FBT1QsT0FBT1UsS0FBSyxHQUFHO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBQUEsSUFDQU0sZUFBZTtBQUFBLE1BQ2IsWUFBWTtBQUFBLFFBQ1ZDLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQSxrQ0FBa0M7QUFBQSxRQUNoQ1IsT0FBT1QsT0FBT2EsT0FBTyxHQUFHO0FBQUEsTUFDMUI7QUFBQSxNQUNBLGdDQUFnQztBQUFBLFFBQzlCSyxpQkFBaUI7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsdUNBQXVDO0FBQUEsUUFDckNULE9BQU9ULE9BQU9hLE9BQU8sR0FBRztBQUFBLE1BQzFCO0FBQUEsTUFDQSx1Q0FBdUM7QUFBQSxRQUNyQ0osT0FBT1QsT0FBT2EsT0FBTyxHQUFHO0FBQUEsTUFDMUI7QUFBQSxNQUNBLG1DQUFtQztBQUFBLFFBQ2pDSixPQUFPVCxPQUFPVSxLQUFLLEdBQUc7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsMkNBQTJDO0FBQUEsUUFDekNELE9BQU9ULE9BQU9VLEtBQUssR0FBRztBQUFBLE1BQ3hCO0FBQUEsTUFDQSwrQkFBK0I7QUFBQSxRQUM3QkQsT0FBT1QsT0FBT2EsT0FBTyxHQUFHO0FBQUEsTUFDMUI7QUFBQSxNQUNBLDBDQUEwQztBQUFBLFFBQ3hDTSxRQUFRO0FBQUEsUUFDUkQsaUJBQWlCbEIsT0FBT1UsS0FBSyxHQUFHO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQUNYLElBOURLTCxjQUFZO0FBQUEsVUFDR0wsUUFBUTtBQUFBO0FBK0Q3QixlQUFlQztBQUFpQixJQUFBUTtBQUFBc0IsYUFBQXRCLElBQUEiLCJuYW1lcyI6WyJOYXYiLCJ1c2VUaGVtZSIsIlNlY29uZGFyeVNpZGVNZW51IiwicHJvcHMiLCJfcyIsIm5hdlN0eWxlcyIsInVzZU5hdlN0eWxlcyIsImdyb3VwcyIsIm9uTGlua0NsaWNrIiwic2VsZWN0ZWRLZXkiLCJfYyIsIl9zMiIsImNvbG9ycyIsInJvb3QiLCJ3aWR0aCIsImNoZXZyb25CdXR0b24iLCJmb250U2l6ZSIsImJvcmRlckJvdHRvbSIsImdyb3VwQ29udGVudCIsIm1hcmdpbiIsImxpbmsiLCJjb2xvciIsImdyYXkiLCJtYXJnaW5MZWZ0IiwiYmxhY2siLCJwdXJwbGUiLCJmb250V2VpZ2h0IiwiYm9yZGVyTGVmdCIsImNvbXBvc2l0ZUxpbmsiLCJwYWRkaW5nIiwiYmFja2dyb3VuZENvbG9yIiwiZmlsdGVyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2Vjb25kYXJ5U2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0L1NlY29uZGFyeVNpZGVNZW51LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElOYXZQcm9wcywgSU5hdlN0eWxlcywgTmF2IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5cbmNvbnN0IFNlY29uZGFyeVNpZGVNZW51OiBGQzxJTmF2UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IG5hdlN0eWxlcyA9IHVzZU5hdlN0eWxlcygpXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxOYXZcbiAgICAgICAgc3R5bGVzPXtuYXZTdHlsZXN9XG4gICAgICAgIGdyb3Vwcz17cHJvcHMuZ3JvdXBzfVxuICAgICAgICBvbkxpbmtDbGljaz17cHJvcHMub25MaW5rQ2xpY2t9XG4gICAgICAgIHNlbGVjdGVkS2V5PXtwcm9wcy5zZWxlY3RlZEtleX1cbiAgICAgIC8+XG4gICAgPC8+XG4gIClcbn1cblxuY29uc3QgdXNlTmF2U3R5bGVzID0gKCkgPT4ge1xuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiAoKTogUGFydGlhbDxJTmF2U3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIHdpZHRoOiAyNjAsXG4gICAgfSxcbiAgICBjaGV2cm9uQnV0dG9uOiB7XG4gICAgICBmb250U2l6ZTogMTQsXG4gICAgICBib3JkZXJCb3R0b206ICdub25lJyxcbiAgICB9LFxuICAgIGdyb3VwQ29udGVudDoge1xuICAgICAgbWFyZ2luOiAwLFxuICAgIH0sXG4gICAgbGluazoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzQwMF0sXG4gICAgICAnJj4gKiA+IC5tcy1CdXR0b24taWNvbjpub3QoOmVtcHR5KSc6IHtcbiAgICAgICAgbWFyZ2luTGVmdDogJzI4cHgnLFxuICAgICAgICBjb2xvcjogY29sb3JzLmJsYWNrLFxuICAgICAgfSxcbiAgICAgICcmLmlzLXNlbGVjdGVkIC5mbGV4Q29udGFpbmVyIC5saW5rVGV4dCc6IHtcbiAgICAgICAgY29sb3I6IGNvbG9ycy5wdXJwbGVbNjAwXSxcbiAgICAgICAgZm9udFdlaWdodDogNjAwLFxuICAgICAgfSxcbiAgICAgICc6OmFmdGVyJzoge1xuICAgICAgICBib3JkZXJMZWZ0OiAnbm9uZScsXG4gICAgICB9LFxuICAgICAgJy5tcy1OYXYtbGlua1RleHQnOiB7XG4gICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGNvbXBvc2l0ZUxpbms6IHtcbiAgICAgICc+IGJ1dHRvbic6IHtcbiAgICAgICAgcGFkZGluZzogMCxcbiAgICAgIH0sXG4gICAgICAnJi5pcy1zZWxlY3RlZCAubXMtTmF2LWxpbmtUZXh0Jzoge1xuICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs2MDBdLFxuICAgICAgfSxcbiAgICAgICcmLmlzLXNlbGVjdGVkID4gLm1zLU5hdi1saW5rJzoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZjVmNWY1JyxcbiAgICAgIH0sXG4gICAgICAnLm1zLU5hdi1saW5rOmhvdmVyIC5tcy1OYXYtbGlua1RleHQnOiB7XG4gICAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzMwMF0sXG4gICAgICB9LFxuICAgICAgJyYuaXMtc2VsZWN0ZWQgLm1zLU5hdi1saW5rIC5tcy1JY29uJzoge1xuICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVszMDBdLFxuICAgICAgfSxcbiAgICAgICcmID4gYnV0dG9uLmlzLWRpc2FibGVkIC5tcy1JY29uJzoge1xuICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbMzAwXSxcbiAgICAgIH0sXG4gICAgICAnJiA+IGJ1dHRvbi5pcy1kaXNhYmxlZCAubXMtTmF2LWxpbmtUZXh0Jzoge1xuICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbMzAwXSxcbiAgICAgIH0sXG4gICAgICAnLm1zLU5hdi1saW5rOmhvdmVyIC5tcy1JY29uJzoge1xuICAgICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVszMDBdLFxuICAgICAgfSxcbiAgICAgICcmOm5vdCguaXMtc2VsZWN0ZWQpOmhvdmVyIC5tcy1OYXYtbGluayc6IHtcbiAgICAgICAgZmlsdGVyOiAnYnJpZ2h0bmVzcygwLjk4KScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2Vjb25kYXJ5U2lkZU1lbnVcbiJdfQ==