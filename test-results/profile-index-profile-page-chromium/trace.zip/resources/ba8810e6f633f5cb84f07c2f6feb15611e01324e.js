import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/card/Card.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/card/Card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { useTheme as useThemeFluent, mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const Card = (props) => {
  _s();
  const cardStyles = useCardStyles(props);
  return /* @__PURE__ */ jsxDEV("div", { className: cardStyles, onClick: props.onClick, children: props.children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/card/Card.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(Card, "xBc/FcH/WJjEtuSANDkaZxwpGDk=", false, function() {
  return [useCardStyles];
});
_c = Card;
const useCardStyles = (props) => {
  _s2();
  const {
    effects
  } = useThemeFluent();
  const {
    colors,
    spacing
  } = useTheme();
  return mergeStyles({
    overflow: props.overflow,
    scrollbarWidth: "thin",
    scrollbarColor: "#D8D8D8 #f2f2f2",
    height: props.height,
    minHeight: props.minHeight,
    maxHeight: props.maxHeight,
    minWidth: props.minWidth,
    maxWidth: props.maxWidth,
    backgroundColor: props.background ?? colors.white,
    boxShadow: props.boxShadow ?? effects.elevation8,
    padding: props.padding ?? spacing.lg,
    border: props.border,
    borderLeft: props.borderLeft,
    borderRadius: props.radius,
    boxSizing: "border-box",
    ":hover": props.hasHover && {
      boxShadow: "2px 2px 10px 1px rgba(0, 0, 0, 0.2)",
      cursor: "pointer"
    }
  });
};
_s2(useCardStyles, "A4NIWozA3YMdceeri9AlFaHJcUI=", false, function() {
  return [useThemeFluent, useTheme];
});
export default Card;
var _c;
$RefreshReg$(_c, "Card");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/card/Card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBeEJKLFNBQVNBLFlBQVlDLGdCQUFnQkMsbUJBQW1CO0FBQ3hELFNBQVNGLGdCQUFnQjtBQW9CekIsTUFBTUcsT0FBdUJDLFdBQVU7QUFBQUMsS0FBQTtBQUNyQyxRQUFNQyxhQUFhQyxjQUFjSCxLQUFLO0FBQ3RDLFNBQ0UsdUJBQUMsU0FBSSxXQUFXRSxZQUFZLFNBQVNGLE1BQU1JLFNBQ3hDSixnQkFBTUssWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDSixHQVBLRixNQUFtQjtBQUFBLFVBQ0pJLGFBQWE7QUFBQTtBQUFBRyxLQUQ1QlA7QUFTTixNQUFNSSxnQkFBZ0JBLENBQUNILFVBQXFCO0FBQUFPLE1BQUE7QUFDMUMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVEsSUFBSVgsZUFBZTtBQUNuQyxRQUFNO0FBQUEsSUFBRVk7QUFBQUEsSUFBUUM7QUFBQUEsRUFBUSxJQUFJZCxTQUFTO0FBQ3JDLFNBQU9FLFlBQVk7QUFBQSxJQUNqQmEsVUFBVVgsTUFBTVc7QUFBQUEsSUFDaEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUWQsTUFBTWM7QUFBQUEsSUFDZEMsV0FBV2YsTUFBTWU7QUFBQUEsSUFDakJDLFdBQVdoQixNQUFNZ0I7QUFBQUEsSUFDakJDLFVBQVVqQixNQUFNaUI7QUFBQUEsSUFDaEJDLFVBQVVsQixNQUFNa0I7QUFBQUEsSUFDaEJDLGlCQUFpQm5CLE1BQU1vQixjQUFjWCxPQUFPWTtBQUFBQSxJQUM1Q0MsV0FBV3RCLE1BQU1zQixhQUFhZCxRQUFRZTtBQUFBQSxJQUN0Q0MsU0FBU3hCLE1BQU13QixXQUFXZCxRQUFRZTtBQUFBQSxJQUNsQ0MsUUFBUTFCLE1BQU0wQjtBQUFBQSxJQUNkQyxZQUFZM0IsTUFBTTJCO0FBQUFBLElBQ2xCQyxjQUFjNUIsTUFBTTZCO0FBQUFBLElBQ3BCQyxXQUFXO0FBQUEsSUFDWCxVQUFVOUIsTUFBTStCLFlBQVk7QUFBQSxNQUMxQlQsV0FBVztBQUFBLE1BQ1hVLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ3pCLElBeEJLSixlQUFhO0FBQUEsVUFDR04sZ0JBQ1FELFFBQVE7QUFBQTtBQXdCdEMsZUFBZUc7QUFBSSxJQUFBTztBQUFBMkIsYUFBQTNCLElBQUEiLCJuYW1lcyI6WyJ1c2VUaGVtZSIsInVzZVRoZW1lRmx1ZW50IiwibWVyZ2VTdHlsZXMiLCJDYXJkIiwicHJvcHMiLCJfcyIsImNhcmRTdHlsZXMiLCJ1c2VDYXJkU3R5bGVzIiwib25DbGljayIsImNoaWxkcmVuIiwiX2MiLCJfczIiLCJlZmZlY3RzIiwiY29sb3JzIiwic3BhY2luZyIsIm92ZXJmbG93Iiwic2Nyb2xsYmFyV2lkdGgiLCJzY3JvbGxiYXJDb2xvciIsImhlaWdodCIsIm1pbkhlaWdodCIsIm1heEhlaWdodCIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJiYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kIiwid2hpdGUiLCJib3hTaGFkb3ciLCJlbGV2YXRpb244IiwicGFkZGluZyIsImxnIiwiYm9yZGVyIiwiYm9yZGVyTGVmdCIsImJvcmRlclJhZGl1cyIsInJhZGl1cyIsImJveFNpemluZyIsImhhc0hvdmVyIiwiY3Vyc29yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FyZC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9jYXJkL0NhcmQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlVGhlbWUgYXMgdXNlVGhlbWVGbHVlbnQsIG1lcmdlU3R5bGVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xyXG5pbXBvcnQgeyBJQ1NTUnVsZSB9IGZyb20gJ0B1aWZhYnJpYy9tZXJnZS1zdHlsZXMnXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENhcmRQcm9wcyB7XHJcbiAgYmFja2dyb3VuZD86IHN0cmluZ1xyXG4gIGJveFNoYWRvdz86IHN0cmluZ1xyXG4gIGJvcmRlcj86IHN0cmluZ1xyXG4gIGJvcmRlckxlZnQ/OiBzdHJpbmdcclxuICByYWRpdXM/OiBzdHJpbmdcclxuICBvbkNsaWNrPzogKCkgPT4gdm9pZFxyXG4gIGhhc0hvdmVyPzogYm9vbGVhblxyXG4gIHBhZGRpbmc/OiBzdHJpbmdcclxuICBoZWlnaHQ/OiBzdHJpbmd8bnVtYmVyXHJcbiAgbWluSGVpZ2h0Pzogc3RyaW5nfG51bWJlclxyXG4gIG1heEhlaWdodD86IHN0cmluZ3xudW1iZXJcclxuICBtaW5XaWR0aD86IHN0cmluZ3xudW1iZXJcclxuICBtYXhXaWR0aD86IHN0cmluZ3xudW1iZXJcclxuICBvdmVyZmxvdz86IElDU1NSdWxlIHwgJ2F1dG8nIHwgJ2hpZGRlbicgfCAnc2Nyb2xsJyB8ICd2aXNpYmxlJ1xyXG59XHJcblxyXG5jb25zdCBDYXJkOiBGQzxDYXJkUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgY2FyZFN0eWxlcyA9IHVzZUNhcmRTdHlsZXMocHJvcHMpXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtjYXJkU3R5bGVzfSBvbkNsaWNrPXtwcm9wcy5vbkNsaWNrfT5cclxuICAgICAge3Byb3BzLmNoaWxkcmVufVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VDYXJkU3R5bGVzID0gKHByb3BzOiBDYXJkUHJvcHMpID0+IHtcclxuICBjb25zdCB7IGVmZmVjdHMgfSA9IHVzZVRoZW1lRmx1ZW50KClcclxuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxyXG4gIHJldHVybiBtZXJnZVN0eWxlcyh7XHJcbiAgICBvdmVyZmxvdzogcHJvcHMub3ZlcmZsb3csXHJcbiAgICBzY3JvbGxiYXJXaWR0aDogJ3RoaW4nLFxyXG4gICAgc2Nyb2xsYmFyQ29sb3I6ICcjRDhEOEQ4ICNmMmYyZjInLFxyXG4gICAgaGVpZ2h0OiBwcm9wcy5oZWlnaHQsXHJcbiAgICBtaW5IZWlnaHQ6IHByb3BzLm1pbkhlaWdodCxcclxuICAgIG1heEhlaWdodDogcHJvcHMubWF4SGVpZ2h0LFxyXG4gICAgbWluV2lkdGg6IHByb3BzLm1pbldpZHRoLFxyXG4gICAgbWF4V2lkdGg6IHByb3BzLm1heFdpZHRoLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiBwcm9wcy5iYWNrZ3JvdW5kID8/IGNvbG9ycy53aGl0ZSxcclxuICAgIGJveFNoYWRvdzogcHJvcHMuYm94U2hhZG93ID8/IGVmZmVjdHMuZWxldmF0aW9uOCxcclxuICAgIHBhZGRpbmc6IHByb3BzLnBhZGRpbmcgPz8gc3BhY2luZy5sZyxcclxuICAgIGJvcmRlcjogcHJvcHMuYm9yZGVyLFxyXG4gICAgYm9yZGVyTGVmdDogcHJvcHMuYm9yZGVyTGVmdCxcclxuICAgIGJvcmRlclJhZGl1czogcHJvcHMucmFkaXVzLFxyXG4gICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXHJcbiAgICAnOmhvdmVyJzogcHJvcHMuaGFzSG92ZXIgJiYge1xyXG4gICAgICBib3hTaGFkb3c6ICcycHggMnB4IDEwcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4yKScsXHJcbiAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXJkXHJcbiJdfQ==