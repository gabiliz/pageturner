import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexItem } from "/src/shared/components/FlexBox/index.ts";
import NotNotificationImg from "/src/shared/components/notifications/images/notNotifications.svg?import";
const NotificationsCenterEmpty = () => {
  _s();
  const {
    colors
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(FlexColumn, { verticalAlign: "center", horizontalAlign: "center", margin: "50px 0 0 0", gap: 20, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV("img", { src: NotNotificationImg, alt: "icon" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
      lineNumber: 14,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", verticalAlign: "center", gap: 8, children: /* @__PURE__ */ jsxDEV(Text, { variant: "xxLarge", style: {
      color: colors.gray[600]
    }, children: "Você não tem novas notificações" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
      lineNumber: 18,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterEmpty, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
_c = NotificationsCenterEmpty;
export default NotificationsCenterEmpty;
var _c;
$RefreshReg$(_c, "NotificationsCenterEmpty");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJSLFNBQVNBLFlBQVk7QUFFckIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVlDLGdCQUFnQjtBQUNyQyxPQUFPQyx3QkFBd0I7QUFFL0IsTUFBTUMsMkJBQStCQSxNQUFNO0FBQUFDLEtBQUE7QUFDekMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSU4sU0FBUztBQUM1QixTQUNFLHVCQUFDLGNBQ0MsZUFBYyxVQUNkLGlCQUFnQixVQUNoQixRQUFPLGNBQ1AsS0FBTSxJQUVOO0FBQUEsMkJBQUMsWUFDQyxpQ0FBQyxTQUFJLEtBQUtHLG9CQUFvQixLQUFJLFVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUNDLGlDQUFDLGNBQ0MsaUJBQWdCLFVBQ2hCLGVBQWMsVUFDZCxLQUFNLEdBRU4saUNBQUMsUUFDQyxTQUFRLFdBQ1IsT0FBTztBQUFBLE1BQUVJLE9BQU9ELE9BQU9FLEtBQUssR0FBRztBQUFBLElBQUUsR0FBRSwrQ0FGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUVKO0FBQUNILEdBNUJLRCwwQkFBNEI7QUFBQSxVQUNiSixRQUFRO0FBQUE7QUFBQVMsS0FEdkJMO0FBOEJOLGVBQWVBO0FBQXdCLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUZXh0IiwidXNlVGhlbWUiLCJGbGV4Q29sdW1uIiwiRmxleEl0ZW0iLCJOb3ROb3RpZmljYXRpb25JbWciLCJOb3RpZmljYXRpb25zQ2VudGVyRW1wdHkiLCJfcyIsImNvbG9ycyIsImNvbG9yIiwiZ3JheSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uc0NlbnRlckVtcHR5LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL25vdGlmaWNhdGlvbnMvY29tcG9uZW50cy9Ob3RpZmljYXRpb25zQ2VudGVyRW1wdHkudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzJ1xuaW1wb3J0IHsgRmxleENvbHVtbiwgRmxleEl0ZW0gfSBmcm9tICcuLi8uLi9GbGV4Qm94J1xuaW1wb3J0IE5vdE5vdGlmaWNhdGlvbkltZyBmcm9tICcuLi9pbWFnZXMvbm90Tm90aWZpY2F0aW9ucy5zdmcnXG5cbmNvbnN0IE5vdGlmaWNhdGlvbnNDZW50ZXJFbXB0eTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW5cbiAgICAgIHZlcnRpY2FsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgaG9yaXpvbnRhbEFsaWduPVwiY2VudGVyXCJcbiAgICAgIG1hcmdpbj1cIjUwcHggMCAwIDBcIlxuICAgICAgZ2FwPXsgMjAgfVxuICAgID5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPGltZyBzcmM9e05vdE5vdGlmaWNhdGlvbkltZ30gYWx0PVwiaWNvblwiIC8+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8RmxleENvbHVtblxuICAgICAgICAgIGhvcml6b250YWxBbGlnbj0nY2VudGVyJ1xuICAgICAgICAgIHZlcnRpY2FsQWxpZ249J2NlbnRlcidcbiAgICAgICAgICBnYXA9eyA4IH1cbiAgICAgICAgPlxuICAgICAgICAgIDxUZXh0XG4gICAgICAgICAgICB2YXJpYW50PSd4eExhcmdlJ1xuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0gfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgVm9jw6ogbsOjbyB0ZW0gbm92YXMgbm90aWZpY2HDp8O1ZXNcbiAgICAgICAgICA8L1RleHQ+XG4gICAgICAgIDwvRmxleENvbHVtbj5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgPC9GbGV4Q29sdW1uPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbnNDZW50ZXJFbXB0eVxuIl19