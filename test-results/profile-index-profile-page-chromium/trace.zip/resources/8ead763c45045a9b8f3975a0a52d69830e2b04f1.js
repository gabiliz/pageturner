import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/CurrencyInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/CurrencyInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const memo = __vite__cjsImport3_react["memo"];
import TextField from "/src/shared/components/inputs/TextField.tsx";
const DEFAULT_INPUT_VALUE = "0";
const DEFAULT_MAX_LENGTH = 12;
const CurrencyInput = (props) => {
  _s();
  const {
    value = 0,
    onChange,
    maxLength = DEFAULT_MAX_LENGTH,
    onlyPositive = false,
    ...otherProps
  } = props;
  const [maskedValue, setMaskedValue] = useState("0");
  const formatCurrency = (value2) => {
    const formattedValue = value2.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    return formattedValue;
  };
  const handleChange = useCallback((event, newValue) => {
    if (newValue === void 0)
      return;
    const numericValue = newValue.replace(onlyPositive ? /[^\d]/g : /[^\d-]/g, "") || DEFAULT_INPUT_VALUE;
    const formattedMaxLength = maxLength ? newValue.includes("-") ? maxLength + 1 : maxLength : void 0;
    const truncatedValue = numericValue.slice(0, formattedMaxLength);
    const normalizedValue = normalizeValue(truncatedValue);
    if (normalizedValue !== void 0) {
      const maskedValue2 = formatCurrency(normalizedValue);
      setMaskedValue(maskedValue2);
      onChange?.(event, normalizedValue);
    }
  }, [onChange, maxLength, onlyPositive]);
  useEffect(() => {
    setMaskedValue(formatCurrency(value || 0));
  }, [value]);
  return /* @__PURE__ */ jsxDEV(TextField, { value: maskedValue, onChange: handleChange, ...otherProps }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/CurrencyInput.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
};
_s(CurrencyInput, "QGHbnvsfWooJ5BiEdgeRLHuxu0c=");
_c = CurrencyInput;
const NEUTRAL_FACTOR = 1;
const NEGATIVE_FACTOR = -1;
function normalizeValue(value) {
  const isNegative = value.includes("-");
  let floatValue = parseFloat(value.replace(",", "."));
  floatValue = floatValue * (isNegative && floatValue >= 0 ? NEGATIVE_FACTOR : NEUTRAL_FACTOR);
  if (isNaN(floatValue))
    return;
  const normalizedValue = floatValue / 100;
  return normalizedValue;
}
export default _c2 = memo(CurrencyInput);
var _c, _c2;
$RefreshReg$(_c, "CurrencyInput");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/CurrencyInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRJOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0RKLFNBQWFBLFVBQVVDLFdBQVdDLGFBQWFDLFlBQVk7QUFFM0QsT0FBT0MsZUFBZTtBQVN0QixNQUFNQyxzQkFBc0I7QUFDNUIsTUFBTUMscUJBQXFCO0FBRTNCLE1BQU1DLGdCQUF5Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3ZELFFBQU07QUFBQSxJQUNKQyxRQUFRO0FBQUEsSUFDUkM7QUFBQUEsSUFDQUMsWUFBWU47QUFBQUEsSUFDWk8sZUFBZTtBQUFBLElBQ2YsR0FBR0M7QUFBQUEsRUFDTCxJQUFJTjtBQUVKLFFBQU0sQ0FBQ08sYUFBYUMsY0FBYyxJQUFJaEIsU0FBUyxHQUFHO0FBRWxELFFBQU1pQixpQkFBaUJBLENBQUNQLFdBQWtCO0FBQ3hDLFVBQU1RLGlCQUFpQlIsT0FBTVMsZUFBZSxTQUFTO0FBQUEsTUFDbkRDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsTUFDVkMsdUJBQXVCO0FBQUEsTUFDdkJDLHVCQUF1QjtBQUFBLElBQ3pCLENBQUM7QUFFRCxXQUFPTDtBQUFBQSxFQUNUO0FBRUEsUUFBTU0sZUFBZXRCLFlBQVksQ0FBQ3VCLE9BQWdCQyxhQUFzQjtBQUN0RSxRQUFJQSxhQUFhQztBQUFXO0FBRTVCLFVBQU1DLGVBQWVGLFNBQVNHLFFBQVFoQixlQUFlLFdBQVcsV0FBVyxFQUFFLEtBQUtSO0FBRWxGLFVBQU15QixxQkFBcUJsQixZQUN2QmMsU0FBU0ssU0FBUyxHQUFHLElBQUluQixZQUFZLElBQUlBLFlBQ3pDZTtBQUVKLFVBQU1LLGlCQUFpQkosYUFBYUssTUFBTSxHQUFHSCxrQkFBa0I7QUFDL0QsVUFBTUksa0JBQWtCQyxlQUFlSCxjQUFjO0FBRXJELFFBQUlFLG9CQUFvQlAsUUFBVztBQUNqQyxZQUFNWixlQUFjRSxlQUFlaUIsZUFBZTtBQUNsRGxCLHFCQUFlRCxZQUFXO0FBRTFCSixpQkFBV2MsT0FBT1MsZUFBZTtBQUFBLElBQ25DO0FBQUEsRUFDRixHQUFHLENBQUN2QixVQUFVQyxXQUFXQyxZQUFZLENBQUM7QUFFdENaLFlBQVUsTUFBTTtBQUNkZSxtQkFBZUMsZUFBZVAsU0FBUyxDQUFDLENBQUM7QUFBQSxFQUMzQyxHQUFHLENBQUNBLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsYUFDQyxPQUFPSyxhQUNQLFVBQVVTLGNBQ1YsR0FBSVYsY0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR2lCO0FBR3JCO0FBQUNMLEdBckRLRixlQUFxQztBQUFBNkIsS0FBckM3QjtBQXVETixNQUFNOEIsaUJBQWlCO0FBQ3ZCLE1BQU1DLGtCQUFrQjtBQUV4QixTQUFTSCxlQUFnQnpCLE9BQWU7QUFDdEMsUUFBTTZCLGFBQWE3QixNQUFNcUIsU0FBUyxHQUFHO0FBRXJDLE1BQUlTLGFBQWFDLFdBQVcvQixNQUFNbUIsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUVuRFcsZUFBYUEsY0FBY0QsY0FBY0MsY0FBYyxJQUNuREYsa0JBQ0FEO0FBR0osTUFBSUssTUFBTUYsVUFBVTtBQUFHO0FBRXZCLFFBQU1OLGtCQUFrQk0sYUFBYTtBQUVyQyxTQUFPTjtBQUNUO0FBRUEsZUFBQVMsTUFBZXhDLEtBQUtJLGFBQWE7QUFBQyxJQUFBNkIsSUFBQU87QUFBQUMsYUFBQVIsSUFBQTtBQUFBUSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsIm1lbW8iLCJUZXh0RmllbGQiLCJERUZBVUxUX0lOUFVUX1ZBTFVFIiwiREVGQVVMVF9NQVhfTEVOR1RIIiwiQ3VycmVuY3lJbnB1dCIsInByb3BzIiwiX3MiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwibWF4TGVuZ3RoIiwib25seVBvc2l0aXZlIiwib3RoZXJQcm9wcyIsIm1hc2tlZFZhbHVlIiwic2V0TWFza2VkVmFsdWUiLCJmb3JtYXRDdXJyZW5jeSIsImZvcm1hdHRlZFZhbHVlIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwibWF4aW11bUZyYWN0aW9uRGlnaXRzIiwiaGFuZGxlQ2hhbmdlIiwiZXZlbnQiLCJuZXdWYWx1ZSIsInVuZGVmaW5lZCIsIm51bWVyaWNWYWx1ZSIsInJlcGxhY2UiLCJmb3JtYXR0ZWRNYXhMZW5ndGgiLCJpbmNsdWRlcyIsInRydW5jYXRlZFZhbHVlIiwic2xpY2UiLCJub3JtYWxpemVkVmFsdWUiLCJub3JtYWxpemVWYWx1ZSIsIl9jIiwiTkVVVFJBTF9GQUNUT1IiLCJORUdBVElWRV9GQUNUT1IiLCJpc05lZ2F0aXZlIiwiZmxvYXRWYWx1ZSIsInBhcnNlRmxvYXQiLCJpc05hTiIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkN1cnJlbmN5SW5wdXQudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvaW5wdXRzL0N1cnJlbmN5SW5wdXQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrLCBtZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElUZXh0RmllbGRQcm9wcyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IFRleHRGaWVsZCBmcm9tICcuL1RleHRGaWVsZCdcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ3VycmVuY3lJbnB1dFByb3BzIGV4dGVuZHMgT21pdDxJVGV4dEZpZWxkUHJvcHMsICd2YWx1ZSd8J29uQ2hhbmdlJz4ge1xyXG4gIHZhbHVlPzogbnVtYmVyXHJcbiAgb25DaGFuZ2U/OiAoXzogdW5rbm93biwgdmFsdWU/OiBudW1iZXIpID0+IHZvaWRcclxuICBkaXNhYmxlZEFzUmVhZE9ubHk/OiBib29sZWFuXHJcbiAgb25seVBvc2l0aXZlPzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBERUZBVUxUX0lOUFVUX1ZBTFVFID0gJzAnXHJcbmNvbnN0IERFRkFVTFRfTUFYX0xFTkdUSCA9IDEyXHJcblxyXG5jb25zdCBDdXJyZW5jeUlucHV0OiBGQzxDdXJyZW5jeUlucHV0UHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qge1xyXG4gICAgdmFsdWUgPSAwLFxyXG4gICAgb25DaGFuZ2UsXHJcbiAgICBtYXhMZW5ndGggPSBERUZBVUxUX01BWF9MRU5HVEgsXHJcbiAgICBvbmx5UG9zaXRpdmUgPSBmYWxzZSxcclxuICAgIC4uLm90aGVyUHJvcHNcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgW21hc2tlZFZhbHVlLCBzZXRNYXNrZWRWYWx1ZV0gPSB1c2VTdGF0ZSgnMCcpXHJcblxyXG4gIGNvbnN0IGZvcm1hdEN1cnJlbmN5ID0gKHZhbHVlOiBudW1iZXIpID0+IHtcclxuICAgIGNvbnN0IGZvcm1hdHRlZFZhbHVlID0gdmFsdWUudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xyXG4gICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcclxuICAgICAgY3VycmVuY3k6ICdCUkwnLFxyXG4gICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIGZvcm1hdHRlZFZhbHVlXHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSB1c2VDYWxsYmFjaygoZXZlbnQ6IHVua25vd24sIG5ld1ZhbHVlPzogc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAobmV3VmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuXHJcblxyXG4gICAgY29uc3QgbnVtZXJpY1ZhbHVlID0gbmV3VmFsdWUucmVwbGFjZShvbmx5UG9zaXRpdmUgPyAvW15cXGRdL2cgOiAvW15cXGQtXS9nLCAnJykgfHwgREVGQVVMVF9JTlBVVF9WQUxVRVxyXG5cclxuICAgIGNvbnN0IGZvcm1hdHRlZE1heExlbmd0aCA9IG1heExlbmd0aFxyXG4gICAgICA/IG5ld1ZhbHVlLmluY2x1ZGVzKCctJykgPyBtYXhMZW5ndGggKyAxIDogbWF4TGVuZ3RoXHJcbiAgICAgIDogdW5kZWZpbmVkXHJcblxyXG4gICAgY29uc3QgdHJ1bmNhdGVkVmFsdWUgPSBudW1lcmljVmFsdWUuc2xpY2UoMCwgZm9ybWF0dGVkTWF4TGVuZ3RoKVxyXG4gICAgY29uc3Qgbm9ybWFsaXplZFZhbHVlID0gbm9ybWFsaXplVmFsdWUodHJ1bmNhdGVkVmFsdWUpXHJcblxyXG4gICAgaWYgKG5vcm1hbGl6ZWRWYWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGNvbnN0IG1hc2tlZFZhbHVlID0gZm9ybWF0Q3VycmVuY3kobm9ybWFsaXplZFZhbHVlKVxyXG4gICAgICBzZXRNYXNrZWRWYWx1ZShtYXNrZWRWYWx1ZSlcclxuXHJcbiAgICAgIG9uQ2hhbmdlPy4oZXZlbnQsIG5vcm1hbGl6ZWRWYWx1ZSlcclxuICAgIH1cclxuICB9LCBbb25DaGFuZ2UsIG1heExlbmd0aCwgb25seVBvc2l0aXZlXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldE1hc2tlZFZhbHVlKGZvcm1hdEN1cnJlbmN5KHZhbHVlIHx8IDApKVxyXG4gIH0sIFt2YWx1ZV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8VGV4dEZpZWxkXHJcbiAgICAgIHZhbHVlPXttYXNrZWRWYWx1ZX1cclxuICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgey4uLm90aGVyUHJvcHN9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgTkVVVFJBTF9GQUNUT1IgPSAxXHJcbmNvbnN0IE5FR0FUSVZFX0ZBQ1RPUiA9IC0xXHJcblxyXG5mdW5jdGlvbiBub3JtYWxpemVWYWx1ZSAodmFsdWU6IHN0cmluZykge1xyXG4gIGNvbnN0IGlzTmVnYXRpdmUgPSB2YWx1ZS5pbmNsdWRlcygnLScpXHJcblxyXG4gIGxldCBmbG9hdFZhbHVlID0gcGFyc2VGbG9hdCh2YWx1ZS5yZXBsYWNlKCcsJywgJy4nKSlcclxuXHJcbiAgZmxvYXRWYWx1ZSA9IGZsb2F0VmFsdWUgKiAoaXNOZWdhdGl2ZSAmJiBmbG9hdFZhbHVlID49IDBcclxuICAgID8gTkVHQVRJVkVfRkFDVE9SXHJcbiAgICA6IE5FVVRSQUxfRkFDVE9SXHJcbiAgKVxyXG5cclxuICBpZiAoaXNOYU4oZmxvYXRWYWx1ZSkpIHJldHVyblxyXG5cclxuICBjb25zdCBub3JtYWxpemVkVmFsdWUgPSBmbG9hdFZhbHVlIC8gMTAwXHJcblxyXG4gIHJldHVybiBub3JtYWxpemVkVmFsdWVcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbWVtbyhDdXJyZW5jeUlucHV0KVxyXG4iXX0=