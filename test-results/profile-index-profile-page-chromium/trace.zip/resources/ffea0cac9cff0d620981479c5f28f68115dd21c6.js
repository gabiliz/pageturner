import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractDetails.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Label, Text, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { UserName } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { Checkbox, FlexColumn, FlexItem, FlexRow, IconButton, Tag } from "/src/shared/components/index.ts?t=1701096626433";
import { formatCurrency, formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
import { ContractTypeRecord } from "/src/shared/record/index.ts";
import TaxesRercord from "/src/shared/record/TaxesRecord.ts";
import { CompanyName } from "/src/modules/admin/companies/components/index.ts?t=1701096626433";
const ContractDetails = (props) => {
  _s();
  const {
    data,
    isSubcontract,
    horizontal = false
  } = props;
  const theme = useTheme();
  const styles = getStyles(horizontal);
  const {
    colors
  } = useTheme();
  const contractTaxes = useMemo(() => {
    return data?.impostos && data?.impostos?.length > 0 ? data?.impostos?.map((tax) => TaxesRercord[tax]).join(", ") : "Não se aplica";
  }, [data?.impostos]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.grid, children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.numeroProposta, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nº do contrato" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: formatProposalNumber(data?.numeroProposta) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.numeroPropostaComercial, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nº da proposta" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: formatProposalNumber(data?.numeroPropostaComercial) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    isSubcontract && /* @__PURE__ */ jsxDEV("div", { className: styles.geraAuditoria, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Gerar projeto", checked: data.geraAuditoria, disabled: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 43,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelTecnico, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Sócio responsável técnico" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserName, { id: data.responsavelTecnicoId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 48,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelCliente, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Responsável cliente" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserName, { id: data.responsavelClienteId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.exercicio, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Exercício" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.exercicio }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.mesRenovacao, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Mês renovação" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      data.mesRenovacao && /* @__PURE__ */ jsxDEV(Text, { children: months[data.mesRenovacao] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 60,
        columnNumber: 31
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.qtdHoras, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Qtd. horas" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.qtdHoras }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 64,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.valor, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Valor" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      data.valor && /* @__PURE__ */ jsxDEV(Text, { children: formatCurrency(data.valor) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 68,
        columnNumber: 24
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.valorHora, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Valor hora" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Tag, { text: formatCurrency(data.qtdHoras && data.qtdHoras !== 0 && data.valor ? data.valor / data.qtdHoras : 0), backgroundColor: colors.blue[500] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.despesaViagem, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Despesa de viagem" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      data.despesaViagem !== void 0 && /* @__PURE__ */ jsxDEV(Text, { children: travelExpense[data.despesaViagem] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 76,
        columnNumber: 46
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.parecer, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Parecer" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.isParecer ? "Sim" : "Não" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.circularizacao, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Circularização" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.isCircularizacao ? "Sim" : "Não" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.inventario, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Inventário" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.isInventario ? "Sim" : "Não" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.observacao, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Descrição" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: data.observacao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 92,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.observacaoAceite, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Observação" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: data.observacaoAceite }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.tipoContrato, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Tipo de contrato" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: ContractTypeRecord[data.tipoContrato] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.impostos, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Tipo de imposto" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: contractTaxes }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 122,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.inicioContrato, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Início do contrato" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: data.dataInicio ? format(new Date(data.dataInicio), "dd/MM/yyyy") : "" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 132,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.finalContrato, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Fim do contrato" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 141,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: data.dataFim ? format(new Date(data.dataFim), "dd/MM/yyyy") : "" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.percentualExito, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Percentual de êxito" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 151,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { styles: {
        root: {
          overflowWrap: "anywhere"
        }
      }, children: data?.percentualExito ? `${data.percentualExito}%` : "" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 152,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 150,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.contatoCliente, children: /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Contato no cliente" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 162,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: "4px", children: [
        /* @__PURE__ */ jsxDEV(Text, { styles: {
          root: {
            overflowWrap: "anywhere"
          }
        }, children: data.nomeResponsavelCliente }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
          lineNumber: 164,
          columnNumber: 13
        }, this),
        (data.telefoneResponsavelCliente || data.emailResponsavelCliente) && /* @__PURE__ */ jsxDEV(IconButton, { iconProps: {
          iconName: "InfoSolid"
        }, styles: {
          icon: {
            color: theme.colors.blue[500],
            fontSize: 10
          },
          root: {
            width: 10,
            height: 10
          }
        }, hint: /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
          data.emailResponsavelCliente && /* @__PURE__ */ jsxDEV(FlexItem, { children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "E-mail" }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
              lineNumber: 184,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Text, { children: data.emailResponsavelCliente }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
              lineNumber: 185,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
            lineNumber: 183,
            columnNumber: 52
          }, this),
          data.telefoneResponsavelCliente && /* @__PURE__ */ jsxDEV(FlexItem, { children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Telefone" }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
              lineNumber: 188,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Text, { children: data.telefoneResponsavelCliente }, void 0, false, {
              fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
              lineNumber: 189,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
            lineNumber: 187,
            columnNumber: 55
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
          lineNumber: 182,
          columnNumber: 20
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
          lineNumber: 171,
          columnNumber: 83
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 163,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 161,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelComercial, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Contato comercial" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 196,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserName, { id: data.responsavelComercialId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 197,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.empresas, children: !horizontal && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Empresa" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
        lineNumber: 201,
        columnNumber: 13
      }, this),
      data.empresas?.map((company, index) => {
        return /* @__PURE__ */ jsxDEV(CompanyName, { id: company.empresaId, last: data.empresas && index === data.empresas?.length - 1 }, company.empresaId, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
          lineNumber: 203,
          columnNumber: 18
        }, this);
      })
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 200,
      columnNumber: 25
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
      lineNumber: 199,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(ContractDetails, "U0ongxjpQxu8bPyx2uLdirlpmtk=", false, function() {
  return [useTheme, useTheme];
});
_c = ContractDetails;
const travelExpense = {
  0: "Não",
  1: "Sim",
  2: "Sim/Parcial"
};
const months = {
  1: "Janeiro",
  2: "Fevereiro",
  3: "Março",
  4: "Abril",
  5: "Maio",
  6: "Junho",
  7: "Julho",
  8: "Agosto",
  9: "Setembro",
  10: "Outubro",
  11: "Novembro",
  12: "Dezembro"
};
const getStyles = (horizontal) => mergeStyleSets({
  grid: {
    display: "grid",
    gap: "12px 16px",
    gridTemplate: horizontal ? `
    "n nc ti im di df" auto
    "e q v ci pa ." auto
    "m d h pe in ." auto
    "t c cc rc . ." auto
    "o o o o o o" auto
    "oa oa oa oa oa oa" auto / 1fr 1fr 1fr 1fr 1fr 1fr
    ` : `
      "n n nc nc" auto
      "ga ga . ." auto
      "ti ti ti ti" auto
      "im im im im" auto
      "t t t t" auto
      "c c c c" auto
      "di di df df" auto
      "e e m m" auto
      "q v h h" auto
      "pe pe . ." auto
      "em em em em" auto
      "d d d d" auto
      "pa pa pa pa" auto
      "ci ci ci ci" auto
      "in in in in" auto
      "cc cc cc cc" auto
      "cm cm ct ct" auto
      "rc rc rc rc" auto
      "o o o o" auto
      "oa oa oa oa" auto / 1fr 1fr 1fr 1fr
    `
  },
  numeroProposta: {
    gridArea: "n"
  },
  numeroPropostaComercial: {
    gridArea: "nc"
  },
  responsavelTecnico: {
    gridArea: "t"
  },
  responsavelCliente: {
    gridArea: "c"
  },
  responsavelComercial: {
    gridArea: "rc"
  },
  exercicio: {
    gridArea: "e"
  },
  mesRenovacao: {
    gridArea: "m"
  },
  qtdHoras: {
    gridArea: "q"
  },
  valor: {
    gridArea: "v"
  },
  valorHora: {
    gridArea: "h"
  },
  tipoContrato: {
    gridArea: "ti"
  },
  impostos: {
    gridArea: "im"
  },
  inicioContrato: {
    gridArea: "di"
  },
  finalContrato: {
    gridArea: "df"
  },
  percentualExito: {
    gridArea: "pe"
  },
  contatoCliente: {
    gridArea: "cc"
  },
  contatoEmail: {
    gridArea: "cm"
  },
  contatoTelefone: {
    gridArea: "ct"
  },
  despesaViagem: {
    gridArea: "d"
  },
  parecer: {
    gridArea: "pa"
  },
  circularizacao: {
    gridArea: "ci"
  },
  inventario: {
    gridArea: "in"
  },
  observacao: {
    gridArea: "o"
  },
  observacaoAceite: {
    gridArea: "oa"
  },
  empresas: {
    gridArea: "em"
  },
  geraAuditoria: {
    gridArea: "ga"
  }
});
export default ContractDetails;
var _c;
$RefreshReg$(_c, "ContractDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NRLFNBbU1FLFVBbk1GOzs7Ozs7Ozs7Ozs7Ozs7O0FBbENSLFNBQWFBLGVBQWU7QUFDNUIsU0FBU0MsT0FBT0MsTUFBTUMsc0JBQXNCO0FBRTVDLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxVQUFVQyxZQUFZQyxVQUFVQyxTQUFTQyxZQUFZQyxXQUFXO0FBQ3pFLFNBQVNDLGdCQUFnQkMsNEJBQTRCO0FBQ3JELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLDBCQUEwQjtBQUNuQyxPQUFPQyxrQkFBa0I7QUFFekIsU0FBU0MsbUJBQW1CO0FBTzVCLE1BQU1DLGtCQUE2Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQzNELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFNQztBQUFBQSxJQUFlQyxhQUFhO0FBQUEsRUFBTSxJQUFJSjtBQUNwRCxRQUFNSyxRQUFRWCxTQUFTO0FBQ3ZCLFFBQU1ZLFNBQVNDLFVBQVVILFVBQVU7QUFDbkMsUUFBTTtBQUFBLElBQUVJO0FBQUFBLEVBQU8sSUFBSWQsU0FBUztBQUU1QixRQUFNZSxnQkFBZ0I1QixRQUFRLE1BQU07QUFDbEMsV0FBT3FCLE1BQU1RLFlBQVlSLE1BQU1RLFVBQVVDLFNBQVMsSUFDOUNULE1BQU1RLFVBQVVFLElBQUksQ0FBQ0MsUUFBbUJoQixhQUFhZ0IsR0FBRyxDQUFDLEVBQUVDLEtBQUssSUFBSSxJQUNwRTtBQUFBLEVBQ04sR0FBRyxDQUFDWixNQUFNUSxRQUFRLENBQUM7QUFFbkIsU0FDRSx1QkFBQyxTQUFJLFdBQVdKLE9BQU9TLE1BQ3JCO0FBQUEsMkJBQUMsU0FBSSxXQUFXVCxPQUFPVSxnQkFDckI7QUFBQSw2QkFBQyxTQUFNLDhCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxNQUNyQix1QkFBQyxRQUFNdkIsK0JBQXFCUyxNQUFNYyxjQUFjLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxTQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV1YsT0FBT1cseUJBQ3JCO0FBQUEsNkJBQUMsU0FBTSw4QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCO0FBQUEsTUFDckIsdUJBQUMsUUFBTXhCLCtCQUFxQlMsTUFBTWUsdUJBQXVCLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxTQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNDZCxpQkFDRCx1QkFBQyxTQUFJLFdBQVdHLE9BQU9ZLGVBQ3JCLGlDQUFDLFlBQ0MsT0FBTSxpQkFDTixTQUFTaEIsS0FBS2dCLGVBQ2QsVUFBVSxRQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHaUIsS0FKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVdaLE9BQU9hLG9CQUNyQjtBQUFBLDZCQUFDLFNBQU0seUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLE1BQ2hDLHVCQUFDLFlBQVMsSUFBSWpCLEtBQUtrQix3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLFNBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXZCxPQUFPZSxvQkFDckI7QUFBQSw2QkFBQyxTQUFNLG1DQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxNQUMxQix1QkFBQyxZQUFTLElBQUluQixLQUFLb0Isd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxTQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV2hCLE9BQU9pQixXQUNyQjtBQUFBLDZCQUFDLFNBQU0seUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLE1BQ2hCLHVCQUFDLFFBQU1yQixlQUFLcUIsYUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsU0FGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdqQixPQUFPa0IsY0FDckI7QUFBQSw2QkFBQyxTQUFNLDZCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUNuQnRCLEtBQUtzQixnQkFDSix1QkFBQyxRQUFNQyxpQkFBT3ZCLEtBQUtzQixZQUFZLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxTQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV2xCLE9BQU9vQixVQUNyQjtBQUFBLDZCQUFDLFNBQU0sMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLFFBQU14QixlQUFLd0IsWUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCO0FBQUEsU0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdwQixPQUFPcUIsT0FDckI7QUFBQSw2QkFBQyxTQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLE1BQ1h6QixLQUFLeUIsU0FDSix1QkFBQyxRQUFNbkMseUJBQWVVLEtBQUt5QixLQUFLLEtBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxTQUh0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV3JCLE9BQU9zQixXQUNyQjtBQUFBLDZCQUFDLFNBQU0sMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLE9BQUksTUFBTXBDLGVBQWVVLEtBQUt3QixZQUFZeEIsS0FBS3dCLGFBQWEsS0FBS3hCLEtBQUt5QixRQUNuRXpCLEtBQUt5QixRQUFRekIsS0FBS3dCLFdBQ2xCLENBQUMsR0FDTCxpQkFBaUJsQixPQUFPcUIsS0FBSyxHQUFHLEtBSGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHa0M7QUFBQSxTQUxwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV3ZCLE9BQU93QixlQUNyQjtBQUFBLDZCQUFDLFNBQU0saUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3ZCNUIsS0FBSzRCLGtCQUFrQkMsVUFDdEIsdUJBQUMsUUFBTUMsd0JBQWM5QixLQUFLNEIsYUFBYSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FIN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVd4QixPQUFPMkIsU0FDckI7QUFBQSw2QkFBQyxTQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ2QsdUJBQUMsUUFBTS9CLGVBQUtnQyxZQUFZLFFBQVEsU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLFNBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXNUIsT0FBTzZCLGdCQUNyQjtBQUFBLDZCQUFDLFNBQU0sOEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQjtBQUFBLE1BQ3JCLHVCQUFDLFFBQU1qQyxlQUFLa0MsbUJBQW1CLFFBQVEsU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QztBQUFBLFNBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXOUIsT0FBTytCLFlBQ3JCO0FBQUEsNkJBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsUUFBTW5DLGVBQUtvQyxlQUFlLFFBQVEsU0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXaEMsT0FBT2lDLFlBQ3JCO0FBQUEsNkJBQUMsU0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCO0FBQUEsTUFDaEIsdUJBQUMsUUFDQyxRQUFRO0FBQUEsUUFDTkMsTUFBTTtBQUFBLFVBQ0pDLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsR0FFQ3ZDLGVBQUtxQyxjQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdqQyxPQUFPb0Msa0JBQ3JCO0FBQUEsNkJBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsUUFDQyxRQUFRO0FBQUEsUUFDTkYsTUFBTTtBQUFBLFVBQ0pDLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsR0FFQ3ZDLGVBQUt3QyxvQkFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXcEMsT0FBT3FDLGNBQ3JCO0FBQUEsNkJBQUMsU0FBTSxnQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDdkIsdUJBQUMsUUFDQyxRQUFRO0FBQUEsUUFDTkgsTUFBTTtBQUFBLFVBQ0pDLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsR0FFQzdDLDZCQUFtQk0sS0FBS3lDLFlBQVksS0FQdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV3JDLE9BQU9JLFVBQ3JCO0FBQUEsNkJBQUMsU0FBTSwrQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFDdEIsdUJBQUMsUUFDQyxRQUFRO0FBQUEsUUFDTjhCLE1BQU07QUFBQSxVQUNKQyxjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGLEdBRUNoQywyQkFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSCxPQUFPc0MsZ0JBQ3JCO0FBQUEsNkJBQUMsU0FBTSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsUUFDQyxRQUFRO0FBQUEsUUFDTkosTUFBTTtBQUFBLFVBQ0pDLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsR0FFQ3ZDLGVBQUsyQyxhQUFhbEQsT0FBTyxJQUFJbUQsS0FBSzVDLEtBQUsyQyxVQUFVLEdBQUcsWUFBWSxJQUFJLE1BUHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVd2QyxPQUFPeUMsZUFDckI7QUFBQSw2QkFBQyxTQUFNLCtCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUN0Qix1QkFBQyxRQUNDLFFBQVE7QUFBQSxRQUNOUCxNQUFNO0FBQUEsVUFDSkMsY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRixHQUVDdkMsZUFBSzhDLFVBQVVyRCxPQUFPLElBQUltRCxLQUFLNUMsS0FBSzhDLE9BQU8sR0FBRyxZQUFZLElBQUksTUFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVzFDLE9BQU8yQyxpQkFDckI7QUFBQSw2QkFBQyxTQUFNLG1DQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxNQUMxQix1QkFBQyxRQUNDLFFBQVE7QUFBQSxRQUNOVCxNQUFNO0FBQUEsVUFDSkMsY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRixHQUVDdkMsZ0JBQU0rQyxrQkFBbUIsR0FBRS9DLEtBQUsrQyxxQkFBcUIsTUFQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVzNDLE9BQU80QyxnQkFDckIsaUNBQUMsY0FDQztBQUFBLDZCQUFDLFNBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFdBQVEsZUFBYyxVQUFTLEtBQUksT0FDbEM7QUFBQSwrQkFBQyxRQUNDLFFBQVE7QUFBQSxVQUNOVixNQUFNO0FBQUEsWUFDSkMsY0FBYztBQUFBLFVBQ2hCO0FBQUEsUUFDRixHQUVDdkMsZUFBS2lELDBCQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFNBQ0VqRCxLQUFLa0QsOEJBQThCbEQsS0FBS21ELDRCQUE0Qix1QkFBQyxjQUNyRSxXQUFXO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFFBQVksR0FDbkMsUUFBUTtBQUFBLFVBQ05DLE1BQU07QUFBQSxZQUFFQyxPQUFPbkQsTUFBTUcsT0FBT3FCLEtBQUssR0FBRztBQUFBLFlBQUc0QixVQUFVO0FBQUEsVUFBRztBQUFBLFVBQ3BEakIsTUFBTTtBQUFBLFlBQUVrQixPQUFPO0FBQUEsWUFBSUMsUUFBUTtBQUFBLFVBQUc7QUFBQSxRQUNoQyxHQUNBLE1BQ0UsdUJBQUMsY0FDRXpEO0FBQUFBLGVBQUttRCwyQkFBMkIsdUJBQUMsWUFDaEM7QUFBQSxtQ0FBQyxTQUFNLHNCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWE7QUFBQSxZQUNiLHVCQUFDLFFBQU1uRCxlQUFLbUQsMkJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQSxlQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR2pDO0FBQUEsVUFDQ25ELEtBQUtrRCw4QkFBOEIsdUJBQUMsWUFDbkM7QUFBQSxtQ0FBQyxTQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUNmLHVCQUFDLFFBQU1sRCxlQUFLa0QsOEJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxlQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR3BDO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0EsS0FoQmtFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQm5FO0FBQUEsV0EzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLFNBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0EsS0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXOUMsT0FBT3NELHNCQUNyQjtBQUFBLDZCQUFDLFNBQU0saUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLFlBQVMsSUFBSTFELEtBQUsyRCwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLFNBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXdkQsT0FBT3dELFVBQ3BCLFdBQUMxRCxjQUNBLG1DQUNFO0FBQUEsNkJBQUMsU0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWM7QUFBQSxNQUNiRixLQUFLNEQsVUFBVWxELElBQUksQ0FBQ21ELFNBQVNDLFVBQVU7QUFDdEMsZUFBTyx1QkFBQyxlQUVOLElBQUlELFFBQVFFLFdBQ1osTUFBTS9ELEtBQUs0RCxZQUFhRSxVQUFXOUQsS0FBSzRELFVBQVVuRCxTQUFTLEtBRnREb0QsUUFBUUUsV0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRzBEO0FBQUEsTUFFbkUsQ0FBQztBQUFBLFNBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FoTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlOQTtBQUVKO0FBQUNoRSxHQWhPS0YsaUJBQXlDO0FBQUEsVUFFL0JMLFVBRUtBLFFBQVE7QUFBQTtBQUFBd0UsS0FKdkJuRTtBQWtPTixNQUFNaUMsZ0JBQXVEO0FBQUEsRUFDM0QsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUFBLEVBQ0gsR0FBRztBQUNMO0FBRUEsTUFBTVAsU0FBK0M7QUFBQSxFQUNuRCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxHQUFHO0FBQUEsRUFDSCxJQUFJO0FBQUEsRUFDSixJQUFJO0FBQUEsRUFDSixJQUFJO0FBQ047QUFFQSxNQUFNbEIsWUFBWUEsQ0FBQ0gsZUFBd0JwQixlQUFlO0FBQUEsRUFDeEQrQixNQUFNO0FBQUEsSUFDSm9ELFNBQVM7QUFBQSxJQUNUQyxLQUFLO0FBQUEsSUFDTEMsY0FBY2pFLGFBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFzQlA7QUFBQSxFQUNBWSxnQkFBZ0I7QUFBQSxJQUFFc0QsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUNoQ3JELHlCQUF5QjtBQUFBLElBQUVxRCxVQUFVO0FBQUEsRUFBSztBQUFBLEVBQzFDbkQsb0JBQW9CO0FBQUEsSUFBRW1ELFVBQVU7QUFBQSxFQUFJO0FBQUEsRUFDcENqRCxvQkFBb0I7QUFBQSxJQUFFaUQsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUNwQ1Ysc0JBQXNCO0FBQUEsSUFBRVUsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUN2Qy9DLFdBQVc7QUFBQSxJQUFFK0MsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUMzQjlDLGNBQWM7QUFBQSxJQUFFOEMsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUM5QjVDLFVBQVU7QUFBQSxJQUFFNEMsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUMxQjNDLE9BQU87QUFBQSxJQUFFMkMsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUN2QjFDLFdBQVc7QUFBQSxJQUFFMEMsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUMzQjNCLGNBQWM7QUFBQSxJQUFFMkIsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUMvQjVELFVBQVU7QUFBQSxJQUFFNEQsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUMzQjFCLGdCQUFnQjtBQUFBLElBQUUwQixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQ2pDdkIsZUFBZTtBQUFBLElBQUV1QixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQ2hDckIsaUJBQWlCO0FBQUEsSUFBRXFCLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDbENwQixnQkFBZ0I7QUFBQSxJQUFFb0IsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUNqQ0MsY0FBYztBQUFBLElBQUVELFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDL0JFLGlCQUFpQjtBQUFBLElBQUVGLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDbEN4QyxlQUFlO0FBQUEsSUFBRXdDLFVBQVU7QUFBQSxFQUFJO0FBQUEsRUFDL0JyQyxTQUFTO0FBQUEsSUFBRXFDLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDMUJuQyxnQkFBZ0I7QUFBQSxJQUFFbUMsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUNqQ2pDLFlBQVk7QUFBQSxJQUFFaUMsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUM3Qi9CLFlBQVk7QUFBQSxJQUFFK0IsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUM1QjVCLGtCQUFrQjtBQUFBLElBQUU0QixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQ25DUixVQUFVO0FBQUEsSUFBRVEsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUMzQnBELGVBQWU7QUFBQSxJQUFFb0QsVUFBVTtBQUFBLEVBQUs7QUFDbEMsQ0FBQztBQUVELGVBQWV2RTtBQUFlLElBQUFtRTtBQUFBTyxhQUFBUCxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIkxhYmVsIiwiVGV4dCIsIm1lcmdlU3R5bGVTZXRzIiwiVXNlck5hbWUiLCJDaGVja2JveCIsIkZsZXhDb2x1bW4iLCJGbGV4SXRlbSIsIkZsZXhSb3ciLCJJY29uQnV0dG9uIiwiVGFnIiwiZm9ybWF0Q3VycmVuY3kiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsInVzZVRoZW1lIiwiZm9ybWF0IiwiQ29udHJhY3RUeXBlUmVjb3JkIiwiVGF4ZXNSZXJjb3JkIiwiQ29tcGFueU5hbWUiLCJDb250cmFjdERldGFpbHMiLCJwcm9wcyIsIl9zIiwiZGF0YSIsImlzU3ViY29udHJhY3QiLCJob3Jpem9udGFsIiwidGhlbWUiLCJzdHlsZXMiLCJnZXRTdHlsZXMiLCJjb2xvcnMiLCJjb250cmFjdFRheGVzIiwiaW1wb3N0b3MiLCJsZW5ndGgiLCJtYXAiLCJ0YXgiLCJqb2luIiwiZ3JpZCIsIm51bWVyb1Byb3Bvc3RhIiwibnVtZXJvUHJvcG9zdGFDb21lcmNpYWwiLCJnZXJhQXVkaXRvcmlhIiwicmVzcG9uc2F2ZWxUZWNuaWNvIiwicmVzcG9uc2F2ZWxUZWNuaWNvSWQiLCJyZXNwb25zYXZlbENsaWVudGUiLCJyZXNwb25zYXZlbENsaWVudGVJZCIsImV4ZXJjaWNpbyIsIm1lc1Jlbm92YWNhbyIsIm1vbnRocyIsInF0ZEhvcmFzIiwidmFsb3IiLCJ2YWxvckhvcmEiLCJibHVlIiwiZGVzcGVzYVZpYWdlbSIsInVuZGVmaW5lZCIsInRyYXZlbEV4cGVuc2UiLCJwYXJlY2VyIiwiaXNQYXJlY2VyIiwiY2lyY3VsYXJpemFjYW8iLCJpc0NpcmN1bGFyaXphY2FvIiwiaW52ZW50YXJpbyIsImlzSW52ZW50YXJpbyIsIm9ic2VydmFjYW8iLCJyb290Iiwib3ZlcmZsb3dXcmFwIiwib2JzZXJ2YWNhb0FjZWl0ZSIsInRpcG9Db250cmF0byIsImluaWNpb0NvbnRyYXRvIiwiZGF0YUluaWNpbyIsIkRhdGUiLCJmaW5hbENvbnRyYXRvIiwiZGF0YUZpbSIsInBlcmNlbnR1YWxFeGl0byIsImNvbnRhdG9DbGllbnRlIiwibm9tZVJlc3BvbnNhdmVsQ2xpZW50ZSIsInRlbGVmb25lUmVzcG9uc2F2ZWxDbGllbnRlIiwiZW1haWxSZXNwb25zYXZlbENsaWVudGUiLCJpY29uTmFtZSIsImljb24iLCJjb2xvciIsImZvbnRTaXplIiwid2lkdGgiLCJoZWlnaHQiLCJyZXNwb25zYXZlbENvbWVyY2lhbCIsInJlc3BvbnNhdmVsQ29tZXJjaWFsSWQiLCJlbXByZXNhcyIsImNvbXBhbnkiLCJpbmRleCIsImVtcHJlc2FJZCIsIl9jIiwiZGlzcGxheSIsImdhcCIsImdyaWRUZW1wbGF0ZSIsImdyaWRBcmVhIiwiY29udGF0b0VtYWlsIiwiY29udGF0b1RlbGVmb25lIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJhY3REZXRhaWxzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL2NvbXBvbmVudHMvQ29udHJhY3REZXRhaWxzLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExhYmVsLCBUZXh0LCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgQmFzZUNvbnRyYWN0LCBDb250cmFjdFJlbmV3YWxNb250aCwgQ29udHJhY3RUcmF2ZWxFeHBlbnNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL0NvbnRyYWN0J1xyXG5pbXBvcnQgeyBVc2VyTmFtZSB9IGZyb20gJy4uLy4uL3VzZXJzL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IERldGFpbHNWaWV3UHJvcHMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdHlwZXMvRGV0YWlsc1ZpZXcnXHJcbmltcG9ydCB7IENoZWNrYm94LCBGbGV4Q29sdW1uLCBGbGV4SXRlbSwgRmxleFJvdywgSWNvbkJ1dHRvbiwgVGFnIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5LCBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IGZvcm1hdCB9IGZyb20gJ2RhdGUtZm5zJ1xyXG5pbXBvcnQgeyBDb250cmFjdFR5cGVSZWNvcmQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvcmVjb3JkJ1xyXG5pbXBvcnQgVGF4ZXNSZXJjb3JkIGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQvVGF4ZXNSZWNvcmQnXHJcbmltcG9ydCB7IFRheGVzRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9UYXhlc0VudW0nXHJcbmltcG9ydCB7IENvbXBhbnlOYW1lIH0gZnJvbSAnLi4vLi4vY29tcGFuaWVzL2NvbXBvbmVudHMnXHJcblxyXG5pbnRlcmZhY2UgQ29udHJhY3REZXRhaWxzUHJvcHMgZXh0ZW5kcyBEZXRhaWxzVmlld1Byb3BzPEJhc2VDb250cmFjdD4ge1xyXG4gIGhvcml6b250YWw/OiBib29sZWFuLFxyXG4gIGlzU3ViY29udHJhY3Q/OiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IENvbnRyYWN0RGV0YWlsczogRkM8Q29udHJhY3REZXRhaWxzUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBkYXRhLCBpc1N1YmNvbnRyYWN0LCBob3Jpem9udGFsID0gZmFsc2UgfSA9IHByb3BzXHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcbiAgY29uc3Qgc3R5bGVzID0gZ2V0U3R5bGVzKGhvcml6b250YWwpXHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgY29uc3QgY29udHJhY3RUYXhlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGRhdGE/LmltcG9zdG9zICYmIGRhdGE/LmltcG9zdG9zPy5sZW5ndGggPiAwXHJcbiAgICAgID8gZGF0YT8uaW1wb3N0b3M/Lm1hcCgodGF4OiBUYXhlc0VudW0pID0+IFRheGVzUmVyY29yZFt0YXhdKS5qb2luKCcsICcpXHJcbiAgICAgIDogJ07Do28gc2UgYXBsaWNhJ1xyXG4gIH0sIFtkYXRhPy5pbXBvc3Rvc10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmdyaWR9PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm51bWVyb1Byb3Bvc3RhfT5cclxuICAgICAgICA8TGFiZWw+TsK6IGRvIGNvbnRyYXRvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dD57Zm9ybWF0UHJvcG9zYWxOdW1iZXIoZGF0YT8ubnVtZXJvUHJvcG9zdGEpfTwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubnVtZXJvUHJvcG9zdGFDb21lcmNpYWx9PlxyXG4gICAgICAgIDxMYWJlbD5OwrogZGEgcHJvcG9zdGE8L0xhYmVsPlxyXG4gICAgICAgIDxUZXh0Pntmb3JtYXRQcm9wb3NhbE51bWJlcihkYXRhPy5udW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCl9PC9UZXh0PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2lzU3ViY29udHJhY3QgJiZcclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5nZXJhQXVkaXRvcmlhfT5cclxuICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgIGxhYmVsPSdHZXJhciBwcm9qZXRvJ1xyXG4gICAgICAgICAgY2hlY2tlZD17ZGF0YS5nZXJhQXVkaXRvcmlhfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e3RydWV9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIH1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5yZXNwb25zYXZlbFRlY25pY299PlxyXG4gICAgICAgIDxMYWJlbD5Tw7NjaW8gcmVzcG9uc8OhdmVsIHTDqWNuaWNvPC9MYWJlbD5cclxuICAgICAgICA8VXNlck5hbWUgaWQ9e2RhdGEucmVzcG9uc2F2ZWxUZWNuaWNvSWQgYXMgc3RyaW5nfSAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5yZXNwb25zYXZlbENsaWVudGV9PlxyXG4gICAgICAgIDxMYWJlbD5SZXNwb25zw6F2ZWwgY2xpZW50ZTwvTGFiZWw+XHJcbiAgICAgICAgPFVzZXJOYW1lIGlkPXtkYXRhLnJlc3BvbnNhdmVsQ2xpZW50ZUlkIGFzIHN0cmluZ30gLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZXhlcmNpY2lvfT5cclxuICAgICAgICA8TGFiZWw+RXhlcmPDrWNpbzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHQ+e2RhdGEuZXhlcmNpY2lvfTwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubWVzUmVub3ZhY2FvfT5cclxuICAgICAgICA8TGFiZWw+TcOqcyByZW5vdmHDp8OjbzwvTGFiZWw+XHJcbiAgICAgICAge2RhdGEubWVzUmVub3ZhY2FvICYmIChcclxuICAgICAgICAgIDxUZXh0Pnttb250aHNbZGF0YS5tZXNSZW5vdmFjYW9dfTwvVGV4dD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5xdGRIb3Jhc30+XHJcbiAgICAgICAgPExhYmVsPlF0ZC4gaG9yYXM8L0xhYmVsPlxyXG4gICAgICAgIDxUZXh0PntkYXRhLnF0ZEhvcmFzfTwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudmFsb3J9PlxyXG4gICAgICAgIDxMYWJlbD5WYWxvcjwvTGFiZWw+XHJcbiAgICAgICAge2RhdGEudmFsb3IgJiYgKFxyXG4gICAgICAgICAgPFRleHQ+e2Zvcm1hdEN1cnJlbmN5KGRhdGEudmFsb3IpfTwvVGV4dD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy52YWxvckhvcmF9PlxyXG4gICAgICAgIDxMYWJlbD5WYWxvciBob3JhPC9MYWJlbD5cclxuICAgICAgICA8VGFnIHRleHQ9e2Zvcm1hdEN1cnJlbmN5KGRhdGEucXRkSG9yYXMgJiYgZGF0YS5xdGRIb3JhcyAhPT0gMCAmJiBkYXRhLnZhbG9yXHJcbiAgICAgICAgICA/IGRhdGEudmFsb3IgLyBkYXRhLnF0ZEhvcmFzID8/IDBcclxuICAgICAgICAgIDogMCl9XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yPXtjb2xvcnMuYmx1ZVs1MDBdfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmRlc3Blc2FWaWFnZW19PlxyXG4gICAgICAgIDxMYWJlbD5EZXNwZXNhIGRlIHZpYWdlbTwvTGFiZWw+XHJcbiAgICAgICAge2RhdGEuZGVzcGVzYVZpYWdlbSAhPT0gdW5kZWZpbmVkICYmIChcclxuICAgICAgICAgIDxUZXh0Pnt0cmF2ZWxFeHBlbnNlW2RhdGEuZGVzcGVzYVZpYWdlbV19PC9UZXh0PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnBhcmVjZXJ9PlxyXG4gICAgICAgIDxMYWJlbD5QYXJlY2VyPC9MYWJlbD5cclxuICAgICAgICA8VGV4dD57ZGF0YS5pc1BhcmVjZXIgPyAnU2ltJyA6ICdOw6NvJ308L1RleHQ+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNpcmN1bGFyaXphY2FvfT5cclxuICAgICAgICA8TGFiZWw+Q2lyY3VsYXJpemHDp8OjbzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHQ+e2RhdGEuaXNDaXJjdWxhcml6YWNhbyA/ICdTaW0nIDogJ07Do28nfTwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuaW52ZW50YXJpb30+XHJcbiAgICAgICAgPExhYmVsPkludmVudMOhcmlvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dD57ZGF0YS5pc0ludmVudGFyaW8gPyAnU2ltJyA6ICdOw6NvJ308L1RleHQ+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm9ic2VydmFjYW99PlxyXG4gICAgICAgIDxMYWJlbD5EZXNjcmnDp8OjbzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHRcclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZGF0YS5vYnNlcnZhY2FvfVxyXG4gICAgICAgIDwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMub2JzZXJ2YWNhb0FjZWl0ZX0+XHJcbiAgICAgICAgPExhYmVsPk9ic2VydmHDp8OjbzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHRcclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZGF0YS5vYnNlcnZhY2FvQWNlaXRlfVxyXG4gICAgICAgIDwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudGlwb0NvbnRyYXRvfT5cclxuICAgICAgICA8TGFiZWw+VGlwbyBkZSBjb250cmF0bzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHRcclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7Q29udHJhY3RUeXBlUmVjb3JkW2RhdGEudGlwb0NvbnRyYXRvXX1cclxuICAgICAgICA8L1RleHQ+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmltcG9zdG9zfT5cclxuICAgICAgICA8TGFiZWw+VGlwbyBkZSBpbXBvc3RvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICBvdmVyZmxvd1dyYXA6ICdhbnl3aGVyZScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtjb250cmFjdFRheGVzfVxyXG4gICAgICAgIDwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuaW5pY2lvQ29udHJhdG99PlxyXG4gICAgICAgIDxMYWJlbD5JbsOtY2lvIGRvIGNvbnRyYXRvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICBvdmVyZmxvd1dyYXA6ICdhbnl3aGVyZScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtkYXRhLmRhdGFJbmljaW8gPyBmb3JtYXQobmV3IERhdGUoZGF0YS5kYXRhSW5pY2lvKSwgJ2RkL01NL3l5eXknKSA6ICcnfVxyXG4gICAgICAgIDwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmluYWxDb250cmF0b30+XHJcbiAgICAgICAgPExhYmVsPkZpbSBkbyBjb250cmF0bzwvTGFiZWw+XHJcbiAgICAgICAgPFRleHRcclxuICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZGF0YS5kYXRhRmltID8gZm9ybWF0KG5ldyBEYXRlKGRhdGEuZGF0YUZpbSksICdkZC9NTS95eXl5JykgOiAnJ31cclxuICAgICAgICA8L1RleHQ+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnBlcmNlbnR1YWxFeGl0b30+XHJcbiAgICAgICAgPExhYmVsPlBlcmNlbnR1YWwgZGUgw6p4aXRvPC9MYWJlbD5cclxuICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICBvdmVyZmxvd1dyYXA6ICdhbnl3aGVyZScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtkYXRhPy5wZXJjZW50dWFsRXhpdG8gPyBgJHtkYXRhLnBlcmNlbnR1YWxFeGl0b30lYCA6ICcnfVxyXG4gICAgICAgIDwvVGV4dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGF0b0NsaWVudGV9PlxyXG4gICAgICAgIDxGbGV4Q29sdW1uPlxyXG4gICAgICAgICAgPExhYmVsPkNvbnRhdG8gbm8gY2xpZW50ZTwvTGFiZWw+XHJcbiAgICAgICAgICA8RmxleFJvdyB2ZXJ0aWNhbEFsaWduPSdjZW50ZXInIGdhcD0nNHB4Jz5cclxuICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgICAgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2RhdGEubm9tZVJlc3BvbnNhdmVsQ2xpZW50ZX1cclxuICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICB7KGRhdGEudGVsZWZvbmVSZXNwb25zYXZlbENsaWVudGUgfHwgZGF0YS5lbWFpbFJlc3BvbnNhdmVsQ2xpZW50ZSkgJiYgPEljb25CdXR0b25cclxuICAgICAgICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdJbmZvU29saWQnIH19XHJcbiAgICAgICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgICAgICBpY29uOiB7IGNvbG9yOiB0aGVtZS5jb2xvcnMuYmx1ZVs1MDBdLCBmb250U2l6ZTogMTAgfSxcclxuICAgICAgICAgICAgICAgIHJvb3Q6IHsgd2lkdGg6IDEwLCBoZWlnaHQ6IDEwIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBoaW50PXtcclxuICAgICAgICAgICAgICAgIDxGbGV4Q29sdW1uPlxyXG4gICAgICAgICAgICAgICAgICB7ZGF0YS5lbWFpbFJlc3BvbnNhdmVsQ2xpZW50ZSAmJiA8RmxleEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPExhYmVsPkUtbWFpbDwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQ+e2RhdGEuZW1haWxSZXNwb25zYXZlbENsaWVudGV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L0ZsZXhJdGVtPn1cclxuICAgICAgICAgICAgICAgICAge2RhdGEudGVsZWZvbmVSZXNwb25zYXZlbENsaWVudGUgJiYgPEZsZXhJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbD5UZWxlZm9uZTwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQ+e2RhdGEudGVsZWZvbmVSZXNwb25zYXZlbENsaWVudGV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L0ZsZXhJdGVtPn1cclxuICAgICAgICAgICAgICAgIDwvRmxleENvbHVtbj5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+fVxyXG4gICAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgIDwvRmxleENvbHVtbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucmVzcG9uc2F2ZWxDb21lcmNpYWx9PlxyXG4gICAgICAgIDxMYWJlbD5Db250YXRvIGNvbWVyY2lhbDwvTGFiZWw+XHJcbiAgICAgICAgPFVzZXJOYW1lIGlkPXtkYXRhLnJlc3BvbnNhdmVsQ29tZXJjaWFsSWQgYXMgc3RyaW5nfSAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5lbXByZXNhc30+XHJcbiAgICAgICAgeyFob3Jpem9udGFsICYmXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8TGFiZWw+RW1wcmVzYTwvTGFiZWw+XHJcbiAgICAgICAgICAgIHtkYXRhLmVtcHJlc2FzPy5tYXAoKGNvbXBhbnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIDxDb21wYW55TmFtZVxyXG4gICAgICAgICAgICAgICAga2V5PXtjb21wYW55LmVtcHJlc2FJZH1cclxuICAgICAgICAgICAgICAgIGlkPXtjb21wYW55LmVtcHJlc2FJZH1cclxuICAgICAgICAgICAgICAgIGxhc3Q9e2RhdGEuZW1wcmVzYXMgJiYgKGluZGV4ID09PSAoZGF0YS5lbXByZXNhcz8ubGVuZ3RoIC0gMSkpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgdHJhdmVsRXhwZW5zZTogUmVjb3JkPENvbnRyYWN0VHJhdmVsRXhwZW5zZSwgc3RyaW5nPiA9IHtcclxuICAwOiAnTsOjbycsXHJcbiAgMTogJ1NpbScsXHJcbiAgMjogJ1NpbS9QYXJjaWFsJyxcclxufVxyXG5cclxuY29uc3QgbW9udGhzOiBSZWNvcmQ8Q29udHJhY3RSZW5ld2FsTW9udGgsIHN0cmluZz4gPSB7XHJcbiAgMTogJ0phbmVpcm8nLFxyXG4gIDI6ICdGZXZlcmVpcm8nLFxyXG4gIDM6ICdNYXLDp28nLFxyXG4gIDQ6ICdBYnJpbCcsXHJcbiAgNTogJ01haW8nLFxyXG4gIDY6ICdKdW5obycsXHJcbiAgNzogJ0p1bGhvJyxcclxuICA4OiAnQWdvc3RvJyxcclxuICA5OiAnU2V0ZW1icm8nLFxyXG4gIDEwOiAnT3V0dWJybycsXHJcbiAgMTE6ICdOb3ZlbWJybycsXHJcbiAgMTI6ICdEZXplbWJybycsXHJcbn1cclxuXHJcbmNvbnN0IGdldFN0eWxlcyA9IChob3Jpem9udGFsOiBib29sZWFuKSA9PiBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgZ3JpZDoge1xyXG4gICAgZGlzcGxheTogJ2dyaWQnLFxyXG4gICAgZ2FwOiAnMTJweCAxNnB4JyxcclxuICAgIGdyaWRUZW1wbGF0ZTogaG9yaXpvbnRhbFxyXG4gICAgICA/IGBcclxuICAgIFwibiBuYyB0aSBpbSBkaSBkZlwiIGF1dG9cclxuICAgIFwiZSBxIHYgY2kgcGEgLlwiIGF1dG9cclxuICAgIFwibSBkIGggcGUgaW4gLlwiIGF1dG9cclxuICAgIFwidCBjIGNjIHJjIC4gLlwiIGF1dG9cclxuICAgIFwibyBvIG8gbyBvIG9cIiBhdXRvXHJcbiAgICBcIm9hIG9hIG9hIG9hIG9hIG9hXCIgYXV0byAvIDFmciAxZnIgMWZyIDFmciAxZnIgMWZyXHJcbiAgICBgXHJcbiAgICAgIDogYFxyXG4gICAgICBcIm4gbiBuYyBuY1wiIGF1dG9cclxuICAgICAgXCJnYSBnYSAuIC5cIiBhdXRvXHJcbiAgICAgIFwidGkgdGkgdGkgdGlcIiBhdXRvXHJcbiAgICAgIFwiaW0gaW0gaW0gaW1cIiBhdXRvXHJcbiAgICAgIFwidCB0IHQgdFwiIGF1dG9cclxuICAgICAgXCJjIGMgYyBjXCIgYXV0b1xyXG4gICAgICBcImRpIGRpIGRmIGRmXCIgYXV0b1xyXG4gICAgICBcImUgZSBtIG1cIiBhdXRvXHJcbiAgICAgIFwicSB2IGggaFwiIGF1dG9cclxuICAgICAgXCJwZSBwZSAuIC5cIiBhdXRvXHJcbiAgICAgIFwiZW0gZW0gZW0gZW1cIiBhdXRvXHJcbiAgICAgIFwiZCBkIGQgZFwiIGF1dG9cclxuICAgICAgXCJwYSBwYSBwYSBwYVwiIGF1dG9cclxuICAgICAgXCJjaSBjaSBjaSBjaVwiIGF1dG9cclxuICAgICAgXCJpbiBpbiBpbiBpblwiIGF1dG9cclxuICAgICAgXCJjYyBjYyBjYyBjY1wiIGF1dG9cclxuICAgICAgXCJjbSBjbSBjdCBjdFwiIGF1dG9cclxuICAgICAgXCJyYyByYyByYyByY1wiIGF1dG9cclxuICAgICAgXCJvIG8gbyBvXCIgYXV0b1xyXG4gICAgICBcIm9hIG9hIG9hIG9hXCIgYXV0byAvIDFmciAxZnIgMWZyIDFmclxyXG4gICAgYCxcclxuICB9LFxyXG4gIG51bWVyb1Byb3Bvc3RhOiB7IGdyaWRBcmVhOiAnbicgfSxcclxuICBudW1lcm9Qcm9wb3N0YUNvbWVyY2lhbDogeyBncmlkQXJlYTogJ25jJyB9LFxyXG4gIHJlc3BvbnNhdmVsVGVjbmljbzogeyBncmlkQXJlYTogJ3QnIH0sXHJcbiAgcmVzcG9uc2F2ZWxDbGllbnRlOiB7IGdyaWRBcmVhOiAnYycgfSxcclxuICByZXNwb25zYXZlbENvbWVyY2lhbDogeyBncmlkQXJlYTogJ3JjJyB9LFxyXG4gIGV4ZXJjaWNpbzogeyBncmlkQXJlYTogJ2UnIH0sXHJcbiAgbWVzUmVub3ZhY2FvOiB7IGdyaWRBcmVhOiAnbScgfSxcclxuICBxdGRIb3JhczogeyBncmlkQXJlYTogJ3EnIH0sXHJcbiAgdmFsb3I6IHsgZ3JpZEFyZWE6ICd2JyB9LFxyXG4gIHZhbG9ySG9yYTogeyBncmlkQXJlYTogJ2gnIH0sXHJcbiAgdGlwb0NvbnRyYXRvOiB7IGdyaWRBcmVhOiAndGknIH0sXHJcbiAgaW1wb3N0b3M6IHsgZ3JpZEFyZWE6ICdpbScgfSxcclxuICBpbmljaW9Db250cmF0bzogeyBncmlkQXJlYTogJ2RpJyB9LFxyXG4gIGZpbmFsQ29udHJhdG86IHsgZ3JpZEFyZWE6ICdkZicgfSxcclxuICBwZXJjZW50dWFsRXhpdG86IHsgZ3JpZEFyZWE6ICdwZScgfSxcclxuICBjb250YXRvQ2xpZW50ZTogeyBncmlkQXJlYTogJ2NjJyB9LFxyXG4gIGNvbnRhdG9FbWFpbDogeyBncmlkQXJlYTogJ2NtJyB9LFxyXG4gIGNvbnRhdG9UZWxlZm9uZTogeyBncmlkQXJlYTogJ2N0JyB9LFxyXG4gIGRlc3Blc2FWaWFnZW06IHsgZ3JpZEFyZWE6ICdkJyB9LFxyXG4gIHBhcmVjZXI6IHsgZ3JpZEFyZWE6ICdwYScgfSxcclxuICBjaXJjdWxhcml6YWNhbzogeyBncmlkQXJlYTogJ2NpJyB9LFxyXG4gIGludmVudGFyaW86IHsgZ3JpZEFyZWE6ICdpbicgfSxcclxuICBvYnNlcnZhY2FvOiB7IGdyaWRBcmVhOiAnbycgfSxcclxuICBvYnNlcnZhY2FvQWNlaXRlOiB7IGdyaWRBcmVhOiAnb2EnIH0sXHJcbiAgZW1wcmVzYXM6IHsgZ3JpZEFyZWE6ICdlbScgfSxcclxuICBnZXJhQXVkaXRvcmlhOiB7IGdyaWRBcmVhOiAnZ2EnIH0sXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb250cmFjdERldGFpbHNcclxuIl19