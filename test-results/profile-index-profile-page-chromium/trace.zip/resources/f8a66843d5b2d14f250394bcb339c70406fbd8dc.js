import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTable.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { get } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { DataTableContent, DataTablePagination, DataTableSearch, DataTableEmptyState } from "/src/shared/components/datatable/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
import { ControlsColumnNameEnum } from "/src/shared/enums/ControlsColumnNameEnum.ts";
function DataTable(props) {
  _s();
  const theme = useTheme();
  const {
    columns,
    items,
    paginated,
    hasSearch,
    renderActions,
    hasControlsColumn,
    menuOptions,
    multipleSelection,
    selection,
    onSelection,
    hasSelection,
    hiddenMenu,
    groups,
    itemsNotSorted,
    onRenderFooter,
    notScrollable,
    sortConfig: outSortConfig,
    isHeaderVisible,
    externalRowStyles,
    childrenGap = true,
    customPageOptions,
    controlsColumnName = ControlsColumnNameEnum.CONTROLS,
    onSingleActionControlClick,
    disableMenu,
    disableMenuText
  } = props;
  const [searchText, setSearchText] = useState("");
  const [transformedItems, setTransformedItems] = useState([]);
  const [paginatedItems, setPaginatedItems] = useState([]);
  const [sortConfig, setSortConfig] = useState(outSortConfig);
  const [paginationConfig, setPaginationConfig] = useState({
    itemsSkipped: 0,
    pageSize: 10
  });
  const filterKeys = useMemo(() => columns.filter((c) => c.filterable && typeof c.field === "string").map(({
    field
  }) => field), [columns]);
  const onHeaderClick = useCallback((column) => {
    setSortConfig(column);
  }, []);
  useEffect(() => {
    if (!outSortConfig) {
      onHeaderClick({
        field: columns[0].field,
        descending: true
      });
    }
  }, [outSortConfig]);
  useEffect(() => {
    if (sortConfig) {
      setTransformedItems(sortItems(filterItems(items, searchText, filterKeys), sortConfig.field, sortConfig.descending));
    }
  }, [items, searchText, sortConfig]);
  useEffect(() => {
    if (paginated) {
      const {
        itemsSkipped,
        pageSize
      } = paginationConfig;
      setPaginatedItems(transformedItems.slice(itemsSkipped, itemsSkipped + pageSize));
    } else {
      setPaginatedItems(transformedItems);
    }
  }, [transformedItems, paginationConfig, paginated]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: childrenGap ? theme.spacing.lg : 0, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", children: [
      !hiddenMenu && /* @__PURE__ */ jsxDEV(FlexRow, { styles: {
        flexGrow: 1
      }, gap: theme.spacing.lg, children: renderActions?.() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
        lineNumber: 109,
        columnNumber: 25
      }, this),
      hasSearch && /* @__PURE__ */ jsxDEV(DataTableSearch, { onChange: setSearchText }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
        lineNumber: 114,
        columnNumber: 23
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    items && items?.length > 0 && /* @__PURE__ */ jsxDEV(DataTableContent, { columns, items: itemsNotSorted ? items : paginatedItems, groups, onHeaderClick, multipleSelection, selection, onSelection, hasControlsColumn, menuOptions, hasSelection, compact: true, sortConfig, onRenderFooter, notScrollable, isHeaderVisible: isHeaderVisible ?? true, externalRowStyles, paginated, controlsColumnName, onSingleActionControlClick, disableMenu, disableMenuText }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
      lineNumber: 116,
      columnNumber: 38
    }, this),
    items && items.length === 0 && /* @__PURE__ */ jsxDEV(DataTableEmptyState, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
      lineNumber: 117,
      columnNumber: 39
    }, this),
    paginated && /* @__PURE__ */ jsxDEV(DataTablePagination, { pageItemsCount: paginatedItems.length, totalItemsCount: transformedItems?.length ?? 0, onPageChange: setPaginationConfig, customPageOptions }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
      lineNumber: 118,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx",
    lineNumber: 107,
    columnNumber: 10
  }, this);
}
_s(DataTable, "sWieSeT09/Aewd2dlsGeHdXKOKE=", false, function() {
  return [useTheme];
});
_c = DataTable;
function normalizeString(text) {
  return text.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
}
function filterItems(items, text, keys) {
  if (text) {
    return items.filter((item) => {
      return keys.some((key) => {
        const value = get(item, key);
        if (value === void 0 || value === null) {
          return false;
        }
        return normalizeString(value.toString()).includes(normalizeString(text));
      });
    });
  }
  return items;
}
const compareNumber = (a, b) => b - a;
const compareString = (a, b) => a.localeCompare(b);
function compare(a, b) {
  if (typeof a === "number" && typeof b === "number") {
    return compareNumber(a, b);
  }
  if (typeof a === "string" && typeof b === "string") {
    return compareString(a, b);
  }
  if (a === void 0 || a === null) {
    return 1;
  }
  if (b === void 0 || b === null) {
    return -1;
  }
  throw new Error("Wrong parameters types. Both must be the same type.");
}
function sortItems(items, field, isSortedDescending) {
  return [...items].sort((a, b) => (isSortedDescending ? 1 : -1) * compare(get(a, field), get(b, field)));
}
export default DataTable;
var _c;
$RefreshReg$(_c, "DataTable");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUp5Qjs7Ozs7Ozs7Ozs7Ozs7OztBQW5KekIsU0FBU0EsVUFBVUMsV0FBV0MsU0FBU0MsbUJBQWlDO0FBVXhFLFNBQVNDLFdBQVc7QUFFcEIsU0FDRUMsa0JBQ0FDLHFCQUNBQyxpQkFJQUMsMkJBQ0s7QUFDUCxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsOEJBQThCO0FBK0J2QyxTQUFTQyxVQUE2QkMsT0FBd0M7QUFBQUMsS0FBQTtBQUM1RSxRQUFNQyxRQUFRUCxTQUFTO0FBQ3ZCLFFBQU07QUFBQSxJQUNKUTtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxZQUFZQztBQUFBQSxJQUNaQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxjQUFjO0FBQUEsSUFDZEM7QUFBQUEsSUFDQUMscUJBQXFCM0IsdUJBQXVCNEI7QUFBQUEsSUFDNUNDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSTdCO0FBRUosUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJN0MsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhDLGtCQUFrQkMsbUJBQW1CLElBQUkvQyxTQUFjLEVBQUU7QUFDaEUsUUFBTSxDQUFDZ0QsZ0JBQWdCQyxpQkFBaUIsSUFBSWpELFNBQWMsRUFBRTtBQUU1RCxRQUFNLENBQUNpQyxZQUFZaUIsYUFBYSxJQUFJbEQsU0FBd0NrQyxhQUFhO0FBQ3pGLFFBQU0sQ0FBQ2lCLGtCQUFrQkMsbUJBQW1CLElBQUlwRCxTQUFvQztBQUFBLElBQ2xGcUQsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFFRCxRQUFNQyxhQUFhckQsUUFBUSxNQUN6QmUsUUFDR3VDLE9BQU9DLE9BQUtBLEVBQUVDLGNBQWMsT0FBT0QsRUFBRUUsVUFBVSxRQUFRLEVBQ3ZEQyxJQUFJLENBQUM7QUFBQSxJQUFFRDtBQUFBQSxFQUFNLE1BQU1BLEtBQWUsR0FDcEMsQ0FBQzFDLE9BQU8sQ0FBQztBQUVaLFFBQU00QyxnQkFBZ0IxRCxZQUFZLENBQUMyRCxXQUFzQztBQUN2RVosa0JBQWNZLE1BQU07QUFBQSxFQUN0QixHQUFHLEVBQUU7QUFFTDdELFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ2lDLGVBQWU7QUFDbEIyQixvQkFBYztBQUFBLFFBQ1pGLE9BQU8xQyxRQUFRLENBQUMsRUFBRTBDO0FBQUFBLFFBQ2xCSSxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxDQUFDN0IsYUFBYSxDQUFDO0FBRWxCakMsWUFBVSxNQUFNO0FBQ2QsUUFBSWdDLFlBQVk7QUFDZGMsMEJBQ0VpQixVQUNFQyxZQUFZL0MsT0FBTzBCLFlBQVlXLFVBQVUsR0FDekN0QixXQUFXMEIsT0FDWDFCLFdBQVc4QixVQUNiLENBQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUM3QyxPQUFPMEIsWUFBWVgsVUFBVSxDQUFDO0FBRWxDaEMsWUFBVSxNQUFNO0FBQ2QsUUFBSWtCLFdBQVc7QUFDYixZQUFNO0FBQUEsUUFBRWtDO0FBQUFBLFFBQWNDO0FBQUFBLE1BQVMsSUFBSUg7QUFDbkNGLHdCQUNFSCxpQkFBaUJvQixNQUNmYixjQUNBQSxlQUFlQyxRQUNqQixDQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0xMLHdCQUFrQkgsZ0JBQWdCO0FBQUEsSUFDcEM7QUFBQSxFQUNGLEdBQUcsQ0FBQ0Esa0JBQWtCSyxrQkFBa0JoQyxTQUFTLENBQUM7QUFFbEQsU0FDRSx1QkFBQyxjQUNDLEtBQU1rQixjQUFjckIsTUFBTW1ELFFBQVFDLEtBQUssR0FFdkM7QUFBQSwyQkFBQyxXQUNDLGlCQUFnQixpQkFFZDtBQUFBLE9BQUN4QyxjQUFjLHVCQUFDLFdBQ2hCLFFBQVE7QUFBQSxRQUFFeUMsVUFBVTtBQUFBLE1BQUUsR0FDdEIsS0FBS3JELE1BQU1tRCxRQUFRQyxJQUVsQi9DLDBCQUFnQixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLakI7QUFBQSxNQUNDRCxhQUFhLHVCQUFDLG1CQUFnQixVQUFVeUIsaUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQVR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNDM0IsU0FBU0EsT0FBT29ELFNBQVMsS0FBSyx1QkFBQyxvQkFDOUIsU0FDQSxPQUFPeEMsaUJBQWlCWixRQUFROEIsZ0JBQ2hDLFFBQ0EsZUFDQSxtQkFDQSxXQUNBLGFBQ0EsbUJBQ0EsYUFDQSxjQUNBLFNBQU8sTUFDUCxZQUNBLGdCQUNBLGVBQ0EsaUJBQWlCYixtQkFBbUIsTUFDcEMsbUJBQ0EsV0FDQSxvQkFDQSw0QkFDQSxhQUNBLG1CQXJCNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCSTtBQUFBLElBRWxDakIsU0FBU0EsTUFBTW9ELFdBQVcsS0FDekIsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQjtBQUFBLElBRXJCbkQsYUFBYSx1QkFBQyx1QkFDYixnQkFBZ0I2QixlQUFlc0IsUUFDL0IsaUJBQWlCeEIsa0JBQWtCd0IsVUFBVSxHQUM3QyxjQUFjbEIscUJBQ2QscUJBSlk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUl5QjtBQUFBLE9BNUN6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBO0FBRUo7QUFBQ3JDLEdBdElRRixXQUFTO0FBQUEsVUFDRkosUUFBUTtBQUFBO0FBQUE4RCxLQURmMUQ7QUF3SVQsU0FBUzJELGdCQUFpQkMsTUFBYztBQUN0QyxTQUFPQSxLQUFLQyxVQUFVLEtBQUssRUFBRUMsUUFBUSxtQkFBbUIsRUFBRSxFQUFFQyxZQUFZO0FBQzFFO0FBRUEsU0FBU1gsWUFBK0IvQyxPQUFZdUQsTUFBY0ksTUFBcUI7QUFDckYsTUFBSUosTUFBTTtBQUNSLFdBQU92RCxNQUFNc0MsT0FBT3NCLFVBQVE7QUFDMUIsYUFBT0QsS0FBS0UsS0FBS0MsU0FBTztBQUN0QixjQUFNQyxRQUFRN0UsSUFBSTBFLE1BQU1FLEdBQUc7QUFDM0IsWUFBSUMsVUFBVUMsVUFBYUQsVUFBVSxNQUFNO0FBQ3pDLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGVBQU9ULGdCQUFnQlMsTUFBTUUsU0FBUyxDQUFDLEVBQ3BDQyxTQUFTWixnQkFBZ0JDLElBQUksQ0FBQztBQUFBLE1BQ25DLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBT3ZEO0FBQ1Q7QUFFQSxNQUFNbUUsZ0JBQWdCQSxDQUFDQyxHQUFXQyxNQUFjQSxJQUFJRDtBQUVwRCxNQUFNRSxnQkFBZ0JBLENBQUNGLEdBQVdDLE1BQWNELEVBQUVHLGNBQWNGLENBQUM7QUFFakUsU0FBU0csUUFBU0osR0FBbUJDLEdBQW1CO0FBQ3RELE1BQUksT0FBT0QsTUFBTSxZQUFZLE9BQU9DLE1BQU0sVUFBVTtBQUNsRCxXQUFPRixjQUFjQyxHQUFHQyxDQUFDO0FBQUEsRUFDM0I7QUFDQSxNQUFJLE9BQU9ELE1BQU0sWUFBWSxPQUFPQyxNQUFNLFVBQVU7QUFDbEQsV0FBT0MsY0FBY0YsR0FBR0MsQ0FBQztBQUFBLEVBQzNCO0FBQ0EsTUFBSUQsTUFBTUosVUFBYUksTUFBTSxNQUFNO0FBQ2pDLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSUMsTUFBTUwsVUFBYUssTUFBTSxNQUFNO0FBQ2pDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxJQUFJSSxNQUFNLHFEQUFxRDtBQUN2RTtBQUVBLFNBQVMzQixVQUFjOUMsT0FBWXlDLE9BQWVpQyxvQkFBbUM7QUFDbkYsU0FBTyxDQUFDLEdBQUcxRSxLQUFLLEVBQUUyRSxLQUNoQixDQUFDUCxHQUFNQyxPQUNKSyxxQkFBcUIsSUFBSSxNQUFNRixRQUFRdEYsSUFBSWtGLEdBQUczQixLQUFLLEdBQUd2RCxJQUFJbUYsR0FBRzVCLEtBQUssQ0FBQyxDQUV4RTtBQUNGO0FBRUEsZUFBZTlDO0FBQVMsSUFBQTBEO0FBQUF1QixhQUFBdkIsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwiZ2V0IiwiRGF0YVRhYmxlQ29udGVudCIsIkRhdGFUYWJsZVBhZ2luYXRpb24iLCJEYXRhVGFibGVTZWFyY2giLCJEYXRhVGFibGVFbXB0eVN0YXRlIiwidXNlVGhlbWUiLCJGbGV4Q29sdW1uIiwiRmxleFJvdyIsIkNvbnRyb2xzQ29sdW1uTmFtZUVudW0iLCJEYXRhVGFibGUiLCJwcm9wcyIsIl9zIiwidGhlbWUiLCJjb2x1bW5zIiwiaXRlbXMiLCJwYWdpbmF0ZWQiLCJoYXNTZWFyY2giLCJyZW5kZXJBY3Rpb25zIiwiaGFzQ29udHJvbHNDb2x1bW4iLCJtZW51T3B0aW9ucyIsIm11bHRpcGxlU2VsZWN0aW9uIiwic2VsZWN0aW9uIiwib25TZWxlY3Rpb24iLCJoYXNTZWxlY3Rpb24iLCJoaWRkZW5NZW51IiwiZ3JvdXBzIiwiaXRlbXNOb3RTb3J0ZWQiLCJvblJlbmRlckZvb3RlciIsIm5vdFNjcm9sbGFibGUiLCJzb3J0Q29uZmlnIiwib3V0U29ydENvbmZpZyIsImlzSGVhZGVyVmlzaWJsZSIsImV4dGVybmFsUm93U3R5bGVzIiwiY2hpbGRyZW5HYXAiLCJjdXN0b21QYWdlT3B0aW9ucyIsImNvbnRyb2xzQ29sdW1uTmFtZSIsIkNPTlRST0xTIiwib25TaW5nbGVBY3Rpb25Db250cm9sQ2xpY2siLCJkaXNhYmxlTWVudSIsImRpc2FibGVNZW51VGV4dCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwidHJhbnNmb3JtZWRJdGVtcyIsInNldFRyYW5zZm9ybWVkSXRlbXMiLCJwYWdpbmF0ZWRJdGVtcyIsInNldFBhZ2luYXRlZEl0ZW1zIiwic2V0U29ydENvbmZpZyIsInBhZ2luYXRpb25Db25maWciLCJzZXRQYWdpbmF0aW9uQ29uZmlnIiwiaXRlbXNTa2lwcGVkIiwicGFnZVNpemUiLCJmaWx0ZXJLZXlzIiwiZmlsdGVyIiwiYyIsImZpbHRlcmFibGUiLCJmaWVsZCIsIm1hcCIsIm9uSGVhZGVyQ2xpY2siLCJjb2x1bW4iLCJkZXNjZW5kaW5nIiwic29ydEl0ZW1zIiwiZmlsdGVySXRlbXMiLCJzbGljZSIsInNwYWNpbmciLCJsZyIsImZsZXhHcm93IiwibGVuZ3RoIiwiX2MiLCJub3JtYWxpemVTdHJpbmciLCJ0ZXh0Iiwibm9ybWFsaXplIiwicmVwbGFjZSIsInRvTG93ZXJDYXNlIiwia2V5cyIsIml0ZW0iLCJzb21lIiwia2V5IiwidmFsdWUiLCJ1bmRlZmluZWQiLCJ0b1N0cmluZyIsImluY2x1ZGVzIiwiY29tcGFyZU51bWJlciIsImEiLCJiIiwiY29tcGFyZVN0cmluZyIsImxvY2FsZUNvbXBhcmUiLCJjb21wYXJlIiwiRXJyb3IiLCJpc1NvcnRlZERlc2NlbmRpbmciLCJzb3J0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGF0YVRhYmxlLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2RhdGF0YWJsZS9EYXRhVGFibGUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlQ2FsbGJhY2ssIFJlYWN0RWxlbWVudCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQge1xyXG4gIElDb250ZXh0dWFsTWVudUl0ZW0sXHJcbiAgSUdyb3VwLFxyXG4gIElEZXRhaWxzR3JvdXBEaXZpZGVyUHJvcHMsXHJcbiAgSVN0eWxlRnVuY3Rpb25Pck9iamVjdCxcclxuICBJRGV0YWlsc1Jvd1N0eWxlUHJvcHMsXHJcbiAgSURldGFpbHNSb3dTdHlsZXMsXHJcbiAgSUNvbWJvQm94T3B0aW9uLFxyXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgZ2V0IH0gZnJvbSAnbG9kYXNoLWVzJ1xyXG5pbXBvcnQgRW50aXR5IGZyb20gJy4uLy4uLy4uL2RvbWFpbi9FbnRpdHknXHJcbmltcG9ydCB7XHJcbiAgRGF0YVRhYmxlQ29udGVudCxcclxuICBEYXRhVGFibGVQYWdpbmF0aW9uLFxyXG4gIERhdGFUYWJsZVNlYXJjaCxcclxuICBEYXRhVGFibGVDb2x1bW4sXHJcbiAgRGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZyxcclxuICBEYXRhVGFibGVTb3J0Q29uZmlnLFxyXG4gIERhdGFUYWJsZUVtcHR5U3RhdGUsXHJcbn0gZnJvbSAnLidcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuaW1wb3J0IEZsZXhDb2x1bW4gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhDb2x1bW4nXHJcbmltcG9ydCBGbGV4Um93IGZyb20gJy4vLi4vRmxleEJveC9GbGV4Um93J1xyXG5pbXBvcnQgeyBDb250cm9sc0NvbHVtbk5hbWVFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvQ29udHJvbHNDb2x1bW5OYW1lRW51bSdcclxuXHJcbmludGVyZmFjZSBEYXRhVGFibGVQcm9wczxUIGV4dGVuZHMgRW50aXR5PiB7XHJcbiAgY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPFQ+W11cclxuICBpdGVtczogVFtdXHJcbiAgcGFnaW5hdGVkPzogYm9vbGVhblxyXG4gIGhhc1NlYXJjaD86IGJvb2xlYW5cclxuICByZW5kZXJBY3Rpb25zPzogKCkgPT4gUmVhY3RFbGVtZW50XHJcbiAgaGFzQ29udHJvbHNDb2x1bW4/OiBib29sZWFuXHJcbiAgbWVudU9wdGlvbnM/OiAoaXRlbTogVCkgPT4gSUNvbnRleHR1YWxNZW51SXRlbVtdXHJcbiAgbXVsdGlwbGVTZWxlY3Rpb24/OiBib29sZWFuXHJcbiAgc2VsZWN0aW9uPzogVFtdXHJcbiAgb25TZWxlY3Rpb24/OiAoaXRlbXM6IFRbXSkgPT4gdm9pZFxyXG4gIGhhc1NlbGVjdGlvbj86IGJvb2xlYW5cclxuICBoaWRkZW5NZW51Pzpib29sZWFuXHJcbiAgY2hpbGRyZW5HYXA/OmJvb2xlYW5cclxuICBncm91cHM/OiBJR3JvdXBbXVxyXG4gIGNvbXBhY3Q/OiBib29sZWFuXHJcbiAgaXRlbXNOb3RTb3J0ZWQ/OiBib29sZWFuXHJcbiAgb25SZW5kZXJGb290ZXI/OiAocHJvcHM6IElEZXRhaWxzR3JvdXBEaXZpZGVyUHJvcHMgfCB1bmRlZmluZWQpID0+IFJlYWN0RWxlbWVudCB8IHVuZGVmaW5lZFxyXG4gIG5vdFNjcm9sbGFibGU/OiBib29sZWFuXHJcbiAgaXNIZWFkZXJWaXNpYmxlPzogYm9vbGVhblxyXG4gIGV4dGVybmFsUm93U3R5bGVzPzogSVN0eWxlRnVuY3Rpb25Pck9iamVjdDxJRGV0YWlsc1Jvd1N0eWxlUHJvcHMsIElEZXRhaWxzUm93U3R5bGVzPlxyXG4gIGN1c3RvbVBhZ2VPcHRpb25zPzogSUNvbWJvQm94T3B0aW9uW10sXHJcbiAgY29udHJvbHNDb2x1bW5OYW1lPzogQ29udHJvbHNDb2x1bW5OYW1lRW51bSxcclxuICBvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljaz86IChpdGVtOiBUKSA9PiB2b2lkXHJcbiAgZGlzYWJsZU1lbnU/OiBib29sZWFuXHJcbiAgZGlzYWJsZU1lbnVUZXh0Pzogc3RyaW5nXHJcbiAgc29ydENvbmZpZz86RGF0YVRhYmxlU29ydENvbmZpZ1xyXG59XHJcblxyXG5mdW5jdGlvbiBEYXRhVGFibGU8VCBleHRlbmRzIEVudGl0eT4gKHByb3BzOiBEYXRhVGFibGVQcm9wczxUPik6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcbiAgY29uc3Qge1xyXG4gICAgY29sdW1ucyxcclxuICAgIGl0ZW1zLFxyXG4gICAgcGFnaW5hdGVkLFxyXG4gICAgaGFzU2VhcmNoLFxyXG4gICAgcmVuZGVyQWN0aW9ucyxcclxuICAgIGhhc0NvbnRyb2xzQ29sdW1uLFxyXG4gICAgbWVudU9wdGlvbnMsXHJcbiAgICBtdWx0aXBsZVNlbGVjdGlvbixcclxuICAgIHNlbGVjdGlvbixcclxuICAgIG9uU2VsZWN0aW9uLFxyXG4gICAgaGFzU2VsZWN0aW9uLFxyXG4gICAgaGlkZGVuTWVudSxcclxuICAgIGdyb3VwcyxcclxuICAgIGl0ZW1zTm90U29ydGVkLFxyXG4gICAgb25SZW5kZXJGb290ZXIsXHJcbiAgICBub3RTY3JvbGxhYmxlLFxyXG4gICAgc29ydENvbmZpZzogb3V0U29ydENvbmZpZyxcclxuICAgIGlzSGVhZGVyVmlzaWJsZSxcclxuICAgIGV4dGVybmFsUm93U3R5bGVzLFxyXG4gICAgY2hpbGRyZW5HYXAgPSB0cnVlLFxyXG4gICAgY3VzdG9tUGFnZU9wdGlvbnMsXHJcbiAgICBjb250cm9sc0NvbHVtbk5hbWUgPSBDb250cm9sc0NvbHVtbk5hbWVFbnVtLkNPTlRST0xTLFxyXG4gICAgb25TaW5nbGVBY3Rpb25Db250cm9sQ2xpY2ssXHJcbiAgICBkaXNhYmxlTWVudSxcclxuICAgIGRpc2FibGVNZW51VGV4dCxcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3RyYW5zZm9ybWVkSXRlbXMsIHNldFRyYW5zZm9ybWVkSXRlbXNdID0gdXNlU3RhdGU8VFtdPihbXSlcclxuICBjb25zdCBbcGFnaW5hdGVkSXRlbXMsIHNldFBhZ2luYXRlZEl0ZW1zXSA9IHVzZVN0YXRlPFRbXT4oW10pXHJcblxyXG4gIGNvbnN0IFtzb3J0Q29uZmlnLCBzZXRTb3J0Q29uZmlnXSA9IHVzZVN0YXRlPERhdGFUYWJsZVNvcnRDb25maWd8dW5kZWZpbmVkPihvdXRTb3J0Q29uZmlnKVxyXG4gIGNvbnN0IFtwYWdpbmF0aW9uQ29uZmlnLCBzZXRQYWdpbmF0aW9uQ29uZmlnXSA9IHVzZVN0YXRlPERhdGFUYWJsZVBhZ2luYXRpb25Db25maWc+KHtcclxuICAgIGl0ZW1zU2tpcHBlZDogMCxcclxuICAgIHBhZ2VTaXplOiAxMCxcclxuICB9KVxyXG5cclxuICBjb25zdCBmaWx0ZXJLZXlzID0gdXNlTWVtbygoKSA9PiAoXHJcbiAgICBjb2x1bW5zXHJcbiAgICAgIC5maWx0ZXIoYyA9PiBjLmZpbHRlcmFibGUgJiYgdHlwZW9mIGMuZmllbGQgPT09ICdzdHJpbmcnKVxyXG4gICAgICAubWFwKCh7IGZpZWxkIH0pID0+IGZpZWxkIGFzIHN0cmluZylcclxuICApLCBbY29sdW1uc10pXHJcblxyXG4gIGNvbnN0IG9uSGVhZGVyQ2xpY2sgPSB1c2VDYWxsYmFjaygoY29sdW1uOiBEYXRhVGFibGVTb3J0Q29uZmlnKTogdm9pZCA9PiB7XHJcbiAgICBzZXRTb3J0Q29uZmlnKGNvbHVtbilcclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3V0U29ydENvbmZpZykge1xyXG4gICAgICBvbkhlYWRlckNsaWNrKHtcclxuICAgICAgICBmaWVsZDogY29sdW1uc1swXS5maWVsZCBhcyBzdHJpbmcsXHJcbiAgICAgICAgZGVzY2VuZGluZzogdHJ1ZSxcclxuICAgICAgfSlcclxuICAgIH1cclxuICB9LCBbb3V0U29ydENvbmZpZ10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc29ydENvbmZpZykge1xyXG4gICAgICBzZXRUcmFuc2Zvcm1lZEl0ZW1zKFxyXG4gICAgICAgIHNvcnRJdGVtcyhcclxuICAgICAgICAgIGZpbHRlckl0ZW1zKGl0ZW1zLCBzZWFyY2hUZXh0LCBmaWx0ZXJLZXlzKSxcclxuICAgICAgICAgIHNvcnRDb25maWcuZmllbGQsXHJcbiAgICAgICAgICBzb3J0Q29uZmlnLmRlc2NlbmRpbmcsXHJcbiAgICAgICAgKSxcclxuICAgICAgKVxyXG4gICAgfVxyXG4gIH0sIFtpdGVtcywgc2VhcmNoVGV4dCwgc29ydENvbmZpZ10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocGFnaW5hdGVkKSB7XHJcbiAgICAgIGNvbnN0IHsgaXRlbXNTa2lwcGVkLCBwYWdlU2l6ZSB9ID0gcGFnaW5hdGlvbkNvbmZpZ1xyXG4gICAgICBzZXRQYWdpbmF0ZWRJdGVtcyhcclxuICAgICAgICB0cmFuc2Zvcm1lZEl0ZW1zLnNsaWNlKFxyXG4gICAgICAgICAgaXRlbXNTa2lwcGVkLFxyXG4gICAgICAgICAgaXRlbXNTa2lwcGVkICsgcGFnZVNpemUsXHJcbiAgICAgICAgKSxcclxuICAgICAgKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0UGFnaW5hdGVkSXRlbXModHJhbnNmb3JtZWRJdGVtcylcclxuICAgIH1cclxuICB9LCBbdHJhbnNmb3JtZWRJdGVtcywgcGFnaW5hdGlvbkNvbmZpZywgcGFnaW5hdGVkXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxGbGV4Q29sdW1uXHJcbiAgICAgIGdhcD17IGNoaWxkcmVuR2FwID8gdGhlbWUuc3BhY2luZy5sZyA6IDAgfVxyXG4gICAgPlxyXG4gICAgICA8RmxleFJvd1xyXG4gICAgICAgIGhvcml6b250YWxBbGlnbj1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICA+XHJcbiAgICAgICAgeyAhaGlkZGVuTWVudSAmJiA8RmxleFJvd1xyXG4gICAgICAgICAgc3R5bGVzPXt7IGZsZXhHcm93OiAxIH19XHJcbiAgICAgICAgICBnYXA9e3RoZW1lLnNwYWNpbmcubGd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3JlbmRlckFjdGlvbnM/LigpfVxyXG4gICAgICAgIDwvRmxleFJvdz59XHJcbiAgICAgICAge2hhc1NlYXJjaCAmJiA8RGF0YVRhYmxlU2VhcmNoIG9uQ2hhbmdlPXtzZXRTZWFyY2hUZXh0fSAvPn1cclxuICAgICAgPC9GbGV4Um93PlxyXG4gICAgICB7aXRlbXMgJiYgaXRlbXM/Lmxlbmd0aCA+IDAgJiYgPERhdGFUYWJsZUNvbnRlbnRcclxuICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgIGl0ZW1zPXtpdGVtc05vdFNvcnRlZCA/IGl0ZW1zIDogcGFnaW5hdGVkSXRlbXN9XHJcbiAgICAgICAgZ3JvdXBzPXtncm91cHN9XHJcbiAgICAgICAgb25IZWFkZXJDbGljaz17b25IZWFkZXJDbGlja31cclxuICAgICAgICBtdWx0aXBsZVNlbGVjdGlvbj17bXVsdGlwbGVTZWxlY3Rpb259XHJcbiAgICAgICAgc2VsZWN0aW9uPXtzZWxlY3Rpb259XHJcbiAgICAgICAgb25TZWxlY3Rpb249e29uU2VsZWN0aW9ufVxyXG4gICAgICAgIGhhc0NvbnRyb2xzQ29sdW1uPXtoYXNDb250cm9sc0NvbHVtbn1cclxuICAgICAgICBtZW51T3B0aW9ucz17bWVudU9wdGlvbnN9XHJcbiAgICAgICAgaGFzU2VsZWN0aW9uPXtoYXNTZWxlY3Rpb259XHJcbiAgICAgICAgY29tcGFjdFxyXG4gICAgICAgIHNvcnRDb25maWc9e3NvcnRDb25maWd9XHJcbiAgICAgICAgb25SZW5kZXJGb290ZXI9e29uUmVuZGVyRm9vdGVyfVxyXG4gICAgICAgIG5vdFNjcm9sbGFibGU9e25vdFNjcm9sbGFibGV9XHJcbiAgICAgICAgaXNIZWFkZXJWaXNpYmxlPXtpc0hlYWRlclZpc2libGUgPz8gdHJ1ZX1cclxuICAgICAgICBleHRlcm5hbFJvd1N0eWxlcz17ZXh0ZXJuYWxSb3dTdHlsZXN9XHJcbiAgICAgICAgcGFnaW5hdGVkPXtwYWdpbmF0ZWR9XHJcbiAgICAgICAgY29udHJvbHNDb2x1bW5OYW1lPXtjb250cm9sc0NvbHVtbk5hbWV9XHJcbiAgICAgICAgb25TaW5nbGVBY3Rpb25Db250cm9sQ2xpY2s9e29uU2luZ2xlQWN0aW9uQ29udHJvbENsaWNrfVxyXG4gICAgICAgIGRpc2FibGVNZW51PXtkaXNhYmxlTWVudX1cclxuICAgICAgICBkaXNhYmxlTWVudVRleHQ9e2Rpc2FibGVNZW51VGV4dH1cclxuICAgICAgLz59XHJcbiAgICAgIHtpdGVtcyAmJiBpdGVtcy5sZW5ndGggPT09IDAgJiZcclxuICAgICAgICA8RGF0YVRhYmxlRW1wdHlTdGF0ZSAvPlxyXG4gICAgICB9XHJcbiAgICAgIHtwYWdpbmF0ZWQgJiYgPERhdGFUYWJsZVBhZ2luYXRpb25cclxuICAgICAgICBwYWdlSXRlbXNDb3VudD17cGFnaW5hdGVkSXRlbXMubGVuZ3RofVxyXG4gICAgICAgIHRvdGFsSXRlbXNDb3VudD17dHJhbnNmb3JtZWRJdGVtcz8ubGVuZ3RoID8/IDB9XHJcbiAgICAgICAgb25QYWdlQ2hhbmdlPXtzZXRQYWdpbmF0aW9uQ29uZmlnfVxyXG4gICAgICAgIGN1c3RvbVBhZ2VPcHRpb25zPXtjdXN0b21QYWdlT3B0aW9uc31cclxuICAgICAgLz59XHJcbiAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBub3JtYWxpemVTdHJpbmcgKHRleHQ6IHN0cmluZykge1xyXG4gIHJldHVybiB0ZXh0Lm5vcm1hbGl6ZSgnTkZEJykucmVwbGFjZSgvXFxwe0RpYWNyaXRpY30vZ3UsICcnKS50b0xvd2VyQ2FzZSgpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZpbHRlckl0ZW1zPFQgZXh0ZW5kcyBFbnRpdHk+IChpdGVtczogVFtdLCB0ZXh0OiBzdHJpbmcsIGtleXM6IHN0cmluZ1tdKTogVFtdIHtcclxuICBpZiAodGV4dCkge1xyXG4gICAgcmV0dXJuIGl0ZW1zLmZpbHRlcihpdGVtID0+IHtcclxuICAgICAgcmV0dXJuIGtleXMuc29tZShrZXkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0KGl0ZW0sIGtleSlcclxuICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbm9ybWFsaXplU3RyaW5nKHZhbHVlLnRvU3RyaW5nKCkpXHJcbiAgICAgICAgICAuaW5jbHVkZXMobm9ybWFsaXplU3RyaW5nKHRleHQpKVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICB9XHJcbiAgcmV0dXJuIGl0ZW1zXHJcbn1cclxuXHJcbmNvbnN0IGNvbXBhcmVOdW1iZXIgPSAoYTogbnVtYmVyLCBiOiBudW1iZXIpID0+IGIgLSBhXHJcblxyXG5jb25zdCBjb21wYXJlU3RyaW5nID0gKGE6IHN0cmluZywgYjogc3RyaW5nKSA9PiBhLmxvY2FsZUNvbXBhcmUoYilcclxuXHJcbmZ1bmN0aW9uIGNvbXBhcmUgKGE/OiBudW1iZXJ8c3RyaW5nLCBiPzogbnVtYmVyfHN0cmluZykge1xyXG4gIGlmICh0eXBlb2YgYSA9PT0gJ251bWJlcicgJiYgdHlwZW9mIGIgPT09ICdudW1iZXInKSB7XHJcbiAgICByZXR1cm4gY29tcGFyZU51bWJlcihhLCBiKVxyXG4gIH1cclxuICBpZiAodHlwZW9mIGEgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBiID09PSAnc3RyaW5nJykge1xyXG4gICAgcmV0dXJuIGNvbXBhcmVTdHJpbmcoYSwgYilcclxuICB9XHJcbiAgaWYgKGEgPT09IHVuZGVmaW5lZCB8fCBhID09PSBudWxsKSB7XHJcbiAgICByZXR1cm4gMVxyXG4gIH1cclxuICBpZiAoYiA9PT0gdW5kZWZpbmVkIHx8IGIgPT09IG51bGwpIHtcclxuICAgIHJldHVybiAtMVxyXG4gIH1cclxuXHJcbiAgdGhyb3cgbmV3IEVycm9yKCdXcm9uZyBwYXJhbWV0ZXJzIHR5cGVzLiBCb3RoIG11c3QgYmUgdGhlIHNhbWUgdHlwZS4nKVxyXG59XHJcblxyXG5mdW5jdGlvbiBzb3J0SXRlbXM8VD4gKGl0ZW1zOiBUW10sIGZpZWxkOiBzdHJpbmcsIGlzU29ydGVkRGVzY2VuZGluZz86IGJvb2xlYW4pOiBUW10ge1xyXG4gIHJldHVybiBbLi4uaXRlbXNdLnNvcnQoXHJcbiAgICAoYTogVCwgYjogVCkgPT4gKFxyXG4gICAgICAoaXNTb3J0ZWREZXNjZW5kaW5nID8gMSA6IC0xKSAqIGNvbXBhcmUoZ2V0KGEsIGZpZWxkKSwgZ2V0KGIsIGZpZWxkKSlcclxuICAgICksXHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXRhVGFibGVcclxuIl19