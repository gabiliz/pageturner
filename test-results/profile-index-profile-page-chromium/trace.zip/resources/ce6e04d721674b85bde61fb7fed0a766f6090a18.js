import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getScrollPosition from "/src/shared/utils/getScrollPosition.ts";
import { PrimaryButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
const IndependenceTermsDisplay = (props) => {
  _s();
  const [value, setValue] = useState(0);
  const {
    toggleIndependenceTermsVisible,
    setIndependenceTerms
  } = props;
  const styles = useStyles();
  useEffect(() => {
    document.querySelector("#terms")?.addEventListener("scroll", () => {
      const scroll = getScrollPosition("terms");
      setValue(scroll);
    });
  }, [value]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.container, children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.content, id: "terms", children: [
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Atesto e confirmo, para os devidos fins e com base no meu conhecimento, que preencho as políticas e procedimentos da empresa de Auditoria Independente “Martinelli Auditores” – abrangendo inclusive o Código de Ética Profissional do Auditor e Requerimento da NBC PA 400 e NBC PO 900 – e que não possuo qualquer vínculo, relação ou interesse na(s) entidade(s), coligada(s) e/ou controlada(s) as quais presto serviço como Auditor Independente, com exceção das relacionada(s) no Anexo I que se faz parte integrante desta declaração." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Declaro não existirem quaisquer circunstâncias que possam gerar perda da minha independência, na condição de auditor(a), com relação as demais entidades por mim auditadas e que não estão relacionadas no Anexo I." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Certifico que sempre que houver alguma alteração nessa condição, que possa incorrer em risco de perda de independência, comprometo-me a informar esse fato por escrito à “Martinelli Auditores”, atualizando prontamente as informações contidas no Anexo I desta declaração." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actions, children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Voltar", onClick: toggleIndependenceTermsVisible }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Li e aceito", disabled: !(value <= 1), onClick: () => {
        setIndependenceTerms(void 0, true);
        toggleIndependenceTermsVisible?.();
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(IndependenceTermsDisplay, "lTQlZIuugxwfbF4lyjd/QMvVu2E=", false, function() {
  return [useStyles];
});
_c = IndependenceTermsDisplay;
const useStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    container: {
      maxWidth: "100%"
    },
    content: {
      maxHeight: "50vh",
      overflow: "auto"
    },
    paragraph: {
      color: colors.neutralLight[600],
      display: "block",
      marginBottom: spacing.lg,
      selectors: {
        "&:last-of-type": {
          marginBottom: spacing.xxl
        }
      }
    },
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
export default IndependenceTermsDisplay;
var _c;
$RefreshReg$(_c, "IndependenceTermsDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/IndependenceTermsDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJROzs7Ozs7Ozs7Ozs7Ozs7O0FBOUJSLFNBQXdCQSxXQUFXQyxnQkFBZ0I7QUFDbkQsU0FBU0MsZ0JBQWdCQyxZQUFZO0FBQ3JDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxlQUFlQyxxQkFBcUI7QUFDN0MsU0FBU0MsZ0JBQWdCO0FBT3pCLE1BQU1DLDJCQUFnRUMsV0FBVTtBQUFBQyxLQUFBO0FBQzlFLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWCxTQUFpQixDQUFDO0FBQzVDLFFBQU07QUFBQSxJQUNKWTtBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlMO0FBQ0osUUFBTU0sU0FBU0MsVUFBVTtBQUV6QmhCLFlBQVUsTUFBTTtBQUNkaUIsYUFBU0MsY0FBYyxRQUFRLEdBQUdDLGlCQUFpQixVQUFVLE1BQU07QUFDakUsWUFBTUMsU0FBU2hCLGtCQUFrQixPQUFPO0FBRXhDUSxlQUFTUSxNQUFNO0FBQUEsSUFDakIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDVCxLQUFLLENBQUM7QUFFVixTQUNFLHVCQUFDLFNBQUksV0FBV0ksT0FBT00sV0FDckI7QUFBQSwyQkFBQyxTQUFJLFdBQVdOLE9BQU9PLFNBQVMsSUFBRyxTQUNqQztBQUFBLDZCQUFDLFFBQUssV0FBV1AsT0FBT1EsV0FBVSwraEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFXUixPQUFPUSxXQUFVLG1PQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBV1IsT0FBT1EsV0FBVSw2UkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXUixPQUFPUyxTQUNyQjtBQUFBLDZCQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTWCxrQ0FGWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTBDO0FBQUEsTUFFMUMsdUJBQUMsaUJBQ0MsTUFBSyxlQUNMLFVBQVUsRUFBRUYsU0FBbUIsSUFDL0IsU0FBUyxNQUFNO0FBQ2JHLDZCQUFxQlcsUUFBVyxJQUFJO0FBQ3BDWix5Q0FBaUM7QUFBQSxNQUNuQyxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNSTtBQUFBLFNBWE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNILEdBekRLRiwwQkFBNEQ7QUFBQSxVQU1qRFEsU0FBUztBQUFBO0FBQUFVLEtBTnBCbEI7QUEyRE4sTUFBTVEsWUFBWUEsTUFBTTtBQUFBVyxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFTQztBQUFBQSxFQUFPLElBQUl0QixTQUFTO0FBRXJDLFNBQU9MLGVBQWU7QUFBQSxJQUNwQm1CLFdBQVc7QUFBQSxNQUNUUyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0FSLFNBQVM7QUFBQSxNQUNQUyxXQUFXO0FBQUEsTUFDWEMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBVCxXQUFXO0FBQUEsTUFDVFUsT0FBT0osT0FBT0ssYUFBYSxHQUFHO0FBQUEsTUFDOUJDLFNBQVM7QUFBQSxNQUNUQyxjQUFjUixRQUFRUztBQUFBQSxNQUN0QkMsV0FBVztBQUFBLFFBQ1Qsa0JBQWtCO0FBQUEsVUFDaEJGLGNBQWNSLFFBQVFXO0FBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBZixTQUFTO0FBQUEsTUFDUFcsU0FBUztBQUFBLE1BQ1RLLGdCQUFnQjtBQUFBLE1BQ2hCRixXQUFXO0FBQUEsUUFDVCx5QkFBeUI7QUFBQSxVQUN2QkcsYUFBYWIsUUFBUVM7QUFBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNWLElBL0JLWCxXQUFTO0FBQUEsVUFDZVQsUUFBUTtBQUFBO0FBZ0N0QyxlQUFlQztBQUF3QixJQUFBa0I7QUFBQWdCLGFBQUFoQixJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJtZXJnZVN0eWxlU2V0cyIsIlRleHQiLCJnZXRTY3JvbGxQb3NpdGlvbiIsIlByaW1hcnlCdXR0b24iLCJEZWZhdWx0QnV0dG9uIiwidXNlVGhlbWUiLCJJbmRlcGVuZGVuY2VUZXJtc0Rpc3BsYXkiLCJwcm9wcyIsIl9zIiwidmFsdWUiLCJzZXRWYWx1ZSIsInRvZ2dsZUluZGVwZW5kZW5jZVRlcm1zVmlzaWJsZSIsInNldEluZGVwZW5kZW5jZVRlcm1zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiYWRkRXZlbnRMaXN0ZW5lciIsInNjcm9sbCIsImNvbnRhaW5lciIsImNvbnRlbnQiLCJwYXJhZ3JhcGgiLCJhY3Rpb25zIiwidW5kZWZpbmVkIiwiX2MiLCJfczIiLCJzcGFjaW5nIiwiY29sb3JzIiwibWF4V2lkdGgiLCJtYXhIZWlnaHQiLCJvdmVyZmxvdyIsImNvbG9yIiwibmV1dHJhbExpZ2h0IiwiZGlzcGxheSIsIm1hcmdpbkJvdHRvbSIsImxnIiwic2VsZWN0b3JzIiwieHhsIiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5SaWdodCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkluZGVwZW5kZW5jZVRlcm1zRGlzcGxheS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0luZGVwZW5kZW5jZVRlcm1zRGlzcGxheS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgRm9ybUV2ZW50LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBtZXJnZVN0eWxlU2V0cywgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCBnZXRTY3JvbGxQb3NpdGlvbiBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdXRpbHMvZ2V0U2Nyb2xsUG9zaXRpb24nXG5pbXBvcnQgeyBQcmltYXJ5QnV0dG9uLCBEZWZhdWx0QnV0dG9uIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcblxuaW50ZXJmYWNlIEluZGVwZW5kZW5jZVRlcm1zRGlzcGxheVByb3BzIHtcbiAgdG9nZ2xlSW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlPzogKCkgPT4gdm9pZFxuICBzZXRJbmRlcGVuZGVuY2VUZXJtczogKGV2OiBGb3JtRXZlbnQ8SFRNTEVsZW1lbnQgfCBIVE1MSW5wdXRFbGVtZW50PiB8IHVuZGVmaW5lZCwgdmFsdWU6IGJvb2xlYW4pID0+IHZvaWRcbn1cblxuY29uc3QgSW5kZXBlbmRlbmNlVGVybXNEaXNwbGF5IDogRkM8SW5kZXBlbmRlbmNlVGVybXNEaXNwbGF5UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGU8bnVtYmVyPigwKVxuICBjb25zdCB7XG4gICAgdG9nZ2xlSW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlLFxuICAgIHNldEluZGVwZW5kZW5jZVRlcm1zLFxuICB9ID0gcHJvcHNcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0ZXJtcycpPy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCAoKSA9PiB7XG4gICAgICBjb25zdCBzY3JvbGwgPSBnZXRTY3JvbGxQb3NpdGlvbigndGVybXMnKVxuXG4gICAgICBzZXRWYWx1ZShzY3JvbGwpXG4gICAgfSlcbiAgfSwgW3ZhbHVlXSlcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGVudH0gaWQ9XCJ0ZXJtc1wiPlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9PlxuICAgICAgICBBdGVzdG8gZSBjb25maXJtbywgcGFyYSBvcyBkZXZpZG9zIGZpbnMgZSBjb20gYmFzZSBubyBtZXUgY29uaGVjaW1lbnRvLFxuICAgICAgICBxdWUgcHJlZW5jaG8gYXMgcG9sw610aWNhcyBlIHByb2NlZGltZW50b3MgZGEgZW1wcmVzYSBkZSBBdWRpdG9yaWFcbiAgICAgICAgSW5kZXBlbmRlbnRlIOKAnE1hcnRpbmVsbGkgQXVkaXRvcmVz4oCdIOKAkyBhYnJhbmdlbmRvIGluY2x1c2l2ZSBvIEPDs2RpZ28gZGVcbiAgICAgICAgw4l0aWNhIFByb2Zpc3Npb25hbCBkbyBBdWRpdG9yIGUgUmVxdWVyaW1lbnRvIGRhIE5CQyBQQSA0MDAgZSBOQkMgUE8gOTAwXG4gICAgICAgIOKAkyBlIHF1ZSBuw6NvIHBvc3N1byBxdWFscXVlciB2w61uY3VsbywgcmVsYcOnw6NvIG91IGludGVyZXNzZSBuYShzKVxuICAgICAgICBlbnRpZGFkZShzKSwgY29saWdhZGEocykgZS9vdSBjb250cm9sYWRhKHMpIGFzIHF1YWlzIHByZXN0byBzZXJ2acOnbyBjb21vXG4gICAgICAgIEF1ZGl0b3IgSW5kZXBlbmRlbnRlLCBjb20gZXhjZcOnw6NvIGRhcyByZWxhY2lvbmFkYShzKSBubyBBbmV4byBJIHF1ZSBzZVxuICAgICAgICBmYXogcGFydGUgaW50ZWdyYW50ZSBkZXN0YSBkZWNsYXJhw6fDo28uXG4gICAgICAgIDwvVGV4dD5cbiAgICAgICAgPFRleHQgY2xhc3NOYW1lPXtzdHlsZXMucGFyYWdyYXBofT5cbiAgICAgICAgRGVjbGFybyBuw6NvIGV4aXN0aXJlbSBxdWFpc3F1ZXIgY2lyY3Vuc3TDom5jaWFzIHF1ZSBwb3NzYW0gZ2VyYXIgcGVyZGEgZGFcbiAgICAgICAgbWluaGEgaW5kZXBlbmTDqm5jaWEsIG5hIGNvbmRpw6fDo28gZGUgYXVkaXRvcihhKSwgY29tIHJlbGHDp8OjbyBhcyBkZW1haXNcbiAgICAgICAgZW50aWRhZGVzIHBvciBtaW0gYXVkaXRhZGFzIGUgcXVlIG7Do28gZXN0w6NvIHJlbGFjaW9uYWRhcyBubyBBbmV4byBJLlxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxUZXh0IGNsYXNzTmFtZT17c3R5bGVzLnBhcmFncmFwaH0+XG4gICAgICAgIENlcnRpZmljbyBxdWUgc2VtcHJlIHF1ZSBob3V2ZXIgYWxndW1hIGFsdGVyYcOnw6NvIG5lc3NhIGNvbmRpw6fDo28sIHF1ZVxuICAgICAgICBwb3NzYSBpbmNvcnJlciBlbSByaXNjbyBkZSBwZXJkYSBkZSBpbmRlcGVuZMOqbmNpYSwgY29tcHJvbWV0by1tZSBhXG4gICAgICAgIGluZm9ybWFyIGVzc2UgZmF0byBwb3IgZXNjcml0byDDoCDigJxNYXJ0aW5lbGxpIEF1ZGl0b3Jlc+KAnSwgYXR1YWxpemFuZG9cbiAgICAgICAgcHJvbnRhbWVudGUgYXMgaW5mb3JtYcOnw7VlcyBjb250aWRhcyBubyBBbmV4byBJIGRlc3RhIGRlY2xhcmHDp8Ojby5cbiAgICAgICAgPC9UZXh0PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFjdGlvbnN9PlxuICAgICAgICA8RGVmYXVsdEJ1dHRvblxuICAgICAgICAgIHRleHQ9XCJWb2x0YXJcIlxuICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUluZGVwZW5kZW5jZVRlcm1zVmlzaWJsZX1cbiAgICAgICAgLz5cbiAgICAgICAgPFByaW1hcnlCdXR0b25cbiAgICAgICAgICB0ZXh0PVwiTGkgZSBhY2VpdG9cIlxuICAgICAgICAgIGRpc2FibGVkPXshKHZhbHVlIGFzIG51bWJlciA8PSAxKX1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBzZXRJbmRlcGVuZGVuY2VUZXJtcyh1bmRlZmluZWQsIHRydWUpXG4gICAgICAgICAgICB0b2dnbGVJbmRlcGVuZGVuY2VUZXJtc1Zpc2libGU/LigpXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgeyBzcGFjaW5nLCBjb2xvcnMgfSA9IHVzZVRoZW1lKClcblxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xuICAgIGNvbnRhaW5lcjoge1xuICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICB9LFxuICAgIGNvbnRlbnQ6IHtcbiAgICAgIG1heEhlaWdodDogJzUwdmgnLFxuICAgICAgb3ZlcmZsb3c6ICdhdXRvJyxcbiAgICB9LFxuICAgIHBhcmFncmFwaDoge1xuICAgICAgY29sb3I6IGNvbG9ycy5uZXV0cmFsTGlnaHRbNjAwXSxcbiAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubGcsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJyY6bGFzdC1vZi10eXBlJzoge1xuICAgICAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy54eGwsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgYWN0aW9uczoge1xuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCcsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJyYgPiA6bm90KDpsYXN0LWNoaWxkKSc6IHtcbiAgICAgICAgICBtYXJnaW5SaWdodDogc3BhY2luZy5sZyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgSW5kZXBlbmRlbmNlVGVybXNEaXNwbGF5XG4iXX0=