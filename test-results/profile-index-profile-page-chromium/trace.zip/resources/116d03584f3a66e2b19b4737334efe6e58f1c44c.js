import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getScrollPosition from "/src/shared/utils/getScrollPosition.ts";
import { PrimaryButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
const ConfidentialityTermsDisplay = (props) => {
  _s();
  const [value, setValue] = useState();
  const {
    toggleConfidentialityTermsVisible,
    setConfidentialityTerms
  } = props;
  const styles = useStyles();
  useEffect(() => {
    document.querySelector("#terms")?.addEventListener("scroll", () => {
      const scroll = getScrollPosition("terms");
      setValue(scroll);
    });
  }, [value]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.container, children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.content, id: "terms", children: [
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Assumo o compromisso de manter confidencialidade e sigilo sobre todas as informações técnicas e outras relacionadas as minhas atividades na Martinelli Auditores, que tiver acesso durante o exercício das minhas atividades profissionais." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: [
        "Por este termo de confidencialidade e sigilo comprometo-me expressamente a:",
        /* @__PURE__ */ jsxDEV("ul", { children: [
          /* @__PURE__ */ jsxDEV("li", { children: "Estar atento para a possibilidade de divulgação inadvertida, incluindo em ambiente social e, especialmente, a parceiro de negócio próximo ou a familiar próximo ou imediato;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 38,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Manter a confidencialidade das informações dentro da Martinelli Auditores;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 43,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Manter a confidencialidade das informações divulgadas por cliente ou organização empregadora em potencial;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 47,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não divulgar fora da Martinelli Auditores ou da organização empregadora informações confidenciais obtidas em decorrência de relações profissionais e comerciais sem a devida autorização específica, a menos que haja um direito ou dever legal ou profissional de divulgação;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 50,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não usar ou divulgar nenhuma informação confidencial obtida ou recebida em decorrência da relação profissional ou comercial após o término dessa relação;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 57,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não utilizar as Informações Confidenciais a que tiver acesso, para gerar benefício próprio exclusivo e/ou unilateral, presente ou futuro, ou para o uso de terceiros;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 62,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não efetuar nenhuma gravação ou cópia da documentação confidencial a que tiver acesso, relacionado as minhas atividades profissionais, com exceção às cópias efetuadas dentro de servidor virtual disponibilizado pela Martinelli Auditores;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 67,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não me apropriar de Informação Confidencial que me venha a ser disponibilizada através de minhas atividades profissionais;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 73,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Não discutir perante terceiros, usar, divulgar, revelar, ceder a qualquer título ou dispor das informações confidenciais, para qualquer pessoa, física ou jurídica, e para qualquer outra finalidade que não seja exclusivamente relacionada ao objeto referido, cumprindo-me adotar cautelas e precauções adequadas no sentido de impedir o uso indevido por qualquer pessoa que, por qualquer razão, tenho tido acesso a elas;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 77,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Responsabilizar-me por impedir, por qualquer meio em direito admitido, a divulgação ou a utilização das Informações Confidenciais;" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 86,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Restituir imediatamente as Informações Confidenciais à Martinelli Auditores sempre que solicitado, ou sempre que as Informações Confidenciais deixarem de ser necessárias, não guardando para mim, em nenhuma hipótese, cópia, reprodução ou segunda via das mesmas; e," }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 90,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Usar as Informações Confidenciais recebidas da empresa com o propósito restrito de se fazer cumprir o estabelecido e acordado no meu Contrato e Manual de Integração recebido no momento de minha contratação." }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
            lineNumber: 96,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 37,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "§1º Para fins desse termo de responsabilidade e confidencialidade da informação, entende-se por Informação Confidencial, toda informação disponibilizada ao profissional da Martinelli Auditores, em razão do desempenho de suas funções e atividades, incluindo dentre outras, todas e quaisquer informações orais, e/ou escritas, de natureza técnica, operacional, comercial, jurídica, know-how, planos de negócios, técnicas e experiências acumuladas, documentos, contratos, papéis, estudos, pareceres, transmitidas ou divulgadas pela Martinelli Auditores." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "§2º A vigência da obrigação de confidencialidade e sigilo, assumida pela minha pessoa por meio deste termo, terá a validade enquanto a informação não for de conhecimento público por qualquer outra pessoa, ou mediante autorização escrita, concedida à minha pessoa pelas partes interessadas neste termo." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "§3º Reconheço e aceito que, na hipótese de violação de quaisquer das cláusulas deste Termo, estarei sujeito às sanções e penalidades legais, sem prejuízo das perdas e danos que der causa, estas estimadas pela Martinelli Auditores, inclusive as de ordem moral e concorrencial, bem como, as de responsabilidade civil e criminal que der causa." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "A fim de assegurar o sigilo e confidencialidade das informações dos clientes da Martinelli Auditores, declaro estar ciente e concordo expressamente com os seguintes procedimentos internos:" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: /* @__PURE__ */ jsxDEV("ul", { children: [
        /* @__PURE__ */ jsxDEV("li", { children: "Manter no disco rígido do computador, ou qualquer outra mídia removível, por mim utilizado para fins profissionais (independentemente de ser de minha propriedade ou da Martinelli) apenas os arquivos dos trabalhos correntes em fase de análise e/ou conclusão;" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 118,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: "Somente manter cópia digital e/ou impressa, as planilhas/arquivos dos testes realizados nos clientes, quando omitidos o nome e identificação do cliente, não havendo qualquer outra possibilidade de reconhecimento;" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 119,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: "Não manter em minha posse, informações de trabalhos anteriores e trabalhos concluídos em meu computador, em mídia removível (pendrive), ou em qualquer outro tipo de mídia (exemplo HD externo); ou ainda em meio físico impresso;" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 120,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: "Sempre que receber arquivos do cliente em “pen drive”ou outro meio de mídia, me comprometo a copiar e apagar de imediato essas informações contidas na mídia removível;" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 121,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: "Comprometo-me a manter a autenticidade, a integridade e/ou sigilo de informações ou dados dos clientes e da Martinelli Auditores; e," }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 122,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: "Concordo em disponibilizar o computador (notebook) de uso profissional (próprio ou cedido em empréstimo), semanalmente para auditoria interna aleatória, permitindo que o profissional de T.I. (Tecnologia da Informática) proceda a varredura nos arquivos profissionais (e tão somente profissionais), desde que a referida verificação efetive-se sempre em minha presença." }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
          lineNumber: 123,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 117,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Por fim, considero-me ciente de todas as consequências administrativas, trabalhistas e jurídicas decorrentes da não obediência às regras de confidencialidade aqui descritas, e firmo esse termo em duas vias para que possa surtir todos os efeitos no mundo jurídico e fático." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actions, children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Voltar", onClick: toggleConfidentialityTermsVisible }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Li e aceito", disabled: !(value <= 1), onClick: () => {
        setConfidentialityTerms(void 0, true);
        toggleConfidentialityTermsVisible?.();
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
        lineNumber: 132,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(ConfidentialityTermsDisplay, "sf4/pc+YyzfWLBIkLHX4DQ1JCBI=", false, function() {
  return [useStyles];
});
_c = ConfidentialityTermsDisplay;
const useStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    container: {
      maxWidth: "100%"
    },
    content: {
      height: "50vh",
      overflow: "auto"
    },
    paragraph: {
      color: colors.neutralLight[600],
      display: "block",
      marginBottom: spacing.lg,
      selectors: {
        "&:last-of-type": {
          marginBottom: spacing.xxl
        }
      }
    },
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: "15px",
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
export default ConfidentialityTermsDisplay;
var _c;
$RefreshReg$(_c, "ConfidentialityTermsDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ConfidentialityTermsDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBL0JSLFNBQXdCQSxXQUFXQyxnQkFBZ0I7QUFDbkQsU0FBU0MsZ0JBQWdCQyxZQUFZO0FBQ3JDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxlQUFlQyxxQkFBcUI7QUFDN0MsU0FBU0MsZ0JBQWdCO0FBT3pCLE1BQU1DLDhCQUFzRUMsV0FBVTtBQUFBQyxLQUFBO0FBQ3BGLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWCxTQUFpQjtBQUUzQyxRQUFNO0FBQUEsSUFDSlk7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJTDtBQUNKLFFBQU1NLFNBQVNDLFVBQVU7QUFFekJoQixZQUFVLE1BQU07QUFDZGlCLGFBQVNDLGNBQWMsUUFBUSxHQUFHQyxpQkFBaUIsVUFBVSxNQUFNO0FBQ2pFLFlBQU1DLFNBQVNoQixrQkFBa0IsT0FBTztBQUV4Q1EsZUFBU1EsTUFBTTtBQUFBLElBQ2pCLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ1QsS0FBSyxDQUFDO0FBRVYsU0FDRSx1QkFBQyxTQUFJLFdBQVdJLE9BQU9NLFdBQ3JCO0FBQUEsMkJBQUMsU0FBSSxXQUFXTixPQUFPTyxTQUFTLElBQUcsU0FDakM7QUFBQSw2QkFBQyxRQUFLLFdBQVdQLE9BQU9RLFdBQVUsMlBBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFXUixPQUFPUSxXQUFVO0FBQUE7QUFBQSxRQUdoQyx1QkFBQyxRQUNDO0FBQUEsaUNBQUMsUUFBRSw0TEFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxRQUFFLDBGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFFBQUUsMEhBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFcUM7QUFBQSxVQUNyQyx1QkFBQyxRQUFFLDhSQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFFBQUUseUtBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRSxxTEFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxRQUFFLDRQQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFFBQUUsMElBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRSxnYkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxRQUFFLGtKQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFFBQUUsdVJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRSw4TkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlFQTtBQUFBLFdBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBV1IsT0FBT1EsV0FBVSxxakJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFXUixPQUFPUSxXQUFVLDZUQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBV1IsT0FBT1EsV0FBVSxvV0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVdSLE9BQU9RLFdBQVUsNE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFXUixPQUFPUSxXQUN0QixpQ0FBQyxRQUNDO0FBQUEsK0JBQUMsUUFBRyxpUkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFRO0FBQUEsUUFDclEsdUJBQUMsUUFBRyxvT0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdOO0FBQUEsUUFDeE4sdUJBQUMsUUFBRyxrUEFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNPO0FBQUEsUUFDdE8sdUJBQUMsUUFBRyx1TEFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJLO0FBQUEsUUFDM0ssdUJBQUMsUUFBRyxvSkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdJO0FBQUEsUUFDeEksdUJBQUMsUUFBRyw4WEFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtYO0FBQUEsV0FOcFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVdSLE9BQU9RLFdBQVUsZ1NBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBckdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV1IsT0FBT1MsU0FDckI7QUFBQSw2QkFBQyxpQkFDQyxNQUFLLFVBQ0wsU0FBU1gscUNBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU2QztBQUFBLE1BRTdDLHVCQUFDLGlCQUNDLE1BQUssZUFDTCxVQUFVLEVBQUVGLFNBQW1CLElBQy9CLFNBQVMsTUFBTTtBQUNiRyxnQ0FBd0JXLFFBQVcsSUFBSTtBQUN2Q1osNENBQW9DO0FBQUEsTUFDdEMsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUk7QUFBQSxTQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BckhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSEE7QUFFSjtBQUFDSCxHQTFJS0YsNkJBQWtFO0FBQUEsVUFPdkRRLFNBQVM7QUFBQTtBQUFBVSxLQVBwQmxCO0FBNElOLE1BQU1RLFlBQVlBLE1BQU07QUFBQVcsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBU0M7QUFBQUEsRUFBTyxJQUFJdEIsU0FBUztBQUVyQyxTQUFPTCxlQUFlO0FBQUEsSUFDcEJtQixXQUFXO0FBQUEsTUFDVFMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBUixTQUFTO0FBQUEsTUFDUFMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQVQsV0FBVztBQUFBLE1BQ1RVLE9BQU9KLE9BQU9LLGFBQWEsR0FBRztBQUFBLE1BQzlCQyxTQUFTO0FBQUEsTUFDVEMsY0FBY1IsUUFBUVM7QUFBQUEsTUFDdEJDLFdBQVc7QUFBQSxRQUNULGtCQUFrQjtBQUFBLFVBQ2hCRixjQUFjUixRQUFRVztBQUFBQSxRQUN4QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQWYsU0FBUztBQUFBLE1BQ1BXLFNBQVM7QUFBQSxNQUNUSyxnQkFBZ0I7QUFBQSxNQUNoQkMsV0FBVztBQUFBLE1BQ1hILFdBQVc7QUFBQSxRQUNULHlCQUF5QjtBQUFBLFVBQ3ZCSSxhQUFhZCxRQUFRUztBQUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ1YsSUFoQ0tYLFdBQVM7QUFBQSxVQUNlVCxRQUFRO0FBQUE7QUFpQ3RDLGVBQWVDO0FBQTJCLElBQUFrQjtBQUFBaUIsYUFBQWpCLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIm1lcmdlU3R5bGVTZXRzIiwiVGV4dCIsImdldFNjcm9sbFBvc2l0aW9uIiwiUHJpbWFyeUJ1dHRvbiIsIkRlZmF1bHRCdXR0b24iLCJ1c2VUaGVtZSIsIkNvbmZpZGVudGlhbGl0eVRlcm1zRGlzcGxheSIsInByb3BzIiwiX3MiLCJ2YWx1ZSIsInNldFZhbHVlIiwidG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlIiwic2V0Q29uZmlkZW50aWFsaXR5VGVybXMiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJhZGRFdmVudExpc3RlbmVyIiwic2Nyb2xsIiwiY29udGFpbmVyIiwiY29udGVudCIsInBhcmFncmFwaCIsImFjdGlvbnMiLCJ1bmRlZmluZWQiLCJfYyIsIl9zMiIsInNwYWNpbmciLCJjb2xvcnMiLCJtYXhXaWR0aCIsImhlaWdodCIsIm92ZXJmbG93IiwiY29sb3IiLCJuZXV0cmFsTGlnaHQiLCJkaXNwbGF5IiwibWFyZ2luQm90dG9tIiwibGciLCJzZWxlY3RvcnMiLCJ4eGwiLCJqdXN0aWZ5Q29udGVudCIsIm1hcmdpblRvcCIsIm1hcmdpblJpZ2h0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL2NvbXBvbmVudHMvQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBGb3JtRXZlbnQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IG1lcmdlU3R5bGVTZXRzLCBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IGdldFNjcm9sbFBvc2l0aW9uIGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC91dGlscy9nZXRTY3JvbGxQb3NpdGlvbidcbmltcG9ydCB7IFByaW1hcnlCdXR0b24sIERlZmF1bHRCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuXG5pbnRlcmZhY2UgQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5UHJvcHMge1xuICB0b2dnbGVDb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGU/OiAoKSA9PiB2b2lkXG4gIHNldENvbmZpZGVudGlhbGl0eVRlcm1zOiAoZXY6IEZvcm1FdmVudDxIVE1MRWxlbWVudCB8IEhUTUxJbnB1dEVsZW1lbnQ+IHwgdW5kZWZpbmVkLCB2YWx1ZTogYm9vbGVhbikgPT4gdm9pZFxufVxuXG5jb25zdCBDb25maWRlbnRpYWxpdHlUZXJtc0Rpc3BsYXkgOiBGQzxDb25maWRlbnRpYWxpdHlUZXJtc0Rpc3BsYXlQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZTxudW1iZXI+KClcblxuICBjb25zdCB7XG4gICAgdG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlLFxuICAgIHNldENvbmZpZGVudGlhbGl0eVRlcm1zLFxuICB9ID0gcHJvcHNcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyN0ZXJtcycpPy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCAoKSA9PiB7XG4gICAgICBjb25zdCBzY3JvbGwgPSBnZXRTY3JvbGxQb3NpdGlvbigndGVybXMnKVxuXG4gICAgICBzZXRWYWx1ZShzY3JvbGwpXG4gICAgfSlcbiAgfSwgW3ZhbHVlXSlcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGVudH0gaWQ9XCJ0ZXJtc1wiPlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9PlxuICAgICAgICBBc3N1bW8gbyBjb21wcm9taXNzbyBkZSBtYW50ZXIgY29uZmlkZW5jaWFsaWRhZGUgZSBzaWdpbG8gc29icmUgdG9kYXMgYXNcbiAgICAgICAgaW5mb3JtYcOnw7VlcyB0w6ljbmljYXMgZSBvdXRyYXMgcmVsYWNpb25hZGFzIGFzIG1pbmhhcyBhdGl2aWRhZGVzIG5hXG4gICAgICAgIE1hcnRpbmVsbGkgQXVkaXRvcmVzLCBxdWUgdGl2ZXIgYWNlc3NvIGR1cmFudGUgbyBleGVyY8OtY2lvIGRhcyBtaW5oYXNcbiAgICAgICAgYXRpdmlkYWRlcyBwcm9maXNzaW9uYWlzLlxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxUZXh0IGNsYXNzTmFtZT17c3R5bGVzLnBhcmFncmFwaH0+XG4gICAgICAgIFBvciBlc3RlIHRlcm1vIGRlIGNvbmZpZGVuY2lhbGlkYWRlIGUgc2lnaWxvIGNvbXByb21ldG8tbWUgZXhwcmVzc2FtZW50ZVxuICAgICAgICBhOlxuICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIEVzdGFyIGF0ZW50byBwYXJhIGEgcG9zc2liaWxpZGFkZSBkZSBkaXZ1bGdhw6fDo28gaW5hZHZlcnRpZGEsXG4gICAgICAgICAgICBpbmNsdWluZG8gZW0gYW1iaWVudGUgc29jaWFsIGUsIGVzcGVjaWFsbWVudGUsIGEgcGFyY2Vpcm8gZGUgbmVnw7NjaW9cbiAgICAgICAgICAgIHByw7N4aW1vIG91IGEgZmFtaWxpYXIgcHLDs3hpbW8gb3UgaW1lZGlhdG87XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgTWFudGVyIGEgY29uZmlkZW5jaWFsaWRhZGUgZGFzIGluZm9ybWHDp8O1ZXMgZGVudHJvIGRhIE1hcnRpbmVsbGlcbiAgICAgICAgICAgIEF1ZGl0b3JlcztcbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICBNYW50ZXIgYSBjb25maWRlbmNpYWxpZGFkZSBkYXMgaW5mb3JtYcOnw7VlcyBkaXZ1bGdhZGFzIHBvciBjbGllbnRlIG91XG4gICAgICAgICAgICBvcmdhbml6YcOnw6NvIGVtcHJlZ2Fkb3JhIGVtIHBvdGVuY2lhbDs8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgTsOjbyBkaXZ1bGdhciBmb3JhIGRhIE1hcnRpbmVsbGkgQXVkaXRvcmVzIG91IGRhIG9yZ2FuaXphw6fDo29cbiAgICAgICAgICAgIGVtcHJlZ2Fkb3JhIGluZm9ybWHDp8O1ZXMgY29uZmlkZW5jaWFpcyBvYnRpZGFzIGVtIGRlY29ycsOqbmNpYSBkZVxuICAgICAgICAgICAgcmVsYcOnw7VlcyBwcm9maXNzaW9uYWlzIGUgY29tZXJjaWFpcyBzZW0gYSBkZXZpZGEgYXV0b3JpemHDp8Ojb1xuICAgICAgICAgICAgZXNwZWPDrWZpY2EsIGEgbWVub3MgcXVlIGhhamEgdW0gZGlyZWl0byBvdSBkZXZlciBsZWdhbCBvdVxuICAgICAgICAgICAgcHJvZmlzc2lvbmFsIGRlIGRpdnVsZ2HDp8OjbztcbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICBOw6NvIHVzYXIgb3UgZGl2dWxnYXIgbmVuaHVtYSBpbmZvcm1hw6fDo28gY29uZmlkZW5jaWFsIG9idGlkYSBvdVxuICAgICAgICAgICAgcmVjZWJpZGEgZW0gZGVjb3Jyw6puY2lhIGRhIHJlbGHDp8OjbyBwcm9maXNzaW9uYWwgb3UgY29tZXJjaWFsIGFww7NzIG9cbiAgICAgICAgICAgIHTDqXJtaW5vIGRlc3NhIHJlbGHDp8OjbztcbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICBOw6NvIHV0aWxpemFyIGFzIEluZm9ybWHDp8O1ZXMgQ29uZmlkZW5jaWFpcyBhIHF1ZSB0aXZlciBhY2Vzc28sIHBhcmFcbiAgICAgICAgICAgIGdlcmFyIGJlbmVmw61jaW8gcHLDs3ByaW8gZXhjbHVzaXZvIGUvb3UgdW5pbGF0ZXJhbCwgcHJlc2VudGUgb3VcbiAgICAgICAgICAgIGZ1dHVybywgb3UgcGFyYSBvIHVzbyBkZSB0ZXJjZWlyb3M7XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgTsOjbyBlZmV0dWFyIG5lbmh1bWEgZ3JhdmHDp8OjbyBvdSBjw7NwaWEgZGEgZG9jdW1lbnRhw6fDo28gY29uZmlkZW5jaWFsXG4gICAgICAgICAgICBhIHF1ZSB0aXZlciBhY2Vzc28sIHJlbGFjaW9uYWRvIGFzIG1pbmhhcyBhdGl2aWRhZGVzIHByb2Zpc3Npb25haXMsXG4gICAgICAgICAgICBjb20gZXhjZcOnw6NvIMOgcyBjw7NwaWFzIGVmZXR1YWRhcyBkZW50cm8gZGUgc2Vydmlkb3IgdmlydHVhbFxuICAgICAgICAgICAgZGlzcG9uaWJpbGl6YWRvIHBlbGEgTWFydGluZWxsaSBBdWRpdG9yZXM7XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgTsOjbyBtZSBhcHJvcHJpYXIgZGUgSW5mb3JtYcOnw6NvIENvbmZpZGVuY2lhbCBxdWUgbWUgdmVuaGEgYSBzZXJcbiAgICAgICAgICAgIGRpc3BvbmliaWxpemFkYSBhdHJhdsOpcyBkZSBtaW5oYXMgYXRpdmlkYWRlcyBwcm9maXNzaW9uYWlzO1xuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIE7Do28gZGlzY3V0aXIgcGVyYW50ZSB0ZXJjZWlyb3MsIHVzYXIsIGRpdnVsZ2FyLCByZXZlbGFyLCBjZWRlciBhXG4gICAgICAgICAgICBxdWFscXVlciB0w610dWxvIG91IGRpc3BvciBkYXMgaW5mb3JtYcOnw7VlcyBjb25maWRlbmNpYWlzLCBwYXJhXG4gICAgICAgICAgICBxdWFscXVlciBwZXNzb2EsIGbDrXNpY2Egb3UganVyw61kaWNhLCBlIHBhcmEgcXVhbHF1ZXIgb3V0cmFcbiAgICAgICAgICAgIGZpbmFsaWRhZGUgcXVlIG7Do28gc2VqYSBleGNsdXNpdmFtZW50ZSByZWxhY2lvbmFkYSBhbyBvYmpldG9cbiAgICAgICAgICAgIHJlZmVyaWRvLCBjdW1wcmluZG8tbWUgYWRvdGFyIGNhdXRlbGFzIGUgcHJlY2F1w6fDtWVzIGFkZXF1YWRhcyBub1xuICAgICAgICAgICAgc2VudGlkbyBkZSBpbXBlZGlyIG8gdXNvIGluZGV2aWRvIHBvciBxdWFscXVlciBwZXNzb2EgcXVlLCBwb3JcbiAgICAgICAgICAgIHF1YWxxdWVyIHJhesOjbywgdGVuaG8gdGlkbyBhY2Vzc28gYSBlbGFzO1xuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIFJlc3BvbnNhYmlsaXphci1tZSBwb3IgaW1wZWRpciwgcG9yIHF1YWxxdWVyIG1laW8gZW0gZGlyZWl0b1xuICAgICAgICAgICAgYWRtaXRpZG8sIGEgZGl2dWxnYcOnw6NvIG91IGEgdXRpbGl6YcOnw6NvIGRhcyBJbmZvcm1hw6fDtWVzIENvbmZpZGVuY2lhaXM7XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgUmVzdGl0dWlyIGltZWRpYXRhbWVudGUgYXMgSW5mb3JtYcOnw7VlcyBDb25maWRlbmNpYWlzIMOgIE1hcnRpbmVsbGlcbiAgICAgICAgICAgIEF1ZGl0b3JlcyBzZW1wcmUgcXVlIHNvbGljaXRhZG8sIG91IHNlbXByZSBxdWUgYXMgSW5mb3JtYcOnw7Vlc1xuICAgICAgICAgICAgQ29uZmlkZW5jaWFpcyBkZWl4YXJlbSBkZSBzZXIgbmVjZXNzw6FyaWFzLCBuw6NvIGd1YXJkYW5kbyBwYXJhIG1pbSxcbiAgICAgICAgICAgIGVtIG5lbmh1bWEgaGlww7N0ZXNlLCBjw7NwaWEsIHJlcHJvZHXDp8OjbyBvdSBzZWd1bmRhIHZpYSBkYXMgbWVzbWFzOyBlLFxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIFVzYXIgYXMgSW5mb3JtYcOnw7VlcyBDb25maWRlbmNpYWlzIHJlY2ViaWRhcyBkYSBlbXByZXNhIGNvbSBvXG4gICAgICAgICAgICBwcm9ww7NzaXRvIHJlc3RyaXRvIGRlIHNlIGZhemVyIGN1bXByaXIgbyBlc3RhYmVsZWNpZG8gZSBhY29yZGFkbyBub1xuICAgICAgICAgICAgbWV1IENvbnRyYXRvIGUgTWFudWFsIGRlIEludGVncmHDp8OjbyByZWNlYmlkbyBubyBtb21lbnRvIGRlIG1pbmhhXG4gICAgICAgICAgICBjb250cmF0YcOnw6NvLlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxUZXh0IGNsYXNzTmFtZT17c3R5bGVzLnBhcmFncmFwaH0+XG4gICAgICAgIMKnMcK6IFBhcmEgZmlucyBkZXNzZSB0ZXJtbyBkZSByZXNwb25zYWJpbGlkYWRlIGUgY29uZmlkZW5jaWFsaWRhZGUgZGEgaW5mb3JtYcOnw6NvLCBlbnRlbmRlLXNlIHBvciBJbmZvcm1hw6fDo28gQ29uZmlkZW5jaWFsLCB0b2RhIGluZm9ybWHDp8OjbyBkaXNwb25pYmlsaXphZGEgYW8gcHJvZmlzc2lvbmFsIGRhIE1hcnRpbmVsbGkgQXVkaXRvcmVzLCBlbSByYXrDo28gZG8gZGVzZW1wZW5obyBkZSBzdWFzIGZ1bsOnw7VlcyBlIGF0aXZpZGFkZXMsIGluY2x1aW5kbyBkZW50cmUgb3V0cmFzLCB0b2RhcyBlIHF1YWlzcXVlciBpbmZvcm1hw6fDtWVzIG9yYWlzLCBlL291IGVzY3JpdGFzLCBkZSBuYXR1cmV6YSB0w6ljbmljYSwgb3BlcmFjaW9uYWwsIGNvbWVyY2lhbCwganVyw61kaWNhLCBrbm93LWhvdywgcGxhbm9zIGRlIG5lZ8OzY2lvcywgdMOpY25pY2FzIGUgZXhwZXJpw6puY2lhcyBhY3VtdWxhZGFzLCBkb2N1bWVudG9zLCBjb250cmF0b3MsIHBhcMOpaXMsIGVzdHVkb3MsIHBhcmVjZXJlcywgdHJhbnNtaXRpZGFzIG91IGRpdnVsZ2FkYXMgcGVsYSBNYXJ0aW5lbGxpIEF1ZGl0b3Jlcy5cbiAgICAgICAgPC9UZXh0PlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9PlxuICAgICAgICDCpzLCuiBBIHZpZ8OqbmNpYSBkYSBvYnJpZ2HDp8OjbyBkZSBjb25maWRlbmNpYWxpZGFkZSBlIHNpZ2lsbywgYXNzdW1pZGEgcGVsYSBtaW5oYSBwZXNzb2EgcG9yIG1laW8gZGVzdGUgdGVybW8sIHRlcsOhIGEgdmFsaWRhZGUgZW5xdWFudG8gYSBpbmZvcm1hw6fDo28gbsOjbyBmb3IgZGUgY29uaGVjaW1lbnRvIHDDumJsaWNvIHBvciBxdWFscXVlciBvdXRyYSBwZXNzb2EsIG91IG1lZGlhbnRlIGF1dG9yaXphw6fDo28gZXNjcml0YSwgY29uY2VkaWRhIMOgIG1pbmhhIHBlc3NvYSBwZWxhcyBwYXJ0ZXMgaW50ZXJlc3NhZGFzIG5lc3RlIHRlcm1vLlxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxUZXh0IGNsYXNzTmFtZT17c3R5bGVzLnBhcmFncmFwaH0+XG4gICAgICAgIMKnM8K6IFJlY29uaGXDp28gZSBhY2VpdG8gcXVlLCBuYSBoaXDDs3Rlc2UgZGUgdmlvbGHDp8OjbyBkZSBxdWFpc3F1ZXIgZGFzIGNsw6F1c3VsYXMgZGVzdGUgVGVybW8sIGVzdGFyZWkgc3VqZWl0byDDoHMgc2Fuw6fDtWVzIGUgcGVuYWxpZGFkZXMgbGVnYWlzLCBzZW0gcHJlanXDrXpvIGRhcyBwZXJkYXMgZSBkYW5vcyBxdWUgZGVyIGNhdXNhLCBlc3RhcyBlc3RpbWFkYXMgcGVsYSBNYXJ0aW5lbGxpIEF1ZGl0b3JlcywgaW5jbHVzaXZlIGFzIGRlIG9yZGVtIG1vcmFsIGUgY29uY29ycmVuY2lhbCwgYmVtIGNvbW8sIGFzIGRlIHJlc3BvbnNhYmlsaWRhZGUgY2l2aWwgZSBjcmltaW5hbCBxdWUgZGVyIGNhdXNhLlxuICAgICAgICA8L1RleHQ+XG4gICAgICAgIDxUZXh0IGNsYXNzTmFtZT17c3R5bGVzLnBhcmFncmFwaH0+XG4gICAgICAgIEEgZmltIGRlIGFzc2VndXJhciBvIHNpZ2lsbyBlIGNvbmZpZGVuY2lhbGlkYWRlIGRhcyBpbmZvcm1hw6fDtWVzIGRvcyBjbGllbnRlcyBkYSBNYXJ0aW5lbGxpIEF1ZGl0b3JlcywgZGVjbGFybyBlc3RhciBjaWVudGUgZSBjb25jb3JkbyBleHByZXNzYW1lbnRlIGNvbSBvcyBzZWd1aW50ZXMgcHJvY2VkaW1lbnRvcyBpbnRlcm5vczpcbiAgICAgICAgPC9UZXh0PlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9PlxuICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgIDxsaT5NYW50ZXIgbm8gZGlzY28gcsOtZ2lkbyBkbyBjb21wdXRhZG9yLCBvdSBxdWFscXVlciBvdXRyYSBtw61kaWEgcmVtb3bDrXZlbCwgcG9yIG1pbSB1dGlsaXphZG8gcGFyYSBmaW5zIHByb2Zpc3Npb25haXMgKGluZGVwZW5kZW50ZW1lbnRlIGRlIHNlciBkZSBtaW5oYSBwcm9wcmllZGFkZSBvdSBkYSBNYXJ0aW5lbGxpKSBhcGVuYXMgb3MgYXJxdWl2b3MgZG9zIHRyYWJhbGhvcyBjb3JyZW50ZXMgZW0gZmFzZSBkZSBhbsOhbGlzZSBlL291IGNvbmNsdXPDo287PC9saT5cbiAgICAgICAgICAgIDxsaT5Tb21lbnRlIG1hbnRlciBjw7NwaWEgZGlnaXRhbCBlL291IGltcHJlc3NhLCBhcyBwbGFuaWxoYXMvYXJxdWl2b3MgZG9zIHRlc3RlcyByZWFsaXphZG9zIG5vcyBjbGllbnRlcywgcXVhbmRvIG9taXRpZG9zIG8gbm9tZSBlIGlkZW50aWZpY2HDp8OjbyBkbyBjbGllbnRlLCBuw6NvIGhhdmVuZG8gcXVhbHF1ZXIgb3V0cmEgcG9zc2liaWxpZGFkZSBkZSByZWNvbmhlY2ltZW50bzs8L2xpPlxuICAgICAgICAgICAgPGxpPk7Do28gbWFudGVyIGVtIG1pbmhhIHBvc3NlLCBpbmZvcm1hw6fDtWVzIGRlIHRyYWJhbGhvcyBhbnRlcmlvcmVzIGUgdHJhYmFsaG9zIGNvbmNsdcOtZG9zIGVtIG1ldSBjb21wdXRhZG9yLCBlbSBtw61kaWEgcmVtb3bDrXZlbCAocGVuZHJpdmUpLCBvdSBlbSBxdWFscXVlciBvdXRybyB0aXBvIGRlIG3DrWRpYSAoZXhlbXBsbyBIRCBleHRlcm5vKTsgb3UgYWluZGEgZW0gbWVpbyBmw61zaWNvIGltcHJlc3NvOzwvbGk+XG4gICAgICAgICAgICA8bGk+U2VtcHJlIHF1ZSByZWNlYmVyIGFycXVpdm9zIGRvIGNsaWVudGUgZW0g4oCccGVuIGRyaXZl4oCdb3Ugb3V0cm8gbWVpbyBkZSBtw61kaWEsIG1lIGNvbXByb21ldG8gYSBjb3BpYXIgZSBhcGFnYXIgZGUgaW1lZGlhdG8gZXNzYXMgaW5mb3JtYcOnw7VlcyBjb250aWRhcyBuYSBtw61kaWEgcmVtb3bDrXZlbDs8L2xpPlxuICAgICAgICAgICAgPGxpPkNvbXByb21ldG8tbWUgYSBtYW50ZXIgYSBhdXRlbnRpY2lkYWRlLCBhIGludGVncmlkYWRlIGUvb3Ugc2lnaWxvIGRlIGluZm9ybWHDp8O1ZXMgb3UgZGFkb3MgZG9zIGNsaWVudGVzIGUgZGEgTWFydGluZWxsaSBBdWRpdG9yZXM7IGUsPC9saT5cbiAgICAgICAgICAgIDxsaT5Db25jb3JkbyBlbSBkaXNwb25pYmlsaXphciBvIGNvbXB1dGFkb3IgKG5vdGVib29rKSBkZSB1c28gcHJvZmlzc2lvbmFsIChwcsOzcHJpbyBvdSBjZWRpZG8gZW0gZW1wcsOpc3RpbW8pLCBzZW1hbmFsbWVudGUgcGFyYSBhdWRpdG9yaWEgaW50ZXJuYSBhbGVhdMOzcmlhLCBwZXJtaXRpbmRvIHF1ZSBvIHByb2Zpc3Npb25hbCBkZSBULkkuIChUZWNub2xvZ2lhIGRhIEluZm9ybcOhdGljYSkgcHJvY2VkYSBhIHZhcnJlZHVyYSBub3MgYXJxdWl2b3MgcHJvZmlzc2lvbmFpcyAoZSB0w6NvIHNvbWVudGUgcHJvZmlzc2lvbmFpcyksIGRlc2RlIHF1ZSBhIHJlZmVyaWRhIHZlcmlmaWNhw6fDo28gZWZldGl2ZS1zZSBzZW1wcmUgZW0gbWluaGEgcHJlc2Vuw6dhLjwvbGk+XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9UZXh0PlxuICAgICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9ID5cbiAgICAgICAgUG9yIGZpbSwgY29uc2lkZXJvLW1lIGNpZW50ZSBkZSB0b2RhcyBhcyBjb25zZXF1w6puY2lhcyBhZG1pbmlzdHJhdGl2YXMsIHRyYWJhbGhpc3RhcyBlIGp1csOtZGljYXMgZGVjb3JyZW50ZXMgZGEgbsOjbyBvYmVkacOqbmNpYSDDoHMgcmVncmFzIGRlIGNvbmZpZGVuY2lhbGlkYWRlIGFxdWkgZGVzY3JpdGFzLCBlIGZpcm1vIGVzc2UgdGVybW8gZW0gZHVhcyB2aWFzIHBhcmEgcXVlIHBvc3NhIHN1cnRpciB0b2RvcyBvcyBlZmVpdG9zIG5vIG11bmRvIGp1csOtZGljbyBlIGbDoXRpY28uXG4gICAgICAgIDwvVGV4dD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5hY3Rpb25zfT5cbiAgICAgICAgPERlZmF1bHRCdXR0b25cbiAgICAgICAgICB0ZXh0PVwiVm9sdGFyXCJcbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVDb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGV9XG4gICAgICAgIC8+XG4gICAgICAgIDxQcmltYXJ5QnV0dG9uXG4gICAgICAgICAgdGV4dD1cIkxpIGUgYWNlaXRvXCJcbiAgICAgICAgICBkaXNhYmxlZD17ISh2YWx1ZSBhcyBudW1iZXIgPD0gMSl9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgc2V0Q29uZmlkZW50aWFsaXR5VGVybXModW5kZWZpbmVkLCB0cnVlKVxuICAgICAgICAgICAgdG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlPy4oKVxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG5cbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcbiAgICBjb250YWluZXI6IHtcbiAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgfSxcbiAgICBjb250ZW50OiB7XG4gICAgICBoZWlnaHQ6ICc1MHZoJyxcbiAgICAgIG92ZXJmbG93OiAnYXV0bycsXG4gICAgfSxcbiAgICBwYXJhZ3JhcGg6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMubmV1dHJhbExpZ2h0WzYwMF0sXG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLmxnLFxuICAgICAgc2VsZWN0b3JzOiB7XG4gICAgICAgICcmOmxhc3Qtb2YtdHlwZSc6IHtcbiAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcueHhsLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFjdGlvbnM6IHtcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnLFxuICAgICAgbWFyZ2luVG9wOiAnMTVweCcsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJyYgPiA6bm90KDpsYXN0LWNoaWxkKSc6IHtcbiAgICAgICAgICBtYXJnaW5SaWdodDogc3BhY2luZy5sZyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5XG4iXX0=