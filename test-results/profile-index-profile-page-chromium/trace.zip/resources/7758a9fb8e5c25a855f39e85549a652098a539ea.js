import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/PhoneInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/PhoneInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { MaskedTextField } from "/src/shared/components/index.ts?t=1701096626433";
const PhoneInput = (props) => {
  _s();
  const {
    value
  } = props;
  const maskFormat = useMemo(() => {
    return (value?.length ?? 0) < 11 ? "(99) 9999-99999" : "(99) 9 9999-9999";
  }, [value]);
  return /* @__PURE__ */ jsxDEV(MaskedTextField, { label: "Telefone", mask: maskFormat, maskChar: " ", ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/PhoneInput.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(PhoneInput, "bsE8Bxoev+LEClZOWUh8iRJuA9Q=");
_c = PhoneInput;
export default PhoneInput;
var _c;
$RefreshReg$(_c, "PhoneInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/PhoneInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaSixTQUFhQSxlQUFlO0FBRTVCLFNBQVNDLHVCQUF1QjtBQUVoQyxNQUFNQyxhQUFtQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQ2pELFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFNLElBQUlGO0FBQ2xCLFFBQU1HLGFBQWFOLFFBQVEsTUFBTTtBQUMvQixZQUFRSyxPQUFPRSxVQUFVLEtBQUssS0FDMUIsb0JBQ0E7QUFBQSxFQUNOLEdBQUcsQ0FBQ0YsS0FBSyxDQUFDO0FBQ1YsU0FDRSx1QkFBQyxtQkFDQyxPQUFNLFlBQ04sTUFBTUMsWUFDTixVQUFTLEtBQ1QsR0FBSUgsU0FKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSVk7QUFHaEI7QUFBQ0MsR0FmS0YsWUFBK0I7QUFBQU0sS0FBL0JOO0FBaUJOLGVBQWVBO0FBQVUsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJNYXNrZWRUZXh0RmllbGQiLCJQaG9uZUlucHV0IiwicHJvcHMiLCJfcyIsInZhbHVlIiwibWFza0Zvcm1hdCIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGhvbmVJbnB1dC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9pbnB1dHMvUGhvbmVJbnB1dC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJVGV4dEZpZWxkUHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IE1hc2tlZFRleHRGaWVsZCB9IGZyb20gJy4uJ1xyXG5cclxuY29uc3QgUGhvbmVJbnB1dDogRkM8SVRleHRGaWVsZFByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHsgdmFsdWUgfSA9IHByb3BzXHJcbiAgY29uc3QgbWFza0Zvcm1hdCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuICh2YWx1ZT8ubGVuZ3RoID8/IDApIDwgMTFcclxuICAgICAgPyAnKDk5KSA5OTk5LTk5OTk5J1xyXG4gICAgICA6ICcoOTkpIDkgOTk5OS05OTk5J1xyXG4gIH0sIFt2YWx1ZV0pXHJcbiAgcmV0dXJuIChcclxuICAgIDxNYXNrZWRUZXh0RmllbGRcclxuICAgICAgbGFiZWw9XCJUZWxlZm9uZVwiXHJcbiAgICAgIG1hc2s9e21hc2tGb3JtYXR9XHJcbiAgICAgIG1hc2tDaGFyPVwiIFwiXHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQaG9uZUlucHV0XHJcbiJdfQ==