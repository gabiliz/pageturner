import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserRoleDate.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDate.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
const UserRoleDate = ({
  date
}) => {
  return date ? /* @__PURE__ */ jsxDEV("span", { children: format(new Date(date), "dd/MM/yyyy") }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDate.tsx",
    lineNumber: 9,
    columnNumber: 17
  }, this) : /* @__PURE__ */ jsxDEV("span", { children: "Atual" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDate.tsx",
    lineNumber: 9,
    columnNumber: 71
  }, this);
};
_c = UserRoleDate;
export default UserRoleDate;
var _c;
$RefreshReg$(_c, "UserRoleDate");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixTQUFTQSxjQUFjO0FBTXZCLE1BQU1DLGVBQXNDQSxDQUFDO0FBQUEsRUFBRUM7QUFBSyxNQUFNO0FBQ3hELFNBQU9BLE9BQ0gsdUJBQUMsVUFBTUYsaUJBQU8sSUFBSUcsS0FBS0QsSUFBSSxHQUFHLFlBQVksS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QyxJQUM1Qyx1QkFBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVztBQUNqQjtBQUFDRSxLQUpLSDtBQU1OLGVBQWVBO0FBQVksSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImZvcm1hdCIsIlVzZXJSb2xlRGF0ZSIsImRhdGUiLCJEYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyUm9sZURhdGUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi91c2Vycy9jb21wb25lbnRzL1VzZXJSb2xlRGF0ZS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgZm9ybWF0IH0gZnJvbSAnZGF0ZS1mbnMnXG5cbmludGVyZmFjZSBVc2VyUm9sZURhdGVQcm9wcyB7XG4gIGRhdGU6IHN0cmluZyB8IHVuZGVmaW5lZCB8IG51bGxcbn1cblxuY29uc3QgVXNlclJvbGVEYXRlOiBGQzxVc2VyUm9sZURhdGVQcm9wcz4gPSAoeyBkYXRlIH0pID0+IHtcbiAgcmV0dXJuIGRhdGVcbiAgICA/IDxzcGFuPntmb3JtYXQobmV3IERhdGUoZGF0ZSksICdkZC9NTS95eXl5Jyl9PC9zcGFuPlxuICAgIDogPHNwYW4+QXR1YWw8L3NwYW4+XG59XG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJSb2xlRGF0ZVxuIl19