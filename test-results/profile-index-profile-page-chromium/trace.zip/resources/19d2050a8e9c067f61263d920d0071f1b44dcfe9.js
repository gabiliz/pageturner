import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/drawer/EditDrawer.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { mergeStyles, TooltipHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport4_react["useMemo"];
import { AppDrawer, PrimaryButton, DefaultButton, ProgressIndicator } from "/src/shared/components/index.ts?t=1701096626433";
const EditDrawer = (props) => {
  _s();
  const {
    title,
    children,
    isOpen,
    onDismiss,
    onSave,
    disabled = false,
    loading = false,
    renderActions,
    large,
    disableSave,
    disableSaveMessage,
    progress
  } = props;
  const panelFooter = useMemo(() => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    loading && /* @__PURE__ */ jsxDEV(ProgressIndicator, { className: progressStyles, styles: {
      itemProgress: {
        padding: 0
      }
    }, percentComplete: progress }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
      lineNumber: 36,
      columnNumber: 17
    }, this),
    !renderActions && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Cancelar", styles: {
        root: {
          marginRight: 16
        }
      }, onClick: onDismiss, disabled }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
        lineNumber: 41,
        columnNumber: 26
      }, this),
      /* @__PURE__ */ jsxDEV(TooltipHost, { content: disableSaveMessage, children: /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Salvar", onClick: onSave, disabled: disabled || disableSave }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
        lineNumber: 47,
        columnNumber: 7
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
        lineNumber: 46,
        columnNumber: 5
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
      lineNumber: 41,
      columnNumber: 24
    }, this),
    renderActions?.()
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
    lineNumber: 35,
    columnNumber: 37
  }, this), [onSave, onDismiss, disabled, loading]);
  return /* @__PURE__ */ jsxDEV(AppDrawer, { title, isOpen, onDismiss, footer: panelFooter, large, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
};
_s(EditDrawer, "G4y6J1oND3ECl2eKqdyeGEwWVGc=");
_c = EditDrawer;
const progressStyles = mergeStyles({
  position: "absolute",
  top: -1,
  left: 0,
  right: 0
});
export default EditDrawer;
var _c;
$RefreshReg$(_c, "EditDrawer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/drawer/EditDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NnQixTQUtRLFVBTFI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQ2hCLFNBQVNBLGFBQWFDLG1CQUFtQjtBQUN6QyxTQUE4Q0MsZUFBZTtBQUM3RCxTQUFTQyxXQUFXQyxlQUFlQyxlQUFlQyx5QkFBeUI7QUFpQjNFLE1BQU1DLGFBQXNEQyxXQUFVO0FBQUFDLEtBQUE7QUFDcEUsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVc7QUFBQSxJQUNYQyxVQUFVO0FBQUEsSUFDVkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJYjtBQUVKLFFBQU1jLGNBQWNwQixRQUFRLE1BQU0sbUNBQy9CYztBQUFBQSxlQUFXLHVCQUFDLHFCQUNYLFdBQVdPLGdCQUNYLFFBQVE7QUFBQSxNQUFFQyxjQUFjO0FBQUEsUUFBRUMsU0FBUztBQUFBLE1BQUU7QUFBQSxJQUFFLEdBQ3ZDLGlCQUFpQkosWUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR2dCO0FBQUEsSUFFMUIsQ0FBQ0osaUJBQWlCLG1DQUFFO0FBQUEsNkJBQUMsaUJBQ3JCLE1BQUssWUFDTCxRQUFRO0FBQUEsUUFBRVMsTUFBTTtBQUFBLFVBQUVDLGFBQWE7QUFBQSxRQUFHO0FBQUEsTUFBRSxHQUNwQyxTQUFTZCxXQUNULFlBSm9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJRDtBQUFBLE1BRXJCLHVCQUFDLGVBQ0MsU0FBU08sb0JBRVQsaUNBQUMsaUJBQ0MsTUFBSyxVQUNMLFNBQVNOLFFBQ1QsVUFBVUMsWUFBWUksZUFIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdvQyxLQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQWRvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZXBCO0FBQUEsSUFDRUYsZ0JBQWdCO0FBQUEsT0F0QmM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCbEMsR0FBSyxDQUFDSCxRQUFRRCxXQUFXRSxVQUFVQyxPQUFPLENBQUM7QUFFM0MsU0FDRSx1QkFBQyxhQUNDLE9BQ0EsUUFDQSxXQUNBLFFBQVFNLGFBQ1IsT0FFQ1gsWUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDRixHQXBES0YsWUFBa0Q7QUFBQXFCLEtBQWxEckI7QUFzRE4sTUFBTWdCLGlCQUFpQnZCLFlBQVk7QUFBQSxFQUNqQzZCLFVBQVU7QUFBQSxFQUNWQyxLQUFLO0FBQUEsRUFDTEMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFDVCxDQUFDO0FBRUQsZUFBZXpCO0FBQVUsSUFBQXFCO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlcyIsIlRvb2x0aXBIb3N0IiwidXNlTWVtbyIsIkFwcERyYXdlciIsIlByaW1hcnlCdXR0b24iLCJEZWZhdWx0QnV0dG9uIiwiUHJvZ3Jlc3NJbmRpY2F0b3IiLCJFZGl0RHJhd2VyIiwicHJvcHMiLCJfcyIsInRpdGxlIiwiY2hpbGRyZW4iLCJpc09wZW4iLCJvbkRpc21pc3MiLCJvblNhdmUiLCJkaXNhYmxlZCIsImxvYWRpbmciLCJyZW5kZXJBY3Rpb25zIiwibGFyZ2UiLCJkaXNhYmxlU2F2ZSIsImRpc2FibGVTYXZlTWVzc2FnZSIsInByb2dyZXNzIiwicGFuZWxGb290ZXIiLCJwcm9ncmVzc1N0eWxlcyIsIml0ZW1Qcm9ncmVzcyIsInBhZGRpbmciLCJyb290IiwibWFyZ2luUmlnaHQiLCJfYyIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsInJpZ2h0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRWRpdERyYXdlci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9kcmF3ZXIvRWRpdERyYXdlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtZXJnZVN0eWxlcywgVG9vbHRpcEhvc3QgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgUHJvcHNXaXRoQ2hpbGRyZW4sIFJlYWN0RWxlbWVudCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQXBwRHJhd2VyLCBQcmltYXJ5QnV0dG9uLCBEZWZhdWx0QnV0dG9uLCBQcm9ncmVzc0luZGljYXRvciB9IGZyb20gJy4uJ1xuXG5pbnRlcmZhY2UgRWRpdERyYXdlclByb3BzIHtcbiAgdGl0bGU6IHN0cmluZ1xuICBpc09wZW46IGJvb2xlYW5cbiAgbGFyZ2U/OiBib29sZWFuXG4gIGN1c3RvbUZvb3Rlcj86IFJlYWN0RWxlbWVudFxuICBvbkRpc21pc3M6ICgpID0+IHZvaWRcbiAgb25TYXZlPzogKCkgPT4gdm9pZFxuICBkaXNhYmxlZD86IGJvb2xlYW5cbiAgZGlzYWJsZVNhdmU/OiBib29sZWFuXG4gIGxvYWRpbmc/OiBib29sZWFuXG4gIHJlbmRlckFjdGlvbnM/OiAoKSA9PiBSZWFjdEVsZW1lbnRcbiAgZGlzYWJsZVNhdmVNZXNzYWdlPzpzdHJpbmdcbiAgcHJvZ3Jlc3M/OiBudW1iZXJcbn1cblxuY29uc3QgRWRpdERyYXdlcjogRkM8UHJvcHNXaXRoQ2hpbGRyZW48RWRpdERyYXdlclByb3BzPj4gPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIHRpdGxlLFxuICAgIGNoaWxkcmVuLFxuICAgIGlzT3BlbixcbiAgICBvbkRpc21pc3MsXG4gICAgb25TYXZlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbG9hZGluZyA9IGZhbHNlLFxuICAgIHJlbmRlckFjdGlvbnMsXG4gICAgbGFyZ2UsXG4gICAgZGlzYWJsZVNhdmUsXG4gICAgZGlzYWJsZVNhdmVNZXNzYWdlLFxuICAgIHByb2dyZXNzLFxuICB9ID0gcHJvcHNcblxuICBjb25zdCBwYW5lbEZvb3RlciA9IHVzZU1lbW8oKCkgPT4gPD5cbiAgICB7bG9hZGluZyAmJiA8UHJvZ3Jlc3NJbmRpY2F0b3JcbiAgICAgIGNsYXNzTmFtZT17cHJvZ3Jlc3NTdHlsZXN9XG4gICAgICBzdHlsZXM9e3sgaXRlbVByb2dyZXNzOiB7IHBhZGRpbmc6IDAgfSB9fVxuICAgICAgcGVyY2VudENvbXBsZXRlPXtwcm9ncmVzc31cbiAgICAvPn1cbiAgICB7ICFyZW5kZXJBY3Rpb25zICYmIDw+PERlZmF1bHRCdXR0b25cbiAgICAgIHRleHQ9XCJDYW5jZWxhclwiXG4gICAgICBzdHlsZXM9e3sgcm9vdDogeyBtYXJnaW5SaWdodDogMTYgfSB9fVxuICAgICAgb25DbGljaz17b25EaXNtaXNzfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgIC8+XG4gICAgPFRvb2x0aXBIb3N0XG4gICAgICBjb250ZW50PXtkaXNhYmxlU2F2ZU1lc3NhZ2V9XG4gICAgPlxuICAgICAgPFByaW1hcnlCdXR0b25cbiAgICAgICAgdGV4dD1cIlNhbHZhclwiXG4gICAgICAgIG9uQ2xpY2s9e29uU2F2ZX1cbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IGRpc2FibGVTYXZlfVxuICAgICAgLz5cbiAgICA8L1Rvb2x0aXBIb3N0PlxuICAgIDwvPn1cbiAgICB7IHJlbmRlckFjdGlvbnM/LigpIH1cbiAgPC8+LCBbb25TYXZlLCBvbkRpc21pc3MsIGRpc2FibGVkLCBsb2FkaW5nXSlcblxuICByZXR1cm4gKFxuICAgIDxBcHBEcmF3ZXJcbiAgICAgIHRpdGxlPXt0aXRsZX1cbiAgICAgIGlzT3Blbj17aXNPcGVufVxuICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XG4gICAgICBmb290ZXI9e3BhbmVsRm9vdGVyfVxuICAgICAgbGFyZ2U9e2xhcmdlfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0FwcERyYXdlcj5cbiAgKVxufVxuXG5jb25zdCBwcm9ncmVzc1N0eWxlcyA9IG1lcmdlU3R5bGVzKHtcbiAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gIHRvcDogLTEsXG4gIGxlZnQ6IDAsXG4gIHJpZ2h0OiAwLFxufSlcblxuZXhwb3J0IGRlZmF1bHQgRWRpdERyYXdlclxuIl19