import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/persona/PersonaGeneral.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Icon, mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { UserAvatar } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { colorPicker } from "/src/shared/utils/index.ts";
const PersonaGeneral = (props) => {
  _s();
  const personaStyles = useStyles(props);
  return /* @__PURE__ */ jsxDEV("div", { className: personaStyles.container, children: [
    /* @__PURE__ */ jsxDEV("div", { className: personaStyles.avatar, children: props.image && props.image !== "" ? /* @__PURE__ */ jsxDEV(UserAvatar, { image: props.image, size: props.size, fontSize: props.fontSize }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx",
      lineNumber: 26,
      columnNumber: 46
    }, this) : props.shortName && props.shortName !== "" ? props.shortName : /* @__PURE__ */ jsxDEV(Icon, { iconName: props.iconName }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx",
      lineNumber: 26,
      columnNumber: 189
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    props.name && /* @__PURE__ */ jsxDEV(Text, { className: personaStyles.name, children: props.name }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx",
      lineNumber: 28,
      columnNumber: 22
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_s(PersonaGeneral, "vbznjt8eK8snoDXHxlNbD66sr7w=", false, function() {
  return [useStyles];
});
_c = PersonaGeneral;
const useStyles = (props) => {
  _s2();
  const {
    colors,
    spacing,
    fontSize,
    fontWeight
  } = useTheme();
  return mergeStyleSets({
    container: {
      display: "flex",
      alignItems: "center",
      gap: spacing.sm,
      fontSize: fontSize.p14
    },
    name: {
      color: props.nameColor ? props.nameColor : colors.purple[800],
      fontWeight: props.fontWeight ? props.fontWeight : fontWeight.semibold,
      fontSize: fontSize.p14
    },
    avatar: {
      width: props.size ?? "40px",
      height: props.size ?? "40px",
      borderRadius: "50%",
      backgroundColor: props.color ? props.color : props.shortName ? colorPicker(props.shortName, "50%") : colors.purple[200],
      color: props.iconFill ? props.iconFill : colors.white,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: props.fontSize ?? fontSize.p14,
      fontWeight: fontWeight.semibold,
      lineHeight: 0
    },
    userName: {
      fontSize: fontSize.p14
    }
  });
};
_s2(useStyles, "cEOrLAwNHai28RP6sRa9bGL1FpM=", false, function() {
  return [useTheme];
});
export default PersonaGeneral;
var _c;
$RefreshReg$(_c, "PersonaGeneral");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/persona/PersonaGeneral.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJZOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJaLFNBQVNBLE1BQU1DLGdCQUFnQkMsWUFBWTtBQUUzQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLG1CQUFtQjtBQWU1QixNQUFNQyxpQkFBMkNDLFdBQVU7QUFBQUMsS0FBQTtBQUN6RCxRQUFNQyxnQkFBZ0JDLFVBQVVILEtBQUs7QUFDckMsU0FDRSx1QkFBQyxTQUFJLFdBQVdFLGNBQWNFLFdBQzVCO0FBQUEsMkJBQUMsU0FBSSxXQUFXRixjQUFjRyxRQUMzQkwsZ0JBQU1NLFNBQVNOLE1BQU1NLFVBQVUsS0FDNUIsdUJBQUMsY0FDRCxPQUFPTixNQUFNTSxPQUNiLE1BQU1OLE1BQU1PLE1BQ1osVUFBVVAsTUFBTVEsWUFIaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUd5QixJQUV6QlIsTUFBTVMsYUFBYVQsTUFBTVMsY0FBYyxLQUNyQ1QsTUFBTVMsWUFDTix1QkFBQyxRQUNELFVBQVVULE1BQU1VLFlBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDeUIsS0FWakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQ1YsTUFBTVcsUUFBUSx1QkFBQyxRQUNkLFdBQVdULGNBQWNTLE1BRXhCWCxnQkFBTVcsUUFITTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSWY7QUFBQSxPQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ1YsR0F4QktGLGdCQUF1QztBQUFBLFVBQ3JCSSxTQUFTO0FBQUE7QUFBQVMsS0FEM0JiO0FBMEJOLE1BQU1JLFlBQVlBLENBQUNILFVBQStCO0FBQUFhLE1BQUE7QUFDaEQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVNQO0FBQUFBLElBQVVRO0FBQUFBLEVBQVcsSUFBSW5CLFNBQVM7QUFFM0QsU0FBT0gsZUFBZTtBQUFBLElBQ3BCVSxXQUFXO0FBQUEsTUFDVGEsU0FBUztBQUFBLE1BQ1RDLFlBQVk7QUFBQSxNQUNaQyxLQUFLSixRQUFRSztBQUFBQSxNQUNiWixVQUFVQSxTQUFTYTtBQUFBQSxJQUNyQjtBQUFBLElBQ0FWLE1BQU07QUFBQSxNQUNKVyxPQUFPdEIsTUFBTXVCLFlBQVl2QixNQUFNdUIsWUFBWVQsT0FBT1UsT0FBTyxHQUFHO0FBQUEsTUFDNURSLFlBQVloQixNQUFNZ0IsYUFBYWhCLE1BQU1nQixhQUFhQSxXQUFXUztBQUFBQSxNQUM3RGpCLFVBQVVBLFNBQVNhO0FBQUFBLElBQ3JCO0FBQUEsSUFDQWhCLFFBQVE7QUFBQSxNQUNOcUIsT0FBTzFCLE1BQU1PLFFBQVE7QUFBQSxNQUNyQm9CLFFBQVEzQixNQUFNTyxRQUFRO0FBQUEsTUFDdEJxQixjQUFjO0FBQUEsTUFDZEMsaUJBQWlCN0IsTUFBTXNCLFFBQ25CdEIsTUFBTXNCLFFBQ050QixNQUFNUyxZQUNKWCxZQUFZRSxNQUFNUyxXQUFxQixLQUFLLElBQzVDSyxPQUFPVSxPQUFPLEdBQUc7QUFBQSxNQUN2QkYsT0FBT3RCLE1BQU04QixXQUFXOUIsTUFBTThCLFdBQVdoQixPQUFPaUI7QUFBQUEsTUFDaERkLFNBQVM7QUFBQSxNQUNUQyxZQUFZO0FBQUEsTUFDWmMsZ0JBQWdCO0FBQUEsTUFDaEJ4QixVQUFVUixNQUFNUSxZQUFZQSxTQUFTYTtBQUFBQSxNQUNyQ0wsWUFBWUEsV0FBV1M7QUFBQUEsTUFDdkJRLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQUMsVUFBVTtBQUFBLE1BQ1IxQixVQUFVQSxTQUFTYTtBQUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNSLElBcENLVixXQUFTO0FBQUEsVUFDcUNOLFFBQVE7QUFBQTtBQXFDNUQsZUFBZUU7QUFTZixJQUFBYTtBQUFBdUIsYUFBQXZCLElBQUEiLCJuYW1lcyI6WyJJY29uIiwibWVyZ2VTdHlsZVNldHMiLCJUZXh0IiwiVXNlckF2YXRhciIsInVzZVRoZW1lIiwiY29sb3JQaWNrZXIiLCJQZXJzb25hR2VuZXJhbCIsInByb3BzIiwiX3MiLCJwZXJzb25hU3R5bGVzIiwidXNlU3R5bGVzIiwiY29udGFpbmVyIiwiYXZhdGFyIiwiaW1hZ2UiLCJzaXplIiwiZm9udFNpemUiLCJzaG9ydE5hbWUiLCJpY29uTmFtZSIsIm5hbWUiLCJfYyIsIl9zMiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJnYXAiLCJzbSIsInAxNCIsImNvbG9yIiwibmFtZUNvbG9yIiwicHVycGxlIiwic2VtaWJvbGQiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmRDb2xvciIsImljb25GaWxsIiwid2hpdGUiLCJqdXN0aWZ5Q29udGVudCIsImxpbmVIZWlnaHQiLCJ1c2VyTmFtZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBlcnNvbmFHZW5lcmFsLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3BlcnNvbmEvUGVyc29uYUdlbmVyYWwudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSWNvbiwgbWVyZ2VTdHlsZVNldHMsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXNlckF2YXRhciB9IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvYWRtaW4vdXNlcnMvY29tcG9uZW50cydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5pbXBvcnQgeyBURm9udFdlaWdodCB9IGZyb20gJy4uLy4uL2hvb2tzL3RoZW1lJ1xuaW1wb3J0IHsgY29sb3JQaWNrZXIgfSBmcm9tICcuLi8uLi91dGlscydcblxuaW50ZXJmYWNlIFBlcnNvbmFHZW5lcmFsUHJvcHMge1xuICBpbWFnZT86IHN0cmluZ1xuICBzaG9ydE5hbWU/OiBzdHJpbmdcbiAgc2l6ZT86IHN0cmluZ1xuICBmb250U2l6ZT86IHN0cmluZ1xuICBuYW1lPzogc3RyaW5nXG4gIGljb25OYW1lPzogc3RyaW5nXG4gIGNvbG9yPzogc3RyaW5nXG4gIGljb25GaWxsPzogc3RyaW5nXG4gIG5hbWVDb2xvcj86IHN0cmluZ1xuICBmb250V2VpZ2h0PzogVEZvbnRXZWlnaHRcbn1cblxuY29uc3QgUGVyc29uYUdlbmVyYWw6IEZDPFBlcnNvbmFHZW5lcmFsUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHBlcnNvbmFTdHlsZXMgPSB1c2VTdHlsZXMocHJvcHMpXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3BlcnNvbmFTdHlsZXMuY29udGFpbmVyfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtwZXJzb25hU3R5bGVzLmF2YXRhcn0+XG4gICAgICAgIHtwcm9wcy5pbWFnZSAmJiBwcm9wcy5pbWFnZSAhPT0gJydcbiAgICAgICAgICA/IDxVc2VyQXZhdGFyXG4gICAgICAgICAgICBpbWFnZT17cHJvcHMuaW1hZ2V9XG4gICAgICAgICAgICBzaXplPXtwcm9wcy5zaXplfVxuICAgICAgICAgICAgZm9udFNpemU9e3Byb3BzLmZvbnRTaXplfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgOiBwcm9wcy5zaG9ydE5hbWUgJiYgcHJvcHMuc2hvcnROYW1lICE9PSAnJ1xuICAgICAgICAgICAgPyBwcm9wcy5zaG9ydE5hbWVcbiAgICAgICAgICAgIDogPEljb25cbiAgICAgICAgICAgICAgaWNvbk5hbWU9e3Byb3BzLmljb25OYW1lfVxuICAgICAgICAgICAgLz59XG4gICAgICA8L2Rpdj5cbiAgICAgIHtwcm9wcy5uYW1lICYmIDxUZXh0XG4gICAgICAgIGNsYXNzTmFtZT17cGVyc29uYVN0eWxlcy5uYW1lfVxuICAgICAgPlxuICAgICAgICB7cHJvcHMubmFtZX1cbiAgICAgIDwvVGV4dD59XG4gICAgPC9kaXY+XG4gIClcbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKHByb3BzOiBQZXJzb25hR2VuZXJhbFByb3BzKSA9PiB7XG4gIGNvbnN0IHsgY29sb3JzLCBzcGFjaW5nLCBmb250U2l6ZSwgZm9udFdlaWdodCB9ID0gdXNlVGhlbWUoKVxuICAvLyBjb25zdCB0YWdDb2xvciA9IHVzZUNvbG9yc0ljb25zKHByb3BzLm5vdGlmaWNhdGlvblR5cGUgYXMgTm90aWZpY2F0aW9uVHlwZUVudW0pXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XG4gICAgY29udGFpbmVyOiB7XG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgIGdhcDogc3BhY2luZy5zbSxcbiAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXG4gICAgfSxcbiAgICBuYW1lOiB7XG4gICAgICBjb2xvcjogcHJvcHMubmFtZUNvbG9yID8gcHJvcHMubmFtZUNvbG9yIDogY29sb3JzLnB1cnBsZVs4MDBdLFxuICAgICAgZm9udFdlaWdodDogcHJvcHMuZm9udFdlaWdodCA/IHByb3BzLmZvbnRXZWlnaHQgOiBmb250V2VpZ2h0LnNlbWlib2xkLFxuICAgICAgZm9udFNpemU6IGZvbnRTaXplLnAxNCxcbiAgICB9LFxuICAgIGF2YXRhcjoge1xuICAgICAgd2lkdGg6IHByb3BzLnNpemUgPz8gJzQwcHgnLFxuICAgICAgaGVpZ2h0OiBwcm9wcy5zaXplID8/ICc0MHB4JyxcbiAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IHByb3BzLmNvbG9yXG4gICAgICAgID8gcHJvcHMuY29sb3JcbiAgICAgICAgOiBwcm9wcy5zaG9ydE5hbWVcbiAgICAgICAgICA/IGNvbG9yUGlja2VyKHByb3BzLnNob3J0TmFtZSBhcyBzdHJpbmcsICc1MCUnKVxuICAgICAgICAgIDogY29sb3JzLnB1cnBsZVsyMDBdLFxuICAgICAgY29sb3I6IHByb3BzLmljb25GaWxsID8gcHJvcHMuaWNvbkZpbGwgOiBjb2xvcnMud2hpdGUsXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICAgIGZvbnRTaXplOiBwcm9wcy5mb250U2l6ZSA/PyBmb250U2l6ZS5wMTQsXG4gICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnNlbWlib2xkLFxuICAgICAgbGluZUhlaWdodDogMCxcbiAgICB9LFxuICAgIHVzZXJOYW1lOiB7XG4gICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxuICAgIH0sXG4gIH0pXG59XG5cbmV4cG9ydCBkZWZhdWx0IFBlcnNvbmFHZW5lcmFsXG5cbi8vIGNvbnN0IHVzZUNvbG9yc0ljb25zID0gKHR5cGU6IE5vdGlmaWNhdGlvblR5cGVFbnVtKSA9PiB7XG4vLyAgIGNvbnN0IHsgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG4vLyAgIHJldHVybiB0eXBlID09PSBOb3RpZmljYXRpb25UeXBlRW51bS5Eb3dubG9hZFxuLy8gICAgID8gY29sb3JzLmxpbWVbMjAwXVxuLy8gICAgIDogdHlwZSA9PT0gTm90aWZpY2F0aW9uVHlwZUVudW0uUmVkaXJlY2lvbmFtZW50b1xuLy8gICAgICAgPyBjb2xvcnMueWVsbG93WzIwMF1cbi8vICAgICAgIDogY29sb3JzLmJsdWVbMjAwXVxuLy8gfVxuIl19