import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterModuleTag.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterModuleTag.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { FontSizes, FontWeights, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTagsColors } from "/src/shared/hooks/index.ts";
import { ModuleRecord } from "/src/shared/record/index.ts";
const NotificationsCenterModuleTag = (props) => {
  _s();
  const styles = useStyles(props.module);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.container, children: ModuleRecord[props.module] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterModuleTag.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterModuleTag, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = NotificationsCenterModuleTag;
export default NotificationsCenterModuleTag;
const useStyles = (props) => {
  _s2();
  const {
    background,
    color
  } = useTagsColors(props, ListTags);
  return mergeStyleSets({
    container: {
      display: "inline-block",
      whiteSpace: "nowrap",
      fontSize: FontSizes.mini,
      fontWeight: FontWeights.semibold,
      backgroundColor: background,
      color,
      padding: "4px 6px",
      borderRadius: "4px"
    }
  });
};
_s2(useStyles, "yAqk/mHsCk1OPWDYazbBUeiAsGM=", false, function() {
  return [useTagsColors];
});
const ListTags = [{
  value: 1,
  type: "Inativo"
}, {
  value: 2,
  type: "Novidade"
}, {
  value: 3,
  type: "Andamento"
}];
var _c;
$RefreshReg$(_c, "NotificationsCenterModuleTag");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterModuleTag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkSixTQUFTQSxXQUFXQyxhQUFhQyxzQkFBc0I7QUFHdkQsU0FBU0MscUJBQXFCO0FBRTlCLFNBQVNDLG9CQUFvQjtBQU03QixNQUFNQywrQkFBdUVDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRixRQUFNQyxTQUFTQyxVQUFVSCxNQUFNSSxNQUFNO0FBQ3JDLFNBQ0UsdUJBQUMsU0FBSSxXQUFXRixPQUFPRyxXQUFZUCx1QkFBYUUsTUFBTUksTUFBTSxLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThEO0FBRWxFO0FBQUNILEdBTEtGLDhCQUFtRTtBQUFBLFVBQ3hESSxTQUFTO0FBQUE7QUFBQUcsS0FEcEJQO0FBT04sZUFBZUE7QUFFZixNQUFNSSxZQUFZQSxDQUFDSCxVQUFzQjtBQUFBTyxNQUFBO0FBQ3ZDLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFZQztBQUFBQSxFQUFNLElBQUlaLGNBQWNHLE9BQU9VLFFBQVE7QUFDM0QsU0FBT2QsZUFBZTtBQUFBLElBQ3BCUyxXQUFXO0FBQUEsTUFDVE0sU0FBUztBQUFBLE1BQ1RDLFlBQVk7QUFBQSxNQUNaQyxVQUFVbkIsVUFBVW9CO0FBQUFBLE1BQ3BCQyxZQUFZcEIsWUFBWXFCO0FBQUFBLE1BQ3hCQyxpQkFBaUJUO0FBQUFBLE1BQ2pCQztBQUFBQSxNQUNBUyxTQUFTO0FBQUEsTUFDVEMsY0FBYztBQUFBLElBQ2hCO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ1osSUFkS0osV0FBUztBQUFBLFVBQ2lCTixhQUFhO0FBQUE7QUFlN0MsTUFBTWEsV0FBVyxDQUNmO0FBQUEsRUFDRVUsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUQsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFDUixHQUNBO0FBQUEsRUFDRUQsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFDUixDQUFDO0FBQ3lCLElBQUFmO0FBQUFnQixhQUFBaEIsSUFBQSIsIm5hbWVzIjpbIkZvbnRTaXplcyIsIkZvbnRXZWlnaHRzIiwibWVyZ2VTdHlsZVNldHMiLCJ1c2VUYWdzQ29sb3JzIiwiTW9kdWxlUmVjb3JkIiwiTm90aWZpY2F0aW9uc0NlbnRlck1vZHVsZVRhZyIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJtb2R1bGUiLCJjb250YWluZXIiLCJfYyIsIl9zMiIsImJhY2tncm91bmQiLCJjb2xvciIsIkxpc3RUYWdzIiwiZGlzcGxheSIsIndoaXRlU3BhY2UiLCJmb250U2l6ZSIsIm1pbmkiLCJmb250V2VpZ2h0Iiwic2VtaWJvbGQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwidmFsdWUiLCJ0eXBlIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uc0NlbnRlck1vZHVsZVRhZy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9ub3RpZmljYXRpb25zL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uc0NlbnRlck1vZHVsZVRhZy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGb250U2l6ZXMsIEZvbnRXZWlnaHRzLCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgTW9kdWxlRW51bSB9IGZyb20gJy4uLy4uLy4uL2VudW1zL01vZHVsZUVudW0nXHJcbmltcG9ydCB7IHVzZVRhZ3NDb2xvcnMgfSBmcm9tICcuLi8uLi8uLi9ob29rcydcclxuaW1wb3J0IHsgVGFnc0NvbXBvc2l0aW9uTW9kdWxlIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdGFnc0NvbG9ycydcclxuaW1wb3J0IHsgTW9kdWxlUmVjb3JkIH0gZnJvbSAnLi4vLi4vLi4vcmVjb3JkJ1xyXG5cclxuaW50ZXJmYWNlIE5vdGlmaWNhdGlvbnNDZW50ZXJNb2R1bGVUYWdQcm9wcyB7XHJcbiAgbW9kdWxlOiBNb2R1bGVFbnVtXHJcbn1cclxuXHJcbmNvbnN0IE5vdGlmaWNhdGlvbnNDZW50ZXJNb2R1bGVUYWc6IEZDPE5vdGlmaWNhdGlvbnNDZW50ZXJNb2R1bGVUYWdQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMocHJvcHMubW9kdWxlKVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+e01vZHVsZVJlY29yZFtwcm9wcy5tb2R1bGVdfTwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uc0NlbnRlck1vZHVsZVRhZ1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKHByb3BzOiBNb2R1bGVFbnVtKSA9PiB7XHJcbiAgY29uc3QgeyBiYWNrZ3JvdW5kLCBjb2xvciB9ID0gdXNlVGFnc0NvbG9ycyhwcm9wcywgTGlzdFRhZ3MpXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGNvbnRhaW5lcjoge1xyXG4gICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcclxuICAgICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXHJcbiAgICAgIGZvbnRTaXplOiBGb250U2l6ZXMubWluaSxcclxuICAgICAgZm9udFdlaWdodDogRm9udFdlaWdodHMuc2VtaWJvbGQsXHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogYmFja2dyb3VuZCxcclxuICAgICAgY29sb3I6IGNvbG9yLFxyXG4gICAgICBwYWRkaW5nOiAnNHB4IDZweCcsXHJcbiAgICAgIGJvcmRlclJhZGl1czogJzRweCcsXHJcbiAgICB9LFxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IExpc3RUYWdzID0gW1xyXG4gIHtcclxuICAgIHZhbHVlOiAxLFxyXG4gICAgdHlwZTogJ0luYXRpdm8nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IDIsXHJcbiAgICB0eXBlOiAnTm92aWRhZGUnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IDMsXHJcbiAgICB0eXBlOiAnQW5kYW1lbnRvJyxcclxuICB9LFxyXG5dIGFzIFRhZ3NDb21wb3NpdGlvbk1vZHVsZVtdXHJcbiJdfQ==