import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/MaskedTextField.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/MaskedTextField.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { MaskedTextField as Input, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const MaskedTextField = (props) => {
  _s();
  const styles = useStyles(props);
  return /* @__PURE__ */ jsxDEV(Input, { ...props, className: styles.input }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/MaskedTextField.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(MaskedTextField, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = MaskedTextField;
const useStyles = (props) => {
  _s2();
  const {
    colors
  } = useTheme();
  const inputStyles = mergeStyleSets({
    input: {
      borderRadius: "2px",
      ".ms-TextField-fieldGroup": {
        borderRadius: "2px",
        border: `solid 1px ${props.errorMessage ? colors.red[500] : colors.gray[400]}`
      },
      ".ms-TextField-fieldGroup:hover": {
        borderColor: `${props.errorMessage ? colors.red[500] : colors.blue[300]}`
      },
      ".ms-TextField-fieldGroup::after": {
        border: `solid 2px ${colors.blue[300]}`,
        borderRadius: "2px"
      },
      ".ms-TextField-errorMessage": {
        color: colors.red[500]
      },
      "input:disabled": {
        background: props.disabledAsReadOnly ? colors.gray[200] : colors.neutralLight[100],
        border: "none"
      },
      "textarea:disabled": {
        background: props.disabledAsReadOnly ? colors.gray[200] : colors.neutralLight[100]
      },
      "&.ms-TextField.is-disabled .ms-TextField-fieldGroup": {
        border: "none"
      }
    },
    ...props.styles
  });
  return inputStyles;
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default MaskedTextField;
var _c;
$RefreshReg$(_c, "MaskedTextField");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/MaskedTextField.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYSixTQUFnQ0EsbUJBQW1CQyxPQUFPQyxzQkFBc0I7QUFFaEYsU0FBU0MsZ0JBQWdCO0FBTXpCLE1BQU1ILGtCQUE2QkksV0FBVTtBQUFBQyxLQUFBO0FBQzNDLFFBQU1DLFNBQVNDLFVBQVVILEtBQUs7QUFDOUIsU0FDRSx1QkFBQyxTQUNDLEdBQUlBLE9BQ0osV0FBV0UsT0FBT0UsU0FGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUUwQjtBQUc5QjtBQUFDSCxHQVJLTCxpQkFBeUI7QUFBQSxVQUNkTyxTQUFTO0FBQUE7QUFBQUUsS0FEcEJUO0FBVU4sTUFBTU8sWUFBWUEsQ0FBQ0gsVUFBaUI7QUFBQU0sTUFBQTtBQUNsQyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJUixTQUFTO0FBQzVCLFFBQU1TLGNBQWNWLGVBQWU7QUFBQSxJQUNqQ00sT0FBTztBQUFBLE1BQ0xLLGNBQWM7QUFBQSxNQUNkLDRCQUE0QjtBQUFBLFFBQzFCQSxjQUFjO0FBQUEsUUFDZEMsUUFBUyxhQUFZVixNQUFNVyxlQUFlSixPQUFPSyxJQUFJLEdBQUcsSUFBSUwsT0FBT00sS0FBSyxHQUFHO0FBQUEsTUFDN0U7QUFBQSxNQUNBLGtDQUFrQztBQUFBLFFBQ2hDQyxhQUFjLEdBQUVkLE1BQU1XLGVBQWVKLE9BQU9LLElBQUksR0FBRyxJQUFJTCxPQUFPUSxLQUFLLEdBQUc7QUFBQSxNQUN4RTtBQUFBLE1BQ0EsbUNBQW1DO0FBQUEsUUFDakNMLFFBQVMsYUFBWUgsT0FBT1EsS0FBSyxHQUFHO0FBQUEsUUFDcENOLGNBQWM7QUFBQSxNQUNoQjtBQUFBLE1BQ0EsOEJBQThCO0FBQUEsUUFDNUJPLE9BQU9ULE9BQU9LLElBQUksR0FBRztBQUFBLE1BQ3ZCO0FBQUEsTUFDQSxrQkFBa0I7QUFBQSxRQUNoQkssWUFBWWpCLE1BQU1rQixxQkFBcUJYLE9BQU9NLEtBQUssR0FBRyxJQUFJTixPQUFPWSxhQUFhLEdBQUc7QUFBQSxRQUNqRlQsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxNQUNBLHFCQUFxQjtBQUFBLFFBQ25CTyxZQUFZakIsTUFBTWtCLHFCQUFxQlgsT0FBT00sS0FBSyxHQUFHLElBQUlOLE9BQU9ZLGFBQWEsR0FBRztBQUFBLE1BQ25GO0FBQUEsTUFDQSx1REFBdUQ7QUFBQSxRQUNyRFQsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFHVixNQUFNRTtBQUFBQSxFQUNYLENBQUM7QUFDRCxTQUFPTTtBQUNUO0FBQUNGLElBakNLSCxXQUFTO0FBQUEsVUFDTUosUUFBUTtBQUFBO0FBa0M3QixlQUFlSDtBQUFlLElBQUFTO0FBQUFlLGFBQUFmLElBQUEiLCJuYW1lcyI6WyJNYXNrZWRUZXh0RmllbGQiLCJJbnB1dCIsIm1lcmdlU3R5bGVTZXRzIiwidXNlVGhlbWUiLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiaW5wdXQiLCJfYyIsIl9zMiIsImNvbG9ycyIsImlucHV0U3R5bGVzIiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwiZXJyb3JNZXNzYWdlIiwicmVkIiwiZ3JheSIsImJvcmRlckNvbG9yIiwiYmx1ZSIsImNvbG9yIiwiYmFja2dyb3VuZCIsImRpc2FibGVkQXNSZWFkT25seSIsIm5ldXRyYWxMaWdodCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1hc2tlZFRleHRGaWVsZC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9pbnB1dHMvTWFza2VkVGV4dEZpZWxkLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElNYXNrZWRUZXh0RmllbGRQcm9wcywgTWFza2VkVGV4dEZpZWxkIGFzIElucHV0LCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuXHJcbmludGVyZmFjZSBQcm9wcyBleHRlbmRzIElNYXNrZWRUZXh0RmllbGRQcm9wcyB7XHJcbiAgZGlzYWJsZWRBc1JlYWRPbmx5PzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBNYXNrZWRUZXh0RmllbGQ6RkM8UHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKHByb3BzKVxyXG4gIHJldHVybiAoXHJcbiAgICA8SW5wdXRcclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAocHJvcHM6IFByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBpbnB1dFN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGlucHV0OiB7XHJcbiAgICAgIGJvcmRlclJhZGl1czogJzJweCcsXHJcbiAgICAgICcubXMtVGV4dEZpZWxkLWZpZWxkR3JvdXAnOiB7XHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnMnB4JyxcclxuICAgICAgICBib3JkZXI6IGBzb2xpZCAxcHggJHtwcm9wcy5lcnJvck1lc3NhZ2UgPyBjb2xvcnMucmVkWzUwMF0gOiBjb2xvcnMuZ3JheVs0MDBdfWAsXHJcbiAgICAgIH0sXHJcbiAgICAgICcubXMtVGV4dEZpZWxkLWZpZWxkR3JvdXA6aG92ZXInOiB7XHJcbiAgICAgICAgYm9yZGVyQ29sb3I6IGAke3Byb3BzLmVycm9yTWVzc2FnZSA/IGNvbG9ycy5yZWRbNTAwXSA6IGNvbG9ycy5ibHVlWzMwMF19YCxcclxuICAgICAgfSxcclxuICAgICAgJy5tcy1UZXh0RmllbGQtZmllbGRHcm91cDo6YWZ0ZXInOiB7XHJcbiAgICAgICAgYm9yZGVyOiBgc29saWQgMnB4ICR7Y29sb3JzLmJsdWVbMzAwXX1gLFxyXG4gICAgICAgIGJvcmRlclJhZGl1czogJzJweCcsXHJcbiAgICAgIH0sXHJcbiAgICAgICcubXMtVGV4dEZpZWxkLWVycm9yTWVzc2FnZSc6IHtcclxuICAgICAgICBjb2xvcjogY29sb3JzLnJlZFs1MDBdLFxyXG4gICAgICB9LFxyXG4gICAgICAnaW5wdXQ6ZGlzYWJsZWQnOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogcHJvcHMuZGlzYWJsZWRBc1JlYWRPbmx5ID8gY29sb3JzLmdyYXlbMjAwXSA6IGNvbG9ycy5uZXV0cmFsTGlnaHRbMTAwXSxcclxuICAgICAgICBib3JkZXI6ICdub25lJyxcclxuICAgICAgfSxcclxuICAgICAgJ3RleHRhcmVhOmRpc2FibGVkJzoge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHByb3BzLmRpc2FibGVkQXNSZWFkT25seSA/IGNvbG9ycy5ncmF5WzIwMF0gOiBjb2xvcnMubmV1dHJhbExpZ2h0WzEwMF0sXHJcbiAgICAgIH0sXHJcbiAgICAgICcmLm1zLVRleHRGaWVsZC5pcy1kaXNhYmxlZCAubXMtVGV4dEZpZWxkLWZpZWxkR3JvdXAnOiB7XHJcbiAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgLi4ucHJvcHMuc3R5bGVzLFxyXG4gIH0pXHJcbiAgcmV0dXJuIGlucHV0U3R5bGVzXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1hc2tlZFRleHRGaWVsZFxyXG4iXX0=