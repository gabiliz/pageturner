import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/filter/FilterGroup.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const memo = __vite__cjsImport5_react["memo"]; const useCallback = __vite__cjsImport5_react["useCallback"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useMemo = __vite__cjsImport5_react["useMemo"]; const useState = __vite__cjsImport5_react["useState"];
import { FlexRow, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FilterGroupTagsDisplay, FilterInputRender } from "/src/shared/components/filter/index.ts?t=1701096626433";
import { produce } from "/node_modules/.vite/deps/immer.js?v=9f90a7ff";
import { filterGroupContext } from "/src/shared/components/filter/filterGroupContext.ts";
const MAX_FILTER_GROUP_LENGTH = 45;
const FilterGroup = ({
  groups,
  onFilterQueryChange
}) => {
  _s();
  const [filterGroups, setFilterGroups] = useState([]);
  const [isActiveTracking, {
    toggle: toggleIsActiveTracking
  }] = useBoolean(true);
  const filterGroupsStyles = useFilterGroupsStyles();
  const handleItemsChange = useCallback((newGroup) => {
    if (newGroup.onChangeItems !== void 0) {
      newGroup.onChangeItems(newGroup.items);
    }
    setFilterGroups((prevFilterGroups) => {
      return produce(prevFilterGroups, (draft) => {
        const i = draft.findIndex((group) => group.filterGroupName === newGroup.filterGroupName);
        draft[i].items = newGroup.items;
        draft[i].allItemsSelected = newGroup.allItemsSelected;
      });
    });
  }, []);
  const handleRemoveItem = useCallback((filterGroup, key) => {
    const newFilterGroup = {
      ...filterGroup,
      items: filterGroup.items.filter((item) => item.key !== key)
    };
    handleItemsChange(newFilterGroup);
  }, [handleItemsChange]);
  const hasActiveFilters = useMemo(() => {
    const hasActiveFiltersLocal = filterGroups.some((filterGroup) => filterGroup.items.some((item) => item));
    return hasActiveFiltersLocal;
  }, [filterGroups]);
  const isDisabledAddItems = useMemo(() => {
    const count = filterGroups.reduce((prevCount, current) => {
      return prevCount + current.items.length;
    }, 0);
    return count >= MAX_FILTER_GROUP_LENGTH;
  }, [filterGroups]);
  const handleFilterGroups = useCallback(() => {
    setFilterGroups(groups);
  }, [groups]);
  const getFilterGroupByName = useCallback((name) => {
    const searchedGroup = filterGroups.find((group) => group.filterGroupName === name);
    return searchedGroup;
  }, [filterGroups]);
  useEffect(() => {
    handleFilterGroups();
  }, [handleFilterGroups]);
  useEffect(() => {
    onFilterQueryChange(filterGroups);
  }, [filterGroups]);
  return /* @__PURE__ */ jsxDEV(filterGroupContext.Provider, { value: {
    filterGroups,
    isDisabledAddItems,
    handleItemsChange,
    handleRemoveItem,
    getFilterGroupByName
  }, children: /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 16, className: filterGroupsStyles.options, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { gap: 10, verticalAlign: "center", className: filterGroupsStyles.layer, children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { className: filterGroupsStyles.eyeButton, iconProps: {
        iconName: isActiveTracking ? !hasActiveFilters ? "Eye-tracking-off" : "Eye-tracking" : "Eye-tracking-off"
      }, disabled: !hasActiveFilters, onClick: toggleIsActiveTracking }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
        lineNumber: 78,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { className: filterGroupsStyles.filterTitle, children: "Filtrar por: " }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
        lineNumber: 82,
        columnNumber: 11
      }, this),
      filterGroups.map((group) => {
        return /* @__PURE__ */ jsxDEV(FilterInputRender, { groupName: group.filterGroupName }, group.filterGroupName, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
          lineNumber: 85,
          columnNumber: 18
        }, this);
      })
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this),
    hasActiveFilters && isActiveTracking && /* @__PURE__ */ jsxDEV(FilterGroupTagsDisplay, { groups: filterGroups }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
      lineNumber: 89,
      columnNumber: 50
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
    lineNumber: 76,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx",
    lineNumber: 69,
    columnNumber: 10
  }, this);
};
_s(FilterGroup, "bZCXsQRBQvxeZa6o96aqbu0h6Ks=", false, function() {
  return [useBoolean, useFilterGroupsStyles];
});
_c = FilterGroup;
const useFilterGroupsStyles = () => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    options: {
      "> span.ms-layer": {
        display: "none"
      }
    },
    eyeButton: {
      minWidth: "12px",
      padding: 0,
      border: "none",
      "&:disabled": {
        backgroundColor: "transparent"
      }
    },
    filterTitle: {
      fontSize: theme.fontSize.p14,
      fontWeight: theme.fontWeight.semibold,
      color: theme.colors.gray[600],
      display: "flex",
      alignItems: "center",
      height: 32
    },
    layer: {
      ".ms-layer": {
        display: "none"
      }
    }
  });
};
_s2(useFilterGroupsStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default _c2 = memo(FilterGroup);
var _c, _c2;
$RefreshReg$(_c, "FilterGroup");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroup.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0ZWLFNBQVNBLGdCQUFnQkMsWUFBWTtBQUNyQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBYUMsTUFBTUMsYUFBYUMsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBRXBFLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUV2QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msd0JBQXdCQyx5QkFBeUI7QUFDMUQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQywwQkFBMEI7QUFPbkMsTUFBTUMsMEJBQTBCO0FBRWhDLE1BQU1DLGNBQW9DQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBUUM7QUFBb0IsTUFBTTtBQUFBQyxLQUFBO0FBQzdFLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJZCxTQUF5QixFQUFFO0FBQ25FLFFBQU0sQ0FBQ2Usa0JBQWtCO0FBQUEsSUFBRUMsUUFBUUM7QUFBQUEsRUFBdUIsQ0FBQyxJQUFJdEIsV0FBVyxJQUFJO0FBRTlFLFFBQU11QixxQkFBcUJDLHNCQUFzQjtBQUVqRCxRQUFNQyxvQkFBb0J2QixZQUN4QixDQUFDd0IsYUFBMkI7QUFDMUIsUUFBSUEsU0FBU0Msa0JBQWtCQyxRQUFXO0FBQ3hDRixlQUFTQyxjQUFjRCxTQUFTRyxLQUFLO0FBQUEsSUFDdkM7QUFFQVYsb0JBQWdCVyxzQkFBb0I7QUFDbEMsYUFBT25CLFFBQVFtQixrQkFBb0NDLFdBQVM7QUFDMUQsY0FBTUMsSUFBSUQsTUFBTUUsVUFBVUMsV0FBU0EsTUFBTUMsb0JBQW9CVCxTQUFTUyxlQUFlO0FBQ3JGSixjQUFNQyxDQUFDLEVBQUVILFFBQVFILFNBQVNHO0FBQzFCRSxjQUFNQyxDQUFDLEVBQUVJLG1CQUFtQlYsU0FBU1U7QUFBQUEsTUFDdkMsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFO0FBRVAsUUFBTUMsbUJBQW1CbkMsWUFBWSxDQUFDb0MsYUFBMkJDLFFBQWdCO0FBQy9FLFVBQU1DLGlCQUFpQjtBQUFBLE1BQ3JCLEdBQUdGO0FBQUFBLE1BQ0hULE9BQU9TLFlBQVlULE1BQU1ZLE9BQU9DLFVBQVFBLEtBQUtILFFBQVFBLEdBQUc7QUFBQSxJQUMxRDtBQUVBZCxzQkFBa0JlLGNBQWM7QUFBQSxFQUNsQyxHQUFHLENBQUNmLGlCQUFpQixDQUFDO0FBRXRCLFFBQU1rQixtQkFBbUJ2QyxRQUFRLE1BQU07QUFDckMsVUFBTXdDLHdCQUF3QjFCLGFBQWEyQixLQUFLUCxpQkFBZUEsWUFBWVQsTUFBTWdCLEtBQUtILFVBQVFBLElBQUksQ0FBQztBQUNuRyxXQUFPRTtBQUFBQSxFQUNULEdBQUcsQ0FBQzFCLFlBQVksQ0FBQztBQUVqQixRQUFNNEIscUJBQXFCMUMsUUFBUSxNQUFNO0FBQ3ZDLFVBQU0yQyxRQUFRN0IsYUFBYThCLE9BQU8sQ0FBQ0MsV0FBV0MsWUFBWTtBQUN4RCxhQUFPRCxZQUFZQyxRQUFRckIsTUFBTXNCO0FBQUFBLElBQ25DLEdBQUcsQ0FBQztBQUVKLFdBQU9KLFNBQVNsQztBQUFBQSxFQUNsQixHQUFHLENBQUNLLFlBQVksQ0FBQztBQUVqQixRQUFNa0MscUJBQXFCbEQsWUFBWSxNQUFNO0FBQzNDaUIsb0JBQWdCSixNQUFNO0FBQUEsRUFDeEIsR0FBRyxDQUFDQSxNQUFNLENBQUM7QUFFWCxRQUFNc0MsdUJBQXVCbkQsWUFBWSxDQUFDb0QsU0FBaUI7QUFDekQsVUFBTUMsZ0JBQWdCckMsYUFBYXNDLEtBQUt0QixXQUFTQSxNQUFNQyxvQkFBb0JtQixJQUFJO0FBRS9FLFdBQU9DO0FBQUFBLEVBQ1QsR0FBRyxDQUFDckMsWUFBWSxDQUFDO0FBRWpCZixZQUFVLE1BQU07QUFDZGlELHVCQUFtQjtBQUFBLEVBQ3JCLEdBQUcsQ0FBQ0Esa0JBQWtCLENBQUM7QUFFdkJqRCxZQUFVLE1BQU07QUFDZGEsd0JBQW9CRSxZQUFZO0FBQUEsRUFDbEMsR0FBRyxDQUFDQSxZQUFZLENBQUM7QUFFakIsU0FDRSx1QkFBQyxtQkFBbUIsVUFBbkIsRUFDQyxPQUFPO0FBQUEsSUFDTEE7QUFBQUEsSUFDQTRCO0FBQUFBLElBQ0FyQjtBQUFBQSxJQUNBWTtBQUFBQSxJQUNBZ0I7QUFBQUEsRUFDRixHQUVBLGlDQUFDLFdBQ0MsZUFBYyxVQUNkLEtBQUssSUFDTCxXQUFXOUIsbUJBQW1Ca0MsU0FFOUI7QUFBQSwyQkFBQyxXQUFRLEtBQUssSUFBSSxlQUFjLFVBQVMsV0FBV2xDLG1CQUFtQm1DLE9BQ3JFO0FBQUEsNkJBQUMsaUJBQ0MsV0FBV25DLG1CQUFtQm9DLFdBQzlCLFdBQVc7QUFBQSxRQUNUQyxVQUFVeEMsbUJBQW9CLENBQUN1QixtQkFBbUIscUJBQXFCLGlCQUFrQjtBQUFBLE1BQzNGLEdBQ0EsVUFBVSxDQUFDQSxrQkFDWCxTQUFTckIsMEJBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1rQztBQUFBLE1BR2xDLHVCQUFDLFFBQUssV0FBV0MsbUJBQW1Cc0MsYUFBYSw2QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BRTdEM0MsYUFBYTRDLElBQUk1QixXQUFTO0FBQ3pCLGVBQ0UsdUJBQUMscUJBRUMsV0FBV0EsTUFBTUMsbUJBRFpELE1BQU1DLGlCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFbUM7QUFBQSxNQUd2QyxDQUFDO0FBQUEsU0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUNRLG9CQUFvQnZCLG9CQUNuQix1QkFBQywwQkFDQyxRQUFRRixnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQ3VCO0FBQUEsT0E3QjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQTtBQUVKO0FBQUNELEdBM0dLSCxhQUFpQztBQUFBLFVBRTBCZCxZQUVwQ3dCLHFCQUFxQjtBQUFBO0FBQUF1QyxLQUo1Q2pEO0FBNkdOLE1BQU1VLHdCQUF3QkEsTUFBTTtBQUFBd0MsTUFBQTtBQUNsQyxRQUFNQyxRQUFRekQsU0FBUztBQUV2QixTQUFPVixlQUFlO0FBQUEsSUFDcEIyRCxTQUFTO0FBQUEsTUFDUCxtQkFBbUI7QUFBQSxRQUNqQlMsU0FBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQUEsSUFDQVAsV0FBVztBQUFBLE1BQ1RRLFVBQVU7QUFBQSxNQUNWQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1IsY0FBYztBQUFBLFFBQ1pDLGlCQUFpQjtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLElBQ0FULGFBQWE7QUFBQSxNQUNYVSxVQUFVTixNQUFNTSxTQUFTQztBQUFBQSxNQUN6QkMsWUFBWVIsTUFBTVEsV0FBV0M7QUFBQUEsTUFDN0JDLE9BQU9WLE1BQU1XLE9BQU9DLEtBQUssR0FBRztBQUFBLE1BQzVCWCxTQUFTO0FBQUEsTUFDVFksWUFBWTtBQUFBLE1BQ1pDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQXJCLE9BQU87QUFBQSxNQUNMLGFBQWE7QUFBQSxRQUNYUSxTQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDRixJQS9CS3hDLHVCQUFxQjtBQUFBLFVBQ1hoQixRQUFRO0FBQUE7QUFnQ3hCLGVBQUF3RSxNQUFlL0UsS0FBS2EsV0FBVztBQUFDLElBQUFpRCxJQUFBaUI7QUFBQUMsYUFBQWxCLElBQUE7QUFBQWtCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlU2V0cyIsIlRleHQiLCJ1c2VCb29sZWFuIiwibWVtbyIsInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiRmxleFJvdyIsIkRlZmF1bHRCdXR0b24iLCJ1c2VUaGVtZSIsIkZpbHRlckdyb3VwVGFnc0Rpc3BsYXkiLCJGaWx0ZXJJbnB1dFJlbmRlciIsInByb2R1Y2UiLCJmaWx0ZXJHcm91cENvbnRleHQiLCJNQVhfRklMVEVSX0dST1VQX0xFTkdUSCIsIkZpbHRlckdyb3VwIiwiZ3JvdXBzIiwib25GaWx0ZXJRdWVyeUNoYW5nZSIsIl9zIiwiZmlsdGVyR3JvdXBzIiwic2V0RmlsdGVyR3JvdXBzIiwiaXNBY3RpdmVUcmFja2luZyIsInRvZ2dsZSIsInRvZ2dsZUlzQWN0aXZlVHJhY2tpbmciLCJmaWx0ZXJHcm91cHNTdHlsZXMiLCJ1c2VGaWx0ZXJHcm91cHNTdHlsZXMiLCJoYW5kbGVJdGVtc0NoYW5nZSIsIm5ld0dyb3VwIiwib25DaGFuZ2VJdGVtcyIsInVuZGVmaW5lZCIsIml0ZW1zIiwicHJldkZpbHRlckdyb3VwcyIsImRyYWZ0IiwiaSIsImZpbmRJbmRleCIsImdyb3VwIiwiZmlsdGVyR3JvdXBOYW1lIiwiYWxsSXRlbXNTZWxlY3RlZCIsImhhbmRsZVJlbW92ZUl0ZW0iLCJmaWx0ZXJHcm91cCIsImtleSIsIm5ld0ZpbHRlckdyb3VwIiwiZmlsdGVyIiwiaXRlbSIsImhhc0FjdGl2ZUZpbHRlcnMiLCJoYXNBY3RpdmVGaWx0ZXJzTG9jYWwiLCJzb21lIiwiaXNEaXNhYmxlZEFkZEl0ZW1zIiwiY291bnQiLCJyZWR1Y2UiLCJwcmV2Q291bnQiLCJjdXJyZW50IiwibGVuZ3RoIiwiaGFuZGxlRmlsdGVyR3JvdXBzIiwiZ2V0RmlsdGVyR3JvdXBCeU5hbWUiLCJuYW1lIiwic2VhcmNoZWRHcm91cCIsImZpbmQiLCJvcHRpb25zIiwibGF5ZXIiLCJleWVCdXR0b24iLCJpY29uTmFtZSIsImZpbHRlclRpdGxlIiwibWFwIiwiX2MiLCJfczIiLCJ0aGVtZSIsImRpc3BsYXkiLCJtaW5XaWR0aCIsInBhZGRpbmciLCJib3JkZXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJmb250U2l6ZSIsInAxNCIsImZvbnRXZWlnaHQiLCJzZW1pYm9sZCIsImNvbG9yIiwiY29sb3JzIiwiZ3JheSIsImFsaWduSXRlbXMiLCJoZWlnaHQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaWx0ZXJHcm91cC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9maWx0ZXIvRmlsdGVyR3JvdXAudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IHVzZUJvb2xlYW4gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtaG9va3MnXHJcbmltcG9ydCB7IEZDLCBtZW1vLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxuaW1wb3J0IHsgRmxleFJvdywgRGVmYXVsdEJ1dHRvbiB9IGZyb20gJy4uLydcclxuaW1wb3J0IHsgSUZpbHRlckdyb3VwIH0gZnJvbSAnLi90eXBlcydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuaW1wb3J0IHsgRmlsdGVyR3JvdXBUYWdzRGlzcGxheSwgRmlsdGVySW5wdXRSZW5kZXIgfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyBwcm9kdWNlIH0gZnJvbSAnaW1tZXInXHJcbmltcG9ydCB7IGZpbHRlckdyb3VwQ29udGV4dCB9IGZyb20gJy4vZmlsdGVyR3JvdXBDb250ZXh0J1xyXG5cclxuaW50ZXJmYWNlIEZpbHRlckdyb3VwUHJvcHMge1xyXG4gIGdyb3VwczogSUZpbHRlckdyb3VwW10sXHJcbiAgb25GaWx0ZXJRdWVyeUNoYW5nZTogKGZpbHRlckdyb3VwczogSUZpbHRlckdyb3VwW10pID0+IHZvaWRcclxufVxyXG5cclxuY29uc3QgTUFYX0ZJTFRFUl9HUk9VUF9MRU5HVEggPSA0NVxyXG5cclxuY29uc3QgRmlsdGVyR3JvdXA6IEZDPEZpbHRlckdyb3VwUHJvcHM+ID0gKHsgZ3JvdXBzLCBvbkZpbHRlclF1ZXJ5Q2hhbmdlIH0pID0+IHtcclxuICBjb25zdCBbZmlsdGVyR3JvdXBzLCBzZXRGaWx0ZXJHcm91cHNdID0gdXNlU3RhdGU8SUZpbHRlckdyb3VwW10+KFtdKVxyXG4gIGNvbnN0IFtpc0FjdGl2ZVRyYWNraW5nLCB7IHRvZ2dsZTogdG9nZ2xlSXNBY3RpdmVUcmFja2luZyB9XSA9IHVzZUJvb2xlYW4odHJ1ZSlcclxuXHJcbiAgY29uc3QgZmlsdGVyR3JvdXBzU3R5bGVzID0gdXNlRmlsdGVyR3JvdXBzU3R5bGVzKClcclxuXHJcbiAgY29uc3QgaGFuZGxlSXRlbXNDaGFuZ2UgPSB1c2VDYWxsYmFjayhcclxuICAgIChuZXdHcm91cDogSUZpbHRlckdyb3VwKSA9PiB7XHJcbiAgICAgIGlmIChuZXdHcm91cC5vbkNoYW5nZUl0ZW1zICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBuZXdHcm91cC5vbkNoYW5nZUl0ZW1zKG5ld0dyb3VwLml0ZW1zKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRGaWx0ZXJHcm91cHMocHJldkZpbHRlckdyb3VwcyA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHByb2R1Y2UocHJldkZpbHRlckdyb3VwcyBhcyBJRmlsdGVyR3JvdXBbXSwgZHJhZnQgPT4ge1xyXG4gICAgICAgICAgY29uc3QgaSA9IGRyYWZ0LmZpbmRJbmRleChncm91cCA9PiBncm91cC5maWx0ZXJHcm91cE5hbWUgPT09IG5ld0dyb3VwLmZpbHRlckdyb3VwTmFtZSkgYXMgbnVtYmVyXHJcbiAgICAgICAgICBkcmFmdFtpXS5pdGVtcyA9IG5ld0dyb3VwLml0ZW1zXHJcbiAgICAgICAgICBkcmFmdFtpXS5hbGxJdGVtc1NlbGVjdGVkID0gbmV3R3JvdXAuYWxsSXRlbXNTZWxlY3RlZFxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlSXRlbSA9IHVzZUNhbGxiYWNrKChmaWx0ZXJHcm91cDogSUZpbHRlckdyb3VwLCBrZXk6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgbmV3RmlsdGVyR3JvdXAgPSB7XHJcbiAgICAgIC4uLmZpbHRlckdyb3VwLFxyXG4gICAgICBpdGVtczogZmlsdGVyR3JvdXAuaXRlbXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5rZXkgIT09IGtleSksXHJcbiAgICB9XHJcblxyXG4gICAgaGFuZGxlSXRlbXNDaGFuZ2UobmV3RmlsdGVyR3JvdXApXHJcbiAgfSwgW2hhbmRsZUl0ZW1zQ2hhbmdlXSlcclxuXHJcbiAgY29uc3QgaGFzQWN0aXZlRmlsdGVycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgaGFzQWN0aXZlRmlsdGVyc0xvY2FsID0gZmlsdGVyR3JvdXBzLnNvbWUoZmlsdGVyR3JvdXAgPT4gZmlsdGVyR3JvdXAuaXRlbXMuc29tZShpdGVtID0+IGl0ZW0pKVxyXG4gICAgcmV0dXJuIGhhc0FjdGl2ZUZpbHRlcnNMb2NhbFxyXG4gIH0sIFtmaWx0ZXJHcm91cHNdKVxyXG5cclxuICBjb25zdCBpc0Rpc2FibGVkQWRkSXRlbXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGNvdW50ID0gZmlsdGVyR3JvdXBzLnJlZHVjZSgocHJldkNvdW50LCBjdXJyZW50KSA9PiB7XHJcbiAgICAgIHJldHVybiBwcmV2Q291bnQgKyBjdXJyZW50Lml0ZW1zLmxlbmd0aFxyXG4gICAgfSwgMClcclxuXHJcbiAgICByZXR1cm4gY291bnQgPj0gTUFYX0ZJTFRFUl9HUk9VUF9MRU5HVEhcclxuICB9LCBbZmlsdGVyR3JvdXBzXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyR3JvdXBzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgc2V0RmlsdGVyR3JvdXBzKGdyb3VwcylcclxuICB9LCBbZ3JvdXBzXSlcclxuXHJcbiAgY29uc3QgZ2V0RmlsdGVyR3JvdXBCeU5hbWUgPSB1c2VDYWxsYmFjaygobmFtZTogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBzZWFyY2hlZEdyb3VwID0gZmlsdGVyR3JvdXBzLmZpbmQoZ3JvdXAgPT4gZ3JvdXAuZmlsdGVyR3JvdXBOYW1lID09PSBuYW1lKVxyXG5cclxuICAgIHJldHVybiBzZWFyY2hlZEdyb3VwXHJcbiAgfSwgW2ZpbHRlckdyb3Vwc10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVGaWx0ZXJHcm91cHMoKVxyXG4gIH0sIFtoYW5kbGVGaWx0ZXJHcm91cHNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgb25GaWx0ZXJRdWVyeUNoYW5nZShmaWx0ZXJHcm91cHMpXHJcbiAgfSwgW2ZpbHRlckdyb3Vwc10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZmlsdGVyR3JvdXBDb250ZXh0LlByb3ZpZGVyXHJcbiAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgZmlsdGVyR3JvdXBzLFxyXG4gICAgICAgIGlzRGlzYWJsZWRBZGRJdGVtcyxcclxuICAgICAgICBoYW5kbGVJdGVtc0NoYW5nZSxcclxuICAgICAgICBoYW5kbGVSZW1vdmVJdGVtLFxyXG4gICAgICAgIGdldEZpbHRlckdyb3VwQnlOYW1lLFxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8RmxleFJvd1xyXG4gICAgICAgIHZlcnRpY2FsQWxpZ249J2NlbnRlcidcclxuICAgICAgICBnYXA9ezE2fVxyXG4gICAgICAgIGNsYXNzTmFtZT17ZmlsdGVyR3JvdXBzU3R5bGVzLm9wdGlvbnN9XHJcbiAgICAgID5cclxuICAgICAgICA8RmxleFJvdyBnYXA9ezEwfSB2ZXJ0aWNhbEFsaWduPVwiY2VudGVyXCIgY2xhc3NOYW1lPXtmaWx0ZXJHcm91cHNTdHlsZXMubGF5ZXJ9PlxyXG4gICAgICAgICAgPERlZmF1bHRCdXR0b25cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtmaWx0ZXJHcm91cHNTdHlsZXMuZXllQnV0dG9ufVxyXG4gICAgICAgICAgICBpY29uUHJvcHM9e3tcclxuICAgICAgICAgICAgICBpY29uTmFtZTogaXNBY3RpdmVUcmFja2luZyA/ICghaGFzQWN0aXZlRmlsdGVycyA/ICdFeWUtdHJhY2tpbmctb2ZmJyA6ICdFeWUtdHJhY2tpbmcnKSA6ICdFeWUtdHJhY2tpbmctb2ZmJyxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFoYXNBY3RpdmVGaWx0ZXJzfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVJc0FjdGl2ZVRyYWNraW5nfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8VGV4dCBjbGFzc05hbWU9e2ZpbHRlckdyb3Vwc1N0eWxlcy5maWx0ZXJUaXRsZX0+RmlsdHJhciBwb3I6IDwvVGV4dD5cclxuXHJcbiAgICAgICAgICB7ZmlsdGVyR3JvdXBzLm1hcChncm91cCA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPEZpbHRlcklucHV0UmVuZGVyXHJcbiAgICAgICAgICAgICAgICBrZXk9e2dyb3VwLmZpbHRlckdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgIGdyb3VwTmFtZT17Z3JvdXAuZmlsdGVyR3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvRmxleFJvdz5cclxuXHJcbiAgICAgICAge2hhc0FjdGl2ZUZpbHRlcnMgJiYgaXNBY3RpdmVUcmFja2luZyAmJiAoXHJcbiAgICAgICAgICA8RmlsdGVyR3JvdXBUYWdzRGlzcGxheVxyXG4gICAgICAgICAgICBncm91cHM9e2ZpbHRlckdyb3Vwc31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9GbGV4Um93PlxyXG5cclxuICAgIDwvZmlsdGVyR3JvdXBDb250ZXh0LlByb3ZpZGVyPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgdXNlRmlsdGVyR3JvdXBzU3R5bGVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxyXG5cclxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgb3B0aW9uczoge1xyXG4gICAgICAnPiBzcGFuLm1zLWxheWVyJzoge1xyXG4gICAgICAgIGRpc3BsYXk6ICdub25lJyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBleWVCdXR0b246IHtcclxuICAgICAgbWluV2lkdGg6ICcxMnB4JyxcclxuICAgICAgcGFkZGluZzogMCxcclxuICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICcmOmRpc2FibGVkJzoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBmaWx0ZXJUaXRsZToge1xyXG4gICAgICBmb250U2l6ZTogdGhlbWUuZm9udFNpemUucDE0LFxyXG4gICAgICBmb250V2VpZ2h0OiB0aGVtZS5mb250V2VpZ2h0LnNlbWlib2xkLFxyXG4gICAgICBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgaGVpZ2h0OiAzMixcclxuICAgIH0sXHJcbiAgICBsYXllcjoge1xyXG4gICAgICAnLm1zLWxheWVyJzoge1xyXG4gICAgICAgIGRpc3BsYXk6ICdub25lJyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbWVtbyhGaWx0ZXJHcm91cClcclxuIl19