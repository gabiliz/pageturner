import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditAnalysisSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditAnalysisSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditAnalysisSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/analysis`;
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "BIDashboard",
      key: "dashboard",
      title: "Dashboard",
      name: "Dashboard",
      permission: "Auditoria",
      url: `${path}/dashboard`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Archive",
      key: "patrimonial-testing",
      title: "Testes de contas patrimoniais",
      name: "Testes de contas patrimoniais",
      permission: "Auditoria",
      url: `${path}/patrimonial-testing`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Money",
      key: "results-testing",
      title: "Testes de contas de resultados",
      name: "Testes de contas de resultados",
      permission: "Auditoria",
      url: `${path}/results-testing`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Task-list-square",
      key: "initial-balance",
      title: "Revisão dos saldos iniciais",
      name: "Revisão dos saldos iniciais",
      permission: "Auditoria",
      url: `${path}/initial-balance`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Link",
      key: "related-parts",
      title: "Partes relacionadas",
      name: "Partes relacionadas",
      permission: "Auditoria",
      url: `${path}/related-parts`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Box-inventory",
      key: "inventory",
      title: "Inventário",
      name: "Inventário",
      permission: "Auditoria",
      url: `${path}/inventory`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Checkmark-stardust",
      key: "external-confirmation",
      title: "Confirmações externas",
      name: "Confirmações externas",
      permission: "Auditoria",
      url: `${path}/external-confirmation`
    }]
  }], [disableTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Análises contábeis", subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditAnalysisSideMenu.tsx",
    lineNumber: 119,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditAnalysisSideMenu.tsx",
    lineNumber: 118,
    columnNumber: 57
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, goBack: () => navigate(`/audit/audits/${auditId}/control-panel/dashboard`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditAnalysisSideMenu.tsx",
    lineNumber: 118,
    columnNumber: 10
  }, this);
};
_s(AuditAnalysisSideMenu, "TefNqRmcBkOs1ZiqDnvdqu5QyeM=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditAnalysisSideMenu;
export default AuditAnalysisSideMenu;
var _c;
$RefreshReg$(_c, "AuditAnalysisSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditAnalysisSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMElVOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUlWLFNBQXlCQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFN0QsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsZ0NBQWdDO0FBQ3ZDLFNBQVNDLDBCQUEwQjtBQUVuQyxNQUFNQyx3QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFTLElBQUlmLFlBQVk7QUFDakMsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFjLElBQUliLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVjO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSVosU0FBUztBQUMzRCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBa0IsS0FBSztBQUVyRSxRQUFNO0FBQUEsSUFBRTBCLElBQUlDO0FBQUFBLEVBQVEsSUFBSXhCLFVBQVU7QUFFbEMsUUFBTTtBQUFBLElBQUV5QixNQUFNQztBQUFBQSxFQUFNLElBQUl0QixrQkFBa0J1QixXQUFXSCxPQUFpQjtBQUV0RSxRQUFNSSxPQUFRLGlCQUFnQko7QUFFOUIsUUFBTUssZ0JBQWlDakMsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRWtDLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsQ0FBQztBQUFBLEVBRUwsQ0FBQyxHQUNBLENBQUNULGFBQWFFLGVBQWUsQ0FBQztBQUVqQyxRQUFNbUIsZ0JBQWdCNUMsUUFBUSxNQUFNO0FBQ2xDLFVBQU02QyxnQkFBaUMsQ0FBQyxHQUFHWixhQUFhO0FBQ3hEWSxrQkFBY0MsUUFBUSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3RDSCxvQkFBY0csS0FBSyxFQUFFZCxRQUFRYSxNQUFNYixNQUFNZSxPQUFPQyxhQUFXaEMsY0FBY2dDLFFBQVFSLFlBQTRCLFlBQVksQ0FBQztBQUFBLElBQzVILENBQUM7QUFDRCxXQUFPRztBQUFBQSxFQUNULEdBQUcsQ0FBQ1osYUFBYSxDQUFDO0FBRWxCLFFBQU1rQixjQUFjbkQsUUFBUSxNQUMxQlksMkJBQTJCSyxVQUFVMkIsYUFBYSxHQUNwRCxDQUFDM0IsVUFBVTJCLGFBQWEsQ0FBQztBQUV6QixRQUFNUSxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQixVQUFJRixLQUFLcEIsT0FBTztBQUNkUiwyQkFBbUIsQ0FBQ0QsZUFBZTtBQUFBLE1BQ3JDLE9BQU87QUFDTFQsaUJBQVNzQyxLQUFLWCxHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBNUMsWUFBVSxNQUFNO0FBQ2QsVUFBTTBELGtCQUFrQjNCLE9BQU80QixTQUFTQyxLQUFLQyxhQUFXQSxRQUFRQyxxQkFBcUIsSUFBSSxFQUFFO0FBQzNGckMsbUJBQWVpQyxtQkFBbUIzQixPQUFPTSxhQUFhLENBQUM7QUFBQSxFQUN6RCxHQUFHLENBQUNOLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLHNCQUNOLFVBQ0UsdUJBQUMsUUFDQyxNQUNHLGtCQUFpQkEsT0FBT2dDLFVBQVVDLHVCQUNqQ2pDLE9BQU9nQyxVQUFVRSxzQkFDWixHQUFFbEMsT0FBT2dDLFNBQVNFLG1DQUFtQ2xDLE9BQU9nQyxVQUFVRyxtQkFDdkVuQyxPQUFPZ0MsVUFBVW5DLE1BR3pCLFFBQU8sU0FFUCxpQ0FBQyxRQUNDLFFBQVE7QUFBQSxJQUNOdUMsTUFBTTtBQUFBLE1BQ0pDLE9BQU9oRCxPQUFPaUQsS0FBSyxHQUFHO0FBQUEsTUFDdEIvQyxZQUFZQSxXQUFXZ0Q7QUFBQUEsTUFDdkIvQyxVQUFVQSxTQUFTZ0Q7QUFBQUEsTUFDbkJDLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUNwQ0ksWUFBWXBELFFBQVFxRDtBQUFBQSxNQUNwQkMsVUFBVTtBQUFBLE1BQ1ZDLGNBQWN2RCxRQUFRd0Q7QUFBQUEsTUFDdEIsV0FBVztBQUFBLFFBQ1RMLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsT0FBSyxNQUVKdEM7QUFBQUEsV0FBT2dDLFVBQVVlO0FBQUFBLElBQWE7QUFBQSxJQUFJcEUscUJBQXFCcUIsT0FBT2dDLFVBQVVHLGNBQXdCO0FBQUEsT0FqQm5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQSxHQUVGLFFBQVFyQixlQUNSLGFBQWFRLGFBQ2IsYUFDQSxRQUFRLE1BQU1wQyxTQUFVLGlCQUFnQlksaUNBQWlDLEtBckMzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUM2RTtBQUdqRjtBQUFDYixHQXpKS0QsdUJBQXlCO0FBQUEsVUFDWlgsYUFDSUQsYUFDS0csZ0JBQ3dCSyxVQUkxQk4sV0FFQUksa0JBQWtCdUIsVUFBVTtBQUFBO0FBQUErQyxLQVZoRGhFO0FBMkpOLGVBQWVBO0FBQXFCLElBQUFnRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVBlcm1pc3Npb25zIiwiTGluayIsIlNpZGVNZW51IiwiYXVkaXRRdWVyeVNlcnZpY2UiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsInVzZVRoZW1lIiwiVGV4dCIsImdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzIiwiQXVkaXRTaXR1YXRpb25FbnVtIiwiQXVkaXRBbmFseXNpc1NpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJkaXNhYmxlVGFicyIsInNldERpc2FibGVUYWJzIiwiaXNHcm91cEV4cGFuZGVkIiwic2V0SXNHcm91cEV4cGFuZGVkIiwiaWQiLCJhdWRpdElkIiwiZGF0YSIsImF1ZGl0IiwidXNlRmluZE9uZSIsInBhdGgiLCJuYXZMaW5rR3JvdXBzIiwibGlua3MiLCJkaXNhYmxlZCIsInNpdHVhY2FvIiwiQ2FuY2VsYWRvIiwiaWNvbiIsImtleSIsInRpdGxlIiwibmFtZSIsInBlcm1pc3Npb24iLCJ1cmwiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsInZlcmlmeVNpdHVhdGlvbiIsImVtcHJlc2FzIiwic29tZSIsImVtcHJlc2EiLCJzaXR1YWNhb1JldmlzYW8iLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsInJvb3QiLCJjb2xvciIsImdyYXkiLCJzZW1pYm9sZCIsInAxNCIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJtYXJnaW5MZWZ0IiwibGciLCJtYXhXaWR0aCIsIm1hcmdpbkJvdHRvbSIsIm1kIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdEFuYWx5c2lzU2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzL0F1ZGl0QW5hbHlzaXNTaWRlTWVudS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgTW91c2VFdmVudCwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJTmF2TGlua0dyb3VwLCBJTmF2TGluayB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC9saWIvTmF2J1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHNlcnZpY2VDb2RlcywgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xyXG5pbXBvcnQgeyBMaW5rLCBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBhdWRpdFF1ZXJ5U2VydmljZSB9IGZyb20gJy4uL2F1ZGl0cy9zZXJ2aWNlcydcclxuaW1wb3J0IHsgZm9ybWF0UHJvcG9zYWxOdW1iZXIgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvdXRpbHMnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MgZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzL2dldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzJ1xyXG5pbXBvcnQgeyBBdWRpdFNpdHVhdGlvbkVudW0gfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvZW51bXMvQXVkaXRTaXR1YXRpb25FbnVtJ1xyXG5cclxuY29uc3QgQXVkaXRBbmFseXNpc1NpZGVNZW51OiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXHJcbiAgY29uc3QgeyBjb2xvcnMsIHNwYWNpbmcsIGZvbnRXZWlnaHQsIGZvbnRTaXplIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgW2Rpc2FibGVUYWJzLCBzZXREaXNhYmxlVGFic10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNHcm91cEV4cGFuZGVkLCBzZXRJc0dyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXHJcblxyXG4gIGNvbnN0IHsgaWQ6IGF1ZGl0SWQgfSA9IHVzZVBhcmFtcygpXHJcblxyXG4gIGNvbnN0IHsgZGF0YTogYXVkaXQgfSA9IGF1ZGl0UXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoYXVkaXRJZCBhcyBzdHJpbmcpXHJcblxyXG4gIGNvbnN0IHBhdGggPSBgL2F1ZGl0L2F1ZGl0cy8ke2F1ZGl0SWR9L2NvbnRyb2wtcGFuZWwvYW5hbHlzaXNgXHJcblxyXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBpY29uOiAnQklEYXNoYm9hcmQnLFxyXG4gICAgICAgICAga2V5OiAnZGFzaGJvYXJkJyxcclxuICAgICAgICAgIHRpdGxlOiAnRGFzaGJvYXJkJyxcclxuICAgICAgICAgIG5hbWU6ICdEYXNoYm9hcmQnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2Rhc2hib2FyZGAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAgaWNvbjogJ0FyY2hpdmUnLFxyXG4gICAgICAgICAga2V5OiAncGF0cmltb25pYWwtdGVzdGluZycsXHJcbiAgICAgICAgICB0aXRsZTogJ1Rlc3RlcyBkZSBjb250YXMgcGF0cmltb25pYWlzJyxcclxuICAgICAgICAgIG5hbWU6ICdUZXN0ZXMgZGUgY29udGFzIHBhdHJpbW9uaWFpcycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vcGF0cmltb25pYWwtdGVzdGluZ2AsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAgaWNvbjogJ01vbmV5JyxcclxuICAgICAgICAgIGtleTogJ3Jlc3VsdHMtdGVzdGluZycsXHJcbiAgICAgICAgICB0aXRsZTogJ1Rlc3RlcyBkZSBjb250YXMgZGUgcmVzdWx0YWRvcycsXHJcbiAgICAgICAgICBuYW1lOiAnVGVzdGVzIGRlIGNvbnRhcyBkZSByZXN1bHRhZG9zJyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRofS9yZXN1bHRzLXRlc3RpbmdgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkbyxcclxuICAgICAgICAgIGljb246ICdUYXNrLWxpc3Qtc3F1YXJlJyxcclxuICAgICAgICAgIGtleTogJ2luaXRpYWwtYmFsYW5jZScsXHJcbiAgICAgICAgICB0aXRsZTogJ1Jldmlzw6NvIGRvcyBzYWxkb3MgaW5pY2lhaXMnLFxyXG4gICAgICAgICAgbmFtZTogJ1Jldmlzw6NvIGRvcyBzYWxkb3MgaW5pY2lhaXMnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L2luaXRpYWwtYmFsYW5jZWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAgaWNvbjogJ0xpbmsnLFxyXG4gICAgICAgICAga2V5OiAncmVsYXRlZC1wYXJ0cycsXHJcbiAgICAgICAgICB0aXRsZTogJ1BhcnRlcyByZWxhY2lvbmFkYXMnLFxyXG4gICAgICAgICAgbmFtZTogJ1BhcnRlcyByZWxhY2lvbmFkYXMnLFxyXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXHJcbiAgICAgICAgICB1cmw6IGAke3BhdGh9L3JlbGF0ZWQtcGFydHNgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkbyxcclxuICAgICAgICAgIGljb246ICdCb3gtaW52ZW50b3J5JyxcclxuICAgICAgICAgIGtleTogJ2ludmVudG9yeScsXHJcbiAgICAgICAgICB0aXRsZTogJ0ludmVudMOhcmlvJyxcclxuICAgICAgICAgIG5hbWU6ICdJbnZlbnTDoXJpbycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vaW52ZW50b3J5YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBpY29uOiAnQ2hlY2ttYXJrLXN0YXJkdXN0JyxcclxuICAgICAgICAgIGtleTogJ2V4dGVybmFsLWNvbmZpcm1hdGlvbicsXHJcbiAgICAgICAgICB0aXRsZTogJ0NvbmZpcm1hw6fDtWVzIGV4dGVybmFzJyxcclxuICAgICAgICAgIG5hbWU6ICdDb25maXJtYcOnw7VlcyBleHRlcm5hcycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vZXh0ZXJuYWwtY29uZmlybWF0aW9uYCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICBdLCBbZGlzYWJsZVRhYnMsIGlzR3JvdXBFeHBhbmRlZF0pXHJcblxyXG4gIGNvbnN0IHBlcm1pc3Npb25OYXYgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkR3JvdXA6IElOYXZMaW5rR3JvdXBbXSA9IFsuLi5uYXZMaW5rR3JvdXBzXVxyXG4gICAgZmlsdGVyZWRHcm91cC5mb3JFYWNoKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgZmlsdGVyZWRHcm91cFtpbmRleF0ubGlua3MgPSBncm91cC5saW5rcy5maWx0ZXIobmF2TGluayA9PiBoYXNQZXJtaXNzaW9uKG5hdkxpbmsucGVybWlzc2lvbiBhcyBzZXJ2aWNlQ29kZXMsICdWaXN1YWxpemFyJykpXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGZpbHRlcmVkR3JvdXBcclxuICB9LCBbbmF2TGlua0dyb3Vwc10pXHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkS2V5ID0gdXNlTWVtbygoKSA9PlxyXG4gICAgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MocGF0aG5hbWUsIHBlcm1pc3Npb25OYXYpLFxyXG4gIFtwYXRobmFtZSwgcGVybWlzc2lvbk5hdl0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XHJcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxyXG4gICAgICBpZiAoaXRlbS5saW5rcykge1xyXG4gICAgICAgIHNldElzR3JvdXBFeHBhbmRlZCghaXNHcm91cEV4cGFuZGVkKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdmVyaWZ5U2l0dWF0aW9uID0gYXVkaXQ/LmVtcHJlc2FzLnNvbWUoZW1wcmVzYSA9PiBlbXByZXNhLnNpdHVhY2FvUmV2aXNhbyA9PT0gKDAgfCAxKSkgYXMgYm9vbGVhblxyXG4gICAgc2V0RGlzYWJsZVRhYnModmVyaWZ5U2l0dWF0aW9uIHx8IGF1ZGl0Py5zaXR1YWNhbyA9PT0gMClcclxuICB9LCBbYXVkaXRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNpZGVNZW51XHJcbiAgICAgIHRpdGxlPSdBbsOhbGlzZXMgY29udMOhYmVpcydcclxuICAgICAgc3VidGl0bGU9e1xyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICBocmVmPXtcclxuICAgICAgICAgICAgYC9hZG1pbi9jbGllbnRzLyR7YXVkaXQ/LmNvbnRyYXRvPy5jbGllbnRlSWR9L2NvbnRyYWN0cy8ke1xyXG4gICAgICAgICAgICAgIGF1ZGl0Py5jb250cmF0bz8uY29udHJhdG9QcmluY2lwYWxJZFxyXG4gICAgICAgICAgICAgICAgPyBgJHthdWRpdD8uY29udHJhdG8uY29udHJhdG9QcmluY2lwYWxJZH0/c3ViY29udHJhY3Q9JHthdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhfWBcclxuICAgICAgICAgICAgICAgIDogYXVkaXQ/LmNvbnRyYXRvPy5pZFxyXG4gICAgICAgICAgICB9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGFyZ2V0PVwiYmxhbmtcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXHJcbiAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAyMDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXHJcbiAgICAgICAgICAgICAgICAnOjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2F1ZGl0Py5jb250cmF0bz8ubm9tZUZhbnRhc2lhfSAtIHtmb3JtYXRQcm9wb3NhbE51bWJlcihhdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhIGFzIHN0cmluZyl9XHJcbiAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICB9XHJcbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cclxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBzZWxlY3RlZEtleT17c2VsZWN0ZWRLZXl9XHJcbiAgICAgIGdvQmFjaz17KCkgPT4gbmF2aWdhdGUoYC9hdWRpdC9hdWRpdHMvJHthdWRpdElkfS9jb250cm9sLXBhbmVsL2Rhc2hib2FyZGApfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1ZGl0QW5hbHlzaXNTaWRlTWVudVxyXG4iXX0=