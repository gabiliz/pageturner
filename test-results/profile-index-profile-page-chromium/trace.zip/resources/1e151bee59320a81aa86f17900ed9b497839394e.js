import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/auth/components/UserControl.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/components/UserControl.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { UserAvatar } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
const AccountControl = () => {
  _s();
  const {
    currentAccount
  } = useAuth();
  const userControlStyles = useAccountControlStyles();
  return /* @__PURE__ */ jsxDEV("div", { className: userControlStyles.container, children: /* @__PURE__ */ jsxDEV("div", { className: userControlStyles.avatar, children: currentAccount.value?.image ? /* @__PURE__ */ jsxDEV(UserAvatar, { image: currentAccount.value?.image }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/components/UserControl.tsx",
    lineNumber: 16,
    columnNumber: 40
  }, this) : currentAccount.value?.shortName }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/components/UserControl.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/components/UserControl.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(AccountControl, "zDaodkh3IVsQH1rt2m6Hjox0UuA=", false, function() {
  return [useAuth, useAccountControlStyles];
});
_c = AccountControl;
const useAccountControlStyles = () => {
  _s2();
  const {
    colors,
    spacing,
    fontSize,
    fontWeight
  } = useTheme();
  return mergeStyleSets({
    container: {
      display: "flex",
      alignItems: "center",
      gap: spacing.sm,
      fontSize: fontSize.p14
    },
    avatar: {
      width: "40px",
      height: "40px",
      borderRadius: "50%",
      backgroundColor: colors.purple[200],
      color: colors.purple[800],
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: fontSize.h4,
      fontWeight: fontWeight.semibold,
      letterSpacing: "2px",
      lineHeight: 0
    },
    userName: {
      fontSize: fontSize.p14
    }
  });
};
_s2(useAccountControlStyles, "cEOrLAwNHai28RP6sRa9bGL1FpM=", false, function() {
  return [useTheme];
});
export default AccountControl;
var _c;
$RefreshReg$(_c, "AccountControl");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/auth/components/UserControl.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFmWixTQUFTQSxzQkFBc0I7QUFFL0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGlCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFlLElBQUlILFFBQVE7QUFFbkMsUUFBTUksb0JBQW9CQyx3QkFBd0I7QUFFbEQsU0FDRSx1QkFBQyxTQUFJLFdBQVdELGtCQUFrQkUsV0FDaEMsaUNBQUMsU0FBSSxXQUFXRixrQkFBa0JHLFFBQy9CSix5QkFBZUssT0FBT0MsUUFDbkIsdUJBQUMsY0FBVyxPQUFPTixlQUFlSyxPQUFPQyxTQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStDLElBQy9DTixlQUFlSyxPQUFPRSxhQUg1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDUixHQWRLRCxnQkFBa0I7QUFBQSxVQUNLRCxTQUVESyx1QkFBdUI7QUFBQTtBQUFBTSxLQUg3Q1Y7QUFnQk4sTUFBTUksMEJBQTBCQSxNQUFNO0FBQUFPLE1BQUE7QUFDcEMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVcsSUFBSWxCLFNBQVM7QUFFM0QsU0FBT0QsZUFBZTtBQUFBLElBQ3BCUyxXQUFXO0FBQUEsTUFDVFcsU0FBUztBQUFBLE1BQ1RDLFlBQVk7QUFBQSxNQUNaQyxLQUFLTCxRQUFRTTtBQUFBQSxNQUNiTCxVQUFVQSxTQUFTTTtBQUFBQSxJQUNyQjtBQUFBLElBQ0FkLFFBQVE7QUFBQSxNQUNOZSxPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLE1BQ1JDLGNBQWM7QUFBQSxNQUNkQyxpQkFBaUJaLE9BQU9hLE9BQU8sR0FBRztBQUFBLE1BQ2xDQyxPQUFPZCxPQUFPYSxPQUFPLEdBQUc7QUFBQSxNQUN4QlQsU0FBUztBQUFBLE1BQ1RDLFlBQVk7QUFBQSxNQUNaVSxnQkFBZ0I7QUFBQSxNQUNoQmIsVUFBVUEsU0FBU2M7QUFBQUEsTUFDbkJiLFlBQVlBLFdBQVdjO0FBQUFBLE1BQ3ZCQyxlQUFlO0FBQUEsTUFDZkMsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBQyxVQUFVO0FBQUEsTUFDUmxCLFVBQVVBLFNBQVNNO0FBQUFBLElBQ3JCO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ1QsSUE1QktQLHlCQUF1QjtBQUFBLFVBQ3VCUCxRQUFRO0FBQUE7QUE2QjVELGVBQWVHO0FBQWMsSUFBQVU7QUFBQXVCLGFBQUF2QixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJ1c2VUaGVtZSIsIlVzZXJBdmF0YXIiLCJ1c2VBdXRoIiwiQWNjb3VudENvbnRyb2wiLCJfcyIsImN1cnJlbnRBY2NvdW50IiwidXNlckNvbnRyb2xTdHlsZXMiLCJ1c2VBY2NvdW50Q29udHJvbFN0eWxlcyIsImNvbnRhaW5lciIsImF2YXRhciIsInZhbHVlIiwiaW1hZ2UiLCJzaG9ydE5hbWUiLCJfYyIsIl9zMiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsInNtIiwicDE0Iiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJjb2xvciIsImp1c3RpZnlDb250ZW50IiwiaDQiLCJzZW1pYm9sZCIsImxldHRlclNwYWNpbmciLCJsaW5lSGVpZ2h0IiwidXNlck5hbWUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQ29udHJvbC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1dGgvY29tcG9uZW50cy9Vc2VyQ29udHJvbC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9ob29rcydcbmltcG9ydCB7IFVzZXJBdmF0YXIgfSBmcm9tICcuLi8uLi9hZG1pbi91c2Vycy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL3N0b3JlL2F1dGgnXG5cbmNvbnN0IEFjY291bnRDb250cm9sOiBGQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjdXJyZW50QWNjb3VudCB9ID0gdXNlQXV0aCgpXG5cbiAgY29uc3QgdXNlckNvbnRyb2xTdHlsZXMgPSB1c2VBY2NvdW50Q29udHJvbFN0eWxlcygpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17dXNlckNvbnRyb2xTdHlsZXMuY29udGFpbmVyfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXt1c2VyQ29udHJvbFN0eWxlcy5hdmF0YXJ9PlxuICAgICAgICB7Y3VycmVudEFjY291bnQudmFsdWU/LmltYWdlXG4gICAgICAgICAgPyA8VXNlckF2YXRhciBpbWFnZT17Y3VycmVudEFjY291bnQudmFsdWU/LmltYWdlfSAvPlxuICAgICAgICAgIDogY3VycmVudEFjY291bnQudmFsdWU/LnNob3J0TmFtZX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmNvbnN0IHVzZUFjY291bnRDb250cm9sU3R5bGVzID0gKCkgPT4ge1xuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZywgZm9udFNpemUsIGZvbnRXZWlnaHQgfSA9IHVzZVRoZW1lKClcblxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xuICAgIGNvbnRhaW5lcjoge1xuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICBnYXA6IHNwYWNpbmcuc20sXG4gICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxuICAgIH0sXG4gICAgYXZhdGFyOiB7XG4gICAgICB3aWR0aDogJzQwcHgnLFxuICAgICAgaGVpZ2h0OiAnNDBweCcsXG4gICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzIwMF0sXG4gICAgICBjb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICBmb250U2l6ZTogZm9udFNpemUuaDQsXG4gICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnNlbWlib2xkLFxuICAgICAgbGV0dGVyU3BhY2luZzogJzJweCcsXG4gICAgICBsaW5lSGVpZ2h0OiAwLFxuICAgIH0sXG4gICAgdXNlck5hbWU6IHtcbiAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgQWNjb3VudENvbnRyb2xcbiJdfQ==