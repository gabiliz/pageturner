export default function(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      resolve(dataUrl);
    };
    reader.onerror = (error) => {
      reject(error);
    };
    reader.onabort = () => {
      reject(new Error());
    };
    reader.readAsDataURL(file);
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnZlcnRGaWxlVG9CYXNlNjQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKGZpbGU6IEZpbGUpOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKClcbiAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xuICAgICAgY29uc3QgZGF0YVVybCA9IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nXG4gICAgICByZXNvbHZlKGRhdGFVcmwpXG4gICAgfVxuXG4gICAgcmVhZGVyLm9uZXJyb3IgPSAoZXJyb3IpID0+IHtcbiAgICAgIHJlamVjdChlcnJvcilcbiAgICB9XG5cbiAgICByZWFkZXIub25hYm9ydCA9ICgpID0+IHtcbiAgICAgIHJlamVjdChuZXcgRXJyb3IoKSlcbiAgICB9XG5cbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKVxuICB9KVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSx3QkFBeUIsTUFBNkI7QUFDcEQsU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsVUFBTSxTQUFTLElBQUksV0FBVztBQUM5QixXQUFPLFNBQVMsTUFBTTtBQUNwQixZQUFNLFVBQVUsT0FBTztBQUN2QixjQUFRLE9BQU87QUFBQSxJQUNqQjtBQUVBLFdBQU8sVUFBVSxDQUFDLFVBQVU7QUFDMUIsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUVBLFdBQU8sVUFBVSxNQUFNO0FBQ3JCLGFBQU8sSUFBSSxNQUFNLENBQUM7QUFBQSxJQUNwQjtBQUVBLFdBQU8sY0FBYyxJQUFJO0FBQUEsRUFDM0IsQ0FBQztBQUNIOyIsIm5hbWVzIjpbXX0=