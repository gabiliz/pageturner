import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/contentPage/PageTitle.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageTitle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
const PageTitle = ({
  children,
  wrap
}) => {
  return /* @__PURE__ */ jsxDEV(Text, { variant: "xxLarge", block: true, nowrap: !wrap, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageTitle.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_c = PageTitle;
export default PageTitle;
var _c;
$RefreshReg$(_c, "PageTitle");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageTitle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7QUFUSiwyQkFBcUI7QUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU90QyxNQUFNQSxZQUFnQ0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQUssTUFBTTtBQUM1RCxTQUNFLHVCQUFDLFFBQ0MsU0FBUSxXQUNSLE9BQUssTUFDTCxRQUFRLENBQUNBLE1BRVJELFlBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0UsS0FWS0g7QUFZTixlQUFlQTtBQUFTLElBQUFHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQYWdlVGl0bGUiLCJjaGlsZHJlbiIsIndyYXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2VUaXRsZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9jb250ZW50UGFnZS9QYWdlVGl0bGUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5cbmludGVyZmFjZSBQYWdlVGl0bGVQcm9wcyB7XG4gIHdyYXA/OiBib29sZWFuXG59XG5cbmNvbnN0IFBhZ2VUaXRsZTogRkM8UGFnZVRpdGxlUHJvcHM+ID0gKHsgY2hpbGRyZW4sIHdyYXAgfSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxUZXh0XG4gICAgICB2YXJpYW50PVwieHhMYXJnZVwiXG4gICAgICBibG9ja1xuICAgICAgbm93cmFwPXshd3JhcH1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9UZXh0PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFBhZ2VUaXRsZVxuIl19