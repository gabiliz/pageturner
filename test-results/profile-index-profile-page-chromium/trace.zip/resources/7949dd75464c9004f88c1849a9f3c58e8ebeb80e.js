import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/MonthDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/MonthDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const MonthDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Mês", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione", styles: {
    root: {
      minWidth: 100
    }
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/MonthDropdown.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = MonthDropdown;
const months = [{
  key: 1,
  text: "Janeiro"
}, {
  key: 2,
  text: "Fevereiro"
}, {
  key: 3,
  text: "Março"
}, {
  key: 4,
  text: "Abril"
}, {
  key: 5,
  text: "Maio"
}, {
  key: 6,
  text: "Junho"
}, {
  key: 7,
  text: "Julho"
}, {
  key: 8,
  text: "Agosto"
}, {
  key: 9,
  text: "Setembro"
}, {
  key: 10,
  text: "Outubro"
}, {
  key: 11,
  text: "Novembro"
}, {
  key: 12,
  text: "Dezembro"
}];
export default MonthDropdown;
var _c;
$RefreshReg$(_c, "MonthDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/MonthDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7QUFUSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxnQkFBOENDLFdBQVU7QUFDNUQsU0FDRSx1QkFBQyxZQUNDLE9BQU0sT0FDTixTQUFTQyxRQUNULGVBQWUsTUFDZixjQUFhLE1BQ2IsYUFBWSxhQUNaLFFBQVE7QUFBQSxJQUNOQyxNQUFNO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQUk7QUFBQSxFQUN4QixHQUNBLEdBQUlILFNBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNZO0FBR2hCO0FBQUNJLEtBZEtMO0FBZ0JOLE1BQU1FLFNBQTRCLENBQ2hDO0FBQUEsRUFBRUksS0FBSztBQUFBLEVBQUdDLE1BQU07QUFBVSxHQUMxQjtBQUFBLEVBQUVELEtBQUs7QUFBQSxFQUFHQyxNQUFNO0FBQVksR0FDNUI7QUFBQSxFQUFFRCxLQUFLO0FBQUEsRUFBR0MsTUFBTTtBQUFRLEdBQ3hCO0FBQUEsRUFBRUQsS0FBSztBQUFBLEVBQUdDLE1BQU07QUFBUSxHQUN4QjtBQUFBLEVBQUVELEtBQUs7QUFBQSxFQUFHQyxNQUFNO0FBQU8sR0FDdkI7QUFBQSxFQUFFRCxLQUFLO0FBQUEsRUFBR0MsTUFBTTtBQUFRLEdBQ3hCO0FBQUEsRUFBRUQsS0FBSztBQUFBLEVBQUdDLE1BQU07QUFBUSxHQUN4QjtBQUFBLEVBQUVELEtBQUs7QUFBQSxFQUFHQyxNQUFNO0FBQVMsR0FDekI7QUFBQSxFQUFFRCxLQUFLO0FBQUEsRUFBR0MsTUFBTTtBQUFXLEdBQzNCO0FBQUEsRUFBRUQsS0FBSztBQUFBLEVBQUlDLE1BQU07QUFBVSxHQUMzQjtBQUFBLEVBQUVELEtBQUs7QUFBQSxFQUFJQyxNQUFNO0FBQVcsR0FDNUI7QUFBQSxFQUFFRCxLQUFLO0FBQUEsRUFBSUMsTUFBTTtBQUFXLENBQUM7QUFHL0IsZUFBZVA7QUFBYSxJQUFBSztBQUFBRyxhQUFBSCxJQUFBIiwibmFtZXMiOlsiSUNvbWJvQm94UHJvcHMiLCJDb21ib0JveCIsIk1vbnRoRHJvcGRvd24iLCJwcm9wcyIsIm1vbnRocyIsInJvb3QiLCJtaW5XaWR0aCIsIl9jIiwia2V5IiwidGV4dCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1vbnRoRHJvcGRvd24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZHJvcGRvd25zQ29tYm9Cb3hlcy9Nb250aERyb3Bkb3duLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIElDb21ib0JveE9wdGlvbixcbiAgSUNvbWJvQm94UHJvcHMsXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uL2NvbWJvQm94J1xuXG5jb25zdCBNb250aERyb3Bkb3duOiBGQzxQYXJ0aWFsPElDb21ib0JveFByb3BzPj4gPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q29tYm9Cb3hcbiAgICAgIGxhYmVsPVwiTcOqc1wiXG4gICAgICBvcHRpb25zPXttb250aHN9XG4gICAgICBhbGxvd0ZyZWVmb3JtPXt0cnVlfVxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcbiAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNpb25lXCJcbiAgICAgIHN0eWxlcz17e1xuICAgICAgICByb290OiB7IG1pbldpZHRoOiAxMDAgfSxcbiAgICAgIH19XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5jb25zdCBtb250aHM6IElDb21ib0JveE9wdGlvbltdID0gW1xuICB7IGtleTogMSwgdGV4dDogJ0phbmVpcm8nIH0sXG4gIHsga2V5OiAyLCB0ZXh0OiAnRmV2ZXJlaXJvJyB9LFxuICB7IGtleTogMywgdGV4dDogJ01hcsOnbycgfSxcbiAgeyBrZXk6IDQsIHRleHQ6ICdBYnJpbCcgfSxcbiAgeyBrZXk6IDUsIHRleHQ6ICdNYWlvJyB9LFxuICB7IGtleTogNiwgdGV4dDogJ0p1bmhvJyB9LFxuICB7IGtleTogNywgdGV4dDogJ0p1bGhvJyB9LFxuICB7IGtleTogOCwgdGV4dDogJ0Fnb3N0bycgfSxcbiAgeyBrZXk6IDksIHRleHQ6ICdTZXRlbWJybycgfSxcbiAgeyBrZXk6IDEwLCB0ZXh0OiAnT3V0dWJybycgfSxcbiAgeyBrZXk6IDExLCB0ZXh0OiAnTm92ZW1icm8nIH0sXG4gIHsga2V5OiAxMiwgdGV4dDogJ0RlemVtYnJvJyB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBNb250aERyb3Bkb3duXG4iXX0=