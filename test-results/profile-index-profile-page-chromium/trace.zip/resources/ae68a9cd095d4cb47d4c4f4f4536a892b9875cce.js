import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/charts/SimpleDonutChart.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { keyframes, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { calculatePercentage } from "/src/shared/utils/calculatePercentage.ts";
const SimpleDonutChart = ({
  percentage,
  color
}) => {
  _s();
  const styles = useStyles(color);
  return /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 36 36", className: styles.circularChart, children: [
    /* @__PURE__ */ jsxDEV("path", { className: styles.circleBg, d: "\r\n          M18 2.0845\r\n          a 15.9155 15.9155 0 0 1 0 31.831\r\n          a 15.9155 15.9155 0 0 1 0 -31.831\r\n        " }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("path", { className: styles.circle, strokeDasharray: `${percentage}, 100`, d: "\r\n          M18 2.0845\r\n          a 15.9155 15.9155 0 0 1 0 31.831\r\n          a 15.9155 15.9155 0 0 1 0 -31.831\r\n        " }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("text", { x: "18", y: "20.35", className: styles.percentage, children: calculatePercentage(percentage) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(SimpleDonutChart, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = SimpleDonutChart;
const useStyles = (color) => {
  return mergeStyleSets({
    circularChart: {
      display: "block",
      margin: "10px auto",
      maxWidth: "80%",
      minWidth: "40%",
      maxHeight: "250px"
    },
    circle: {
      stroke: color,
      fill: "none",
      strokeWidth: 1.8,
      strokeLinecap: "round",
      animation: `${progress} 1s ease-out forwards`
    },
    circleBg: {
      fill: "none",
      stroke: "#eee",
      strokeWidth: 1.8
    },
    percentage: {
      fill: "#666",
      fontFamily: "sans-serif",
      fontSize: "0.5em",
      textAnchor: "middle"
    }
  });
};
const progress = keyframes({
  "0%": {
    strokeDasharray: "0 100"
  }
});
export default SimpleDonutChart;
var _c;
$RefreshReg$(_c, "SimpleDonutChart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/charts/SimpleDonutChart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJOLFNBQVNBLFdBQVdDLHNCQUFzQjtBQUUxQyxTQUFTQywyQkFBMkI7QUFPcEMsTUFBTUMsbUJBQThDQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBWUM7QUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDN0UsUUFBTUMsU0FBU0MsVUFBVUgsS0FBSztBQUM5QixTQUNFLHVCQUFDLFNBQ0MsU0FBUSxhQUNSLFdBQVdFLE9BQU9FLGVBRWxCO0FBQUEsMkJBQUMsVUFDQyxXQUFXRixPQUFPRyxVQUNsQixHQUFFLHVJQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNRztBQUFBLElBRUgsdUJBQUMsVUFDQyxXQUFXSCxPQUFPSSxRQUNsQixpQkFBa0IsR0FBRVAsbUJBQ3BCLEdBQUUsdUlBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9HO0FBQUEsSUFFSCx1QkFBQyxVQUNDLEdBQUUsTUFDRixHQUFFLFNBQ0YsV0FBV0csT0FBT0gsWUFFakJGLDhCQUFvQkUsVUFBVSxLQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBRUo7QUFBQ0UsR0FqQ0tILGtCQUEyQztBQUFBLFVBQ2hDSyxTQUFTO0FBQUE7QUFBQUksS0FEcEJUO0FBbUNOLE1BQU1LLFlBQVlBLENBQUNILFVBQWtCO0FBQ25DLFNBQU9KLGVBQWU7QUFBQSxJQUNwQlEsZUFBZTtBQUFBLE1BQ2JJLFNBQVM7QUFBQSxNQUNUQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxNQUNWQyxXQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0FOLFFBQVE7QUFBQSxNQUNOTyxRQUFRYjtBQUFBQSxNQUNSYyxNQUFNO0FBQUEsTUFDTkMsYUFBYTtBQUFBLE1BQ2JDLGVBQWU7QUFBQSxNQUNmQyxXQUFZLEdBQUVDO0FBQUFBLElBQ2hCO0FBQUEsSUFDQWIsVUFBVTtBQUFBLE1BQ1JTLE1BQU07QUFBQSxNQUNORCxRQUFRO0FBQUEsTUFDUkUsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBaEIsWUFBWTtBQUFBLE1BQ1ZlLE1BQU07QUFBQSxNQUNOSyxZQUFZO0FBQUEsTUFDWkMsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFFQSxNQUFNSCxXQUFXdkIsVUFBVTtBQUFBLEVBQ3pCLE1BQU07QUFBQSxJQUNKMkIsaUJBQWlCO0FBQUEsRUFDbkI7QUFDRixDQUFDO0FBRUQsZUFBZXhCO0FBQWdCLElBQUFTO0FBQUFnQixhQUFBaEIsSUFBQSIsIm5hbWVzIjpbImtleWZyYW1lcyIsIm1lcmdlU3R5bGVTZXRzIiwiY2FsY3VsYXRlUGVyY2VudGFnZSIsIlNpbXBsZURvbnV0Q2hhcnQiLCJwZXJjZW50YWdlIiwiY29sb3IiLCJfcyIsInN0eWxlcyIsInVzZVN0eWxlcyIsImNpcmN1bGFyQ2hhcnQiLCJjaXJjbGVCZyIsImNpcmNsZSIsIl9jIiwiZGlzcGxheSIsIm1hcmdpbiIsIm1heFdpZHRoIiwibWluV2lkdGgiLCJtYXhIZWlnaHQiLCJzdHJva2UiLCJmaWxsIiwic3Ryb2tlV2lkdGgiLCJzdHJva2VMaW5lY2FwIiwiYW5pbWF0aW9uIiwicHJvZ3Jlc3MiLCJmb250RmFtaWx5IiwiZm9udFNpemUiLCJ0ZXh0QW5jaG9yIiwic3Ryb2tlRGFzaGFycmF5IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2ltcGxlRG9udXRDaGFydC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9jaGFydHMvU2ltcGxlRG9udXRDaGFydC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBrZXlmcmFtZXMsIG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjYWxjdWxhdGVQZXJjZW50YWdlIH0gZnJvbSAnLi4vLi4vdXRpbHMvY2FsY3VsYXRlUGVyY2VudGFnZSdcclxuXHJcbmludGVyZmFjZSBTaW1wbGVEb251dENoYXJ0UHJvcHMge1xyXG4gIHBlcmNlbnRhZ2U6IG51bWJlclxyXG4gIGNvbG9yOiBzdHJpbmdcclxufVxyXG5cclxuY29uc3QgU2ltcGxlRG9udXRDaGFydDogRkM8U2ltcGxlRG9udXRDaGFydFByb3BzPiA9ICh7IHBlcmNlbnRhZ2UsIGNvbG9yIH0pID0+IHtcclxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoY29sb3IpXHJcbiAgcmV0dXJuIChcclxuICAgIDxzdmdcclxuICAgICAgdmlld0JveD1cIjAgMCAzNiAzNlwiXHJcbiAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmNpcmN1bGFyQ2hhcnR9XHJcbiAgICA+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuY2lyY2xlQmd9XHJcbiAgICAgICAgZD1cIlxyXG4gICAgICAgICAgTTE4IDIuMDg0NVxyXG4gICAgICAgICAgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAzMS44MzFcclxuICAgICAgICAgIGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgLTMxLjgzMVxyXG4gICAgICAgIFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuY2lyY2xlfVxyXG4gICAgICAgIHN0cm9rZURhc2hhcnJheT17YCR7cGVyY2VudGFnZX0sIDEwMGB9XHJcbiAgICAgICAgZD1cIlxyXG4gICAgICAgICAgTTE4IDIuMDg0NVxyXG4gICAgICAgICAgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAzMS44MzFcclxuICAgICAgICAgIGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgLTMxLjgzMVxyXG4gICAgICAgIFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDx0ZXh0XHJcbiAgICAgICAgeD1cIjE4XCJcclxuICAgICAgICB5PVwiMjAuMzVcIlxyXG4gICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLnBlcmNlbnRhZ2V9XHJcbiAgICAgID5cclxuICAgICAgICB7Y2FsY3VsYXRlUGVyY2VudGFnZShwZXJjZW50YWdlKX1cclxuICAgICAgPC90ZXh0PlxyXG4gICAgPC9zdmc+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoY29sb3I6IHN0cmluZykgPT4ge1xyXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBjaXJjdWxhckNoYXJ0OiB7XHJcbiAgICAgIGRpc3BsYXk6ICdibG9jaycsXHJcbiAgICAgIG1hcmdpbjogJzEwcHggYXV0bycsXHJcbiAgICAgIG1heFdpZHRoOiAnODAlJyxcclxuICAgICAgbWluV2lkdGg6ICc0MCUnLFxyXG4gICAgICBtYXhIZWlnaHQ6ICcyNTBweCcsXHJcbiAgICB9LFxyXG4gICAgY2lyY2xlOiB7XHJcbiAgICAgIHN0cm9rZTogY29sb3IsXHJcbiAgICAgIGZpbGw6ICdub25lJyxcclxuICAgICAgc3Ryb2tlV2lkdGg6IDEuOCxcclxuICAgICAgc3Ryb2tlTGluZWNhcDogJ3JvdW5kJyxcclxuICAgICAgYW5pbWF0aW9uOiBgJHtwcm9ncmVzc30gMXMgZWFzZS1vdXQgZm9yd2FyZHNgLFxyXG4gICAgfSxcclxuICAgIGNpcmNsZUJnOiB7XHJcbiAgICAgIGZpbGw6ICdub25lJyxcclxuICAgICAgc3Ryb2tlOiAnI2VlZScsXHJcbiAgICAgIHN0cm9rZVdpZHRoOiAxLjgsXHJcbiAgICB9LFxyXG4gICAgcGVyY2VudGFnZToge1xyXG4gICAgICBmaWxsOiAnIzY2NicsXHJcbiAgICAgIGZvbnRGYW1pbHk6ICdzYW5zLXNlcmlmJyxcclxuICAgICAgZm9udFNpemU6ICcwLjVlbScsXHJcbiAgICAgIHRleHRBbmNob3I6ICdtaWRkbGUnLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5jb25zdCBwcm9ncmVzcyA9IGtleWZyYW1lcyh7XHJcbiAgJzAlJzoge1xyXG4gICAgc3Ryb2tlRGFzaGFycmF5OiAnMCAxMDAnLFxyXG4gIH0sXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaW1wbGVEb251dENoYXJ0XHJcbiJdfQ==