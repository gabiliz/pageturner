import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserConfirmedDisplay.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserConfirmedDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const confirmStatus = {
  true: "Confirmado",
  false: "Pendente"
};
const UserConfirmedDisplay = ({
  status
}) => {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: confirmStatus[status] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserConfirmedDisplay.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
};
_c = UserConfirmedDisplay;
export default UserConfirmedDisplay;
var _c;
$RefreshReg$(_c, "UserConfirmedDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserConfirmedDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVM7QUFSVCwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUxQixNQUFNQSxnQkFBZ0I7QUFBQSxFQUNwQkMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFDVDtBQUVBLE1BQU1DLHVCQUFpRUEsQ0FBQztBQUFBLEVBQUVDO0FBQU8sTUFBTTtBQUNyRixTQUFPLG1DQUFHSix3QkFBY0ksTUFBTSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlCO0FBQ2xDO0FBQUNDLEtBRktGO0FBSU4sZUFBZUE7QUFBb0IsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImNvbmZpcm1TdGF0dXMiLCJ0cnVlIiwiZmFsc2UiLCJVc2VyQ29uZmlybWVkRGlzcGxheSIsInN0YXR1cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlckNvbmZpcm1lZERpc3BsYXkudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi91c2Vycy9jb21wb25lbnRzL1VzZXJDb25maXJtZWREaXNwbGF5LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IGNvbmZpcm1TdGF0dXMgPSB7XG4gIHRydWU6ICdDb25maXJtYWRvJyxcbiAgZmFsc2U6ICdQZW5kZW50ZScsXG59XG5cbmNvbnN0IFVzZXJDb25maXJtZWREaXNwbGF5OiBGQzx7c3RhdHVzOiBrZXlvZiB0eXBlb2YgY29uZmlybVN0YXR1c30+ID0gKHsgc3RhdHVzIH0pID0+IHtcbiAgcmV0dXJuIDw+e2NvbmZpcm1TdGF0dXNbc3RhdHVzXX08Lz5cbn1cblxuZXhwb3J0IGRlZmF1bHQgVXNlckNvbmZpcm1lZERpc3BsYXlcbiJdfQ==