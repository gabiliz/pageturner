import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/toggle/Toggle.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/toggle/Toggle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, Toggle as SwitchButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const Toggle = (props) => {
  _s();
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV(SwitchButton, { ...props, className: styles.container }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/toggle/Toggle.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_s(Toggle, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = Toggle;
export default Toggle;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyleSets({
    container: {
      '.ms-Toggle-background[aria-checked="true"]': {
        background: colors.primary,
        ":hover": {
          background: colors.purple[800]
        }
      },
      '.ms-Toggle-background[aria-checked="false"]': {
        borderColor: colors.purple[500],
        ":hover": {
          borderColor: colors.purple[800]
        },
        ".ms-Toggle-thumb": {
          background: colors.purple[500]
        },
        ":hover .ms-Toggle-thumb": {
          borderColor: colors.purple[800]
        }
      },
      '.ms-Toggle-background[aria-checked="true"]:disabled': {
        opacity: "0.5"
      },
      '.ms-Toggle-background[aria-checked="false"]:disabled': {
        opacity: "0.5"
      }
    }
  });
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
var _c;
$RefreshReg$(_c, "Toggle");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/toggle/Toggle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFOSixTQUF1QkEsZ0JBQWdCQyxVQUFVQyxvQkFBb0I7QUFDckUsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1GLFNBQTJCRyxXQUFVO0FBQUFDLEtBQUE7QUFDekMsUUFBTUMsU0FBU0MsVUFBVTtBQUN6QixTQUNFLHVCQUFDLGdCQUFhLEdBQUlILE9BQU8sV0FBV0UsT0FBT0UsYUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxRDtBQUV6RDtBQUFDSCxHQUxLSixRQUF1QjtBQUFBLFVBQ1pNLFNBQVM7QUFBQTtBQUFBRSxLQURwQlI7QUFPTixlQUFlQTtBQUVmLE1BQU1NLFlBQVlBLE1BQU07QUFBQUcsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJUixTQUFTO0FBQzVCLFNBQU9ILGVBQWU7QUFBQSxJQUNwQlEsV0FBVztBQUFBLE1BQ1QsOENBQThDO0FBQUEsUUFDNUNJLFlBQVlELE9BQU9FO0FBQUFBLFFBQ25CLFVBQVU7QUFBQSxVQUNSRCxZQUFZRCxPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUMvQjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLCtDQUErQztBQUFBLFFBQzdDQyxhQUFhSixPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUM5QixVQUFVO0FBQUEsVUFDUkMsYUFBYUosT0FBT0csT0FBTyxHQUFHO0FBQUEsUUFDaEM7QUFBQSxRQUNBLG9CQUFvQjtBQUFBLFVBQ2xCRixZQUFZRCxPQUFPRyxPQUFPLEdBQUc7QUFBQSxRQUMvQjtBQUFBLFFBQ0EsMkJBQTJCO0FBQUEsVUFDekJDLGFBQWFKLE9BQU9HLE9BQU8sR0FBRztBQUFBLFFBQ2hDO0FBQUEsTUFDRjtBQUFBLE1BQ0EsdURBQXVEO0FBQUEsUUFDckRFLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQSx3REFBd0Q7QUFBQSxRQUN0REEsU0FBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ04sSUE5QktILFdBQVM7QUFBQSxVQUNNSixRQUFRO0FBQUE7QUFBQSxJQUFBTTtBQUFBUSxhQUFBUixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJUb2dnbGUiLCJTd2l0Y2hCdXR0b24iLCJ1c2VUaGVtZSIsInByb3BzIiwiX3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJjb250YWluZXIiLCJfYyIsIl9zMiIsImNvbG9ycyIsImJhY2tncm91bmQiLCJwcmltYXJ5IiwicHVycGxlIiwiYm9yZGVyQ29sb3IiLCJvcGFjaXR5IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVG9nZ2xlLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3RvZ2dsZS9Ub2dnbGUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSVRvZ2dsZVByb3BzLCBtZXJnZVN0eWxlU2V0cywgVG9nZ2xlIGFzIFN3aXRjaEJ1dHRvbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuXHJcbmNvbnN0IFRvZ2dsZTpGQzxJVG9nZ2xlUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuICByZXR1cm4gKFxyXG4gICAgPFN3aXRjaEJ1dHRvbiB7Li4ucHJvcHN9IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0vPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVG9nZ2xlXHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgY29udGFpbmVyOiB7XHJcbiAgICAgICcubXMtVG9nZ2xlLWJhY2tncm91bmRbYXJpYS1jaGVja2VkPVwidHJ1ZVwiXSc6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBjb2xvcnMucHJpbWFyeSxcclxuICAgICAgICAnOmhvdmVyJzoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLnB1cnBsZVs4MDBdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgICcubXMtVG9nZ2xlLWJhY2tncm91bmRbYXJpYS1jaGVja2VkPVwiZmFsc2VcIl0nOiB7XHJcbiAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5wdXJwbGVbNTAwXSxcclxuICAgICAgICAnOmhvdmVyJzoge1xyXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5wdXJwbGVbODAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICAgICcubXMtVG9nZ2xlLXRodW1iJzoge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJzpob3ZlciAubXMtVG9nZ2xlLXRodW1iJzoge1xyXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5wdXJwbGVbODAwXSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICAnLm1zLVRvZ2dsZS1iYWNrZ3JvdW5kW2FyaWEtY2hlY2tlZD1cInRydWVcIl06ZGlzYWJsZWQnOiB7XHJcbiAgICAgICAgb3BhY2l0eTogJzAuNScsXHJcbiAgICAgIH0sXHJcbiAgICAgICcubXMtVG9nZ2xlLWJhY2tncm91bmRbYXJpYS1jaGVja2VkPVwiZmFsc2VcIl06ZGlzYWJsZWQnOiB7XHJcbiAgICAgICAgb3BhY2l0eTogJzAuNScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0pXHJcbn1cclxuIl19