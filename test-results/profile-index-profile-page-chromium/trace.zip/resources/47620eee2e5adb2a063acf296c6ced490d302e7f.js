import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/ChartOfAccountsDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ChartOfAccountsDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { chartOfAccountsQueryService } from "/src/modules/admin/chartOfAccounts/services/index.ts";
import { ComboBox, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
const ChartOfAccountsDropdown = (props) => {
  _s();
  const {
    label,
    selectedKeys,
    onChange,
    styles,
    placeholder,
    disabled = false,
    companyId
  } = props;
  const {
    data
  } = chartOfAccountsQueryService.useFindAllPaginated({
    $filter: companyId ? `empresaId eq ${companyId}` : void 0
  });
  const processedCharts = useMemo(() => {
    return data?.value.filter((chart) => chart.situacao === 2);
  }, [data]);
  const options = useMemo(() => processedCharts?.map((chartOfAccounts) => ({
    key: chartOfAccounts.id,
    text: `${chartOfAccounts.descricao}`
  })) ?? [], [processedCharts]);
  const tooltipText = useCallback(() => {
    return processedCharts?.length === 0 ? "Não há planos de contas processados para esta empresa" : "";
  }, [processedCharts]);
  return /* @__PURE__ */ jsxDEV(TooltipHost, { content: tooltipText(), id: "add-flow-dropdown-tooltip", children: /* @__PURE__ */ jsxDEV(ComboBox, { label, options, placeholder, selectedKey: selectedKeys, onChange, disabled, styles, calloutProps: {
    calloutMinWidth: 80
  } }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ChartOfAccountsDropdown.tsx",
    lineNumber: 43,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ChartOfAccountsDropdown.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(ChartOfAccountsDropdown, "lK8BNEtyNvMYwH2MdtxwNwMRxCY=", false, function() {
  return [chartOfAccountsQueryService.useFindAllPaginated];
});
_c = ChartOfAccountsDropdown;
export default ChartOfAccountsDropdown;
var _c;
$RefreshReg$(_c, "ChartOfAccountsDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ChartOfAccountsDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEROLFNBQWFBLGFBQWFDLGVBQWU7QUFDekMsU0FBU0MsbUNBQW1DO0FBRTVDLFNBQVNDLFVBQVVDLG1CQUFtQjtBQVl0QyxNQUFNQywwQkFBNkRDLFdBQVU7QUFBQUMsS0FBQTtBQUMzRSxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsV0FBVztBQUFBLElBQ1hDO0FBQUFBLEVBQ0YsSUFBSVI7QUFFSixRQUFNO0FBQUEsSUFBRVM7QUFBQUEsRUFBSyxJQUFJYiw0QkFBNEJjLG9CQUFvQjtBQUFBLElBQUVDLFNBQVNILFlBQWEsZ0JBQWVBLGNBQWNJO0FBQUFBLEVBQVUsQ0FBQztBQUVqSSxRQUFNQyxrQkFBa0JsQixRQUFRLE1BQU07QUFDcEMsV0FBT2MsTUFBTUssTUFBTUMsT0FBT0MsV0FBU0EsTUFBTUMsYUFBYSxDQUFDO0FBQUEsRUFDekQsR0FBRyxDQUFDUixJQUFJLENBQUM7QUFFVCxRQUFNUyxVQUFVdkIsUUFDZCxNQUFNa0IsaUJBQWlCTSxJQUFJQyxzQkFBb0I7QUFBQSxJQUM3Q0MsS0FBS0QsZ0JBQWdCRTtBQUFBQSxJQUNyQkMsTUFBTyxHQUFFSCxnQkFBZ0JJO0FBQUFBLEVBQzNCLEVBQUUsS0FBSyxJQUNQLENBQUNYLGVBQWUsQ0FDbEI7QUFDQSxRQUFNWSxjQUFjL0IsWUFBWSxNQUFNO0FBQ3BDLFdBQU9tQixpQkFBaUJhLFdBQVcsSUFDL0IsMERBQ0E7QUFBQSxFQUNOLEdBQUcsQ0FBQ2IsZUFBZSxDQUFDO0FBRXBCLFNBQ0UsdUJBQUMsZUFDQyxTQUFTWSxZQUFZLEdBQ3JCLElBQUcsNkJBRUgsaUNBQUMsWUFDQyxPQUNBLFNBQ0EsYUFDQSxhQUFhdEIsY0FDYixVQUNBLFVBQ0EsUUFDQSxjQUFjO0FBQUEsSUFDWndCLGlCQUFpQjtBQUFBLEVBQ25CLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVJLEtBZE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUMxQixHQWpES0YseUJBQXlEO0FBQUEsVUFXNUNILDRCQUE0QmMsbUJBQW1CO0FBQUE7QUFBQWtCLEtBWDVEN0I7QUFtRE4sZUFBZUE7QUFBdUIsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZU1lbW8iLCJjaGFydE9mQWNjb3VudHNRdWVyeVNlcnZpY2UiLCJDb21ib0JveCIsIlRvb2x0aXBIb3N0IiwiQ2hhcnRPZkFjY291bnRzRHJvcGRvd24iLCJwcm9wcyIsIl9zIiwibGFiZWwiLCJzZWxlY3RlZEtleXMiLCJvbkNoYW5nZSIsInN0eWxlcyIsInBsYWNlaG9sZGVyIiwiZGlzYWJsZWQiLCJjb21wYW55SWQiLCJkYXRhIiwidXNlRmluZEFsbFBhZ2luYXRlZCIsIiRmaWx0ZXIiLCJ1bmRlZmluZWQiLCJwcm9jZXNzZWRDaGFydHMiLCJ2YWx1ZSIsImZpbHRlciIsImNoYXJ0Iiwic2l0dWFjYW8iLCJvcHRpb25zIiwibWFwIiwiY2hhcnRPZkFjY291bnRzIiwia2V5IiwiaWQiLCJ0ZXh0IiwiZGVzY3JpY2FvIiwidG9vbHRpcFRleHQiLCJsZW5ndGgiLCJjYWxsb3V0TWluV2lkdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNoYXJ0T2ZBY2NvdW50c0Ryb3Bkb3duLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2Ryb3Bkb3duc0NvbWJvQm94ZXMvQ2hhcnRPZkFjY291bnRzRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbWJvQm94U3R5bGVzLCBJRHJvcGRvd25PcHRpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjaGFydE9mQWNjb3VudHNRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2FkbWluL2NoYXJ0T2ZBY2NvdW50cy9zZXJ2aWNlcydcclxuaW1wb3J0IENoYXJ0T2ZBY2NvdW50cyBmcm9tICcuLi8uLi8uLi9kb21haW4vQ2hhcnRPZkFjY291bnRzJ1xyXG5pbXBvcnQgeyBDb21ib0JveCwgVG9vbHRpcEhvc3QgfSBmcm9tICcuLidcclxuXHJcbmludGVyZmFjZSBDaGFydE9mQWNjb3VudHNEcm9wZG93blByb3BzIHtcclxuICBsYWJlbD86IHN0cmluZ1xyXG4gIGNvbXBhbnlJZDogc3RyaW5nXHJcbiAgc2VsZWN0ZWRLZXlzPzogc3RyaW5nfHN0cmluZ1tdXHJcbiAgZGlzYWJsZWQ/OiBib29sZWFuXHJcbiAgcGxhY2Vob2xkZXI6IHN0cmluZ1xyXG4gIG9uQ2hhbmdlOiAoZXZlbnQ6IHVua25vd24sIG9wdGlvbj86IElEcm9wZG93bk9wdGlvbjxDaGFydE9mQWNjb3VudHM+LCBpbmRleD86IG51bWJlcikgPT4gdm9pZFxyXG4gIHN0eWxlcz86IFBhcnRpYWw8SUNvbWJvQm94U3R5bGVzPlxyXG59XHJcblxyXG5jb25zdCBDaGFydE9mQWNjb3VudHNEcm9wZG93bjogRkM8Q2hhcnRPZkFjY291bnRzRHJvcGRvd25Qcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBsYWJlbCxcclxuICAgIHNlbGVjdGVkS2V5cyxcclxuICAgIG9uQ2hhbmdlLFxyXG4gICAgc3R5bGVzLFxyXG4gICAgcGxhY2Vob2xkZXIsXHJcbiAgICBkaXNhYmxlZCA9IGZhbHNlLFxyXG4gICAgY29tcGFueUlkLFxyXG4gIH0gPSBwcm9wc1xyXG5cclxuICBjb25zdCB7IGRhdGEgfSA9IGNoYXJ0T2ZBY2NvdW50c1F1ZXJ5U2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKHsgJGZpbHRlcjogY29tcGFueUlkID8gYGVtcHJlc2FJZCBlcSAke2NvbXBhbnlJZH1gIDogdW5kZWZpbmVkIH0pXHJcblxyXG4gIGNvbnN0IHByb2Nlc3NlZENoYXJ0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGRhdGE/LnZhbHVlLmZpbHRlcihjaGFydCA9PiBjaGFydC5zaXR1YWNhbyA9PT0gMilcclxuICB9LCBbZGF0YV0pXHJcblxyXG4gIGNvbnN0IG9wdGlvbnMgPSB1c2VNZW1vPElEcm9wZG93bk9wdGlvbltdPihcclxuICAgICgpID0+IHByb2Nlc3NlZENoYXJ0cz8ubWFwKGNoYXJ0T2ZBY2NvdW50cyA9PiAoe1xyXG4gICAgICBrZXk6IGNoYXJ0T2ZBY2NvdW50cy5pZCBhcyBzdHJpbmcsXHJcbiAgICAgIHRleHQ6IGAke2NoYXJ0T2ZBY2NvdW50cy5kZXNjcmljYW99YCxcclxuICAgIH0pKSA/PyBbXSxcclxuICAgIFtwcm9jZXNzZWRDaGFydHNdLFxyXG4gIClcclxuICBjb25zdCB0b29sdGlwVGV4dCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIHJldHVybiBwcm9jZXNzZWRDaGFydHM/Lmxlbmd0aCA9PT0gMFxyXG4gICAgICA/ICdOw6NvIGjDoSBwbGFub3MgZGUgY29udGFzIHByb2Nlc3NhZG9zIHBhcmEgZXN0YSBlbXByZXNhJ1xyXG4gICAgICA6ICcnXHJcbiAgfSwgW3Byb2Nlc3NlZENoYXJ0c10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8VG9vbHRpcEhvc3RcclxuICAgICAgY29udGVudD17dG9vbHRpcFRleHQoKX1cclxuICAgICAgaWQ9J2FkZC1mbG93LWRyb3Bkb3duLXRvb2x0aXAnXHJcbiAgICA+XHJcbiAgICAgIDxDb21ib0JveFxyXG4gICAgICAgIGxhYmVsPXtsYWJlbH1cclxuICAgICAgICBvcHRpb25zPXtvcHRpb25zfVxyXG4gICAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cclxuICAgICAgICBzZWxlY3RlZEtleT17c2VsZWN0ZWRLZXlzfVxyXG4gICAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX1cclxuICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XHJcbiAgICAgICAgc3R5bGVzPXtzdHlsZXN9XHJcbiAgICAgICAgY2FsbG91dFByb3BzPXt7XHJcbiAgICAgICAgICBjYWxsb3V0TWluV2lkdGg6IDgwLFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hhcnRPZkFjY291bnRzRHJvcGRvd25cclxuIl19