import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/ComplexityDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ComplexityDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ComplexityEnum } from "/src/shared/enums/ComplexityEnum.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const ComplexityDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Complexidade", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione a complexidade", styles: {
    root: {
      minWidth: 100
    }
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ComplexityDropdown.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = ComplexityDropdown;
const months = [{
  key: ComplexityEnum.BAIXA,
  text: "Baixa"
}, {
  key: ComplexityEnum.MEDIA,
  text: "Média"
}, {
  key: ComplexityEnum.ALTA,
  text: "Alta"
}];
export default ComplexityDropdown;
var _c;
$RefreshReg$(_c, "ComplexityDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/ComplexityDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMscUJBQW1EQyxXQUFVO0FBQ2pFLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLGdCQUNOLFNBQVNDLFFBQ1QsZUFBZSxNQUNmLGNBQWEsTUFDYixhQUFZLDRCQUNaLFFBQVE7QUFBQSxJQUNOQyxNQUFNO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQUk7QUFBQSxFQUN4QixHQUNBLEdBQUlILFNBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNZO0FBR2hCO0FBQUNJLEtBZEtMO0FBZ0JOLE1BQU1FLFNBQTRCLENBQ2hDO0FBQUEsRUFBRUksS0FBS1IsZUFBZVM7QUFBQUEsRUFBT0MsTUFBTTtBQUFRLEdBQzNDO0FBQUEsRUFBRUYsS0FBS1IsZUFBZVc7QUFBQUEsRUFBT0QsTUFBTTtBQUFRLEdBQzNDO0FBQUEsRUFBRUYsS0FBS1IsZUFBZVk7QUFBQUEsRUFBTUYsTUFBTTtBQUFPLENBQUM7QUFHNUMsZUFBZVI7QUFBa0IsSUFBQUs7QUFBQU0sYUFBQU4sSUFBQSIsIm5hbWVzIjpbIklDb21ib0JveFByb3BzIiwiQ29tcGxleGl0eUVudW0iLCJDb21ib0JveCIsIkNvbXBsZXhpdHlEcm9wZG93biIsInByb3BzIiwibW9udGhzIiwicm9vdCIsIm1pbldpZHRoIiwiX2MiLCJrZXkiLCJCQUlYQSIsInRleHQiLCJNRURJQSIsIkFMVEEiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb21wbGV4aXR5RHJvcGRvd24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZHJvcGRvd25zQ29tYm9Cb3hlcy9Db21wbGV4aXR5RHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgSUNvbWJvQm94T3B0aW9uLFxuICBJQ29tYm9Cb3hQcm9wcyxcbn0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENvbXBsZXhpdHlFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvQ29tcGxleGl0eUVudW0nXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uL2NvbWJvQm94J1xuXG5jb25zdCBDb21wbGV4aXR5RHJvcGRvd246IEZDPFBhcnRpYWw8SUNvbWJvQm94UHJvcHM+PiA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxDb21ib0JveFxuICAgICAgbGFiZWw9XCJDb21wbGV4aWRhZGVcIlxuICAgICAgb3B0aW9ucz17bW9udGhzfVxuICAgICAgYWxsb3dGcmVlZm9ybT17dHJ1ZX1cbiAgICAgIGF1dG9Db21wbGV0ZT0nb24nXG4gICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjaW9uZSBhIGNvbXBsZXhpZGFkZVwiXG4gICAgICBzdHlsZXM9e3tcbiAgICAgICAgcm9vdDogeyBtaW5XaWR0aDogMTAwIH0sXG4gICAgICB9fVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgbW9udGhzOiBJQ29tYm9Cb3hPcHRpb25bXSA9IFtcbiAgeyBrZXk6IENvbXBsZXhpdHlFbnVtLkJBSVhBLCB0ZXh0OiAnQmFpeGEnIH0sXG4gIHsga2V5OiBDb21wbGV4aXR5RW51bS5NRURJQSwgdGV4dDogJ03DqWRpYScgfSxcbiAgeyBrZXk6IENvbXBsZXhpdHlFbnVtLkFMVEEsIHRleHQ6ICdBbHRhJyB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBDb21wbGV4aXR5RHJvcGRvd25cbiJdfQ==