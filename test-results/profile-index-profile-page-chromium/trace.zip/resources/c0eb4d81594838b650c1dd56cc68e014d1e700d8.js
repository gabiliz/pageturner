import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/CompanySizeDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/CompanySizeDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { CompanySizeEnum } from "/src/shared/enums/CompanySizeEnum.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const CompanySizeDropdown = (props) => {
  return /* @__PURE__ */ jsxDEV(ComboBox, { label: "Porte da empresa", options: months, allowFreeform: true, autoComplete: "on", placeholder: "Selecione o porte da empresa", styles: {
    root: {
      minWidth: 100
    }
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/CompanySizeDropdown.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = CompanySizeDropdown;
const months = [{
  key: CompanySizeEnum.GRANDE,
  text: "Grande"
}, {
  key: CompanySizeEnum.PEQUENO,
  text: "Pequena"
}];
export default CompanySizeDropdown;
var _c;
$RefreshReg$(_c, "CompanySizeDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/CompanySizeDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSiwyQkFFRUE7QUFBYyxJQUNUO0FBQUEsSUFBaUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXhCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsc0JBQW9EQyxXQUFVO0FBQ2xFLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLG9CQUNOLFNBQVNDLFFBQ1QsZUFBZSxNQUNmLGNBQWEsTUFDYixhQUFZLGdDQUNaLFFBQVE7QUFBQSxJQUNOQyxNQUFNO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQUk7QUFBQSxFQUN4QixHQUNBLEdBQUlILFNBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNZO0FBR2hCO0FBQUNJLEtBZEtMO0FBZ0JOLE1BQU1FLFNBQTRCLENBQ2hDO0FBQUEsRUFBRUksS0FBS1IsZ0JBQWdCUztBQUFBQSxFQUFRQyxNQUFNO0FBQVMsR0FDOUM7QUFBQSxFQUFFRixLQUFLUixnQkFBZ0JXO0FBQUFBLEVBQVNELE1BQU07QUFBVSxDQUFDO0FBR25ELGVBQWVSO0FBQW1CLElBQUFLO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJJQ29tYm9Cb3hQcm9wcyIsIkNvbXBhbnlTaXplRW51bSIsIkNvbWJvQm94IiwiQ29tcGFueVNpemVEcm9wZG93biIsInByb3BzIiwibW9udGhzIiwicm9vdCIsIm1pbldpZHRoIiwiX2MiLCJrZXkiLCJHUkFOREUiLCJ0ZXh0IiwiUEVRVUVOTyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbXBhbnlTaXplRHJvcGRvd24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZHJvcGRvd25zQ29tYm9Cb3hlcy9Db21wYW55U2l6ZURyb3Bkb3duLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgSUNvbWJvQm94T3B0aW9uLFxyXG4gIElDb21ib0JveFByb3BzLFxyXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgQ29tcGFueVNpemVFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvQ29tcGFueVNpemVFbnVtJ1xyXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uL2NvbWJvQm94J1xyXG5cclxuY29uc3QgQ29tcGFueVNpemVEcm9wZG93bjogRkM8UGFydGlhbDxJQ29tYm9Cb3hQcm9wcz4+ID0gKHByb3BzKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDb21ib0JveFxyXG4gICAgICBsYWJlbD1cIlBvcnRlIGRhIGVtcHJlc2FcIlxyXG4gICAgICBvcHRpb25zPXttb250aHN9XHJcbiAgICAgIGFsbG93RnJlZWZvcm09e3RydWV9XHJcbiAgICAgIGF1dG9Db21wbGV0ZT0nb24nXHJcbiAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNpb25lIG8gcG9ydGUgZGEgZW1wcmVzYVwiXHJcbiAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgIHJvb3Q6IHsgbWluV2lkdGg6IDEwMCB9LFxyXG4gICAgICB9fVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgbW9udGhzOiBJQ29tYm9Cb3hPcHRpb25bXSA9IFtcclxuICB7IGtleTogQ29tcGFueVNpemVFbnVtLkdSQU5ERSwgdGV4dDogJ0dyYW5kZScgfSxcclxuICB7IGtleTogQ29tcGFueVNpemVFbnVtLlBFUVVFTk8sIHRleHQ6ICdQZXF1ZW5hJyB9LFxyXG5dXHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21wYW55U2l6ZURyb3Bkb3duXHJcbiJdfQ==