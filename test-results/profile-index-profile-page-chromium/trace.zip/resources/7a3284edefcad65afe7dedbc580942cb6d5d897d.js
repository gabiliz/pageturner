import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/AcceptTermsModal.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Text, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { Link, Modal, PrimaryButton, DefaultButton, Checkbox } from "/src/shared/components/index.ts?t=1701096626433";
import { contractService } from "/src/modules/admin/contracts/services/index.ts";
import { ConfidentialityTermsDisplay, IndependenceTermsDisplay } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
const AcceptTermsModal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    onAccept,
    onReject,
    contractId
  } = props;
  const styles = useStyles();
  const [independenceTerms, {
    toggle: toggleIndependenceTerms,
    setTrue: setIndependenceTerms
  }] = useBoolean(false);
  const [confidentialityTerms, {
    toggle: toggleConfidentialityTerms,
    setTrue: setConfidentialityTerms
  }] = useBoolean(false);
  const [independenceTermsVisible, {
    toggle: toggleIndependenceTermsVisible
  }] = useBoolean(false);
  const [confidentialityTermsVisible, {
    toggle: toggleConfidentialityTermsVisible
  }] = useBoolean(false);
  const modalTitle = useMemo(() => {
    if (independenceTermsVisible) {
      return "Termos de independência";
    }
    if (confidentialityTermsVisible) {
      return "Termos de confidencialidade";
    }
    return "Termos de independência e confidencialidade";
  }, [independenceTermsVisible, confidentialityTermsVisible]);
  const reject = useCallback(async () => {
    await contractService.acceptTerms({
      contratoId: contractId,
      aceito: false,
      termoConfidencialidade: false,
      termoIndependencia: false
    });
    onReject();
  }, [contractId]);
  const accept = useCallback(async () => {
    await contractService.acceptTerms({
      contratoId: contractId,
      aceito: true,
      termoConfidencialidade: true,
      termoIndependencia: true
    });
    onAccept();
  }, [contractId]);
  return /* @__PURE__ */ jsxDEV(Modal, { isOpen, onDismiss, title: modalTitle, children: [
    !independenceTermsVisible && !confidentialityTermsVisible && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Text, { className: styles.paragraph, children: "Para continuar a auditoria verifique e aceite os termos de independência e confidencialidade." }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
        lineNumber: 68,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.checkboxes, children: [
        /* @__PURE__ */ jsxDEV(Checkbox, { disabled: !independenceTerms, onRenderLabel: () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
          "Declaro que li e aceito os ",
          /* @__PURE__ */ jsxDEV(Link, { onClick: toggleIndependenceTermsVisible, children: "termos de independência" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
            lineNumber: 74,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 72,
          columnNumber: 70
        }, this), checked: independenceTerms, onChange: toggleIndependenceTerms }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 72,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { disabled: !confidentialityTerms, onRenderLabel: () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
          "Declaro que li e aceito os ",
          /* @__PURE__ */ jsxDEV(Link, { onClick: toggleConfidentialityTermsVisible, children: "termos de confidencialidade" }, void 0, false, {
            fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 78,
          columnNumber: 73
        }, this), checked: confidentialityTerms, onChange: toggleConfidentialityTerms }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 78,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
        lineNumber: 71,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: styles.actions, children: [
        /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Rejeitar", onClick: reject }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 86,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Aceitar", onClick: accept, disabled: !independenceTerms || !confidentialityTerms }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
          lineNumber: 87,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
        lineNumber: 85,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
      lineNumber: 67,
      columnNumber: 67
    }, this),
    independenceTermsVisible && /* @__PURE__ */ jsxDEV(IndependenceTermsDisplay, { setIndependenceTerms, toggleIndependenceTermsVisible }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
      lineNumber: 90,
      columnNumber: 34
    }, this),
    confidentialityTermsVisible && /* @__PURE__ */ jsxDEV(ConfidentialityTermsDisplay, { toggleConfidentialityTermsVisible, setConfidentialityTerms }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
      lineNumber: 91,
      columnNumber: 37
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx",
    lineNumber: 66,
    columnNumber: 10
  }, this);
};
_s(AcceptTermsModal, "aM3mIoY+c3c4tfjsuuej3tn4z4A=", false, function() {
  return [useStyles, useBoolean, useBoolean, useBoolean, useBoolean];
});
_c = AcceptTermsModal;
const useStyles = () => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    paragraph: {
      color: colors.gray[600],
      display: "block",
      marginBottom: spacing.lg,
      selectors: {
        "&:last-of-type": {
          marginBottom: spacing.xxl
        }
      }
    },
    checkboxes: {
      marginBottom: spacing.xxl,
      selectors: {
        "& > :not(:last-child)": {
          marginBottom: spacing.lg
        }
      }
    },
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
export default AcceptTermsModal;
var _c;
$RefreshReg$(_c, "AcceptTermsModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/AcceptTermsModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZNLFNBTXlCLFVBTnpCOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEZOLFNBQWFBLGFBQWFDLGVBQWU7QUFDekMsU0FBU0MsTUFBTUMsc0JBQXNCO0FBQ3JDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxNQUFNQyxPQUFtQkMsZUFBZUMsZUFBZUMsZ0JBQWdCO0FBQ2hGLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyw2QkFBNkJDLGdDQUFnQztBQUN0RSxTQUFTQyxnQkFBZ0I7QUFVekIsTUFBTUMsbUJBQStDQyxXQUFVO0FBQUFDLEtBQUE7QUFDN0QsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVdDO0FBQUFBLElBQVVDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVcsSUFBSU47QUFDOUQsUUFBTU8sU0FBU0MsVUFBVTtBQUV6QixRQUFNLENBQ0pDLG1CQUNBO0FBQUEsSUFDRUMsUUFBUUM7QUFBQUEsSUFDUkMsU0FBU0M7QUFBQUEsRUFDWCxDQUFDLElBQ0N4QixXQUFXLEtBQUs7QUFFcEIsUUFBTSxDQUNKeUIsc0JBQ0E7QUFBQSxJQUNFSixRQUFRSztBQUFBQSxJQUNSSCxTQUFTSTtBQUFBQSxFQUNYLENBQUMsSUFDQzNCLFdBQVcsS0FBSztBQUVwQixRQUFNLENBQ0o0QiwwQkFDQTtBQUFBLElBQUVQLFFBQVFRO0FBQUFBLEVBQStCLENBQUMsSUFDeEM3QixXQUFXLEtBQUs7QUFFcEIsUUFBTSxDQUNKOEIsNkJBQ0E7QUFBQSxJQUFFVCxRQUFRVTtBQUFBQSxFQUFrQyxDQUFDLElBQzNDL0IsV0FBVyxLQUFLO0FBRXBCLFFBQU1nQyxhQUFhbkMsUUFBZ0IsTUFBTTtBQUN2QyxRQUFJK0IsMEJBQTBCO0FBQzVCLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSUUsNkJBQTZCO0FBQy9CLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1QsR0FBRyxDQUFDRiwwQkFBMEJFLDJCQUEyQixDQUFDO0FBRTFELFFBQU1HLFNBQVNyQyxZQUFZLFlBQVk7QUFDckMsVUFBTVUsZ0JBQWdCNEIsWUFBWTtBQUFBLE1BQ2hDQyxZQUFZbEI7QUFBQUEsTUFDWm1CLFFBQVE7QUFBQSxNQUNSQyx3QkFBd0I7QUFBQSxNQUN4QkMsb0JBQW9CO0FBQUEsSUFDdEIsQ0FBQztBQUNEdEIsYUFBUztBQUFBLEVBQ1gsR0FBRyxDQUFDQyxVQUFVLENBQUM7QUFFZixRQUFNc0IsU0FBUzNDLFlBQVksWUFBWTtBQUNyQyxVQUFNVSxnQkFBZ0I0QixZQUFZO0FBQUEsTUFDaENDLFlBQVlsQjtBQUFBQSxNQUNabUIsUUFBUTtBQUFBLE1BQ1JDLHdCQUF3QjtBQUFBLE1BQ3hCQyxvQkFBb0I7QUFBQSxJQUN0QixDQUFDO0FBQ0R2QixhQUFTO0FBQUEsRUFDWCxHQUFHLENBQUNFLFVBQVUsQ0FBQztBQUVmLFNBQU8sdUJBQUMsU0FDTixRQUNBLFdBQ0EsT0FBT2UsWUFFTjtBQUFBLEtBQUNKLDRCQUE0QixDQUFDRSwrQkFBK0IsbUNBQzVEO0FBQUEsNkJBQUMsUUFBSyxXQUFXWixPQUFPc0IsV0FBVSw2R0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVd0QixPQUFPdUIsWUFDckI7QUFBQSwrQkFBQyxZQUNDLFVBQVUsQ0FBQ3JCLG1CQUNYLGVBQWUsTUFBTTtBQUFBO0FBQUEsVUFFbkIsdUJBQUMsUUFBSyxTQUFTUyxnQ0FBK0IsdUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUptQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3JCLEdBQ0EsU0FBU1QsbUJBQ1QsVUFBVUUsMkJBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNvQztBQUFBLFFBRXBDLHVCQUFDLFlBQ0MsVUFBVSxDQUFDRyxzQkFDWCxlQUFlLE1BQU07QUFBQTtBQUFBLFVBRW5CLHVCQUFDLFFBQUssU0FBU00sbUNBQWtDLDJDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKbUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtyQixHQUNBLFNBQVNOLHNCQUNULFVBQVVDLDhCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTdUM7QUFBQSxXQXJCekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFXUixPQUFPd0IsU0FDckI7QUFBQSwrQkFBQyxpQkFDQyxNQUFPLFlBQ1AsU0FBV1QsVUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRW9CO0FBQUEsUUFFcEIsdUJBQUMsaUJBQ0MsTUFBTyxXQUNQLFNBQVdNLFFBQ1gsVUFDRSxDQUFDbkIscUJBQ0QsQ0FBQ0ssd0JBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1HO0FBQUEsV0FYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXpDNEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDOUQ7QUFBQSxJQUNDRyw0QkFBNEIsdUJBQUMsNEJBQzVCLHNCQUNBLGtDQUYyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRW9DO0FBQUEsSUFFaEVFLCtCQUErQix1QkFBQywrQkFDL0IsbUNBQ0EsMkJBRjhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFbUI7QUFBQSxPQXREOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdEUDtBQUNGO0FBQUNsQixHQXZIS0Ysa0JBQTJDO0FBQUEsVUFFaENTLFdBUVhuQixZQVFBQSxZQUtBQSxZQUtBQSxVQUFVO0FBQUE7QUFBQTJDLEtBNUJWakM7QUF5SE4sTUFBTVMsWUFBWUEsTUFBTTtBQUFBeUIsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBU0M7QUFBQUEsRUFBTyxJQUFJckMsU0FBUztBQUVyQyxTQUFPVixlQUFlO0FBQUEsSUFDcEJ5QyxXQUFXO0FBQUEsTUFDVE8sT0FBT0QsT0FBT0UsS0FBSyxHQUFHO0FBQUEsTUFDdEJDLFNBQVM7QUFBQSxNQUNUQyxjQUFjTCxRQUFRTTtBQUFBQSxNQUN0QkMsV0FBVztBQUFBLFFBQ1Qsa0JBQWtCO0FBQUEsVUFDaEJGLGNBQWNMLFFBQVFRO0FBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBWixZQUFZO0FBQUEsTUFDVlMsY0FBY0wsUUFBUVE7QUFBQUEsTUFDdEJELFdBQVc7QUFBQSxRQUNULHlCQUF5QjtBQUFBLFVBQ3ZCRixjQUFjTCxRQUFRTTtBQUFBQSxRQUN4QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQVQsU0FBUztBQUFBLE1BQ1BPLFNBQVM7QUFBQSxNQUNUSyxnQkFBZ0I7QUFBQSxNQUNoQkYsV0FBVztBQUFBLFFBQ1QseUJBQXlCO0FBQUEsVUFDdkJHLGFBQWFWLFFBQVFNO0FBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDUCxJQWhDS3pCLFdBQVM7QUFBQSxVQUNlVixRQUFRO0FBQUE7QUFpQ3RDLGVBQWVDO0FBQWdCLElBQUFpQztBQUFBYSxhQUFBYixJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VNZW1vIiwiVGV4dCIsIm1lcmdlU3R5bGVTZXRzIiwidXNlQm9vbGVhbiIsIkxpbmsiLCJNb2RhbCIsIlByaW1hcnlCdXR0b24iLCJEZWZhdWx0QnV0dG9uIiwiQ2hlY2tib3giLCJjb250cmFjdFNlcnZpY2UiLCJDb25maWRlbnRpYWxpdHlUZXJtc0Rpc3BsYXkiLCJJbmRlcGVuZGVuY2VUZXJtc0Rpc3BsYXkiLCJ1c2VUaGVtZSIsIkFjY2VwdFRlcm1zTW9kYWwiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwib25BY2NlcHQiLCJvblJlamVjdCIsImNvbnRyYWN0SWQiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJpbmRlcGVuZGVuY2VUZXJtcyIsInRvZ2dsZSIsInRvZ2dsZUluZGVwZW5kZW5jZVRlcm1zIiwic2V0VHJ1ZSIsInNldEluZGVwZW5kZW5jZVRlcm1zIiwiY29uZmlkZW50aWFsaXR5VGVybXMiLCJ0b2dnbGVDb25maWRlbnRpYWxpdHlUZXJtcyIsInNldENvbmZpZGVudGlhbGl0eVRlcm1zIiwiaW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlIiwidG9nZ2xlSW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlIiwiY29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlIiwidG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlIiwibW9kYWxUaXRsZSIsInJlamVjdCIsImFjY2VwdFRlcm1zIiwiY29udHJhdG9JZCIsImFjZWl0byIsInRlcm1vQ29uZmlkZW5jaWFsaWRhZGUiLCJ0ZXJtb0luZGVwZW5kZW5jaWEiLCJhY2NlcHQiLCJwYXJhZ3JhcGgiLCJjaGVja2JveGVzIiwiYWN0aW9ucyIsIl9jIiwiX3MyIiwic3BhY2luZyIsImNvbG9ycyIsImNvbG9yIiwiZ3JheSIsImRpc3BsYXkiLCJtYXJnaW5Cb3R0b20iLCJsZyIsInNlbGVjdG9ycyIsInh4bCIsImp1c3RpZnlDb250ZW50IiwibWFyZ2luUmlnaHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBY2NlcHRUZXJtc01vZGFsLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL2NvbXBvbmVudHMvQWNjZXB0VGVybXNNb2RhbC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlQ2FsbGJhY2ssIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFRleHQsIG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IExpbmssIE1vZGFsLCBNb2RhbFByb3BzLCBQcmltYXJ5QnV0dG9uLCBEZWZhdWx0QnV0dG9uLCBDaGVja2JveCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgY29udHJhY3RTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5pbXBvcnQgeyBDb25maWRlbnRpYWxpdHlUZXJtc0Rpc3BsYXksIEluZGVwZW5kZW5jZVRlcm1zRGlzcGxheSB9IGZyb20gJy4nXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcbmludGVyZmFjZSBBY2NlcHRUZXJtc01vZGFsUHJvcHMgZXh0ZW5kcyBQaWNrPFxuTW9kYWxQcm9wcyxcbidpc09wZW4nfCdvbkRpc21pc3MnXG4+IHtcbiAgY29udHJhY3RJZDogc3RyaW5nXG4gIG9uUmVqZWN0OiAoKSA9PiB2b2lkXG4gIG9uQWNjZXB0OiAoKSA9PiB2b2lkXG59XG5cbmNvbnN0IEFjY2VwdFRlcm1zTW9kYWw6IEZDPEFjY2VwdFRlcm1zTW9kYWxQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBpc09wZW4sIG9uRGlzbWlzcywgb25BY2NlcHQsIG9uUmVqZWN0LCBjb250cmFjdElkIH0gPSBwcm9wc1xuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoKVxuXG4gIGNvbnN0IFtcbiAgICBpbmRlcGVuZGVuY2VUZXJtcyxcbiAgICB7XG4gICAgICB0b2dnbGU6IHRvZ2dsZUluZGVwZW5kZW5jZVRlcm1zLFxuICAgICAgc2V0VHJ1ZTogc2V0SW5kZXBlbmRlbmNlVGVybXMsXG4gICAgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG5cbiAgY29uc3QgW1xuICAgIGNvbmZpZGVudGlhbGl0eVRlcm1zLFxuICAgIHtcbiAgICAgIHRvZ2dsZTogdG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXMsXG4gICAgICBzZXRUcnVlOiBzZXRDb25maWRlbnRpYWxpdHlUZXJtcyxcbiAgICB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcblxuICBjb25zdCBbXG4gICAgaW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlLFxuICAgIHsgdG9nZ2xlOiB0b2dnbGVJbmRlcGVuZGVuY2VUZXJtc1Zpc2libGUgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG5cbiAgY29uc3QgW1xuICAgIGNvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZSxcbiAgICB7IHRvZ2dsZTogdG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlIH0sXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxuXG4gIGNvbnN0IG1vZGFsVGl0bGUgPSB1c2VNZW1vPHN0cmluZz4oKCkgPT4ge1xuICAgIGlmIChpbmRlcGVuZGVuY2VUZXJtc1Zpc2libGUpIHtcbiAgICAgIHJldHVybiAnVGVybW9zIGRlIGluZGVwZW5kw6puY2lhJ1xuICAgIH1cblxuICAgIGlmIChjb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGUpIHtcbiAgICAgIHJldHVybiAnVGVybW9zIGRlIGNvbmZpZGVuY2lhbGlkYWRlJ1xuICAgIH1cblxuICAgIHJldHVybiAnVGVybW9zIGRlIGluZGVwZW5kw6puY2lhIGUgY29uZmlkZW5jaWFsaWRhZGUnXG4gIH0sIFtpbmRlcGVuZGVuY2VUZXJtc1Zpc2libGUsIGNvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZV0pXG5cbiAgY29uc3QgcmVqZWN0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNvbnRyYWN0U2VydmljZS5hY2NlcHRUZXJtcyh7XG4gICAgICBjb250cmF0b0lkOiBjb250cmFjdElkLFxuICAgICAgYWNlaXRvOiBmYWxzZSxcbiAgICAgIHRlcm1vQ29uZmlkZW5jaWFsaWRhZGU6IGZhbHNlLFxuICAgICAgdGVybW9JbmRlcGVuZGVuY2lhOiBmYWxzZSxcbiAgICB9KVxuICAgIG9uUmVqZWN0KClcbiAgfSwgW2NvbnRyYWN0SWRdKVxuXG4gIGNvbnN0IGFjY2VwdCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjb250cmFjdFNlcnZpY2UuYWNjZXB0VGVybXMoe1xuICAgICAgY29udHJhdG9JZDogY29udHJhY3RJZCxcbiAgICAgIGFjZWl0bzogdHJ1ZSxcbiAgICAgIHRlcm1vQ29uZmlkZW5jaWFsaWRhZGU6IHRydWUsXG4gICAgICB0ZXJtb0luZGVwZW5kZW5jaWE6IHRydWUsXG4gICAgfSlcbiAgICBvbkFjY2VwdCgpXG4gIH0sIFtjb250cmFjdElkXSlcblxuICByZXR1cm4gPE1vZGFsXG4gICAgaXNPcGVuPXtpc09wZW59XG4gICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XG4gICAgdGl0bGU9e21vZGFsVGl0bGV9XG4gID5cbiAgICB7IWluZGVwZW5kZW5jZVRlcm1zVmlzaWJsZSAmJiAhY29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlICYmIDw+XG4gICAgICA8VGV4dCBjbGFzc05hbWU9e3N0eWxlcy5wYXJhZ3JhcGh9PlxuICAgICAgICBQYXJhIGNvbnRpbnVhciBhIGF1ZGl0b3JpYSB2ZXJpZmlxdWUgZSBhY2VpdGUgb3MgdGVybW9zIGRlIGluZGVwZW5kw6puY2lhIGUgY29uZmlkZW5jaWFsaWRhZGUuXG4gICAgICA8L1RleHQ+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNoZWNrYm94ZXN9PlxuICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICBkaXNhYmxlZD17IWluZGVwZW5kZW5jZVRlcm1zfVxuICAgICAgICAgIG9uUmVuZGVyTGFiZWw9eygpID0+IDw+XG4gICAgICAgICAgICBEZWNsYXJvIHF1ZSBsaSBlIGFjZWl0byBvcyZuYnNwO1xuICAgICAgICAgICAgPExpbmsgb25DbGljaz17dG9nZ2xlSW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlfT5cbiAgICAgICAgICAgICAgdGVybW9zIGRlIGluZGVwZW5kw6puY2lhXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC8+fVxuICAgICAgICAgIGNoZWNrZWQ9e2luZGVwZW5kZW5jZVRlcm1zfVxuICAgICAgICAgIG9uQ2hhbmdlPXt0b2dnbGVJbmRlcGVuZGVuY2VUZXJtc31cbiAgICAgICAgLz5cbiAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgZGlzYWJsZWQ9eyFjb25maWRlbnRpYWxpdHlUZXJtc31cbiAgICAgICAgICBvblJlbmRlckxhYmVsPXsoKSA9PiA8PlxuICAgICAgICAgICAgRGVjbGFybyBxdWUgbGkgZSBhY2VpdG8gb3MmbmJzcDtcbiAgICAgICAgICAgIDxMaW5rIG9uQ2xpY2s9e3RvZ2dsZUNvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZX0+XG4gICAgICAgICAgICAgIHRlcm1vcyBkZSBjb25maWRlbmNpYWxpZGFkZVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvPn1cbiAgICAgICAgICBjaGVja2VkPXtjb25maWRlbnRpYWxpdHlUZXJtc31cbiAgICAgICAgICBvbkNoYW5nZT17dG9nZ2xlQ29uZmlkZW50aWFsaXR5VGVybXN9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYWN0aW9uc30+XG4gICAgICAgIDxEZWZhdWx0QnV0dG9uXG4gICAgICAgICAgdGV4dCA9IFwiUmVqZWl0YXJcIlxuICAgICAgICAgIG9uQ2xpY2sgPSB7cmVqZWN0fVxuICAgICAgICAvPlxuICAgICAgICA8UHJpbWFyeUJ1dHRvblxuICAgICAgICAgIHRleHQgPSBcIkFjZWl0YXJcIlxuICAgICAgICAgIG9uQ2xpY2sgPSB7YWNjZXB0fVxuICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICFpbmRlcGVuZGVuY2VUZXJtcyB8fFxuICAgICAgICAgICAgIWNvbmZpZGVudGlhbGl0eVRlcm1zXG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgPC8+fVxuICAgIHtpbmRlcGVuZGVuY2VUZXJtc1Zpc2libGUgJiYgPEluZGVwZW5kZW5jZVRlcm1zRGlzcGxheVxuICAgICAgc2V0SW5kZXBlbmRlbmNlVGVybXM9e3NldEluZGVwZW5kZW5jZVRlcm1zfVxuICAgICAgdG9nZ2xlSW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlPXt0b2dnbGVJbmRlcGVuZGVuY2VUZXJtc1Zpc2libGV9XG4gICAgLz59XG4gICAge2NvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZSAmJiA8Q29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5XG4gICAgICB0b2dnbGVDb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGU9e3RvZ2dsZUNvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZX1cbiAgICAgIHNldENvbmZpZGVudGlhbGl0eVRlcm1zPXtzZXRDb25maWRlbnRpYWxpdHlUZXJtc31cbiAgICAvPn1cbiAgPC9Nb2RhbD5cbn1cblxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xuICBjb25zdCB7IHNwYWNpbmcsIGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XG4gICAgcGFyYWdyYXBoOiB7XG4gICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcbiAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubGcsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJyY6bGFzdC1vZi10eXBlJzoge1xuICAgICAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy54eGwsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgY2hlY2tib3hlczoge1xuICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLnh4bCxcbiAgICAgIHNlbGVjdG9yczoge1xuICAgICAgICAnJiA+IDpub3QoOmxhc3QtY2hpbGQpJzoge1xuICAgICAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy5sZyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhY3Rpb25zOiB7XG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtZW5kJyxcbiAgICAgIHNlbGVjdG9yczoge1xuICAgICAgICAnJiA+IDpub3QoOmxhc3QtY2hpbGQpJzoge1xuICAgICAgICAgIG1hcmdpblJpZ2h0OiBzcGFjaW5nLmxnLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBBY2NlcHRUZXJtc01vZGFsXG4iXX0=