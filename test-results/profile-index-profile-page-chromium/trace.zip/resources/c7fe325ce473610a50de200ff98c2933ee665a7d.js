export var AuditApprovalSituationEnum = /* @__PURE__ */ ((AuditApprovalSituationEnum2) => {
  AuditApprovalSituationEnum2[AuditApprovalSituationEnum2["PENDING"] = 0] = "PENDING";
  AuditApprovalSituationEnum2[AuditApprovalSituationEnum2["IN_PROGRESS"] = 1] = "IN_PROGRESS";
  AuditApprovalSituationEnum2[AuditApprovalSituationEnum2["FINISHED"] = 2] = "FINISHED";
  AuditApprovalSituationEnum2[AuditApprovalSituationEnum2["ERROR"] = 3] = "ERROR";
  return AuditApprovalSituationEnum2;
})(AuditApprovalSituationEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkF1ZGl0QXBwcm92YWxTaXR1YXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0ge1xuICBQRU5ESU5HLFxuICBJTl9QUk9HUkVTUyxcbiAgRklOSVNIRUQsXG4gIEVSUk9SLFxufVxuIl0sIm1hcHBpbmdzIjoiQUFBTyxXQUFLLDZCQUFMLGtCQUFLQSxnQ0FBTDtBQUNMLEVBQUFBLHdEQUFBO0FBQ0EsRUFBQUEsd0RBQUE7QUFDQSxFQUFBQSx3REFBQTtBQUNBLEVBQUFBLHdEQUFBO0FBSlUsU0FBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbIkF1ZGl0QXBwcm92YWxTaXR1YXRpb25FbnVtIl19