import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/inputs/ChatMessageInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport4_react["useState"];
import { IconButton, PersonaGeneral } from "/src/shared/components/index.ts?t=1701096626433";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexItem, FlexRow } from "/src/shared/components/FlexBox/index.ts";
import { RichTextEditor } from "/src/shared/components/richTextEditor/index.ts?t=1701096626433";
import { generateJSON } from "/node_modules/.vite/deps/@tiptap_react.js?v=9f90a7ff";
import { StarterKit } from "/node_modules/.vite/deps/@tiptap_starter-kit.js?v=9f90a7ff";
import { getShortName } from "/src/shared/utils/getShortName.ts";
const MESSAGE_LIMIT = 8e3;
const INPUT_MIN_HEIGHT = "2rem";
const ChatMessageInput = (props) => {
  _s();
  const {
    onSend,
    onFocus,
    onChangeMessage,
    disableSend,
    value,
    hasEnter
  } = props;
  const styles = useStyles();
  const {
    spacing
  } = useTheme();
  const {
    currentAccount
  } = useAuth();
  const [, setContent] = useState(null);
  const handleChangeOutput = (content) => {
    setContent(content);
    const justifyJSON = content ? generateJSON(content, [StarterKit]) : null;
    const message = justifyJSON ? JSON.stringify(justifyJSON) : "";
    onChangeMessage(message);
  };
  return /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", wrap: "nowrap", gap: spacing.md, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(PersonaGeneral, { size: "24px", image: currentAccount.value?.image, shortName: getShortName(currentAccount.value?.nome) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, styles: {
      overflow: "hidden"
    }, children: /* @__PURE__ */ jsxDEV(RichTextEditor, { content: value, placeholder: "Responder", limit: MESSAGE_LIMIT, onFocus, onBlur: onFocus, onChangeOutput: handleChangeOutput, onCrlShiftEnter: hasEnter && !disableSend ? onSend : void 0, minHeight: INPUT_MIN_HEIGHT, onRenderSuffix: () => /* @__PURE__ */ jsxDEV(IconButton, { hint: hasEnter ? "pressione (Cmd/Crtl + Shift + Enter) para enviar" : void 0, disabled: disableSend, styles: styles.iconStyles, iconProps: {
      iconName: "Send-Message"
    }, onClick: onSend }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
      lineNumber: 54,
      columnNumber: 273
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
};
_s(ChatMessageInput, "J2u1fJNSOVNzcQupzhHXf6ckJYM=", false, function() {
  return [useStyles, useTheme, useAuth];
});
_c = ChatMessageInput;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  const inputStyles = {
    root: {
      ".ms-TextField-fieldGroup": {
        border: "none",
        borderRadius: "4px"
      }
    },
    suffix: {
      background: "transparent",
      cursor: "pointer",
      "::hover": {
        fill: colors.purple[500]
      }
    }
  };
  const iconStyles = mergeStyleSets({
    root: {
      background: "transparent",
      fill: colors.purple[300],
      ":hover": {
        fill: colors.purple[500]
      },
      ":active": {
        fill: colors.purple[500]
      }
    }
  });
  return {
    inputStyles,
    iconStyles
  };
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default ChatMessageInput;
var _c;
$RefreshReg$(_c, "ChatMessageInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/inputs/ChatMessageInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURROzs7Ozs7Ozs7Ozs7Ozs7O0FBakRSLFNBQTJCQSxzQkFBc0I7QUFDakQsU0FBYUMsZ0JBQWdCO0FBQzdCLFNBQVNDLFlBQVlDLHNCQUFzQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxVQUFVQyxlQUFlO0FBQ2xDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUErQkMsb0JBQW9CO0FBQ25ELFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFXN0IsTUFBTUMsZ0JBQWdCO0FBQ3RCLE1BQU1DLG1CQUFtQjtBQUV6QixNQUFNQyxtQkFBK0NDLFdBQVU7QUFBQUMsS0FBQTtBQUM3RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBaUJDO0FBQUFBLElBQWFDO0FBQUFBLElBQU9DO0FBQUFBLEVBQVMsSUFBSVA7QUFDM0UsUUFBTVEsU0FBU0MsVUFBVTtBQUN6QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBUSxJQUFJcEIsU0FBUztBQUM3QixRQUFNO0FBQUEsSUFBRXFCO0FBQUFBLEVBQWUsSUFBSXRCLFFBQVE7QUFDbkMsUUFBTSxHQUFHdUIsVUFBVSxJQUFJMUIsU0FBa0IsSUFBSTtBQUU3QyxRQUFNMkIscUJBQXFCQSxDQUFDQyxZQUFxQjtBQUMvQ0YsZUFBV0UsT0FBTztBQUVsQixVQUFNQyxjQUFjRCxVQUNoQnBCLGFBQWFvQixTQUF3QixDQUFDbkIsVUFBVSxDQUFDLElBQ2pEO0FBRUosVUFBTXFCLFVBQVVELGNBQWNFLEtBQUtDLFVBQVVILFdBQVcsSUFBSTtBQUU1RFgsb0JBQWdCWSxPQUFPO0FBQUEsRUFDekI7QUFFQSxTQUNFLHVCQUFDLFdBQ0MsZUFBYyxVQUNkLE1BQUssVUFDTCxLQUFLTixRQUFRUyxJQUViO0FBQUEsMkJBQUMsWUFDQyxpQ0FBQyxrQkFDQyxNQUFNLFFBQ04sT0FBT1IsZUFBZUwsT0FBT2MsT0FDN0IsV0FBV3hCLGFBQWFlLGVBQWVMLE9BQU9lLElBQWMsS0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdnRSxLQUpsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFlBQVMsTUFBTSxHQUFHLFFBQVE7QUFBQSxNQUFFQyxVQUFVO0FBQUEsSUFBUyxHQUM5QyxpQ0FBQyxrQkFDQyxTQUFTaEIsT0FDVCxhQUFZLGFBQ1osT0FBT1QsZUFDUCxTQUNBLFFBQVFNLFNBQ1IsZ0JBQWdCVSxvQkFDaEIsaUJBQ0dOLFlBQVksQ0FBQ0YsY0FDVkgsU0FDQXFCLFFBRU4sV0FBV3pCLGtCQUNYLGdCQUFnQixNQUFNLHVCQUFDLGNBQ3JCLE1BQU1TLFdBQ0YscURBQ0FnQixRQUVKLFVBQVVsQixhQUNWLFFBQVFHLE9BQU9nQixZQUNmLFdBQVc7QUFBQSxNQUFFQyxVQUFVO0FBQUEsSUFBZSxHQUN0QyxTQUFTdkIsVUFSVztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUosS0FyQnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkssS0F2QlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDRCxHQTVES0Ysa0JBQTJDO0FBQUEsVUFFaENVLFdBQ0tuQixVQUNPRCxPQUFPO0FBQUE7QUFBQXFDLEtBSjlCM0I7QUE4RE4sTUFBTVUsWUFBWUEsTUFBTTtBQUFBa0IsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJdEMsU0FBUztBQUM1QixRQUFNdUMsY0FBeUM7QUFBQSxJQUM3Q0MsTUFBTTtBQUFBLE1BQ0osNEJBQTRCO0FBQUEsUUFDMUJDLFFBQVE7QUFBQSxRQUNSQyxjQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQUMsUUFBUTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxRQUFRO0FBQUEsTUFDUixXQUFXO0FBQUEsUUFDVEMsTUFBTVIsT0FBT1MsT0FBTyxHQUFHO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU1iLGFBQWF2QyxlQUFlO0FBQUEsSUFDaEM2QyxNQUFNO0FBQUEsTUFDSkksWUFBWTtBQUFBLE1BQ1pFLE1BQU1SLE9BQU9TLE9BQU8sR0FBRztBQUFBLE1BQ3ZCLFVBQVU7QUFBQSxRQUNSRCxNQUFNUixPQUFPUyxPQUFPLEdBQUc7QUFBQSxNQUN6QjtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1RELE1BQU1SLE9BQU9TLE9BQU8sR0FBRztBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNELFNBQU87QUFBQSxJQUFFUjtBQUFBQSxJQUFhTDtBQUFBQSxFQUFXO0FBQ25DO0FBQUNHLElBOUJLbEIsV0FBUztBQUFBLFVBQ01uQixRQUFRO0FBQUE7QUErQjdCLGVBQWVTO0FBQWdCLElBQUEyQjtBQUFBWSxhQUFBWixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJ1c2VTdGF0ZSIsIkljb25CdXR0b24iLCJQZXJzb25hR2VuZXJhbCIsInVzZUF1dGgiLCJ1c2VUaGVtZSIsIkZsZXhJdGVtIiwiRmxleFJvdyIsIlJpY2hUZXh0RWRpdG9yIiwiZ2VuZXJhdGVKU09OIiwiU3RhcnRlcktpdCIsImdldFNob3J0TmFtZSIsIk1FU1NBR0VfTElNSVQiLCJJTlBVVF9NSU5fSEVJR0hUIiwiQ2hhdE1lc3NhZ2VJbnB1dCIsInByb3BzIiwiX3MiLCJvblNlbmQiLCJvbkZvY3VzIiwib25DaGFuZ2VNZXNzYWdlIiwiZGlzYWJsZVNlbmQiLCJ2YWx1ZSIsImhhc0VudGVyIiwic3R5bGVzIiwidXNlU3R5bGVzIiwic3BhY2luZyIsImN1cnJlbnRBY2NvdW50Iiwic2V0Q29udGVudCIsImhhbmRsZUNoYW5nZU91dHB1dCIsImNvbnRlbnQiLCJqdXN0aWZ5SlNPTiIsIm1lc3NhZ2UiLCJKU09OIiwic3RyaW5naWZ5IiwibWQiLCJpbWFnZSIsIm5vbWUiLCJvdmVyZmxvdyIsInVuZGVmaW5lZCIsImljb25TdHlsZXMiLCJpY29uTmFtZSIsIl9jIiwiX3MyIiwiY29sb3JzIiwiaW5wdXRTdHlsZXMiLCJyb290IiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwic3VmZml4IiwiYmFja2dyb3VuZCIsImN1cnNvciIsImZpbGwiLCJwdXJwbGUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDaGF0TWVzc2FnZUlucHV0LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2lucHV0cy9DaGF0TWVzc2FnZUlucHV0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElUZXh0RmllbGRTdHlsZXMsIG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSWNvbkJ1dHRvbiwgUGVyc29uYUdlbmVyYWwgfSBmcm9tICcuLidcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL21vZHVsZXMvYXV0aC9zdG9yZS9hdXRoJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xyXG5pbXBvcnQgeyBGbGV4SXRlbSwgRmxleFJvdyB9IGZyb20gJy4uL0ZsZXhCb3gnXHJcbmltcG9ydCB7IFJpY2hUZXh0RWRpdG9yIH0gZnJvbSAnLi4vcmljaFRleHRFZGl0b3InXHJcbmltcG9ydCB7IENvbnRlbnQsIEhUTUxDb250ZW50LCBnZW5lcmF0ZUpTT04gfSBmcm9tICdAdGlwdGFwL3JlYWN0J1xyXG5pbXBvcnQgeyBTdGFydGVyS2l0IH0gZnJvbSAnQHRpcHRhcC9zdGFydGVyLWtpdCdcclxuaW1wb3J0IHsgZ2V0U2hvcnROYW1lIH0gZnJvbSAnLi4vLi4vdXRpbHMvZ2V0U2hvcnROYW1lJ1xyXG5cclxuaW50ZXJmYWNlIENoYXRNZXNzYWdlSW5wdXRQcm9wcyB7XHJcbiAgb25Gb2N1cz86ICgpID0+IHZvaWRcclxuICBkaXNhYmxlU2VuZD86IGJvb2xlYW5cclxuICBvblNlbmQ6ICgpID0+IHZvaWRcclxuICB2YWx1ZTogc3RyaW5nXHJcbiAgaGFzRW50ZXI/OiBib29sZWFuXHJcbiAgb25DaGFuZ2VNZXNzYWdlOiAoY29udGVudDogc3RyaW5nKSA9PiB2b2lkIHwgdW5kZWZpbmVkXHJcbn1cclxuXHJcbmNvbnN0IE1FU1NBR0VfTElNSVQgPSA4MDAwXHJcbmNvbnN0IElOUFVUX01JTl9IRUlHSFQgPSAnMnJlbSdcclxuXHJcbmNvbnN0IENoYXRNZXNzYWdlSW5wdXQ6IEZDPENoYXRNZXNzYWdlSW5wdXRQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IG9uU2VuZCwgb25Gb2N1cywgb25DaGFuZ2VNZXNzYWdlLCBkaXNhYmxlU2VuZCwgdmFsdWUsIGhhc0VudGVyIH0gPSBwcm9wc1xyXG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcygpXHJcbiAgY29uc3QgeyBzcGFjaW5nIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgeyBjdXJyZW50QWNjb3VudCB9ID0gdXNlQXV0aCgpXHJcbiAgY29uc3QgWywgc2V0Q29udGVudF0gPSB1c2VTdGF0ZTxDb250ZW50PihudWxsKVxyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VPdXRwdXQgPSAoY29udGVudDogQ29udGVudCkgPT4ge1xyXG4gICAgc2V0Q29udGVudChjb250ZW50KVxyXG5cclxuICAgIGNvbnN0IGp1c3RpZnlKU09OID0gY29udGVudFxyXG4gICAgICA/IGdlbmVyYXRlSlNPTihjb250ZW50IGFzIEhUTUxDb250ZW50LCBbU3RhcnRlcktpdF0pXHJcbiAgICAgIDogbnVsbFxyXG5cclxuICAgIGNvbnN0IG1lc3NhZ2UgPSBqdXN0aWZ5SlNPTiA/IEpTT04uc3RyaW5naWZ5KGp1c3RpZnlKU09OKSA6ICcnXHJcblxyXG4gICAgb25DaGFuZ2VNZXNzYWdlKG1lc3NhZ2UpXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEZsZXhSb3dcclxuICAgICAgdmVydGljYWxBbGlnbj0nY2VudGVyJ1xyXG4gICAgICB3cmFwPSdub3dyYXAnXHJcbiAgICAgIGdhcD17c3BhY2luZy5tZH1cclxuICAgID5cclxuICAgICAgPEZsZXhJdGVtPlxyXG4gICAgICAgIDxQZXJzb25hR2VuZXJhbFxyXG4gICAgICAgICAgc2l6ZT17JzI0cHgnfVxyXG4gICAgICAgICAgaW1hZ2U9e2N1cnJlbnRBY2NvdW50LnZhbHVlPy5pbWFnZSBhcyBzdHJpbmd9XHJcbiAgICAgICAgICBzaG9ydE5hbWU9e2dldFNob3J0TmFtZShjdXJyZW50QWNjb3VudC52YWx1ZT8ubm9tZSBhcyBzdHJpbmcpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgIDxGbGV4SXRlbSBncm93PXsxfSBzdHlsZXM9e3sgb3ZlcmZsb3c6ICdoaWRkZW4nIH19PlxyXG4gICAgICAgIDxSaWNoVGV4dEVkaXRvclxyXG4gICAgICAgICAgY29udGVudD17dmFsdWV9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj0nUmVzcG9uZGVyJ1xyXG4gICAgICAgICAgbGltaXQ9e01FU1NBR0VfTElNSVR9XHJcbiAgICAgICAgICBvbkZvY3VzPXtvbkZvY3VzfVxyXG4gICAgICAgICAgb25CbHVyPXtvbkZvY3VzfVxyXG4gICAgICAgICAgb25DaGFuZ2VPdXRwdXQ9e2hhbmRsZUNoYW5nZU91dHB1dH1cclxuICAgICAgICAgIG9uQ3JsU2hpZnRFbnRlcj17XHJcbiAgICAgICAgICAgIChoYXNFbnRlciAmJiAhZGlzYWJsZVNlbmQpXHJcbiAgICAgICAgICAgICAgPyBvblNlbmRcclxuICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgbWluSGVpZ2h0PXtJTlBVVF9NSU5fSEVJR0hUfVxyXG4gICAgICAgICAgb25SZW5kZXJTdWZmaXg9eygpID0+IDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIGhpbnQ9e2hhc0VudGVyXHJcbiAgICAgICAgICAgICAgPyAncHJlc3Npb25lIChDbWQvQ3J0bCArIFNoaWZ0ICsgRW50ZXIpIHBhcmEgZW52aWFyJ1xyXG4gICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVTZW5kfVxyXG4gICAgICAgICAgICBzdHlsZXM9e3N0eWxlcy5pY29uU3R5bGVzfVxyXG4gICAgICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdTZW5kLU1lc3NhZ2UnIH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uU2VuZH1cclxuICAgICAgICAgIC8+fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICA8L0ZsZXhSb3c+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBpbnB1dFN0eWxlczogUGFydGlhbDxJVGV4dEZpZWxkU3R5bGVzPiA9IHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgJy5tcy1UZXh0RmllbGQtZmllbGRHcm91cCc6IHtcclxuICAgICAgICBib3JkZXI6ICdub25lJyxcclxuICAgICAgICBib3JkZXJSYWRpdXM6ICc0cHgnLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHN1ZmZpeDoge1xyXG4gICAgICBiYWNrZ3JvdW5kOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICBjdXJzb3I6ICdwb2ludGVyJyxcclxuICAgICAgJzo6aG92ZXInOiB7XHJcbiAgICAgICAgZmlsbDogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9XHJcbiAgY29uc3QgaWNvblN0eWxlcyA9IG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgYmFja2dyb3VuZDogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgZmlsbDogY29sb3JzLnB1cnBsZVszMDBdLFxyXG4gICAgICAnOmhvdmVyJzoge1xyXG4gICAgICAgIGZpbGw6IGNvbG9ycy5wdXJwbGVbNTAwXSxcclxuICAgICAgfSxcclxuICAgICAgJzphY3RpdmUnOiB7XHJcbiAgICAgICAgZmlsbDogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG4gIHJldHVybiB7IGlucHV0U3R5bGVzLCBpY29uU3R5bGVzIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hhdE1lc3NhZ2VJbnB1dFxyXG4iXX0=