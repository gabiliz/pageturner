import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/breadcrumb/BreadCrumb.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const Fragment = __vite__cjsImport3_react["Fragment"];
import { Icon, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { Link } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
const BreadCrumb = ({
  items
}) => {
  _s();
  const {
    spacing
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: spacing.md, children: items.map((item, index) => item?.label && /* @__PURE__ */ jsxDEV(Fragment, { children: [
    index > 0 && /* @__PURE__ */ jsxDEV(Icon, { iconName: "ChevronRight" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
      lineNumber: 20,
      columnNumber: 25
    }, this),
    item.url ? /* @__PURE__ */ jsxDEV(Link, { href: item.url, children: /* @__PURE__ */ jsxDEV(Text, { block: true, nowrap: true, styles: {
      root: {
        maxWidth: 200
      }
    }, children: item.label }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
      lineNumber: 22,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
      lineNumber: 21,
      columnNumber: 23
    }, this) : /* @__PURE__ */ jsxDEV(Text, { block: true, nowrap: true, styles: {
      root: {
        maxWidth: 200
      }
    }, children: item.label }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
      lineNumber: 29,
      columnNumber: 23
    }, this)
  ] }, index, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
    lineNumber: 19,
    columnNumber: 50
  }, this)) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(BreadCrumb, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
_c = BreadCrumb;
export default BreadCrumb;
var _c;
$RefreshReg$(_c, "BreadCrumb");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/breadcrumb/BreadCrumb.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0J3Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXRCeEIsU0FBYUEsZ0JBQWdCO0FBQzdCLFNBQVNDLE1BQU1DLFlBQVk7QUFDM0IsU0FBU0MsWUFBWTtBQUVyQixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsYUFBYTtBQU1wQixNQUFNQyxhQUFrQ0EsQ0FBQztBQUFBLEVBQUVDO0FBQU0sTUFBTTtBQUFBQyxLQUFBO0FBQ3JELFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFRLElBQUlMLFNBQVM7QUFFN0IsU0FDRSx1QkFBQyxXQUNDLGVBQWMsVUFDZCxLQUFLSyxRQUFRQyxJQUVaSCxnQkFBTUksSUFBSSxDQUFDQyxNQUFNQyxVQUNoQkQsTUFBTUUsU0FDTix1QkFBQyxZQUNFRDtBQUFBQSxZQUFRLEtBQUssdUJBQUMsUUFBSyxVQUFTLGtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUMxQ0QsS0FBS0csTUFDRix1QkFBQyxRQUNELE1BQU1ILEtBQUtHLEtBQ1gsaUNBQUMsUUFDQyxPQUFLLE1BQ0wsUUFBTSxNQUNOLFFBQVE7QUFBQSxNQUFFQyxNQUFNO0FBQUEsUUFBRUMsVUFBVTtBQUFBLE1BQUk7QUFBQSxJQUFFLEdBRWpDTCxlQUFLRSxTQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTRixJQUNFLHVCQUFDLFFBQ0QsT0FBSyxNQUNMLFFBQU0sTUFDTixRQUFRO0FBQUEsTUFBRUUsTUFBTTtBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFJO0FBQUEsSUFBRSxHQUVqQ0wsZUFBS0UsU0FMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUY7QUFBQSxPQW5CV0QsT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBLENBRUYsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNMLEdBcENLRixZQUErQjtBQUFBLFVBQ2ZGLFFBQVE7QUFBQTtBQUFBYyxLQUR4Qlo7QUFzQ04sZUFBZUE7QUFBVSxJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRnJhZ21lbnQiLCJJY29uIiwiVGV4dCIsIkxpbmsiLCJ1c2VUaGVtZSIsIkZsZXhSb3ciLCJCcmVhZENydW1iIiwiaXRlbXMiLCJfcyIsInNwYWNpbmciLCJtZCIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImxhYmVsIiwidXJsIiwicm9vdCIsIm1heFdpZHRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCcmVhZENydW1iLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2JyZWFkY3J1bWIvQnJlYWRDcnVtYi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEljb24sIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAnLi4nXG5pbXBvcnQgeyBCcmVhZENydW1iSXRlbSB9IGZyb20gJy4nXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuaW1wb3J0IEZsZXhSb3cgZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhSb3cnXG5cbmludGVyZmFjZSBCcmVhZENydW1iUHJvcHMge1xuICBpdGVtczogQXJyYXk8QnJlYWRDcnVtYkl0ZW0+XG59XG5cbmNvbnN0IEJyZWFkQ3J1bWI6IEZDPEJyZWFkQ3J1bWJQcm9wcz4gPSAoeyBpdGVtcyB9KSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiAoXG4gICAgPEZsZXhSb3dcbiAgICAgIHZlcnRpY2FsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgZ2FwPXtzcGFjaW5nLm1kfVxuICAgID5cbiAgICAgIHtpdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgIGl0ZW0/LmxhYmVsICYmXG4gICAgICAgIDxGcmFnbWVudCBrZXk9e2luZGV4fT5cbiAgICAgICAgICB7aW5kZXggPiAwICYmIDxJY29uIGljb25OYW1lPSdDaGV2cm9uUmlnaHQnIC8+fVxuICAgICAgICAgIHtpdGVtLnVybFxuICAgICAgICAgICAgPyA8TGlua1xuICAgICAgICAgICAgICBocmVmPXtpdGVtLnVybH0+XG4gICAgICAgICAgICAgIDxUZXh0XG4gICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICBub3dyYXBcbiAgICAgICAgICAgICAgICBzdHlsZXM9e3sgcm9vdDogeyBtYXhXaWR0aDogMjAwIH0gfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxuICAgICAgICAgICAgICA8L1RleHQ+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA6IDxUZXh0XG4gICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgIG5vd3JhcFxuICAgICAgICAgICAgICBzdHlsZXM9e3sgcm9vdDogeyBtYXhXaWR0aDogMjAwIH0gfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICA8L1RleHQ+XG4gICAgICAgICAgfVxuICAgICAgICA8L0ZyYWdtZW50PlxuICAgICAgKSxcbiAgICAgICl9XG4gICAgPC9GbGV4Um93PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJyZWFkQ3J1bWJcbiJdfQ==