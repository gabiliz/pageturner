import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UsersDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UsersDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { userService as service } from "/src/modules/admin/users/services/index.ts";
const UserDropdown = (props) => {
  _s();
  const [users, setUsers] = useState([]);
  const getAllUsers = useCallback(async () => {
    const data = await service.findQuery();
    setUsers(data.value);
  }, [setUsers]);
  useEffect(() => {
    getAllUsers();
  }, []);
  const options = useMemo(() => users.map((user) => ({
    key: user.id,
    text: user.nome
  })) ?? [], [users]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { options: !props.filterId ? options : options.filter((opt) => opt.key !== props.filterId), allowFreeform: true, autoComplete: "on", ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UsersDropdown.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_s(UserDropdown, "NBd6HCcfBKomAEj5+ClPvo87EVg=");
_c = UserDropdown;
export default UserDropdown;
var _c;
$RefreshReg$(_c, "UserDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UsersDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUJKLFNBQWFBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUU5RCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZUMsZUFBZTtBQU12QyxNQUFNQyxlQUF1Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3JELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUixTQUFpQixFQUFFO0FBRTdDLFFBQU1TLGNBQWNaLFlBQVksWUFBWTtBQUMxQyxVQUFNYSxPQUFPLE1BQU1QLFFBQVFRLFVBQVU7QUFDckNILGFBQVNFLEtBQUtFLEtBQUs7QUFBQSxFQUNyQixHQUFHLENBQUNKLFFBQVEsQ0FBQztBQUViVixZQUFVLE1BQU07QUFDZFcsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMLFFBQU1JLFVBQVVkLFFBQ2QsTUFBTVEsTUFBTU8sSUFBSUMsV0FBUztBQUFBLElBQ3ZCQyxLQUFLRCxLQUFLRTtBQUFBQSxJQUNWQyxNQUFNSCxLQUFLSTtBQUFBQSxFQUNiLEVBQUUsS0FBSyxJQUNQLENBQUNaLEtBQUssQ0FDUjtBQUVBLFNBQ0UsdUJBQUMsWUFDQyxTQUNFLENBQUNGLE1BQU1lLFdBQ0hQLFVBQ0FBLFFBQVFRLE9BQU9DLFNBQU9BLElBQUlOLFFBQVFYLE1BQU1lLFFBQVEsR0FFdEQsZUFBZSxNQUNmLGNBQWEsTUFDYixHQUFJZixTQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRWTtBQUdoQjtBQUFDQyxHQWhDS0YsY0FBbUM7QUFBQW1CLEtBQW5DbkI7QUFrQ04sZUFBZUE7QUFBWSxJQUFBbUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ29tYm9Cb3giLCJ1c2VyU2VydmljZSIsInNlcnZpY2UiLCJVc2VyRHJvcGRvd24iLCJwcm9wcyIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImdldEFsbFVzZXJzIiwiZGF0YSIsImZpbmRRdWVyeSIsInZhbHVlIiwib3B0aW9ucyIsIm1hcCIsInVzZXIiLCJrZXkiLCJpZCIsInRleHQiLCJub21lIiwiZmlsdGVySWQiLCJmaWx0ZXIiLCJvcHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJzRHJvcGRvd24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi91c2Vycy9jb21wb25lbnRzL1VzZXJzRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbWJvQm94T3B0aW9uLCBJQ29tYm9Cb3hQcm9wcyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBVc2VyIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Vc2VyJ1xyXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VyU2VydmljZSBhcyBzZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJEcm9wZG93blByb3BzIGV4dGVuZHMgUGFydGlhbDxJQ29tYm9Cb3hQcm9wcz4ge1xyXG4gIGZpbHRlcklkPzogc3RyaW5nXHJcbn1cclxuXHJcbmNvbnN0IFVzZXJEcm9wZG93bjogRkM8VXNlckRyb3Bkb3duUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZTxVc2VyW10+KFtdKVxyXG5cclxuICBjb25zdCBnZXRBbGxVc2VycyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBzZXJ2aWNlLmZpbmRRdWVyeSgpXHJcbiAgICBzZXRVc2VycyhkYXRhLnZhbHVlKVxyXG4gIH0sIFtzZXRVc2Vyc10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBnZXRBbGxVc2VycygpXHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG9wdGlvbnMgPSB1c2VNZW1vPElDb21ib0JveE9wdGlvbltdPihcclxuICAgICgpID0+IHVzZXJzLm1hcCh1c2VyID0+ICh7XHJcbiAgICAgIGtleTogdXNlci5pZCBhcyBzdHJpbmcsXHJcbiAgICAgIHRleHQ6IHVzZXIubm9tZSxcclxuICAgIH0pKSA/PyBbXSxcclxuICAgIFt1c2Vyc10sXHJcbiAgKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPENvbWJvQm94XHJcbiAgICAgIG9wdGlvbnM9e1xyXG4gICAgICAgICFwcm9wcy5maWx0ZXJJZFxyXG4gICAgICAgICAgPyBvcHRpb25zXHJcbiAgICAgICAgICA6IG9wdGlvbnMuZmlsdGVyKG9wdCA9PiBvcHQua2V5ICE9PSBwcm9wcy5maWx0ZXJJZClcclxuICAgICAgfVxyXG4gICAgICBhbGxvd0ZyZWVmb3JtPXt0cnVlfVxyXG4gICAgICBhdXRvQ29tcGxldGU9J29uJ1xyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlckRyb3Bkb3duXHJcbiJdfQ==