import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/riskForm/pages/RiskFormForward.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text, TooltipHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"]; const useContext = __vite__cjsImport4_react["useContext"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { AppPage, ErrorScreen, FlexItem, FlexRow, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { useQueryString, useTheme } from "/src/shared/hooks/index.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { RiskFormForwardList } from "/src/modules/audit/riskForm/components/index.ts?t=1701096626433";
import { riskFormForwardService } from "/src/modules/audit/riskForm/services/index.ts";
const RiskFormForward = () => {
  _s();
  const [forms, setForms] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [refetch, setRefetch] = useState(true);
  const {
    isAuthenticated
  } = useAuth();
  const {
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  const {
    colors,
    fontWeight
  } = useTheme();
  const queryString = useQueryString();
  const endFetch = useCallback(() => {
    setIsLoading(false);
    setRefetch(false);
  }, []);
  useEffect(() => {
    if (refetch) {
      setIsLoading(true);
      riskFormForwardService.sendTokenGetForms({
        token: queryString.get("code"),
        email: queryString.get("email")
      }).then((response) => setForms(response)).finally(() => endFetch());
    }
  }, [refetch]);
  useEffect(() => {
    setGlobalLoading(isLoading && !isAuthenticated);
  }, [isLoading, isAuthenticated]);
  return /* @__PURE__ */ jsxDEV(AppPage, { title: "Formulários recebidos", subtitle: forms.length > 0 && forms[0].codigoEnvio ? `Código de envio: ${forms[0].codigoEnvio}` : void 0, children: [
    forms.length > 0 && forms[0].empresas.length > 0 && /* @__PURE__ */ jsxDEV(FlexRow, { children: /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(TooltipHost, { content: `Empresas: ${forms[0].empresas.map((cmp) => cmp?.empresa.razaoSocial).join(", ")}`, children: /* @__PURE__ */ jsxDEV(Text, { styles: {
      root: {
        fontWeight: fontWeight.semibold,
        color: colors.gray[800],
        width: 838,
        wordWrap: "break-word",
        overflowWrap: "break-word"
      }
    }, children: `Empresas: ${forms[0].empresas.map((cmp) => cmp?.empresa.razaoSocial).join(", ")}` }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 47,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 46,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 45,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 44,
      columnNumber: 60
    }, this),
    !isLoading && !isAuthenticated && forms.length > 0 && /* @__PURE__ */ jsxDEV(RiskFormForwardList, { forms, token: queryString.get("code"), email: queryString.get("email"), setRefetch }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 61,
      columnNumber: 62
    }, this),
    !isLoading && !isAuthenticated && forms.length === 0 && /* @__PURE__ */ jsxDEV(ErrorScreen, { type: "noForms" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 62,
      columnNumber: 64
    }, this),
    isLoading && !isAuthenticated && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 63,
      columnNumber: 41
    }, this),
    (!queryString.get("code") || !queryString.get("email")) && !isAuthenticated && /* @__PURE__ */ jsxDEV(ErrorScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 64,
      columnNumber: 87
    }, this),
    isAuthenticated && /* @__PURE__ */ jsxDEV(ErrorScreen, { type: "loggedIn" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
      lineNumber: 65,
      columnNumber: 27
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_s(RiskFormForward, "5s0r3toDi/JrUVbDr7rebydrB5Y=", false, function() {
  return [useAuth, useTheme, useQueryString];
});
_c = RiskFormForward;
export default RiskFormForward;
var _c;
$RefreshReg$(_c, "RiskFormForward");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormForward.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRjOzs7Ozs7Ozs7Ozs7Ozs7O0FBMURkLFNBQVNBLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFhQyxhQUFhQyxZQUFZQyxXQUFXQyxnQkFBZ0I7QUFFakUsU0FBU0MsU0FBU0MsYUFBYUMsVUFBVUMsU0FBU0MscUJBQXFCO0FBQ3ZFLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0JDLGdCQUFnQjtBQUN6QyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyw4QkFBOEI7QUFFdkMsTUFBTUMsa0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlmLFNBQWdDLEVBQUU7QUFDNUQsUUFBTSxDQUFDZ0IsV0FBV0MsWUFBWSxJQUFJakIsU0FBa0IsS0FBSztBQUN6RCxRQUFNLENBQUNrQixTQUFTQyxVQUFVLElBQUluQixTQUFrQixJQUFJO0FBQ3BELFFBQU07QUFBQSxJQUFFb0I7QUFBQUEsRUFBZ0IsSUFBSVgsUUFBUTtBQUNwQyxRQUFNO0FBQUEsSUFBRVEsY0FBY0k7QUFBQUEsRUFBaUIsSUFBSXZCLFdBQVdRLGtCQUFrQjtBQUN4RSxRQUFNO0FBQUEsSUFBRWdCO0FBQUFBLElBQVFDO0FBQUFBLEVBQVcsSUFBSWYsU0FBUztBQUN4QyxRQUFNZ0IsY0FBY2pCLGVBQWU7QUFDbkMsUUFBTWtCLFdBQVc1QixZQUFZLE1BQU07QUFDakNvQixpQkFBYSxLQUFLO0FBQ2xCRSxlQUFXLEtBQUs7QUFBQSxFQUNsQixHQUFHLEVBQUU7QUFFTHBCLFlBQVUsTUFBTTtBQUNkLFFBQUltQixTQUFTO0FBQ1hELG1CQUFhLElBQUk7QUFDakJOLDZCQUF1QmUsa0JBQ3JCO0FBQUEsUUFDRUMsT0FBT0gsWUFBWUksSUFBSSxNQUFNO0FBQUEsUUFDN0JDLE9BQU9MLFlBQVlJLElBQUksT0FBTztBQUFBLE1BQ2hDLENBQ0YsRUFDR0UsS0FBS0MsY0FBWWhCLFNBQVNnQixRQUFpQyxDQUFDLEVBQzVEQyxRQUFRLE1BQU1QLFNBQVMsQ0FBQztBQUFBLElBQzdCO0FBQUEsRUFDRixHQUFHLENBQUNQLE9BQU8sQ0FBQztBQUVabkIsWUFBVSxNQUFNO0FBQ2RzQixxQkFBaUJMLGFBQWEsQ0FBQ0ksZUFBZTtBQUFBLEVBQ2hELEdBQUcsQ0FBQ0osV0FBV0ksZUFBZSxDQUFDO0FBRS9CLFNBQ0UsdUJBQUMsV0FDQyxPQUFNLHlCQUNOLFVBQ0VOLE1BQU1tQixTQUFTLEtBQUtuQixNQUFNLENBQUMsRUFBRW9CLGNBQ3hCLG9CQUFtQnBCLE1BQU0sQ0FBQyxFQUFFb0IsZ0JBQzdCQyxRQUlKckI7QUFBQUEsVUFBTW1CLFNBQVMsS0FDZm5CLE1BQU0sQ0FBQyxFQUFFc0IsU0FBU0gsU0FBUyxLQUMzQix1QkFBQyxXQUNDLGlDQUFDLFlBQ0MsaUNBQUMsZUFDQyxTQUFVLGFBQVluQixNQUFNLENBQUMsRUFBRXNCLFNBQVNDLElBQUlDLFNBQU9BLEtBQUtDLFFBQVFDLFdBQVcsRUFBRUMsS0FBSyxJQUFJLEtBRXRGLGlDQUFDLFFBQ0MsUUFBUTtBQUFBLE1BQ05DLE1BQU07QUFBQSxRQUNKbkIsWUFBWUEsV0FBV29CO0FBQUFBLFFBQ3ZCQyxPQUFPdEIsT0FBT3VCLEtBQUssR0FBRztBQUFBLFFBQ3RCQyxPQUFPO0FBQUEsUUFDUEMsVUFBVTtBQUFBLFFBQ1ZDLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0YsR0FFRSx1QkFBWWxDLE1BQU0sQ0FBQyxFQUFFc0IsU0FBU0MsSUFBSUMsU0FBT0EsS0FBS0MsUUFBUUMsV0FBVyxFQUFFQyxLQUFLLElBQUksT0FYaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVELENBQUN6QixhQUFhLENBQUNJLG1CQUFtQk4sTUFBTW1CLFNBQVMsS0FBSyx1QkFBQyx1QkFDdEQsT0FDQSxPQUFPVCxZQUFZSSxJQUFJLE1BQU0sR0FDN0IsT0FBT0osWUFBWUksSUFBSSxPQUFPLEdBQzlCLGNBSnFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJOUI7QUFBQSxJQUV4QixDQUFDWixhQUFhLENBQUNJLG1CQUFtQk4sTUFBTW1CLFdBQVcsS0FBSyx1QkFBQyxlQUFZLE1BQUssYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLElBQ25GakIsYUFBYSxDQUFDSSxtQkFBbUIsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsS0FDOUMsQ0FBQ0ksWUFBWUksSUFBSSxNQUFNLEtBQUssQ0FBQ0osWUFBWUksSUFBSSxPQUFPLE1BQU0sQ0FBQ1IsbUJBQW1CLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWTtBQUFBLElBQzNGQSxtQkFBbUIsdUJBQUMsZUFBWSxNQUFLLGNBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQTFDbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQTtBQUVKO0FBQUNQLEdBN0VLRCxpQkFBbUI7QUFBQSxVQUlLSCxTQUVHRCxVQUNYRCxjQUFjO0FBQUE7QUFBQTBDLEtBUDlCckM7QUErRU4sZUFBZUE7QUFBZSxJQUFBcUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlRleHQiLCJUb29sdGlwSG9zdCIsInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQXBwUGFnZSIsIkVycm9yU2NyZWVuIiwiRmxleEl0ZW0iLCJGbGV4Um93IiwiTG9hZGluZ1NjcmVlbiIsIkxvYWRpbmdEYXRhQ29udGV4dCIsInVzZVF1ZXJ5U3RyaW5nIiwidXNlVGhlbWUiLCJ1c2VBdXRoIiwiUmlza0Zvcm1Gb3J3YXJkTGlzdCIsInJpc2tGb3JtRm9yd2FyZFNlcnZpY2UiLCJSaXNrRm9ybUZvcndhcmQiLCJfcyIsImZvcm1zIiwic2V0Rm9ybXMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJyZWZldGNoIiwic2V0UmVmZXRjaCIsImlzQXV0aGVudGljYXRlZCIsInNldEdsb2JhbExvYWRpbmciLCJjb2xvcnMiLCJmb250V2VpZ2h0IiwicXVlcnlTdHJpbmciLCJlbmRGZXRjaCIsInNlbmRUb2tlbkdldEZvcm1zIiwidG9rZW4iLCJnZXQiLCJlbWFpbCIsInRoZW4iLCJyZXNwb25zZSIsImZpbmFsbHkiLCJsZW5ndGgiLCJjb2RpZ29FbnZpbyIsInVuZGVmaW5lZCIsImVtcHJlc2FzIiwibWFwIiwiY21wIiwiZW1wcmVzYSIsInJhemFvU29jaWFsIiwiam9pbiIsInJvb3QiLCJzZW1pYm9sZCIsImNvbG9yIiwiZ3JheSIsIndpZHRoIiwid29yZFdyYXAiLCJvdmVyZmxvd1dyYXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJpc2tGb3JtRm9yd2FyZC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L3Jpc2tGb3JtL3BhZ2VzL1Jpc2tGb3JtRm9yd2FyZC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgVGV4dCwgVG9vbHRpcEhvc3QgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBSaXNrRm9ybUZvcndhcmQgYXMgUmlza0Zvcm1Gb3J3YXJkVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9SaXNrRm9ybSdcclxuaW1wb3J0IHsgQXBwUGFnZSwgRXJyb3JTY3JlZW4sIEZsZXhJdGVtLCBGbGV4Um93LCBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IExvYWRpbmdEYXRhQ29udGV4dCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb250ZXh0L0xvYWRpbmdEYXRhQ29udGV4dCdcclxuaW1wb3J0IHsgdXNlUXVlcnlTdHJpbmcsIHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zdG9yZS9hdXRoJ1xyXG5pbXBvcnQgeyBSaXNrRm9ybUZvcndhcmRMaXN0IH0gZnJvbSAnLi4vY29tcG9uZW50cydcclxuaW1wb3J0IHsgcmlza0Zvcm1Gb3J3YXJkU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xyXG5cclxuY29uc3QgUmlza0Zvcm1Gb3J3YXJkOiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBbZm9ybXMsIHNldEZvcm1zXSA9IHVzZVN0YXRlPFJpc2tGb3JtRm9yd2FyZFR5cGVbXT4oW10pXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxyXG4gIGNvbnN0IFtyZWZldGNoLCBzZXRSZWZldGNoXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpXHJcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQgfSA9IHVzZUF1dGgoKVxyXG4gIGNvbnN0IHsgc2V0SXNMb2FkaW5nOiBzZXRHbG9iYWxMb2FkaW5nIH0gPSB1c2VDb250ZXh0KExvYWRpbmdEYXRhQ29udGV4dClcclxuICBjb25zdCB7IGNvbG9ycywgZm9udFdlaWdodCB9ID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IHF1ZXJ5U3RyaW5nID0gdXNlUXVlcnlTdHJpbmcoKVxyXG4gIGNvbnN0IGVuZEZldGNoID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxyXG4gICAgc2V0UmVmZXRjaChmYWxzZSlcclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChyZWZldGNoKSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKVxyXG4gICAgICByaXNrRm9ybUZvcndhcmRTZXJ2aWNlLnNlbmRUb2tlbkdldEZvcm1zKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHRva2VuOiBxdWVyeVN0cmluZy5nZXQoJ2NvZGUnKSBhcyBzdHJpbmcsXHJcbiAgICAgICAgICBlbWFpbDogcXVlcnlTdHJpbmcuZ2V0KCdlbWFpbCcpIGFzIHN0cmluZyxcclxuICAgICAgICB9LFxyXG4gICAgICApXHJcbiAgICAgICAgLnRoZW4ocmVzcG9uc2UgPT4gc2V0Rm9ybXMocmVzcG9uc2UgYXMgUmlza0Zvcm1Gb3J3YXJkVHlwZVtdKSlcclxuICAgICAgICAuZmluYWxseSgoKSA9PiBlbmRGZXRjaCgpKVxyXG4gICAgfVxyXG4gIH0sIFtyZWZldGNoXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldEdsb2JhbExvYWRpbmcoaXNMb2FkaW5nICYmICFpc0F1dGhlbnRpY2F0ZWQpXHJcbiAgfSwgW2lzTG9hZGluZywgaXNBdXRoZW50aWNhdGVkXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBcHBQYWdlXHJcbiAgICAgIHRpdGxlPSdGb3JtdWzDoXJpb3MgcmVjZWJpZG9zJ1xyXG4gICAgICBzdWJ0aXRsZT17XHJcbiAgICAgICAgZm9ybXMubGVuZ3RoID4gMCAmJiBmb3Jtc1swXS5jb2RpZ29FbnZpb1xyXG4gICAgICAgICAgPyBgQ8OzZGlnbyBkZSBlbnZpbzogJHtmb3Jtc1swXS5jb2RpZ29FbnZpb31gXHJcbiAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICB9XHJcbiAgICA+XHJcbiAgICAgIHtcclxuICAgICAgICBmb3Jtcy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgZm9ybXNbMF0uZW1wcmVzYXMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgIDxGbGV4Um93PlxyXG4gICAgICAgICAgPEZsZXhJdGVtPlxyXG4gICAgICAgICAgICA8VG9vbHRpcEhvc3RcclxuICAgICAgICAgICAgICBjb250ZW50PXtgRW1wcmVzYXM6ICR7Zm9ybXNbMF0uZW1wcmVzYXMubWFwKGNtcCA9PiBjbXA/LmVtcHJlc2EucmF6YW9Tb2NpYWwpLmpvaW4oJywgJyl9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzgwMF0sXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDgzOCxcclxuICAgICAgICAgICAgICAgICAgICB3b3JkV3JhcDogJ2JyZWFrLXdvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJmbG93V3JhcDogJ2JyZWFrLXdvcmQnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7YEVtcHJlc2FzOiAke2Zvcm1zWzBdLmVtcHJlc2FzLm1hcChjbXAgPT4gY21wPy5lbXByZXNhLnJhemFvU29jaWFsKS5qb2luKCcsICcpfWB9XHJcbiAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gICAgICAgICAgPC9GbGV4SXRlbT5cclxuICAgICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgIH1cclxuICAgICAgeyFpc0xvYWRpbmcgJiYgIWlzQXV0aGVudGljYXRlZCAmJiBmb3Jtcy5sZW5ndGggPiAwICYmIDxSaXNrRm9ybUZvcndhcmRMaXN0XHJcbiAgICAgICAgZm9ybXM9e2Zvcm1zfVxyXG4gICAgICAgIHRva2VuPXtxdWVyeVN0cmluZy5nZXQoJ2NvZGUnKSBhcyBzdHJpbmd9XHJcbiAgICAgICAgZW1haWw9e3F1ZXJ5U3RyaW5nLmdldCgnZW1haWwnKSBhcyBzdHJpbmd9XHJcbiAgICAgICAgc2V0UmVmZXRjaD17c2V0UmVmZXRjaH1cclxuICAgICAgLz59XHJcbiAgICAgIHshaXNMb2FkaW5nICYmICFpc0F1dGhlbnRpY2F0ZWQgJiYgZm9ybXMubGVuZ3RoID09PSAwICYmIDxFcnJvclNjcmVlbiB0eXBlPSdub0Zvcm1zJy8+fVxyXG4gICAgICB7aXNMb2FkaW5nICYmICFpc0F1dGhlbnRpY2F0ZWQgJiYgPExvYWRpbmdTY3JlZW4gLz59XHJcbiAgICAgIHsoIXF1ZXJ5U3RyaW5nLmdldCgnY29kZScpIHx8ICFxdWVyeVN0cmluZy5nZXQoJ2VtYWlsJykpICYmICFpc0F1dGhlbnRpY2F0ZWQgJiYgPEVycm9yU2NyZWVuIC8+fVxyXG4gICAgICB7aXNBdXRoZW50aWNhdGVkICYmIDxFcnJvclNjcmVlbiB0eXBlPSdsb2dnZWRJbicvPn1cclxuICAgIDwvQXBwUGFnZT5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJpc2tGb3JtRm9yd2FyZFxyXG4iXX0=