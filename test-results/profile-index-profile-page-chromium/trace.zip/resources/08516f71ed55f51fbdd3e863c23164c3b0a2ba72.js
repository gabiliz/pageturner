export var SpinnerSizeEnum = /* @__PURE__ */ ((SpinnerSizeEnum2) => {
  SpinnerSizeEnum2[SpinnerSizeEnum2["xSmall"] = 0] = "xSmall";
  SpinnerSizeEnum2[SpinnerSizeEnum2["small"] = 1] = "small";
  SpinnerSizeEnum2[SpinnerSizeEnum2["medium"] = 2] = "medium";
  SpinnerSizeEnum2[SpinnerSizeEnum2["large"] = 3] = "large";
  return SpinnerSizeEnum2;
})(SpinnerSizeEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNwaW5uZXJTaXplRW51bS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBTcGlubmVyU2l6ZUVudW0ge1xuICB4U21hbGwsXG4gIHNtYWxsLFxuICBtZWRpdW0sXG4gIGxhcmdlLFxufVxuIl0sIm1hcHBpbmdzIjoiQUFBTyxXQUFLLGtCQUFMLGtCQUFLQSxxQkFBTDtBQUNMLEVBQUFBLGtDQUFBO0FBQ0EsRUFBQUEsa0NBQUE7QUFDQSxFQUFBQSxrQ0FBQTtBQUNBLEVBQUFBLGtDQUFBO0FBSlUsU0FBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbIlNwaW5uZXJTaXplRW51bSJdfQ==