import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/buttons/SpinningButton.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { PrimaryButton, Spinner } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { SpinnerSizeEnum } from "/src/shared/enums/SpinnerSizeEnum.ts";
import { css } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
const SpinningButton = (props) => {
  _s();
  const {
    spacing
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(PrimaryButton, { styles: props.styles || {
    root: {
      marginTop: spacing.xl
    }
  }, disabled: props.disabled, label: props.label, onRenderText: () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Spinner, { size: SpinnerSizeEnum.medium, styles: spinnerCustom }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this),
    props?.label && /* @__PURE__ */ jsxDEV("span", { style: {
      marginLeft: 10
    }, children: props.label }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx",
      lineNumber: 24,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx",
    lineNumber: 22,
    columnNumber: 72
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(SpinningButton, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
_c = SpinningButton;
export default SpinningButton;
const spinnerCustom = css`
  border: 1.5px solid ${(props) => props.theme.colors.white};
  border-top: 1.5px solid ${(props) => props.theme.colors.purple[800]};
`;
var _c;
$RefreshReg$(_c, "SpinningButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/buttons/SpinningButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0IwQixtQkFDbEIsY0FEa0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQjFCLFNBQVNBLGVBQWVDLGVBQWU7QUFDdkMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxXQUFXO0FBUXBCLE1BQU1DLGlCQUEyQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3pELFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFRLElBQUlOLFNBQVM7QUFDN0IsU0FDRSx1QkFBQyxpQkFDQyxRQUFRSSxNQUFNRyxVQUFVO0FBQUEsSUFDdEJDLE1BQU07QUFBQSxNQUFFQyxXQUFXSCxRQUFRSTtBQUFBQSxJQUFHO0FBQUEsRUFDaEMsR0FDQSxVQUFVTixNQUFNTyxVQUNoQixPQUFPUCxNQUFNUSxPQUNiLGNBQWMsTUFBTSxtQ0FDbEI7QUFBQSwyQkFBQyxXQUNDLE1BQU1YLGdCQUFnQlksUUFDdEIsUUFBUUMsaUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUV3QjtBQUFBLElBRXZCVixPQUFPUSxTQUFTLHVCQUFDLFVBQUssT0FBTztBQUFBLE1BQUVHLFlBQVk7QUFBQSxJQUFHLEdBQUlYLGdCQUFNUSxTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsT0FMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1wQixLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZTTtBQUdWO0FBQUNQLEdBbEJLRixnQkFBdUM7QUFBQSxVQUN2QkgsUUFBUTtBQUFBO0FBQUFnQixLQUR4QmI7QUFvQk4sZUFBZUE7QUFFZixNQUFNVyxnQkFBZ0JaO0FBQUFBLHdCQUNHRSxXQUFVQSxNQUFNYSxNQUFNQyxPQUFPQztBQUFBQSw0QkFDekJmLFdBQVVBLE1BQU1hLE1BQU1DLE9BQU9FLE9BQU8sR0FBRztBQUFBO0FBQ25FLElBQUFKO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJQcmltYXJ5QnV0dG9uIiwiU3Bpbm5lciIsInVzZVRoZW1lIiwiU3Bpbm5lclNpemVFbnVtIiwiY3NzIiwiU3Bpbm5pbmdCdXR0b24iLCJwcm9wcyIsIl9zIiwic3BhY2luZyIsInN0eWxlcyIsInJvb3QiLCJtYXJnaW5Ub3AiLCJ4bCIsImRpc2FibGVkIiwibGFiZWwiLCJtZWRpdW0iLCJzcGlubmVyQ3VzdG9tIiwibWFyZ2luTGVmdCIsIl9jIiwidGhlbWUiLCJjb2xvcnMiLCJ3aGl0ZSIsInB1cnBsZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNwaW5uaW5nQnV0dG9uLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbnMvU3Bpbm5pbmdCdXR0b24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUJ1dHRvblN0eWxlcyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBQcmltYXJ5QnV0dG9uLCBTcGlubmVyIH0gZnJvbSAnLi4vJ1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IFNwaW5uZXJTaXplRW51bSB9IGZyb20gJy4uLy4uL2VudW1zL1NwaW5uZXJTaXplRW51bSdcbmltcG9ydCB7IGNzcyB9IGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xuXG5pbnRlcmZhY2UgU3Bpbm5pbmdCdXR0b25Qcm9wcyB7XG4gIGxhYmVsPzogc3RyaW5nXG4gIGRpc2FibGVkPzogYm9vbGVhblxuICBzdHlsZXM/OiBJQnV0dG9uU3R5bGVzXG59XG5cbmNvbnN0IFNwaW5uaW5nQnV0dG9uOiBGQzxTcGlubmluZ0J1dHRvblByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IHNwYWNpbmcgfSA9IHVzZVRoZW1lKClcbiAgcmV0dXJuIChcbiAgICA8UHJpbWFyeUJ1dHRvblxuICAgICAgc3R5bGVzPXtwcm9wcy5zdHlsZXMgfHwge1xuICAgICAgICByb290OiB7IG1hcmdpblRvcDogc3BhY2luZy54bCB9LFxuICAgICAgfSB9XG4gICAgICBkaXNhYmxlZD17cHJvcHMuZGlzYWJsZWR9XG4gICAgICBsYWJlbD17cHJvcHMubGFiZWx9XG4gICAgICBvblJlbmRlclRleHQ9eygpID0+IDw+XG4gICAgICAgIDxTcGlubmVyXG4gICAgICAgICAgc2l6ZT17U3Bpbm5lclNpemVFbnVtLm1lZGl1bX1cbiAgICAgICAgICBzdHlsZXM9e3NwaW5uZXJDdXN0b219XG4gICAgICAgIC8+XG4gICAgICAgIHtwcm9wcz8ubGFiZWwgJiYgPHNwYW4gc3R5bGU9e3sgbWFyZ2luTGVmdDogMTAgfX0+e3Byb3BzLmxhYmVsfTwvc3Bhbj59XG4gICAgICA8Lz59XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBTcGlubmluZ0J1dHRvblxuXG5jb25zdCBzcGlubmVyQ3VzdG9tID0gY3NzYFxuICBib3JkZXI6IDEuNXB4IHNvbGlkICR7KHByb3BzKSA9PiBwcm9wcy50aGVtZS5jb2xvcnMud2hpdGV9O1xuICBib3JkZXItdG9wOiAxLjVweCBzb2xpZCAkeyhwcm9wcykgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs4MDBdfTtcbmBcbiJdfQ==