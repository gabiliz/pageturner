import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/progress/ProgressIndicator.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressIndicator.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ProgressIndicator as FluentProgressIndicator } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const ProgressIndicator = ({
  styles,
  ...props
}) => {
  _s();
  const progressIndicatorStyles = useProgressIndicatorStyles();
  return /* @__PURE__ */ jsxDEV(FluentProgressIndicator, { styles: {
    ...progressIndicatorStyles,
    ...styles
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressIndicator.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(ProgressIndicator, "pGJQPZ7ck3nQ5C8VXONOyZo9VHc=", false, function() {
  return [useProgressIndicatorStyles];
});
_c = ProgressIndicator;
const useProgressIndicatorStyles = () => {
  _s2();
  const theme = useTheme();
  const progressIndicatorStyles = {
    root: {
      width: "100%",
      margin: "0 auto"
    },
    itemDescription: {
      padding: `${theme.spacing.sm} 0`,
      color: theme.colors.gray[600]
    },
    progressTrack: {
      height: "8px",
      backgroundColor: theme.colors.purple[100],
      borderRadius: theme.spacing.xs
    },
    progressBar: {
      height: "8px",
      backgroundColor: theme.colors.purple[300],
      borderRadius: theme.spacing.xs
    }
  };
  return progressIndicatorStyles;
};
_s2(useProgressIndicatorStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default ProgressIndicator;
var _c;
$RefreshReg$(_c, "ProgressIndicator");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/progress/ProgressIndicator.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFUSixTQUE0REEscUJBQXFCQywrQkFBK0I7QUFFaEgsU0FBU0MsZ0JBQWdCO0FBSXpCLE1BQU1GLG9CQUFnREEsQ0FBQztBQUFBLEVBQUVHO0FBQUFBLEVBQVEsR0FBR0M7QUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDOUUsUUFBTUMsMEJBQTBCQywyQkFBMkI7QUFDM0QsU0FDRSx1QkFBQywyQkFDQyxRQUFRO0FBQUEsSUFDTixHQUFHRDtBQUFBQSxJQUNILEdBQUdIO0FBQUFBLEVBQ0wsR0FFQSxHQUFJQyxTQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNWTtBQUdoQjtBQUFDQyxHQVpLTCxtQkFBNkM7QUFBQSxVQUNqQk8sMEJBQTBCO0FBQUE7QUFBQUMsS0FEdERSO0FBY04sTUFBTU8sNkJBQTZCQSxNQUFNO0FBQUFFLE1BQUE7QUFDdkMsUUFBTUMsUUFBUVIsU0FBUztBQUV2QixRQUFNSSwwQkFBNkQ7QUFBQSxJQUNqRUssTUFBTTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FDLGlCQUFpQjtBQUFBLE1BQ2ZDLFNBQVUsR0FBRUwsTUFBTU0sUUFBUUM7QUFBQUEsTUFDMUJDLE9BQU9SLE1BQU1TLE9BQU9DLEtBQUssR0FBRztBQUFBLElBQzlCO0FBQUEsSUFDQUMsZUFBZTtBQUFBLE1BQ2JDLFFBQVE7QUFBQSxNQUNSQyxpQkFBaUJiLE1BQU1TLE9BQU9LLE9BQU8sR0FBRztBQUFBLE1BQ3hDQyxjQUFjZixNQUFNTSxRQUFRVTtBQUFBQSxJQUM5QjtBQUFBLElBQ0FDLGFBQWE7QUFBQSxNQUNYTCxRQUFRO0FBQUEsTUFDUkMsaUJBQWlCYixNQUFNUyxPQUFPSyxPQUFPLEdBQUc7QUFBQSxNQUN4Q0MsY0FBY2YsTUFBTU0sUUFBUVU7QUFBQUEsSUFDOUI7QUFBQSxFQUNGO0FBRUEsU0FBT3BCO0FBQ1Q7QUFBQ0csSUF6QktGLDRCQUEwQjtBQUFBLFVBQ2hCTCxRQUFRO0FBQUE7QUEwQnhCLGVBQWVGO0FBQWlCLElBQUFRO0FBQUFvQixhQUFBcEIsSUFBQSIsIm5hbWVzIjpbIlByb2dyZXNzSW5kaWNhdG9yIiwiRmx1ZW50UHJvZ3Jlc3NJbmRpY2F0b3IiLCJ1c2VUaGVtZSIsInN0eWxlcyIsInByb3BzIiwiX3MiLCJwcm9ncmVzc0luZGljYXRvclN0eWxlcyIsInVzZVByb2dyZXNzSW5kaWNhdG9yU3R5bGVzIiwiX2MiLCJfczIiLCJ0aGVtZSIsInJvb3QiLCJ3aWR0aCIsIm1hcmdpbiIsIml0ZW1EZXNjcmlwdGlvbiIsInBhZGRpbmciLCJzcGFjaW5nIiwic20iLCJjb2xvciIsImNvbG9ycyIsImdyYXkiLCJwcm9ncmVzc1RyYWNrIiwiaGVpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwicHVycGxlIiwiYm9yZGVyUmFkaXVzIiwieHMiLCJwcm9ncmVzc0JhciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2dyZXNzSW5kaWNhdG9yLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL3Byb2dyZXNzL1Byb2dyZXNzSW5kaWNhdG9yLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElQcm9ncmVzc0luZGljYXRvclByb3BzLCBJUHJvZ3Jlc3NJbmRpY2F0b3JTdHlsZXMsIFByb2dyZXNzSW5kaWNhdG9yIGFzIEZsdWVudFByb2dyZXNzSW5kaWNhdG9yIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5cbnR5cGUgUHJvZ3Jlc3NJbmRpY2F0b3JQcm9wcyA9IElQcm9ncmVzc0luZGljYXRvclByb3BzXG5cbmNvbnN0IFByb2dyZXNzSW5kaWNhdG9yOiBGQzxQcm9ncmVzc0luZGljYXRvclByb3BzPiA9ICh7IHN0eWxlcywgLi4ucHJvcHMgfSkgPT4ge1xuICBjb25zdCBwcm9ncmVzc0luZGljYXRvclN0eWxlcyA9IHVzZVByb2dyZXNzSW5kaWNhdG9yU3R5bGVzKClcbiAgcmV0dXJuIChcbiAgICA8Rmx1ZW50UHJvZ3Jlc3NJbmRpY2F0b3JcbiAgICAgIHN0eWxlcz17e1xuICAgICAgICAuLi5wcm9ncmVzc0luZGljYXRvclN0eWxlcyxcbiAgICAgICAgLi4uc3R5bGVzLFxuICAgICAgfX1cblxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuY29uc3QgdXNlUHJvZ3Jlc3NJbmRpY2F0b3JTdHlsZXMgPSAoKSA9PiB7XG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxuXG4gIGNvbnN0IHByb2dyZXNzSW5kaWNhdG9yU3R5bGVzOiBQYXJ0aWFsPElQcm9ncmVzc0luZGljYXRvclN0eWxlcz4gPSB7XG4gICAgcm9vdDoge1xuICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgIG1hcmdpbjogJzAgYXV0bycsXG4gICAgfSxcbiAgICBpdGVtRGVzY3JpcHRpb246IHtcbiAgICAgIHBhZGRpbmc6IGAke3RoZW1lLnNwYWNpbmcuc219IDBgLFxuICAgICAgY29sb3I6IHRoZW1lLmNvbG9ycy5ncmF5WzYwMF0sXG4gICAgfSxcbiAgICBwcm9ncmVzc1RyYWNrOiB7XG4gICAgICBoZWlnaHQ6ICc4cHgnLFxuICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb2xvcnMucHVycGxlWzEwMF0sXG4gICAgICBib3JkZXJSYWRpdXM6IHRoZW1lLnNwYWNpbmcueHMsXG4gICAgfSxcbiAgICBwcm9ncmVzc0Jhcjoge1xuICAgICAgaGVpZ2h0OiAnOHB4JyxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29sb3JzLnB1cnBsZVszMDBdLFxuICAgICAgYm9yZGVyUmFkaXVzOiB0aGVtZS5zcGFjaW5nLnhzLFxuICAgIH0sXG4gIH1cblxuICByZXR1cm4gcHJvZ3Jlc3NJbmRpY2F0b3JTdHlsZXNcbn1cblxuZXhwb3J0IGRlZmF1bHQgUHJvZ3Jlc3NJbmRpY2F0b3JcbiJdfQ==