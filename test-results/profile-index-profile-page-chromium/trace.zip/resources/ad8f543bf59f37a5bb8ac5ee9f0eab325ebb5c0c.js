import.meta.env = {"M_REQUEST_TIMEOUT":"0","M_REFRESH_TOKEN_ENDPOINT":"/api/account/refresh-token","MANPATH":"/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man:/usr/share/man:/usr/local/share/man:/Users/gabiliz/.nvm/versions/node/v20.5.1/share/man:/opt/homebrew/share/man::","MallocNanoZone":"0","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import axios from "/node_modules/.vite/deps/axios.js?v=9f90a7ff";
import { ApiError, AuthenticationError, ForbiddenError } from "/src/shared/errors/index.ts";
import { omitBy } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
export class BaseApi {
  axios;
  constructor(apiBase = "") {
    const timeout = parseInt(import.meta.env.M_REQUEST_TIMEOUT) * 1e3;
    this.axios = axios.create({
      baseURL: apiBase,
      timeout,
      withCredentials: true
    });
    this.handleRequestError = this.handleRequestError.bind(this);
    this.axios.interceptors.response.use(
      this.handleRequestSuccess,
      this.handleRequestError
    );
  }
  getAll(url, data, config) {
    const params = omitBy(data, (param) => {
      return param === null && param === void 0 && param === "";
    });
    return this.axios.get(url, { ...config, params });
  }
  getAllPaginated(url, data) {
    const params = omitBy(data, (param) => {
      return param === null && param === void 0 && param === "";
    });
    return this.axios.get(url, { params });
  }
  getOne(url, data, config) {
    return this.axios.get(url, { ...config, params: data });
  }
  post(url, data, config) {
    return this.axios.post(url, data, config);
  }
  put(url, data) {
    return this.axios.put(url, data);
  }
  delete(url, data) {
    return this.axios.delete(
      url,
      data instanceof Array ? { data: { ids: data } } : { params: data }
    );
  }
  upload(url, data, onUploadProgress, signal) {
    const formData = new FormData();
    this.buildFormData(formData, data);
    return this.axios.post(
      url,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data"
        },
        onUploadProgress,
        signal
      }
    );
  }
  download(url, data, onDownloadProgress) {
    return this.axios.post(
      url,
      data,
      {
        responseType: "arraybuffer",
        onDownloadProgress
      }
    );
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  buildFormData(formData, data, parentKey) {
    if (data && typeof data === "object" && !(data instanceof Date) && !(data instanceof File) && !(data instanceof Blob)) {
      Object.keys(data).forEach((key) => {
        this.buildFormData(formData, data[key], parentKey ? `${parentKey}[${key}]` : key);
      });
    } else {
      const value = data == null ? "" : data;
      const separateStringsByPoints = parentKey?.replace(/\[(\w+)\]\[(\w+)\]/g, "[$1].$2").split(".");
      const lastWordAfterLastPoint = separateStringsByPoints?.splice(separateStringsByPoints?.length - 1, 1);
      const removeParenthesisOfLastWord = lastWordAfterLastPoint?.[0].replace("[", ".").replace("]", "");
      separateStringsByPoints?.push(removeParenthesisOfLastWord);
      const rebuiltString = separateStringsByPoints?.join(".");
      formData.append(rebuiltString, value);
    }
  }
  handleRequestSuccess(response) {
    return {
      headers: response.headers,
      status: response.status,
      data: response.data
    };
  }
  async handleRequestError(error) {
    if (error.response?.status === 401) {
      try {
        await this.regenerateToken();
        await this.retry(error.config);
      } catch (error2) {
        return Promise.reject(error2);
      }
      return Promise.reject(new AuthenticationError());
    }
    if (error.response?.status === 403) {
      return Promise.reject(new ForbiddenError());
    }
    return Promise.reject(new ApiError(error.response?.data));
  }
  regenerateToken() {
    return this.axios.post(import.meta.env.M_REFRESH_TOKEN_ENDPOINT);
  }
  retry(config) {
    return this.axios.request(config);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkJhc2VBcGkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zLCB7IEF4aW9zRXJyb3IsIEF4aW9zSW5zdGFuY2UsIEF4aW9zUHJvZ3Jlc3NFdmVudCwgQXhpb3NSZXF1ZXN0Q29uZmlnLCBBeGlvc1Jlc3BvbnNlLCBJbnRlcm5hbEF4aW9zUmVxdWVzdENvbmZpZyB9IGZyb20gJ2F4aW9zJ1xyXG5pbXBvcnQgeyBJQmFzZUFwaSwgUmVzcG9uc2UgfSBmcm9tICcuL0lCYXNlQXBpJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciwgQXV0aGVudGljYXRpb25FcnJvciwgRm9yYmlkZGVuRXJyb3IgfSBmcm9tICcuLi9lcnJvcnMnXHJcbmltcG9ydCB7IFBhZ2luYXRlZFJlc3BvbnNlIH0gZnJvbSAnLi4vdHlwZXMvUGFnaW5hdGVkUmVzcG9uc2UnXHJcbmltcG9ydCB7IG9taXRCeSB9IGZyb20gJ2xvZGFzaC1lcydcclxuXHJcbmV4cG9ydCBjbGFzcyBCYXNlQXBpPFEsIEM+IGltcGxlbWVudHMgSUJhc2VBcGk8USwgQz4ge1xyXG4gIGF4aW9zOiBBeGlvc0luc3RhbmNlXHJcbiAgY29uc3RydWN0b3IgKGFwaUJhc2UgPSAnJykge1xyXG4gICAgY29uc3QgdGltZW91dCA9IHBhcnNlSW50KGltcG9ydC5tZXRhLmVudi5NX1JFUVVFU1RfVElNRU9VVCkgKiAxMDAwXHJcbiAgICB0aGlzLmF4aW9zID0gYXhpb3MuY3JlYXRlKHtcclxuICAgICAgYmFzZVVSTDogYXBpQmFzZSxcclxuICAgICAgdGltZW91dCxcclxuICAgICAgd2l0aENyZWRlbnRpYWxzOiB0cnVlLFxyXG4gICAgfSlcclxuICAgIHRoaXMuaGFuZGxlUmVxdWVzdEVycm9yID0gdGhpcy5oYW5kbGVSZXF1ZXN0RXJyb3IuYmluZCh0aGlzKVxyXG4gICAgdGhpcy5heGlvcy5pbnRlcmNlcHRvcnMucmVzcG9uc2UudXNlKFxyXG4gICAgICB0aGlzLmhhbmRsZVJlcXVlc3RTdWNjZXNzIGFzICh2YWx1ZTogQXhpb3NSZXNwb25zZTxRLCBDPikgPT4gQXhpb3NSZXNwb25zZTxRLCBDPiB8IFByb21pc2U8QXhpb3NSZXNwb25zZTxRLCBDPj4sXHJcbiAgICAgIHRoaXMuaGFuZGxlUmVxdWVzdEVycm9yLFxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgZ2V0QWxsICh1cmw6IHN0cmluZywgZGF0YT86IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBjb25maWc/OiBBeGlvc1JlcXVlc3RDb25maWcpOiBQcm9taXNlPFJlc3BvbnNlPFFbXT4+IHtcclxuICAgIGNvbnN0IHBhcmFtcyA9IG9taXRCeShkYXRhLCAocGFyYW0pID0+IHtcclxuICAgICAgcmV0dXJuIHBhcmFtID09PSBudWxsICYmIHBhcmFtID09PSB1bmRlZmluZWQgJiYgcGFyYW0gPT09ICcnXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MuZ2V0KHVybCwgeyAuLi5jb25maWcsIHBhcmFtcyB9KVxyXG4gIH1cclxuXHJcbiAgZ2V0QWxsUGFnaW5hdGVkICh1cmw6IHN0cmluZywgZGF0YT86IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUHJvbWlzZTxSZXNwb25zZTxQYWdpbmF0ZWRSZXNwb25zZTxRPj4+IHtcclxuICAgIGNvbnN0IHBhcmFtcyA9IG9taXRCeShkYXRhLCAocGFyYW0pID0+IHtcclxuICAgICAgcmV0dXJuIHBhcmFtID09PSBudWxsICYmIHBhcmFtID09PSB1bmRlZmluZWQgJiYgcGFyYW0gPT09ICcnXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MuZ2V0KHVybCwgeyBwYXJhbXMgfSlcclxuICB9XHJcblxyXG4gIGdldE9uZSAodXJsOiBzdHJpbmcsIGRhdGE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgY29uZmlnPzogQXhpb3NSZXF1ZXN0Q29uZmlnKTogUHJvbWlzZTxSZXNwb25zZTxRPj4ge1xyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MuZ2V0KHVybCwgeyAuLi5jb25maWcsIHBhcmFtczogZGF0YSB9KVxyXG4gIH1cclxuXHJcbiAgcG9zdCAodXJsOiBzdHJpbmcsIGRhdGE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgY29uZmlnPzogQXhpb3NSZXF1ZXN0Q29uZmlnKTogUHJvbWlzZTxSZXNwb25zZTxDPj4ge1xyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MucG9zdCh1cmwsIGRhdGEsIGNvbmZpZylcclxuICB9XHJcblxyXG4gIHB1dCAodXJsOiBzdHJpbmcsIGRhdGE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8UmVzcG9uc2U8Qz4+IHtcclxuICAgIHJldHVybiB0aGlzLmF4aW9zLnB1dCh1cmwsIGRhdGEpXHJcbiAgfVxyXG5cclxuICBkZWxldGUgKHVybDogc3RyaW5nLCBkYXRhPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj58dW5rbm93bltdKTogUHJvbWlzZTxSZXNwb25zZTx2b2lkPj4ge1xyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MuZGVsZXRlKFxyXG4gICAgICB1cmwsXHJcbiAgICAgIGRhdGEgaW5zdGFuY2VvZiBBcnJheVxyXG4gICAgICAgID8geyBkYXRhOiB7IGlkczogZGF0YSB9IH1cclxuICAgICAgICA6IHsgcGFyYW1zOiBkYXRhIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICB1cGxvYWQgKFxyXG4gICAgdXJsOiBzdHJpbmcsXHJcbiAgICBkYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LFxyXG4gICAgb25VcGxvYWRQcm9ncmVzcz86IChwcm9ncmVzc0V2ZW50OiBBeGlvc1Byb2dyZXNzRXZlbnQpID0+IHZvaWQsXHJcbiAgICBzaWduYWw/OiBBYm9ydFNpZ25hbCxcclxuICApOiBQcm9taXNlPFJlc3BvbnNlPEM+PiB7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpXHJcbiAgICB0aGlzLmJ1aWxkRm9ybURhdGEoZm9ybURhdGEsIGRhdGEpXHJcbiAgICByZXR1cm4gdGhpcy5heGlvcy5wb3N0KFxyXG4gICAgICB1cmwsXHJcbiAgICAgIGZvcm1EYXRhLFxyXG4gICAgICB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdtdWx0aXBhcnQvZm9ybS1kYXRhJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uVXBsb2FkUHJvZ3Jlc3MsXHJcbiAgICAgICAgc2lnbmFsLFxyXG4gICAgICB9LFxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgZG93bmxvYWQgKFxyXG4gICAgdXJsOiBzdHJpbmcsXHJcbiAgICBkYXRhPzogdW5rbm93bixcclxuICAgIG9uRG93bmxvYWRQcm9ncmVzcz86IChwcm9ncmVzc0V2ZW50OiBBeGlvc1Byb2dyZXNzRXZlbnQpID0+IHZvaWQsXHJcbiAgKTogUHJvbWlzZTxBeGlvc1Jlc3BvbnNlPiB7XHJcbiAgICByZXR1cm4gdGhpcy5heGlvcy5wb3N0KFxyXG4gICAgICB1cmwsXHJcbiAgICAgIGRhdGEsXHJcbiAgICAgIHtcclxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcnJheWJ1ZmZlcicgYXMgJ2pzb24nLFxyXG4gICAgICAgIG9uRG93bmxvYWRQcm9ncmVzcyxcclxuICAgICAgfSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XHJcbiAgcHJpdmF0ZSBidWlsZEZvcm1EYXRhIChmb3JtRGF0YTogRm9ybURhdGEsIGRhdGE6IGFueSwgcGFyZW50S2V5PzpzdHJpbmcpIHtcclxuICAgIGlmIChkYXRhICYmIHR5cGVvZiBkYXRhID09PSAnb2JqZWN0JyAmJiAhKGRhdGEgaW5zdGFuY2VvZiBEYXRlKSAmJiAhKGRhdGEgaW5zdGFuY2VvZiBGaWxlKSAmJiAhKGRhdGEgaW5zdGFuY2VvZiBCbG9iKSkge1xyXG4gICAgICBPYmplY3Qua2V5cyhkYXRhKS5mb3JFYWNoKChrZXk6c3RyaW5nKSA9PiB7XHJcbiAgICAgICAgdGhpcy5idWlsZEZvcm1EYXRhKGZvcm1EYXRhLCBkYXRhW2tleV0sIHBhcmVudEtleSA/IGAke3BhcmVudEtleX1bJHtrZXl9XWAgOiBrZXkpXHJcbiAgICAgIH0pXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCB2YWx1ZSA9IGRhdGEgPT0gbnVsbCA/ICcnIDogZGF0YVxyXG4gICAgICBjb25zdCBzZXBhcmF0ZVN0cmluZ3NCeVBvaW50cyA9IHBhcmVudEtleT8ucmVwbGFjZSgvXFxbKFxcdyspXFxdXFxbKFxcdyspXFxdL2csICdbJDFdLiQyJykuc3BsaXQoJy4nKVxyXG4gICAgICBjb25zdCBsYXN0V29yZEFmdGVyTGFzdFBvaW50ID0gc2VwYXJhdGVTdHJpbmdzQnlQb2ludHM/LnNwbGljZShzZXBhcmF0ZVN0cmluZ3NCeVBvaW50cz8ubGVuZ3RoIC0gMSwgMSlcclxuICAgICAgY29uc3QgcmVtb3ZlUGFyZW50aGVzaXNPZkxhc3RXb3JkID0gbGFzdFdvcmRBZnRlckxhc3RQb2ludD8uWzBdLnJlcGxhY2UoJ1snLCAnLicpLnJlcGxhY2UoJ10nLCAnJylcclxuICAgICAgc2VwYXJhdGVTdHJpbmdzQnlQb2ludHM/LnB1c2gocmVtb3ZlUGFyZW50aGVzaXNPZkxhc3RXb3JkIGFzIHN0cmluZylcclxuICAgICAgY29uc3QgcmVidWlsdFN0cmluZyA9IHNlcGFyYXRlU3RyaW5nc0J5UG9pbnRzPy5qb2luKCcuJylcclxuXHJcbiAgICAgIGZvcm1EYXRhLmFwcGVuZChyZWJ1aWx0U3RyaW5nIGFzIHN0cmluZywgdmFsdWUpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGhhbmRsZVJlcXVlc3RTdWNjZXNzIChyZXNwb25zZTogQXhpb3NSZXNwb25zZSk6IFJlc3BvbnNlPHVua25vd24+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGhlYWRlcnM6IHJlc3BvbnNlLmhlYWRlcnMsXHJcbiAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxyXG4gICAgICBkYXRhOiByZXNwb25zZS5kYXRhLFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVSZXF1ZXN0RXJyb3IgKGVycm9yOiBBeGlvc0Vycm9yKTogUHJvbWlzZTxBeGlvc0Vycm9yPiB7XHJcbiAgICBpZiAoZXJyb3IucmVzcG9uc2U/LnN0YXR1cyA9PT0gNDAxKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5yZWdlbmVyYXRlVG9rZW4oKVxyXG4gICAgICAgIGF3YWl0IHRoaXMucmV0cnkoZXJyb3IuY29uZmlnIGFzIEludGVybmFsQXhpb3NSZXF1ZXN0Q29uZmlnPFE+KVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcilcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBBdXRoZW50aWNhdGlvbkVycm9yKCkpXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGVycm9yLnJlc3BvbnNlPy5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEZvcmJpZGRlbkVycm9yKCkpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBBcGlFcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YSBhcyBBcGlFcnJvcikpXHJcbiAgfVxyXG5cclxuICByZWdlbmVyYXRlVG9rZW4gKCk6IFByb21pc2U8dW5rbm93bj4ge1xyXG4gICAgcmV0dXJuIHRoaXMuYXhpb3MucG9zdChpbXBvcnQubWV0YS5lbnYuTV9SRUZSRVNIX1RPS0VOX0VORFBPSU5UKVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSByZXRyeSAoY29uZmlnOiBBeGlvc1JlcXVlc3RDb25maWcpOiBQcm9taXNlPHVua25vd24+IHtcclxuICAgIHJldHVybiB0aGlzLmF4aW9zLnJlcXVlc3QoY29uZmlnKVxyXG4gIH1cclxufVxyXG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sV0FBNkg7QUFFcEksU0FBUyxVQUFVLHFCQUFxQixzQkFBc0I7QUFFOUQsU0FBUyxjQUFjO0FBRWhCLGFBQU0sUUFBd0M7QUFBQSxFQUNuRDtBQUFBLEVBQ0EsWUFBYSxVQUFVLElBQUk7QUFDekIsVUFBTSxVQUFVLFNBQVMsWUFBWSxJQUFJLGlCQUFpQixJQUFJO0FBQzlELFNBQUssUUFBUSxNQUFNLE9BQU87QUFBQSxNQUN4QixTQUFTO0FBQUEsTUFDVDtBQUFBLE1BQ0EsaUJBQWlCO0FBQUEsSUFDbkIsQ0FBQztBQUNELFNBQUsscUJBQXFCLEtBQUssbUJBQW1CLEtBQUssSUFBSTtBQUMzRCxTQUFLLE1BQU0sYUFBYSxTQUFTO0FBQUEsTUFDL0IsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGO0FBQUEsRUFFQSxPQUFRLEtBQWEsTUFBZ0MsUUFBcUQ7QUFDeEcsVUFBTSxTQUFTLE9BQU8sTUFBTSxDQUFDLFVBQVU7QUFDckMsYUFBTyxVQUFVLFFBQVEsVUFBVSxVQUFhLFVBQVU7QUFBQSxJQUM1RCxDQUFDO0FBQ0QsV0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLEVBQUUsR0FBRyxRQUFRLE9BQU8sQ0FBQztBQUFBLEVBQ2xEO0FBQUEsRUFFQSxnQkFBaUIsS0FBYSxNQUF5RTtBQUNyRyxVQUFNLFNBQVMsT0FBTyxNQUFNLENBQUMsVUFBVTtBQUNyQyxhQUFPLFVBQVUsUUFBUSxVQUFVLFVBQWEsVUFBVTtBQUFBLElBQzVELENBQUM7QUFDRCxXQUFPLEtBQUssTUFBTSxJQUFJLEtBQUssRUFBRSxPQUFPLENBQUM7QUFBQSxFQUN2QztBQUFBLEVBRUEsT0FBUSxLQUFhLE1BQWdDLFFBQW1EO0FBQ3RHLFdBQU8sS0FBSyxNQUFNLElBQUksS0FBSyxFQUFFLEdBQUcsUUFBUSxRQUFRLEtBQUssQ0FBQztBQUFBLEVBQ3hEO0FBQUEsRUFFQSxLQUFNLEtBQWEsTUFBZ0MsUUFBbUQ7QUFDcEcsV0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTTtBQUFBLEVBQzFDO0FBQUEsRUFFQSxJQUFLLEtBQWEsTUFBc0Q7QUFDdEUsV0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUk7QUFBQSxFQUNqQztBQUFBLEVBRUEsT0FBUSxLQUFhLE1BQW1FO0FBQ3RGLFdBQU8sS0FBSyxNQUFNO0FBQUEsTUFDaEI7QUFBQSxNQUNBLGdCQUFnQixRQUNaLEVBQUUsTUFBTSxFQUFFLEtBQUssS0FBSyxFQUFFLElBQ3RCLEVBQUUsUUFBUSxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQUEsRUFFQSxPQUNFLEtBQ0EsTUFDQSxrQkFDQSxRQUNzQjtBQUN0QixVQUFNLFdBQVcsSUFBSSxTQUFTO0FBQzlCLFNBQUssY0FBYyxVQUFVLElBQUk7QUFDakMsV0FBTyxLQUFLLE1BQU07QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsUUFDRSxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxRQUNsQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxTQUNFLEtBQ0EsTUFDQSxvQkFDd0I7QUFDeEIsV0FBTyxLQUFLLE1BQU07QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsUUFDRSxjQUFjO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHUSxjQUFlLFVBQW9CLE1BQVcsV0FBbUI7QUFDdkUsUUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLEVBQUUsZ0JBQWdCLFNBQVMsRUFBRSxnQkFBZ0IsU0FBUyxFQUFFLGdCQUFnQixPQUFPO0FBQ3JILGFBQU8sS0FBSyxJQUFJLEVBQUUsUUFBUSxDQUFDLFFBQWU7QUFDeEMsYUFBSyxjQUFjLFVBQVUsS0FBSyxHQUFHLEdBQUcsWUFBWSxHQUFHLGFBQWEsU0FBUyxHQUFHO0FBQUEsTUFDbEYsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sUUFBUSxRQUFRLE9BQU8sS0FBSztBQUNsQyxZQUFNLDBCQUEwQixXQUFXLFFBQVEsdUJBQXVCLFNBQVMsRUFBRSxNQUFNLEdBQUc7QUFDOUYsWUFBTSx5QkFBeUIseUJBQXlCLE9BQU8seUJBQXlCLFNBQVMsR0FBRyxDQUFDO0FBQ3JHLFlBQU0sOEJBQThCLHlCQUF5QixDQUFDLEVBQUUsUUFBUSxLQUFLLEdBQUcsRUFBRSxRQUFRLEtBQUssRUFBRTtBQUNqRywrQkFBeUIsS0FBSywyQkFBcUM7QUFDbkUsWUFBTSxnQkFBZ0IseUJBQXlCLEtBQUssR0FBRztBQUV2RCxlQUFTLE9BQU8sZUFBeUIsS0FBSztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUFBLEVBRVEscUJBQXNCLFVBQTRDO0FBQ3hFLFdBQU87QUFBQSxNQUNMLFNBQVMsU0FBUztBQUFBLE1BQ2xCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLE1BQU0sU0FBUztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxtQkFBb0IsT0FBd0M7QUFDeEUsUUFBSSxNQUFNLFVBQVUsV0FBVyxLQUFLO0FBQ2xDLFVBQUk7QUFDRixjQUFNLEtBQUssZ0JBQWdCO0FBQzNCLGNBQU0sS0FBSyxNQUFNLE1BQU0sTUFBdUM7QUFBQSxNQUNoRSxTQUFTQSxRQUFQO0FBQ0EsZUFBTyxRQUFRLE9BQU9BLE1BQUs7QUFBQSxNQUM3QjtBQUVBLGFBQU8sUUFBUSxPQUFPLElBQUksb0JBQW9CLENBQUM7QUFBQSxJQUNqRDtBQUVBLFFBQUksTUFBTSxVQUFVLFdBQVcsS0FBSztBQUNsQyxhQUFPLFFBQVEsT0FBTyxJQUFJLGVBQWUsQ0FBQztBQUFBLElBQzVDO0FBRUEsV0FBTyxRQUFRLE9BQU8sSUFBSSxTQUFTLE1BQU0sVUFBVSxJQUFnQixDQUFDO0FBQUEsRUFDdEU7QUFBQSxFQUVBLGtCQUFxQztBQUNuQyxXQUFPLEtBQUssTUFBTSxLQUFLLFlBQVksSUFBSSx3QkFBd0I7QUFBQSxFQUNqRTtBQUFBLEVBRVEsTUFBTyxRQUE4QztBQUMzRCxXQUFPLEtBQUssTUFBTSxRQUFRLE1BQU07QUFBQSxFQUNsQztBQUNGOyIsIm5hbWVzIjpbImVycm9yIl19