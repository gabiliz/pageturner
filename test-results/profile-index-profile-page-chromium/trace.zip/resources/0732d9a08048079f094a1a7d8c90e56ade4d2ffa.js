import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAssociatesDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAssociatesDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { ComboBox } from "/src/shared/components/index.ts?t=1701096626433";
import { userService as service } from "/src/modules/admin/users/services/index.ts";
const UserAssociatesDropdown = (props) => {
  _s();
  const [users, setUsers] = useState([]);
  const getAllUsers = useCallback(async () => {
    const data = await service.findQuery();
    setUsers(data.value);
  }, [setUsers]);
  useEffect(() => {
    getAllUsers();
  }, []);
  const associates = useMemo(() => {
    return users?.filter((user) => user.socio === true);
  }, [users]);
  const options = useMemo(() => {
    if (associates) {
      return associates?.map((user) => ({
        key: user.id,
        text: user.nome
      }));
    }
    return [];
  }, [associates]);
  return /* @__PURE__ */ jsxDEV(ComboBox, { options: !props.filterId ? options : options.filter((opt) => opt.key !== props.filterId), allowFreeform: true, autoComplete: "on", ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAssociatesDropdown.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
};
_s(UserAssociatesDropdown, "x7IHxABNcpI8FOHfi1OL1Rie6+A=");
_c = UserAssociatesDropdown;
export default UserAssociatesDropdown;
var _c;
$RefreshReg$(_c, "UserAssociatesDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAssociatesDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNJOzs7Ozs7Ozs7Ozs7Ozs7O0FBcENKLFNBQWFBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUU5RCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZUMsZUFBZTtBQUt2QyxNQUFNQyx5QkFBb0VDLFdBQVU7QUFBQUMsS0FBQTtBQUNsRixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVIsU0FBaUIsRUFBRTtBQUU3QyxRQUFNUyxjQUFjWixZQUFZLFlBQVk7QUFDMUMsVUFBTWEsT0FBTyxNQUFNUCxRQUFRUSxVQUFVO0FBQ3JDSCxhQUFTRSxLQUFLRSxLQUFLO0FBQUEsRUFDckIsR0FBRyxDQUFDSixRQUFRLENBQUM7QUFFYlYsWUFBVSxNQUFNO0FBQ2RXLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTCxRQUFNSSxhQUFhZCxRQUFRLE1BQU07QUFDL0IsV0FBT1EsT0FBT08sT0FBT0MsVUFBUUEsS0FBS0MsVUFBVSxJQUFJO0FBQUEsRUFDbEQsR0FBRyxDQUFDVCxLQUFLLENBQUM7QUFFVixRQUFNVSxVQUFVbEIsUUFBMkIsTUFBTTtBQUMvQyxRQUFJYyxZQUFZO0FBQ2QsYUFBT0EsWUFBWUssSUFBSUgsV0FBUztBQUFBLFFBQzlCSSxLQUFLSixLQUFLSztBQUFBQSxRQUNWQyxNQUFNTixLQUFLTztBQUFBQSxNQUNiLEVBQUU7QUFBQSxJQUNKO0FBQ0EsV0FBTztBQUFBLEVBQ1QsR0FBRyxDQUFDVCxVQUFVLENBQ2Q7QUFFQSxTQUNFLHVCQUFDLFlBQ0MsU0FDRSxDQUFDUixNQUFNa0IsV0FDSE4sVUFDQUEsUUFBUUgsT0FBT1UsU0FBT0EsSUFBSUwsUUFBUWQsTUFBTWtCLFFBQVEsR0FFdEQsZUFBZSxNQUNmLGNBQWEsTUFDYixHQUFJbEIsU0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUVk7QUFHaEI7QUFBQ0MsR0F2Q0tGLHdCQUFnRTtBQUFBcUIsS0FBaEVyQjtBQXlDTixlQUFlQTtBQUFzQixJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ29tYm9Cb3giLCJ1c2VyU2VydmljZSIsInNlcnZpY2UiLCJVc2VyQXNzb2NpYXRlc0Ryb3Bkb3duIiwicHJvcHMiLCJfcyIsInVzZXJzIiwic2V0VXNlcnMiLCJnZXRBbGxVc2VycyIsImRhdGEiLCJmaW5kUXVlcnkiLCJ2YWx1ZSIsImFzc29jaWF0ZXMiLCJmaWx0ZXIiLCJ1c2VyIiwic29jaW8iLCJvcHRpb25zIiwibWFwIiwia2V5IiwiaWQiLCJ0ZXh0Iiwibm9tZSIsImZpbHRlcklkIiwib3B0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQXNzb2NpYXRlc0Ryb3Bkb3duLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vdXNlcnMvY29tcG9uZW50cy9Vc2VyQXNzb2NpYXRlc0Ryb3Bkb3duLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElDb21ib0JveE9wdGlvbiwgSUNvbWJvQm94UHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgVXNlciBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vVXNlcidcclxuaW1wb3J0IHsgQ29tYm9Cb3ggfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IHsgdXNlclNlcnZpY2UgYXMgc2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBVc2VyQXNzb2NpYXRlc0Ryb3Bkb3duUHJvcHMgZXh0ZW5kcyBQYXJ0aWFsPElDb21ib0JveFByb3BzPiB7XHJcbiAgZmlsdGVySWQ/OiBzdHJpbmdcclxufVxyXG5jb25zdCBVc2VyQXNzb2NpYXRlc0Ryb3Bkb3duOiBGQzxQYXJ0aWFsPFVzZXJBc3NvY2lhdGVzRHJvcGRvd25Qcm9wcz4+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZTxVc2VyW10+KFtdKVxyXG5cclxuICBjb25zdCBnZXRBbGxVc2VycyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBzZXJ2aWNlLmZpbmRRdWVyeSgpXHJcbiAgICBzZXRVc2VycyhkYXRhLnZhbHVlKVxyXG4gIH0sIFtzZXRVc2Vyc10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBnZXRBbGxVc2VycygpXHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IGFzc29jaWF0ZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiB1c2Vycz8uZmlsdGVyKHVzZXIgPT4gdXNlci5zb2NpbyA9PT0gdHJ1ZSlcclxuICB9LCBbdXNlcnNdKVxyXG5cclxuICBjb25zdCBvcHRpb25zID0gdXNlTWVtbzxJQ29tYm9Cb3hPcHRpb25bXT4oKCkgPT4ge1xyXG4gICAgaWYgKGFzc29jaWF0ZXMpIHtcclxuICAgICAgcmV0dXJuIGFzc29jaWF0ZXM/Lm1hcCh1c2VyID0+ICh7XHJcbiAgICAgICAga2V5OiB1c2VyLmlkIGFzIHN0cmluZyxcclxuICAgICAgICB0ZXh0OiB1c2VyLm5vbWUsXHJcbiAgICAgIH0pKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIFtdXHJcbiAgfSwgW2Fzc29jaWF0ZXNdLFxyXG4gIClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDb21ib0JveFxyXG4gICAgICBvcHRpb25zPXtcclxuICAgICAgICAhcHJvcHMuZmlsdGVySWRcclxuICAgICAgICAgID8gb3B0aW9uc1xyXG4gICAgICAgICAgOiBvcHRpb25zLmZpbHRlcihvcHQgPT4gb3B0LmtleSAhPT0gcHJvcHMuZmlsdGVySWQpXHJcbiAgICAgIH1cclxuICAgICAgYWxsb3dGcmVlZm9ybT17dHJ1ZX1cclxuICAgICAgYXV0b0NvbXBsZXRlPSdvbidcclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJBc3NvY2lhdGVzRHJvcGRvd25cclxuIl19