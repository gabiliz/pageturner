import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/link/Link.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/link/Link.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Link as FluentLink } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
const Link = (props) => {
  _s();
  const {
    href,
    ...otherProps
  } = props;
  const navigate = useNavigate();
  const handleClick = useCallback((event) => {
    event.preventDefault();
    if (href) {
      navigate(href);
    }
  }, [href]);
  return /* @__PURE__ */ jsxDEV(FluentLink, { href, onClick: handleClick, ...otherProps }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/link/Link.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(Link, "qO2S9XgnUb0WIZcjCBv6XWQeYx8=", false, function() {
  return [useNavigate];
});
_c = Link;
export default Link;
var _c;
$RefreshReg$(_c, "Link");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/link/Link.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJKLFNBQXlCQSxtQkFBbUI7QUFDNUMsU0FBU0MsUUFBUUMsa0JBQThCO0FBQy9DLFNBQVNDLG1CQUFtQjtBQUU1QixNQUFNRixPQUF3QkcsV0FBVTtBQUFBQyxLQUFBO0FBQ3RDLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFNLEdBQUdDO0FBQUFBLEVBQVcsSUFBSUg7QUFFaEMsUUFBTUksV0FBV0wsWUFBWTtBQUU3QixRQUFNTSxjQUFjVCxZQUFZLENBQUNVLFVBQXNCO0FBQ3JEQSxVQUFNQyxlQUFlO0FBQ3JCLFFBQUlMLE1BQU07QUFDUkUsZUFBU0YsSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsSUFBSSxDQUFDO0FBRVQsU0FDRSx1QkFBQyxjQUNDLE1BQ0EsU0FBU0csYUFDVCxHQUFJRixjQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHaUI7QUFHckI7QUFBQ0YsR0FuQktKLE1BQW9CO0FBQUEsVUFHUEUsV0FBVztBQUFBO0FBQUFTLEtBSHhCWDtBQXFCTixlQUFlQTtBQUFJLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsIkxpbmsiLCJGbHVlbnRMaW5rIiwidXNlTmF2aWdhdGUiLCJwcm9wcyIsIl9zIiwiaHJlZiIsIm90aGVyUHJvcHMiLCJuYXZpZ2F0ZSIsImhhbmRsZUNsaWNrIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGluay50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9saW5rL0xpbmsudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBMaW5rIGFzIEZsdWVudExpbmssIElMaW5rUHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmNvbnN0IExpbms6IEZDPElMaW5rUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgaHJlZiwgLi4ub3RoZXJQcm9wcyB9ID0gcHJvcHNcblxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcblxuICBjb25zdCBoYW5kbGVDbGljayA9IHVzZUNhbGxiYWNrKChldmVudDogTW91c2VFdmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoaHJlZikge1xuICAgICAgbmF2aWdhdGUoaHJlZilcbiAgICB9XG4gIH0sIFtocmVmXSlcblxuICByZXR1cm4gKFxuICAgIDxGbHVlbnRMaW5rXG4gICAgICBocmVmPXtocmVmfVxuICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XG4gICAgICB7Li4ub3RoZXJQcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IExpbmtcbiJdfQ==