import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractDetailsCard.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { Card } from "/src/shared/components/index.ts?t=1701096626433";
import { ContractConfigurationContext } from "/src/modules/admin/contracts/context/ContractConfigurationPageContext.ts";
import { ContractDetails, ContractEditForm } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
import { useHandleRejection, useTheme } from "/src/shared/hooks/index.ts";
const ContractDetailsCard = () => {
  _s();
  const theme = useTheme();
  const {
    client,
    isEditing,
    contract,
    contractFormData,
    setContractFormData: setContract
  } = useContext(ContractConfigurationContext);
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  useEffect(() => {
    if (!isEditing) {
      setError(void 0);
    }
  }, [isEditing]);
  const setLocalContract = useCallback((newContract) => {
    setContract((contract2) => ({
      ...contract2,
      ...newContract,
      dataInclusao: void 0,
      clienteId: client?.id
    }));
  }, [client]);
  return /* @__PURE__ */ jsxDEV(Card, { background: "#f1f7fa", border: "1px solid #E0EBF1", radius: "4px", boxShadow: "none", children: [
    /* @__PURE__ */ jsxDEV(Text, { block: true, variant: "xLarge", styles: {
      root: {
        paddingBottom: theme.spacing.lg
      }
    }, children: "Detalhes" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    isEditing && contractFormData && /* @__PURE__ */ jsxDEV(ContractEditForm, { formData: contractFormData, onChange: setLocalContract, horizontal: true, apiError: error?.reason ? error?.reason : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx",
      lineNumber: 52,
      columnNumber: 41
    }, this),
    !isEditing && contract && /* @__PURE__ */ jsxDEV(ContractDetails, { data: contract, horizontal: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx",
      lineNumber: 53,
      columnNumber: 34
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx",
    lineNumber: 44,
    columnNumber: 10
  }, this);
};
_s(ContractDetailsCard, "r3gLUCy3mp/i+ILBQOIy4hiAQYY=", false, function() {
  return [useTheme, useHandleRejection];
});
_c = ContractDetailsCard;
export default ContractDetailsCard;
var _c;
$RefreshReg$(_c, "ContractDetailsCard");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractDetailsCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkROLFNBQWFBLFlBQVlDLGFBQWFDLFVBQVVDLGlCQUFpQjtBQUNqRSxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0Msb0NBQW9DO0FBQzdDLFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBRWxELFNBQVNDLG9CQUFvQkMsZ0JBQWdCO0FBRzdDLE1BQU1DLHNCQUEwQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU1DLFFBQVFILFNBQVM7QUFDdkIsUUFBTTtBQUFBLElBQ0pJO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLHFCQUFxQkM7QUFBQUEsRUFDdkIsSUFBSW5CLFdBQVdNLDRCQUE0QjtBQUUzQyxRQUFNLENBQUNjLE9BQU9DLFFBQVEsSUFBSW5CLFNBQWdDO0FBRTFELFFBQU07QUFBQSxJQUNKb0I7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJZCxtQkFBbUI7QUFFdkJOLFlBQVUsTUFBTTtBQUNkbUIscUJBQWlCRCxRQUFRO0FBQ3pCLFdBQU8sTUFBTTtBQUNYRSx5QkFBbUJGLFFBQVE7QUFBQSxJQUM3QjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYmxCLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ1ksV0FBVztBQUNkTSxlQUFTRyxNQUFTO0FBQUEsSUFDcEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1QsU0FBUyxDQUFDO0FBRWQsUUFBTVUsbUJBQW1CeEIsWUFBWSxDQUFDeUIsZ0JBQThCO0FBQ2xFUCxnQkFBWUgsZ0JBQWM7QUFBQSxNQUN4QixHQUFHQTtBQUFBQSxNQUNILEdBQUdVO0FBQUFBLE1BQ0hDLGNBQWNIO0FBQUFBLE1BQ2RJLFdBQVdkLFFBQVFlO0FBQUFBLElBQ3JCLEVBQWU7QUFBQSxFQUNqQixHQUFHLENBQUNmLE1BQU0sQ0FBQztBQUVYLFNBQ0UsdUJBQUMsUUFDQyxZQUFXLFdBQ1gsUUFBTyxxQkFDUCxRQUFPLE9BQ1AsV0FBVSxRQUVWO0FBQUEsMkJBQUMsUUFDQyxPQUFLLE1BQ0wsU0FBUSxVQUNSLFFBQVE7QUFBQSxNQUFFZ0IsTUFBTTtBQUFBLFFBQUVDLGVBQWVsQixNQUFNbUIsUUFBUUM7QUFBQUEsTUFBRztBQUFBLElBQUUsR0FDckQsd0JBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFDQ2xCLGFBQWFFLG9CQUNaLHVCQUFDLG9CQUNDLFVBQVVBLGtCQUNWLFVBQVVRLGtCQUNWLFlBQVUsTUFDVixVQUFVTCxPQUFPYyxTQUFTZCxPQUFPYyxTQUFxQlYsVUFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlrRTtBQUFBLElBR25FLENBQUNULGFBQWFDLFlBQ2IsdUJBQUMsbUJBQ0MsTUFBTUEsVUFDTixZQUFVLFFBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVZO0FBQUEsT0F4QmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFFSjtBQUFDSixHQXJFS0QscUJBQXVCO0FBQUEsVUFDYkQsVUFjVkQsa0JBQWtCO0FBQUE7QUFBQTBCLEtBZmxCeEI7QUF1RU4sZUFBZUE7QUFBbUIsSUFBQXdCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlRleHQiLCJDYXJkIiwiQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dCIsIkNvbnRyYWN0RGV0YWlscyIsIkNvbnRyYWN0RWRpdEZvcm0iLCJ1c2VIYW5kbGVSZWplY3Rpb24iLCJ1c2VUaGVtZSIsIkNvbnRyYWN0RGV0YWlsc0NhcmQiLCJfcyIsInRoZW1lIiwiY2xpZW50IiwiaXNFZGl0aW5nIiwiY29udHJhY3QiLCJjb250cmFjdEZvcm1EYXRhIiwic2V0Q29udHJhY3RGb3JtRGF0YSIsInNldENvbnRyYWN0IiwiZXJyb3IiLCJzZXRFcnJvciIsInJlZ2lzdGVyTGlzdGVuZXIiLCJ1bnJlZ2lzdGVyTGlzdGVuZXIiLCJ1bmRlZmluZWQiLCJzZXRMb2NhbENvbnRyYWN0IiwibmV3Q29udHJhY3QiLCJkYXRhSW5jbHVzYW8iLCJjbGllbnRlSWQiLCJpZCIsInJvb3QiLCJwYWRkaW5nQm90dG9tIiwic3BhY2luZyIsImxnIiwicmVhc29uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cmFjdERldGFpbHNDYXJkLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL2NvbXBvbmVudHMvQ29udHJhY3REZXRhaWxzQ2FyZC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBDb250cmFjdENvbmZpZ3VyYXRpb25Db250ZXh0IH0gZnJvbSAnLi4vY29udGV4dC9Db250cmFjdENvbmZpZ3VyYXRpb25QYWdlQ29udGV4dCdcclxuaW1wb3J0IHsgQ29udHJhY3REZXRhaWxzLCBDb250cmFjdEVkaXRGb3JtIH0gZnJvbSAnLidcclxuaW1wb3J0IENvbnRyYWN0LCB7IEJhc2VDb250cmFjdCB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Db250cmFjdCdcclxuaW1wb3J0IHsgdXNlSGFuZGxlUmVqZWN0aW9uLCB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvZXJyb3JzJ1xyXG5cclxuY29uc3QgQ29udHJhY3REZXRhaWxzQ2FyZDogRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcbiAgY29uc3Qge1xyXG4gICAgY2xpZW50LFxyXG4gICAgaXNFZGl0aW5nLFxyXG4gICAgY29udHJhY3QsXHJcbiAgICBjb250cmFjdEZvcm1EYXRhLFxyXG4gICAgc2V0Q29udHJhY3RGb3JtRGF0YTogc2V0Q29udHJhY3QsXHJcbiAgfSA9IHVzZUNvbnRleHQoQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dClcclxuXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxQcm9taXNlUmVqZWN0aW9uRXZlbnQ+KClcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXJMaXN0ZW5lcixcclxuICAgIHVucmVnaXN0ZXJMaXN0ZW5lcixcclxuICB9ID0gdXNlSGFuZGxlUmVqZWN0aW9uKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB1bnJlZ2lzdGVyTGlzdGVuZXIoc2V0RXJyb3IpXHJcbiAgICB9XHJcbiAgfSwgW3NldEVycm9yXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghaXNFZGl0aW5nKSB7XHJcbiAgICAgIHNldEVycm9yKHVuZGVmaW5lZClcclxuICAgIH1cclxuICB9LCBbaXNFZGl0aW5nXSlcclxuXHJcbiAgY29uc3Qgc2V0TG9jYWxDb250cmFjdCA9IHVzZUNhbGxiYWNrKChuZXdDb250cmFjdDogQmFzZUNvbnRyYWN0KSA9PiB7XHJcbiAgICBzZXRDb250cmFjdChjb250cmFjdCA9PiAoKHtcclxuICAgICAgLi4uY29udHJhY3QsXHJcbiAgICAgIC4uLm5ld0NvbnRyYWN0LFxyXG4gICAgICBkYXRhSW5jbHVzYW86IHVuZGVmaW5lZCxcclxuICAgICAgY2xpZW50ZUlkOiBjbGllbnQ/LmlkIGFzIHN0cmluZyxcclxuICAgIH0pIGFzIENvbnRyYWN0KSlcclxuICB9LCBbY2xpZW50XSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkXHJcbiAgICAgIGJhY2tncm91bmQ9JyNmMWY3ZmEnXHJcbiAgICAgIGJvcmRlcj0nMXB4IHNvbGlkICNFMEVCRjEnXHJcbiAgICAgIHJhZGl1cz0nNHB4J1xyXG4gICAgICBib3hTaGFkb3c9J25vbmUnXHJcbiAgICA+XHJcbiAgICAgIDxUZXh0XHJcbiAgICAgICAgYmxvY2tcclxuICAgICAgICB2YXJpYW50PVwieExhcmdlXCJcclxuICAgICAgICBzdHlsZXM9e3sgcm9vdDogeyBwYWRkaW5nQm90dG9tOiB0aGVtZS5zcGFjaW5nLmxnIH0gfX1cclxuICAgICAgPlxyXG4gICAgICAgIERldGFsaGVzXHJcbiAgICAgIDwvVGV4dD5cclxuICAgICAge2lzRWRpdGluZyAmJiBjb250cmFjdEZvcm1EYXRhICYmIChcclxuICAgICAgICA8Q29udHJhY3RFZGl0Rm9ybVxyXG4gICAgICAgICAgZm9ybURhdGE9e2NvbnRyYWN0Rm9ybURhdGF9XHJcbiAgICAgICAgICBvbkNoYW5nZT17c2V0TG9jYWxDb250cmFjdH1cclxuICAgICAgICAgIGhvcml6b250YWxcclxuICAgICAgICAgIGFwaUVycm9yPXtlcnJvcj8ucmVhc29uID8gZXJyb3I/LnJlYXNvbiBhcyBBcGlFcnJvciA6IHVuZGVmaW5lZH1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7IWlzRWRpdGluZyAmJiBjb250cmFjdCAmJiAoXHJcbiAgICAgICAgPENvbnRyYWN0RGV0YWlsc1xyXG4gICAgICAgICAgZGF0YT17Y29udHJhY3R9XHJcbiAgICAgICAgICBob3Jpem9udGFsXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvQ2FyZD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0RGV0YWlsc0NhcmRcclxuIl19