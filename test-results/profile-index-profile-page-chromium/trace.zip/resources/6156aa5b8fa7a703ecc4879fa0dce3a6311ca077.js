import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { FlexColumn, TextField } from "/src/shared/components/index.ts?t=1701096626433";
const UserAccountConfigurationForgotPasswordFormForm = (props) => {
  const {
    passwordFormData,
    onTextChange
  } = props;
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, width: "100%", children: [
    /* @__PURE__ */ jsxDEV(TextField, { label: "Senha atual", value: passwordFormData?.currentPassword, onChange: onTextChange("currentPassword"), canRevealPassword: true, type: "password" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nova senha", value: passwordFormData?.newPassword, onChange: onTextChange("newPassword"), canRevealPassword: true, type: "password" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Confirme a nova senha", canRevealPassword: true, type: "password", value: passwordFormData?.repeatNewPassword, onChange: onTextChange("repeatNewPassword") }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_c = UserAccountConfigurationForgotPasswordFormForm;
export default UserAccountConfigurationForgotPasswordFormForm;
var _c;
$RefreshReg$(_c, "UserAccountConfigurationForgotPasswordFormForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForgotPasswordForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBR0EsU0FBU0EsWUFBWUMsaUJBQWlCO0FBT3RDLE1BQU1DLGlEQUF1R0MsV0FBVTtBQUNySCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBa0JDO0FBQUFBLEVBQWEsSUFBSUY7QUFFM0MsU0FDRSx1QkFBQyxjQUFXLEtBQU0sSUFBSyxPQUFPLFFBQzVCO0FBQUEsMkJBQUMsYUFDQyxPQUFNLGVBQ04sT0FBT0Msa0JBQWtCRSxpQkFDekIsVUFBVUQsYUFBYSxpQkFBaUIsR0FDeEMsbUJBQWlCLE1BQ2pCLE1BQUssY0FMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2lCO0FBQUEsSUFFakIsdUJBQUMsYUFDQyxPQUFNLGNBQ04sT0FBT0Qsa0JBQWtCRyxhQUN6QixVQUFVRixhQUFhLGFBQWEsR0FDcEMsbUJBQWlCLE1BQ2pCLE1BQUssY0FMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2lCO0FBQUEsSUFFakIsdUJBQUMsYUFDQyxPQUFNLHlCQUNOLG1CQUFpQixNQUNqQixNQUFLLFlBQ0wsT0FBT0Qsa0JBQWtCSSxtQkFDekIsVUFBVUgsYUFBYSxtQkFBbUIsS0FMNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUs4QztBQUFBLE9BcEJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBO0FBRUo7QUFBQ0ksS0E1QktQO0FBOEJOLGVBQWVBO0FBQThDLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGbGV4Q29sdW1uIiwiVGV4dEZpZWxkIiwiVXNlckFjY291bnRDb25maWd1cmF0aW9uRm9yZ290UGFzc3dvcmRGb3JtRm9ybSIsInByb3BzIiwicGFzc3dvcmRGb3JtRGF0YSIsIm9uVGV4dENoYW5nZSIsImN1cnJlbnRQYXNzd29yZCIsIm5ld1Bhc3N3b3JkIiwicmVwZWF0TmV3UGFzc3dvcmQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlckFjY291bnRDb25maWd1cmF0aW9uRm9yZ290UGFzc3dvcmRGb3JtLnRzeCIsInNvdXJjZXNDb250ZW50IjpbIi8vIFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybVxuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENoYW5nZVBhc3N3b3JkTG9nZ2VkRFRPIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9lbnRpdGllcydcbmltcG9ydCB7IEZsZXhDb2x1bW4sIFRleHRGaWVsZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybVByb3BzIHtcbiAgcGFzc3dvcmRGb3JtRGF0YTogQ2hhbmdlUGFzc3dvcmRMb2dnZWREVE9cbiAgb25UZXh0Q2hhbmdlOiAoa2V5OiBrZXlvZiBDaGFuZ2VQYXNzd29yZExvZ2dlZERUTykgPT4gKF8/OiB1bmtub3duLCB2YWx1ZT86IHN0cmluZyB8IHVuZGVmaW5lZCkgPT4gdm9pZFxufVxuXG5jb25zdCBVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3Jnb3RQYXNzd29yZEZvcm1Gb3JtOiBGQzxVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3Jnb3RQYXNzd29yZEZvcm1Qcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBwYXNzd29yZEZvcm1EYXRhLCBvblRleHRDaGFuZ2UgfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9IHdpZHRoPXsnMTAwJSd9PlxuICAgICAgPFRleHRGaWVsZFxuICAgICAgICBsYWJlbD1cIlNlbmhhIGF0dWFsXCJcbiAgICAgICAgdmFsdWU9e3Bhc3N3b3JkRm9ybURhdGE/LmN1cnJlbnRQYXNzd29yZH1cbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnY3VycmVudFBhc3N3b3JkJyl9XG4gICAgICAgIGNhblJldmVhbFBhc3N3b3JkXG4gICAgICAgIHR5cGU9J3Bhc3N3b3JkJ1xuICAgICAgLz5cbiAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgbGFiZWw9XCJOb3ZhIHNlbmhhXCJcbiAgICAgICAgdmFsdWU9e3Bhc3N3b3JkRm9ybURhdGE/Lm5ld1Bhc3N3b3JkfVxuICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCduZXdQYXNzd29yZCcpfVxuICAgICAgICBjYW5SZXZlYWxQYXNzd29yZFxuICAgICAgICB0eXBlPSdwYXNzd29yZCdcbiAgICAgIC8+XG4gICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsPVwiQ29uZmlybWUgYSBub3ZhIHNlbmhhXCJcbiAgICAgICAgY2FuUmV2ZWFsUGFzc3dvcmRcbiAgICAgICAgdHlwZT0ncGFzc3dvcmQnXG4gICAgICAgIHZhbHVlPXtwYXNzd29yZEZvcm1EYXRhPy5yZXBlYXROZXdQYXNzd29yZH1cbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgncmVwZWF0TmV3UGFzc3dvcmQnKX1cbiAgICAgIC8+XG4gICAgPC9GbGV4Q29sdW1uPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcmdvdFBhc3N3b3JkRm9ybUZvcm1cbiJdfQ==