export default function selectFile(multipleSelect, accept) {
  return new Promise((resolve) => {
    const fileInput = document.createElement("input");
    fileInput.setAttribute("type", "file");
    if (accept) {
      fileInput.setAttribute("accept", accept);
    }
    if (multipleSelect) {
      fileInput.setAttribute("multiple", "multiple");
    }
    window.addEventListener("focus", () => {
      setTimeout(() => {
        if (fileInput.files?.length === 0) {
          resolve(fileInput.files);
        }
      }, 1e3);
    }, { once: true });
    fileInput.addEventListener("change", (event) => {
      const target = event.target;
      if (target.files && target.files.length >= 1) {
        resolve(target.files);
      }
    }, { once: true });
    fileInput.click();
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdEZpbGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2VsZWN0RmlsZSAobXVsdGlwbGVTZWxlY3Q/OiBib29sZWFuLCBhY2NlcHQ/OiBzdHJpbmcpOiBQcm9taXNlPEZpbGVMaXN0PiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIGNvbnN0IGZpbGVJbnB1dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0JylcbiAgICBmaWxlSW5wdXQuc2V0QXR0cmlidXRlKCd0eXBlJywgJ2ZpbGUnKVxuICAgIGlmIChhY2NlcHQpIHtcbiAgICAgIGZpbGVJbnB1dC5zZXRBdHRyaWJ1dGUoJ2FjY2VwdCcsIGFjY2VwdClcbiAgICB9XG4gICAgaWYgKG11bHRpcGxlU2VsZWN0KSB7XG4gICAgICBmaWxlSW5wdXQuc2V0QXR0cmlidXRlKCdtdWx0aXBsZScsICdtdWx0aXBsZScpXG4gICAgfVxuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywgKCkgPT4ge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmIChmaWxlSW5wdXQuZmlsZXM/Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgIHJlc29sdmUoZmlsZUlucHV0LmZpbGVzKVxuICAgICAgICB9XG4gICAgICB9LCAxMDAwKVxuICAgIH0sIHsgb25jZTogdHJ1ZSB9KVxuXG4gICAgZmlsZUlucHV0LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIChldmVudDogRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50XG4gICAgICBpZiAodGFyZ2V0LmZpbGVzICYmIHRhcmdldC5maWxlcy5sZW5ndGggPj0gMSkge1xuICAgICAgICByZXNvbHZlKHRhcmdldC5maWxlcylcbiAgICAgIH1cbiAgICB9LCB7IG9uY2U6IHRydWUgfSlcblxuICAgIGZpbGVJbnB1dC5jbGljaygpXG4gIH0pXG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixXQUFZLGdCQUEwQixRQUFvQztBQUNoRyxTQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsVUFBTSxZQUFZLFNBQVMsY0FBYyxPQUFPO0FBQ2hELGNBQVUsYUFBYSxRQUFRLE1BQU07QUFDckMsUUFBSSxRQUFRO0FBQ1YsZ0JBQVUsYUFBYSxVQUFVLE1BQU07QUFBQSxJQUN6QztBQUNBLFFBQUksZ0JBQWdCO0FBQ2xCLGdCQUFVLGFBQWEsWUFBWSxVQUFVO0FBQUEsSUFDL0M7QUFFQSxXQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsaUJBQVcsTUFBTTtBQUNmLFlBQUksVUFBVSxPQUFPLFdBQVcsR0FBRztBQUNqQyxrQkFBUSxVQUFVLEtBQUs7QUFBQSxRQUN6QjtBQUFBLE1BQ0YsR0FBRyxHQUFJO0FBQUEsSUFDVCxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFFakIsY0FBVSxpQkFBaUIsVUFBVSxDQUFDLFVBQWlCO0FBQ3JELFlBQU0sU0FBUyxNQUFNO0FBQ3JCLFVBQUksT0FBTyxTQUFTLE9BQU8sTUFBTSxVQUFVLEdBQUc7QUFDNUMsZ0JBQVEsT0FBTyxLQUFLO0FBQUEsTUFDdEI7QUFBQSxJQUNGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUVqQixjQUFVLE1BQU07QUFBQSxFQUNsQixDQUFDO0FBQ0g7IiwibmFtZXMiOltdfQ==