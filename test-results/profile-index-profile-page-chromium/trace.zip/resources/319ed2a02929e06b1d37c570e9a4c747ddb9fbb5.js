export var analyticalRevisionType = /* @__PURE__ */ ((analyticalRevisionType2) => {
  analyticalRevisionType2[analyticalRevisionType2["patrimonial"] = 1] = "patrimonial";
  analyticalRevisionType2[analyticalRevisionType2["result"] = 2] = "result";
  return analyticalRevisionType2;
})(analyticalRevisionType || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuYWx5dGljYWxSZXZpc2lvblR5cGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGVudW0gYW5hbHl0aWNhbFJldmlzaW9uVHlwZSB7XG4gIHBhdHJpbW9uaWFsID0gMSxcbiAgcmVzdWx0ID0gMixcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQU8sV0FBVyx5QkFBWCxrQkFBV0EsNEJBQVg7QUFDTCxFQUFBQSxnREFBQSxpQkFBYyxLQUFkO0FBQ0EsRUFBQUEsZ0RBQUEsWUFBUyxLQUFUO0FBRmdCLFNBQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6WyJhbmFseXRpY2FsUmV2aXNpb25UeXBlIl19