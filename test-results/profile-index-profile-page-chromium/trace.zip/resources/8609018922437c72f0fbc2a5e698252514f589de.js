import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];
export const useDidMountEffect = (func, deps) => {
  const didMount = useRef(false);
  useEffect(() => {
    if (didMount.current)
      func();
    else
      didMount.current = true;
  }, deps);
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRpZE1vdW50RWZmZWN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERlcGVuZGVuY3lMaXN0LCBFZmZlY3RDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGNvbnN0IHVzZURpZE1vdW50RWZmZWN0ID0gKGZ1bmM6IEVmZmVjdENhbGxiYWNrLCBkZXBzOiBEZXBlbmRlbmN5TGlzdCk6IHZvaWQgPT4ge1xuICBjb25zdCBkaWRNb3VudCA9IHVzZVJlZihmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaWRNb3VudC5jdXJyZW50KSBmdW5jKClcbiAgICBlbHNlIGRpZE1vdW50LmN1cnJlbnQgPSB0cnVlXG4gIH0sIGRlcHMpXG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQXlDLFdBQVcsY0FBYztBQUUzRCxhQUFNLG9CQUFvQixDQUFDLE1BQXNCLFNBQStCO0FBQ3JGLFFBQU0sV0FBVyxPQUFPLEtBQUs7QUFFN0IsWUFBVSxNQUFNO0FBQ2QsUUFBSSxTQUFTO0FBQVMsV0FBSztBQUFBO0FBQ3RCLGVBQVMsVUFBVTtBQUFBLEVBQzFCLEdBQUcsSUFBSTtBQUNUOyIsIm5hbWVzIjpbXX0=