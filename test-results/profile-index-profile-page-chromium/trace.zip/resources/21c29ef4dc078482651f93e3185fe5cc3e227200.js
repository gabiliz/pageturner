import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserDetails.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Text, Label } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { UserAvatar } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { RoleName } from "/src/modules/admin/roles/components/index.ts?t=1701096626433";
import { OfficeNameList } from "/src/modules/admin/offices/components/index.ts?t=1701096626433";
import { ProfileName } from "/src/modules/admin/profiles/components/index.ts?t=1701096626433";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { Checkbox, FlexColumn, FlexItem, FlexRow } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
const UserDetails = (props) => {
  _s();
  const {
    data
  } = props;
  const theme = useTheme();
  const {
    currentAccount
  } = useAuth();
  const officesIds = useMemo(() => {
    return data.escritorios?.map((office) => office.escritorioId) ?? [];
  }, [data]);
  const roleId = useMemo(() => {
    return data.cargos?.length !== 0 && data.cargos?.[data.cargos.length - 1] ? data.cargos[data.cargos.length - 1].cargoId : "";
  }, [data]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "flex-end", gap: theme.spacing.xl, children: [
      /* @__PURE__ */ jsxDEV(UserAvatar, { image: data.image }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Apelido" }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 33,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Text, { children: data.apelido }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 34,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Atuações" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.lg, children: [
        /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Sócio", disabled: true, checked: data.socio }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 41,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 40,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Responsável por relatório", disabled: true, checked: data.responsavelRelatorio }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 44,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 43,
          columnNumber: 11
        }, this),
        (currentAccount.value?.id === data.id && data.desenvolvedor || currentAccount.value?.administrator) && /* @__PURE__ */ jsxDEV(FlexItem, { grow: 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Desenvolvedor", disabled: true, checked: data.desenvolvedor }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 46,
          columnNumber: 115
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Nome completo" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.nome }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Data de nascimento" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.dataNascimento && format(new Date(data.dataNascimento), "dd/MM/yyyy") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Data de admissão" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.dataAdmissao && format(new Date(data.dataAdmissao), "dd/MM/yyyy") }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "E-mail" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.email }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 65,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Telefone" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 68,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.phoneNumber }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 69,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Perfil" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ProfileName, { id: data.perfilId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 71,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Status" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { children: data.status ? "Habilitado" : "Desabilitado" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Escritório" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(OfficeNameList, { ids: officesIds }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 81,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Cargo" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: theme.spacing.xxl, children: /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: roleId && /* @__PURE__ */ jsxDEV(RoleName, { id: roleId }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 87,
        columnNumber: 24
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 86,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Possui veículo", checked: data.possuiVeiculo }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 92,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: [
      /* @__PURE__ */ jsxDEV(Label, {}, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Checkbox, { label: "Registro CRC", checked: data.possuiCrc, styles: {
        root: {
          marginTop: theme.spacing.xs,
          marginBottom: theme.spacing.xs
        }
      } }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 96,
        columnNumber: 9
      }, this),
      data.possuiCrc && /* @__PURE__ */ jsxDEV(Text, { children: data.nroCrc }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 102,
        columnNumber: 28
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.xs, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Registro CNAI" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "QTG", checked: data.possuiCnaiQtg }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 107,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "BACEN", checked: data.possuiCnaiBacen }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 108,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "SUSEP", checked: data.possuiCnaiSusep }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "CVM", checked: data.possuiCnaiCvm }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 110,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Checkbox, { label: "PREVIC", checked: data.possuiCnaiPrevic }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
};
_s(UserDetails, "SmVxLT4wxdIksXPMQvLrTyJ9kn8=", false, function() {
  return [useTheme, useAuth];
});
_c = UserDetails;
export default UserDetails;
var _c;
$RefreshReg$(_c, "UserDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NROzs7Ozs7Ozs7Ozs7Ozs7O0FBbENSLFNBQWFBLGVBQWU7QUFHNUIsU0FBU0MsTUFBTUMsYUFBYTtBQUM1QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFVBQVVDLFlBQVlDLFVBQVVDLGVBQWU7QUFDeEQsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGNBQTJDQyxXQUFVO0FBQUFDLEtBQUE7QUFDekQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQUssSUFBSUY7QUFDakIsUUFBTUcsUUFBUUwsU0FBUztBQUN2QixRQUFNO0FBQUEsSUFBRU07QUFBQUEsRUFBZSxJQUFJWCxRQUFRO0FBRW5DLFFBQU1ZLGFBQWFwQixRQUFRLE1BQU07QUFDL0IsV0FBT2lCLEtBQUtJLGFBQWFDLElBQUtDLFlBQVdBLE9BQU9DLFlBQVksS0FBSztBQUFBLEVBQ25FLEdBQUcsQ0FBQ1AsSUFBSSxDQUFDO0FBRVQsUUFBTVEsU0FBU3pCLFFBQVEsTUFBTTtBQUMzQixXQUFPaUIsS0FBS1MsUUFBUUMsV0FBVyxLQUFLVixLQUFLUyxTQUFTVCxLQUFLUyxPQUFPQyxTQUFTLENBQUMsSUFDcEVWLEtBQUtTLE9BQU9ULEtBQUtTLE9BQU9DLFNBQVMsQ0FBQyxFQUFFQyxVQUNwQztBQUFBLEVBQ04sR0FBRyxDQUFDWCxJQUFJLENBQUM7QUFFVCxTQUNFLHVCQUFDLGNBQVcsS0FBTSxJQUNoQjtBQUFBLDJCQUFDLFdBQ0MsZUFBYyxZQUNkLEtBQU1DLE1BQU1XLFFBQVFDLElBRXBCO0FBQUEsNkJBQUMsY0FBVyxPQUFPYixLQUFLYyxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFDOUIsdUJBQUMsWUFBUyxNQUFNLEdBQ2Q7QUFBQSwrQkFBQyxTQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsUUFBTWQsZUFBS2UsV0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsV0FGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLGNBQ0M7QUFBQSw2QkFBQyxTQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsV0FBUSxLQUFLZCxNQUFNVyxRQUFRSSxJQUMxQjtBQUFBLCtCQUFDLFlBQVMsTUFBTSxHQUNkLGlDQUFDLFlBQ0MsT0FBTSxTQUNOLFVBQVEsTUFDUixTQUFTaEIsS0FBS2lCLFNBSGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHc0IsS0FKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxZQUFTLE1BQU0sR0FDZCxpQ0FBQyxZQUNDLE9BQU0sNkJBQ04sVUFBUSxNQUNSLFNBQVNqQixLQUFLa0Isd0JBSGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHcUMsS0FKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsU0FHSWhCLGVBQWVpQixPQUFPQyxPQUFPcEIsS0FBS29CLE1BQ3BDcEIsS0FBS3FCLGlCQUVMbkIsZUFBZWlCLE9BQU9HLGtCQUNuQix1QkFBQyxZQUFTLE1BQU0sR0FDbkIsaUNBQUMsWUFDQyxPQUFNLGlCQUNOLFVBQVEsTUFDUixTQUFTdEIsS0FBS3FCLGlCQUhoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRzhCLEtBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNTDtBQUFBLFdBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxTQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEIsdUJBQUMsUUFBTXJCLGVBQUt1QixRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxTQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxTQUFNLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxRQUFNdkIsZUFBS3dCLGtCQUFrQmxDLE9BQU8sSUFBSW1DLEtBQUt6QixLQUFLd0IsY0FBYyxHQUFHLFlBQVksS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRjtBQUFBLFNBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsWUFDQztBQUFBLDZCQUFDLFNBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QjtBQUFBLE1BQ3ZCLHVCQUFDLFFBQU14QixlQUFLMEIsZ0JBQWdCcEMsT0FBTyxJQUFJbUMsS0FBS3pCLEtBQUswQixZQUFZLEdBQUcsWUFBWSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThFO0FBQUEsU0FGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUNiLHVCQUFDLFFBQU0xQixlQUFLMkIsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSx3QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmLHVCQUFDLFFBQU0zQixlQUFLNEIsZUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsU0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUNiLHVCQUFDLGVBQVksSUFBSTVCLEtBQUs2QixZQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsU0FGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUNiLHVCQUFDLFFBQU03QixlQUFLOEIsU0FBUyxlQUFlLGtCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsa0JBQWUsS0FBSzNCLGNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxTQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxTQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLE1BQ1osdUJBQUMsV0FDQyxlQUFjLFVBQ2QsS0FBTUYsTUFBTVcsUUFBUW1CLEtBRXBCLGlDQUFDLFlBQVMsTUFBTSxHQUNidkIsb0JBQVUsdUJBQUMsWUFBUyxJQUFJQSxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUIsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFlBQVMsTUFBTSxHQUNkLGlDQUFDLFlBQ0MsT0FBTSxrQkFDTixTQUFTUixLQUFLZ0MsaUJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFOEIsS0FIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU87QUFBQSxNQUNQLHVCQUFDLFlBQ0MsT0FBTSxnQkFDTixTQUFTaEMsS0FBS2lDLFdBQ2QsUUFBUTtBQUFBLFFBQ05DLE1BQU07QUFBQSxVQUNKQyxXQUFXbEMsTUFBTVcsUUFBUXdCO0FBQUFBLFVBQ3pCQyxjQUFjcEMsTUFBTVcsUUFBUXdCO0FBQUFBLFFBQzlCO0FBQUEsTUFDRixLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRSTtBQUFBLE1BRUhwQyxLQUFLaUMsYUFBYSx1QkFBQyxRQUFNakMsZUFBS3NDLFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLFNBWnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxLQUFNckMsTUFBTVcsUUFBUXdCLElBQzlCO0FBQUEsNkJBQUMsU0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEIsdUJBQUMsY0FBVyxLQUFNLElBQ2hCO0FBQUEsK0JBQUMsWUFDQyxPQUFNLE9BQ04sU0FBU3BDLEtBQUt1QyxpQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUU4QjtBQUFBLFFBRTlCLHVCQUFDLFlBQ0MsT0FBTSxTQUNOLFNBQVN2QyxLQUFLd0MsbUJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFZ0M7QUFBQSxRQUVoQyx1QkFBQyxZQUNDLE9BQU0sU0FDTixTQUFTeEMsS0FBS3lDLG1CQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRWdDO0FBQUEsUUFFaEMsdUJBQUMsWUFDQyxPQUFNLE9BQ04sU0FBU3pDLEtBQUswQyxpQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUU4QjtBQUFBLFFBRTlCLHVCQUFDLFlBQ0MsT0FBTSxVQUNOLFNBQVMxQyxLQUFLMkMsb0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFaUM7QUFBQSxXQW5CbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxPQWxJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUlBO0FBRUo7QUFBQzVDLEdBckpLRixhQUF1QztBQUFBLFVBRTdCRCxVQUNhTCxPQUFPO0FBQUE7QUFBQXFELEtBSDlCL0M7QUF1Sk4sZUFBZUE7QUFBVyxJQUFBK0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJUZXh0IiwiTGFiZWwiLCJVc2VyQXZhdGFyIiwiUm9sZU5hbWUiLCJPZmZpY2VOYW1lTGlzdCIsIlByb2ZpbGVOYW1lIiwiZm9ybWF0IiwidXNlQXV0aCIsIkNoZWNrYm94IiwiRmxleENvbHVtbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsInVzZVRoZW1lIiwiVXNlckRldGFpbHMiLCJwcm9wcyIsIl9zIiwiZGF0YSIsInRoZW1lIiwiY3VycmVudEFjY291bnQiLCJvZmZpY2VzSWRzIiwiZXNjcml0b3Jpb3MiLCJtYXAiLCJvZmZpY2UiLCJlc2NyaXRvcmlvSWQiLCJyb2xlSWQiLCJjYXJnb3MiLCJsZW5ndGgiLCJjYXJnb0lkIiwic3BhY2luZyIsInhsIiwiaW1hZ2UiLCJhcGVsaWRvIiwibGciLCJzb2NpbyIsInJlc3BvbnNhdmVsUmVsYXRvcmlvIiwidmFsdWUiLCJpZCIsImRlc2Vudm9sdmVkb3IiLCJhZG1pbmlzdHJhdG9yIiwibm9tZSIsImRhdGFOYXNjaW1lbnRvIiwiRGF0ZSIsImRhdGFBZG1pc3NhbyIsImVtYWlsIiwicGhvbmVOdW1iZXIiLCJwZXJmaWxJZCIsInN0YXR1cyIsInh4bCIsInBvc3N1aVZlaWN1bG8iLCJwb3NzdWlDcmMiLCJyb290IiwibWFyZ2luVG9wIiwieHMiLCJtYXJnaW5Cb3R0b20iLCJucm9DcmMiLCJwb3NzdWlDbmFpUXRnIiwicG9zc3VpQ25haUJhY2VuIiwicG9zc3VpQ25haVN1c2VwIiwicG9zc3VpQ25haUN2bSIsInBvc3N1aUNuYWlQcmV2aWMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJEZXRhaWxzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vdXNlcnMvY29tcG9uZW50cy9Vc2VyRGV0YWlscy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFVzZXIgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXInXG5pbXBvcnQgeyBEZXRhaWxzVmlld1Byb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3R5cGVzL0RldGFpbHNWaWV3J1xuaW1wb3J0IHsgVGV4dCwgTGFiZWwgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBVc2VyQXZhdGFyIH0gZnJvbSAnLidcbmltcG9ydCB7IFJvbGVOYW1lIH0gZnJvbSAnLi4vLi4vcm9sZXMvY29tcG9uZW50cydcbmltcG9ydCB7IE9mZmljZU5hbWVMaXN0IH0gZnJvbSAnLi4vLi4vb2ZmaWNlcy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgUHJvZmlsZU5hbWUgfSBmcm9tICcuLi8uLi9wcm9maWxlcy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgZm9ybWF0IH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zdG9yZS9hdXRoJ1xuaW1wb3J0IHsgQ2hlY2tib3gsIEZsZXhDb2x1bW4sIEZsZXhJdGVtLCBGbGV4Um93IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcblxuY29uc3QgVXNlckRldGFpbHM6IEZDPERldGFpbHNWaWV3UHJvcHM8VXNlcj4+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gcHJvcHNcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXG4gIGNvbnN0IHsgY3VycmVudEFjY291bnQgfSA9IHVzZUF1dGgoKVxuXG4gIGNvbnN0IG9mZmljZXNJZHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZGF0YS5lc2NyaXRvcmlvcz8ubWFwKChvZmZpY2UpID0+IG9mZmljZS5lc2NyaXRvcmlvSWQpID8/IFtdXG4gIH0sIFtkYXRhXSlcblxuICBjb25zdCByb2xlSWQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZGF0YS5jYXJnb3M/Lmxlbmd0aCAhPT0gMCAmJiBkYXRhLmNhcmdvcz8uW2RhdGEuY2FyZ29zLmxlbmd0aCAtIDFdXG4gICAgICA/IGRhdGEuY2FyZ29zW2RhdGEuY2FyZ29zLmxlbmd0aCAtIDFdLmNhcmdvSWRcbiAgICAgIDogJydcbiAgfSwgW2RhdGFdKVxuXG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW4gZ2FwPXsgMTIgfT5cbiAgICAgIDxGbGV4Um93XG4gICAgICAgIHZlcnRpY2FsQWxpZ249XCJmbGV4LWVuZFwiXG4gICAgICAgIGdhcD17IHRoZW1lLnNwYWNpbmcueGwgfVxuICAgICAgPlxuICAgICAgICA8VXNlckF2YXRhciBpbWFnZT17ZGF0YS5pbWFnZX0gLz5cbiAgICAgICAgPEZsZXhJdGVtIGdyb3c9ezF9PlxuICAgICAgICAgIDxMYWJlbD5BcGVsaWRvPC9MYWJlbD5cbiAgICAgICAgICA8VGV4dD57ZGF0YS5hcGVsaWRvfTwvVGV4dD5cbiAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDwvRmxleFJvdz5cbiAgICAgIDxGbGV4Q29sdW1uPlxuICAgICAgICA8TGFiZWw+QXR1YcOnw7VlczwvTGFiZWw+XG4gICAgICAgIDxGbGV4Um93IGdhcD17dGhlbWUuc3BhY2luZy5sZ30+XG4gICAgICAgICAgPEZsZXhJdGVtIGdyb3c9ezB9PlxuICAgICAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgICAgIGxhYmVsPVwiU8OzY2lvXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWRcbiAgICAgICAgICAgICAgY2hlY2tlZD17ZGF0YS5zb2Npb31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgICAgICA8RmxleEl0ZW0gZ3Jvdz17MH0+XG4gICAgICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICAgICAgbGFiZWw9XCJSZXNwb25zw6F2ZWwgcG9yIHJlbGF0w7NyaW9cIlxuICAgICAgICAgICAgICBkaXNhYmxlZFxuICAgICAgICAgICAgICBjaGVja2VkPXtkYXRhLnJlc3BvbnNhdmVsUmVsYXRvcmlvfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0ZsZXhJdGVtPlxuICAgICAgICAgIHsoXG4gICAgICAgICAgICAoXG4gICAgICAgICAgICAgIGN1cnJlbnRBY2NvdW50LnZhbHVlPy5pZCA9PT0gZGF0YS5pZCAmJlxuICAgICAgICAgICAgZGF0YS5kZXNlbnZvbHZlZG9yXG4gICAgICAgICAgICApIHx8XG4gICAgICAgICAgICBjdXJyZW50QWNjb3VudC52YWx1ZT8uYWRtaW5pc3RyYXRvclxuICAgICAgICAgICkgJiYgPEZsZXhJdGVtIGdyb3c9ezB9PlxuICAgICAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgICAgIGxhYmVsPVwiRGVzZW52b2x2ZWRvclwiXG4gICAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e2RhdGEuZGVzZW52b2x2ZWRvcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GbGV4SXRlbT59XG4gICAgICAgIDwvRmxleFJvdz5cbiAgICAgIDwvRmxleENvbHVtbj5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPk5vbWUgY29tcGxldG88L0xhYmVsPlxuICAgICAgICA8VGV4dD57ZGF0YS5ub21lfTwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD5EYXRhIGRlIG5hc2NpbWVudG88L0xhYmVsPlxuICAgICAgICA8VGV4dD57ZGF0YS5kYXRhTmFzY2ltZW50byAmJiBmb3JtYXQobmV3IERhdGUoZGF0YS5kYXRhTmFzY2ltZW50byksICdkZC9NTS95eXl5Jyl9PC9UZXh0PlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPkRhdGEgZGUgYWRtaXNzw6NvPC9MYWJlbD5cbiAgICAgICAgPFRleHQ+e2RhdGEuZGF0YUFkbWlzc2FvICYmIGZvcm1hdChuZXcgRGF0ZShkYXRhLmRhdGFBZG1pc3NhbyksICdkZC9NTS95eXl5Jyl9PC9UZXh0PlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPkUtbWFpbDwvTGFiZWw+XG4gICAgICAgIDxUZXh0PntkYXRhLmVtYWlsfTwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD5UZWxlZm9uZTwvTGFiZWw+XG4gICAgICAgIDxUZXh0PntkYXRhLnBob25lTnVtYmVyfTwvVGV4dD5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD5QZXJmaWw8L0xhYmVsPlxuICAgICAgICA8UHJvZmlsZU5hbWUgaWQ9e2RhdGEucGVyZmlsSWR9IC8+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8TGFiZWw+U3RhdHVzPC9MYWJlbD5cbiAgICAgICAgPFRleHQ+e2RhdGEuc3RhdHVzID8gJ0hhYmlsaXRhZG8nIDogJ0Rlc2FiaWxpdGFkbyd9PC9UZXh0PlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgPExhYmVsPkVzY3JpdMOzcmlvPC9MYWJlbD5cbiAgICAgICAgPE9mZmljZU5hbWVMaXN0IGlkcz17b2ZmaWNlc0lkc30gLz5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD5DYXJnbzwvTGFiZWw+XG4gICAgICAgIDxGbGV4Um93XG4gICAgICAgICAgdmVydGljYWxBbGlnbj1cImNlbnRlclwiXG4gICAgICAgICAgZ2FwPXsgdGhlbWUuc3BhY2luZy54eGwgfVxuICAgICAgICA+XG4gICAgICAgICAgPEZsZXhJdGVtIGdyb3c9ezF9PlxuICAgICAgICAgICAge3JvbGVJZCAmJiA8Um9sZU5hbWUgaWQ9e3JvbGVJZH0gLz59XG4gICAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgICAgPC9GbGV4Um93PlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDxGbGV4SXRlbSBncm93PXsxfT5cbiAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgbGFiZWw9XCJQb3NzdWkgdmXDrWN1bG9cIlxuICAgICAgICAgIGNoZWNrZWQ9e2RhdGEucG9zc3VpVmVpY3Vsb31cbiAgICAgICAgLz5cbiAgICAgIDwvRmxleEl0ZW0+XG4gICAgICA8RmxleEl0ZW0+XG4gICAgICAgIDxMYWJlbD48L0xhYmVsPlxuICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICBsYWJlbD1cIlJlZ2lzdHJvIENSQ1wiXG4gICAgICAgICAgY2hlY2tlZD17ZGF0YS5wb3NzdWlDcmN9XG4gICAgICAgICAgc3R5bGVzPXt7XG4gICAgICAgICAgICByb290OiB7XG4gICAgICAgICAgICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZy54cyxcbiAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiB0aGVtZS5zcGFjaW5nLnhzLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgICB7ZGF0YS5wb3NzdWlDcmMgJiYgPFRleHQ+e2RhdGEubnJvQ3JjfTwvVGV4dD59XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPEZsZXhDb2x1bW4gZ2FwPXsgdGhlbWUuc3BhY2luZy54cyB9PlxuICAgICAgICA8TGFiZWw+UmVnaXN0cm8gQ05BSTwvTGFiZWw+XG4gICAgICAgIDxGbGV4Q29sdW1uIGdhcD17IDEyIH0+XG4gICAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgICBsYWJlbD0nUVRHJ1xuICAgICAgICAgICAgY2hlY2tlZD17ZGF0YS5wb3NzdWlDbmFpUXRnfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgICBsYWJlbD0nQkFDRU4nXG4gICAgICAgICAgICBjaGVja2VkPXtkYXRhLnBvc3N1aUNuYWlCYWNlbn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxDaGVja2JveFxuICAgICAgICAgICAgbGFiZWw9J1NVU0VQJ1xuICAgICAgICAgICAgY2hlY2tlZD17ZGF0YS5wb3NzdWlDbmFpU3VzZXB9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICAgIGxhYmVsPSdDVk0nXG4gICAgICAgICAgICBjaGVja2VkPXtkYXRhLnBvc3N1aUNuYWlDdm19XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICAgIGxhYmVsPSdQUkVWSUMnXG4gICAgICAgICAgICBjaGVja2VkPXtkYXRhLnBvc3N1aUNuYWlQcmV2aWN9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAgPC9GbGV4Q29sdW1uPlxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBVc2VyRGV0YWlsc1xuIl19