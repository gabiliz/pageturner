import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTableInt.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { DataTableContent, DataTablePagination, DataTableSearch, DataTableFilterGroups, DataTableEmptyState } from "/src/shared/components/datatable/index.ts?t=1701096626433";
import { LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { debounce } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
import FlexRow from "/src/shared/components/FlexBox/FlexRow.tsx";
import { ControlsColumnNameEnum } from "/src/shared/enums/ControlsColumnNameEnum.ts";
function DataTableInt(props) {
  _s();
  const theme = useTheme();
  const {
    columns,
    items,
    itemsCount,
    paginated,
    onPageChange,
    sortConfig,
    onSortChange,
    onSearchTextChange,
    onFilterGroupChange,
    loading = false,
    hasSearch,
    renderActions,
    hasControlsColumn,
    menuOptions,
    onRenderMenuItem,
    multipleSelection,
    selection,
    onSelection,
    hasSelection,
    hiddenMenu,
    customPageOptions,
    renderExtraElement,
    controlsColumnName = ControlsColumnNameEnum.CONTROLS,
    onSingleActionControlClick,
    disableMenu,
    disableMenuText,
    onMenuOpened,
    onMenuDismissed
  } = props;
  const [itemsCountCache, setItemsCountCache] = useState(0);
  const [pageSizeCache, setPageSizeCache] = useState(0);
  const styles = useDataTableIntStyles();
  const hasFilter = useMemo(() => {
    return !!columns && columns.some((column) => column.filterOptions?.isGroupMode);
  }, [columns, items]);
  useEffect(() => {
    if (items) {
      setPageSizeCache(items.length);
    }
  }, [items]);
  useEffect(() => {
    if (itemsCount) {
      setItemsCountCache(itemsCount);
    }
  }, [itemsCount]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.lg, className: styles.dataTable, children: [
    /* @__PURE__ */ jsxDEV(FlexRow, { horizontalAlign: "space-between", children: [
      !hiddenMenu && /* @__PURE__ */ jsxDEV(FlexRow, { styles: {
        flexGrow: 1
      }, gap: theme.spacing.lg, children: renderActions?.() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
        lineNumber: 94,
        columnNumber: 25
      }, this),
      hasSearch && onSearchTextChange && /* @__PURE__ */ jsxDEV(DataTableSearch, { onChange: debounce(onSearchTextChange, 300) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
        lineNumber: 99,
        columnNumber: 45
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
      lineNumber: 93,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.lg, children: [
      /* @__PURE__ */ jsxDEV(FlexColumn, { gap: theme.spacing.sm, children: [
        hasFilter && onFilterGroupChange && /* @__PURE__ */ jsxDEV(DataTableFilterGroups, { columns, onQueryChange: onFilterGroupChange }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
          lineNumber: 103,
          columnNumber: 48
        }, this),
        !!renderExtraElement && items && items?.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: renderExtraElement }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
          lineNumber: 104,
          columnNumber: 66
        }, this),
        loading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
          lineNumber: 107,
          columnNumber: 23
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      !loading && items && items.length > 0 && /* @__PURE__ */ jsxDEV(DataTableContent, { compact: true, onSingleActionControlClick, controlsColumnName, columns, items, onHeaderClick: onSortChange, sortConfig, multipleSelection, selection, onSelection, hasControlsColumn, menuOptions, onRenderMenuItem, hasSelection, disableMenu, disableMenuText, onMenuOpened, onMenuDismissed }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
        lineNumber: 109,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    !loading && items && items.length === 0 && /* @__PURE__ */ jsxDEV(DataTableEmptyState, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
      lineNumber: 111,
      columnNumber: 51
    }, this),
    paginated && onPageChange && /* @__PURE__ */ jsxDEV(DataTablePagination, { pageItemsCount: pageSizeCache, totalItemsCount: itemsCountCache, onPageChange, customPageOptions }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
      lineNumber: 112,
      columnNumber: 37
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx",
    lineNumber: 92,
    columnNumber: 10
  }, this);
}
_s(DataTableInt, "W1cA4sCeqpT3Qyl7G4j2rGoqhdE=", false, function() {
  return [useTheme, useDataTableIntStyles];
});
_c = DataTableInt;
const useDataTableIntStyles = () => {
  return mergeStyleSets({
    dataTable: {
      overflow: "hidden"
    }
  });
};
export default DataTableInt;
var _c;
$RefreshReg$(_c, "DataTableInt");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableInt.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0h3QixTQW1CWixVQW5CWTs7Ozs7Ozs7Ozs7Ozs7OztBQWhIeEIsU0FBU0EsVUFBVUMsV0FBeUJDLGVBQTBCO0FBQ3RFLFNBQStDQyxzQkFBdUM7QUFFdEYsU0FDRUMsa0JBQ0FDLHFCQUNBQyxpQkFJQUMsdUJBQ0FDLDJCQUNLO0FBQ1AsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsOEJBQThCO0FBa0N2QyxTQUFTQyxhQUFnQ0MsT0FBMkM7QUFBQUMsS0FBQTtBQUNsRixRQUFNQyxRQUFRUCxTQUFTO0FBQ3ZCLFFBQU07QUFBQSxJQUNKUTtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxVQUFVO0FBQUEsSUFDVkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMscUJBQXFCM0IsdUJBQXVCNEI7QUFBQUEsSUFDNUNDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSS9CO0FBQ0osUUFBTSxDQUFDZ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWpELFNBQVMsQ0FBQztBQUN4RCxRQUFNLENBQUNrRCxlQUFlQyxnQkFBZ0IsSUFBSW5ELFNBQVMsQ0FBQztBQUNwRCxRQUFNb0QsU0FBU0Msc0JBQXNCO0FBRXJDLFFBQU1DLFlBQVlwRCxRQUFRLE1BQU07QUFDOUIsV0FBTyxDQUFDLENBQUNpQixXQUFXQSxRQUFRb0MsS0FBS0MsWUFBVUEsT0FBT0MsZUFBZUMsV0FBVztBQUFBLEVBQzlFLEdBQUcsQ0FBQ3ZDLFNBQVNDLEtBQUssQ0FBQztBQUVuQm5CLFlBQVUsTUFBTTtBQUNkLFFBQUltQixPQUFPO0FBQ1QrQix1QkFBaUIvQixNQUFNdUMsTUFBTTtBQUFBLElBQy9CO0FBQUEsRUFDRixHQUFHLENBQUN2QyxLQUFLLENBQUM7QUFFVm5CLFlBQVUsTUFBTTtBQUNkLFFBQUlvQixZQUFZO0FBQ2Q0Qix5QkFBbUI1QixVQUFVO0FBQUEsSUFDL0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsVUFBVSxDQUFDO0FBRWYsU0FDRSx1QkFBQyxjQUNDLEtBQUtILE1BQU0wQyxRQUFRQyxJQUNuQixXQUFXVCxPQUFPVSxXQUVsQjtBQUFBLDJCQUFDLFdBQ0MsaUJBQWdCLGlCQUVmO0FBQUEsT0FBQ3hCLGNBQWMsdUJBQUMsV0FDZixRQUFRO0FBQUEsUUFBRXlCLFVBQVU7QUFBQSxNQUFFLEdBQ3RCLEtBQUs3QyxNQUFNMEMsUUFBUUMsSUFFbEIvQiwwQkFBZ0IsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS2hCO0FBQUEsTUFDQ0QsYUFBYUgsc0JBQ1osdUJBQUMsbUJBQWdCLFVBQVVoQixTQUFTZ0Isb0JBQW9CLEdBQUcsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLFNBVmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxLQUFLUixNQUFNMEMsUUFBUUMsSUFDN0I7QUFBQSw2QkFBQyxjQUFXLEtBQUszQyxNQUFNMEMsUUFBUUksSUFDNUJWO0FBQUFBLHFCQUFhM0IsdUJBQ1osdUJBQUMseUJBQ0MsU0FDQSxlQUFlQSx1QkFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVxQztBQUFBLFFBR3RDLENBQUMsQ0FBQ2Esc0JBQXNCcEIsU0FBU0EsT0FBT3VDLFNBQVMsS0FDaEQsbUNBQ0duQixnQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVEWixXQUNDLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFdBYmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BQ0MsQ0FBQ0EsV0FBV1IsU0FBU0EsTUFBTXVDLFNBQVMsS0FDbkMsdUJBQUMsb0JBQ0MsU0FBTyxNQUNQLDRCQUNBLG9CQUNBLFNBQ0EsT0FDQSxlQUFlbEMsY0FDZixZQUNBLG1CQUNBLFdBQ0EsYUFDQSxtQkFDQSxhQUNBLGtCQUNBLGNBQ0EsYUFDQSxpQkFDQSxjQUNBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JtQztBQUFBLFNBcEN2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBO0FBQUEsSUFDQyxDQUFDRyxXQUFXUixTQUFTQSxNQUFNdUMsV0FBVyxLQUNyQyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CO0FBQUEsSUFFckJyQyxhQUFhQyxnQkFBZ0IsdUJBQUMsdUJBQzdCLGdCQUFnQjJCLGVBQ2hCLGlCQUFpQkYsaUJBQ2pCLGNBQ0EscUJBSjRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJUztBQUFBLE9BaEV6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0VBO0FBRUo7QUFBQy9CLEdBekhRRixjQUFZO0FBQUEsVUFDTEosVUFpQ0MwQyxxQkFBcUI7QUFBQTtBQUFBWSxLQWxDN0JsRDtBQTJIVCxNQUFNc0Msd0JBQXdCQSxNQUFNO0FBQ2xDLFNBQU9sRCxlQUFlO0FBQUEsSUFDcEIyRCxXQUFXO0FBQUEsTUFDVEksVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLGVBQWVuRDtBQUFZLElBQUFrRDtBQUFBRSxhQUFBRixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwibWVyZ2VTdHlsZVNldHMiLCJEYXRhVGFibGVDb250ZW50IiwiRGF0YVRhYmxlUGFnaW5hdGlvbiIsIkRhdGFUYWJsZVNlYXJjaCIsIkRhdGFUYWJsZUZpbHRlckdyb3VwcyIsIkRhdGFUYWJsZUVtcHR5U3RhdGUiLCJMb2FkaW5nU2NyZWVuIiwiZGVib3VuY2UiLCJ1c2VUaGVtZSIsIkZsZXhDb2x1bW4iLCJGbGV4Um93IiwiQ29udHJvbHNDb2x1bW5OYW1lRW51bSIsIkRhdGFUYWJsZUludCIsInByb3BzIiwiX3MiLCJ0aGVtZSIsImNvbHVtbnMiLCJpdGVtcyIsIml0ZW1zQ291bnQiLCJwYWdpbmF0ZWQiLCJvblBhZ2VDaGFuZ2UiLCJzb3J0Q29uZmlnIiwib25Tb3J0Q2hhbmdlIiwib25TZWFyY2hUZXh0Q2hhbmdlIiwib25GaWx0ZXJHcm91cENoYW5nZSIsImxvYWRpbmciLCJoYXNTZWFyY2giLCJyZW5kZXJBY3Rpb25zIiwiaGFzQ29udHJvbHNDb2x1bW4iLCJtZW51T3B0aW9ucyIsIm9uUmVuZGVyTWVudUl0ZW0iLCJtdWx0aXBsZVNlbGVjdGlvbiIsInNlbGVjdGlvbiIsIm9uU2VsZWN0aW9uIiwiaGFzU2VsZWN0aW9uIiwiaGlkZGVuTWVudSIsImN1c3RvbVBhZ2VPcHRpb25zIiwicmVuZGVyRXh0cmFFbGVtZW50IiwiY29udHJvbHNDb2x1bW5OYW1lIiwiQ09OVFJPTFMiLCJvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljayIsImRpc2FibGVNZW51IiwiZGlzYWJsZU1lbnVUZXh0Iiwib25NZW51T3BlbmVkIiwib25NZW51RGlzbWlzc2VkIiwiaXRlbXNDb3VudENhY2hlIiwic2V0SXRlbXNDb3VudENhY2hlIiwicGFnZVNpemVDYWNoZSIsInNldFBhZ2VTaXplQ2FjaGUiLCJzdHlsZXMiLCJ1c2VEYXRhVGFibGVJbnRTdHlsZXMiLCJoYXNGaWx0ZXIiLCJzb21lIiwiY29sdW1uIiwiZmlsdGVyT3B0aW9ucyIsImlzR3JvdXBNb2RlIiwibGVuZ3RoIiwic3BhY2luZyIsImxnIiwiZGF0YVRhYmxlIiwiZmxleEdyb3ciLCJzbSIsIl9jIiwib3ZlcmZsb3ciLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGVJbnQudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZGF0YXRhYmxlL0RhdGFUYWJsZUludC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCBSZWFjdEVsZW1lbnQsIHVzZU1lbW8sIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBJQ29udGV4dHVhbE1lbnVJdGVtLCBJQ29tYm9Cb3hPcHRpb24sIG1lcmdlU3R5bGVTZXRzLCBJUmVuZGVyRnVuY3Rpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCBFbnRpdHkgZnJvbSAnLi4vLi4vLi4vZG9tYWluL0VudGl0eSdcclxuaW1wb3J0IHtcclxuICBEYXRhVGFibGVDb250ZW50LFxyXG4gIERhdGFUYWJsZVBhZ2luYXRpb24sXHJcbiAgRGF0YVRhYmxlU2VhcmNoLFxyXG4gIERhdGFUYWJsZUNvbHVtbixcclxuICBEYXRhVGFibGVQYWdpbmF0aW9uQ29uZmlnLFxyXG4gIERhdGFUYWJsZVNvcnRDb25maWcsXHJcbiAgRGF0YVRhYmxlRmlsdGVyR3JvdXBzLFxyXG4gIERhdGFUYWJsZUVtcHR5U3RhdGUsXHJcbn0gZnJvbSAnLidcclxuaW1wb3J0IHsgTG9hZGluZ1NjcmVlbiB9IGZyb20gJy4uJ1xyXG5pbXBvcnQgeyBkZWJvdW5jZSB9IGZyb20gJ2xvZGFzaC1lcydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuaW1wb3J0IEZsZXhDb2x1bW4gZnJvbSAnLi8uLi9GbGV4Qm94L0ZsZXhDb2x1bW4nXHJcbmltcG9ydCBGbGV4Um93IGZyb20gJy4vLi4vRmxleEJveC9GbGV4Um93J1xyXG5pbXBvcnQgeyBDb250cm9sc0NvbHVtbk5hbWVFbnVtIH0gZnJvbSAnLi4vLi4vZW51bXMvQ29udHJvbHNDb2x1bW5OYW1lRW51bSdcclxuaW1wb3J0IHsgSUZpbHRlckdyb3VwIH0gZnJvbSAnLi4vZmlsdGVyL3R5cGVzJ1xyXG5cclxuaW50ZXJmYWNlIERhdGFUYWJsZUludFByb3BzPFQgZXh0ZW5kcyBFbnRpdHk+IHtcclxuICBjb2x1bW5zOiBEYXRhVGFibGVDb2x1bW48VD5bXVxyXG4gIGl0ZW1zPzogVFtdXHJcbiAgaXRlbXNDb3VudD86IG51bWJlclxyXG4gIHBhZ2luYXRlZD86IGJvb2xlYW5cclxuICBvblBhZ2VDaGFuZ2U/OiAoY29uZmlnOiBEYXRhVGFibGVQYWdpbmF0aW9uQ29uZmlnKSA9PiB2b2lkXHJcbiAgc29ydENvbmZpZzogRGF0YVRhYmxlU29ydENvbmZpZ1xyXG4gIG9uU29ydENoYW5nZT86IChjb25maWc6IERhdGFUYWJsZVNvcnRDb25maWcpID0+IHZvaWRcclxuICBvblNlYXJjaFRleHRDaGFuZ2U/OiAodGV4dDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgb25GaWx0ZXJHcm91cENoYW5nZT86IChmaWx0ZXJHcm91cHM6IElGaWx0ZXJHcm91cFtdKSA9PiB2b2lkXHJcbiAgbG9hZGluZz86IGJvb2xlYW5cclxuICBoYXNTZWFyY2g/OiBib29sZWFuXHJcbiAgcmVuZGVyQWN0aW9ucz86ICgpID0+IFJlYWN0RWxlbWVudFxyXG4gIGhhc0NvbnRyb2xzQ29sdW1uPzogYm9vbGVhblxyXG4gIG1lbnVPcHRpb25zPzogKGl0ZW06IFQpID0+IElDb250ZXh0dWFsTWVudUl0ZW1bXVxyXG4gIG9uUmVuZGVyTWVudUl0ZW0/OiBJUmVuZGVyRnVuY3Rpb248SUNvbnRleHR1YWxNZW51SXRlbT5cclxuICBvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljaz86IChpdGVtOiBUKSA9PiB2b2lkXHJcbiAgbXVsdGlwbGVTZWxlY3Rpb24/OiBib29sZWFuXHJcbiAgc2VsZWN0aW9uPzogVFtdXHJcbiAgb25TZWxlY3Rpb24/OiAoaXRlbXM6IFRbXSkgPT4gdm9pZFxyXG4gIGhhc1NlbGVjdGlvbj86IGJvb2xlYW5cclxuICBoaWRkZW5NZW51PzogYm9vbGVhblxyXG4gIGN1c3RvbVBhZ2VPcHRpb25zPzogSUNvbWJvQm94T3B0aW9uW11cclxuICByZW5kZXJFeHRyYUVsZW1lbnQ/OiBSZWFjdE5vZGVcclxuICBjb250cm9sc0NvbHVtbk5hbWU/OiBDb250cm9sc0NvbHVtbk5hbWVFbnVtXHJcbiAgZGlzYWJsZU1lbnU/OiBib29sZWFuXHJcbiAgZGlzYWJsZU1lbnVUZXh0Pzogc3RyaW5nXHJcbiAgb25NZW51T3BlbmVkPzogKGl0ZW0/OiBUKSA9PiB2b2lkXHJcbiAgb25NZW51RGlzbWlzc2VkPzogKGl0ZW0/OiBUKSA9PiB2b2lkXHJcbn1cclxuXHJcbmZ1bmN0aW9uIERhdGFUYWJsZUludDxUIGV4dGVuZHMgRW50aXR5PiAocHJvcHM6IERhdGFUYWJsZUludFByb3BzPFQ+KTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcclxuICBjb25zdCB7XHJcbiAgICBjb2x1bW5zLFxyXG4gICAgaXRlbXMsXHJcbiAgICBpdGVtc0NvdW50LFxyXG4gICAgcGFnaW5hdGVkLFxyXG4gICAgb25QYWdlQ2hhbmdlLFxyXG4gICAgc29ydENvbmZpZyxcclxuICAgIG9uU29ydENoYW5nZSxcclxuICAgIG9uU2VhcmNoVGV4dENoYW5nZSxcclxuICAgIG9uRmlsdGVyR3JvdXBDaGFuZ2UsXHJcbiAgICBsb2FkaW5nID0gZmFsc2UsXHJcbiAgICBoYXNTZWFyY2gsXHJcbiAgICByZW5kZXJBY3Rpb25zLFxyXG4gICAgaGFzQ29udHJvbHNDb2x1bW4sXHJcbiAgICBtZW51T3B0aW9ucyxcclxuICAgIG9uUmVuZGVyTWVudUl0ZW0sXHJcbiAgICBtdWx0aXBsZVNlbGVjdGlvbixcclxuICAgIHNlbGVjdGlvbixcclxuICAgIG9uU2VsZWN0aW9uLFxyXG4gICAgaGFzU2VsZWN0aW9uLFxyXG4gICAgaGlkZGVuTWVudSxcclxuICAgIGN1c3RvbVBhZ2VPcHRpb25zLFxyXG4gICAgcmVuZGVyRXh0cmFFbGVtZW50LFxyXG4gICAgY29udHJvbHNDb2x1bW5OYW1lID0gQ29udHJvbHNDb2x1bW5OYW1lRW51bS5DT05UUk9MUyxcclxuICAgIG9uU2luZ2xlQWN0aW9uQ29udHJvbENsaWNrLFxyXG4gICAgZGlzYWJsZU1lbnUsXHJcbiAgICBkaXNhYmxlTWVudVRleHQsXHJcbiAgICBvbk1lbnVPcGVuZWQsXHJcbiAgICBvbk1lbnVEaXNtaXNzZWQsXHJcbiAgfSA9IHByb3BzXHJcbiAgY29uc3QgW2l0ZW1zQ291bnRDYWNoZSwgc2V0SXRlbXNDb3VudENhY2hlXSA9IHVzZVN0YXRlKDApXHJcbiAgY29uc3QgW3BhZ2VTaXplQ2FjaGUsIHNldFBhZ2VTaXplQ2FjaGVdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCBzdHlsZXMgPSB1c2VEYXRhVGFibGVJbnRTdHlsZXMoKVxyXG5cclxuICBjb25zdCBoYXNGaWx0ZXIgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiAhIWNvbHVtbnMgJiYgY29sdW1ucy5zb21lKGNvbHVtbiA9PiBjb2x1bW4uZmlsdGVyT3B0aW9ucz8uaXNHcm91cE1vZGUpXHJcbiAgfSwgW2NvbHVtbnMsIGl0ZW1zXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpdGVtcykge1xyXG4gICAgICBzZXRQYWdlU2l6ZUNhY2hlKGl0ZW1zLmxlbmd0aClcclxuICAgIH1cclxuICB9LCBbaXRlbXNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGl0ZW1zQ291bnQpIHtcclxuICAgICAgc2V0SXRlbXNDb3VudENhY2hlKGl0ZW1zQ291bnQpXHJcbiAgICB9XHJcbiAgfSwgW2l0ZW1zQ291bnRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEZsZXhDb2x1bW5cclxuICAgICAgZ2FwPXt0aGVtZS5zcGFjaW5nLmxnfVxyXG4gICAgICBjbGFzc05hbWU9e3N0eWxlcy5kYXRhVGFibGV9XHJcbiAgICA+XHJcbiAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgaG9yaXpvbnRhbEFsaWduPVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgID5cclxuICAgICAgICB7IWhpZGRlbk1lbnUgJiYgPEZsZXhSb3dcclxuICAgICAgICAgIHN0eWxlcz17eyBmbGV4R3JvdzogMSB9fVxyXG4gICAgICAgICAgZ2FwPXt0aGVtZS5zcGFjaW5nLmxnfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtyZW5kZXJBY3Rpb25zPy4oKX1cclxuICAgICAgICA8L0ZsZXhSb3c+fVxyXG4gICAgICAgIHtoYXNTZWFyY2ggJiYgb25TZWFyY2hUZXh0Q2hhbmdlICYmIChcclxuICAgICAgICAgIDxEYXRhVGFibGVTZWFyY2ggb25DaGFuZ2U9e2RlYm91bmNlKG9uU2VhcmNoVGV4dENoYW5nZSwgMzAwKX0gLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L0ZsZXhSb3c+XHJcbiAgICAgIDxGbGV4Q29sdW1uIGdhcD17dGhlbWUuc3BhY2luZy5sZ30+XHJcbiAgICAgICAgPEZsZXhDb2x1bW4gZ2FwPXt0aGVtZS5zcGFjaW5nLnNtfT5cclxuICAgICAgICAgIHtoYXNGaWx0ZXIgJiYgb25GaWx0ZXJHcm91cENoYW5nZSAmJlxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlRmlsdGVyR3JvdXBzXHJcbiAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICBvblF1ZXJ5Q2hhbmdlPXtvbkZpbHRlckdyb3VwQ2hhbmdlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgeyEhcmVuZGVyRXh0cmFFbGVtZW50ICYmIGl0ZW1zICYmIGl0ZW1zPy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge3JlbmRlckV4dHJhRWxlbWVudH1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB7bG9hZGluZyAmJlxyXG4gICAgICAgICAgICA8TG9hZGluZ1NjcmVlbiAvPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDwvRmxleENvbHVtbj5cclxuICAgICAgICB7IWxvYWRpbmcgJiYgaXRlbXMgJiYgaXRlbXMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgPERhdGFUYWJsZUNvbnRlbnRcclxuICAgICAgICAgICAgY29tcGFjdFxyXG4gICAgICAgICAgICBvblNpbmdsZUFjdGlvbkNvbnRyb2xDbGljaz17b25TaW5nbGVBY3Rpb25Db250cm9sQ2xpY2t9XHJcbiAgICAgICAgICAgIGNvbnRyb2xzQ29sdW1uTmFtZT17Y29udHJvbHNDb2x1bW5OYW1lfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICBpdGVtcz17aXRlbXN9XHJcbiAgICAgICAgICAgIG9uSGVhZGVyQ2xpY2s9e29uU29ydENoYW5nZX1cclxuICAgICAgICAgICAgc29ydENvbmZpZz17c29ydENvbmZpZ31cclxuICAgICAgICAgICAgbXVsdGlwbGVTZWxlY3Rpb249e211bHRpcGxlU2VsZWN0aW9ufVxyXG4gICAgICAgICAgICBzZWxlY3Rpb249e3NlbGVjdGlvbn1cclxuICAgICAgICAgICAgb25TZWxlY3Rpb249e29uU2VsZWN0aW9ufVxyXG4gICAgICAgICAgICBoYXNDb250cm9sc0NvbHVtbj17aGFzQ29udHJvbHNDb2x1bW59XHJcbiAgICAgICAgICAgIG1lbnVPcHRpb25zPXttZW51T3B0aW9uc31cclxuICAgICAgICAgICAgb25SZW5kZXJNZW51SXRlbT17b25SZW5kZXJNZW51SXRlbX1cclxuICAgICAgICAgICAgaGFzU2VsZWN0aW9uPXtoYXNTZWxlY3Rpb259XHJcbiAgICAgICAgICAgIGRpc2FibGVNZW51PXtkaXNhYmxlTWVudX1cclxuICAgICAgICAgICAgZGlzYWJsZU1lbnVUZXh0PXtkaXNhYmxlTWVudVRleHR9XHJcbiAgICAgICAgICAgIG9uTWVudU9wZW5lZD17b25NZW51T3BlbmVkfVxyXG4gICAgICAgICAgICBvbk1lbnVEaXNtaXNzZWQ9e29uTWVudURpc21pc3NlZH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgfVxyXG4gICAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgICAgIHshbG9hZGluZyAmJiBpdGVtcyAmJiBpdGVtcy5sZW5ndGggPT09IDAgJiZcclxuICAgICAgICA8RGF0YVRhYmxlRW1wdHlTdGF0ZSAvPlxyXG4gICAgICB9XHJcbiAgICAgIHtwYWdpbmF0ZWQgJiYgb25QYWdlQ2hhbmdlICYmIDxEYXRhVGFibGVQYWdpbmF0aW9uXHJcbiAgICAgICAgcGFnZUl0ZW1zQ291bnQ9e3BhZ2VTaXplQ2FjaGV9XHJcbiAgICAgICAgdG90YWxJdGVtc0NvdW50PXtpdGVtc0NvdW50Q2FjaGV9XHJcbiAgICAgICAgb25QYWdlQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9XHJcbiAgICAgICAgY3VzdG9tUGFnZU9wdGlvbnM9e2N1c3RvbVBhZ2VPcHRpb25zfVxyXG4gICAgICAvPn1cclxuICAgIDwvRmxleENvbHVtbj5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZURhdGFUYWJsZUludFN0eWxlcyA9ICgpID0+IHtcclxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xyXG4gICAgZGF0YVRhYmxlOiB7XHJcbiAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgIH0sXHJcbiAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGF0YVRhYmxlSW50XHJcbiJdfQ==