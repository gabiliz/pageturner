import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserName.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserName.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { userService as service } from "/src/modules/admin/users/services/index.ts";
const UserName = ({
  id
}) => {
  _s();
  const [users, setUsers] = useState([]);
  const getAllUsers = useCallback(async () => {
    const data = await service.findQuery();
    setUsers(data.value);
  }, [setUsers]);
  useEffect(() => {
    getAllUsers();
  }, []);
  return users.length ? /* @__PURE__ */ jsxDEV("span", { children: users?.find((x) => x.id === id)?.nome }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserName.tsx",
    lineNumber: 20,
    columnNumber: 25
  }, this) : /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserName.tsx",
    lineNumber: 20,
    columnNumber: 78
  }, this);
};
_s(UserName, "lgDMKt7pwOkUVLUBpXr5OSASyWY=");
_c = UserName;
export default UserName;
var _c;
$RefreshReg$(_c, "UserName");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserName.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJOLFNBQWFBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUVyRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZUFBZUMsZUFBZTtBQUV2QyxNQUFNQyxXQUE2QkEsQ0FBQztBQUFBLEVBQUVDO0FBQUcsTUFBTTtBQUFBQyxLQUFBO0FBQzdDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUixTQUFpQixFQUFFO0FBRTdDLFFBQU1TLGNBQWNYLFlBQVksWUFBWTtBQUMxQyxVQUFNWSxPQUFPLE1BQU1QLFFBQVFRLFVBQVU7QUFDckNILGFBQVNFLEtBQUtFLEtBQUs7QUFBQSxFQUNyQixHQUFHLENBQUNKLFFBQVEsQ0FBQztBQUViVCxZQUFVLE1BQU07QUFDZFUsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUNMLFNBQU9GLE1BQU1NLFNBQ1QsdUJBQUMsVUFBTU4saUJBQU9PLEtBQUtDLE9BQUtBLEVBQUVWLE9BQU9BLEVBQUUsR0FBR1csUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQyxJQUMzQyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWM7QUFDcEI7QUFBQ1YsR0FkS0YsVUFBMEI7QUFBQWEsS0FBMUJiO0FBZ0JOLGVBQWVBO0FBQVEsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMb2FkaW5nU2NyZWVuIiwidXNlclNlcnZpY2UiLCJzZXJ2aWNlIiwiVXNlck5hbWUiLCJpZCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImdldEFsbFVzZXJzIiwiZGF0YSIsImZpbmRRdWVyeSIsInZhbHVlIiwibGVuZ3RoIiwiZmluZCIsIngiLCJub21lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyTmFtZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlck5hbWUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBVc2VyIGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Vc2VyJ1xyXG5pbXBvcnQgeyBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IHVzZXJTZXJ2aWNlIGFzIHNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuXHJcbmNvbnN0IFVzZXJOYW1lOiBGQzx7aWQ6IHN0cmluZ30+ID0gKHsgaWQgfSkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGU8VXNlcltdPihbXSlcclxuXHJcbiAgY29uc3QgZ2V0QWxsVXNlcnMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgc2VydmljZS5maW5kUXVlcnkoKVxyXG4gICAgc2V0VXNlcnMoZGF0YS52YWx1ZSlcclxuICB9LCBbc2V0VXNlcnNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0QWxsVXNlcnMoKVxyXG4gIH0sIFtdKVxyXG4gIHJldHVybiB1c2Vycy5sZW5ndGhcclxuICAgID8gPHNwYW4+e3VzZXJzPy5maW5kKHggPT4geC5pZCA9PT0gaWQpPy5ub21lfTwvc3Bhbj5cclxuICAgIDogPExvYWRpbmdTY3JlZW4gLz5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlck5hbWVcclxuIl19