import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/SideBarModule.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBarModule.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const SideBarModule = (props) => {
  _s();
  const sideBarStyles = useSideBarStyles();
  return /* @__PURE__ */ jsxDEV("div", { ...props, className: `${props.className} ${sideBarStyles}` }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBarModule.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(SideBarModule, "DShNoS1Ary+yibGv4OFlfMT42uk=", false, function() {
  return [useSideBarStyles];
});
_c = SideBarModule;
const useSideBarStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyles({
    backgroundColor: colors.gray[200]
  });
};
_s2(useSideBarStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default SideBarModule;
var _c;
$RefreshReg$(_c, "SideBarModule");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBarModule.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFUSixTQUFTQSxtQkFBbUI7QUFFNUIsU0FBU0MsZ0JBQWdCO0FBSXpCLE1BQU1DLGdCQUF5Q0MsV0FBVTtBQUFBQyxLQUFBO0FBQ3ZELFFBQU1DLGdCQUFnQkMsaUJBQWlCO0FBQ3ZDLFNBQ0UsdUJBQUMsU0FBSSxHQUFJSCxPQUFPLFdBQVksR0FBRUEsTUFBTUksYUFBYUYsbUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0U7QUFFdEU7QUFBQ0QsR0FMS0YsZUFBcUM7QUFBQSxVQUNuQkksZ0JBQWdCO0FBQUE7QUFBQUUsS0FEbENOO0FBT04sTUFBTUksbUJBQW1CQSxNQUFNO0FBQUFHLE1BQUE7QUFDN0IsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSVQsU0FBUztBQUM1QixTQUFPRCxZQUFZO0FBQUEsSUFDakJXLGlCQUFpQkQsT0FBT0UsS0FBSyxHQUFHO0FBQUEsRUFDbEMsQ0FBQztBQUNIO0FBQUNILElBTEtILGtCQUFnQjtBQUFBLFVBQ0RMLFFBQVE7QUFBQTtBQU03QixlQUFlQztBQUFhLElBQUFNO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJtZXJnZVN0eWxlcyIsInVzZVRoZW1lIiwiU2lkZUJhck1vZHVsZSIsInByb3BzIiwiX3MiLCJzaWRlQmFyU3R5bGVzIiwidXNlU2lkZUJhclN0eWxlcyIsImNsYXNzTmFtZSIsIl9jIiwiX3MyIiwiY29sb3JzIiwiYmFja2dyb3VuZENvbG9yIiwiZ3JheSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpZGVCYXJNb2R1bGUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0L1NpZGVCYXJNb2R1bGUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZXMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgSFRNTEF0dHJpYnV0ZXMsIFByb3BzV2l0aENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG50eXBlIFNpZGVCYXJNb2R1bGVQcm9wcyA9IFByb3BzV2l0aENoaWxkcmVuPEhUTUxBdHRyaWJ1dGVzPEhUTUxEaXZFbGVtZW50Pj5cblxuY29uc3QgU2lkZUJhck1vZHVsZTogRkM8U2lkZUJhck1vZHVsZVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCBzaWRlQmFyU3R5bGVzID0gdXNlU2lkZUJhclN0eWxlcygpXG4gIHJldHVybiAoXG4gICAgPGRpdiB7Li4ucHJvcHN9IGNsYXNzTmFtZT17YCR7cHJvcHMuY2xhc3NOYW1lfSAke3NpZGVCYXJTdHlsZXN9YH0+PC9kaXY+XG4gIClcbn1cblxuY29uc3QgdXNlU2lkZUJhclN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcbiAgcmV0dXJuIG1lcmdlU3R5bGVzKHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXG4gIH0pXG59XG5cbmV4cG9ydCBkZWZhdWx0IFNpZGVCYXJNb2R1bGVcbiJdfQ==