import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useState = __vite__cjsImport3_react["useState"];
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { ErrorBoundary } from "/node_modules/.vite/deps/react-error-boundary.js?v=9f90a7ff";
import ContractListActions from "/src/modules/admin/contracts/components/ContractListActions.tsx?t=1701096626433";
import { DangerButton, DataTableInt, DefaultButton, ErrorScreen } from "/src/shared/components/index.ts?t=1701096626433";
import ContractCreateDrawer from "/src/modules/admin/contracts/components/ContractCreateDrawer.tsx?t=1701096626433";
import { contractService, contractQueryService as service } from "/src/modules/admin/contracts/services/index.ts";
import { ContractHistoryModal, ContractSituation } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
import { ContractsContext } from "/src/modules/admin/contracts/context/ContractsPageContext.ts";
import { formatProposalNumber, buildQueryFilterDefault } from "/src/shared/utils/index.ts";
import { ContractTypeRecord, MonthsRecord } from "/src/shared/record/index.ts";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
import { queryClient } from "/src/shared/providers/QueryProvider.tsx";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
import { ContractSituationEnum } from "/src/shared/enums/ContractSituationEnum.ts";
const ContractList = (props) => {
  _s();
  const {
    deletePermission,
    createPermission,
    visualizePermission
  } = props;
  const {
    client,
    selection,
    setSelection,
    remove: askForRemovalConfirmation
  } = useContext(ContractsContext);
  const {
    openDialog,
    closeDialog
  } = useDialogs();
  const [selectedContratId, setSelectedContractId] = useState("");
  const navigate = useNavigate();
  const [isAddDrawerOpen, {
    setTrue: openAddDrawer,
    setFalse: closeAddDrawer
  }] = useBoolean(false);
  const [isHistoryModalOpen, {
    setTrue: showHistoryModal,
    setFalse: hideHistoryModal
  }] = useBoolean(false);
  const [toDuplicate, setToDuplicate] = useState();
  const [paginationConfig, setPaginationConfig] = useState({
    itemsSkipped: 0,
    pageSize: 10
  });
  const [sortConfig, setSortConfig] = useState({
    field: "numeroProposta",
    descending: false
  });
  const [filter, setFilter] = useState();
  const filterData = useCallback((value) => {
    setFilter(buildQueryFilterDefault(columns, value));
  }, [setFilter, columns, filter]);
  const {
    isLoading,
    error,
    data
  } = service.useFindAllPaginated({
    $count: true,
    $skip: paginationConfig.itemsSkipped,
    $top: paginationConfig.pageSize,
    $filter: `clienteId eq ${client?.id} and situacao ne ${ContractSituationEnum.Cancelado} and contratoPrincipalId eq null ${filter ? `and (${filter})` : ""}`,
    $orderby: `${sortConfig.field.replaceAll(".", "/")} ${sortConfig.descending ? "desc" : "asc"}`
  });
  const {
    mutateAsync: cancelContract
  } = useCancel();
  const askForCancelPermission = useCallback((id) => {
    openDialog({
      title: "Cancelar contrato",
      description: "Você tem certeza que deseja cancelar esse contrato?",
      actions: () => [/* @__PURE__ */ jsxDEV(DefaultButton, { onClick: closeDialog, children: "Manter contrato" }, "keep", false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
        lineNumber: 86,
        columnNumber: 23
      }, this), /* @__PURE__ */ jsxDEV(DangerButton, { onClick: () => {
        cancelContract(id);
        closeDialog();
      }, children: "Cancelar contrato" }, "confirm", false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
        lineNumber: 88,
        columnNumber: 27
      }, this)]
    });
  }, [cancelContract]);
  const menuOptions = useCallback((contract) => {
    const menu = [];
    if (visualizePermission) {
      menu.push({
        key: "detailEdit",
        text: "Detalhar",
        onClick: () => navigate(`${contract.id}`)
      });
    }
    if (createPermission) {
      menu.push({
        key: "duplicate",
        text: "Replicar",
        onClick: () => {
          setToDuplicate(contract);
          openAddDrawer();
        }
      });
    }
    if (deletePermission) {
      menu.push({
        key: "cancel",
        text: "Cancelar",
        onClick: () => askForCancelPermission(`${contract.id}`)
      });
    }
    if (deletePermission) {
      menu.push({
        key: "remove",
        text: "Excluir",
        onClick: () => askForRemovalConfirmation([contract])
      });
    }
    menu.push({
      key: "history",
      text: "Histórico",
      onClick: () => {
        setSelectedContractId(contract.id);
        showHistoryModal();
      }
    });
    return menu;
  }, [askForRemovalConfirmation, visualizePermission, deletePermission, createPermission]);
  const actions = useCallback(() => /* @__PURE__ */ jsxDEV(ContractListActions, { disabledRemoveButton: selection.length === 0, onAddClick: openAddDrawer, onRemoveClick: () => askForRemovalConfirmation(selection), createPermission, deletePermission }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
    lineNumber: 139,
    columnNumber: 37
  }, this), [selection]);
  if (error)
    return /* @__PURE__ */ jsxDEV(ErrorScreen, { error }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
      lineNumber: 140,
      columnNumber: 21
    }, this);
  return /* @__PURE__ */ jsxDEV(ErrorBoundary, { fallbackRender: ({
    error: error2
  }) => /* @__PURE__ */ jsxDEV(ErrorScreen, { error: error2 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
    lineNumber: 143,
    columnNumber: 9
  }, this), children: [
    /* @__PURE__ */ jsxDEV(DataTableInt, { items: data?.value, itemsCount: data?.["@odata.count"], columns, paginated: true, onPageChange: setPaginationConfig, sortConfig, onSortChange: setSortConfig, onSearchTextChange: filterData, loading: isLoading, hasControlsColumn: true, menuOptions, renderActions: actions, selection, onSelection: setSelection, hasSearch: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    isAddDrawerOpen && /* @__PURE__ */ jsxDEV(ContractCreateDrawer, { toDuplicate, isOpen: isAddDrawerOpen, onDismiss: () => {
      setToDuplicate(void 0);
      closeAddDrawer();
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
      lineNumber: 145,
      columnNumber: 27
    }, this),
    isHistoryModalOpen && /* @__PURE__ */ jsxDEV(ContractHistoryModal, { isOpen: isHistoryModalOpen, onDismiss: hideHistoryModal, contractId: selectedContratId }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
      lineNumber: 150,
      columnNumber: 30
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
    lineNumber: 141,
    columnNumber: 10
  }, this);
};
_s(ContractList, "lkgxsglwYvdE1buFEqkVikzOczs=", false, function() {
  return [useDialogs, useNavigate, useBoolean, useBoolean, service.useFindAllPaginated, useCancel];
});
_c = ContractList;
const columns = [{
  header: "Nº do contrato",
  field: "numeroProposta",
  filterable: true,
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  format: (item) => formatProposalNumber(item.numeroProposta)
}, {
  header: "Nº da proposta",
  field: "numeroPropostaComercial",
  filterable: true,
  sortable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  format: (item) => formatProposalNumber(item.numeroPropostaComercial)
}, {
  header: "Tipo de contrato",
  field: "tipoContrato",
  filterable: true,
  filterOptions: {
    queryType: "record",
    queryMode: "default",
    record: ContractTypeRecord
  },
  type: "string",
  format: (item) => {
    if (item.tipoContrato !== void 0) {
      return ContractTypeRecord[item.tipoContrato];
    }
  }
}, {
  header: "Sócio responsável",
  field: "responsavelTecnico.nome",
  filterable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Responsável cliente",
  field: "responsavelCliente.nome",
  filterable: true,
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Exercício",
  field: "exercicio",
  filterOptions: {
    queryType: "number",
    queryMode: "default"
  },
  type: "number",
  filterable: true,
  sortable: true
}, {
  header: "Qtd. horas",
  field: "qtdHoras",
  filterable: true,
  filterOptions: {
    queryType: "number",
    queryMode: "default"
  },
  type: "number",
  sortable: true
}, {
  header: "% de êxito",
  field: "percentualExito",
  filterable: true,
  filterOptions: {
    queryType: "number",
    queryMode: "default"
  },
  type: "number",
  sortable: true
}, {
  header: "Data de inclusão",
  field: "dataInclusao",
  format: (item) => item.dataInclusao ? format(new Date(item.dataInclusao), "dd/MM/yyyy") : "",
  filterable: true,
  filterOptions: {
    queryType: "date",
    queryMode: "default"
  },
  type: "date",
  sortable: true
}, {
  header: "Vigência",
  field: "dataInicio",
  format: (item) => item.dataInicio && item.dataFim ? `${format(new Date(item.dataInicio), "dd/MM/yyyy")} a ${format(new Date(item.dataFim), "dd/MM/yyyy")}` : "",
  type: "date",
  sortable: true
}, {
  header: "Mês renovação",
  field: "mesRenovacao",
  filterable: true,
  filterOptions: {
    queryType: "record",
    queryMode: "default",
    record: MonthsRecord
  },
  type: "string",
  format: (item) => {
    if (item.mesRenovacao !== void 0) {
      return MonthsRecord[item.mesRenovacao];
    }
  }
}, {
  header: "Situação",
  field: "situacao",
  format: (item) => {
    if (item.situacao !== void 0) {
      return /* @__PURE__ */ jsxDEV(ContractSituation, { situation: item.situacao }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx",
        lineNumber: 281,
        columnNumber: 14
      }, this);
    }
  }
}];
const useCancel = () => {
  _s2();
  const {
    showNotification
  } = useNotifications();
  return useMutation((item) => contractService.cancel(item), {
    onSuccess: () => {
      showNotification({
        message: "Contrato cancelado com sucesso!",
        type: MessageBarType.success
      });
      queryClient.invalidateQueries();
    },
    onError: () => {
      showNotification({
        message: "Não foi possível cancelar o contrato",
        type: MessageBarType.error
      });
    }
  });
};
_s2(useCancel, "h3E96/uBWbCUn0cveO52RBfxszY=", false, function() {
  return [useNotifications, useMutation];
});
export default ContractList;
var _c;
$RefreshReg$(_c, "ContractList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZROzs7Ozs7Ozs7Ozs7Ozs7O0FBckZSLFNBQWFBLGFBQWFDLFlBQVlDLGdCQUFnQjtBQUN0RCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBOEJDLHNCQUFzQjtBQUNwRCxTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MseUJBQXlCO0FBQ2hDLFNBQVNDLGNBQStCQyxjQUE4REMsZUFBZUMsbUJBQW1CO0FBQ3hJLE9BQU9DLDBCQUEwQjtBQUNqQyxTQUFTQyxpQkFBaUJDLHdCQUF3QkMsZUFBZTtBQUVqRSxTQUFTQyxzQkFBc0JDLHlCQUF5QjtBQUN4RCxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msc0JBQXNCQywrQkFBK0I7QUFDOUQsU0FBU0Msb0JBQW9CQyxvQkFBb0I7QUFDakQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGNBQWM7QUFDdkIsU0FBNEJDLG1CQUFtQjtBQUMvQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyw2QkFBNkI7QUFRdEMsTUFBTUMsZUFBdUNDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRCxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJSjtBQUNKLFFBQU07QUFBQSxJQUNKSztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxRQUFRQztBQUFBQSxFQUNWLElBQUl0QyxXQUFXZ0IsZ0JBQWdCO0FBRS9CLFFBQU07QUFBQSxJQUFFdUI7QUFBQUEsSUFBWUM7QUFBQUEsRUFBWSxJQUFJZCxXQUFXO0FBRS9DLFFBQU0sQ0FBQ2UsbUJBQW1CQyxxQkFBcUIsSUFBSXpDLFNBQWlCLEVBQUU7QUFDdEUsUUFBTTBDLFdBQVd0QixZQUFZO0FBQzdCLFFBQU0sQ0FDSnVCLGlCQUNBO0FBQUEsSUFBRUMsU0FBU0M7QUFBQUEsSUFBZUMsVUFBVUM7QUFBQUEsRUFBZSxDQUFDLElBQ2xEOUMsV0FBVyxLQUFLO0FBRXBCLFFBQU0sQ0FDSitDLG9CQUNBO0FBQUEsSUFBRUosU0FBU0s7QUFBQUEsSUFBa0JILFVBQVVJO0FBQUFBLEVBQWlCLENBQUMsSUFDdkRqRCxXQUFXLEtBQUs7QUFFcEIsUUFBTSxDQUFDa0QsYUFBYUMsY0FBYyxJQUFJcEQsU0FBbUI7QUFDekQsUUFBTSxDQUFDcUQsa0JBQWtCQyxtQkFBbUIsSUFBSXRELFNBQW9DO0FBQUEsSUFDbEZ1RCxjQUFjO0FBQUEsSUFDZEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJMUQsU0FBOEI7QUFBQSxJQUNoRTJELE9BQU87QUFBQSxJQUNQQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk5RCxTQUFpQjtBQUM3QyxRQUFNK0QsYUFBYWpFLFlBQVksQ0FBQ2tFLFVBQXdCO0FBQ3RERixjQUFVN0Msd0JBQXdCZ0QsU0FBU0QsS0FBSyxDQUFDO0FBQUEsRUFDbkQsR0FBRyxDQUFDRixXQUFXRyxTQUFTSixNQUFNLENBQUM7QUFFL0IsUUFBTTtBQUFBLElBQUVLO0FBQUFBLElBQVdDO0FBQUFBLElBQU9DO0FBQUFBLEVBQUssSUFBSXhELFFBQVF5RCxvQkFDekM7QUFBQSxJQUNFQyxRQUFRO0FBQUEsSUFDUkMsT0FBT2xCLGlCQUFpQkU7QUFBQUEsSUFDeEJpQixNQUFNbkIsaUJBQWlCRztBQUFBQSxJQUN2QmlCLFNBQVUsZ0JBQWV4QyxRQUFReUMsc0JBQXNCaEQsc0JBQXNCaUQsNkNBQTZDZCxTQUFVLFFBQU9BLFlBQVk7QUFBQSxJQUN2SmUsVUFBVyxHQUFFbkIsV0FBV0UsTUFBTWtCLFdBQVcsS0FBSyxHQUFHLEtBQUtwQixXQUFXRyxhQUFhLFNBQVM7QUFBQSxFQUN6RixDQUNGO0FBRUEsUUFBTTtBQUFBLElBQUVrQixhQUFhQztBQUFBQSxFQUFlLElBQUlDLFVBQVU7QUFFbEQsUUFBTUMseUJBQXlCbkYsWUFBWSxDQUFDNEUsT0FBZTtBQUN6RHBDLGVBQVc7QUFBQSxNQUNUNEMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxTQUFTQSxNQUFNLENBQ2IsdUJBQUMsaUJBRUMsU0FBUzdDLGFBQVksK0JBRGpCLFFBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEdBQ0EsdUJBQUMsZ0JBRUMsU0FBUyxNQUFNO0FBQ2J3Qyx1QkFBZUwsRUFBWTtBQUMzQm5DLG9CQUFZO0FBQUEsTUFDZCxHQUFFLGlDQUpFLFdBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLENBQWU7QUFBQSxJQUVuQixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUN3QyxjQUFjLENBQUM7QUFFbkIsUUFBTU0sY0FBY3ZGLFlBQVksQ0FBQ3dGLGFBQThDO0FBQzdFLFVBQU1DLE9BQU87QUFDYixRQUFJdkQscUJBQXFCO0FBQ3ZCdUQsV0FBS0MsS0FBSztBQUFBLFFBQ1JDLEtBQUs7QUFBQSxRQUNMQyxNQUFNO0FBQUEsUUFDTkMsU0FBU0EsTUFBTWpELFNBQVUsR0FBRTRDLFNBQVNaLElBQUk7QUFBQSxNQUMxQyxDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUkzQyxrQkFBa0I7QUFDcEJ3RCxXQUFLQyxLQUFLO0FBQUEsUUFDUkMsS0FBSztBQUFBLFFBQ0xDLE1BQU07QUFBQSxRQUNOQyxTQUFTQSxNQUFNO0FBQ2J2Qyx5QkFBZWtDLFFBQVE7QUFDdkJ6Qyx3QkFBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUlmLGtCQUFrQjtBQUNwQnlELFdBQUtDLEtBQUs7QUFBQSxRQUNSQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLFFBQ05DLFNBQVNBLE1BQU1WLHVCQUF3QixHQUFFSyxTQUFTWixJQUFJO0FBQUEsTUFDeEQsQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJNUMsa0JBQWtCO0FBQ3BCeUQsV0FBS0MsS0FBSztBQUFBLFFBQ1JDLEtBQUs7QUFBQSxRQUNMQyxNQUFNO0FBQUEsUUFDTkMsU0FBU0EsTUFBTXRELDBCQUEwQixDQUFDaUQsUUFBUSxDQUFDO0FBQUEsTUFDckQsQ0FBQztBQUFBLElBQ0g7QUFFQUMsU0FBS0MsS0FBSztBQUFBLE1BQ1JDLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsU0FBU0EsTUFBTTtBQUNibEQsOEJBQXNCNkMsU0FBU1osRUFBWTtBQUMzQ3pCLHlCQUFpQjtBQUFBLE1BQ25CO0FBQUEsSUFDRixDQUFDO0FBQ0QsV0FBT3NDO0FBQUFBLEVBQ1QsR0FBRyxDQUFDbEQsMkJBQTJCTCxxQkFBcUJGLGtCQUFrQkMsZ0JBQWdCLENBQUM7QUFFdkYsUUFBTXFELFVBQVV0RixZQUFZLE1BQzFCLHVCQUFDLHVCQUNDLHNCQUFzQm9DLFVBQVUwRCxXQUFXLEdBQzNDLFlBQVkvQyxlQUNaLGVBQWUsTUFBTVIsMEJBQTBCSCxTQUFTLEdBQ3hELGtCQUNBLG9CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLcUMsR0FFcEMsQ0FBQ0EsU0FBUyxDQUFDO0FBRWQsTUFBSWlDO0FBQU8sV0FBTyx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUU1QyxTQUNFLHVCQUFDLGlCQUNDLGdCQUFnQixDQUFDO0FBQUEsSUFBRUE7QUFBQUEsRUFBTSxNQUN2Qix1QkFBQyxlQUFZLE9BQU9BLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEIsR0FHNUI7QUFBQSwyQkFBQyxnQkFDQyxPQUFPQyxNQUFNSixPQUNiLFlBQVlJLE9BQU8sY0FBYyxHQUNqQyxTQUNBLFdBQVMsTUFDVCxjQUFjZCxxQkFDZCxZQUNBLGNBQWNJLGVBQ2Qsb0JBQW9CSyxZQUNwQixTQUFTRyxXQUNULG1CQUFpQixNQUNqQixhQUNBLGVBQWVrQixTQUNmLFdBQ0EsYUFBYWpELGNBQ2IsV0FBUyxRQWZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlVztBQUFBLElBRVZRLG1CQUFtQix1QkFBQyx3QkFDbkIsYUFDQSxRQUFRQSxpQkFDUixXQUFXLE1BQU07QUFDZlMscUJBQWV5QyxNQUFTO0FBQ3hCOUMscUJBQWU7QUFBQSxJQUNqQixLQU5rQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTWhCO0FBQUEsSUFHSEMsc0JBQ0MsdUJBQUMsd0JBQ0MsUUFBUUEsb0JBQ1IsV0FBV0Usa0JBQ1gsWUFBWVYscUJBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdnQztBQUFBLE9BbkNwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBO0FBRUo7QUFBQ1gsR0EvS0tGLGNBQW1DO0FBQUEsVUFhSEYsWUFHbkJMLGFBSWJuQixZQUtBQSxZQWdCK0JXLFFBQVF5RCxxQkFVSFcsU0FBUztBQUFBO0FBQUFjLEtBbkQ3Q25FO0FBaUxOLE1BQU1zQyxVQUF1QyxDQUMzQztBQUFBLEVBQ0U4QixRQUFRO0FBQUEsRUFDUnBDLE9BQU87QUFBQSxFQUNQcUMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05oRixRQUFTaUYsVUFBU3RGLHFCQUFxQnNGLEtBQUtDLGNBQWM7QUFDNUQsR0FDQTtBQUFBLEVBQ0VSLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1BxQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUFBLEVBQ1ZDLGVBQWU7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLEVBQ2I7QUFBQSxFQUNBQyxNQUFNO0FBQUEsRUFDTmhGLFFBQVNpRixVQUFTdEYscUJBQXFCc0YsS0FBS0UsdUJBQXVCO0FBQ3JFLEdBQ0E7QUFBQSxFQUNFVCxRQUFRO0FBQUEsRUFDUnBDLE9BQU87QUFBQSxFQUNQcUMsWUFBWTtBQUFBLEVBQ1pFLGVBQWU7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hLLFFBQVF2RjtBQUFBQSxFQUNWO0FBQUEsRUFDQW1GLE1BQU07QUFBQSxFQUNOaEYsUUFBU2lGLFVBQVM7QUFDaEIsUUFBSUEsS0FBS0ksaUJBQWlCYixRQUFXO0FBQ25DLGFBQU8zRSxtQkFBbUJvRixLQUFLSSxZQUFZO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBQ0YsR0FDQTtBQUFBLEVBQ0VYLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1BxQyxZQUFZO0FBQUEsRUFDWkUsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOSixVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1BxQyxZQUFZO0FBQUEsRUFDWkUsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOSixVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1B1QyxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05MLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1BxQyxZQUFZO0FBQUEsRUFDWkUsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOSixVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1BxQyxZQUFZO0FBQUEsRUFDWkUsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOSixVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLFFBQVE7QUFBQSxFQUNScEMsT0FBTztBQUFBLEVBQ1B0QyxRQUFTaUYsVUFBU0EsS0FBS0ssZUFDbkJ0RixPQUFPLElBQUl1RixLQUFLTixLQUFLSyxZQUFZLEdBQUcsWUFBWSxJQUNoRDtBQUFBLEVBQ0pYLFlBQVk7QUFBQSxFQUNaRSxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUFBLEVBQ05KLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUYsUUFBUTtBQUFBLEVBQ1JwQyxPQUFPO0FBQUEsRUFDUHRDLFFBQVNpRixVQUFVQSxLQUFLTyxjQUFjUCxLQUFLUSxVQUN0QyxHQUFFekYsT0FBTyxJQUFJdUYsS0FBS04sS0FBS08sVUFBVSxHQUFHLFlBQVksT0FBT3hGLE9BQU8sSUFBSXVGLEtBQUtOLEtBQUtRLE9BQU8sR0FBRyxZQUFZLE1BQ25HO0FBQUEsRUFDSlQsTUFBTTtBQUFBLEVBQ05KLFVBQVU7QUFDWixHQUNBO0FBQUEsRUFDRUYsUUFBUTtBQUFBLEVBQ1JwQyxPQUFPO0FBQUEsRUFDUHFDLFlBQVk7QUFBQSxFQUNaRSxlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYSyxRQUFRdEY7QUFBQUEsRUFDVjtBQUFBLEVBQ0FrRixNQUFNO0FBQUEsRUFDTmhGLFFBQVNpRixVQUFTO0FBQ2hCLFFBQUlBLEtBQUtTLGlCQUFpQmxCLFFBQVc7QUFDbkMsYUFBTzFFLGFBQWFtRixLQUFLUyxZQUFZO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0YsR0FDQTtBQUFBLEVBQ0VoQixRQUFRO0FBQUEsRUFDUnBDLE9BQU87QUFBQSxFQUNQdEMsUUFBU2lGLFVBQVM7QUFDaEIsUUFBSUEsS0FBS1UsYUFBYW5CLFFBQVc7QUFDL0IsYUFBTyx1QkFBQyxxQkFBa0IsV0FBV1MsS0FBS1UsWUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFHSCxNQUFNaEMsWUFBWUEsTUFBeUI7QUFBQWlDLE1BQUE7QUFDekMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQWlCLElBQUkzRixpQkFBaUI7QUFFOUMsU0FBT0QsWUFDSmdGLFVBQVM1RixnQkFBZ0J5RyxPQUFPYixJQUFjLEdBQy9DO0FBQUEsSUFDRWMsV0FBV0EsTUFBTTtBQUNmRix1QkFBaUI7QUFBQSxRQUNmRyxTQUFTO0FBQUEsUUFDVGhCLE1BQU1uRyxlQUFlb0g7QUFBQUEsTUFDdkIsQ0FBQztBQUNEOUYsa0JBQVkrRixrQkFBa0I7QUFBQSxJQUNoQztBQUFBLElBQ0FDLFNBQVNBLE1BQU07QUFDYk4sdUJBQWlCO0FBQUEsUUFDZkcsU0FBUztBQUFBLFFBQ1RoQixNQUFNbkcsZUFBZWlFO0FBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixDQUNGO0FBQ0Y7QUFBQzhDLElBckJLakMsV0FBUztBQUFBLFVBQ2dCekQsa0JBRXRCRCxXQUFXO0FBQUE7QUFvQnBCLGVBQWVLO0FBQVksSUFBQW1FO0FBQUEyQixhQUFBM0IsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZVN0YXRlIiwidXNlQm9vbGVhbiIsIk1lc3NhZ2VCYXJUeXBlIiwiRXJyb3JCb3VuZGFyeSIsIkNvbnRyYWN0TGlzdEFjdGlvbnMiLCJEYW5nZXJCdXR0b24iLCJEYXRhVGFibGVJbnQiLCJEZWZhdWx0QnV0dG9uIiwiRXJyb3JTY3JlZW4iLCJDb250cmFjdENyZWF0ZURyYXdlciIsImNvbnRyYWN0U2VydmljZSIsImNvbnRyYWN0UXVlcnlTZXJ2aWNlIiwic2VydmljZSIsIkNvbnRyYWN0SGlzdG9yeU1vZGFsIiwiQ29udHJhY3RTaXR1YXRpb24iLCJDb250cmFjdHNDb250ZXh0IiwiZm9ybWF0UHJvcG9zYWxOdW1iZXIiLCJidWlsZFF1ZXJ5RmlsdGVyRGVmYXVsdCIsIkNvbnRyYWN0VHlwZVJlY29yZCIsIk1vbnRoc1JlY29yZCIsInVzZU5hdmlnYXRlIiwiZm9ybWF0IiwidXNlTXV0YXRpb24iLCJ1c2VOb3RpZmljYXRpb25zIiwicXVlcnlDbGllbnQiLCJ1c2VEaWFsb2dzIiwiQ29udHJhY3RTaXR1YXRpb25FbnVtIiwiQ29udHJhY3RMaXN0IiwicHJvcHMiLCJfcyIsImRlbGV0ZVBlcm1pc3Npb24iLCJjcmVhdGVQZXJtaXNzaW9uIiwidmlzdWFsaXplUGVybWlzc2lvbiIsImNsaWVudCIsInNlbGVjdGlvbiIsInNldFNlbGVjdGlvbiIsInJlbW92ZSIsImFza0ZvclJlbW92YWxDb25maXJtYXRpb24iLCJvcGVuRGlhbG9nIiwiY2xvc2VEaWFsb2ciLCJzZWxlY3RlZENvbnRyYXRJZCIsInNldFNlbGVjdGVkQ29udHJhY3RJZCIsIm5hdmlnYXRlIiwiaXNBZGREcmF3ZXJPcGVuIiwic2V0VHJ1ZSIsIm9wZW5BZGREcmF3ZXIiLCJzZXRGYWxzZSIsImNsb3NlQWRkRHJhd2VyIiwiaXNIaXN0b3J5TW9kYWxPcGVuIiwic2hvd0hpc3RvcnlNb2RhbCIsImhpZGVIaXN0b3J5TW9kYWwiLCJ0b0R1cGxpY2F0ZSIsInNldFRvRHVwbGljYXRlIiwicGFnaW5hdGlvbkNvbmZpZyIsInNldFBhZ2luYXRpb25Db25maWciLCJpdGVtc1NraXBwZWQiLCJwYWdlU2l6ZSIsInNvcnRDb25maWciLCJzZXRTb3J0Q29uZmlnIiwiZmllbGQiLCJkZXNjZW5kaW5nIiwiZmlsdGVyIiwic2V0RmlsdGVyIiwiZmlsdGVyRGF0YSIsInZhbHVlIiwiY29sdW1ucyIsImlzTG9hZGluZyIsImVycm9yIiwiZGF0YSIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCIkY291bnQiLCIkc2tpcCIsIiR0b3AiLCIkZmlsdGVyIiwiaWQiLCJDYW5jZWxhZG8iLCIkb3JkZXJieSIsInJlcGxhY2VBbGwiLCJtdXRhdGVBc3luYyIsImNhbmNlbENvbnRyYWN0IiwidXNlQ2FuY2VsIiwiYXNrRm9yQ2FuY2VsUGVybWlzc2lvbiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb25zIiwibWVudU9wdGlvbnMiLCJjb250cmFjdCIsIm1lbnUiLCJwdXNoIiwia2V5IiwidGV4dCIsIm9uQ2xpY2siLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJfYyIsImhlYWRlciIsImZpbHRlcmFibGUiLCJzb3J0YWJsZSIsImZpbHRlck9wdGlvbnMiLCJxdWVyeVR5cGUiLCJxdWVyeU1vZGUiLCJ0eXBlIiwiaXRlbSIsIm51bWVyb1Byb3Bvc3RhIiwibnVtZXJvUHJvcG9zdGFDb21lcmNpYWwiLCJyZWNvcmQiLCJ0aXBvQ29udHJhdG8iLCJkYXRhSW5jbHVzYW8iLCJEYXRlIiwiZGF0YUluaWNpbyIsImRhdGFGaW0iLCJtZXNSZW5vdmFjYW8iLCJzaXR1YWNhbyIsIl9zMiIsInNob3dOb3RpZmljYXRpb24iLCJjYW5jZWwiLCJvblN1Y2Nlc3MiLCJtZXNzYWdlIiwic3VjY2VzcyIsImludmFsaWRhdGVRdWVyaWVzIiwib25FcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyYWN0TGlzdC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0TGlzdC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VCb29sZWFuIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0LWhvb2tzJ1xuaW1wb3J0IHsgSUNvbnRleHR1YWxNZW51SXRlbSwgTWVzc2FnZUJhclR5cGUgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG5pbXBvcnQgQ29udHJhY3RMaXN0QWN0aW9ucyBmcm9tICcuL0NvbnRyYWN0TGlzdEFjdGlvbnMnXG5pbXBvcnQgeyBEYW5nZXJCdXR0b24sIERhdGFUYWJsZUNvbHVtbiwgRGF0YVRhYmxlSW50LCBEYXRhVGFibGVQYWdpbmF0aW9uQ29uZmlnLCBEYXRhVGFibGVTb3J0Q29uZmlnLCBEZWZhdWx0QnV0dG9uLCBFcnJvclNjcmVlbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IENvbnRyYWN0Q3JlYXRlRHJhd2VyIGZyb20gJy4vQ29udHJhY3RDcmVhdGVEcmF3ZXInXG5pbXBvcnQgeyBjb250cmFjdFNlcnZpY2UsIGNvbnRyYWN0UXVlcnlTZXJ2aWNlIGFzIHNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcbmltcG9ydCBDb250cmFjdCBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQ29udHJhY3QnXG5pbXBvcnQgeyBDb250cmFjdEhpc3RvcnlNb2RhbCwgQ29udHJhY3RTaXR1YXRpb24gfSBmcm9tICcuJ1xuaW1wb3J0IHsgQ29udHJhY3RzQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvQ29udHJhY3RzUGFnZUNvbnRleHQnXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciwgYnVpbGRRdWVyeUZpbHRlckRlZmF1bHQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdXRpbHMnXG5pbXBvcnQgeyBDb250cmFjdFR5cGVSZWNvcmQsIE1vbnRoc1JlY29yZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBmb3JtYXQgfSBmcm9tICdkYXRlLWZucydcbmltcG9ydCB7IFVzZU11dGF0aW9uUmVzdWx0LCB1c2VNdXRhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xuaW1wb3J0IHsgcXVlcnlDbGllbnQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvcHJvdmlkZXJzL1F1ZXJ5UHJvdmlkZXInXG5pbXBvcnQgeyB1c2VEaWFsb2dzIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3N0b3JlL2RpYWxvZ3MvZGlhbG9ncydcbmltcG9ydCB7IENvbnRyYWN0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9Db250cmFjdFNpdHVhdGlvbkVudW0nXG5cbmludGVyZmFjZSBDb250cmFjdExpc3RQcm9wcyB7XG4gIGRlbGV0ZVBlcm1pc3Npb246IGJvb2xlYW5cbiAgY3JlYXRlUGVybWlzc2lvbjogYm9vbGVhblxuICB2aXN1YWxpemVQZXJtaXNzaW9uOiBib29sZWFuXG59XG5cbmNvbnN0IENvbnRyYWN0TGlzdDogRkM8Q29udHJhY3RMaXN0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBkZWxldGVQZXJtaXNzaW9uLFxuICAgIGNyZWF0ZVBlcm1pc3Npb24sXG4gICAgdmlzdWFsaXplUGVybWlzc2lvbixcbiAgfSA9IHByb3BzXG4gIGNvbnN0IHtcbiAgICBjbGllbnQsXG4gICAgc2VsZWN0aW9uLFxuICAgIHNldFNlbGVjdGlvbixcbiAgICByZW1vdmU6IGFza0ZvclJlbW92YWxDb25maXJtYXRpb24sXG4gIH0gPSB1c2VDb250ZXh0KENvbnRyYWN0c0NvbnRleHQpXG5cbiAgY29uc3QgeyBvcGVuRGlhbG9nLCBjbG9zZURpYWxvZyB9ID0gdXNlRGlhbG9ncygpXG5cbiAgY29uc3QgW3NlbGVjdGVkQ29udHJhdElkLCBzZXRTZWxlY3RlZENvbnRyYWN0SWRdID0gdXNlU3RhdGU8c3RyaW5nPignJylcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IFtcbiAgICBpc0FkZERyYXdlck9wZW4sXG4gICAgeyBzZXRUcnVlOiBvcGVuQWRkRHJhd2VyLCBzZXRGYWxzZTogY2xvc2VBZGREcmF3ZXIgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG5cbiAgY29uc3QgW1xuICAgIGlzSGlzdG9yeU1vZGFsT3BlbixcbiAgICB7IHNldFRydWU6IHNob3dIaXN0b3J5TW9kYWwsIHNldEZhbHNlOiBoaWRlSGlzdG9yeU1vZGFsIH0sXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxuXG4gIGNvbnN0IFt0b0R1cGxpY2F0ZSwgc2V0VG9EdXBsaWNhdGVdID0gdXNlU3RhdGU8Q29udHJhY3Q+KClcbiAgY29uc3QgW3BhZ2luYXRpb25Db25maWcsIHNldFBhZ2luYXRpb25Db25maWddID0gdXNlU3RhdGU8RGF0YVRhYmxlUGFnaW5hdGlvbkNvbmZpZz4oe1xuICAgIGl0ZW1zU2tpcHBlZDogMCxcbiAgICBwYWdlU2l6ZTogMTAsXG4gIH0pXG4gIGNvbnN0IFtzb3J0Q29uZmlnLCBzZXRTb3J0Q29uZmlnXSA9IHVzZVN0YXRlPERhdGFUYWJsZVNvcnRDb25maWc+KHtcbiAgICBmaWVsZDogJ251bWVyb1Byb3Bvc3RhJyxcbiAgICBkZXNjZW5kaW5nOiBmYWxzZSxcbiAgfSlcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oKVxuICBjb25zdCBmaWx0ZXJEYXRhID0gdXNlQ2FsbGJhY2soKHZhbHVlOiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICBzZXRGaWx0ZXIoYnVpbGRRdWVyeUZpbHRlckRlZmF1bHQoY29sdW1ucywgdmFsdWUpKVxuICB9LCBbc2V0RmlsdGVyLCBjb2x1bW5zLCBmaWx0ZXJdKVxuXG4gIGNvbnN0IHsgaXNMb2FkaW5nLCBlcnJvciwgZGF0YSB9ID0gc2VydmljZS51c2VGaW5kQWxsUGFnaW5hdGVkKFxuICAgIHtcbiAgICAgICRjb3VudDogdHJ1ZSxcbiAgICAgICRza2lwOiBwYWdpbmF0aW9uQ29uZmlnLml0ZW1zU2tpcHBlZCxcbiAgICAgICR0b3A6IHBhZ2luYXRpb25Db25maWcucGFnZVNpemUsXG4gICAgICAkZmlsdGVyOiBgY2xpZW50ZUlkIGVxICR7Y2xpZW50Py5pZH0gYW5kIHNpdHVhY2FvIG5lICR7Q29udHJhY3RTaXR1YXRpb25FbnVtLkNhbmNlbGFkb30gYW5kIGNvbnRyYXRvUHJpbmNpcGFsSWQgZXEgbnVsbCAke2ZpbHRlciA/IGBhbmQgKCR7ZmlsdGVyfSlgIDogJyd9YCxcbiAgICAgICRvcmRlcmJ5OiBgJHtzb3J0Q29uZmlnLmZpZWxkLnJlcGxhY2VBbGwoJy4nLCAnLycpfSAke3NvcnRDb25maWcuZGVzY2VuZGluZyA/ICdkZXNjJyA6ICdhc2MnfWAsXG4gICAgfSxcbiAgKVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGNhbmNlbENvbnRyYWN0IH0gPSB1c2VDYW5jZWwoKVxuXG4gIGNvbnN0IGFza0ZvckNhbmNlbFBlcm1pc3Npb24gPSB1c2VDYWxsYmFjaygoaWQ6IHN0cmluZykgPT4ge1xuICAgIG9wZW5EaWFsb2coe1xuICAgICAgdGl0bGU6ICdDYW5jZWxhciBjb250cmF0bycsXG4gICAgICBkZXNjcmlwdGlvbjogJ1ZvY8OqIHRlbSBjZXJ0ZXphIHF1ZSBkZXNlamEgY2FuY2VsYXIgZXNzZSBjb250cmF0bz8nLFxuICAgICAgYWN0aW9uczogKCkgPT4gW1xuICAgICAgICA8RGVmYXVsdEJ1dHRvblxuICAgICAgICAgIGtleT1cImtlZXBcIlxuICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlRGlhbG9nfVxuICAgICAgICA+XG4gICAgICAgICAgTWFudGVyIGNvbnRyYXRvXG4gICAgICAgIDwvRGVmYXVsdEJ1dHRvbj4sXG4gICAgICAgIDxEYW5nZXJCdXR0b25cbiAgICAgICAgICBrZXk9XCJjb25maXJtXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBjYW5jZWxDb250cmFjdChpZCBhcyBzdHJpbmcpXG4gICAgICAgICAgICBjbG9zZURpYWxvZygpXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIENhbmNlbGFyIGNvbnRyYXRvXG4gICAgICAgIDwvRGFuZ2VyQnV0dG9uPixcbiAgICAgIF0sXG4gICAgfSlcbiAgfSwgW2NhbmNlbENvbnRyYWN0XSlcblxuICBjb25zdCBtZW51T3B0aW9ucyA9IHVzZUNhbGxiYWNrKChjb250cmFjdDogQ29udHJhY3QpOiBJQ29udGV4dHVhbE1lbnVJdGVtW10gPT4ge1xuICAgIGNvbnN0IG1lbnUgPSBbXVxuICAgIGlmICh2aXN1YWxpemVQZXJtaXNzaW9uKSB7XG4gICAgICBtZW51LnB1c2goe1xuICAgICAgICBrZXk6ICdkZXRhaWxFZGl0JyxcbiAgICAgICAgdGV4dDogJ0RldGFsaGFyJyxcbiAgICAgICAgb25DbGljazogKCkgPT4gbmF2aWdhdGUoYCR7Y29udHJhY3QuaWR9YCksXG4gICAgICB9KVxuICAgIH1cbiAgICBpZiAoY3JlYXRlUGVybWlzc2lvbikge1xuICAgICAgbWVudS5wdXNoKHtcbiAgICAgICAga2V5OiAnZHVwbGljYXRlJyxcbiAgICAgICAgdGV4dDogJ1JlcGxpY2FyJyxcbiAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgIHNldFRvRHVwbGljYXRlKGNvbnRyYWN0KVxuICAgICAgICAgIG9wZW5BZGREcmF3ZXIoKVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9XG4gICAgaWYgKGRlbGV0ZVBlcm1pc3Npb24pIHtcbiAgICAgIG1lbnUucHVzaCh7XG4gICAgICAgIGtleTogJ2NhbmNlbCcsXG4gICAgICAgIHRleHQ6ICdDYW5jZWxhcicsXG4gICAgICAgIG9uQ2xpY2s6ICgpID0+IGFza0ZvckNhbmNlbFBlcm1pc3Npb24oYCR7Y29udHJhY3QuaWR9YCksXG4gICAgICB9KVxuICAgIH1cbiAgICBpZiAoZGVsZXRlUGVybWlzc2lvbikge1xuICAgICAgbWVudS5wdXNoKHtcbiAgICAgICAga2V5OiAncmVtb3ZlJyxcbiAgICAgICAgdGV4dDogJ0V4Y2x1aXInLFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiBhc2tGb3JSZW1vdmFsQ29uZmlybWF0aW9uKFtjb250cmFjdF0pLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICBtZW51LnB1c2goe1xuICAgICAga2V5OiAnaGlzdG9yeScsXG4gICAgICB0ZXh0OiAnSGlzdMOzcmljbycsXG4gICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgIHNldFNlbGVjdGVkQ29udHJhY3RJZChjb250cmFjdC5pZCBhcyBzdHJpbmcpXG4gICAgICAgIHNob3dIaXN0b3J5TW9kYWwoKVxuICAgICAgfSxcbiAgICB9KVxuICAgIHJldHVybiBtZW51XG4gIH0sIFthc2tGb3JSZW1vdmFsQ29uZmlybWF0aW9uLCB2aXN1YWxpemVQZXJtaXNzaW9uLCBkZWxldGVQZXJtaXNzaW9uLCBjcmVhdGVQZXJtaXNzaW9uXSlcblxuICBjb25zdCBhY3Rpb25zID0gdXNlQ2FsbGJhY2soKCkgPT4gKFxuICAgIDxDb250cmFjdExpc3RBY3Rpb25zXG4gICAgICBkaXNhYmxlZFJlbW92ZUJ1dHRvbj17c2VsZWN0aW9uLmxlbmd0aCA9PT0gMH1cbiAgICAgIG9uQWRkQ2xpY2s9e29wZW5BZGREcmF3ZXJ9XG4gICAgICBvblJlbW92ZUNsaWNrPXsoKSA9PiBhc2tGb3JSZW1vdmFsQ29uZmlybWF0aW9uKHNlbGVjdGlvbil9XG4gICAgICBjcmVhdGVQZXJtaXNzaW9uPXtjcmVhdGVQZXJtaXNzaW9ufVxuICAgICAgZGVsZXRlUGVybWlzc2lvbj17ZGVsZXRlUGVybWlzc2lvbn1cbiAgICAvPlxuICApLCBbc2VsZWN0aW9uXSlcblxuICBpZiAoZXJyb3IpIHJldHVybiA8RXJyb3JTY3JlZW4gZXJyb3I9e2Vycm9yfSAvPlxuXG4gIHJldHVybiAoXG4gICAgPEVycm9yQm91bmRhcnlcbiAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyBlcnJvciB9KSA9PiAoXG4gICAgICAgIDxFcnJvclNjcmVlbiBlcnJvcj17ZXJyb3J9IC8+XG4gICAgICApfVxuICAgID5cbiAgICAgIDxEYXRhVGFibGVJbnRcbiAgICAgICAgaXRlbXM9e2RhdGE/LnZhbHVlIGFzIENvbnRyYWN0W119XG4gICAgICAgIGl0ZW1zQ291bnQ9e2RhdGE/LlsnQG9kYXRhLmNvdW50J119XG4gICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XG4gICAgICAgIHBhZ2luYXRlZFxuICAgICAgICBvblBhZ2VDaGFuZ2U9e3NldFBhZ2luYXRpb25Db25maWd9XG4gICAgICAgIHNvcnRDb25maWc9e3NvcnRDb25maWd9XG4gICAgICAgIG9uU29ydENoYW5nZT17c2V0U29ydENvbmZpZ31cbiAgICAgICAgb25TZWFyY2hUZXh0Q2hhbmdlPXtmaWx0ZXJEYXRhfVxuICAgICAgICBsb2FkaW5nPXtpc0xvYWRpbmd9XG4gICAgICAgIGhhc0NvbnRyb2xzQ29sdW1uXG4gICAgICAgIG1lbnVPcHRpb25zPXttZW51T3B0aW9uc31cbiAgICAgICAgcmVuZGVyQWN0aW9ucz17YWN0aW9uc31cbiAgICAgICAgc2VsZWN0aW9uPXtzZWxlY3Rpb259XG4gICAgICAgIG9uU2VsZWN0aW9uPXtzZXRTZWxlY3Rpb259XG4gICAgICAgIGhhc1NlYXJjaFxuICAgICAgLz5cbiAgICAgIHtpc0FkZERyYXdlck9wZW4gJiYgPENvbnRyYWN0Q3JlYXRlRHJhd2VyXG4gICAgICAgIHRvRHVwbGljYXRlPXt0b0R1cGxpY2F0ZX1cbiAgICAgICAgaXNPcGVuPXtpc0FkZERyYXdlck9wZW59XG4gICAgICAgIG9uRGlzbWlzcz17KCkgPT4ge1xuICAgICAgICAgIHNldFRvRHVwbGljYXRlKHVuZGVmaW5lZClcbiAgICAgICAgICBjbG9zZUFkZERyYXdlcigpXG4gICAgICAgIH19XG4gICAgICAvPn1cblxuICAgICAge2lzSGlzdG9yeU1vZGFsT3BlbiAmJlxuICAgICAgICA8Q29udHJhY3RIaXN0b3J5TW9kYWxcbiAgICAgICAgICBpc09wZW49e2lzSGlzdG9yeU1vZGFsT3Blbn1cbiAgICAgICAgICBvbkRpc21pc3M9e2hpZGVIaXN0b3J5TW9kYWx9XG4gICAgICAgICAgY29udHJhY3RJZD17c2VsZWN0ZWRDb250cmF0SWR9XG4gICAgICAgIC8+XG4gICAgICB9XG4gICAgPC9FcnJvckJvdW5kYXJ5PlxuICApXG59XG5cbmNvbnN0IGNvbHVtbnM6IERhdGFUYWJsZUNvbHVtbjxDb250cmFjdD5bXSA9IFtcbiAge1xuICAgIGhlYWRlcjogJ07CuiBkbyBjb250cmF0bycsXG4gICAgZmllbGQ6ICdudW1lcm9Qcm9wb3N0YScsXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgICBmaWx0ZXJPcHRpb25zOiB7XG4gICAgICBxdWVyeVR5cGU6ICdzdHJpbmcnLFxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXG4gICAgfSxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBmb3JtYXQ6IChpdGVtKSA9PiBmb3JtYXRQcm9wb3NhbE51bWJlcihpdGVtLm51bWVyb1Byb3Bvc3RhKSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ07CuiBkYSBwcm9wb3N0YScsXG4gICAgZmllbGQ6ICdudW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCcsXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgICBmaWx0ZXJPcHRpb25zOiB7XG4gICAgICBxdWVyeVR5cGU6ICdzdHJpbmcnLFxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXG4gICAgfSxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBmb3JtYXQ6IChpdGVtKSA9PiBmb3JtYXRQcm9wb3NhbE51bWJlcihpdGVtLm51bWVyb1Byb3Bvc3RhQ29tZXJjaWFsKSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ1RpcG8gZGUgY29udHJhdG8nLFxuICAgIGZpZWxkOiAndGlwb0NvbnRyYXRvJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ3JlY29yZCcsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICAgIHJlY29yZDogQ29udHJhY3RUeXBlUmVjb3JkLFxuICAgIH0sXG4gICAgdHlwZTogJ3N0cmluZycsXG4gICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xuICAgICAgaWYgKGl0ZW0udGlwb0NvbnRyYXRvICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIENvbnRyYWN0VHlwZVJlY29yZFtpdGVtLnRpcG9Db250cmF0b11cbiAgICAgIH1cbiAgICB9LFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnU8OzY2lvIHJlc3BvbnPDoXZlbCcsXG4gICAgZmllbGQ6ICdyZXNwb25zYXZlbFRlY25pY28ubm9tZScsXG4gICAgZmlsdGVyYWJsZTogdHJ1ZSxcbiAgICBmaWx0ZXJPcHRpb25zOiB7XG4gICAgICBxdWVyeVR5cGU6ICdzdHJpbmcnLFxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXG4gICAgfSxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ1Jlc3BvbnPDoXZlbCBjbGllbnRlJyxcbiAgICBmaWVsZDogJ3Jlc3BvbnNhdmVsQ2xpZW50ZS5ub21lJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ3N0cmluZycsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdzdHJpbmcnLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnRXhlcmPDrWNpbycsXG4gICAgZmllbGQ6ICdleGVyY2ljaW8nLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ251bWJlcicsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdudW1iZXInLFxuICAgIGZpbHRlcmFibGU6IHRydWUsXG4gICAgc29ydGFibGU6IHRydWUsXG4gIH0sXG4gIHtcbiAgICBoZWFkZXI6ICdRdGQuIGhvcmFzJyxcbiAgICBmaWVsZDogJ3F0ZEhvcmFzJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ251bWJlcicsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdudW1iZXInLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnJSBkZSDDqnhpdG8nLFxuICAgIGZpZWxkOiAncGVyY2VudHVhbEV4aXRvJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ251bWJlcicsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdudW1iZXInLFxuICAgIHNvcnRhYmxlOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnRGF0YSBkZSBpbmNsdXPDo28nLFxuICAgIGZpZWxkOiAnZGF0YUluY2x1c2FvJyxcbiAgICBmb3JtYXQ6IChpdGVtKSA9PiBpdGVtLmRhdGFJbmNsdXNhb1xuICAgICAgPyBmb3JtYXQobmV3IERhdGUoaXRlbS5kYXRhSW5jbHVzYW8pLCAnZGQvTU0veXl5eScpXG4gICAgICA6ICcnLFxuICAgIGZpbHRlcmFibGU6IHRydWUsXG4gICAgZmlsdGVyT3B0aW9uczoge1xuICAgICAgcXVlcnlUeXBlOiAnZGF0ZScsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICAgIHR5cGU6ICdkYXRlJyxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ1ZpZ8OqbmNpYScsXG4gICAgZmllbGQ6ICdkYXRhSW5pY2lvJyxcbiAgICBmb3JtYXQ6IChpdGVtKSA9PiAoaXRlbS5kYXRhSW5pY2lvICYmIGl0ZW0uZGF0YUZpbSlcbiAgICAgID8gYCR7Zm9ybWF0KG5ldyBEYXRlKGl0ZW0uZGF0YUluaWNpbyksICdkZC9NTS95eXl5Jyl9IGEgJHtmb3JtYXQobmV3IERhdGUoaXRlbS5kYXRhRmltKSwgJ2RkL01NL3l5eXknKX1gXG4gICAgICA6ICcnLFxuICAgIHR5cGU6ICdkYXRlJyxcbiAgICBzb3J0YWJsZTogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGhlYWRlcjogJ03DqnMgcmVub3Zhw6fDo28nLFxuICAgIGZpZWxkOiAnbWVzUmVub3ZhY2FvJyxcbiAgICBmaWx0ZXJhYmxlOiB0cnVlLFxuICAgIGZpbHRlck9wdGlvbnM6IHtcbiAgICAgIHF1ZXJ5VHlwZTogJ3JlY29yZCcsXG4gICAgICBxdWVyeU1vZGU6ICdkZWZhdWx0JyxcbiAgICAgIHJlY29yZDogTW9udGhzUmVjb3JkLFxuICAgIH0sXG4gICAgdHlwZTogJ3N0cmluZycsXG4gICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xuICAgICAgaWYgKGl0ZW0ubWVzUmVub3ZhY2FvICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIE1vbnRoc1JlY29yZFtpdGVtLm1lc1Jlbm92YWNhb11cbiAgICAgIH1cbiAgICB9LFxuICB9LFxuICB7XG4gICAgaGVhZGVyOiAnU2l0dWHDp8OjbycsXG4gICAgZmllbGQ6ICdzaXR1YWNhbycsXG4gICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xuICAgICAgaWYgKGl0ZW0uc2l0dWFjYW8gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gPENvbnRyYWN0U2l0dWF0aW9uIHNpdHVhdGlvbj17aXRlbS5zaXR1YWNhb30gLz5cbiAgICAgIH1cbiAgICB9LFxuICB9LFxuXVxuXG5jb25zdCB1c2VDYW5jZWwgPSAoKTogVXNlTXV0YXRpb25SZXN1bHQgPT4ge1xuICBjb25zdCB7IHNob3dOb3RpZmljYXRpb24gfSA9IHVzZU5vdGlmaWNhdGlvbnMoKVxuXG4gIHJldHVybiB1c2VNdXRhdGlvbihcbiAgICAoaXRlbSkgPT4gY29udHJhY3RTZXJ2aWNlLmNhbmNlbChpdGVtIGFzIHN0cmluZyksXG4gICAge1xuICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xuICAgICAgICAgIG1lc3NhZ2U6ICdDb250cmF0byBjYW5jZWxhZG8gY29tIHN1Y2Vzc28hJyxcbiAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5zdWNjZXNzLFxuICAgICAgICB9KVxuICAgICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcygpXG4gICAgICB9LFxuICAgICAgb25FcnJvcjogKCkgPT4ge1xuICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgICBtZXNzYWdlOiAnTsOjbyBmb2kgcG9zc8OtdmVsIGNhbmNlbGFyIG8gY29udHJhdG8nLFxuICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxuICAgICAgICB9KVxuICAgICAgfSxcbiAgICB9LFxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0TGlzdFxuIl19