import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AnalyticalRevisionContext } from "/src/modules/audit/analyticalRevision/context/AnalyticalRevisionContext.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditPatrimonialTestingSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname,
    search
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isActiveGroupExpanded, setIsActiveGroupExpanded] = useState(true);
  const [isPassiveGroupExpanded, setIsPassiveGroupExpanded] = useState(true);
  const searchParams = useMemo(() => new URLSearchParams(search), [search]);
  const searchCompanyId = searchParams.get("searchCompanyId");
  const {
    audit,
    group
  } = useContext(AnalyticalRevisionContext);
  const active = useMemo(() => group?.filter((gr) => gr.codigo.split(".")?.[0] === "1"), [group]);
  const passive = useMemo(() => group?.filter((gr) => gr.codigo.split(".")?.[0] === "2"), [group]);
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "BarChartVerticalFilterSolid",
      name: "Ativo",
      isExpanded: isActiveGroupExpanded,
      permission: "Auditoria",
      url: "",
      links: active?.map((gr) => {
        return {
          key: gr.codigo,
          name: gr.descricao,
          title: gr.descricao,
          permission: "Auditoria",
          url: `${pathname}/${gr.codigo.replace(".", "-")}${searchCompanyId ? `?searchCompanyId=${searchCompanyId}` : ""}`
        };
      })
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "BarChartVerticalFilter",
      name: "Passivo",
      isExpanded: isPassiveGroupExpanded,
      permission: "Auditoria",
      url: "",
      links: passive?.map((gr) => {
        return {
          key: gr.codigo,
          name: gr.descricao,
          title: gr.descricao,
          permission: "Auditoria",
          url: `${pathname}/${gr.codigo.replace(".", "-")}${searchCompanyId ? `?searchCompanyId=${searchCompanyId}` : ""}`
        };
      })
    }]
  }], [disableTabs, isActiveGroupExpanded, isPassiveGroupExpanded, pathname, active, passive]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group2, index) => {
      filteredGroup[index].links = group2.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        item.name === "Ativo" ? setIsActiveGroupExpanded(!isActiveGroupExpanded) : setIsPassiveGroupExpanded(!isPassiveGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Testes de contas patrimoniais", subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx",
    lineNumber: 97,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx",
    lineNumber: 96,
    columnNumber: 68
  }, this), groups: permissionNav, onLinkClick: handleClick, goBack: () => navigate(`/audit/audits/${audit?.id}/control-panel/analysis/dashboard`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx",
    lineNumber: 96,
    columnNumber: 10
  }, this);
};
_s(AuditPatrimonialTestingSideMenu, "U4OnE5VIj5eHu35++JBgAbGEiE8=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme];
});
_c = AuditPatrimonialTestingSideMenu;
export default AuditPatrimonialTestingSideMenu;
var _c;
$RefreshReg$(_c, "AuditPatrimonialTestingSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditPatrimonialTestingSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0dVOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0dWLFNBQXlCQSxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFekUsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUVyQixTQUFTQyxpQ0FBaUM7QUFDMUMsU0FBU0MsMEJBQTBCO0FBRW5DLE1BQU1DLGtDQUFzQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2hELFFBQU1DLFdBQVdYLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVZO0FBQUFBLElBQVVDO0FBQUFBLEVBQU8sSUFBSWQsWUFBWTtBQUN6QyxRQUFNO0FBQUEsSUFBRWU7QUFBQUEsRUFBYyxJQUFJYixlQUFlO0FBQ3pDLFFBQU07QUFBQSxJQUFFYztBQUFBQSxJQUFRQztBQUFBQSxJQUFTQztBQUFBQSxJQUFZQztBQUFBQSxFQUFTLElBQUliLFNBQVM7QUFDM0QsUUFBTSxDQUFDYyxhQUFhQyxjQUFjLElBQUl0QixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDdUIsdUJBQXVCQyx3QkFBd0IsSUFBSXhCLFNBQWtCLElBQUk7QUFDaEYsUUFBTSxDQUFDeUIsd0JBQXdCQyx5QkFBeUIsSUFBSTFCLFNBQWtCLElBQUk7QUFDbEYsUUFBTTJCLGVBQWU1QixRQUFRLE1BQU0sSUFBSTZCLGdCQUFnQmIsTUFBTSxHQUFHLENBQUNBLE1BQU0sQ0FBQztBQUN4RSxRQUFNYyxrQkFBa0JGLGFBQWFHLElBQUksaUJBQWlCO0FBQzFELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUluQyxXQUFXWSx5QkFBeUI7QUFFeEMsUUFBTXdCLFNBQVNsQyxRQUFRLE1BQU1pQyxPQUFPRSxPQUFPQyxRQUFNQSxHQUFHQyxPQUFPQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUNMLEtBQUssQ0FBQztBQUM1RixRQUFNTSxVQUFVdkMsUUFBUSxNQUFNaUMsT0FBT0UsT0FBT0MsUUFBTUEsR0FBR0MsT0FBT0MsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDTCxLQUFLLENBQUM7QUFFN0YsUUFBTU8sZ0JBQWlDeEMsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRXlDLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLFVBQVVWLE9BQU9XLGFBQWFoQyxtQkFBbUJpQztBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxZQUFZdkI7QUFBQUEsTUFDWndCLFlBQVk7QUFBQSxNQUNaQyxLQUFLO0FBQUEsTUFDTFIsT0FBT1AsUUFBUWdCLElBQUlkLFFBQU07QUFDdkIsZUFBTztBQUFBLFVBQ0xlLEtBQUtmLEdBQUdDO0FBQUFBLFVBQ1JTLE1BQU1WLEdBQUdnQjtBQUFBQSxVQUNUQyxPQUFPakIsR0FBR2dCO0FBQUFBLFVBQ1ZKLFlBQVk7QUFBQSxVQUNaQyxLQUFNLEdBQUVsQyxZQUFZcUIsR0FBR0MsT0FBT2lCLFFBQVEsS0FBSyxHQUFHLElBQUl4QixrQkFBbUIsb0JBQW1CQSxvQkFBb0I7QUFBQSxRQUM5RztBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsR0FDQTtBQUFBLE1BQ0VZLFVBQVVWLE9BQU9XLGFBQWFoQyxtQkFBbUJpQztBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxZQUFZckI7QUFBQUEsTUFDWnNCLFlBQVk7QUFBQSxNQUNaQyxLQUFLO0FBQUEsTUFDTFIsT0FBT0YsU0FBU1csSUFBSWQsUUFBTTtBQUN4QixlQUFPO0FBQUEsVUFDTGUsS0FBS2YsR0FBR0M7QUFBQUEsVUFDUlMsTUFBTVYsR0FBR2dCO0FBQUFBLFVBQ1RDLE9BQU9qQixHQUFHZ0I7QUFBQUEsVUFDVkosWUFBWTtBQUFBLFVBQ1pDLEtBQU0sR0FBRWxDLFlBQVlxQixHQUFHQyxPQUFPaUIsUUFBUSxLQUFLLEdBQUcsSUFBSXhCLGtCQUFtQixvQkFBbUJBLG9CQUFvQjtBQUFBLFFBQzlHO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFFTCxDQUFDLEdBQ0EsQ0FBQ1IsYUFBYUUsdUJBQXVCRSx3QkFBd0JYLFVBQVVtQixRQUFRSyxPQUFPLENBQUM7QUFFMUYsUUFBTWdCLGdCQUFnQnZELFFBQVEsTUFBTTtBQUNsQyxVQUFNd0QsZ0JBQWlDLENBQUMsR0FBR2hCLGFBQWE7QUFDeERnQixrQkFBY0MsUUFBUSxDQUFDeEIsUUFBT3lCLFVBQVU7QUFDdENGLG9CQUFjRSxLQUFLLEVBQUVqQixRQUFRUixPQUFNUSxNQUFNTixPQUFPd0IsYUFBVzFDLGNBQWMwQyxRQUFRWCxZQUE0QixZQUFZLENBQUM7QUFBQSxJQUM1SCxDQUFDO0FBQ0QsV0FBT1E7QUFBQUEsRUFDVCxHQUFHLENBQUNoQixhQUFhLENBQUM7QUFFbEIsUUFBTW9CLGNBQWNBLENBQUNDLElBQWlCQyxTQUFvQjtBQUN4RCxRQUFJRCxPQUFPRSxVQUFhRCxTQUFTQyxRQUFXO0FBQzFDRixTQUFHRyxlQUFlO0FBQ2xCLFVBQUlGLEtBQUtyQixPQUFPO0FBQ2RxQixhQUFLaEIsU0FBUyxVQUNWckIseUJBQXlCLENBQUNELHFCQUFxQixJQUMvQ0csMEJBQTBCLENBQUNELHNCQUFzQjtBQUFBLE1BQ3ZELE9BQU87QUFDTFosaUJBQVNnRCxLQUFLYixHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBbEQsWUFBVSxNQUFNO0FBQ2QsVUFBTWtFLGtCQUFrQmpDLE9BQU9rQyxTQUFTQyxLQUFLQyxhQUFXQSxRQUFRQyxxQkFBcUIsSUFBSSxFQUFFO0FBQzNGOUMsbUJBQWUwQyxtQkFBbUJqQyxPQUFPVyxhQUFhLENBQUM7QUFBQSxFQUN6RCxHQUFHLENBQUNYLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLGlDQUNOLFVBQ0UsdUJBQUMsUUFDQyxNQUNHLGtCQUFpQkEsT0FBT3NDLFVBQVVDLHVCQUNqQ3ZDLE9BQU9zQyxVQUFVRSxzQkFDWixHQUFFeEMsT0FBT3NDLFNBQVNFLG1DQUFtQ3hDLE9BQU9zQyxVQUFVRyxtQkFDdkV6QyxPQUFPc0MsVUFBVUksTUFHekIsUUFBTyxTQUVQLGlDQUFDLFFBQ0MsUUFBUTtBQUFBLElBQ05DLE1BQU07QUFBQSxNQUNKQyxPQUFPMUQsT0FBTzJELEtBQUssR0FBRztBQUFBLE1BQ3RCekQsWUFBWUEsV0FBVzBEO0FBQUFBLE1BQ3ZCekQsVUFBVUEsU0FBUzBEO0FBQUFBLE1BQ25CQyxxQkFBcUI5RCxPQUFPMkQsS0FBSyxHQUFHO0FBQUEsTUFDcENJLFlBQVk5RCxRQUFRK0Q7QUFBQUEsTUFDcEJDLFVBQVU7QUFBQSxNQUNWQyxjQUFjakUsUUFBUWtFO0FBQUFBLE1BQ3RCLFdBQVc7QUFBQSxRQUNUTCxxQkFBcUI5RCxPQUFPMkQsS0FBSyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUNBLE9BQUssTUFFSjdDO0FBQUFBLFdBQU9zQyxVQUFVZ0I7QUFBQUEsSUFBYTtBQUFBLElBQUkvRSxxQkFBcUJ5QixPQUFPc0MsVUFBVUcsY0FBd0I7QUFBQSxPQWpCbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBLEdBRUYsUUFBUWxCLGVBQ1IsYUFBYUssYUFDYixRQUFRLE1BQU05QyxTQUFVLGlCQUFnQmtCLE9BQU8wQyxxQ0FBcUMsS0FwQ3RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQ3dGO0FBRzVGO0FBQUM3RCxHQTdIS0QsaUNBQW1DO0FBQUEsVUFDdEJULGFBQ1lELGFBQ0hFLGdCQUN3QkksUUFBUTtBQUFBO0FBQUErRSxLQUp0RDNFO0FBK0hOLGVBQWVBO0FBQStCLElBQUEyRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQZXJtaXNzaW9ucyIsIkxpbmsiLCJTaWRlTWVudSIsImZvcm1hdFByb3Bvc2FsTnVtYmVyIiwidXNlVGhlbWUiLCJUZXh0IiwiQW5hbHl0aWNhbFJldmlzaW9uQ29udGV4dCIsIkF1ZGl0U2l0dWF0aW9uRW51bSIsIkF1ZGl0UGF0cmltb25pYWxUZXN0aW5nU2lkZU1lbnUiLCJfcyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJzZWFyY2giLCJoYXNQZXJtaXNzaW9uIiwiY29sb3JzIiwic3BhY2luZyIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsImRpc2FibGVUYWJzIiwic2V0RGlzYWJsZVRhYnMiLCJpc0FjdGl2ZUdyb3VwRXhwYW5kZWQiLCJzZXRJc0FjdGl2ZUdyb3VwRXhwYW5kZWQiLCJpc1Bhc3NpdmVHcm91cEV4cGFuZGVkIiwic2V0SXNQYXNzaXZlR3JvdXBFeHBhbmRlZCIsInNlYXJjaFBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNlYXJjaENvbXBhbnlJZCIsImdldCIsImF1ZGl0IiwiZ3JvdXAiLCJhY3RpdmUiLCJmaWx0ZXIiLCJnciIsImNvZGlnbyIsInNwbGl0IiwicGFzc2l2ZSIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsImRpc2FibGVkIiwic2l0dWFjYW8iLCJDYW5jZWxhZG8iLCJpY29uIiwibmFtZSIsImlzRXhwYW5kZWQiLCJwZXJtaXNzaW9uIiwidXJsIiwibWFwIiwia2V5IiwiZGVzY3JpY2FvIiwidGl0bGUiLCJyZXBsYWNlIiwicGVybWlzc2lvbk5hdiIsImZpbHRlcmVkR3JvdXAiLCJmb3JFYWNoIiwiaW5kZXgiLCJuYXZMaW5rIiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsInZlcmlmeVNpdHVhdGlvbiIsImVtcHJlc2FzIiwic29tZSIsImVtcHJlc2EiLCJzaXR1YWNhb1JldmlzYW8iLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsImlkIiwicm9vdCIsImNvbG9yIiwiZ3JheSIsInNlbWlib2xkIiwicDE0IiwidGV4dERlY29yYXRpb25Db2xvciIsIm1hcmdpbkxlZnQiLCJsZyIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwibWQiLCJub21lRmFudGFzaWEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0UGF0cmltb25pYWxUZXN0aW5nU2lkZU1lbnUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzL0F1ZGl0UGF0cmltb25pYWxUZXN0aW5nU2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIE1vdXNlRXZlbnQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSU5hdkxpbmtHcm91cCwgSU5hdkxpbmsgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QvbGliL05hdidcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgc2VydmljZUNvZGVzLCB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXHJcbmltcG9ydCB7IExpbmssIFNpZGVNZW51IH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgVGV4dCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgUmV2aXNpb25Hcm91cCB9IGZyb20gJy4uLy4uLy4uL2RvbWFpbi9BbmFseXRpY2FsUmV2aXNpb24nXHJcbmltcG9ydCB7IEFuYWx5dGljYWxSZXZpc2lvbkNvbnRleHQgfSBmcm9tICcuLi9hbmFseXRpY2FsUmV2aXNpb24vY29udGV4dC9BbmFseXRpY2FsUmV2aXNpb25Db250ZXh0J1xyXG5pbXBvcnQgeyBBdWRpdFNpdHVhdGlvbkVudW0gfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvZW51bXMvQXVkaXRTaXR1YXRpb25FbnVtJ1xyXG5cclxuY29uc3QgQXVkaXRQYXRyaW1vbmlhbFRlc3RpbmdTaWRlTWVudTogRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcbiAgY29uc3QgeyBwYXRobmFtZSwgc2VhcmNoIH0gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXHJcbiAgY29uc3QgeyBjb2xvcnMsIHNwYWNpbmcsIGZvbnRXZWlnaHQsIGZvbnRTaXplIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgW2Rpc2FibGVUYWJzLCBzZXREaXNhYmxlVGFic10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNBY3RpdmVHcm91cEV4cGFuZGVkLCBzZXRJc0FjdGl2ZUdyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSlcclxuICBjb25zdCBbaXNQYXNzaXZlR3JvdXBFeHBhbmRlZCwgc2V0SXNQYXNzaXZlR3JvdXBFeHBhbmRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKVxyXG4gIGNvbnN0IHNlYXJjaFBhcmFtcyA9IHVzZU1lbW8oKCkgPT4gbmV3IFVSTFNlYXJjaFBhcmFtcyhzZWFyY2gpLCBbc2VhcmNoXSlcclxuICBjb25zdCBzZWFyY2hDb21wYW55SWQgPSBzZWFyY2hQYXJhbXMuZ2V0KCdzZWFyY2hDb21wYW55SWQnKVxyXG4gIGNvbnN0IHtcclxuICAgIGF1ZGl0LFxyXG4gICAgZ3JvdXAsXHJcbiAgfSA9IHVzZUNvbnRleHQoQW5hbHl0aWNhbFJldmlzaW9uQ29udGV4dClcclxuXHJcbiAgY29uc3QgYWN0aXZlID0gdXNlTWVtbygoKSA9PiBncm91cD8uZmlsdGVyKGdyID0+IGdyLmNvZGlnby5zcGxpdCgnLicpPy5bMF0gPT09ICcxJyksIFtncm91cF0pIGFzIFJldmlzaW9uR3JvdXBbXVxyXG4gIGNvbnN0IHBhc3NpdmUgPSB1c2VNZW1vKCgpID0+IGdyb3VwPy5maWx0ZXIoZ3IgPT4gZ3IuY29kaWdvLnNwbGl0KCcuJyk/LlswXSA9PT0gJzInKSwgW2dyb3VwXSkgYXMgUmV2aXNpb25Hcm91cFtdXHJcblxyXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBpY29uOiAnQmFyQ2hhcnRWZXJ0aWNhbEZpbHRlclNvbGlkJyxcclxuICAgICAgICAgIG5hbWU6ICdBdGl2bycsXHJcbiAgICAgICAgICBpc0V4cGFuZGVkOiBpc0FjdGl2ZUdyb3VwRXhwYW5kZWQsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogJycsXHJcbiAgICAgICAgICBsaW5rczogYWN0aXZlPy5tYXAoZ3IgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIGtleTogZ3IuY29kaWdvLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyLmRlc2NyaWNhbyxcclxuICAgICAgICAgICAgICB0aXRsZTogZ3IuZGVzY3JpY2FvLFxyXG4gICAgICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgICAgIHVybDogYCR7cGF0aG5hbWV9LyR7Z3IuY29kaWdvLnJlcGxhY2UoJy4nLCAnLScpfSR7c2VhcmNoQ29tcGFueUlkID8gYD9zZWFyY2hDb21wYW55SWQ9JHtzZWFyY2hDb21wYW55SWR9YCA6ICcnfWAsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pIGFzIElOYXZMaW5rW10sXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkaXNhYmxlZDogYXVkaXQ/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvLFxyXG4gICAgICAgICAgaWNvbjogJ0JhckNoYXJ0VmVydGljYWxGaWx0ZXInLFxyXG4gICAgICAgICAgbmFtZTogJ1Bhc3Npdm8nLFxyXG4gICAgICAgICAgaXNFeHBhbmRlZDogaXNQYXNzaXZlR3JvdXBFeHBhbmRlZCxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiAnJyxcclxuICAgICAgICAgIGxpbmtzOiBwYXNzaXZlPy5tYXAoZ3IgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIGtleTogZ3IuY29kaWdvLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyLmRlc2NyaWNhbyxcclxuICAgICAgICAgICAgICB0aXRsZTogZ3IuZGVzY3JpY2FvLFxyXG4gICAgICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgICAgIHVybDogYCR7cGF0aG5hbWV9LyR7Z3IuY29kaWdvLnJlcGxhY2UoJy4nLCAnLScpfSR7c2VhcmNoQ29tcGFueUlkID8gYD9zZWFyY2hDb21wYW55SWQ9JHtzZWFyY2hDb21wYW55SWR9YCA6ICcnfWAsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pIGFzIElOYXZMaW5rW10sXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgXSwgW2Rpc2FibGVUYWJzLCBpc0FjdGl2ZUdyb3VwRXhwYW5kZWQsIGlzUGFzc2l2ZUdyb3VwRXhwYW5kZWQsIHBhdGhuYW1lLCBhY3RpdmUsIHBhc3NpdmVdKVxyXG5cclxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZEdyb3VwOiBJTmF2TGlua0dyb3VwW10gPSBbLi4ubmF2TGlua0dyb3Vwc11cclxuICAgIGZpbHRlcmVkR3JvdXAuZm9yRWFjaCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgIGZpbHRlcmVkR3JvdXBbaW5kZXhdLmxpbmtzID0gZ3JvdXAubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gaGFzUGVybWlzc2lvbihuYXZMaW5rLnBlcm1pc3Npb24gYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicpKVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmaWx0ZXJlZEdyb3VwXHJcbiAgfSwgW25hdkxpbmtHcm91cHNdKVxyXG5cclxuICBjb25zdCBoYW5kbGVDbGljayA9IChldj86IE1vdXNlRXZlbnQsIGl0ZW0/OiBJTmF2TGluaykgPT4ge1xyXG4gICAgaWYgKGV2ICE9PSB1bmRlZmluZWQgJiYgaXRlbSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgaWYgKGl0ZW0ubGlua3MpIHtcclxuICAgICAgICBpdGVtLm5hbWUgPT09ICdBdGl2bydcclxuICAgICAgICAgID8gc2V0SXNBY3RpdmVHcm91cEV4cGFuZGVkKCFpc0FjdGl2ZUdyb3VwRXhwYW5kZWQpXHJcbiAgICAgICAgICA6IHNldElzUGFzc2l2ZUdyb3VwRXhwYW5kZWQoIWlzUGFzc2l2ZUdyb3VwRXhwYW5kZWQpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbmF2aWdhdGUoaXRlbS51cmwpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB2ZXJpZnlTaXR1YXRpb24gPSBhdWRpdD8uZW1wcmVzYXMuc29tZShlbXByZXNhID0+IGVtcHJlc2Euc2l0dWFjYW9SZXZpc2FvID09PSAoMCB8IDEpKSBhcyBib29sZWFuXHJcbiAgICBzZXREaXNhYmxlVGFicyh2ZXJpZnlTaXR1YXRpb24gfHwgYXVkaXQ/LnNpdHVhY2FvID09PSAwKVxyXG4gIH0sIFthdWRpdF0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U2lkZU1lbnVcclxuICAgICAgdGl0bGU9J1Rlc3RlcyBkZSBjb250YXMgcGF0cmltb25pYWlzJ1xyXG4gICAgICBzdWJ0aXRsZT17XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIGhyZWY9e1xyXG4gICAgICAgICAgICBgL2FkbWluL2NsaWVudHMvJHthdWRpdD8uY29udHJhdG8/LmNsaWVudGVJZH0vY29udHJhY3RzLyR7XHJcbiAgICAgICAgICAgICAgYXVkaXQ/LmNvbnRyYXRvPy5jb250cmF0b1ByaW5jaXBhbElkXHJcbiAgICAgICAgICAgICAgICA/IGAke2F1ZGl0Py5jb250cmF0by5jb250cmF0b1ByaW5jaXBhbElkfT9zdWJjb250cmFjdD0ke2F1ZGl0Py5jb250cmF0bz8ubnVtZXJvUHJvcG9zdGF9YFxyXG4gICAgICAgICAgICAgICAgOiBhdWRpdD8uY29udHJhdG8/LmlkXHJcbiAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0YXJnZXQ9XCJibGFua1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBmb250V2VpZ2h0LnNlbWlib2xkLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnRTaXplLnAxNCxcclxuICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiBzcGFjaW5nLmxnLFxyXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6IDIwMCxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogc3BhY2luZy5tZCxcclxuICAgICAgICAgICAgICAgICc6OmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7YXVkaXQ/LmNvbnRyYXRvPy5ub21lRmFudGFzaWF9IC0ge2Zvcm1hdFByb3Bvc2FsTnVtYmVyKGF1ZGl0Py5jb250cmF0bz8ubnVtZXJvUHJvcG9zdGEgYXMgc3RyaW5nKX1cclxuICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIH1cclxuICAgICAgZ3JvdXBzPXtwZXJtaXNzaW9uTmF2fVxyXG4gICAgICBvbkxpbmtDbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgIGdvQmFjaz17KCkgPT4gbmF2aWdhdGUoYC9hdWRpdC9hdWRpdHMvJHthdWRpdD8uaWR9L2NvbnRyb2wtcGFuZWwvYW5hbHlzaXMvZGFzaGJvYXJkYCl9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRQYXRyaW1vbmlhbFRlc3RpbmdTaWRlTWVudVxyXG4iXX0=