import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsCenterList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport4_react["useMemo"];
import { FlexColumn } from "/src/shared/components/FlexBox/index.ts";
import { ScrollablePane } from "/src/shared/components/scrollablePane/index.ts";
import NotificationCenterItem from "/src/shared/components/notifications/components/NotificationCenterItem.tsx?t=1701096626433";
import NotificationsCenterEmpty from "/src/shared/components/notifications/components/NotificationsCenterEmpty.tsx";
const NotificationsCenterList = (props) => {
  _s();
  const {
    module,
    notifications,
    onDismiss
  } = props;
  const styles = useStyles();
  const notificationList = useMemo(() => {
    if (module) {
      return notifications.filter((notification) => notification.modulo === module);
    } else {
      return notifications;
    }
  }, [module, notifications]);
  if (notificationList.length === 0) {
    return /* @__PURE__ */ jsxDEV(NotificationsCenterEmpty, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx",
      lineNumber: 31,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: styles.navLinkContainer, children: /* @__PURE__ */ jsxDEV(ScrollablePane, { children: /* @__PURE__ */ jsxDEV(FlexColumn, { children: notificationList.map((item) => /* @__PURE__ */ jsxDEV(NotificationCenterItem, { notification: item, onDismiss }, item.id, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx",
    lineNumber: 36,
    columnNumber: 41
  }, this)) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx",
    lineNumber: 35,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx",
    lineNumber: 34,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(NotificationsCenterList, "Zysk4bD7SlAkO9F+l6BaNgdxkYM=", false, function() {
  return [useStyles];
});
_c = NotificationsCenterList;
export default NotificationsCenterList;
const useStyles = () => {
  const navLinkContainer = mergeStyles({
    overflowY: "auto",
    maxHeight: "inherit",
    height: "100%",
    "> div": {
      marginTop: "64px"
    }
  });
  return {
    navLinkContainer
  };
};
var _c;
$RefreshReg$(_c, "NotificationsCenterList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsCenterList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUJOLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFhQyxlQUFlO0FBRzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxzQkFBc0I7QUFDL0IsT0FBT0MsNEJBQTRCO0FBQ25DLE9BQU9DLDhCQUE4QjtBQVFyQyxNQUFNQywwQkFBNkRDLFdBQVU7QUFBQUMsS0FBQTtBQUMzRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBZUM7QUFBQUEsRUFBVSxJQUFJSjtBQUU3QyxRQUFNSyxTQUFTQyxVQUFVO0FBRXpCLFFBQU1DLG1CQUFtQmIsUUFBUSxNQUFNO0FBQ3JDLFFBQUlRLFFBQVE7QUFDVixhQUFPQyxjQUFjSyxPQUFPQyxrQkFBZ0JBLGFBQWFDLFdBQVdSLE1BQU07QUFBQSxJQUM1RSxPQUFPO0FBQ0wsYUFBT0M7QUFBQUEsSUFDVDtBQUFBLEVBQ0YsR0FBRyxDQUFDRCxRQUFRQyxhQUFhLENBQUM7QUFFMUIsTUFBSUksaUJBQWlCSSxXQUFXLEdBQUc7QUFDakMsV0FDRSx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsRUFFN0I7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBV04sT0FBT08sa0JBQ3JCLGlDQUFDLGtCQUNDLGlDQUFDLGNBQ0VMLDJCQUFpQk0sSUFBSUMsVUFDcEIsdUJBQUMsMEJBQXFDLGNBQWNBLE1BQU0sYUFBN0JBLEtBQUtDLElBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0UsQ0FDaEYsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDZCxHQTlCS0YseUJBQXlEO0FBQUEsVUFHOUNPLFNBQVM7QUFBQTtBQUFBVSxLQUhwQmpCO0FBZ0NOLGVBQWVBO0FBRWYsTUFBTU8sWUFBWUEsTUFBTTtBQUN0QixRQUFNTSxtQkFBbUJuQixZQUFZO0FBQUEsSUFDbkN3QixXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFFBQVE7QUFBQSxJQUNSLFNBQVM7QUFBQSxNQUNQQyxXQUFXO0FBQUEsSUFDYjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU87QUFBQSxJQUNMUjtBQUFBQSxFQUNGO0FBQ0Y7QUFBQyxJQUFBSTtBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZXMiLCJ1c2VNZW1vIiwiRmxleENvbHVtbiIsIlNjcm9sbGFibGVQYW5lIiwiTm90aWZpY2F0aW9uQ2VudGVySXRlbSIsIk5vdGlmaWNhdGlvbnNDZW50ZXJFbXB0eSIsIk5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0IiwicHJvcHMiLCJfcyIsIm1vZHVsZSIsIm5vdGlmaWNhdGlvbnMiLCJvbkRpc21pc3MiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJub3RpZmljYXRpb25MaXN0IiwiZmlsdGVyIiwibm90aWZpY2F0aW9uIiwibW9kdWxvIiwibGVuZ3RoIiwibmF2TGlua0NvbnRhaW5lciIsIm1hcCIsIml0ZW0iLCJpZCIsIl9jIiwib3ZlcmZsb3dZIiwibWF4SGVpZ2h0IiwiaGVpZ2h0IiwibWFyZ2luVG9wIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uc0NlbnRlckxpc3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9jb21wb25lbnRzL05vdGlmaWNhdGlvbnNDZW50ZXJMaXN0LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1lcmdlU3R5bGVzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgRkMsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCBBcHBOb3RpZmljYXRpb24gZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL0FwcE5vdGlmaWNhdGlvbidcbmltcG9ydCB7IE1vZHVsZUVudW0gfSBmcm9tICcuLi8uLi8uLi9lbnVtcy9Nb2R1bGVFbnVtJ1xuaW1wb3J0IHsgRmxleENvbHVtbiB9IGZyb20gJy4uLy4uL0ZsZXhCb3gnXG5pbXBvcnQgeyBTY3JvbGxhYmxlUGFuZSB9IGZyb20gJy4uLy4uL3Njcm9sbGFibGVQYW5lJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbkNlbnRlckl0ZW0gZnJvbSAnLi9Ob3RpZmljYXRpb25DZW50ZXJJdGVtJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbnNDZW50ZXJFbXB0eSBmcm9tICcuL05vdGlmaWNhdGlvbnNDZW50ZXJFbXB0eSdcblxuaW50ZXJmYWNlIE5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0UHJvcHMge1xuICBtb2R1bGU/OiBNb2R1bGVFbnVtXG4gIG5vdGlmaWNhdGlvbnM6IEFwcE5vdGlmaWNhdGlvbltdXG4gIG9uRGlzbWlzczogKCkgPT4gdm9pZFxufVxuXG5jb25zdCBOb3RpZmljYXRpb25zQ2VudGVyTGlzdDogRkM8Tm90aWZpY2F0aW9uc0NlbnRlckxpc3RQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBtb2R1bGUsIG5vdGlmaWNhdGlvbnMsIG9uRGlzbWlzcyB9ID0gcHJvcHNcblxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoKVxuXG4gIGNvbnN0IG5vdGlmaWNhdGlvbkxpc3QgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAobW9kdWxlKSB7XG4gICAgICByZXR1cm4gbm90aWZpY2F0aW9ucy5maWx0ZXIobm90aWZpY2F0aW9uID0+IG5vdGlmaWNhdGlvbi5tb2R1bG8gPT09IG1vZHVsZSlcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5vdGlmaWNhdGlvbnNcbiAgICB9XG4gIH0sIFttb2R1bGUsIG5vdGlmaWNhdGlvbnNdKVxuXG4gIGlmIChub3RpZmljYXRpb25MaXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAoXG4gICAgICA8Tm90aWZpY2F0aW9uc0NlbnRlckVtcHR5Lz5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubmF2TGlua0NvbnRhaW5lcn0+XG4gICAgICA8U2Nyb2xsYWJsZVBhbmU+XG4gICAgICAgIDxGbGV4Q29sdW1uPlxuICAgICAgICAgIHtub3RpZmljYXRpb25MaXN0Lm1hcChpdGVtID0+IChcbiAgICAgICAgICAgIDxOb3RpZmljYXRpb25DZW50ZXJJdGVtIGtleT17aXRlbS5pZH0gbm90aWZpY2F0aW9uPXtpdGVtfSBvbkRpc21pc3M9e29uRGlzbWlzc30vPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L0ZsZXhDb2x1bW4+XG4gICAgICA8L1Njcm9sbGFibGVQYW5lPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbnNDZW50ZXJMaXN0XG5cbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgbmF2TGlua0NvbnRhaW5lciA9IG1lcmdlU3R5bGVzKHtcbiAgICBvdmVyZmxvd1k6ICdhdXRvJyxcbiAgICBtYXhIZWlnaHQ6ICdpbmhlcml0JyxcbiAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICAnPiBkaXYnOiB7XG4gICAgICBtYXJnaW5Ub3A6ICc2NHB4JyxcbiAgICB9LFxuICB9KVxuXG4gIHJldHVybiB7XG4gICAgbmF2TGlua0NvbnRhaW5lcixcbiAgfVxufVxuIl19