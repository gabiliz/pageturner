import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/checkbox/Checkbox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/checkbox/Checkbox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Checkbox as CheckboxFluent, mergeStyles } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const Checkbox = ({
  className,
  ...props
}) => {
  _s();
  const styles = useStyles();
  return /* @__PURE__ */ jsxDEV(CheckboxFluent, { className: `${styles} ${className}`, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/checkbox/Checkbox.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(Checkbox, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = Checkbox;
const useStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyles({
    "&.is-checked .ms-Checkbox-checkbox": {
      backgroundColor: colors.purple[500],
      borderColor: colors.purple[500]
    },
    "&.is-checked:hover .ms-Checkbox-checkbox": {
      backgroundColor: colors.purple[600],
      borderColor: colors.purple[600]
    },
    "&:not(.is-disabled) .ms-Checkbox-checkbox:hover": {
      backgroundColor: colors.purple[600],
      borderColor: colors.purple[600]
    }
  });
};
_s2(useStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default Checkbox;
var _c;
$RefreshReg$(_c, "Checkbox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/checkbox/Checkbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixTQUF5QkEsWUFBWUMsZ0JBQWdCQyxtQkFBbUI7QUFFeEUsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1ILFdBQStCQSxDQUFDO0FBQUEsRUFBRUk7QUFBQUEsRUFBVyxHQUFHQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUNoRSxRQUFNQyxTQUFTQyxVQUFVO0FBRXpCLFNBQ0UsdUJBQUMsa0JBQ0MsV0FBWSxHQUFFRCxVQUFVSCxhQUN4QixHQUFJQyxTQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFWTtBQUdoQjtBQUFDQyxHQVRLTixVQUE0QjtBQUFBLFVBQ2pCUSxTQUFTO0FBQUE7QUFBQUMsS0FEcEJUO0FBV04sTUFBTVEsWUFBWUEsTUFBTTtBQUFBRSxNQUFBO0FBQ3RCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFPLElBQUlSLFNBQVM7QUFDNUIsU0FBT0QsWUFBWTtBQUFBLElBQ2pCLHNDQUFzQztBQUFBLE1BQ3BDVSxpQkFBaUJELE9BQU9FLE9BQU8sR0FBRztBQUFBLE1BQ2xDQyxhQUFhSCxPQUFPRSxPQUFPLEdBQUc7QUFBQSxJQUNoQztBQUFBLElBQ0EsNENBQTRDO0FBQUEsTUFDMUNELGlCQUFpQkQsT0FBT0UsT0FBTyxHQUFHO0FBQUEsTUFDbENDLGFBQWFILE9BQU9FLE9BQU8sR0FBRztBQUFBLElBQ2hDO0FBQUEsSUFDQSxtREFBbUQ7QUFBQSxNQUNqREQsaUJBQWlCRCxPQUFPRSxPQUFPLEdBQUc7QUFBQSxNQUNsQ0MsYUFBYUgsT0FBT0UsT0FBTyxHQUFHO0FBQUEsSUFDaEM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDSCxJQWhCS0YsV0FBUztBQUFBLFVBQ01MLFFBQVE7QUFBQTtBQWlCN0IsZUFBZUg7QUFBUSxJQUFBUztBQUFBTSxhQUFBTixJQUFBIiwibmFtZXMiOlsiQ2hlY2tib3giLCJDaGVja2JveEZsdWVudCIsIm1lcmdlU3R5bGVzIiwidXNlVGhlbWUiLCJjbGFzc05hbWUiLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiX2MiLCJfczIiLCJjb2xvcnMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwdXJwbGUiLCJib3JkZXJDb2xvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNoZWNrYm94LnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2NoZWNrYm94L0NoZWNrYm94LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElDaGVja2JveFByb3BzLCBDaGVja2JveCBhcyBDaGVja2JveEZsdWVudCwgbWVyZ2VTdHlsZXMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXHJcblxyXG5jb25zdCBDaGVja2JveDogRkM8SUNoZWNrYm94UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9KSA9PiB7XHJcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDaGVja2JveEZsdWVudFxyXG4gICAgICBjbGFzc05hbWU9e2Ake3N0eWxlc30gJHtjbGFzc05hbWV9YH1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxyXG4gIHJldHVybiBtZXJnZVN0eWxlcyh7XHJcbiAgICAnJi5pcy1jaGVja2VkIC5tcy1DaGVja2JveC1jaGVja2JveCc6IHtcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICB9LFxyXG4gICAgJyYuaXMtY2hlY2tlZDpob3ZlciAubXMtQ2hlY2tib3gtY2hlY2tib3gnOiB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs2MDBdLFxyXG4gICAgICBib3JkZXJDb2xvcjogY29sb3JzLnB1cnBsZVs2MDBdLFxyXG4gICAgfSxcclxuICAgICcmOm5vdCguaXMtZGlzYWJsZWQpIC5tcy1DaGVja2JveC1jaGVja2JveDpob3Zlcic6IHtcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXHJcbiAgICB9LFxyXG4gIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoZWNrYm94XHJcbiJdfQ==