import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { AppPage } from "/src/shared/components/index.ts?t=1701096626433";
import { TestProcessPathRecord } from "/src/shared/record/index.ts";
import { TestProcessList } from "/src/modules/audit/testProcess/components/index.ts?t=1701096626433";
import { TestProcessPathEnum } from "/src/shared/enums/TestProcessPathEnum.ts";
import { FinancialStatementsBreadcrumb } from "/src/modules/audit/financialStatements/components/index.ts?t=1701096626433";
const FinancialStatementsOldPage = () => {
  return /* @__PURE__ */ jsxDEV(AppPage, { title: TestProcessPathRecord[TestProcessPathEnum.financialStatements], renderBreadCrumb: () => /* @__PURE__ */ jsxDEV(FinancialStatementsBreadcrumb, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx",
    lineNumber: 8,
    columnNumber: 114
  }, this), docsUrl: "/projetos/projetos/analises-contabeis/execucao-dos-testes", children: /* @__PURE__ */ jsxDEV(TestProcessList, { testProcessType: TestProcessPathEnum.financialStatements }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx",
    lineNumber: 9,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_c = FinancialStatementsOldPage;
export default FinancialStatementsOldPage;
var _c;
$RefreshReg$(_c, "FinancialStatementsOldPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsOldPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVzhCO0FBWDlCLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MscUNBQXFDO0FBRTlDLE1BQU1DLDZCQUFpQ0EsTUFBTTtBQUMzQyxTQUNFLHVCQUFDLFdBQ0MsT0FBT0osc0JBQXNCRSxvQkFBb0JHLG1CQUFtQixHQUNwRSxrQkFBa0IsTUFBTSx1QkFBQyxtQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThCLEdBQ3RELFNBQVEsNkRBRVIsaUNBQUMsbUJBQWdCLGlCQUFpQkgsb0JBQW9CRyx1QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwRSxLQUw1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDQyxLQVZLRjtBQVlOLGVBQWVBO0FBQTBCLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJBcHBQYWdlIiwiVGVzdFByb2Nlc3NQYXRoUmVjb3JkIiwiVGVzdFByb2Nlc3NMaXN0IiwiVGVzdFByb2Nlc3NQYXRoRW51bSIsIkZpbmFuY2lhbFN0YXRlbWVudHNCcmVhZGNydW1iIiwiRmluYW5jaWFsU3RhdGVtZW50c09sZFBhZ2UiLCJmaW5hbmNpYWxTdGF0ZW1lbnRzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaW5hbmNpYWxTdGF0ZW1lbnRzT2xkUGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2ZpbmFuY2lhbFN0YXRlbWVudHMvcGFnZXMvRmluYW5jaWFsU3RhdGVtZW50c09sZFBhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEFwcFBhZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IFRlc3RQcm9jZXNzUGF0aFJlY29yZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQnXG5pbXBvcnQgeyBUZXN0UHJvY2Vzc0xpc3QgfSBmcm9tICcuLi8uLi90ZXN0UHJvY2Vzcy9jb21wb25lbnRzJ1xuaW1wb3J0IHsgVGVzdFByb2Nlc3NQYXRoRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9UZXN0UHJvY2Vzc1BhdGhFbnVtJ1xuaW1wb3J0IHsgRmluYW5jaWFsU3RhdGVtZW50c0JyZWFkY3J1bWIgfSBmcm9tICcuLi9jb21wb25lbnRzJ1xuXG5jb25zdCBGaW5hbmNpYWxTdGF0ZW1lbnRzT2xkUGFnZTogRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEFwcFBhZ2VcbiAgICAgIHRpdGxlPXtUZXN0UHJvY2Vzc1BhdGhSZWNvcmRbVGVzdFByb2Nlc3NQYXRoRW51bS5maW5hbmNpYWxTdGF0ZW1lbnRzXX1cbiAgICAgIHJlbmRlckJyZWFkQ3J1bWI9eygpID0+IDxGaW5hbmNpYWxTdGF0ZW1lbnRzQnJlYWRjcnVtYi8+fVxuICAgICAgZG9jc1VybD0nL3Byb2pldG9zL3Byb2pldG9zL2FuYWxpc2VzLWNvbnRhYmVpcy9leGVjdWNhby1kb3MtdGVzdGVzJ1xuICAgID5cbiAgICAgIDxUZXN0UHJvY2Vzc0xpc3QgdGVzdFByb2Nlc3NUeXBlPXtUZXN0UHJvY2Vzc1BhdGhFbnVtLmZpbmFuY2lhbFN0YXRlbWVudHN9IC8+XG4gICAgPC9BcHBQYWdlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEZpbmFuY2lhbFN0YXRlbWVudHNPbGRQYWdlXG4iXX0=