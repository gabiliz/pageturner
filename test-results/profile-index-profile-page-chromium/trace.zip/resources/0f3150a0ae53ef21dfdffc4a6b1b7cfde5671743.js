import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/riskForm/pages/RiskFormEdit.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"]; const useContext = __vite__cjsImport4_react["useContext"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { AppPage, LoadingScreen } from "/src/shared/components/index.ts?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { useHandleRejection } from "/src/shared/hooks/index.ts";
import { useDialogs } from "/src/shared/store/dialogs/dialogs.ts";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { RiskFormDetails, RiskFormEditActions, RiskFormEditForm } from "/src/modules/audit/riskForm/components/index.ts?t=1701096626433";
import { riskFormQueryService, riskFormService } from "/src/modules/audit/riskForm/services/index.ts";
const RiskFormEdit = (props) => {
  _s();
  const {
    isCreating
  } = props;
  const {
    riskFormId
  } = useParams();
  const {
    currentAccount
  } = useAuth();
  const goBack = useNavigate();
  const {
    hasPermission
  } = usePermissions();
  const {
    openDialog
  } = useDialogs();
  const {
    mutateAsync: create,
    isLoading: loadingCreating
  } = riskFormQueryService.useCreate();
  const {
    mutateAsync: update,
    isLoading: loadingUpdating
  } = riskFormQueryService.useUpdate();
  const [itemToEdit, setItemToEdit] = useState();
  const [loadingItemToEdit, setLoadingItemToEdit] = useState(false);
  const {
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  const [isEditing, {
    setTrue: setIsEditing,
    setFalse: setIsNotEditing
  }] = useBoolean(false);
  const emptyRiskForm = useMemo(() => {
    return {
      nomeFormulario: "",
      situacao: 0,
      area: "",
      dataInclusao: void 0,
      dataAlteracao: void 0,
      responsavelId: currentAccount.value?.id,
      contas: [],
      perguntas: []
    };
  }, [currentAccount]);
  const [formData, setFormData] = useState();
  useEffect(() => {
    if (riskFormId && !isEditing) {
      setLoadingItemToEdit(true);
      riskFormService.findOne(riskFormId).then((res) => setItemToEdit(res)).finally(() => setLoadingItemToEdit(false));
    }
  }, [isEditing, riskFormId]);
  useEffect(() => {
    if (itemToEdit) {
      setFormData(itemToEdit);
    } else {
      setFormData(emptyRiskForm);
    }
  }, [itemToEdit, emptyRiskForm]);
  const onChange = useCallback((item) => {
    return setFormData(item);
  }, []);
  const createRiskForm = useCallback(async () => {
    await create(formData);
    goBack(-1);
  }, [formData]);
  const updateRiskForm = useCallback(async () => {
    await update(formData);
    setIsNotEditing();
  }, [formData]);
  const cancelEdit = useCallback(() => {
    setIsNotEditing();
    setError(void 0);
  }, []);
  const confirmCancel = useCallback(() => {
    openDialog({
      title: "Deseja realmente cancelar?",
      description: "Podem existir dados alterados que ainda não foram salvos. Tem certeza que quer cancelar e perder todas as alterações?",
      acceptLabel: "OK",
      rejectLabel: "Cancelar",
      onAccept: cancelEdit,
      style: "danger"
    });
  }, [cancelEdit]);
  const [error, setError] = useState();
  const {
    registerListener,
    unregisterListener
  } = useHandleRejection();
  useEffect(() => {
    registerListener(setError);
    return () => {
      unregisterListener(setError);
    };
  }, [setError]);
  const dismiss = useCallback(() => {
    setFormData(emptyRiskForm);
    setError(void 0);
    riskFormQueryService.invalidateQueries();
    goBack(-1);
  }, [emptyRiskForm]);
  useEffect(() => {
    setGlobalLoading(loadingCreating || loadingUpdating || loadingItemToEdit);
  }, [loadingItemToEdit, loadingCreating, loadingUpdating]);
  return /* @__PURE__ */ jsxDEV(AppPage, { title: isCreating ? "Adicionar formulário de risco" : "Alterar formulário de risco", docsUrl: "/contabil/formulario-de-risco", topRightCorner: formData && /* @__PURE__ */ jsxDEV(RiskFormEditActions, { onGoBack: dismiss, onAdd: isCreating ? createRiskForm : updateRiskForm, disableSave: loadingCreating || loadingUpdating || formData.perguntas?.some((question) => question.pergunta === "") || !formData.perguntas.length, disableCancel: loadingCreating || loadingUpdating, cancelChanges: confirmCancel, startEditing: setIsEditing, isEditing, isCreating, updatePermission: hasPermission("FormularioRisco", "Alterar") }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx",
    lineNumber: 124,
    columnNumber: 172
  }, this), children: [
    (!loadingItemToEdit || !riskFormId) && formData && (isEditing || isCreating) && /* @__PURE__ */ jsxDEV(RiskFormEditForm, { formData, onChange, apiError: error?.reason ? error.reason : void 0, isEditing: isEditing || isCreating }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx",
      lineNumber: 125,
      columnNumber: 88
    }, this),
    (!loadingItemToEdit || !riskFormId) && formData && !isEditing && !isCreating && /* @__PURE__ */ jsxDEV(RiskFormDetails, { data: formData }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx",
      lineNumber: 126,
      columnNumber: 88
    }, this),
    loadingItemToEdit && riskFormId && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx",
      lineNumber: 127,
      columnNumber: 43
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx",
    lineNumber: 124,
    columnNumber: 10
  }, this);
};
_s(RiskFormEdit, "EwFuTOw3dpjQQaHyKfmBoPvuy4I=", false, function() {
  return [useParams, useAuth, useNavigate, usePermissions, useDialogs, riskFormQueryService.useCreate, riskFormQueryService.useUpdate, useBoolean, useHandleRejection];
});
_c = RiskFormEdit;
export default RiskFormEdit;
var _c;
$RefreshReg$(_c, "RiskFormEdit");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/pages/RiskFormEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkhvQjs7Ozs7Ozs7Ozs7Ozs7OztBQTNIcEIsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQWFDLGFBQWFDLFlBQVlDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUMxRSxTQUFTQyxhQUFhQyxpQkFBaUI7QUFFdkMsU0FBU0MsU0FBU0MscUJBQXFCO0FBQ3ZDLFNBQVNDLDBCQUEwQjtBQUVuQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQkMscUJBQXFCQyx3QkFBd0I7QUFDdkUsU0FBU0Msc0JBQXNCQyx1QkFBdUI7QUFNdEQsTUFBTUMsZUFBdUNDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBVyxJQUFJRjtBQUN2QixRQUFNO0FBQUEsSUFBRUc7QUFBQUEsRUFBVyxJQUFJakIsVUFBVTtBQUNqQyxRQUFNO0FBQUEsSUFBRWtCO0FBQUFBLEVBQWUsSUFBSVgsUUFBUTtBQUNuQyxRQUFNWSxTQUFTcEIsWUFBWTtBQUMzQixRQUFNO0FBQUEsSUFBRXFCO0FBQUFBLEVBQWMsSUFBSWQsZUFBZTtBQUN6QyxRQUFNO0FBQUEsSUFBRWU7QUFBQUEsRUFBVyxJQUFJaEIsV0FBVztBQUNsQyxRQUFNO0FBQUEsSUFBRWlCLGFBQWFDO0FBQUFBLElBQVFDLFdBQVdDO0FBQUFBLEVBQWdCLElBQUlkLHFCQUFxQmUsVUFBVTtBQUMzRixRQUFNO0FBQUEsSUFBRUosYUFBYUs7QUFBQUEsSUFBUUgsV0FBV0k7QUFBQUEsRUFBZ0IsSUFBSWpCLHFCQUFxQmtCLFVBQVU7QUFDM0YsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlqQyxTQUFtQjtBQUN2RCxRQUFNLENBQUNrQyxtQkFBbUJDLG9CQUFvQixJQUFJbkMsU0FBa0IsS0FBSztBQUN6RSxRQUFNO0FBQUEsSUFBRW9DLGNBQWNDO0FBQUFBLEVBQWlCLElBQUl4QyxXQUFXUSxrQkFBa0I7QUFDeEUsUUFBTSxDQUNKaUMsV0FDQTtBQUFBLElBQUVDLFNBQVNDO0FBQUFBLElBQWNDLFVBQVVDO0FBQUFBLEVBQWdCLENBQUMsSUFDbEQvQyxXQUFXLEtBQUs7QUFDcEIsUUFBTWdELGdCQUEwQjVDLFFBQVEsTUFBTTtBQUM1QyxXQUFPO0FBQUEsTUFDTDZDLGdCQUFnQjtBQUFBLE1BQ2hCQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLGNBQWNDO0FBQUFBLE1BQ2RDLGVBQWVEO0FBQUFBLE1BQ2ZFLGVBQWU5QixlQUFlK0IsT0FBT0M7QUFBQUEsTUFDckNDLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxDQUFDbEMsY0FBYyxDQUFDO0FBQ25CLFFBQU0sQ0FBQ21DLFVBQVVDLFdBQVcsSUFBSXhELFNBQW1CO0FBRW5ERixZQUFVLE1BQU07QUFDZCxRQUFJcUIsY0FBYyxDQUFDbUIsV0FBVztBQUM1QkgsMkJBQXFCLElBQUk7QUFDekJyQixzQkFBZ0IyQyxRQUFRdEMsVUFBVSxFQUMvQnVDLEtBQUtDLFNBQU8xQixjQUFjMEIsR0FBZSxDQUFDLEVBQzFDQyxRQUFRLE1BQU16QixxQkFBcUIsS0FBSyxDQUFDO0FBQUEsSUFDOUM7QUFBQSxFQUNGLEdBQUcsQ0FBQ0csV0FBV25CLFVBQVUsQ0FBQztBQUUxQnJCLFlBQVUsTUFBTTtBQUNkLFFBQUlrQyxZQUFZO0FBQ2R3QixrQkFBWXhCLFVBQVU7QUFBQSxJQUN4QixPQUFPO0FBQ0x3QixrQkFBWWIsYUFBYTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLENBQUNYLFlBQVlXLGFBQWEsQ0FBQztBQUU5QixRQUFNa0IsV0FBV2pFLFlBQVksQ0FBQ2tFLFNBQW1CO0FBQy9DLFdBQU9OLFlBQVlNLElBQUk7QUFBQSxFQUN6QixHQUFHLEVBQUU7QUFFTCxRQUFNQyxpQkFBaUJuRSxZQUFZLFlBQVk7QUFDN0MsVUFBTTZCLE9BQU84QixRQUFvQjtBQUNqQ2xDLFdBQU8sRUFBRTtBQUFBLEVBQ1gsR0FBRyxDQUFDa0MsUUFBUSxDQUFDO0FBRWIsUUFBTVMsaUJBQWlCcEUsWUFBWSxZQUFZO0FBQzdDLFVBQU1pQyxPQUFPMEIsUUFBb0I7QUFDakNiLG9CQUFnQjtBQUFBLEVBQ2xCLEdBQUcsQ0FBQ2EsUUFBUSxDQUFDO0FBRWIsUUFBTVUsYUFBYXJFLFlBQVksTUFBTTtBQUNuQzhDLG9CQUFnQjtBQUNoQndCLGFBQVNsQixNQUFTO0FBQUEsRUFDcEIsR0FBRyxFQUFFO0FBRUwsUUFBTW1CLGdCQUFnQnZFLFlBQVksTUFBTTtBQUN0QzJCLGVBQVc7QUFBQSxNQUNUNkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxhQUFhO0FBQUEsTUFDYkMsYUFBYTtBQUFBLE1BQ2JDLFVBQVVQO0FBQUFBLE1BQ1ZRLE9BQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ1IsVUFBVSxDQUFDO0FBRWYsUUFBTSxDQUFDUyxPQUFPUixRQUFRLElBQUlsRSxTQUFnQztBQUMxRCxRQUFNO0FBQUEsSUFDSjJFO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSXRFLG1CQUFtQjtBQUV2QlIsWUFBVSxNQUFNO0FBQ2Q2RSxxQkFBaUJULFFBQVE7QUFDekIsV0FBTyxNQUFNO0FBQ1hVLHlCQUFtQlYsUUFBUTtBQUFBLElBQzdCO0FBQUEsRUFDRixHQUFHLENBQUNBLFFBQVEsQ0FBQztBQUViLFFBQU1XLFVBQVVqRixZQUFZLE1BQU07QUFDaEM0RCxnQkFBWWIsYUFBYTtBQUN6QnVCLGFBQVNsQixNQUFTO0FBQ2xCbkMseUJBQXFCaUUsa0JBQWtCO0FBQ3ZDekQsV0FBTyxFQUFFO0FBQUEsRUFDWCxHQUFHLENBQUNzQixhQUFhLENBQUM7QUFFbEI3QyxZQUFVLE1BQU07QUFDZHVDLHFCQUFrQlYsbUJBQW1CRyxtQkFBbUJJLGlCQUE2QjtBQUFBLEVBQ3ZGLEdBQUcsQ0FBQ0EsbUJBQW1CUCxpQkFBaUJHLGVBQWUsQ0FBQztBQUN4RCxTQUNFLHVCQUFDLFdBQ0MsT0FBT1osYUFBYSxrQ0FBa0MsK0JBQ3RELFNBQVEsaUNBQ1IsZ0JBQ0VxQyxZQUFZLHVCQUFDLHVCQUNYLFVBQVVzQixTQUNWLE9BQU8zRCxhQUFhNkMsaUJBQWlCQyxnQkFDckMsYUFDRXJDLG1CQUNBRyxtQkFDQXlCLFNBQVNELFdBQVd5QixLQUFLQyxjQUFZQSxTQUFTQyxhQUFhLEVBQUUsS0FDN0QsQ0FBQzFCLFNBQVNELFVBQVU0QixRQUV0QixlQUNFdkQsbUJBQ0FHLGlCQUVGLGVBQWVxQyxlQUNmLGNBQWMzQixjQUNkLFdBQ0EsWUFDQSxrQkFBa0JsQixjQUFjLG1CQUFtQixTQUFTLEtBakJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJvRCxHQUloRTtBQUFBLE1BQUNZLHFCQUFxQixDQUFDZixlQUFlb0MsYUFBYWpCLGFBQWFwQixlQUFlLHVCQUFDLG9CQUNoRixVQUNBLFVBQ0EsVUFBVXdELE9BQU9TLFNBQVNULE1BQU1TLFNBQXFCbkMsUUFDckQsV0FBV1YsYUFBYXBCLGNBSnVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJNUM7QUFBQSxLQUVuQyxDQUFDZ0IscUJBQXFCLENBQUNmLGVBQWVvQyxZQUFhLENBQUNqQixhQUFhLENBQUNwQixjQUFlLHVCQUFDLG1CQUNsRixNQUFNcUMsWUFEMkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUNsRTtBQUFBLElBR2hCckIscUJBQXFCZixjQUFjLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLE9BbkNwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0NBO0FBRUo7QUFBQ0YsR0EzSUtGLGNBQW1DO0FBQUEsVUFFaEJiLFdBQ0lPLFNBQ1pSLGFBQ1dPLGdCQUNIRCxZQUNxQ00scUJBQXFCZSxXQUNyQmYscUJBQXFCa0IsV0FPN0VwQyxZQWtFQVcsa0JBQWtCO0FBQUE7QUFBQThFLEtBakZsQnJFO0FBNklOLGVBQWVBO0FBQVksSUFBQXFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VCb29sZWFuIiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJBcHBQYWdlIiwiTG9hZGluZ1NjcmVlbiIsIkxvYWRpbmdEYXRhQ29udGV4dCIsInVzZUhhbmRsZVJlamVjdGlvbiIsInVzZURpYWxvZ3MiLCJ1c2VQZXJtaXNzaW9ucyIsInVzZUF1dGgiLCJSaXNrRm9ybURldGFpbHMiLCJSaXNrRm9ybUVkaXRBY3Rpb25zIiwiUmlza0Zvcm1FZGl0Rm9ybSIsInJpc2tGb3JtUXVlcnlTZXJ2aWNlIiwicmlza0Zvcm1TZXJ2aWNlIiwiUmlza0Zvcm1FZGl0IiwicHJvcHMiLCJfcyIsImlzQ3JlYXRpbmciLCJyaXNrRm9ybUlkIiwiY3VycmVudEFjY291bnQiLCJnb0JhY2siLCJoYXNQZXJtaXNzaW9uIiwib3BlbkRpYWxvZyIsIm11dGF0ZUFzeW5jIiwiY3JlYXRlIiwiaXNMb2FkaW5nIiwibG9hZGluZ0NyZWF0aW5nIiwidXNlQ3JlYXRlIiwidXBkYXRlIiwibG9hZGluZ1VwZGF0aW5nIiwidXNlVXBkYXRlIiwiaXRlbVRvRWRpdCIsInNldEl0ZW1Ub0VkaXQiLCJsb2FkaW5nSXRlbVRvRWRpdCIsInNldExvYWRpbmdJdGVtVG9FZGl0Iiwic2V0SXNMb2FkaW5nIiwic2V0R2xvYmFsTG9hZGluZyIsImlzRWRpdGluZyIsInNldFRydWUiLCJzZXRJc0VkaXRpbmciLCJzZXRGYWxzZSIsInNldElzTm90RWRpdGluZyIsImVtcHR5Umlza0Zvcm0iLCJub21lRm9ybXVsYXJpbyIsInNpdHVhY2FvIiwiYXJlYSIsImRhdGFJbmNsdXNhbyIsInVuZGVmaW5lZCIsImRhdGFBbHRlcmFjYW8iLCJyZXNwb25zYXZlbElkIiwidmFsdWUiLCJpZCIsImNvbnRhcyIsInBlcmd1bnRhcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJmaW5kT25lIiwidGhlbiIsInJlcyIsImZpbmFsbHkiLCJvbkNoYW5nZSIsIml0ZW0iLCJjcmVhdGVSaXNrRm9ybSIsInVwZGF0ZVJpc2tGb3JtIiwiY2FuY2VsRWRpdCIsInNldEVycm9yIiwiY29uZmlybUNhbmNlbCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY2NlcHRMYWJlbCIsInJlamVjdExhYmVsIiwib25BY2NlcHQiLCJzdHlsZSIsImVycm9yIiwicmVnaXN0ZXJMaXN0ZW5lciIsInVucmVnaXN0ZXJMaXN0ZW5lciIsImRpc21pc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsInNvbWUiLCJxdWVzdGlvbiIsInBlcmd1bnRhIiwibGVuZ3RoIiwicmVhc29uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSaXNrRm9ybUVkaXQudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9yaXNrRm9ybS9wYWdlcy9SaXNrRm9ybUVkaXQudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgUmlza0Zvcm0gZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1Jpc2tGb3JtJ1xuaW1wb3J0IHsgQXBwUGFnZSwgTG9hZGluZ1NjcmVlbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgTG9hZGluZ0RhdGFDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbnRleHQvTG9hZGluZ0RhdGFDb250ZXh0J1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvZXJyb3JzJ1xuaW1wb3J0IHsgdXNlSGFuZGxlUmVqZWN0aW9uIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuaW1wb3J0IHsgdXNlRGlhbG9ncyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9zdG9yZS9kaWFsb2dzL2RpYWxvZ3MnXG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vYXV0aC9zdG9yZS9hdXRoJ1xuaW1wb3J0IHsgUmlza0Zvcm1EZXRhaWxzLCBSaXNrRm9ybUVkaXRBY3Rpb25zLCBSaXNrRm9ybUVkaXRGb3JtIH0gZnJvbSAnLi4vY29tcG9uZW50cydcbmltcG9ydCB7IHJpc2tGb3JtUXVlcnlTZXJ2aWNlLCByaXNrRm9ybVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcblxuZXhwb3J0IGludGVyZmFjZSBSaXNrRm9ybUVkaXRQcm9wcyB7XG4gIGlzQ3JlYXRpbmc6IGJvb2xlYW5cbn1cblxuY29uc3QgUmlza0Zvcm1FZGl0OiBGQzxSaXNrRm9ybUVkaXRQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBpc0NyZWF0aW5nIH0gPSBwcm9wc1xuICBjb25zdCB7IHJpc2tGb3JtSWQgfSA9IHVzZVBhcmFtcygpXG4gIGNvbnN0IHsgY3VycmVudEFjY291bnQgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBnb0JhY2sgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgaGFzUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKVxuICBjb25zdCB7IG9wZW5EaWFsb2cgfSA9IHVzZURpYWxvZ3MoKVxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBjcmVhdGUsIGlzTG9hZGluZzogbG9hZGluZ0NyZWF0aW5nIH0gPSByaXNrRm9ybVF1ZXJ5U2VydmljZS51c2VDcmVhdGUoKVxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiB1cGRhdGUsIGlzTG9hZGluZzogbG9hZGluZ1VwZGF0aW5nIH0gPSByaXNrRm9ybVF1ZXJ5U2VydmljZS51c2VVcGRhdGUoKVxuICBjb25zdCBbaXRlbVRvRWRpdCwgc2V0SXRlbVRvRWRpdF0gPSB1c2VTdGF0ZTxSaXNrRm9ybT4oKVxuICBjb25zdCBbbG9hZGluZ0l0ZW1Ub0VkaXQsIHNldExvYWRpbmdJdGVtVG9FZGl0XSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxuICBjb25zdCB7IHNldElzTG9hZGluZzogc2V0R2xvYmFsTG9hZGluZyB9ID0gdXNlQ29udGV4dChMb2FkaW5nRGF0YUNvbnRleHQpXG4gIGNvbnN0IFtcbiAgICBpc0VkaXRpbmcsXG4gICAgeyBzZXRUcnVlOiBzZXRJc0VkaXRpbmcsIHNldEZhbHNlOiBzZXRJc05vdEVkaXRpbmcgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG4gIGNvbnN0IGVtcHR5Umlza0Zvcm06IFJpc2tGb3JtID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5vbWVGb3JtdWxhcmlvOiAnJyxcbiAgICAgIHNpdHVhY2FvOiAwLFxuICAgICAgYXJlYTogJycsXG4gICAgICBkYXRhSW5jbHVzYW86IHVuZGVmaW5lZCxcbiAgICAgIGRhdGFBbHRlcmFjYW86IHVuZGVmaW5lZCxcbiAgICAgIHJlc3BvbnNhdmVsSWQ6IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5pZCBhcyBzdHJpbmcsXG4gICAgICBjb250YXM6IFtdLFxuICAgICAgcGVyZ3VudGFzOiBbXSxcbiAgICB9XG4gIH0sIFtjdXJyZW50QWNjb3VudF0pXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8Umlza0Zvcm0+KClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChyaXNrRm9ybUlkICYmICFpc0VkaXRpbmcpIHtcbiAgICAgIHNldExvYWRpbmdJdGVtVG9FZGl0KHRydWUpXG4gICAgICByaXNrRm9ybVNlcnZpY2UuZmluZE9uZShyaXNrRm9ybUlkKVxuICAgICAgICAudGhlbihyZXMgPT4gc2V0SXRlbVRvRWRpdChyZXMgYXMgUmlza0Zvcm0pKVxuICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nSXRlbVRvRWRpdChmYWxzZSkpXG4gICAgfVxuICB9LCBbaXNFZGl0aW5nLCByaXNrRm9ybUlkXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpdGVtVG9FZGl0KSB7XG4gICAgICBzZXRGb3JtRGF0YShpdGVtVG9FZGl0KVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXRGb3JtRGF0YShlbXB0eVJpc2tGb3JtKVxuICAgIH1cbiAgfSwgW2l0ZW1Ub0VkaXQsIGVtcHR5Umlza0Zvcm1dKVxuXG4gIGNvbnN0IG9uQ2hhbmdlID0gdXNlQ2FsbGJhY2soKGl0ZW06IFJpc2tGb3JtKSA9PiB7XG4gICAgcmV0dXJuIHNldEZvcm1EYXRhKGl0ZW0pXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGNyZWF0ZVJpc2tGb3JtID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNyZWF0ZShmb3JtRGF0YSBhcyBSaXNrRm9ybSlcbiAgICBnb0JhY2soLTEpXG4gIH0sIFtmb3JtRGF0YV0pXG5cbiAgY29uc3QgdXBkYXRlUmlza0Zvcm0gPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgdXBkYXRlKGZvcm1EYXRhIGFzIFJpc2tGb3JtKVxuICAgIHNldElzTm90RWRpdGluZygpXG4gIH0sIFtmb3JtRGF0YV0pXG5cbiAgY29uc3QgY2FuY2VsRWRpdCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBzZXRJc05vdEVkaXRpbmcoKVxuICAgIHNldEVycm9yKHVuZGVmaW5lZClcbiAgfSwgW10pXG5cbiAgY29uc3QgY29uZmlybUNhbmNlbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBvcGVuRGlhbG9nKHtcbiAgICAgIHRpdGxlOiAnRGVzZWphIHJlYWxtZW50ZSBjYW5jZWxhcj8nLFxuICAgICAgZGVzY3JpcHRpb246ICdQb2RlbSBleGlzdGlyIGRhZG9zIGFsdGVyYWRvcyBxdWUgYWluZGEgbsOjbyBmb3JhbSBzYWx2b3MuIFRlbSBjZXJ0ZXphIHF1ZSBxdWVyIGNhbmNlbGFyIGUgcGVyZGVyIHRvZGFzIGFzIGFsdGVyYcOnw7Vlcz8nLFxuICAgICAgYWNjZXB0TGFiZWw6ICdPSycsXG4gICAgICByZWplY3RMYWJlbDogJ0NhbmNlbGFyJyxcbiAgICAgIG9uQWNjZXB0OiBjYW5jZWxFZGl0LFxuICAgICAgc3R5bGU6ICdkYW5nZXInLFxuICAgIH0pXG4gIH0sIFtjYW5jZWxFZGl0XSlcblxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPFByb21pc2VSZWplY3Rpb25FdmVudD4oKVxuICBjb25zdCB7XG4gICAgcmVnaXN0ZXJMaXN0ZW5lcixcbiAgICB1bnJlZ2lzdGVyTGlzdGVuZXIsXG4gIH0gPSB1c2VIYW5kbGVSZWplY3Rpb24oKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmVnaXN0ZXJMaXN0ZW5lcihzZXRFcnJvcilcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdW5yZWdpc3Rlckxpc3RlbmVyKHNldEVycm9yKVxuICAgIH1cbiAgfSwgW3NldEVycm9yXSlcblxuICBjb25zdCBkaXNtaXNzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldEZvcm1EYXRhKGVtcHR5Umlza0Zvcm0pXG4gICAgc2V0RXJyb3IodW5kZWZpbmVkKVxuICAgIHJpc2tGb3JtUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKClcbiAgICBnb0JhY2soLTEpXG4gIH0sIFtlbXB0eVJpc2tGb3JtXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldEdsb2JhbExvYWRpbmcoKGxvYWRpbmdDcmVhdGluZyB8fCBsb2FkaW5nVXBkYXRpbmcgfHwgbG9hZGluZ0l0ZW1Ub0VkaXQpIGFzIGJvb2xlYW4pXG4gIH0sIFtsb2FkaW5nSXRlbVRvRWRpdCwgbG9hZGluZ0NyZWF0aW5nLCBsb2FkaW5nVXBkYXRpbmddKVxuICByZXR1cm4gKFxuICAgIDxBcHBQYWdlXG4gICAgICB0aXRsZT17aXNDcmVhdGluZyA/ICdBZGljaW9uYXIgZm9ybXVsw6FyaW8gZGUgcmlzY28nIDogJ0FsdGVyYXIgZm9ybXVsw6FyaW8gZGUgcmlzY28nfVxuICAgICAgZG9jc1VybD0nL2NvbnRhYmlsL2Zvcm11bGFyaW8tZGUtcmlzY28nXG4gICAgICB0b3BSaWdodENvcm5lcj17XG4gICAgICAgIGZvcm1EYXRhICYmIDxSaXNrRm9ybUVkaXRBY3Rpb25zXG4gICAgICAgICAgb25Hb0JhY2s9e2Rpc21pc3N9XG4gICAgICAgICAgb25BZGQ9e2lzQ3JlYXRpbmcgPyBjcmVhdGVSaXNrRm9ybSA6IHVwZGF0ZVJpc2tGb3JtfVxuICAgICAgICAgIGRpc2FibGVTYXZlPXtcbiAgICAgICAgICAgIGxvYWRpbmdDcmVhdGluZyB8fFxuICAgICAgICAgICAgbG9hZGluZ1VwZGF0aW5nIHx8XG4gICAgICAgICAgICBmb3JtRGF0YS5wZXJndW50YXM/LnNvbWUocXVlc3Rpb24gPT4gcXVlc3Rpb24ucGVyZ3VudGEgPT09ICcnKSB8fFxuICAgICAgICAgICAgIWZvcm1EYXRhLnBlcmd1bnRhcy5sZW5ndGhcbiAgICAgICAgICB9XG4gICAgICAgICAgZGlzYWJsZUNhbmNlbD17XG4gICAgICAgICAgICBsb2FkaW5nQ3JlYXRpbmcgfHxcbiAgICAgICAgICAgIGxvYWRpbmdVcGRhdGluZ1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYW5jZWxDaGFuZ2VzPXtjb25maXJtQ2FuY2VsfVxuICAgICAgICAgIHN0YXJ0RWRpdGluZz17c2V0SXNFZGl0aW5nfVxuICAgICAgICAgIGlzRWRpdGluZz17aXNFZGl0aW5nfVxuICAgICAgICAgIGlzQ3JlYXRpbmc9e2lzQ3JlYXRpbmd9XG4gICAgICAgICAgdXBkYXRlUGVybWlzc2lvbj17aGFzUGVybWlzc2lvbignRm9ybXVsYXJpb1Jpc2NvJywgJ0FsdGVyYXInKX1cbiAgICAgICAgLz5cbiAgICAgIH1cbiAgICA+XG4gICAgICB7KCFsb2FkaW5nSXRlbVRvRWRpdCB8fCAhcmlza0Zvcm1JZCkgJiYgZm9ybURhdGEgJiYgKGlzRWRpdGluZyB8fCBpc0NyZWF0aW5nKSAmJiA8Umlza0Zvcm1FZGl0Rm9ybVxuICAgICAgICBmb3JtRGF0YT17Zm9ybURhdGF9XG4gICAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX1cbiAgICAgICAgYXBpRXJyb3I9e2Vycm9yPy5yZWFzb24gPyBlcnJvci5yZWFzb24gYXMgQXBpRXJyb3IgOiB1bmRlZmluZWR9XG4gICAgICAgIGlzRWRpdGluZz17aXNFZGl0aW5nIHx8IGlzQ3JlYXRpbmd9XG4gICAgICAvPn1cbiAgICAgIHsoIWxvYWRpbmdJdGVtVG9FZGl0IHx8ICFyaXNrRm9ybUlkKSAmJiBmb3JtRGF0YSAmJiAoIWlzRWRpdGluZyAmJiAhaXNDcmVhdGluZykgJiYgPFJpc2tGb3JtRGV0YWlsc1xuICAgICAgICBkYXRhPXtmb3JtRGF0YX1cbiAgICAgIC8+XG4gICAgICB9XG4gICAgICB7bG9hZGluZ0l0ZW1Ub0VkaXQgJiYgcmlza0Zvcm1JZCAmJiA8TG9hZGluZ1NjcmVlbiAvPn1cbiAgICA8L0FwcFBhZ2U+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmlza0Zvcm1FZGl0XG4iXX0=