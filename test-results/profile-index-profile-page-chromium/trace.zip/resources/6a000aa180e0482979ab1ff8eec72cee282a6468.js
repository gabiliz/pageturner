import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/pivot/Pivot.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/pivot/Pivot.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Pivot as PivotFluent } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const Pivot = ({
  children,
  styles,
  ...props
}) => {
  _s();
  const pivotStyles = usePivotStyles();
  return /* @__PURE__ */ jsxDEV(PivotFluent, { styles: {
    ...pivotStyles,
    ...styles
  }, ...props, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/pivot/Pivot.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(Pivot, "WAcMVMg/eb262T+9oycvNLOC6jk=", false, function() {
  return [usePivotStyles];
});
_c = Pivot;
const usePivotStyles = () => {
  _s2();
  const theme = useTheme();
  const pivotStyles = {
    itemContainer: {
      paddingTop: theme.spacing.xl
    },
    linkIsSelected: {
      color: theme.colors.purple[300],
      ":hover": {
        color: theme.colors.purple[300]
      },
      "::before": {
        backgroundColor: theme.colors.purple[300]
      },
      "::after": {
        backgroundColor: theme.colors.purple[300]
      }
    }
  };
  return pivotStyles;
};
_s2(usePivotStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default Pivot;
var _c;
$RefreshReg$(_c, "Pivot");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/pivot/Pivot.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixTQUFvQ0EsU0FBU0MsbUJBQW1CO0FBRWhFLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNRixRQUF5QkEsQ0FBQztBQUFBLEVBQUVHO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVEsR0FBR0M7QUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDakUsUUFBTUMsY0FBY0MsZUFBZTtBQUVuQyxTQUNFLHVCQUFDLGVBQ0MsUUFBUTtBQUFBLElBQ04sR0FBR0Q7QUFBQUEsSUFDSCxHQUFHSDtBQUFBQSxFQUNMLEdBQ0EsR0FBSUMsT0FFSEYsWUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDRyxHQWRLTixPQUFzQjtBQUFBLFVBQ05RLGNBQWM7QUFBQTtBQUFBQyxLQUQ5QlQ7QUFnQk4sTUFBTVEsaUJBQWlCQSxNQUFNO0FBQUFFLE1BQUE7QUFDM0IsUUFBTUMsUUFBUVQsU0FBUztBQUV2QixRQUFNSyxjQUFxQztBQUFBLElBQ3pDSyxlQUFlO0FBQUEsTUFDYkMsWUFBWUYsTUFBTUcsUUFBUUM7QUFBQUEsSUFDNUI7QUFBQSxJQUNBQyxnQkFBZ0I7QUFBQSxNQUNkQyxPQUFPTixNQUFNTyxPQUFPQyxPQUFPLEdBQUc7QUFBQSxNQUM5QixVQUFVO0FBQUEsUUFDUkYsT0FBT04sTUFBTU8sT0FBT0MsT0FBTyxHQUFHO0FBQUEsTUFDaEM7QUFBQSxNQUNBLFlBQVk7QUFBQSxRQUNWQyxpQkFBaUJULE1BQU1PLE9BQU9DLE9BQU8sR0FBRztBQUFBLE1BQzFDO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVEMsaUJBQWlCVCxNQUFNTyxPQUFPQyxPQUFPLEdBQUc7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsU0FBT1o7QUFDVDtBQUFDRyxJQXRCS0YsZ0JBQWM7QUFBQSxVQUNKTixRQUFRO0FBQUE7QUFzQnhCLGVBQWVGO0FBQUssSUFBQVM7QUFBQVksYUFBQVosSUFBQSIsIm5hbWVzIjpbIlBpdm90IiwiUGl2b3RGbHVlbnQiLCJ1c2VUaGVtZSIsImNoaWxkcmVuIiwic3R5bGVzIiwicHJvcHMiLCJfcyIsInBpdm90U3R5bGVzIiwidXNlUGl2b3RTdHlsZXMiLCJfYyIsIl9zMiIsInRoZW1lIiwiaXRlbUNvbnRhaW5lciIsInBhZGRpbmdUb3AiLCJzcGFjaW5nIiwieGwiLCJsaW5rSXNTZWxlY3RlZCIsImNvbG9yIiwiY29sb3JzIiwicHVycGxlIiwiYmFja2dyb3VuZENvbG9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGl2b3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvcGl2b3QvUGl2b3QudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVBpdm90UHJvcHMsIElQaXZvdFN0eWxlcywgUGl2b3QgYXMgUGl2b3RGbHVlbnQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcblxuY29uc3QgUGl2b3Q6IEZDPElQaXZvdFByb3BzPiA9ICh7IGNoaWxkcmVuLCBzdHlsZXMsIC4uLnByb3BzIH0pID0+IHtcbiAgY29uc3QgcGl2b3RTdHlsZXMgPSB1c2VQaXZvdFN0eWxlcygpXG5cbiAgcmV0dXJuIChcbiAgICA8UGl2b3RGbHVlbnRcbiAgICAgIHN0eWxlcz17e1xuICAgICAgICAuLi5waXZvdFN0eWxlcyxcbiAgICAgICAgLi4uc3R5bGVzLFxuICAgICAgfX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9QaXZvdEZsdWVudD5cbiAgKVxufVxuXG5jb25zdCB1c2VQaXZvdFN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXG5cbiAgY29uc3QgcGl2b3RTdHlsZXM6IFBhcnRpYWw8SVBpdm90U3R5bGVzPiA9IHtcbiAgICBpdGVtQ29udGFpbmVyOiB7XG4gICAgICBwYWRkaW5nVG9wOiB0aGVtZS5zcGFjaW5nLnhsLFxuICAgIH0sXG4gICAgbGlua0lzU2VsZWN0ZWQ6IHtcbiAgICAgIGNvbG9yOiB0aGVtZS5jb2xvcnMucHVycGxlWzMwMF0sXG4gICAgICAnOmhvdmVyJzoge1xuICAgICAgICBjb2xvcjogdGhlbWUuY29sb3JzLnB1cnBsZVszMDBdLFxuICAgICAgfSxcbiAgICAgICc6OmJlZm9yZSc6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb2xvcnMucHVycGxlWzMwMF0sXG4gICAgICB9LFxuICAgICAgJzo6YWZ0ZXInOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29sb3JzLnB1cnBsZVszMDBdLFxuICAgICAgfSxcbiAgICB9LFxuICB9XG5cbiAgcmV0dXJuIHBpdm90U3R5bGVzXG59XG5leHBvcnQgZGVmYXVsdCBQaXZvdFxuIl19