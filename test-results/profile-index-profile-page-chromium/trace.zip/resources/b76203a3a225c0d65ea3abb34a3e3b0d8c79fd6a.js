import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/Page.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_merge-styles.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { ProgressIndicator } from "/src/shared/components/index.ts?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { PageContent, TopBar, SideBar, SideBarModule } from "/src/shared/components/layout/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { MessageBar } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { MessageContext } from "/src/shared/context/MessageContext.ts";
const Page = (parts) => {
  _s();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const pageStyles = usePageStyles(isLoading);
  const [message, setMessage] = useState();
  const [hasMenu, setHasMenu] = useState(true);
  const [menuCollapsed, setMenuCollapsed] = useState();
  const centerPages = location.pathname === "/backlog-monitor" || location.pathname === "/form-list" || location.pathname === "/answer";
  useEffect(() => {
    if (!location.pathname.includes("control-panel/analysis/patrimonial-testing") && !location.pathname.includes("control-panel/analysis/results-testing")) {
      setHasMenu(true);
    }
  }, [location]);
  const showMessage = (props) => {
    setMessage(props);
  };
  const hideMessage = () => {
    setMessage(void 0);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: pageStyles.mainGrid, children: /* @__PURE__ */ jsxDEV(MessageContext.Provider, { value: {
    showMessage,
    hideMessage,
    message
  }, children: [
    /* @__PURE__ */ jsxDEV(TopBar, { className: pageStyles.topBar, children: [
      parts.topBar,
      isLoading ? /* @__PURE__ */ jsxDEV(ProgressIndicator, { barHeight: 5, className: pageStyles.progressBar }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
        lineNumber: 50,
        columnNumber: 24
      }, this) : parts.topBar && /* @__PURE__ */ jsxDEV("div", { className: pageStyles.progressTrail }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
        lineNumber: 50,
        columnNumber: 113
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this),
    message && /* @__PURE__ */ jsxDEV(MessageBar, { className: pageStyles.messageBar, ...message }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
      lineNumber: 52,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(LoadingDataContext.Provider, { value: {
      menuCollapsed,
      setMenuCollapsed,
      setIsLoading,
      isLoading,
      hasMenu,
      setHasMenu
    }, children: [
      /* @__PURE__ */ jsxDEV(SideBarModule, { className: pageStyles.sideBarModules, children: parts.sideBarModules }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
        lineNumber: 61,
        columnNumber: 11
      }, this),
      !centerPages && hasMenu && /* @__PURE__ */ jsxDEV(SideBar, { className: pageStyles.sideBar, children: parts.sideBar }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
        lineNumber: 64,
        columnNumber: 39
      }, this),
      /* @__PURE__ */ jsxDEV(PageContent, { className: pageStyles.pageContent, children: parts.pageContent }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
        lineNumber: 67,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
      lineNumber: 53,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
    lineNumber: 43,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(Page, "QyYIIzDZHz9OM+5Aco/VuWMmU9c=", false, function() {
  return [useLocation, usePageStyles];
});
_c = Page;
const usePageStyles = (isLoading) => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyleSets({
    mainGrid: {
      display: "grid",
      gridTemplateColumns: "auto auto minmax(0, 1fr)",
      gridTemplateRows: "auto auto 1fr",
      gridTemplateAreas: '"top-bar top-bar top-bar" "side-bar-modules side-bar page-content"',
      height: "100vh",
      overflow: "hidden"
    },
    messageBar: {
      position: "absolute",
      top: isLoading ? "69px" : "65px",
      zIndex: 1
    },
    topBar: {
      gridArea: "top-bar"
    },
    sideBar: {
      gridArea: "side-bar"
    },
    sideBarModules: {
      gridArea: "side-bar-modules"
    },
    pageContent: {
      gridArea: "page-content",
      display: "block",
      overflow: "auto"
    },
    progressTrail: {
      height: "5px",
      backgroundColor: colors.gray[200]
    },
    progressBar: {
      ".ms-ProgressIndicator-itemProgress": {
        padding: "0px 0px"
      },
      ".ms-ProgressIndicator-progressTrack": {
        backgroundColor: colors.gray[200]
      },
      ".ms-ProgressIndicator-progressBar": {
        background: `
          ${colors.black}
          linear-gradient(
            to right,
            ${colors.white} 0%,
            ${colors.blue[500]} 50%,
            ${colors.white} 100%
          )
          repeat
          scroll
          0%
          0%
        `
      }
    }
  });
};
_s2(usePageStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default Page;
var _c;
$RefreshReg$(_c, "Page");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/Page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURnQjs7Ozs7Ozs7Ozs7Ozs7OztBQXpEaEIsU0FBU0Esc0JBQXNCO0FBQy9CLFNBQTJDQyxXQUFXQyxnQkFBZ0I7QUFDdEUsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsYUFBYUMsUUFBUUMsU0FBU0MscUJBQXFCO0FBQzVELFNBQVNDLGdCQUFnQjtBQUN6QixTQUEyQkMsa0JBQWtCO0FBQzdDLFNBQVNDLHNCQUFzQjtBQVMvQixNQUFNQyxPQUF1QkMsV0FBVTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU1DLFdBQVdiLFlBQVk7QUFDN0IsUUFBTSxDQUFDYyxXQUFXQyxZQUFZLElBQUloQixTQUFrQixLQUFLO0FBQ3pELFFBQU1pQixhQUFhQyxjQUFjSCxTQUFTO0FBQzFDLFFBQU0sQ0FBQ0ksU0FBU0MsVUFBVSxJQUFJcEIsU0FBMkI7QUFDekQsUUFBTSxDQUFDcUIsU0FBU0MsVUFBVSxJQUFJdEIsU0FBa0IsSUFBSTtBQUNwRCxRQUFNLENBQUN1QixlQUFlQyxnQkFBZ0IsSUFBSXhCLFNBQThCO0FBQ3hFLFFBQU15QixjQUFjWCxTQUFTWSxhQUFhLHNCQUMxQ1osU0FBU1ksYUFBYSxnQkFBZ0JaLFNBQVNZLGFBQWE7QUFLNUQzQixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNlLFNBQVNZLFNBQVNDLFNBQVMsNENBQTRDLEtBQUssQ0FBQ2IsU0FBU1ksU0FBU0MsU0FBUyx3Q0FBd0MsR0FBRztBQUN0SkwsaUJBQVcsSUFBSTtBQUFBLElBQ2pCO0FBQUEsRUFDRixHQUFHLENBQUNSLFFBQVEsQ0FBQztBQUViLFFBQU1jLGNBQWNBLENBQUNDLFVBQTRCO0FBQy9DVCxlQUFXUyxLQUFLO0FBQUEsRUFDbEI7QUFFQSxRQUFNQyxjQUFjQSxNQUFNO0FBQ3hCVixlQUFXVyxNQUFTO0FBQUEsRUFDdEI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBV2QsV0FBV2UsVUFDekIsaUNBQUMsZUFBZSxVQUFmLEVBQ0MsT0FBTztBQUFBLElBQ0xKO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0FYO0FBQUFBLEVBQ0YsR0FFQTtBQUFBLDJCQUFDLFVBQU8sV0FBV0YsV0FBV2dCLFFBQzNCckI7QUFBQUEsWUFBTXFCO0FBQUFBLE1BRUxsQixZQUNJLHVCQUFDLHFCQUNELFdBQVcsR0FDWCxXQUFXRSxXQUFXaUIsZUFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVrQyxJQUVsQ3RCLE1BQU1xQixVQUFVLHVCQUFDLFNBQUksV0FBV2hCLFdBQVdrQixpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBUmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0NoQixXQUNDLHVCQUFDLGNBQ0MsV0FBV0YsV0FBV21CLFlBQ3RCLEdBQUlqQixXQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFYztBQUFBLElBR2hCLHVCQUFDLG1CQUFtQixVQUFuQixFQUNDLE9BQU87QUFBQSxNQUNMSTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBUjtBQUFBQSxNQUNBRDtBQUFBQSxNQUNBTTtBQUFBQSxNQUNBQztBQUFBQSxJQUNGLEdBRUE7QUFBQSw2QkFBQyxpQkFBYyxXQUFXTCxXQUFXb0IsZ0JBQ2xDekIsZ0JBQU15QixrQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNFLENBQUNaLGVBQWVKLFdBQ2hCLHVCQUFDLFdBQVEsV0FBV0osV0FBV3FCLFNBQzVCMUIsZ0JBQU0wQixXQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYsdUJBQUMsZUFBWSxXQUFXckIsV0FBV3NCLGFBQ2hDM0IsZ0JBQU0yQixlQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxPQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBLEtBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFSjtBQUFDMUIsR0E5RUtGLE1BQW1CO0FBQUEsVUFDTlYsYUFFRWlCLGFBQWE7QUFBQTtBQUFBc0IsS0FINUI3QjtBQWdGTixNQUFNTyxnQkFBZ0JBLENBQUNILGNBQXVCO0FBQUEwQixNQUFBO0FBQzVDLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFPLElBQUlsQyxTQUFTO0FBQzVCLFNBQU9WLGVBQWU7QUFBQSxJQUNwQmtDLFVBQVU7QUFBQSxNQUNSVyxTQUFTO0FBQUEsTUFDVEMscUJBQXFCO0FBQUEsTUFDckJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQVosWUFBWTtBQUFBLE1BQ1ZhLFVBQVU7QUFBQSxNQUNWQyxLQUFLbkMsWUFBWSxTQUFTO0FBQUEsTUFDMUJvQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0FsQixRQUFRO0FBQUEsTUFDTm1CLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQWQsU0FBUztBQUFBLE1BQ1BjLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFDQWYsZ0JBQWdCO0FBQUEsTUFDZGUsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBYixhQUFhO0FBQUEsTUFDWGEsVUFBVTtBQUFBLE1BQ1ZULFNBQVM7QUFBQSxNQUNUSyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0FiLGVBQWU7QUFBQSxNQUNiWSxRQUFRO0FBQUEsTUFDUk0saUJBQWlCWCxPQUFPWSxLQUFLLEdBQUc7QUFBQSxJQUNsQztBQUFBLElBQ0FwQixhQUFhO0FBQUEsTUFDWCxzQ0FBc0M7QUFBQSxRQUNwQ3FCLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQSx1Q0FBdUM7QUFBQSxRQUNyQ0YsaUJBQWlCWCxPQUFPWSxLQUFLLEdBQUc7QUFBQSxNQUNsQztBQUFBLE1BQ0EscUNBQXFDO0FBQUEsUUFDbkNFLFlBQWE7QUFBQSxZQUNUZCxPQUFPZTtBQUFBQTtBQUFBQTtBQUFBQSxjQUdMZixPQUFPZ0I7QUFBQUEsY0FDUGhCLE9BQU9pQixLQUFLLEdBQUc7QUFBQSxjQUNmakIsT0FBT2dCO0FBQUFBO0FBQUFBO0FBQUFBO0FBQUFBO0FBQUFBO0FBQUFBO0FBQUFBLE1BT2Y7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ2pCLElBMURLdkIsZUFBYTtBQUFBLFVBQ0VWLFFBQVE7QUFBQTtBQTJEN0IsZUFBZUc7QUFBSSxJQUFBNkI7QUFBQW9CLGFBQUFwQixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwiUHJvZ3Jlc3NJbmRpY2F0b3IiLCJMb2FkaW5nRGF0YUNvbnRleHQiLCJQYWdlQ29udGVudCIsIlRvcEJhciIsIlNpZGVCYXIiLCJTaWRlQmFyTW9kdWxlIiwidXNlVGhlbWUiLCJNZXNzYWdlQmFyIiwiTWVzc2FnZUNvbnRleHQiLCJQYWdlIiwicGFydHMiLCJfcyIsImxvY2F0aW9uIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicGFnZVN0eWxlcyIsInVzZVBhZ2VTdHlsZXMiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsImhhc01lbnUiLCJzZXRIYXNNZW51IiwibWVudUNvbGxhcHNlZCIsInNldE1lbnVDb2xsYXBzZWQiLCJjZW50ZXJQYWdlcyIsInBhdGhuYW1lIiwiaW5jbHVkZXMiLCJzaG93TWVzc2FnZSIsInByb3BzIiwiaGlkZU1lc3NhZ2UiLCJ1bmRlZmluZWQiLCJtYWluR3JpZCIsInRvcEJhciIsInByb2dyZXNzQmFyIiwicHJvZ3Jlc3NUcmFpbCIsIm1lc3NhZ2VCYXIiLCJzaWRlQmFyTW9kdWxlcyIsInNpZGVCYXIiLCJwYWdlQ29udGVudCIsIl9jIiwiX3MyIiwiY29sb3JzIiwiZGlzcGxheSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJncmlkVGVtcGxhdGVSb3dzIiwiZ3JpZFRlbXBsYXRlQXJlYXMiLCJoZWlnaHQiLCJvdmVyZmxvdyIsInBvc2l0aW9uIiwidG9wIiwiekluZGV4IiwiZ3JpZEFyZWEiLCJiYWNrZ3JvdW5kQ29sb3IiLCJncmF5IiwicGFkZGluZyIsImJhY2tncm91bmQiLCJibGFjayIsIndoaXRlIiwiYmx1ZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2UudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMgfSBmcm9tICdAZmx1ZW50dWkvbWVyZ2Utc3R5bGVzJ1xuaW1wb3J0IHsgRkMsIEhUTUxBdHRyaWJ1dGVzLCBSZWFjdEVsZW1lbnQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFByb2dyZXNzSW5kaWNhdG9yIH0gZnJvbSAnLi4nXG5pbXBvcnQgeyBMb2FkaW5nRGF0YUNvbnRleHQgfSBmcm9tICcuLi8uLi9jb250ZXh0L0xvYWRpbmdEYXRhQ29udGV4dCdcbmltcG9ydCB7IFBhZ2VDb250ZW50LCBUb3BCYXIsIFNpZGVCYXIsIFNpZGVCYXJNb2R1bGUgfSBmcm9tICcuL2luZGV4J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IElNZXNzYWdlQmFyUHJvcHMsIE1lc3NhZ2VCYXIgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBNZXNzYWdlQ29udGV4dCB9IGZyb20gJy4uLy4uL2NvbnRleHQvTWVzc2FnZUNvbnRleHQnXG5cbmludGVyZmFjZSBQYWdlUHJvcHMgZXh0ZW5kcyBIVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4ge1xuICBwYWdlQ29udGVudD86IFJlYWN0RWxlbWVudCxcbiAgdG9wQmFyPzogUmVhY3RFbGVtZW50LFxuICBzaWRlQmFyPzogUmVhY3RFbGVtZW50LFxuICBzaWRlQmFyTW9kdWxlcz86IFJlYWN0RWxlbWVudCxcbn1cblxuY29uc3QgUGFnZTogRkM8UGFnZVByb3BzPiA9IChwYXJ0cykgPT4ge1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxuICBjb25zdCBwYWdlU3R5bGVzID0gdXNlUGFnZVN0eWxlcyhpc0xvYWRpbmcpXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlPElNZXNzYWdlQmFyUHJvcHM+KClcbiAgY29uc3QgW2hhc01lbnUsIHNldEhhc01lbnVdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSlcbiAgY29uc3QgW21lbnVDb2xsYXBzZWQsIHNldE1lbnVDb2xsYXBzZWRdID0gdXNlU3RhdGU8Ym9vbGVhbiB8IHVuZGVmaW5lZD4oKVxuICBjb25zdCBjZW50ZXJQYWdlcyA9IGxvY2F0aW9uLnBhdGhuYW1lID09PSAnL2JhY2tsb2ctbW9uaXRvcicgfHxcbiAgbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvZm9ybS1saXN0JyB8fCBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy9hbnN3ZXInXG5cbiAgLy8gRklYTUU6IFNvbHXDp2FvIHRlbXBvcmFyaWEgcGFyYSBjb21wYXJ0aWxoYW1lbnRvIGRlIGVzdGFkbyBuYSBzaWRlIGJhciBkYSBleGVjdcOnYW8gZGUgdGVzdGVzXG4gIC8vIEZlaXRvIGRlc3RhIGZvcm1hIGRldmlkbyBhIHRlbXBvIGxpbWl0YWRvIHBhcmEgZW50cmVnYVxuICAvLyBhanVzdGFyIGZ1dHVyYW1lbnRlIHBhcmEgcSBuIHNlamEgbmVjZXNzYXJpbyB1dGlsaXphciBvIGhhcyBtZW51LCBkZSBwcmVmZXJlbmNpYSBmYXplciBvIGVzdGFkbyB1dGlsaXphbmRvIHJlZHV4XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFsb2NhdGlvbi5wYXRobmFtZS5pbmNsdWRlcygnY29udHJvbC1wYW5lbC9hbmFseXNpcy9wYXRyaW1vbmlhbC10ZXN0aW5nJykgJiYgIWxvY2F0aW9uLnBhdGhuYW1lLmluY2x1ZGVzKCdjb250cm9sLXBhbmVsL2FuYWx5c2lzL3Jlc3VsdHMtdGVzdGluZycpKSB7XG4gICAgICBzZXRIYXNNZW51KHRydWUpXG4gICAgfVxuICB9LCBbbG9jYXRpb25dKVxuXG4gIGNvbnN0IHNob3dNZXNzYWdlID0gKHByb3BzOiBJTWVzc2FnZUJhclByb3BzKSA9PiB7XG4gICAgc2V0TWVzc2FnZShwcm9wcylcbiAgfVxuXG4gIGNvbnN0IGhpZGVNZXNzYWdlID0gKCkgPT4ge1xuICAgIHNldE1lc3NhZ2UodW5kZWZpbmVkKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17cGFnZVN0eWxlcy5tYWluR3JpZH0+XG4gICAgICA8TWVzc2FnZUNvbnRleHQuUHJvdmlkZXJcbiAgICAgICAgdmFsdWU9e3tcbiAgICAgICAgICBzaG93TWVzc2FnZSxcbiAgICAgICAgICBoaWRlTWVzc2FnZSxcbiAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8VG9wQmFyIGNsYXNzTmFtZT17cGFnZVN0eWxlcy50b3BCYXJ9PlxuICAgICAgICAgIHtwYXJ0cy50b3BCYXJ9XG4gICAgICAgICAge1xuICAgICAgICAgICAgaXNMb2FkaW5nXG4gICAgICAgICAgICAgID8gPFByb2dyZXNzSW5kaWNhdG9yXG4gICAgICAgICAgICAgICAgYmFySGVpZ2h0PXs1fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17cGFnZVN0eWxlcy5wcm9ncmVzc0Jhcn1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgOiBwYXJ0cy50b3BCYXIgJiYgPGRpdiBjbGFzc05hbWU9e3BhZ2VTdHlsZXMucHJvZ3Jlc3NUcmFpbH0vPlxuICAgICAgICAgIH1cbiAgICAgICAgPC9Ub3BCYXI+XG4gICAgICAgIHttZXNzYWdlICYmIChcbiAgICAgICAgICA8TWVzc2FnZUJhclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtwYWdlU3R5bGVzLm1lc3NhZ2VCYXJ9XG4gICAgICAgICAgICB7Li4ubWVzc2FnZX1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgICA8TG9hZGluZ0RhdGFDb250ZXh0LlByb3ZpZGVyXG4gICAgICAgICAgdmFsdWU9e3tcbiAgICAgICAgICAgIG1lbnVDb2xsYXBzZWQsXG4gICAgICAgICAgICBzZXRNZW51Q29sbGFwc2VkLFxuICAgICAgICAgICAgc2V0SXNMb2FkaW5nLFxuICAgICAgICAgICAgaXNMb2FkaW5nLFxuICAgICAgICAgICAgaGFzTWVudSxcbiAgICAgICAgICAgIHNldEhhc01lbnUsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxTaWRlQmFyTW9kdWxlIGNsYXNzTmFtZT17cGFnZVN0eWxlcy5zaWRlQmFyTW9kdWxlc30+XG4gICAgICAgICAgICB7cGFydHMuc2lkZUJhck1vZHVsZXN9XG4gICAgICAgICAgPC9TaWRlQmFyTW9kdWxlPlxuICAgICAgICAgIHsgIWNlbnRlclBhZ2VzICYmIGhhc01lbnUgJiZcbiAgICAgICAgICAgIDxTaWRlQmFyIGNsYXNzTmFtZT17cGFnZVN0eWxlcy5zaWRlQmFyfT5cbiAgICAgICAgICAgICAge3BhcnRzLnNpZGVCYXJ9XG4gICAgICAgICAgICA8L1NpZGVCYXI+XG4gICAgICAgICAgfVxuICAgICAgICAgIDxQYWdlQ29udGVudCBjbGFzc05hbWU9e3BhZ2VTdHlsZXMucGFnZUNvbnRlbnR9PlxuICAgICAgICAgICAge3BhcnRzLnBhZ2VDb250ZW50fVxuICAgICAgICAgIDwvUGFnZUNvbnRlbnQ+XG4gICAgICAgIDwvTG9hZGluZ0RhdGFDb250ZXh0LlByb3ZpZGVyPlxuICAgICAgPC9NZXNzYWdlQ29udGV4dC5Qcm92aWRlcj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5jb25zdCB1c2VQYWdlU3R5bGVzID0gKGlzTG9hZGluZzogYm9vbGVhbikgPT4ge1xuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xuICAgIG1haW5HcmlkOiB7XG4gICAgICBkaXNwbGF5OiAnZ3JpZCcsXG4gICAgICBncmlkVGVtcGxhdGVDb2x1bW5zOiAnYXV0byBhdXRvIG1pbm1heCgwLCAxZnIpJyxcbiAgICAgIGdyaWRUZW1wbGF0ZVJvd3M6ICdhdXRvIGF1dG8gMWZyJyxcbiAgICAgIGdyaWRUZW1wbGF0ZUFyZWFzOiAnXCJ0b3AtYmFyIHRvcC1iYXIgdG9wLWJhclwiIFwic2lkZS1iYXItbW9kdWxlcyBzaWRlLWJhciBwYWdlLWNvbnRlbnRcIicsXG4gICAgICBoZWlnaHQ6ICcxMDB2aCcsXG4gICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgfSxcbiAgICBtZXNzYWdlQmFyOiB7XG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIHRvcDogaXNMb2FkaW5nID8gJzY5cHgnIDogJzY1cHgnLFxuICAgICAgekluZGV4OiAxLFxuICAgIH0sXG4gICAgdG9wQmFyOiB7XG4gICAgICBncmlkQXJlYTogJ3RvcC1iYXInLFxuICAgIH0sXG4gICAgc2lkZUJhcjoge1xuICAgICAgZ3JpZEFyZWE6ICdzaWRlLWJhcicsXG4gICAgfSxcbiAgICBzaWRlQmFyTW9kdWxlczoge1xuICAgICAgZ3JpZEFyZWE6ICdzaWRlLWJhci1tb2R1bGVzJyxcbiAgICB9LFxuICAgIHBhZ2VDb250ZW50OiB7XG4gICAgICBncmlkQXJlYTogJ3BhZ2UtY29udGVudCcsXG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgb3ZlcmZsb3c6ICdhdXRvJyxcbiAgICB9LFxuICAgIHByb2dyZXNzVHJhaWw6IHtcbiAgICAgIGhlaWdodDogJzVweCcsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXG4gICAgfSxcbiAgICBwcm9ncmVzc0Jhcjoge1xuICAgICAgJy5tcy1Qcm9ncmVzc0luZGljYXRvci1pdGVtUHJvZ3Jlc3MnOiB7XG4gICAgICAgIHBhZGRpbmc6ICcwcHggMHB4JyxcbiAgICAgIH0sXG4gICAgICAnLm1zLVByb2dyZXNzSW5kaWNhdG9yLXByb2dyZXNzVHJhY2snOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcbiAgICAgIH0sXG4gICAgICAnLm1zLVByb2dyZXNzSW5kaWNhdG9yLXByb2dyZXNzQmFyJzoge1xuICAgICAgICBiYWNrZ3JvdW5kOiBgXG4gICAgICAgICAgJHtjb2xvcnMuYmxhY2t9XG4gICAgICAgICAgbGluZWFyLWdyYWRpZW50KFxuICAgICAgICAgICAgdG8gcmlnaHQsXG4gICAgICAgICAgICAke2NvbG9ycy53aGl0ZX0gMCUsXG4gICAgICAgICAgICAke2NvbG9ycy5ibHVlWzUwMF19IDUwJSxcbiAgICAgICAgICAgICR7Y29sb3JzLndoaXRlfSAxMDAlXG4gICAgICAgICAgKVxuICAgICAgICAgIHJlcGVhdFxuICAgICAgICAgIHNjcm9sbFxuICAgICAgICAgIDAlXG4gICAgICAgICAgMCVcbiAgICAgICAgYCxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGFnZVxuIl19