export var FileExtensionEnum = /* @__PURE__ */ ((FileExtensionEnum2) => {
  FileExtensionEnum2["accdb"] = "accdb";
  FileExtensionEnum2["audio"] = "audio";
  FileExtensionEnum2["code"] = "code";
  FileExtensionEnum2["csv"] = "csv";
  FileExtensionEnum2["docx"] = "docx";
  FileExtensionEnum2["doc"] = "doc";
  FileExtensionEnum2["dotx"] = "dotx";
  FileExtensionEnum2["mpp"] = "mpp";
  FileExtensionEnum2["mpt"] = "mpt";
  FileExtensionEnum2["model"] = "model";
  FileExtensionEnum2["one"] = "one";
  FileExtensionEnum2["onetoc"] = "onetoc";
  FileExtensionEnum2["potx"] = "potx";
  FileExtensionEnum2["ppsx"] = "ppsx";
  FileExtensionEnum2["pdf"] = "pdf";
  FileExtensionEnum2["photo"] = "photo";
  FileExtensionEnum2["png"] = "png";
  FileExtensionEnum2["pptx"] = "pptx";
  FileExtensionEnum2["presentation"] = "presentation";
  FileExtensionEnum2["pub"] = "pub";
  FileExtensionEnum2["rtf"] = "rtf";
  FileExtensionEnum2["spreadsheet"] = "spreadsheet";
  FileExtensionEnum2["txt"] = "txt";
  FileExtensionEnum2["vector"] = "vector";
  FileExtensionEnum2["vsdx"] = "vsdx";
  FileExtensionEnum2["vssx"] = "vssx";
  FileExtensionEnum2["vstx"] = "vstx";
  FileExtensionEnum2["xlsx"] = "xlsx";
  FileExtensionEnum2["xltx"] = "xltx";
  FileExtensionEnum2["xsn"] = "xsn";
  FileExtensionEnum2["zip"] = "zip";
  return FileExtensionEnum2;
})(FileExtensionEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkZpbGVFeHRlbnNpb25FbnVtLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXG5leHBvcnQgZW51bSBGaWxlRXh0ZW5zaW9uRW51bSB7XG4gICdhY2NkYicgPSAnYWNjZGInLFxuICAnYXVkaW8nID0gJ2F1ZGlvJyxcbiAgJ2NvZGUnID0gJ2NvZGUnLFxuICAnY3N2JyA9ICdjc3YnLFxuICAnZG9jeCcgPSAnZG9jeCcsXG4gICdkb2MnID0gJ2RvYycsXG4gICdkb3R4JyA9ICdkb3R4JyxcbiAgJ21wcCcgPSAnbXBwJyxcbiAgJ21wdCcgPSAnbXB0JyxcbiAgJ21vZGVsJyA9ICdtb2RlbCcsXG4gICdvbmUnID0gJ29uZScsXG4gICdvbmV0b2MnID0gJ29uZXRvYycsXG4gICdwb3R4JyA9ICdwb3R4JyxcbiAgJ3Bwc3gnID0gJ3Bwc3gnLFxuICAncGRmJyA9ICdwZGYnLFxuICAncGhvdG8nID0gJ3Bob3RvJyxcbiAgJ3BuZycgPSAncG5nJyxcbiAgJ3BwdHgnID0gJ3BwdHgnLFxuICAncHJlc2VudGF0aW9uJyA9ICdwcmVzZW50YXRpb24nLFxuICAncHViJyA9ICdwdWInLFxuICAncnRmJyA9ICdydGYnLFxuICAnc3ByZWFkc2hlZXQnID0gJ3NwcmVhZHNoZWV0JyxcbiAgJ3R4dCcgPSAndHh0JyxcbiAgJ3ZlY3RvcicgPSAndmVjdG9yJyxcbiAgJ3ZzZHgnID0gJ3ZzZHgnLFxuICAndnNzeCcgPSAndnNzeCcsXG4gICd2c3R4JyA9ICd2c3R4JyxcbiAgJ3hsc3gnID0gJ3hsc3gnLFxuICAneGx0eCcgPSAneGx0eCcsXG4gICd4c24nID0gJ3hzbicsXG4gICd6aXAnID0gJ3ppcCcsXG59XG4iXSwibWFwcGluZ3MiOiJBQUNPLFdBQUssb0JBQUwsa0JBQUtBLHVCQUFMO0FBQ0wsRUFBQUEsbUJBQUEsV0FBVTtBQUNWLEVBQUFBLG1CQUFBLFdBQVU7QUFDVixFQUFBQSxtQkFBQSxVQUFTO0FBQ1QsRUFBQUEsbUJBQUEsU0FBUTtBQUNSLEVBQUFBLG1CQUFBLFVBQVM7QUFDVCxFQUFBQSxtQkFBQSxTQUFRO0FBQ1IsRUFBQUEsbUJBQUEsVUFBUztBQUNULEVBQUFBLG1CQUFBLFNBQVE7QUFDUixFQUFBQSxtQkFBQSxTQUFRO0FBQ1IsRUFBQUEsbUJBQUEsV0FBVTtBQUNWLEVBQUFBLG1CQUFBLFNBQVE7QUFDUixFQUFBQSxtQkFBQSxZQUFXO0FBQ1gsRUFBQUEsbUJBQUEsVUFBUztBQUNULEVBQUFBLG1CQUFBLFVBQVM7QUFDVCxFQUFBQSxtQkFBQSxTQUFRO0FBQ1IsRUFBQUEsbUJBQUEsV0FBVTtBQUNWLEVBQUFBLG1CQUFBLFNBQVE7QUFDUixFQUFBQSxtQkFBQSxVQUFTO0FBQ1QsRUFBQUEsbUJBQUEsa0JBQWlCO0FBQ2pCLEVBQUFBLG1CQUFBLFNBQVE7QUFDUixFQUFBQSxtQkFBQSxTQUFRO0FBQ1IsRUFBQUEsbUJBQUEsaUJBQWdCO0FBQ2hCLEVBQUFBLG1CQUFBLFNBQVE7QUFDUixFQUFBQSxtQkFBQSxZQUFXO0FBQ1gsRUFBQUEsbUJBQUEsVUFBUztBQUNULEVBQUFBLG1CQUFBLFVBQVM7QUFDVCxFQUFBQSxtQkFBQSxVQUFTO0FBQ1QsRUFBQUEsbUJBQUEsVUFBUztBQUNULEVBQUFBLG1CQUFBLFVBQVM7QUFDVCxFQUFBQSxtQkFBQSxTQUFRO0FBQ1IsRUFBQUEsbUJBQUEsU0FBUTtBQS9CRSxTQUFBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiRmlsZUV4dGVuc2lvbkVudW0iXX0=