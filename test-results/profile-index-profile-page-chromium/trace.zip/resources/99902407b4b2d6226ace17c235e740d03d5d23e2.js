import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/contentPage/PageSubtitle.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageSubtitle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const PageSubtitle = ({
  children,
  hideMarginTop
}) => {
  _s();
  const {
    spacing,
    colors,
    fontWeight
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(Text, { variant: "mediumPlus", block: true, nowrap: true, styles: {
    root: {
      marginTop: !hideMarginTop ? spacing.xxl : void 0,
      fontWeight: fontWeight.semibold,
      color: colors.gray[800]
    }
  }, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageSubtitle.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(PageSubtitle, "cdmU1wPWdPuI6imuk1FDrluEhSQ=", false, function() {
  return [useTheme];
});
_c = PageSubtitle;
export default PageSubtitle;
var _c;
$RefreshReg$(_c, "PageSubtitle");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/contentPage/PageSubtitle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWSixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQU16QixNQUFNQyxlQUFzQ0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQWMsTUFBTTtBQUFBQyxLQUFBO0FBQzNFLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFTQztBQUFBQSxJQUFRQztBQUFBQSxFQUFXLElBQUlQLFNBQVM7QUFDakQsU0FDRSx1QkFBQyxRQUNDLFNBQVEsY0FDUixPQUFLLE1BQ0wsUUFBTSxNQUNOLFFBQVE7QUFBQSxJQUNOUSxNQUFNO0FBQUEsTUFDSkMsV0FBVyxDQUFDTixnQkFBZ0JFLFFBQVFLLE1BQU1DO0FBQUFBLE1BQzFDSixZQUFZQSxXQUFXSztBQUFBQSxNQUN2QkMsT0FBT1AsT0FBT1EsS0FBSyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGLEdBRUVaLFlBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ0UsR0FsQktILGNBQW1DO0FBQUEsVUFDQ0QsUUFBUTtBQUFBO0FBQUFlLEtBRDVDZDtBQW9CTixlQUFlQTtBQUFZLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUZXh0IiwidXNlVGhlbWUiLCJQYWdlU3VidGl0bGUiLCJjaGlsZHJlbiIsImhpZGVNYXJnaW5Ub3AiLCJfcyIsInNwYWNpbmciLCJjb2xvcnMiLCJmb250V2VpZ2h0Iiwicm9vdCIsIm1hcmdpblRvcCIsInh4bCIsInVuZGVmaW5lZCIsInNlbWlib2xkIiwiY29sb3IiLCJncmF5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQYWdlU3VidGl0bGUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvY29udGVudFBhZ2UvUGFnZVN1YnRpdGxlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBUZXh0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcblxuaW50ZXJmYWNlIFBhZ2VTdWJ0aXRsZVByb3BzIHtcbiAgaGlkZU1hcmdpblRvcD86IGJvb2xlYW5cbn1cblxuY29uc3QgUGFnZVN1YnRpdGxlOiBGQzxQYWdlU3VidGl0bGVQcm9wcz4gPSAoeyBjaGlsZHJlbiwgaGlkZU1hcmdpblRvcCB9KSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzLCBmb250V2VpZ2h0IH0gPSB1c2VUaGVtZSgpXG4gIHJldHVybiAoXG4gICAgPFRleHRcbiAgICAgIHZhcmlhbnQ9XCJtZWRpdW1QbHVzXCJcbiAgICAgIGJsb2NrXG4gICAgICBub3dyYXBcbiAgICAgIHN0eWxlcz17e1xuICAgICAgICByb290OiB7XG4gICAgICAgICAgbWFyZ2luVG9wOiAhaGlkZU1hcmdpblRvcCA/IHNwYWNpbmcueHhsIDogdW5kZWZpbmVkLFxuICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXG4gICAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzgwMF0sXG4gICAgICAgIH0sXG4gICAgICB9fVxuICAgID5cbiAgICAgIHsgY2hpbGRyZW4gfVxuICAgIDwvVGV4dD5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBQYWdlU3VidGl0bGVcbiJdfQ==