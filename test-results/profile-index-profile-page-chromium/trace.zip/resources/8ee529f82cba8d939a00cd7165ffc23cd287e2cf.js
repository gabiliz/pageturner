import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditResultsTestingSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditResultsTestingSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AnalyticalRevisionContext } from "/src/modules/audit/analyticalRevision/context/AnalyticalRevisionContext.ts";
const AuditResultsTestingSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname,
    search
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const searchParams = useMemo(() => new URLSearchParams(search), [search]);
  const searchCompanyId = searchParams.get("searchCompanyId");
  const {
    audit,
    group
  } = useContext(AnalyticalRevisionContext);
  const navLinkGroups = useMemo(() => [{
    links: group?.map((gr) => {
      return {
        key: gr.codigo,
        name: gr.descricao,
        title: gr.descricao,
        permission: "Auditoria",
        url: `${pathname}/${gr.codigo}${searchCompanyId ? `?searchCompanyId=${searchCompanyId}` : ""}`
      };
    }).filter((gr) => gr.name !== "Lucro Antes das Receitas e Despesas Financeiras")
  }], [disableTabs, isGroupExpanded, pathname, group]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((gr, index) => {
      filteredGroup[index].links = gr.links?.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Testes de contas de resultados", disabledCollapse: true, subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditResultsTestingSideMenu.tsx",
    lineNumber: 68,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditResultsTestingSideMenu.tsx",
    lineNumber: 67,
    columnNumber: 86
  }, this), groups: permissionNav, onLinkClick: handleClick, goBack: () => navigate(`/audit/audits/${audit?.id}/control-panel/analysis/dashboard`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditResultsTestingSideMenu.tsx",
    lineNumber: 67,
    columnNumber: 10
  }, this);
};
_s(AuditResultsTestingSideMenu, "fxP1vd+fhV+aRRPjYzohMj/YcZQ=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme];
});
_c = AuditResultsTestingSideMenu;
export default AuditResultsTestingSideMenu;
var _c;
$RefreshReg$(_c, "AuditResultsTestingSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditResultsTestingSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkVVOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0VWLFNBQXlCQSxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFekUsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQXVCQyxzQkFBc0I7QUFDN0MsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxpQ0FBaUM7QUFFMUMsTUFBTUMsOEJBQWtDQSxNQUFNO0FBQUFDLEtBQUE7QUFDNUMsUUFBTUMsV0FBV1YsWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRVc7QUFBQUEsSUFBVUM7QUFBQUEsRUFBTyxJQUFJYixZQUFZO0FBQ3pDLFFBQU07QUFBQSxJQUFFYztBQUFBQSxFQUFjLElBQUlaLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVhO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSVosU0FBUztBQUMzRCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNzQixpQkFBaUJDLGtCQUFrQixJQUFJdkIsU0FBa0IsS0FBSztBQUNyRSxRQUFNd0IsZUFBZXpCLFFBQVEsTUFBTSxJQUFJMEIsZ0JBQWdCWCxNQUFNLEdBQUcsQ0FBQ0EsTUFBTSxDQUFDO0FBQ3hFLFFBQU1ZLGtCQUFrQkYsYUFBYUcsSUFBSSxpQkFBaUI7QUFDMUQsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSWhDLFdBQVdZLHlCQUF5QjtBQUV4QyxRQUFNcUIsZ0JBQWlDL0IsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRWdDLE9BQU9GLE9BQU9HLElBQUlDLFFBQU07QUFDdEIsYUFBTztBQUFBLFFBQ0xDLEtBQUtELEdBQUdFO0FBQUFBLFFBQ1JDLE1BQU1ILEdBQUdJO0FBQUFBLFFBQ1RDLE9BQU9MLEdBQUdJO0FBQUFBLFFBQ1ZFLFlBQVk7QUFBQSxRQUNaQyxLQUFNLEdBQUUzQixZQUFZb0IsR0FBR0UsU0FBU1Qsa0JBQW1CLG9CQUFtQkEsb0JBQW9CO0FBQUEsTUFDNUY7QUFBQSxJQUNGLENBQUMsRUFBRWUsT0FBT1IsUUFBTUEsR0FBR0csU0FBUyxpREFBaUQ7QUFBQSxFQUMvRSxDQUFDLEdBQ0EsQ0FBQ2hCLGFBQWFFLGlCQUFpQlQsVUFBVWdCLEtBQUssQ0FBQztBQUVsRCxRQUFNYSxnQkFBZ0IzQyxRQUFRLE1BQU07QUFDbEMsVUFBTTRDLGdCQUFpQyxDQUFDLEdBQUdiLGFBQWE7QUFDeERhLGtCQUFjQyxRQUFRLENBQUNYLElBQUlZLFVBQVU7QUFDbkNGLG9CQUFjRSxLQUFLLEVBQUVkLFFBQVFFLEdBQUdGLE9BQU9VLE9BQU9LLGFBQVcvQixjQUFjK0IsUUFBUVAsWUFBNEIsWUFBWSxDQUFDO0FBQUEsSUFDMUgsQ0FBQztBQUNELFdBQU9JO0FBQUFBLEVBQ1QsR0FBRyxDQUFDYixhQUFhLENBQUM7QUFFbEIsUUFBTWlCLGNBQWNBLENBQUNDLElBQWlCQyxTQUFvQjtBQUN4RCxRQUFJRCxPQUFPRSxVQUFhRCxTQUFTQyxRQUFXO0FBQzFDRixTQUFHRyxlQUFlO0FBQ2xCLFVBQUlGLEtBQUtsQixPQUFPO0FBQ2RSLDJCQUFtQixDQUFDRCxlQUFlO0FBQUEsTUFDckMsT0FBTztBQUNMVixpQkFBU3FDLEtBQUtULEdBQUc7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUExQyxZQUFVLE1BQU07QUFDZCxVQUFNc0Qsa0JBQWtCeEIsT0FBT3lCLFNBQVNDLEtBQUtDLGFBQVdBLFFBQVFDLHFCQUFxQixJQUFJLEVBQUU7QUFDM0ZuQyxtQkFBZStCLG1CQUFtQnhCLE9BQU82QixhQUFhLENBQUM7QUFBQSxFQUN6RCxHQUFHLENBQUM3QixLQUFLLENBQUM7QUFFVixTQUNFLHVCQUFDLFlBQ0MsT0FBTSxrQ0FDTixrQkFBZ0IsTUFDaEIsVUFDRSx1QkFBQyxRQUNDLE1BQ0csa0JBQWlCQSxPQUFPOEIsVUFBVUMsdUJBQ2pDL0IsT0FBTzhCLFVBQVVFLHNCQUNaLEdBQUVoQyxPQUFPOEIsU0FBU0UsbUNBQW1DaEMsT0FBTzhCLFVBQVVHLG1CQUN2RWpDLE9BQU84QixVQUFVSSxNQUd6QixRQUFPLFNBRVAsaUNBQUMsUUFDQyxRQUFRO0FBQUEsSUFDTkMsTUFBTTtBQUFBLE1BQ0pDLE9BQU9oRCxPQUFPaUQsS0FBSyxHQUFHO0FBQUEsTUFDdEIvQyxZQUFZQSxXQUFXZ0Q7QUFBQUEsTUFDdkIvQyxVQUFVQSxTQUFTZ0Q7QUFBQUEsTUFDbkJDLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUNwQ0ksWUFBWXBELFFBQVFxRDtBQUFBQSxNQUNwQkMsVUFBVTtBQUFBLE1BQ1ZDLGNBQWN2RCxRQUFRd0Q7QUFBQUEsTUFDdEIsV0FBVztBQUFBLFFBQ1RMLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsT0FBSyxNQUVKckM7QUFBQUEsV0FBTzhCLFVBQVVnQjtBQUFBQSxJQUFhO0FBQUEsSUFBSXBFLHFCQUFxQnNCLE9BQU84QixVQUFVRyxjQUF3QjtBQUFBLE9BakJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsR0FFRixRQUFRbkIsZUFDUixhQUFhSyxhQUNiLFFBQVEsTUFBTW5DLFNBQVUsaUJBQWdCZ0IsT0FBT2tDLHFDQUFxQyxLQXJDdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDd0Y7QUFHNUY7QUFBQ25ELEdBN0ZLRCw2QkFBK0I7QUFBQSxVQUNsQlIsYUFDWUQsYUFDSEUsZ0JBQ3dCSSxRQUFRO0FBQUE7QUFBQW9FLEtBSnREakU7QUErRk4sZUFBZUE7QUFBMkIsSUFBQWlFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVBlcm1pc3Npb25zIiwiTGluayIsIlNpZGVNZW51IiwiZm9ybWF0UHJvcG9zYWxOdW1iZXIiLCJ1c2VUaGVtZSIsIlRleHQiLCJBbmFseXRpY2FsUmV2aXNpb25Db250ZXh0IiwiQXVkaXRSZXN1bHRzVGVzdGluZ1NpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwic2VhcmNoIiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJkaXNhYmxlVGFicyIsInNldERpc2FibGVUYWJzIiwiaXNHcm91cEV4cGFuZGVkIiwic2V0SXNHcm91cEV4cGFuZGVkIiwic2VhcmNoUGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwic2VhcmNoQ29tcGFueUlkIiwiZ2V0IiwiYXVkaXQiLCJncm91cCIsIm5hdkxpbmtHcm91cHMiLCJsaW5rcyIsIm1hcCIsImdyIiwia2V5IiwiY29kaWdvIiwibmFtZSIsImRlc2NyaWNhbyIsInRpdGxlIiwicGVybWlzc2lvbiIsInVybCIsImZpbHRlciIsInBlcm1pc3Npb25OYXYiLCJmaWx0ZXJlZEdyb3VwIiwiZm9yRWFjaCIsImluZGV4IiwibmF2TGluayIsImhhbmRsZUNsaWNrIiwiZXYiLCJpdGVtIiwidW5kZWZpbmVkIiwicHJldmVudERlZmF1bHQiLCJ2ZXJpZnlTaXR1YXRpb24iLCJlbXByZXNhcyIsInNvbWUiLCJlbXByZXNhIiwic2l0dWFjYW9SZXZpc2FvIiwic2l0dWFjYW8iLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsImlkIiwicm9vdCIsImNvbG9yIiwiZ3JheSIsInNlbWlib2xkIiwicDE0IiwidGV4dERlY29yYXRpb25Db2xvciIsIm1hcmdpbkxlZnQiLCJsZyIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwibWQiLCJub21lRmFudGFzaWEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0UmVzdWx0c1Rlc3RpbmdTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRSZXN1bHRzVGVzdGluZ1NpZGVNZW51LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBNb3VzZUV2ZW50LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElOYXZMaW5rR3JvdXAsIElOYXZMaW5rIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0L2xpYi9OYXYnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHNlcnZpY2VDb2RlcywgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi9hdXRoL2hvb2tzL3Blcm1pc3Npb25zJ1xyXG5pbXBvcnQgeyBMaW5rLCBTaWRlTWVudSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBmb3JtYXRQcm9wb3NhbE51bWJlciB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC91dGlscydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEFuYWx5dGljYWxSZXZpc2lvbkNvbnRleHQgfSBmcm9tICcuLi9hbmFseXRpY2FsUmV2aXNpb24vY29udGV4dC9BbmFseXRpY2FsUmV2aXNpb25Db250ZXh0J1xyXG5cclxuY29uc3QgQXVkaXRSZXN1bHRzVGVzdGluZ1NpZGVNZW51OiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHBhdGhuYW1lLCBzZWFyY2ggfSA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCB7IGhhc1Blcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKClcclxuICBjb25zdCB7IGNvbG9ycywgc3BhY2luZywgZm9udFdlaWdodCwgZm9udFNpemUgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCBbZGlzYWJsZVRhYnMsIHNldERpc2FibGVUYWJzXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtpc0dyb3VwRXhwYW5kZWQsIHNldElzR3JvdXBFeHBhbmRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSlcclxuICBjb25zdCBzZWFyY2hQYXJhbXMgPSB1c2VNZW1vKCgpID0+IG5ldyBVUkxTZWFyY2hQYXJhbXMoc2VhcmNoKSwgW3NlYXJjaF0pXHJcbiAgY29uc3Qgc2VhcmNoQ29tcGFueUlkID0gc2VhcmNoUGFyYW1zLmdldCgnc2VhcmNoQ29tcGFueUlkJylcclxuICBjb25zdCB7XHJcbiAgICBhdWRpdCxcclxuICAgIGdyb3VwLFxyXG4gIH0gPSB1c2VDb250ZXh0KEFuYWx5dGljYWxSZXZpc2lvbkNvbnRleHQpXHJcblxyXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAge1xyXG4gICAgICBsaW5rczogZ3JvdXA/Lm1hcChnciA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGtleTogZ3IuY29kaWdvLFxyXG4gICAgICAgICAgbmFtZTogZ3IuZGVzY3JpY2FvLFxyXG4gICAgICAgICAgdGl0bGU6IGdyLmRlc2NyaWNhbyxcclxuICAgICAgICAgIHBlcm1pc3Npb246ICdBdWRpdG9yaWEnLFxyXG4gICAgICAgICAgdXJsOiBgJHtwYXRobmFtZX0vJHtnci5jb2RpZ299JHtzZWFyY2hDb21wYW55SWQgPyBgP3NlYXJjaENvbXBhbnlJZD0ke3NlYXJjaENvbXBhbnlJZH1gIDogJyd9YCxcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihnciA9PiBnci5uYW1lICE9PSAnTHVjcm8gQW50ZXMgZGFzIFJlY2VpdGFzIGUgRGVzcGVzYXMgRmluYW5jZWlyYXMnKSBhcyBJTmF2TGlua1tdLFxyXG4gICAgfSxcclxuICBdLCBbZGlzYWJsZVRhYnMsIGlzR3JvdXBFeHBhbmRlZCwgcGF0aG5hbWUsIGdyb3VwXSlcclxuXHJcbiAgY29uc3QgcGVybWlzc2lvbk5hdiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRHcm91cDogSU5hdkxpbmtHcm91cFtdID0gWy4uLm5hdkxpbmtHcm91cHNdXHJcbiAgICBmaWx0ZXJlZEdyb3VwLmZvckVhY2goKGdyLCBpbmRleCkgPT4ge1xyXG4gICAgICBmaWx0ZXJlZEdyb3VwW2luZGV4XS5saW5rcyA9IGdyLmxpbmtzPy5maWx0ZXIobmF2TGluayA9PiBoYXNQZXJtaXNzaW9uKG5hdkxpbmsucGVybWlzc2lvbiBhcyBzZXJ2aWNlQ29kZXMsICdWaXN1YWxpemFyJykpXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGZpbHRlcmVkR3JvdXBcclxuICB9LCBbbmF2TGlua0dyb3Vwc10pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGV2PzogTW91c2VFdmVudCwgaXRlbT86IElOYXZMaW5rKSA9PiB7XHJcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgZXYucHJldmVudERlZmF1bHQoKVxyXG4gICAgICBpZiAoaXRlbS5saW5rcykge1xyXG4gICAgICAgIHNldElzR3JvdXBFeHBhbmRlZCghaXNHcm91cEV4cGFuZGVkKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdmVyaWZ5U2l0dWF0aW9uID0gYXVkaXQ/LmVtcHJlc2FzLnNvbWUoZW1wcmVzYSA9PiBlbXByZXNhLnNpdHVhY2FvUmV2aXNhbyA9PT0gKDAgfCAxKSkgYXMgYm9vbGVhblxyXG4gICAgc2V0RGlzYWJsZVRhYnModmVyaWZ5U2l0dWF0aW9uIHx8IGF1ZGl0Py5zaXR1YWNhbyA9PT0gMClcclxuICB9LCBbYXVkaXRdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNpZGVNZW51XHJcbiAgICAgIHRpdGxlPSdUZXN0ZXMgZGUgY29udGFzIGRlIHJlc3VsdGFkb3MnXHJcbiAgICAgIGRpc2FibGVkQ29sbGFwc2VcclxuICAgICAgc3VidGl0bGU9e1xyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICBocmVmPXtcclxuICAgICAgICAgICAgYC9hZG1pbi9jbGllbnRzLyR7YXVkaXQ/LmNvbnRyYXRvPy5jbGllbnRlSWR9L2NvbnRyYWN0cy8ke1xyXG4gICAgICAgICAgICAgIGF1ZGl0Py5jb250cmF0bz8uY29udHJhdG9QcmluY2lwYWxJZFxyXG4gICAgICAgICAgICAgICAgPyBgJHthdWRpdD8uY29udHJhdG8uY29udHJhdG9QcmluY2lwYWxJZH0/c3ViY29udHJhY3Q9JHthdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhfWBcclxuICAgICAgICAgICAgICAgIDogYXVkaXQ/LmNvbnRyYXRvPy5pZFxyXG4gICAgICAgICAgICB9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGFyZ2V0PVwiYmxhbmtcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogZm9udFdlaWdodC5zZW1pYm9sZCxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250U2l6ZS5wMTQsXHJcbiAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogc3BhY2luZy5sZyxcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAyMDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IHNwYWNpbmcubWQsXHJcbiAgICAgICAgICAgICAgICAnOjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2F1ZGl0Py5jb250cmF0bz8ubm9tZUZhbnRhc2lhfSAtIHtmb3JtYXRQcm9wb3NhbE51bWJlcihhdWRpdD8uY29udHJhdG8/Lm51bWVyb1Byb3Bvc3RhIGFzIHN0cmluZyl9XHJcbiAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICB9XHJcbiAgICAgIGdyb3Vwcz17cGVybWlzc2lvbk5hdn1cclxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBnb0JhY2s9eygpID0+IG5hdmlnYXRlKGAvYXVkaXQvYXVkaXRzLyR7YXVkaXQ/LmlkfS9jb250cm9sLXBhbmVsL2FuYWx5c2lzL2Rhc2hib2FyZGApfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1ZGl0UmVzdWx0c1Rlc3RpbmdTaWRlTWVudVxyXG4iXX0=