export default function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return hash;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhhc2hDb2RlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhc2hDb2RlIChzdHI6IHN0cmluZyk6IG51bWJlciB7XG4gIGxldCBoYXNoID0gMFxuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIGhhc2ggPSBzdHIuY2hhckNvZGVBdChpKSArICgoaGFzaCA8PCA1KSAtIGhhc2gpXG4gIH1cbiAgcmV0dXJuIGhhc2hcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLFNBQVUsS0FBcUI7QUFDckQsTUFBSSxPQUFPO0FBQ1gsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztBQUNuQyxXQUFPLElBQUksV0FBVyxDQUFDLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDNUM7QUFDQSxTQUFPO0FBQ1Q7IiwibmFtZXMiOltdfQ==