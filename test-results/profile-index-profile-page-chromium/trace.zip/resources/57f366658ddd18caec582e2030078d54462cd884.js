import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Label } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import ChoiceGroup from "/src/shared/components/choiceGroup/ChoiceGroup.tsx";
import { FlexColumn, FlexRow } from "/src/shared/components/FlexBox/index.ts";
const BooleanChoiceGroup = (props) => {
  const {
    label,
    selectedBoolKey,
    setSelectedBoolKey
  } = props;
  const handleChangeValue = (option) => {
    setSelectedBoolKey(option.key === "true");
  };
  return /* @__PURE__ */ jsxDEV(FlexColumn, { children: [
    /* @__PURE__ */ jsxDEV(Label, { children: label }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexRow, { children: /* @__PURE__ */ jsxDEV(ChoiceGroup, { selectedKey: selectedBoolKey?.toString(), onChange: (_, option) => handleChangeValue(option), styles: {
      flexContainer: {
        display: "flex",
        flexDirection: "row",
        gap: 30
      }
    }, options: [{
      key: "true",
      text: "Sim"
    }, {
      key: "false",
      text: "Não"
    }], disabled: props.disabled }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_c = BooleanChoiceGroup;
export default BooleanChoiceGroup;
var _c;
$RefreshReg$(_c, "BooleanChoiceGroup");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/BooleanChoiceGroup.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNO0FBcEJOLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQWdEQSxhQUFhO0FBQzdELE9BQU9DLGlCQUFpQjtBQUN4QixTQUFTQyxZQUFZQyxlQUFlO0FBUXBDLE1BQU1DLHFCQUFrREMsV0FBVTtBQUNoRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBT0M7QUFBQUEsSUFBaUJDO0FBQUFBLEVBQW1CLElBQUlIO0FBRXZELFFBQU1JLG9CQUFvQkEsQ0FBQ0MsV0FBOEI7QUFDdkRGLHVCQUFtQkUsT0FBT0MsUUFBUSxNQUFNO0FBQUEsRUFDMUM7QUFFQSxTQUNFLHVCQUFDLGNBQ0M7QUFBQSwyQkFBQyxTQUFPTCxtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFdBQ0MsaUNBQUMsZUFDQyxhQUFhQyxpQkFBaUJLLFNBQVMsR0FDdkMsVUFBVSxDQUFDQyxHQUFHSCxXQUFXRCxrQkFBa0JDLE1BQTRCLEdBQ3ZFLFFBQVE7QUFBQSxNQUNOSSxlQUFlO0FBQUEsUUFDYkMsU0FBUztBQUFBLFFBQ1RDLGVBQWU7QUFBQSxRQUNmQyxLQUFLO0FBQUEsTUFDUDtBQUFBLElBQ0YsR0FDQSxTQUNFLENBQ0U7QUFBQSxNQUFFTixLQUFLO0FBQUEsTUFBUU8sTUFBTTtBQUFBLElBQU0sR0FDM0I7QUFBQSxNQUFFUCxLQUFLO0FBQUEsTUFBU08sTUFBTTtBQUFBLElBQU0sQ0FBQyxHQUdqQyxVQUFVYixNQUFNYyxZQWhCbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCMkIsS0FqQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ0MsS0FqQ0toQjtBQW1DTixlQUFlQTtBQUFrQixJQUFBZ0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxhYmVsIiwiQ2hvaWNlR3JvdXAiLCJGbGV4Q29sdW1uIiwiRmxleFJvdyIsIkJvb2xlYW5DaG9pY2VHcm91cCIsInByb3BzIiwibGFiZWwiLCJzZWxlY3RlZEJvb2xLZXkiLCJzZXRTZWxlY3RlZEJvb2xLZXkiLCJoYW5kbGVDaGFuZ2VWYWx1ZSIsIm9wdGlvbiIsImtleSIsInRvU3RyaW5nIiwiXyIsImZsZXhDb250YWluZXIiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsInRleHQiLCJkaXNhYmxlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQm9vbGVhbkNob2ljZUdyb3VwLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2Nob2ljZUdyb3VwL0Jvb2xlYW5DaG9pY2VHcm91cC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSUNob2ljZUdyb3VwT3B0aW9uLCBJQ2hvaWNlR3JvdXBQcm9wcywgTGFiZWwgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgQ2hvaWNlR3JvdXAgZnJvbSAnLi9DaG9pY2VHcm91cCdcbmltcG9ydCB7IEZsZXhDb2x1bW4sIEZsZXhSb3cgfSBmcm9tICcuLi9GbGV4Qm94J1xuXG5pbnRlcmZhY2UgQm9vbGVhbkNob2ljZUdyb3VwUHJvcHMgZXh0ZW5kcyBJQ2hvaWNlR3JvdXBQcm9wcyB7XG4gIGxhYmVsPzogc3RyaW5nXG4gIHNlbGVjdGVkQm9vbEtleTpib29sZWFuXG4gIHNldFNlbGVjdGVkQm9vbEtleToodmFsdWU6IGJvb2xlYW4pID0+IHZvaWRcbn1cblxuY29uc3QgQm9vbGVhbkNob2ljZUdyb3VwOkZDPEJvb2xlYW5DaG9pY2VHcm91cFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGxhYmVsLCBzZWxlY3RlZEJvb2xLZXksIHNldFNlbGVjdGVkQm9vbEtleSB9ID0gcHJvcHNcblxuICBjb25zdCBoYW5kbGVDaGFuZ2VWYWx1ZSA9IChvcHRpb246SUNob2ljZUdyb3VwT3B0aW9uKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRCb29sS2V5KG9wdGlvbi5rZXkgPT09ICd0cnVlJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW4+XG4gICAgICA8TGFiZWw+e2xhYmVsfTwvTGFiZWw+XG4gICAgICA8RmxleFJvdz5cbiAgICAgICAgPENob2ljZUdyb3VwXG4gICAgICAgICAgc2VsZWN0ZWRLZXk9e3NlbGVjdGVkQm9vbEtleT8udG9TdHJpbmcoKX1cbiAgICAgICAgICBvbkNoYW5nZT17KF8sIG9wdGlvbikgPT4gaGFuZGxlQ2hhbmdlVmFsdWUob3B0aW9uIGFzIElDaG9pY2VHcm91cE9wdGlvbil9XG4gICAgICAgICAgc3R5bGVzPXt7XG4gICAgICAgICAgICBmbGV4Q29udGFpbmVyOiB7XG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gICAgICAgICAgICAgIGdhcDogMzAsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH19XG4gICAgICAgICAgb3B0aW9ucz17XG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIHsga2V5OiAndHJ1ZScsIHRleHQ6ICdTaW0nIH0sXG4gICAgICAgICAgICAgIHsga2V5OiAnZmFsc2UnLCB0ZXh0OiAnTsOjbycgfSxcbiAgICAgICAgICAgIF1cbiAgICAgICAgICB9XG4gICAgICAgICAgZGlzYWJsZWQ9e3Byb3BzLmRpc2FibGVkfVxuICAgICAgICAvPlxuXG4gICAgICA8L0ZsZXhSb3c+XG4gICAgPC9GbGV4Q29sdW1uPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJvb2xlYW5DaG9pY2VHcm91cFxuIl19