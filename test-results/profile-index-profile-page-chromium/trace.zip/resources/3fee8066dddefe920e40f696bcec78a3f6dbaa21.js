import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/FlexBox/FlexRow.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexRow.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const FlexRow = (props) => {
  const {
    children,
    width,
    height,
    background,
    wrap = "wrap",
    verticalAlign,
    horizontalAlign,
    gap,
    columnGap,
    rowGap,
    margin,
    padding,
    grow,
    styles,
    className,
    onClick,
    ...rest
  } = props;
  return /* @__PURE__ */ jsxDEV("div", { style: {
    display: "flex",
    flexDirection: "row",
    margin,
    padding,
    width,
    height,
    background,
    flexWrap: wrap,
    alignItems: verticalAlign,
    justifyContent: horizontalAlign,
    gap,
    columnGap: columnGap || gap,
    rowGap: rowGap || gap,
    flexGrow: grow,
    ...styles
  }, className, onClick, ...rest, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexRow.tsx",
    lineNumber: 44,
    columnNumber: 10
  }, this);
};
_c = FlexRow;
export default FlexRow;
var _c;
$RefreshReg$(_c, "FlexRow");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NJO0FBL0NKLDJCQUEwQjtBQUFrQkE7QUFBaUIsSUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5QnBFLE1BQU1DLFVBQTZCQyxXQUFVO0FBQzNDLFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxPQUFPO0FBQUEsSUFDUEM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQSxHQUFHQztBQUFBQSxFQUNMLElBQUlqQjtBQUVKLFNBQ0UsdUJBQUMsU0FDQyxPQUFPO0FBQUEsSUFDTGtCLFNBQVM7QUFBQSxJQUNUQyxlQUFlO0FBQUEsSUFDZlI7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQVY7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQWdCLFVBQVVmO0FBQUFBLElBQ1ZnQixZQUFZZjtBQUFBQSxJQUNaZ0IsZ0JBQWdCZjtBQUFBQSxJQUNoQkM7QUFBQUEsSUFDQUMsV0FBV0EsYUFBYUQ7QUFBQUEsSUFDeEJFLFFBQVFBLFVBQVVGO0FBQUFBLElBQ2xCZSxVQUFVVjtBQUFBQSxJQUNWLEdBQUdDO0FBQUFBLEVBQ0wsR0FDQSxXQUNBLFNBQ0EsR0FBSUcsTUFFSGhCLFlBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFDdUIsS0EvQ0t6QjtBQWlETixlQUFlQTtBQUFPLElBQUF5QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3ROb2RlIiwiRmxleFJvdyIsInByb3BzIiwiY2hpbGRyZW4iLCJ3aWR0aCIsImhlaWdodCIsImJhY2tncm91bmQiLCJ3cmFwIiwidmVydGljYWxBbGlnbiIsImhvcml6b250YWxBbGlnbiIsImdhcCIsImNvbHVtbkdhcCIsInJvd0dhcCIsIm1hcmdpbiIsInBhZGRpbmciLCJncm93Iiwic3R5bGVzIiwiY2xhc3NOYW1lIiwib25DbGljayIsInJlc3QiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhXcmFwIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZmxleEdyb3ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZsZXhSb3cudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRmxleEJveC9GbGV4Um93LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENTU1Byb3BlcnRpZXMsIEZDLCBIVE1MQXR0cmlidXRlcywgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIEFsaWduSXRlbnMgPSAnc3RyZXRjaCcgfCAnZmxleC1zdGFydCcgfCAnZmxleC1lbmQnIHwgJ2NlbnRlcicgfCAnYmFzZWxpbmUnIHwgJ3NwYWNlLWJldHdlZW4nIHwgJ3NwYWNlLWFyb3VuZCcgfCAnc3BhY2UtZXZlbmx5J1xyXG50eXBlIEp1c3RpZnlDb250ZW50ID0gJ2ZsZXgtc3RhcnQnIHwgJ2ZsZXgtZW5kJyB8ICdjZW50ZXInIHwgJ3NwYWNlLWJldHdlZW4nIHwgJ3NwYWNlLWFyb3VuZCcgfCAnc3BhY2UtZXZlbmx5J1xyXG50eXBlIFdyYXAgPSAnbm93cmFwJyB8ICd3cmFwJyB8ICd3cmFwLXJldmVyc2UnXHJcbnR5cGUgU2V0RmxleCA9ICdpbmhlcml0JyB8ICdpbml0aWFsJyB8ICdyZXZlcnQnIHwgJ3Vuc2V0J1xyXG5pbnRlcmZhY2UgSUZsZXhSb3dQcm9wcyBleHRlbmRzIEhUTUxBdHRyaWJ1dGVzPEhUTUxEaXZFbGVtZW50PiB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZVxyXG4gIHdpZHRoPzogbnVtYmVyIHwgc3RyaW5nXHJcbiAgaGVpZ2h0PzogbnVtYmVyIHwgc3RyaW5nXHJcbiAgYmFja2dyb3VuZD86IHN0cmluZ1xyXG4gIHdyYXA/OiBXcmFwXHJcbiAgdmVydGljYWxBbGlnbj86IEFsaWduSXRlbnNcclxuICBob3Jpem9udGFsQWxpZ24/OiBKdXN0aWZ5Q29udGVudFxyXG4gIGdhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIGNvbHVtbkdhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIHJvd0dhcD86IHN0cmluZyB8IG51bWJlclxyXG4gIG1hcmdpbj86IG51bWJlciB8IHN0cmluZ1xyXG4gIHBhZGRpbmc/OiBudW1iZXIgfCBzdHJpbmdcclxuICBncm93PzogbnVtYmVyIHwgU2V0RmxleFxyXG4gIHN0eWxlcz86IENTU1Byb3BlcnRpZXNcclxuICBjbGFzc05hbWU/OiBzdHJpbmdcclxuICBvbkNsaWNrPzogKCkgPT4gdm9pZFxyXG59XHJcblxyXG5jb25zdCBGbGV4Um93OkZDPElGbGV4Um93UHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qge1xyXG4gICAgY2hpbGRyZW4sXHJcbiAgICB3aWR0aCxcclxuICAgIGhlaWdodCxcclxuICAgIGJhY2tncm91bmQsXHJcbiAgICB3cmFwID0gJ3dyYXAnLFxyXG4gICAgdmVydGljYWxBbGlnbixcclxuICAgIGhvcml6b250YWxBbGlnbixcclxuICAgIGdhcCxcclxuICAgIGNvbHVtbkdhcCxcclxuICAgIHJvd0dhcCxcclxuICAgIG1hcmdpbixcclxuICAgIHBhZGRpbmcsXHJcbiAgICBncm93LFxyXG4gICAgc3R5bGVzLFxyXG4gICAgY2xhc3NOYW1lLFxyXG4gICAgb25DbGljayxcclxuICAgIC4uLnJlc3RcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgc3R5bGU9e3tcclxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ3JvdycsXHJcbiAgICAgICAgbWFyZ2luOiBtYXJnaW4sXHJcbiAgICAgICAgcGFkZGluZzogcGFkZGluZyxcclxuICAgICAgICB3aWR0aDogd2lkdGgsXHJcbiAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXHJcbiAgICAgICAgYmFja2dyb3VuZDogYmFja2dyb3VuZCxcclxuICAgICAgICBmbGV4V3JhcDogd3JhcCxcclxuICAgICAgICBhbGlnbkl0ZW1zOiB2ZXJ0aWNhbEFsaWduLFxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50OiBob3Jpem9udGFsQWxpZ24sXHJcbiAgICAgICAgZ2FwOiBnYXAsXHJcbiAgICAgICAgY29sdW1uR2FwOiBjb2x1bW5HYXAgfHwgZ2FwLFxyXG4gICAgICAgIHJvd0dhcDogcm93R2FwIHx8IGdhcCxcclxuICAgICAgICBmbGV4R3JvdzogZ3JvdyxcclxuICAgICAgICAuLi5zdHlsZXMsXHJcbiAgICAgIH19XHJcbiAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxyXG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxyXG4gICAgICB7Li4ucmVzdH1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGbGV4Um93XHJcbiJdfQ==