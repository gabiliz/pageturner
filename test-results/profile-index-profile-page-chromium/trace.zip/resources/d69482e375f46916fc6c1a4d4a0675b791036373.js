import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/filter/FilterInputSearch.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Callout, CommandButton, Label, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean, useId } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useContext = __vite__cjsImport5_react["useContext"]; const useMemo = __vite__cjsImport5_react["useMemo"]; const useState = __vite__cjsImport5_react["useState"];
import { useTheme } from "/src/shared/hooks/index.ts";
import { PrimaryButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import { FlexRow } from "/src/shared/components/FlexBox/index.ts";
import { TextField } from "/src/shared/components/inputs/index.ts?t=1701096626433";
import { Tag } from "/src/shared/components/tag/index.ts";
import { filterGroupContext } from "/src/shared/components/filter/filterGroupContext.ts";
const FilterInputSearch = ({
  group
}) => {
  _s();
  const {
    handleItemsChange,
    handleRemoveItem
  } = useContext(filterGroupContext);
  const [isCalloutVisible, {
    toggle: toggleIsCalloutVisible
  }] = useBoolean(false);
  const filterId = useId(group.filterGroupName.replace(/ /g, "_"));
  const [textItem, setTextItem] = useState("");
  const theme = useTheme();
  const filterStyles = useFilterStyles(group.color);
  const hasActiveItems = useMemo(() => {
    return group.items.length > 0;
  }, [group]);
  const activeItemsCount = useMemo(() => {
    return group.items.length;
  }, [group]);
  const handleAddItem = useCallback((newItemText) => {
    const itemToAdd = newItemText.trim();
    const alreadyHasItem = group.items.some((item) => item.key === itemToAdd);
    if (!alreadyHasItem) {
      const newItem = {
        key: itemToAdd,
        text: itemToAdd
      };
      const newFilterGroup = {
        ...group,
        items: [...group.items, newItem]
      };
      handleItemsChange(newFilterGroup);
      setTextItem("");
    }
  }, [group, handleItemsChange]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Label, { id: filterId, disabled: group.disabled, styles: {
      root: {
        padding: 0,
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        fontSize: theme.fontSize.p14,
        fontWeight: hasActiveItems ? theme.fontWeight.semibold : theme.fontWeight.regular,
        color: theme.colors.gray[600],
        "&:hover": {
          backgroundColor: theme.colors.gray[200]
        },
        gridGap: theme.spacing.xs,
        display: "flex"
      }
    }, children: [
      /* @__PURE__ */ jsxDEV("span", { children: group.filterGroupName }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      activeItemsCount > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "(",
          activeItemsCount,
          ")"
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
          lineNumber: 73,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: filterStyles.circle }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 72,
        columnNumber: 34
      }, this),
      /* @__PURE__ */ jsxDEV(CommandButton, { styles: {
        root: {
          padding: 0
        }
      }, disabled: group?.disabled, iconProps: {
        iconName: "ChevronDown",
        styles: {
          root: {
            fontSize: theme.fontSize.xs,
            height: theme.fontSize.xs,
            lineHeight: "auto"
          }
        }
      }, onClick: toggleIsCalloutVisible }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    isCalloutVisible && /* @__PURE__ */ jsxDEV(Callout, { onDismiss: toggleIsCalloutVisible, isBeakVisible: false, role: "dialog", target: `#${filterId}`, styles: {
      calloutMain: {
        padding: theme.spacing.lg,
        display: "flex",
        flexDirection: "column",
        maxWidth: 300
      }
    }, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: `${group.filterGroupName}` }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 101,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.sm, children: [
        /* @__PURE__ */ jsxDEV(TextField, { value: textItem, onChange: (e) => setTextItem(e.currentTarget.value), maxLength: 30 }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
          lineNumber: 103,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(PrimaryButton, { onClick: () => handleAddItem(textItem), disabled: textItem.trim() === "", styles: {
          root: {
            minWidth: "32px"
          }
        }, iconProps: {
          iconName: "StatusCircleCheckmark",
          styles: {
            root: {
              fontSize: theme.fontSize.h4,
              margin: 0
            }
          }
        } }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
          lineNumber: 104,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 102,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(FlexRow, { padding: "8px 0 0 0", wrap: "wrap", gap: theme.spacing.xs, children: group.items.map((item) => {
        return /* @__PURE__ */ jsxDEV(Tag, { text: item.text, color: theme.colors.purple[800], backgroundColor: group.color ? group.color : theme.colors.purple[200], onClick: () => handleRemoveItem(group, item.key), onRemove: () => handleRemoveItem(group, item.key) }, item.key, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
          lineNumber: 120,
          columnNumber: 18
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
        lineNumber: 118,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
      lineNumber: 93,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx",
    lineNumber: 53,
    columnNumber: 10
  }, this);
};
_s(FilterInputSearch, "WgaZS2pcn6ymDn7p3KDlkM9Fhfg=", false, function() {
  return [useBoolean, useId, useTheme, useFilterStyles];
});
_c = FilterInputSearch;
const useFilterStyles = (groupColor) => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    circle: {
      display: "inline-block",
      paddingLeft: theme.spacing.xs,
      width: 8,
      height: 8,
      borderRadius: "50%",
      backgroundColor: groupColor || theme.colors.purple[500]
    }
  });
};
_s2(useFilterStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default FilterInputSearch;
var _c;
$RefreshReg$(_c, "FilterInputSearch");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0ZRLFNBR0EsVUFIQTs7Ozs7Ozs7Ozs7Ozs7OztBQWhGUixTQUFTQSxTQUFTQyxlQUFlQyxPQUFPQyxzQkFBc0I7QUFDOUQsU0FBU0MsWUFBWUMsYUFBYTtBQUNsQyxTQUFhQyxhQUFhQyxZQUFZQyxTQUFTQyxnQkFBZ0I7QUFDL0QsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxXQUFXO0FBQ3BCLFNBQVNDLDBCQUEwQjtBQU9uQyxNQUFNQyxvQkFBaURBLENBQUM7QUFBQSxFQUFFQztBQUFNLE1BQU07QUFBQUMsS0FBQTtBQUNwRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBbUJDO0FBQUFBLEVBQWlCLElBQUliLFdBQVdRLGtCQUFrQjtBQUU3RSxRQUFNLENBQUNNLGtCQUFrQjtBQUFBLElBQUVDLFFBQVFDO0FBQUFBLEVBQXVCLENBQUMsSUFBSW5CLFdBQVcsS0FBSztBQUMvRSxRQUFNb0IsV0FBV25CLE1BQU1ZLE1BQU1RLGdCQUFnQkMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUMvRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSW5CLFNBQWlCLEVBQUU7QUFFbkQsUUFBTW9CLFFBQVFuQixTQUFTO0FBQ3ZCLFFBQU1vQixlQUFlQyxnQkFBZ0JkLE1BQU1lLEtBQUs7QUFFaEQsUUFBTUMsaUJBQWlCekIsUUFBUSxNQUFNO0FBQ25DLFdBQU9TLE1BQU1pQixNQUFNQyxTQUFTO0FBQUEsRUFDOUIsR0FBRyxDQUFDbEIsS0FBSyxDQUFDO0FBRVYsUUFBTW1CLG1CQUFtQjVCLFFBQVEsTUFBTTtBQUNyQyxXQUFPUyxNQUFNaUIsTUFBTUM7QUFBQUEsRUFDckIsR0FBRyxDQUFDbEIsS0FBSyxDQUFDO0FBRVYsUUFBTW9CLGdCQUFnQi9CLFlBQVksQ0FBQ2dDLGdCQUF3QjtBQUN6RCxVQUFNQyxZQUFZRCxZQUFZRSxLQUFLO0FBRW5DLFVBQU1DLGlCQUFpQnhCLE1BQU1pQixNQUFNUSxLQUFNQyxVQUFTQSxLQUFLQyxRQUFRTCxTQUFTO0FBRXhFLFFBQUksQ0FBQ0UsZ0JBQWdCO0FBQ25CLFlBQU1JLFVBQVU7QUFBQSxRQUNkRCxLQUFLTDtBQUFBQSxRQUNMTyxNQUFNUDtBQUFBQSxNQUNSO0FBRUEsWUFBTVEsaUJBQStCO0FBQUEsUUFDbkMsR0FBRzlCO0FBQUFBLFFBQ0hpQixPQUFPLENBQ0wsR0FBR2pCLE1BQU1pQixPQUNUVyxPQUFPO0FBQUEsTUFFWDtBQUVBMUIsd0JBQWtCNEIsY0FBYztBQUNoQ25CLGtCQUFZLEVBQUU7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsR0FBRyxDQUFDWCxPQUFPRSxpQkFBaUIsQ0FBQztBQUU3QixTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FDQyxJQUFJSyxVQUNKLFVBQVVQLE1BQU0rQixVQUNoQixRQUFRO0FBQUEsTUFDTkMsTUFBTTtBQUFBLFFBQ0pDLFNBQVM7QUFBQSxRQUNUQyxZQUFZO0FBQUEsUUFDWkMsZ0JBQWdCO0FBQUEsUUFDaEJDLFFBQVE7QUFBQSxRQUNSQyxVQUFVekIsTUFBTXlCLFNBQVNDO0FBQUFBLFFBQ3pCQyxZQUFZdkIsaUJBQWlCSixNQUFNMkIsV0FBV0MsV0FBVzVCLE1BQU0yQixXQUFXRTtBQUFBQSxRQUMxRTFCLE9BQU9ILE1BQU04QixPQUFPQyxLQUFLLEdBQUc7QUFBQSxRQUM1QixXQUFXO0FBQUEsVUFDVEMsaUJBQWlCaEMsTUFBTThCLE9BQU9DLEtBQUssR0FBRztBQUFBLFFBQ3hDO0FBQUEsUUFDQUUsU0FBU2pDLE1BQU1rQyxRQUFRQztBQUFBQSxRQUN2QkMsU0FBUztBQUFBLE1BQ1g7QUFBQSxJQUNGLEdBR0E7QUFBQSw2QkFBQyxVQUFNaEQsZ0JBQU1RLG1CQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUU1QlcsbUJBQW1CLEtBQ3BCLG1DQUNFO0FBQUEsK0JBQUMsVUFBSztBQUFBO0FBQUEsVUFBRUE7QUFBQUEsVUFBaUI7QUFBQSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsUUFDMUIsdUJBQUMsVUFBSyxXQUFXTixhQUFhb0MsVUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFdBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0EsdUJBQUMsaUJBQ0MsUUFBUTtBQUFBLFFBQUVqQixNQUFNO0FBQUEsVUFBRUMsU0FBUztBQUFBLFFBQUU7QUFBQSxNQUFFLEdBQy9CLFVBQVVqQyxPQUFPK0IsVUFDakIsV0FBVztBQUFBLFFBQ1RtQixVQUFVO0FBQUEsUUFDVkMsUUFBUTtBQUFBLFVBQ05uQixNQUFNO0FBQUEsWUFDSkssVUFBVXpCLE1BQU15QixTQUFTVTtBQUFBQSxZQUN6QkssUUFBUXhDLE1BQU15QixTQUFTVTtBQUFBQSxZQUN2Qk0sWUFBWTtBQUFBLFVBQ2Q7QUFBQSxRQUNGO0FBQUEsTUFDRixHQUNBLFNBQVMvQywwQkFiWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYWtDO0FBQUEsU0EzQ3BDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2Q0E7QUFBQSxJQUVDRixvQkFDQyx1QkFBQyxXQUNDLFdBQVdFLHdCQUNYLGVBQWUsT0FDZixNQUFLLFVBQ0wsUUFBUyxJQUFHQyxZQUNaLFFBQVE7QUFBQSxNQUNOK0MsYUFBYTtBQUFBLFFBQ1hyQixTQUFTckIsTUFBTWtDLFFBQVFTO0FBQUFBLFFBQ3ZCUCxTQUFTO0FBQUEsUUFDVFEsZUFBZTtBQUFBLFFBQ2ZDLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixHQUVBO0FBQUEsNkJBQUMsU0FBUSxhQUFFekQsTUFBTVEscUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUNuQyx1QkFBQyxXQUFRLEtBQUtJLE1BQU1rQyxRQUFRWSxJQUMxQjtBQUFBLCtCQUFDLGFBQ0MsT0FBT2hELFVBQ1AsVUFBV2lELE9BQU1oRCxZQUFZZ0QsRUFBRUMsY0FBY0MsS0FBSyxHQUNsRCxXQUFXLE1BSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdnQjtBQUFBLFFBRWhCLHVCQUFDLGlCQUNDLFNBQVMsTUFBTXpDLGNBQWNWLFFBQVEsR0FDckMsVUFBVUEsU0FBU2EsS0FBSyxNQUFNLElBQzlCLFFBQVE7QUFBQSxVQUNOUyxNQUFNO0FBQUEsWUFDSjhCLFVBQVU7QUFBQSxVQUNaO0FBQUEsUUFDRixHQUNBLFdBQVc7QUFBQSxVQUNUWixVQUFVO0FBQUEsVUFDVkMsUUFBUTtBQUFBLFlBQ05uQixNQUFNO0FBQUEsY0FDSkssVUFBVXpCLE1BQU15QixTQUFTMEI7QUFBQUEsY0FDekJDLFFBQVE7QUFBQSxZQUNWO0FBQUEsVUFDRjtBQUFBLFFBQ0YsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCSTtBQUFBLFdBdEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxNQUNBLHVCQUFDLFdBQVEsU0FBUSxhQUFZLE1BQUssUUFBTyxLQUFLcEQsTUFBTWtDLFFBQVFDLElBQ3pEL0MsZ0JBQU1pQixNQUFNZ0QsSUFBSXZDLFVBQVE7QUFDdkIsZUFDRSx1QkFBQyxPQUVDLE1BQU1BLEtBQUtHLE1BQ1gsT0FBT2pCLE1BQU04QixPQUFPd0IsT0FBTyxHQUFHLEdBQzlCLGlCQUFpQmxFLE1BQU1lLFFBQVFmLE1BQU1lLFFBQVFILE1BQU04QixPQUFPd0IsT0FBTyxHQUFHLEdBQ3BFLFNBQVMsTUFBTS9ELGlCQUFpQkgsT0FBTzBCLEtBQUtDLEdBQUcsR0FDL0MsVUFBVSxNQUFNeEIsaUJBQWlCSCxPQUFPMEIsS0FBS0MsR0FBRyxLQUwzQ0QsS0FBS0MsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTW9EO0FBQUEsTUFHeEQsQ0FBQyxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzREE7QUFBQSxPQXZHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUdBO0FBRUo7QUFBQzFCLEdBdEpLRixtQkFBOEM7QUFBQSxVQUdhWixZQUM5Q0MsT0FHSEssVUFDT3FCLGVBQWU7QUFBQTtBQUFBcUQsS0FSaENwRTtBQXdKTixNQUFNZSxrQkFBa0JBLENBQUNzRCxlQUFtQztBQUFBQyxNQUFBO0FBQzFELFFBQU16RCxRQUFRbkIsU0FBUztBQUV2QixTQUFPUCxlQUFlO0FBQUEsSUFDcEIrRCxRQUFRO0FBQUEsTUFDTkQsU0FBUztBQUFBLE1BQ1RzQixhQUFhMUQsTUFBTWtDLFFBQVFDO0FBQUFBLE1BQzNCd0IsT0FBTztBQUFBLE1BQ1BuQixRQUFRO0FBQUEsTUFDUm9CLGNBQWM7QUFBQSxNQUNkNUIsaUJBQWlCd0IsY0FBY3hELE1BQU04QixPQUFPd0IsT0FBTyxHQUFHO0FBQUEsSUFDeEQ7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDRyxJQWJLdkQsaUJBQWU7QUFBQSxVQUNMckIsUUFBUTtBQUFBO0FBY3hCLGVBQWVNO0FBQWlCLElBQUFvRTtBQUFBTSxhQUFBTixJQUFBIiwibmFtZXMiOlsiQ2FsbG91dCIsIkNvbW1hbmRCdXR0b24iLCJMYWJlbCIsIm1lcmdlU3R5bGVTZXRzIiwidXNlQm9vbGVhbiIsInVzZUlkIiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlVGhlbWUiLCJQcmltYXJ5QnV0dG9uIiwiRmxleFJvdyIsIlRleHRGaWVsZCIsIlRhZyIsImZpbHRlckdyb3VwQ29udGV4dCIsIkZpbHRlcklucHV0U2VhcmNoIiwiZ3JvdXAiLCJfcyIsImhhbmRsZUl0ZW1zQ2hhbmdlIiwiaGFuZGxlUmVtb3ZlSXRlbSIsImlzQ2FsbG91dFZpc2libGUiLCJ0b2dnbGUiLCJ0b2dnbGVJc0NhbGxvdXRWaXNpYmxlIiwiZmlsdGVySWQiLCJmaWx0ZXJHcm91cE5hbWUiLCJyZXBsYWNlIiwidGV4dEl0ZW0iLCJzZXRUZXh0SXRlbSIsInRoZW1lIiwiZmlsdGVyU3R5bGVzIiwidXNlRmlsdGVyU3R5bGVzIiwiY29sb3IiLCJoYXNBY3RpdmVJdGVtcyIsIml0ZW1zIiwibGVuZ3RoIiwiYWN0aXZlSXRlbXNDb3VudCIsImhhbmRsZUFkZEl0ZW0iLCJuZXdJdGVtVGV4dCIsIml0ZW1Ub0FkZCIsInRyaW0iLCJhbHJlYWR5SGFzSXRlbSIsInNvbWUiLCJpdGVtIiwia2V5IiwibmV3SXRlbSIsInRleHQiLCJuZXdGaWx0ZXJHcm91cCIsImRpc2FibGVkIiwicm9vdCIsInBhZGRpbmciLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJjdXJzb3IiLCJmb250U2l6ZSIsInAxNCIsImZvbnRXZWlnaHQiLCJzZW1pYm9sZCIsInJlZ3VsYXIiLCJjb2xvcnMiLCJncmF5IiwiYmFja2dyb3VuZENvbG9yIiwiZ3JpZEdhcCIsInNwYWNpbmciLCJ4cyIsImRpc3BsYXkiLCJjaXJjbGUiLCJpY29uTmFtZSIsInN0eWxlcyIsImhlaWdodCIsImxpbmVIZWlnaHQiLCJjYWxsb3V0TWFpbiIsImxnIiwiZmxleERpcmVjdGlvbiIsIm1heFdpZHRoIiwic20iLCJlIiwiY3VycmVudFRhcmdldCIsInZhbHVlIiwibWluV2lkdGgiLCJoNCIsIm1hcmdpbiIsIm1hcCIsInB1cnBsZSIsIl9jIiwiZ3JvdXBDb2xvciIsIl9zMiIsInBhZGRpbmdMZWZ0Iiwid2lkdGgiLCJib3JkZXJSYWRpdXMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaWx0ZXJJbnB1dFNlYXJjaC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9maWx0ZXIvRmlsdGVySW5wdXRTZWFyY2gudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2FsbG91dCwgQ29tbWFuZEJ1dHRvbiwgTGFiZWwsIG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VCb29sZWFuLCB1c2VJZCB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcclxuaW1wb3J0IHsgRkMsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xyXG5pbXBvcnQgeyBQcmltYXJ5QnV0dG9uIH0gZnJvbSAnLi4vYnV0dG9ucydcclxuaW1wb3J0IHsgRmxleFJvdyB9IGZyb20gJy4uL0ZsZXhCb3gnXHJcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gJy4uL2lucHV0cydcclxuaW1wb3J0IHsgVGFnIH0gZnJvbSAnLi4vdGFnJ1xyXG5pbXBvcnQgeyBmaWx0ZXJHcm91cENvbnRleHQgfSBmcm9tICcuL2ZpbHRlckdyb3VwQ29udGV4dCdcclxuaW1wb3J0IHsgSUZpbHRlckdyb3VwIH0gZnJvbSAnLi90eXBlcydcclxuXHJcbmludGVyZmFjZSBJRmlsdGVySW5wdXRTZWFyY2hQcm9wcyB7XHJcbiAgZ3JvdXA6IElGaWx0ZXJHcm91cFxyXG59XHJcblxyXG5jb25zdCBGaWx0ZXJJbnB1dFNlYXJjaDogRkM8SUZpbHRlcklucHV0U2VhcmNoUHJvcHM+ID0gKHsgZ3JvdXAgfSkgPT4ge1xyXG4gIGNvbnN0IHsgaGFuZGxlSXRlbXNDaGFuZ2UsIGhhbmRsZVJlbW92ZUl0ZW0gfSA9IHVzZUNvbnRleHQoZmlsdGVyR3JvdXBDb250ZXh0KVxyXG5cclxuICBjb25zdCBbaXNDYWxsb3V0VmlzaWJsZSwgeyB0b2dnbGU6IHRvZ2dsZUlzQ2FsbG91dFZpc2libGUgfV0gPSB1c2VCb29sZWFuKGZhbHNlKVxyXG4gIGNvbnN0IGZpbHRlcklkID0gdXNlSWQoZ3JvdXAuZmlsdGVyR3JvdXBOYW1lLnJlcGxhY2UoLyAvZywgJ18nKSlcclxuICBjb25zdCBbdGV4dEl0ZW0sIHNldFRleHRJdGVtXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpXHJcblxyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IGZpbHRlclN0eWxlcyA9IHVzZUZpbHRlclN0eWxlcyhncm91cC5jb2xvcilcclxuXHJcbiAgY29uc3QgaGFzQWN0aXZlSXRlbXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBncm91cC5pdGVtcy5sZW5ndGggPiAwXHJcbiAgfSwgW2dyb3VwXSlcclxuXHJcbiAgY29uc3QgYWN0aXZlSXRlbXNDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGdyb3VwLml0ZW1zLmxlbmd0aFxyXG4gIH0sIFtncm91cF0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZEl0ZW0gPSB1c2VDYWxsYmFjaygobmV3SXRlbVRleHQ6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgaXRlbVRvQWRkID0gbmV3SXRlbVRleHQudHJpbSgpXHJcblxyXG4gICAgY29uc3QgYWxyZWFkeUhhc0l0ZW0gPSBncm91cC5pdGVtcy5zb21lKChpdGVtKSA9PiBpdGVtLmtleSA9PT0gaXRlbVRvQWRkKVxyXG5cclxuICAgIGlmICghYWxyZWFkeUhhc0l0ZW0pIHtcclxuICAgICAgY29uc3QgbmV3SXRlbSA9IHtcclxuICAgICAgICBrZXk6IGl0ZW1Ub0FkZCxcclxuICAgICAgICB0ZXh0OiBpdGVtVG9BZGQsXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IG5ld0ZpbHRlckdyb3VwOiBJRmlsdGVyR3JvdXAgPSB7XHJcbiAgICAgICAgLi4uZ3JvdXAsXHJcbiAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgIC4uLmdyb3VwLml0ZW1zLFxyXG4gICAgICAgICAgbmV3SXRlbSxcclxuICAgICAgICBdLFxyXG4gICAgICB9XHJcblxyXG4gICAgICBoYW5kbGVJdGVtc0NoYW5nZShuZXdGaWx0ZXJHcm91cClcclxuICAgICAgc2V0VGV4dEl0ZW0oJycpXHJcbiAgICB9XHJcbiAgfSwgW2dyb3VwLCBoYW5kbGVJdGVtc0NoYW5nZV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TGFiZWxcclxuICAgICAgICBpZD17ZmlsdGVySWR9XHJcbiAgICAgICAgZGlzYWJsZWQ9e2dyb3VwLmRpc2FibGVkfVxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxyXG4gICAgICAgICAgICBjdXJzb3I6ICdwb2ludGVyJyxcclxuICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLnAxNCxcclxuICAgICAgICAgICAgZm9udFdlaWdodDogaGFzQWN0aXZlSXRlbXMgPyB0aGVtZS5mb250V2VpZ2h0LnNlbWlib2xkIDogdGhlbWUuZm9udFdlaWdodC5yZWd1bGFyLFxyXG4gICAgICAgICAgICBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgJyY6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb2xvcnMuZ3JheVsyMDBdLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBncmlkR2FwOiB0aGVtZS5zcGFjaW5nLnhzLFxyXG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcblxyXG4gICAgICA+XHJcbiAgICAgICAgPHNwYW4+e2dyb3VwLmZpbHRlckdyb3VwTmFtZX08L3NwYW4+XHJcblxyXG4gICAgICAgIHthY3RpdmVJdGVtc0NvdW50ID4gMCAmJlxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8c3Bhbj4oe2FjdGl2ZUl0ZW1zQ291bnR9KTwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17ZmlsdGVyU3R5bGVzLmNpcmNsZX0vPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgPENvbW1hbmRCdXR0b25cclxuICAgICAgICAgIHN0eWxlcz17eyByb290OiB7IHBhZGRpbmc6IDAgfSB9fVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2dyb3VwPy5kaXNhYmxlZH1cclxuICAgICAgICAgIGljb25Qcm9wcz17e1xyXG4gICAgICAgICAgICBpY29uTmFtZTogJ0NoZXZyb25Eb3duJyxcclxuICAgICAgICAgICAgc3R5bGVzOiB7XHJcbiAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLnhzLFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiB0aGVtZS5mb250U2l6ZS54cyxcclxuICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6ICdhdXRvJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUlzQ2FsbG91dFZpc2libGV9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9MYWJlbD5cclxuXHJcbiAgICAgIHtpc0NhbGxvdXRWaXNpYmxlICYmXHJcbiAgICAgICAgPENhbGxvdXRcclxuICAgICAgICAgIG9uRGlzbWlzcz17dG9nZ2xlSXNDYWxsb3V0VmlzaWJsZX1cclxuICAgICAgICAgIGlzQmVha1Zpc2libGU9e2ZhbHNlfVxyXG4gICAgICAgICAgcm9sZT1cImRpYWxvZ1wiXHJcbiAgICAgICAgICB0YXJnZXQ9e2AjJHtmaWx0ZXJJZH1gfVxyXG4gICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgIGNhbGxvdXRNYWluOiB7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogdGhlbWUuc3BhY2luZy5sZyxcclxuICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXHJcbiAgICAgICAgICAgICAgbWF4V2lkdGg6IDMwMCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPExhYmVsPntgJHtncm91cC5maWx0ZXJHcm91cE5hbWV9YH08L0xhYmVsPlxyXG4gICAgICAgICAgPEZsZXhSb3cgZ2FwPXt0aGVtZS5zcGFjaW5nLnNtfT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgIHZhbHVlPXt0ZXh0SXRlbX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRleHRJdGVtKGUuY3VycmVudFRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgbWF4TGVuZ3RoPXszMH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFByaW1hcnlCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRJdGVtKHRleHRJdGVtKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17dGV4dEl0ZW0udHJpbSgpID09PSAnJ31cclxuICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgICAgICAgbWluV2lkdGg6ICczMnB4JyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBpY29uUHJvcHM9e3tcclxuICAgICAgICAgICAgICAgIGljb25OYW1lOiAnU3RhdHVzQ2lyY2xlQ2hlY2ttYXJrJyxcclxuICAgICAgICAgICAgICAgIHN0eWxlczoge1xyXG4gICAgICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLmZvbnRTaXplLmg0LFxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvRmxleFJvdz5cclxuICAgICAgICAgIDxGbGV4Um93IHBhZGRpbmc9JzhweCAwIDAgMCcgd3JhcD0nd3JhcCcgZ2FwPXt0aGVtZS5zcGFjaW5nLnhzfT5cclxuICAgICAgICAgICAge2dyb3VwLml0ZW1zLm1hcChpdGVtID0+IHtcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxyXG4gICAgICAgICAgICAgICAgICB0ZXh0PXtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPXt0aGVtZS5jb2xvcnMucHVycGxlWzgwMF19XHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcj17Z3JvdXAuY29sb3IgPyBncm91cC5jb2xvciA6IHRoZW1lLmNvbG9ycy5wdXJwbGVbMjAwXX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlSXRlbShncm91cCwgaXRlbS5rZXkpfVxyXG4gICAgICAgICAgICAgICAgICBvblJlbW92ZT17KCkgPT4gaGFuZGxlUmVtb3ZlSXRlbShncm91cCwgaXRlbS5rZXkpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9GbGV4Um93PlxyXG4gICAgICAgIDwvQ2FsbG91dD5cclxuICAgICAgfVxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VGaWx0ZXJTdHlsZXMgPSAoZ3JvdXBDb2xvcjogc3RyaW5nIHwgdW5kZWZpbmVkKSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcblxyXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBjaXJjbGU6IHtcclxuICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXHJcbiAgICAgIHBhZGRpbmdMZWZ0OiB0aGVtZS5zcGFjaW5nLnhzLFxyXG4gICAgICB3aWR0aDogOCxcclxuICAgICAgaGVpZ2h0OiA4LFxyXG4gICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGdyb3VwQ29sb3IgfHwgdGhlbWUuY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGaWx0ZXJJbnB1dFNlYXJjaFxyXG4iXX0=