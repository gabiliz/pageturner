import {
  Async,
  getDocument,
  getId,
  on,
  useIsomorphicLayoutEffect,
  warn,
  warnConditionallyRequiredProps,
  warnControlledUsage,
  warnDeprecations,
  warnMutuallyExclusive
} from "/node_modules/.vite/deps/chunk-JYWLVXGS.js?v=9f90a7ff";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  __assign,
  __spreadArray,
  setVersion
} from "/node_modules/.vite/deps/chunk-VMZS5K6Z.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@fluentui/react-hooks/lib/version.js
setVersion("@fluentui/react-hooks", "8.6.20");

// node_modules/@fluentui/react-hooks/lib/useAsync.js
var React = __toESM(require_react());
function useAsync() {
  var asyncRef = React.useRef();
  if (!asyncRef.current) {
    asyncRef.current = new Async();
  }
  React.useEffect(function() {
    return function() {
      var _a;
      (_a = asyncRef.current) === null || _a === void 0 ? void 0 : _a.dispose();
      asyncRef.current = void 0;
    };
  }, []);
  return asyncRef.current;
}

// node_modules/@fluentui/react-hooks/lib/useBoolean.js
var React3 = __toESM(require_react());

// node_modules/@fluentui/react-hooks/lib/useConst.js
var React2 = __toESM(require_react());
function useConst(initialValue) {
  var ref = React2.useRef();
  if (ref.current === void 0) {
    ref.current = {
      value: typeof initialValue === "function" ? initialValue() : initialValue
    };
  }
  return ref.current.value;
}

// node_modules/@fluentui/react-hooks/lib/useBoolean.js
function useBoolean(initialState) {
  var _a = React3.useState(initialState), value = _a[0], setValue = _a[1];
  var setTrue = useConst(function() {
    return function() {
      setValue(true);
    };
  });
  var setFalse = useConst(function() {
    return function() {
      setValue(false);
    };
  });
  var toggle = useConst(function() {
    return function() {
      setValue(function(currentValue) {
        return !currentValue;
      });
    };
  });
  return [value, { setTrue, setFalse, toggle }];
}

// node_modules/@fluentui/react-hooks/lib/useConstCallback.js
var React4 = __toESM(require_react());
function useConstCallback(callback) {
  var ref = React4.useRef();
  if (!ref.current) {
    ref.current = callback;
  }
  return ref.current;
}

// node_modules/@fluentui/react-hooks/lib/useControllableValue.js
var React5 = __toESM(require_react());
function useControllableValue(controlledValue, defaultUncontrolledValue, onChange) {
  var _a = React5.useState(defaultUncontrolledValue), value = _a[0], setValue = _a[1];
  var isControlled = useConst(controlledValue !== void 0);
  var currentValue = isControlled ? controlledValue : value;
  var valueRef = React5.useRef(currentValue);
  var onChangeRef = React5.useRef(onChange);
  React5.useEffect(function() {
    valueRef.current = currentValue;
    onChangeRef.current = onChange;
  });
  var setValueOrCallOnChange = useConst(function() {
    return function(update, ev) {
      var newValue = typeof update === "function" ? update(valueRef.current) : update;
      if (onChangeRef.current) {
        onChangeRef.current(ev, newValue);
      }
      if (!isControlled) {
        setValue(newValue);
      }
    };
  });
  return [currentValue, setValueOrCallOnChange];
}

// node_modules/@fluentui/react-hooks/lib/useEventCallback.js
var React6 = __toESM(require_react());
function useEventCallback(fn) {
  var callbackRef = React6.useRef(function() {
    throw new Error("Cannot call an event handler while rendering");
  });
  useIsomorphicLayoutEffect(function() {
    callbackRef.current = fn;
  }, [fn]);
  return useConst(function() {
    return function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var callback = callbackRef.current;
      return callback.apply(void 0, args);
    };
  });
}

// node_modules/@fluentui/react-hooks/lib/useForceUpdate.js
var React7 = __toESM(require_react());
function useForceUpdate() {
  var _a = React7.useState(0), setValue = _a[1];
  var forceUpdate = useConst(function() {
    return function() {
      return setValue(function(value) {
        return ++value;
      });
    };
  });
  return forceUpdate;
}

// node_modules/@fluentui/react-hooks/lib/useId.js
var React8 = __toESM(require_react());
function useId(prefix, providedId) {
  var ref = React8.useRef(providedId);
  if (!ref.current) {
    ref.current = getId(prefix);
  }
  return ref.current;
}

// node_modules/@fluentui/react-hooks/lib/useMergedRefs.js
var React9 = __toESM(require_react());
function useMergedRefs() {
  var refs = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    refs[_i] = arguments[_i];
  }
  var mergedCallback = React9.useCallback(function(value) {
    mergedCallback.current = value;
    for (var _i2 = 0, refs_1 = refs; _i2 < refs_1.length; _i2++) {
      var ref = refs_1[_i2];
      if (typeof ref === "function") {
        ref(value);
      } else if (ref) {
        ref.current = value;
      }
    }
  }, __spreadArray([], refs));
  return mergedCallback;
}

// node_modules/@fluentui/react-hooks/lib/useMount.js
var React10 = __toESM(require_react());
var useMount = function(callback) {
  var mountRef = React10.useRef(callback);
  mountRef.current = callback;
  React10.useEffect(function() {
    var _a;
    (_a = mountRef.current) === null || _a === void 0 ? void 0 : _a.call(mountRef);
  }, []);
};

// node_modules/@fluentui/react-hooks/lib/useMountSync.js
var React11 = __toESM(require_react());
var useMountSync = function(callback) {
  var mountRef = React11.useRef(callback);
  mountRef.current = callback;
  React11.useLayoutEffect(function() {
    var _a;
    (_a = mountRef.current) === null || _a === void 0 ? void 0 : _a.call(mountRef);
  }, []);
};

// node_modules/@fluentui/react-hooks/lib/useOnEvent.js
var React12 = __toESM(require_react());
function useOnEvent(element, eventName, callback, useCapture) {
  var callbackRef = React12.useRef(callback);
  callbackRef.current = callback;
  React12.useEffect(function() {
    var actualElement = element && "current" in element ? element.current : element;
    if (!actualElement) {
      return;
    }
    var dispose = on(actualElement, eventName, function(ev) {
      return callbackRef.current(ev);
    }, useCapture);
    return dispose;
  }, [element, eventName, useCapture]);
}

// node_modules/@fluentui/react-hooks/lib/usePrevious.js
var import_react = __toESM(require_react());
function usePrevious(value) {
  var ref = (0, import_react.useRef)();
  (0, import_react.useEffect)(function() {
    ref.current = value;
  });
  return ref.current;
}

// node_modules/@fluentui/react-hooks/lib/useRefEffect.js
var React13 = __toESM(require_react());
function useRefEffect(callback, initial) {
  if (initial === void 0) {
    initial = null;
  }
  var createRefCallback = function() {
    var refCallback = function(value) {
      if (data.ref.current !== value) {
        if (data.cleanup) {
          data.cleanup();
          data.cleanup = void 0;
        }
        data.ref.current = value;
        if (value !== null) {
          data.cleanup = data.callback(value);
        }
      }
    };
    refCallback.current = initial;
    return refCallback;
  };
  var data = React13.useRef({
    ref: createRefCallback(),
    callback
  }).current;
  data.callback = callback;
  return data.ref;
}

// node_modules/@fluentui/react-hooks/lib/useSetInterval.js
var React14 = __toESM(require_react());
var useSetInterval = function() {
  var intervalIds = useConst({});
  React14.useEffect(
    function() {
      return function() {
        for (var _i = 0, _a = Object.keys(intervalIds); _i < _a.length; _i++) {
          var id = _a[_i];
          clearInterval(id);
        }
      };
    },
    // useConst ensures this will never change, but react-hooks/exhaustive-deps doesn't know that
    [intervalIds]
  );
  return useConst({
    setInterval: function(func, duration) {
      var id = setInterval(func, duration);
      intervalIds[id] = 1;
      return id;
    },
    clearInterval: function(id) {
      delete intervalIds[id];
      clearInterval(id);
    }
  });
};

// node_modules/@fluentui/react-hooks/lib/useSetTimeout.js
var React15 = __toESM(require_react());
var useSetTimeout = function() {
  var timeoutIds = useConst({});
  React15.useEffect(
    function() {
      return function() {
        for (var _i = 0, _a = Object.keys(timeoutIds); _i < _a.length; _i++) {
          var id = _a[_i];
          clearTimeout(id);
        }
      };
    },
    // useConst ensures this will never change, but react-hooks/exhaustive-deps doesn't know that
    [timeoutIds]
  );
  return useConst({
    setTimeout: function(func, duration) {
      var id = setTimeout(func, duration);
      timeoutIds[id] = 1;
      return id;
    },
    clearTimeout: function(id) {
      delete timeoutIds[id];
      clearTimeout(id);
    }
  });
};

// node_modules/@fluentui/react-hooks/lib/useTarget.js
var React17 = __toESM(require_react());

// node_modules/@fluentui/react-window-provider/lib/WindowProvider.js
var React16 = __toESM(require_react());
var WindowContext = React16.createContext({
  window: typeof window === "object" ? window : void 0
});
var useWindow = function() {
  return React16.useContext(WindowContext).window;
};
var useDocument = function() {
  var _a;
  return (_a = React16.useContext(WindowContext).window) === null || _a === void 0 ? void 0 : _a.document;
};
var WindowProvider = function(props) {
  return React16.createElement(WindowContext.Provider, { value: props }, props.children);
};

// node_modules/@fluentui/react-window-provider/lib/version.js
setVersion("@fluentui/react-window-provider", "2.2.15");

// node_modules/@fluentui/react-hooks/lib/useTarget.js
function useTarget(target, hostElement) {
  var previousTargetProp = React17.useRef();
  var targetRef = React17.useRef(null);
  var targetWindow = useWindow();
  if (!target || target !== previousTargetProp.current || typeof target === "string") {
    var currentElement = hostElement === null || hostElement === void 0 ? void 0 : hostElement.current;
    if (target) {
      if (typeof target === "string") {
        var currentDoc = getDocument(currentElement);
        targetRef.current = currentDoc ? currentDoc.querySelector(target) : null;
      } else if ("stopPropagation" in target) {
        targetRef.current = target;
      } else if ("getBoundingClientRect" in target) {
        targetRef.current = target;
      } else if ("current" in target) {
        targetRef.current = target.current;
      } else {
        targetRef.current = target;
      }
    }
    previousTargetProp.current = target;
  }
  return [targetRef, targetWindow];
}

// node_modules/@fluentui/react-hooks/lib/useUnmount.js
var React18 = __toESM(require_react());
var useUnmount = function(callback) {
  var unmountRef = React18.useRef(callback);
  unmountRef.current = callback;
  React18.useEffect(function() {
    return function() {
      var _a;
      (_a = unmountRef.current) === null || _a === void 0 ? void 0 : _a.call(unmountRef);
    };
  }, []);
};

// node_modules/@fluentui/react-hooks/lib/useWarnings.js
var React19 = __toESM(require_react());
var warningId = 0;
function useWarnings(options) {
  if (true) {
    var name_1 = options.name, props = options.props, _a = options.other, other = _a === void 0 ? [] : _a, conditionallyRequired = options.conditionallyRequired, deprecations = options.deprecations, mutuallyExclusive = options.mutuallyExclusive, controlledUsage = options.controlledUsage;
    var hasWarnedRef = React19.useRef(false);
    var componentId = useConst(function() {
      return "useWarnings_" + warningId++;
    });
    var oldProps = usePrevious(props);
    if (!hasWarnedRef.current) {
      hasWarnedRef.current = true;
      for (var _i = 0, other_1 = other; _i < other_1.length; _i++) {
        var warning = other_1[_i];
        warn(warning);
      }
      if (conditionallyRequired) {
        for (var _b = 0, conditionallyRequired_1 = conditionallyRequired; _b < conditionallyRequired_1.length; _b++) {
          var req = conditionallyRequired_1[_b];
          warnConditionallyRequiredProps(name_1, props, req.requiredProps, req.conditionalPropName, req.condition);
        }
      }
      deprecations && warnDeprecations(name_1, props, deprecations);
      mutuallyExclusive && warnMutuallyExclusive(name_1, props, mutuallyExclusive);
    }
    controlledUsage && warnControlledUsage(__assign(__assign({}, controlledUsage), { componentId, props, componentName: name_1, oldProps }));
  }
}

export {
  useAsync,
  useConst,
  useBoolean,
  useConstCallback,
  useControllableValue,
  useEventCallback,
  useForceUpdate,
  useId,
  useMergedRefs,
  useMount,
  useMountSync,
  useOnEvent,
  usePrevious,
  useRefEffect,
  useSetInterval,
  useSetTimeout,
  WindowContext,
  useWindow,
  useDocument,
  WindowProvider,
  useTarget,
  useUnmount,
  useWarnings
};
//# sourceMappingURL=chunk-AL35FZVI.js.map
