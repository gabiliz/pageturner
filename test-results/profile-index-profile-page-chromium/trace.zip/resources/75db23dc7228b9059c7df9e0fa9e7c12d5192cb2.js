import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/loadingScreen/LoadingScreen.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/loadingScreen/LoadingScreen.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Spinner } from "/src/shared/components/index.ts?t=1701096626433";
import FlexColumn from "/src/shared/components/FlexBox/FlexColumn.tsx";
import { SpinnerSizeEnum } from "/src/shared/enums/SpinnerSizeEnum.ts";
const LoadingApp = () => {
  return /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", verticalAlign: "center", height: "100%", styles: {
    flexGrow: 1
  }, children: /* @__PURE__ */ jsxDEV(Spinner, { size: SpinnerSizeEnum.large }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/loadingScreen/LoadingScreen.tsx",
    lineNumber: 9,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/loadingScreen/LoadingScreen.tsx",
    lineNumber: 6,
    columnNumber: 10
  }, this);
};
_c = LoadingApp;
export default LoadingApp;
var _c;
$RefreshReg$(_c, "LoadingApp");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/loadingScreen/LoadingScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07QUFiTiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixTQUFTQSxlQUFlO0FBQ3hCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyx1QkFBdUI7QUFFaEMsTUFBTUMsYUFBaUJBLE1BQU07QUFDM0IsU0FDRSx1QkFBQyxjQUNDLGlCQUFnQixVQUNoQixlQUFjLFVBQ2QsUUFBTyxRQUNQLFFBQVE7QUFBQSxJQUFFQyxVQUFVO0FBQUEsRUFBRSxHQUV0QixpQ0FBQyxXQUFRLE1BQU1GLGdCQUFnQkcsU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQyxLQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDQyxLQVhLSDtBQWFOLGVBQWVBO0FBQVUsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNwaW5uZXIiLCJGbGV4Q29sdW1uIiwiU3Bpbm5lclNpemVFbnVtIiwiTG9hZGluZ0FwcCIsImZsZXhHcm93IiwibGFyZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvYWRpbmdTY3JlZW4udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbG9hZGluZ1NjcmVlbi9Mb2FkaW5nU2NyZWVuLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi4nXG5pbXBvcnQgRmxleENvbHVtbiBmcm9tICcuLy4uL0ZsZXhCb3gvRmxleENvbHVtbidcbmltcG9ydCB7IFNwaW5uZXJTaXplRW51bSB9IGZyb20gJy4uLy4uL2VudW1zL1NwaW5uZXJTaXplRW51bSdcblxuY29uc3QgTG9hZGluZ0FwcDogRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEZsZXhDb2x1bW5cbiAgICAgIGhvcml6b250YWxBbGlnbj1cImNlbnRlclwiXG4gICAgICB2ZXJ0aWNhbEFsaWduPVwiY2VudGVyXCJcbiAgICAgIGhlaWdodD1cIjEwMCVcIlxuICAgICAgc3R5bGVzPXt7IGZsZXhHcm93OiAxIH19XG4gICAgPlxuICAgICAgPFNwaW5uZXIgc2l6ZT17U3Bpbm5lclNpemVFbnVtLmxhcmdlfSAvPlxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2FkaW5nQXBwXG4iXX0=