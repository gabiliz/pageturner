import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/providers/QueryProvider.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/QueryProvider.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { ReactQueryDevtools } from "/node_modules/.vite/deps/@tanstack_react-query-devtools.js?v=9f90a7ff";
const MINUTE_IN_SECONDS = 60;
const SECOND_IN_MILLISECONDS = 1e3;
const MINUTE_AMOUNT = 1;
const MINUTE_IN_MILLISECONDS = MINUTE_IN_SECONDS * SECOND_IN_MILLISECONDS * MINUTE_AMOUNT;
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: MINUTE_IN_MILLISECONDS
    }
  }
});
const QueryProvider = (props) => {
  return /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: [
    props.children,
    /* @__PURE__ */ jsxDEV(ReactQueryDevtools, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/QueryProvider.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/QueryProvider.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_c = QueryProvider;
export default QueryProvider;
var _c;
$RefreshReg$(_c, "QueryProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/QueryProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JNO0FBdEJOLDJCQUFzQkE7QUFBbUIsSUFBUTtBQUFBO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN4RSxTQUFTQywwQkFBMEI7QUFHbkMsTUFBTUMsb0JBQW9CO0FBQzFCLE1BQU1DLHlCQUF5QjtBQUMvQixNQUFNQyxnQkFBZ0I7QUFDdEIsTUFBTUMseUJBQXlCSCxvQkFBb0JDLHlCQUF5QkM7QUFFckUsYUFBTUUsY0FBYyxJQUFJQyxZQUFZO0FBQUEsRUFDekNDLGdCQUFnQjtBQUFBLElBQ2RDLFNBQVM7QUFBQSxNQUNQQyxzQkFBc0I7QUFBQSxNQUN0QkMsV0FBV047QUFBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBRUQsTUFBTU8sZ0JBQThEQyxXQUFVO0FBQzVFLFNBQ0UsdUJBQUMsdUJBQW9CLFFBQVFQLGFBQzFCTztBQUFBQSxVQUFNQztBQUFBQSxJQUNQLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUI7QUFBQSxPQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDQyxLQVBLSDtBQVNOLGVBQWVBO0FBQWEsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlF1ZXJ5Q2xpZW50UHJvdmlkZXIiLCJSZWFjdFF1ZXJ5RGV2dG9vbHMiLCJNSU5VVEVfSU5fU0VDT05EUyIsIlNFQ09ORF9JTl9NSUxMSVNFQ09ORFMiLCJNSU5VVEVfQU1PVU5UIiwiTUlOVVRFX0lOX01JTExJU0VDT05EUyIsInF1ZXJ5Q2xpZW50IiwiUXVlcnlDbGllbnQiLCJkZWZhdWx0T3B0aW9ucyIsInF1ZXJpZXMiLCJyZWZldGNoT25XaW5kb3dGb2N1cyIsInN0YWxlVGltZSIsIlF1ZXJ5UHJvdmlkZXIiLCJwcm9wcyIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJRdWVyeVByb3ZpZGVyLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9wcm92aWRlcnMvUXVlcnlQcm92aWRlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgUmVhY3RRdWVyeURldnRvb2xzIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5LWRldnRvb2xzJ1xyXG5pbXBvcnQgeyBGQywgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcclxuXHJcbmNvbnN0IE1JTlVURV9JTl9TRUNPTkRTID0gNjBcclxuY29uc3QgU0VDT05EX0lOX01JTExJU0VDT05EUyA9IDEwMDBcclxuY29uc3QgTUlOVVRFX0FNT1VOVCA9IDFcclxuY29uc3QgTUlOVVRFX0lOX01JTExJU0VDT05EUyA9IE1JTlVURV9JTl9TRUNPTkRTICogU0VDT05EX0lOX01JTExJU0VDT05EUyAqIE1JTlVURV9BTU9VTlRcclxuXHJcbmV4cG9ydCBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCh7XHJcbiAgZGVmYXVsdE9wdGlvbnM6IHtcclxuICAgIHF1ZXJpZXM6IHtcclxuICAgICAgcmVmZXRjaE9uV2luZG93Rm9jdXM6IGZhbHNlLFxyXG4gICAgICBzdGFsZVRpbWU6IE1JTlVURV9JTl9NSUxMSVNFQ09ORFMsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pXHJcblxyXG5jb25zdCBRdWVyeVByb3ZpZGVyOiBGQzxQcm9wc1dpdGhDaGlsZHJlbjxSZWNvcmQ8bmV2ZXIsIG5ldmVyPj4+ID0gKHByb3BzKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxyXG4gICAgICB7cHJvcHMuY2hpbGRyZW59XHJcbiAgICAgIDxSZWFjdFF1ZXJ5RGV2dG9vbHMgLz5cclxuICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFF1ZXJ5UHJvdmlkZXJcclxuIl19