// node_modules/@microsoft/load-themed-styles/lib-es6/index.js
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var _root = typeof window === "undefined" ? global : window;
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
function initializeThemeState() {
  var state = _root.__themeState__ || {
    theme: void 0,
    lastStyleElement: void 0,
    registeredStyles: []
  };
  if (!state.runState) {
    state = __assign(__assign({}, state), { perf: {
      count: 0,
      duration: 0
    }, runState: {
      flushTimer: 0,
      mode: 0,
      buffer: []
    } });
  }
  if (!state.registeredThemableStyles) {
    state = __assign(__assign({}, state), { registeredThemableStyles: [] });
  }
  _root.__themeState__ = state;
  return state;
}
function applyThemableStyles(stylesArray, styleRecord) {
  if (_themeState.loadStyles) {
    _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
  } else {
    registerStyles(stylesArray);
  }
}
function loadTheme(theme) {
  _themeState.theme = theme;
  reloadStyles();
}
function clearStyles(option) {
  if (option === void 0) {
    option = 3;
  }
  if (option === 3 || option === 2) {
    clearStylesInternal(_themeState.registeredStyles);
    _themeState.registeredStyles = [];
  }
  if (option === 3 || option === 1) {
    clearStylesInternal(_themeState.registeredThemableStyles);
    _themeState.registeredThemableStyles = [];
  }
}
function clearStylesInternal(records) {
  records.forEach(function(styleRecord) {
    var styleElement = styleRecord && styleRecord.styleElement;
    if (styleElement && styleElement.parentElement) {
      styleElement.parentElement.removeChild(styleElement);
    }
  });
}
function reloadStyles() {
  if (_themeState.theme) {
    var themableStyles = [];
    for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
      var styleRecord = _a[_i];
      themableStyles.push(styleRecord.themableStyle);
    }
    if (themableStyles.length > 0) {
      clearStyles(
        1
        /* ClearStyleOptions.onlyThemable */
      );
      applyThemableStyles([].concat.apply([], themableStyles));
    }
  }
}
function resolveThemableArray(splitStyleArray) {
  var theme = _themeState.theme;
  var themable = false;
  var resolvedArray = (splitStyleArray || []).map(function(currentValue) {
    var themeSlot = currentValue.theme;
    if (themeSlot) {
      themable = true;
      var themedValue = theme ? theme[themeSlot] : void 0;
      var defaultValue = currentValue.defaultValue || "inherit";
      if (theme && !themedValue && console && !(themeSlot in theme) && typeof DEBUG !== "undefined" && DEBUG) {
        console.warn('Theming value not provided for "'.concat(themeSlot, '". Falling back to "').concat(defaultValue, '".'));
      }
      return themedValue || defaultValue;
    } else {
      return currentValue.rawString;
    }
  });
  return {
    styleString: resolvedArray.join(""),
    themable
  };
}
function registerStyles(styleArray) {
  if (typeof document === "undefined") {
    return;
  }
  var head = document.getElementsByTagName("head")[0];
  var styleElement = document.createElement("style");
  var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
  styleElement.setAttribute("data-load-themed-styles", "true");
  if (_styleNonce) {
    styleElement.setAttribute("nonce", _styleNonce);
  }
  styleElement.appendChild(document.createTextNode(styleString));
  _themeState.perf.count++;
  head.appendChild(styleElement);
  var ev = document.createEvent("HTMLEvents");
  ev.initEvent(
    "styleinsert",
    true,
    false
    /* cancelable */
  );
  ev.args = {
    newStyle: styleElement
  };
  document.dispatchEvent(ev);
  var record = {
    styleElement,
    themableStyle: styleArray
  };
  if (themable) {
    _themeState.registeredThemableStyles.push(record);
  } else {
    _themeState.registeredStyles.push(record);
  }
}

export {
  loadTheme
};
//# sourceMappingURL=chunk-2EIJ3ZL6.js.map
