import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAccountConfigurationForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { UserAvatarUpload } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { Checkbox, FlexColumn, TextField } from "/src/shared/components/index.ts?t=1701096626433";
const UserAccountConfigurationForm = (props) => {
  const {
    userFormData,
    onTextChange,
    removeImage
  } = props;
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(UserAvatarUpload, { image: userFormData.image, onChange: (path) => onTextChange("image")(null, path), hasImage: userFormData.image !== "", removeImage }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Nome completo", value: userFormData?.nome, onChange: onTextChange("nome"), maxLength: 100 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Email", value: userFormData?.email, readOnly: true, disabled: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Cargo", value: userFormData?.cargos?.[0] ? userFormData?.cargos?.[0].cargo?.nome : "", readOnly: true, disabled: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    userFormData.desenvolvedor && /* @__PURE__ */ jsxDEV(Checkbox, { label: "Desenvolvedor", checked: userFormData.desenvolvedor, disabled: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
      lineNumber: 21,
      columnNumber: 38
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_c = UserAccountConfigurationForm;
export default UserAccountConfigurationForm;
var _c;
$RefreshReg$(_c, "UserAccountConfigurationForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAccountConfigurationForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNO0FBaEJOLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRTFCLFNBQVNBLHdCQUF3QjtBQUNqQyxTQUFTQyxVQUFVQyxZQUFZQyxpQkFBaUI7QUFRaEQsTUFBTUMsK0JBQW1FQyxXQUFVO0FBQ2pGLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFjQztBQUFBQSxJQUFjQztBQUFBQSxFQUFZLElBQUlIO0FBRXBELFNBQ0UsdUJBQUMsY0FBVyxLQUFNLElBQ2hCO0FBQUEsMkJBQUMsb0JBQ0MsT0FBT0MsYUFBYUcsT0FDcEIsVUFBVUMsVUFBUUgsYUFBYSxPQUFPLEVBQUUsTUFBTUcsSUFBSSxHQUNsRCxVQUFVSixhQUFhRyxVQUFVLElBQ2pDLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUkyQjtBQUFBLElBRTNCLHVCQUFDLGFBQ0MsT0FBTSxpQkFDTixPQUFPSCxjQUFjSyxNQUNyQixVQUFVSixhQUFhLE1BQU0sR0FDN0IsV0FBVyxPQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJaUI7QUFBQSxJQUVqQix1QkFBQyxhQUNDLE9BQU0sU0FDTixPQUFPRCxjQUFjTSxPQUNyQixVQUFRLE1BQ1IsVUFBUSxRQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJVTtBQUFBLElBRVYsdUJBQUMsYUFDQyxPQUFNLFNBQ04sT0FBT04sY0FBY08sU0FBUyxDQUFDLElBQUlQLGNBQWNPLFNBQVMsQ0FBQyxFQUFFQyxPQUFPSCxPQUFPLElBQzNFLFVBQVEsTUFDUixVQUFRLFFBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlVO0FBQUEsSUFFVEwsYUFBYVMsaUJBQWlCLHVCQUFDLFlBQzlCLE9BQU0saUJBQ04sU0FBU1QsYUFBYVMsZUFDdEIsVUFBUSxRQUhxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR3JCO0FBQUEsT0E1Qlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNDLEtBcENLWjtBQXNDTixlQUFlQTtBQUE0QixJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVXNlckF2YXRhclVwbG9hZCIsIkNoZWNrYm94IiwiRmxleENvbHVtbiIsIlRleHRGaWVsZCIsIlVzZXJBY2NvdW50Q29uZmlndXJhdGlvbkZvcm0iLCJwcm9wcyIsInVzZXJGb3JtRGF0YSIsIm9uVGV4dENoYW5nZSIsInJlbW92ZUltYWdlIiwiaW1hZ2UiLCJwYXRoIiwibm9tZSIsImVtYWlsIiwiY2FyZ29zIiwiY2FyZ28iLCJkZXNlbnZvbHZlZG9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3JtLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vdXNlcnMvY29tcG9uZW50cy9Vc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3JtLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgVXNlciBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vVXNlcidcbmltcG9ydCB7IFVzZXJBdmF0YXJVcGxvYWQgfSBmcm9tICcuJ1xuaW1wb3J0IHsgQ2hlY2tib3gsIEZsZXhDb2x1bW4sIFRleHRGaWVsZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJBY2NvdW50Q29uZmlndXJhdGlvblByb3BzIHtcbiAgdXNlckZvcm1EYXRhOiBVc2VyXG4gIG9uVGV4dENoYW5nZTogKGtleToga2V5b2YgVXNlcikgPT4gKF8/OiB1bmtub3duLCB2YWx1ZT86IHN0cmluZyB8IHVuZGVmaW5lZCkgPT4gdm9pZFxuICByZW1vdmVJbWFnZTogKCkgPT4gdm9pZFxufVxuXG5jb25zdCBVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3JtOiBGQzxVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Qcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyB1c2VyRm9ybURhdGEsIG9uVGV4dENoYW5nZSwgcmVtb3ZlSW1hZ2UgfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtbiBnYXA9eyAxMiB9PlxuICAgICAgPFVzZXJBdmF0YXJVcGxvYWRcbiAgICAgICAgaW1hZ2U9e3VzZXJGb3JtRGF0YS5pbWFnZX1cbiAgICAgICAgb25DaGFuZ2U9e3BhdGggPT4gb25UZXh0Q2hhbmdlKCdpbWFnZScpKG51bGwsIHBhdGgpfVxuICAgICAgICBoYXNJbWFnZT17dXNlckZvcm1EYXRhLmltYWdlICE9PSAnJ31cbiAgICAgICAgcmVtb3ZlSW1hZ2U9e3JlbW92ZUltYWdlfVxuICAgICAgLz5cbiAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgbGFiZWw9XCJOb21lIGNvbXBsZXRvXCJcbiAgICAgICAgdmFsdWU9e3VzZXJGb3JtRGF0YT8ubm9tZX1cbiAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnbm9tZScpfVxuICAgICAgICBtYXhMZW5ndGg9ezEwMH1cbiAgICAgIC8+XG4gICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsPVwiRW1haWxcIlxuICAgICAgICB2YWx1ZT17dXNlckZvcm1EYXRhPy5lbWFpbH1cbiAgICAgICAgcmVhZE9ubHlcbiAgICAgICAgZGlzYWJsZWRcbiAgICAgIC8+XG4gICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsPVwiQ2FyZ29cIlxuICAgICAgICB2YWx1ZT17dXNlckZvcm1EYXRhPy5jYXJnb3M/LlswXSA/IHVzZXJGb3JtRGF0YT8uY2FyZ29zPy5bMF0uY2FyZ28/Lm5vbWUgOiAnJ31cbiAgICAgICAgcmVhZE9ubHlcbiAgICAgICAgZGlzYWJsZWRcbiAgICAgIC8+XG4gICAgICB7dXNlckZvcm1EYXRhLmRlc2Vudm9sdmVkb3IgJiYgPENoZWNrYm94XG4gICAgICAgIGxhYmVsPSdEZXNlbnZvbHZlZG9yJ1xuICAgICAgICBjaGVja2VkPXt1c2VyRm9ybURhdGEuZGVzZW52b2x2ZWRvcn1cbiAgICAgICAgZGlzYWJsZWRcbiAgICAgIC8+fVxuICAgIDwvRmxleENvbHVtbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBVc2VyQWNjb3VudENvbmZpZ3VyYXRpb25Gb3JtXG4iXX0=