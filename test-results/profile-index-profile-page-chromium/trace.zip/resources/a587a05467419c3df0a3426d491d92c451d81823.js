import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractsBreadCrumb.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractsBreadCrumb.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"];
import { BreadCrumb } from "/src/shared/components/index.ts?t=1701096626433";
import { ContractsContext } from "/src/modules/admin/contracts/context/ContractsPageContext.ts";
const ContractConfigurationBreadCrumb = () => {
  _s();
  const {
    client
  } = useContext(ContractsContext);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: client && /* @__PURE__ */ jsxDEV(BreadCrumb, { items: [{
    label: "Clientes",
    url: "/admin/clients"
  }, {
    label: client.nomeFantasia
  }, {
    label: "Contratos"
  }] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractsBreadCrumb.tsx",
    lineNumber: 11,
    columnNumber: 16
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractsBreadCrumb.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(ContractConfigurationBreadCrumb, "z61b9Lqq4geyv4W7FIyI2YCrXy0=");
_c = ContractConfigurationBreadCrumb;
export default ContractConfigurationBreadCrumb;
var _c;
$RefreshReg$(_c, "ContractConfigurationBreadCrumb");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractsBreadCrumb.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1MsbUJBRUgsY0FGRzs7Ozs7Ozs7Ozs7Ozs7OztBQVBULFNBQWFBLGtCQUFrQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msd0JBQXdCO0FBRWpDLE1BQU1DLGtDQUFzQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2hELFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFPLElBQUlMLFdBQVdFLGdCQUFnQjtBQUU5QyxTQUFPLG1DQUNKRyxvQkFDQyx1QkFBQyxjQUFXLE9BQU8sQ0FDakI7QUFBQSxJQUNFQyxPQUFPO0FBQUEsSUFDUEMsS0FBSztBQUFBLEVBQ1AsR0FDQTtBQUFBLElBQ0VELE9BQU9ELE9BQU9HO0FBQUFBLEVBQ2hCLEdBQ0E7QUFBQSxJQUNFRixPQUFPO0FBQUEsRUFDVCxDQUFDLEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdFLEtBYkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVQO0FBQ0Y7QUFBQ0YsR0FuQktELGlDQUFtQztBQUFBTSxLQUFuQ047QUFxQk4sZUFBZUE7QUFBK0IsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNvbnRleHQiLCJCcmVhZENydW1iIiwiQ29udHJhY3RzQ29udGV4dCIsIkNvbnRyYWN0Q29uZmlndXJhdGlvbkJyZWFkQ3J1bWIiLCJfcyIsImNsaWVudCIsImxhYmVsIiwidXJsIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cmFjdHNCcmVhZENydW1iLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYWRtaW4vY29udHJhY3RzL2NvbXBvbmVudHMvQ29udHJhY3RzQnJlYWRDcnVtYi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQnJlYWRDcnVtYiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgQ29udHJhY3RzQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvQ29udHJhY3RzUGFnZUNvbnRleHQnXG5cbmNvbnN0IENvbnRyYWN0Q29uZmlndXJhdGlvbkJyZWFkQ3J1bWI6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNsaWVudCB9ID0gdXNlQ29udGV4dChDb250cmFjdHNDb250ZXh0KVxuXG4gIHJldHVybiA8PlxuICAgIHtjbGllbnQgJiYgKFxuICAgICAgPEJyZWFkQ3J1bWIgaXRlbXM9e1tcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiAnQ2xpZW50ZXMnLFxuICAgICAgICAgIHVybDogJy9hZG1pbi9jbGllbnRzJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBjbGllbnQubm9tZUZhbnRhc2lhLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgbGFiZWw6ICdDb250cmF0b3MnLFxuICAgICAgICB9LFxuICAgICAgXX0gLz5cbiAgICApfVxuICA8Lz5cbn1cblxuZXhwb3J0IGRlZmF1bHQgQ29udHJhY3RDb25maWd1cmF0aW9uQnJlYWRDcnVtYlxuIl19