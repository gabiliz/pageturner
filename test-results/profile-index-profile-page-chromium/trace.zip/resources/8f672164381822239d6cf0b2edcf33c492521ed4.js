import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractHistoryModal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=9f90a7ff";
import { DataTable, LoadingScreen, Modal, PrimaryButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { UserName } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { contractHistoryQueryService } from "/src/modules/admin/contracts/services/index.ts";
const ContractHistoryModal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    contractId
  } = props;
  const styles = useStyles();
  const {
    data: history,
    isLoading
  } = contractHistoryQueryService.useFindAllPaginated(contractId);
  return /* @__PURE__ */ jsxDEV(Modal, { isOpen, onDismiss, title: "Histórico", children: [
    history && !isLoading && /* @__PURE__ */ jsxDEV(DataTable, { columns, items: history?.value ?? [], hasSelection: false, paginated: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
      lineNumber: 29,
      columnNumber: 33
    }, this),
    isLoading && /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
      lineNumber: 30,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actionStyles.actions, children: /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Fechar", onClick: onDismiss }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
};
_s(ContractHistoryModal, "4rDtczKkB3VMV0t/lfGMdoDNn30=", false, function() {
  return [useStyles, contractHistoryQueryService.useFindAllPaginated];
});
_c = ContractHistoryModal;
const useStyles = () => {
  _s2();
  const {
    spacing
  } = useTheme();
  const actionStyles = mergeStyleSets({
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 40,
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
  return {
    actionStyles
  };
};
_s2(useStyles, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
const columns = [{
  header: "Log",
  field: "descricao",
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Data",
  field: "dataHora",
  format: (item) => {
    if (item?.dataHora) {
      return format(new Date(item?.dataHora), "dd/MM/yyyy HH:mm");
    }
  },
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string",
  sortable: true
}, {
  header: "Usuário",
  field: "usuarioId",
  format: (item) => {
    return item.usuarioId ? /* @__PURE__ */ jsxDEV(UserName, { id: item.usuarioId }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx",
      lineNumber: 91,
      columnNumber: 29
    }, this) : "";
  },
  filterOptions: {
    queryType: "string",
    queryMode: "default"
  },
  type: "string"
}];
export default ContractHistoryModal;
var _c;
$RefreshReg$(_c, "ContractHistoryModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractHistoryModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJnQzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCaEMsU0FBU0Esc0JBQXNCO0FBQy9CLFNBQVNDLGNBQWM7QUFHdkIsU0FBU0MsV0FBNEJDLGVBQWVDLE9BQU9DLHFCQUFxQjtBQUNoRixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1DQUFtQztBQVE1QyxNQUFNQyx1QkFBdURDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBV0M7QUFBQUEsRUFBVyxJQUFJSjtBQUMxQyxRQUFNSyxTQUFTQyxVQUFVO0FBRXpCLFFBQU07QUFBQSxJQUFFQyxNQUFNQztBQUFBQSxJQUFTQztBQUFBQSxFQUFVLElBQUlYLDRCQUE0Qlksb0JBQW9CTixVQUFVO0FBRS9GLFNBQ0UsdUJBQUMsU0FDQyxRQUNBLFdBQ0EsT0FBTSxhQUVMSTtBQUFBQSxlQUFXLENBQUNDLGFBQWEsdUJBQUMsYUFDekIsU0FDQSxPQUFPRCxTQUFTRyxTQUFTLElBQ3pCLGNBQWMsT0FDZCxXQUFTLFFBSmU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlmO0FBQUEsSUFFVkYsYUFBYSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUM1Qix1QkFBQyxTQUFJLFdBQVdKLE9BQU9PLGFBQWFDLFNBQ2xDLGlDQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTVixhQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFcUIsS0FIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsT0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVKO0FBQUNGLEdBM0JLRixzQkFBbUQ7QUFBQSxVQUV4Q08sV0FFc0JSLDRCQUE0QlksbUJBQW1CO0FBQUE7QUFBQUksS0FKaEZmO0FBNkJOLE1BQU1PLFlBQVlBLE1BQU07QUFBQVMsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBUSxJQUFJcEIsU0FBUztBQUU3QixRQUFNZ0IsZUFBZXRCLGVBQWU7QUFBQSxJQUNsQ3VCLFNBQVM7QUFBQSxNQUNQSSxTQUFTO0FBQUEsTUFDVEMsZ0JBQWdCO0FBQUEsTUFDaEJDLFdBQVc7QUFBQSxNQUNYQyxXQUFXO0FBQUEsUUFDVCx5QkFBeUI7QUFBQSxVQUN2QkMsYUFBYUwsUUFBUU07QUFBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU87QUFBQSxJQUNMVjtBQUFBQSxFQUNGO0FBQ0Y7QUFBQ0csSUFuQktULFdBQVM7QUFBQSxVQUNPVixRQUFRO0FBQUE7QUFvQjlCLE1BQU0yQixVQUFzQyxDQUMxQztBQUFBLEVBQ0VDLFFBQVE7QUFBQSxFQUNSQyxPQUFPO0FBQUEsRUFDUEMsZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VOLFFBQVE7QUFBQSxFQUNSQyxPQUFPO0FBQUEsRUFDUGxDLFFBQVFBLENBQUN3QyxTQUFrQjtBQUN6QixRQUFJQSxNQUFNQyxVQUFVO0FBQ2xCLGFBQU96QyxPQUFPLElBQUkwQyxLQUFLRixNQUFNQyxRQUFRLEdBQUcsa0JBQWtCO0FBQUEsSUFDNUQ7QUFBQSxFQUNGO0FBQUEsRUFDQU4sZUFBZTtBQUFBLElBQ2JDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VOLFFBQVE7QUFBQSxFQUNSQyxPQUFPO0FBQUEsRUFDUGxDLFFBQVFBLENBQUN3QyxTQUFrQjtBQUN6QixXQUFPQSxLQUFLRyxZQUFZLHVCQUFDLFlBQVMsSUFBSUgsS0FBS0csYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QixJQUFLO0FBQUEsRUFDNUQ7QUFBQSxFQUNBUixlQUFlO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNiO0FBQUEsRUFDQUMsTUFBTTtBQUNSLENBQUM7QUFJSCxlQUFlOUI7QUFBb0IsSUFBQWU7QUFBQXFCLGFBQUFyQixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJmb3JtYXQiLCJEYXRhVGFibGUiLCJMb2FkaW5nU2NyZWVuIiwiTW9kYWwiLCJQcmltYXJ5QnV0dG9uIiwidXNlVGhlbWUiLCJVc2VyTmFtZSIsImNvbnRyYWN0SGlzdG9yeVF1ZXJ5U2VydmljZSIsIkNvbnRyYWN0SGlzdG9yeU1vZGFsIiwicHJvcHMiLCJfcyIsImlzT3BlbiIsIm9uRGlzbWlzcyIsImNvbnRyYWN0SWQiLCJzdHlsZXMiLCJ1c2VTdHlsZXMiLCJkYXRhIiwiaGlzdG9yeSIsImlzTG9hZGluZyIsInVzZUZpbmRBbGxQYWdpbmF0ZWQiLCJ2YWx1ZSIsImFjdGlvblN0eWxlcyIsImFjdGlvbnMiLCJfYyIsIl9zMiIsInNwYWNpbmciLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Ub3AiLCJzZWxlY3RvcnMiLCJtYXJnaW5SaWdodCIsImxnIiwiY29sdW1ucyIsImhlYWRlciIsImZpZWxkIiwiZmlsdGVyT3B0aW9ucyIsInF1ZXJ5VHlwZSIsInF1ZXJ5TW9kZSIsInR5cGUiLCJzb3J0YWJsZSIsIml0ZW0iLCJkYXRhSG9yYSIsIkRhdGUiLCJ1c3VhcmlvSWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cmFjdEhpc3RvcnlNb2RhbC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0SGlzdG9yeU1vZGFsLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1lcmdlU3R5bGVTZXRzIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBmb3JtYXQgfSBmcm9tICdkYXRlLWZucydcclxuaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEhpc3RvcnkgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL0hpc3RvcnknXHJcbmltcG9ydCB7IERhdGFUYWJsZSwgRGF0YVRhYmxlQ29sdW1uLCBMb2FkaW5nU2NyZWVuLCBNb2RhbCwgUHJpbWFyeUJ1dHRvbiB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgVXNlck5hbWUgfSBmcm9tICcuLi8uLi91c2Vycy9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBjb250cmFjdEhpc3RvcnlRdWVyeVNlcnZpY2UgfSBmcm9tICcuLy4uL3NlcnZpY2VzJ1xyXG5cclxuaW50ZXJmYWNlIENvbnRyYWN0SGlzdG9yeU1vZGFsUHJvcHMge1xyXG4gIGlzT3BlbjogYm9vbGVhblxyXG4gIG9uRGlzbWlzczogKCkgPT4gdm9pZFxyXG4gIGNvbnRyYWN0SWQ6IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBDb250cmFjdEhpc3RvcnlNb2RhbDogRkM8Q29udHJhY3RIaXN0b3J5TW9kYWxQcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IGlzT3Blbiwgb25EaXNtaXNzLCBjb250cmFjdElkIH0gPSBwcm9wc1xyXG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcygpXHJcblxyXG4gIGNvbnN0IHsgZGF0YTogaGlzdG9yeSwgaXNMb2FkaW5nIH0gPSBjb250cmFjdEhpc3RvcnlRdWVyeVNlcnZpY2UudXNlRmluZEFsbFBhZ2luYXRlZChjb250cmFjdElkKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsXHJcbiAgICAgIGlzT3Blbj17aXNPcGVufVxyXG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cclxuICAgICAgdGl0bGU9J0hpc3TDs3JpY28nXHJcbiAgICA+XHJcbiAgICAgIHtoaXN0b3J5ICYmICFpc0xvYWRpbmcgJiYgPERhdGFUYWJsZVxyXG4gICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgaXRlbXM9e2hpc3Rvcnk/LnZhbHVlID8/IFtdfVxyXG4gICAgICAgIGhhc1NlbGVjdGlvbj17ZmFsc2V9XHJcbiAgICAgICAgcGFnaW5hdGVkXHJcbiAgICAgIC8+fVxyXG4gICAgICB7aXNMb2FkaW5nICYmIDxMb2FkaW5nU2NyZWVuIC8+fVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFjdGlvblN0eWxlcy5hY3Rpb25zfT5cclxuICAgICAgICA8UHJpbWFyeUJ1dHRvblxyXG4gICAgICAgICAgdGV4dD1cIkZlY2hhclwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkRpc21pc3N9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxyXG5cclxuICBjb25zdCBhY3Rpb25TdHlsZXMgPSBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBhY3Rpb25zOiB7XHJcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCcsXHJcbiAgICAgIG1hcmdpblRvcDogNDAsXHJcbiAgICAgIHNlbGVjdG9yczoge1xyXG4gICAgICAgICcmID4gOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICBtYXJnaW5SaWdodDogc3BhY2luZy5sZyxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgYWN0aW9uU3R5bGVzLFxyXG4gIH1cclxufVxyXG5cclxuY29uc3QgY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPEhpc3Rvcnk+W10gPSBbXHJcbiAge1xyXG4gICAgaGVhZGVyOiAnTG9nJyxcclxuICAgIGZpZWxkOiAnZGVzY3JpY2FvJyxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGhlYWRlcjogJ0RhdGEnLFxyXG4gICAgZmllbGQ6ICdkYXRhSG9yYScsXHJcbiAgICBmb3JtYXQ6IChpdGVtOiBIaXN0b3J5KSA9PiB7XHJcbiAgICAgIGlmIChpdGVtPy5kYXRhSG9yYSkge1xyXG4gICAgICAgIHJldHVybiBmb3JtYXQobmV3IERhdGUoaXRlbT8uZGF0YUhvcmEpLCAnZGQvTU0veXl5eSBISDptbScpXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBmaWx0ZXJPcHRpb25zOiB7XHJcbiAgICAgIHF1ZXJ5VHlwZTogJ3N0cmluZycsXHJcbiAgICAgIHF1ZXJ5TW9kZTogJ2RlZmF1bHQnLFxyXG4gICAgfSxcclxuICAgIHR5cGU6ICdzdHJpbmcnLFxyXG4gICAgc29ydGFibGU6IHRydWUsXHJcbiAgfSxcclxuICB7XHJcbiAgICBoZWFkZXI6ICdVc3XDoXJpbycsXHJcbiAgICBmaWVsZDogJ3VzdWFyaW9JZCcsXHJcbiAgICBmb3JtYXQ6IChpdGVtOiBIaXN0b3J5KSA9PiB7XHJcbiAgICAgIHJldHVybiBpdGVtLnVzdWFyaW9JZCA/IDxVc2VyTmFtZSBpZD17aXRlbS51c3VhcmlvSWR9Lz4gOiAnJ1xyXG4gICAgfSxcclxuICAgIGZpbHRlck9wdGlvbnM6IHtcclxuICAgICAgcXVlcnlUeXBlOiAnc3RyaW5nJyxcclxuICAgICAgcXVlcnlNb2RlOiAnZGVmYXVsdCcsXHJcbiAgICB9LFxyXG4gICAgdHlwZTogJ3N0cmluZycsXHJcbiAgfSxcclxuXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0SGlzdG9yeU1vZGFsXHJcbiJdfQ==