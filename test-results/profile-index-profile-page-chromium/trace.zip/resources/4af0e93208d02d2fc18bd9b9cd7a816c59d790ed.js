const navLinkGroups = [
  {
    links: [
      {
        key: "TipoProjeto",
        name: "Tipo de projeto",
        icon: "Tag",
        url: "/fiscal/project-types"
      },
      {
        key: "FiscalRegra",
        name: "Configurar regras",
        icon: "Settings",
        url: "/fiscal/config-rules"
      },
      {
        key: "Projeto",
        name: "Projetos",
        icon: "ProjectCollection",
        url: "/fiscal/projects"
      }
    ]
  }
];
export default navLinkGroups;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpbmtzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElOYXZMaW5rR3JvdXAgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcblxyXG5jb25zdCBuYXZMaW5rR3JvdXBzOiBJTmF2TGlua0dyb3VwW10gPSBbXHJcbiAge1xyXG4gICAgbGlua3M6IFtcclxuICAgICAge1xyXG4gICAgICAgIGtleTogJ1RpcG9Qcm9qZXRvJyxcclxuICAgICAgICBuYW1lOiAnVGlwbyBkZSBwcm9qZXRvJyxcclxuICAgICAgICBpY29uOiAnVGFnJyxcclxuICAgICAgICB1cmw6ICcvZmlzY2FsL3Byb2plY3QtdHlwZXMnLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiAnRmlzY2FsUmVncmEnLFxyXG4gICAgICAgIG5hbWU6ICdDb25maWd1cmFyIHJlZ3JhcycsXHJcbiAgICAgICAgaWNvbjogJ1NldHRpbmdzJyxcclxuICAgICAgICB1cmw6ICcvZmlzY2FsL2NvbmZpZy1ydWxlcycsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6ICdQcm9qZXRvJyxcclxuICAgICAgICBuYW1lOiAnUHJvamV0b3MnLFxyXG4gICAgICAgIGljb246ICdQcm9qZWN0Q29sbGVjdGlvbicsXHJcbiAgICAgICAgdXJsOiAnL2Zpc2NhbC9wcm9qZWN0cycsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5hdkxpbmtHcm91cHNcclxuIl0sIm1hcHBpbmdzIjoiQUFFQSxNQUFNLGdCQUFpQztBQUFBLEVBQ3JDO0FBQUEsSUFDRSxPQUFPO0FBQUEsTUFDTDtBQUFBLFFBQ0UsS0FBSztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUNBO0FBQUEsUUFDRSxLQUFLO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixNQUFNO0FBQUEsUUFDTixLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQ0E7QUFBQSxRQUNFLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLEtBQUs7QUFBQSxNQUNQO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==