import styled, { css } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { IconButton } from "/src/shared/components/buttons/index.ts?t=1701096626433";
import { ContextualMenu, Nav } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
export const RetractMenuIcon = styled(IconButton)`
  background-color: ${(props) => props.theme.colors.purple[600]};
  border-radius: 50%;
  width: 24px;
  height: 24px;
  position: absolute;
  bottom: 32px;
  right: -12px;
  z-index: 1;

  transition: transform 300ms;

  ${(props) => !props.collapsed && css`
    transform: rotate(180deg);
  `}

  :hover, :active {
    background-color: ${(props) => props.theme.colors.purple[800]};
    color: inherit;
  }

  i {
    color: ${(props) => props.theme.colors.white};
    font-size: ${(props) => props.theme.fontSize.sm};
  }
`;
export const GoBackButton = styled(IconButton)`
  color: ${(props) => props.theme.colors.gray[500]};
  margin-top: ${(props) => props.theme.spacing.xxl};
  margin-bottom: ${(props) => props.theme.spacing.md};

  :hover {
    color: ${(props) => props.theme.colors.purple[800]};
  }

  :active {
    color: ${(props) => props.theme.colors.purple[800]};
  }
`;
export const SideMenuContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${(props) => props.theme.spacing.xs};
  height: inherit;
  padding-bottom: ${(props) => props.theme.spacing.xl};
`;
export const NavContainer = styled.div`
  overflow-y: auto;
  overflow-x: hidden;
`;
export const NavContextualMenu = styled(ContextualMenu)`
  color: ${(props) => props.theme.colors.gray[800]};

  :hover {
    color: ${(props) => props.theme.colors.purple[600]};

    .ms-ContextualMenu-icon {
      color: ${(props) => props.theme.colors.purple[600]};
    }
  }

  .ms-ContextualMenu-header {
    color: ${(props) => props.theme.colors.purple[600]};
  }

  .ms-ContextualMenu-icon {
    color: ${(props) => props.theme.colors.purple[500]};
  }
`;
export const ModuleContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  margin-left: ${(props) => props.theme.spacing.md};
  margin-right: ${(props) => props.theme.spacing.md};
`;
export const SideMenuNav = styled(Nav)`
  ${(props) => props.collapsed && css`
    .ms-Nav-chevronButton {
      display: none;
    }

    &.ms-Nav .ms-Nav-compositeLink .ms-Nav-linkText {
      display: none;
    }

    .ms-Nav-navItems .ms-Nav-navItems {
      position: absolute;
      overflow: hidden;
      width: 1px;
      height: 0;
      margin-left -1px;
    }

    &.ms-Nav .ms-Nav-compositeLink .ms-Nav-link {
      padding: 0 16px 0 0;

      > * > .ms-Button-icon:not(:empty) {
        margin-left: 16px;
      }
    }

    .ms-Nav-compositeLink[data-active='true'] .ms-Nav-link {
      ::after {
        border-left: ${(props2) => props2.theme.colors.purple[500]} 2px solid;
        content: "";
        position: absolute;
        inset: 0px;
        pointer-events: none;
      }
    }

  `}

  &.ms-Nav {
    width: ${(props) => props.collapsed ? "auto" : "230px"};

    .ms-Nav-groupContent {
      margin: 0;
    }

    .ms-Nav-compositeLink{
      margin: 0;
      padding: 0;
      background-color: transparent;
      height: 48px;
      width: 100%;
      color: ${(props) => props.theme.colors.gray[400]};

      .ms-Nav-linkText {
        overflow: hidden;
      }

      &.is-selected {
        .ms-Nav-linkText {
          color: ${(props) => props.theme.colors.purple[500]};
        }
        .ms-Nav-link {
          background-color: ${(props) => props.theme.colors.neutralLight[300]};
        }
        .ms-Nav-link .ms-Icon {
          color: ${(props) => props.theme.colors.purple[500]};
        }
        .ms-Button-flexContainer .ms-Nav-linkText {
          color: ${(props) => props.theme.colors.purple[500]};
          font-weight: 600;
        }
        .ms-Button-flexContainer i {
          color: ${(props) => props.theme.colors.purple[500]};
        }
      }

      &.is-disabled{
        ${({ hasErrorWhenDisabled, theme }) => css`

          &.is-selected .ms-Nav-link {
            background-color: ${hasErrorWhenDisabled ? theme.colors.red[200] : "transparent"};
          }

          background-color: ${hasErrorWhenDisabled ? theme.colors.red[200] : "transparent"};
          opacity: ${hasErrorWhenDisabled ? 0.3 : 1};
          cursor: default;

          & > button.is-disabled {
            :hover .ms-Icon, .ms-Icon, .ms-Icon svg path{
              color: ${hasErrorWhenDisabled ? theme.colors.red[500] : theme.colors.gray[300]};
              fill: ${hasErrorWhenDisabled ? theme.colors.red[500] : theme.colors.gray[300]};
            }
            .ms-Nav-linkText {
              color: ${hasErrorWhenDisabled ? theme.colors.red[500] : theme.colors.gray[300]};
            }
          }
        `}
      }

      &:hover:not(.is-disabled) .ms-Nav-link {
        background-color: ${(props) => props.theme.colors.neutralLight[300]};
      }

      .ms-Nav-link {
        color: ${(props) => props.theme.colors.gray[800]};

        > * > .ms-Button-icon:not(:empty) {
          margin-left: 28px;
        }
        .ms-Icon {
          color: ${(props) => props.theme.colors.gray[800]};
        }
        :hover {
          color: ${(props) => props.theme.colors.purple[500]};
          .ms-Icon {
            color: ${(props) => props.theme.colors.purple[500]};
          }
        }
        ::after {
          border-left: ${(props) => props.theme.colors.purple[500]} 4px solid;
        }
      }
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNpZGVNZW51LnN0eWxlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkLCB7IGNzcyB9IGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xuaW1wb3J0IHsgSWNvbkJ1dHRvbiB9IGZyb20gJy4uL2J1dHRvbnMnXG5pbXBvcnQgeyBDb250ZXh0dWFsTWVudSwgTmF2IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuXG5pbnRlcmZhY2UgUmV0cmFjdE1lbnVJY29uUHJvcHMge1xuICBjb2xsYXBzZWQ6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGNvbnN0IFJldHJhY3RNZW51SWNvbiA9IHN0eWxlZChJY29uQnV0dG9uKTxSZXRyYWN0TWVudUljb25Qcm9wcz5gXG4gIGJhY2tncm91bmQtY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs2MDBdfTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMzJweDtcbiAgcmlnaHQ6IC0xMnB4O1xuICB6LWluZGV4OiAxO1xuXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAzMDBtcztcblxuICAke3Byb3BzID0+ICFwcm9wcy5jb2xsYXBzZWQgJiYgY3NzYFxuICAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG4gIGB9XG5cbiAgOmhvdmVyLCA6YWN0aXZlIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbODAwXX07XG4gICAgY29sb3I6IGluaGVyaXQ7XG4gIH1cblxuICBpIHtcbiAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMud2hpdGV9O1xuICAgIGZvbnQtc2l6ZTogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5mb250U2l6ZS5zbX07XG4gIH1cbmBcblxuZXhwb3J0IGNvbnN0IEdvQmFja0J1dHRvbiA9IHN0eWxlZChJY29uQnV0dG9uKWBcbiAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbNTAwXX07XG4gIG1hcmdpbi10b3A6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuc3BhY2luZy54eGx9O1xuICBtYXJnaW4tYm90dG9tOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcubWR9O1xuXG4gIDpob3ZlciB7XG4gICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs4MDBdfTtcbiAgfVxuXG4gIDphY3RpdmUge1xuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbODAwXX07XG4gIH1cbmBcblxuZXhwb3J0IGNvbnN0IFNpZGVNZW51Q29udGFpbmVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZ2FwOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcueHN9O1xuICBoZWlnaHQ6IGluaGVyaXQ7XG4gIHBhZGRpbmctYm90dG9tOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcueGx9O1xuYFxuXG5leHBvcnQgY29uc3QgTmF2Q29udGFpbmVyID0gc3R5bGVkLmRpdmBcbiAgb3ZlcmZsb3cteTogYXV0bztcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xuYFxuXG5leHBvcnQgY29uc3QgTmF2Q29udGV4dHVhbE1lbnUgPSBzdHlsZWQoQ29udGV4dHVhbE1lbnUpYFxuICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMuZ3JheVs4MDBdfTtcblxuICA6aG92ZXIge1xuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNjAwXX07XG5cbiAgICAubXMtQ29udGV4dHVhbE1lbnUtaWNvbiB7XG4gICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzYwMF19O1xuICAgIH1cbiAgfVxuXG4gIC5tcy1Db250ZXh0dWFsTWVudS1oZWFkZXIge1xuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNjAwXX07XG4gIH1cblxuICAubXMtQ29udGV4dHVhbE1lbnUtaWNvbiB7XG4gICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLnB1cnBsZVs1MDBdfTtcbiAgfVxuYFxuXG5leHBvcnQgY29uc3QgTW9kdWxlQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgZmxleC13cmFwOiB3cmFwO1xuICBtYXJnaW4tbGVmdDogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5zcGFjaW5nLm1kfTtcbiAgbWFyZ2luLXJpZ2h0OiAke3Byb3BzID0+IHByb3BzLnRoZW1lLnNwYWNpbmcubWR9O1xuYFxuXG5pbnRlcmZhY2UgU2lkZU1lbnVOYXZQcm9wcyB7XG4gIGNvbGxhcHNlZD86IGJvb2xlYW47XG4gIGhhc0Vycm9yV2hlbkRpc2FibGVkPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNvbnN0IFNpZGVNZW51TmF2ID0gc3R5bGVkKE5hdik8U2lkZU1lbnVOYXZQcm9wcz5gXG4gICR7cHJvcHMgPT4gcHJvcHMuY29sbGFwc2VkICYmIGNzc2BcbiAgICAubXMtTmF2LWNoZXZyb25CdXR0b24ge1xuICAgICAgZGlzcGxheTogbm9uZTtcbiAgICB9XG5cbiAgICAmLm1zLU5hdiAubXMtTmF2LWNvbXBvc2l0ZUxpbmsgLm1zLU5hdi1saW5rVGV4dCB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cblxuICAgIC5tcy1OYXYtbmF2SXRlbXMgLm1zLU5hdi1uYXZJdGVtcyB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgd2lkdGg6IDFweDtcbiAgICAgIGhlaWdodDogMDtcbiAgICAgIG1hcmdpbi1sZWZ0IC0xcHg7XG4gICAgfVxuXG4gICAgJi5tcy1OYXYgLm1zLU5hdi1jb21wb3NpdGVMaW5rIC5tcy1OYXYtbGluayB7XG4gICAgICBwYWRkaW5nOiAwIDE2cHggMCAwO1xuXG4gICAgICA+ICogPiAubXMtQnV0dG9uLWljb246bm90KDplbXB0eSkge1xuICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAubXMtTmF2LWNvbXBvc2l0ZUxpbmtbZGF0YS1hY3RpdmU9J3RydWUnXSAubXMtTmF2LWxpbmsge1xuICAgICAgOjphZnRlciB7XG4gICAgICAgIGJvcmRlci1sZWZ0OiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNTAwXX0gMnB4IHNvbGlkO1xuICAgICAgICBjb250ZW50OiBcIlwiO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGluc2V0OiAwcHg7XG4gICAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgfVxuICAgIH1cblxuICBgfVxuXG4gICYubXMtTmF2IHtcbiAgICB3aWR0aDogJHtwcm9wcyA9PiBwcm9wcy5jb2xsYXBzZWQgPyAnYXV0bycgOiAnMjMwcHgnfTtcblxuICAgIC5tcy1OYXYtZ3JvdXBDb250ZW50IHtcbiAgICAgIG1hcmdpbjogMDtcbiAgICB9XG5cbiAgICAubXMtTmF2LWNvbXBvc2l0ZUxpbmt7XG4gICAgICBtYXJnaW46IDA7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5ncmF5WzQwMF19O1xuXG4gICAgICAubXMtTmF2LWxpbmtUZXh0IHtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgIH1cblxuICAgICAgJi5pcy1zZWxlY3RlZCB7XG4gICAgICAgIC5tcy1OYXYtbGlua1RleHQge1xuICAgICAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNTAwXX07XG4gICAgICAgIH1cbiAgICAgICAgLm1zLU5hdi1saW5rIHtcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5uZXV0cmFsTGlnaHRbMzAwXX07XG4gICAgICAgIH1cbiAgICAgICAgLm1zLU5hdi1saW5rIC5tcy1JY29uIHtcbiAgICAgICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzUwMF19O1xuICAgICAgICB9XG4gICAgICAgIC5tcy1CdXR0b24tZmxleENvbnRhaW5lciAubXMtTmF2LWxpbmtUZXh0IHtcbiAgICAgICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzUwMF19O1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgIH1cbiAgICAgICAgLm1zLUJ1dHRvbi1mbGV4Q29udGFpbmVyIGkge1xuICAgICAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNTAwXX07XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgJi5pcy1kaXNhYmxlZHtcbiAgICAgICAgJHsoeyBoYXNFcnJvcldoZW5EaXNhYmxlZCwgdGhlbWUgfSkgPT4gY3NzYFxuXG4gICAgICAgICAgJi5pcy1zZWxlY3RlZCAubXMtTmF2LWxpbmsge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHtoYXNFcnJvcldoZW5EaXNhYmxlZCA/IHRoZW1lLmNvbG9ycy5yZWRbMjAwXSA6ICd0cmFuc3BhcmVudCd9O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7aGFzRXJyb3JXaGVuRGlzYWJsZWQgPyB0aGVtZS5jb2xvcnMucmVkWzIwMF0gOiAndHJhbnNwYXJlbnQnfTtcbiAgICAgICAgICBvcGFjaXR5OiAke2hhc0Vycm9yV2hlbkRpc2FibGVkID8gMC4zIDogMX07XG4gICAgICAgICAgY3Vyc29yOiBkZWZhdWx0O1xuXG4gICAgICAgICAgJiA+IGJ1dHRvbi5pcy1kaXNhYmxlZCB7XG4gICAgICAgICAgICA6aG92ZXIgLm1zLUljb24sIC5tcy1JY29uLCAubXMtSWNvbiBzdmcgcGF0aHtcbiAgICAgICAgICAgICAgY29sb3I6ICR7aGFzRXJyb3JXaGVuRGlzYWJsZWQgPyB0aGVtZS5jb2xvcnMucmVkWzUwMF0gOiB0aGVtZS5jb2xvcnMuZ3JheVszMDBdfTtcbiAgICAgICAgICAgICAgZmlsbDogJHtoYXNFcnJvcldoZW5EaXNhYmxlZCA/IHRoZW1lLmNvbG9ycy5yZWRbNTAwXSA6IHRoZW1lLmNvbG9ycy5ncmF5WzMwMF19O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLm1zLU5hdi1saW5rVGV4dCB7XG4gICAgICAgICAgICAgIGNvbG9yOiAke2hhc0Vycm9yV2hlbkRpc2FibGVkID8gdGhlbWUuY29sb3JzLnJlZFs1MDBdIDogdGhlbWUuY29sb3JzLmdyYXlbMzAwXX07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICBgfVxuICAgICAgfVxuXG4gICAgICAmOmhvdmVyOm5vdCguaXMtZGlzYWJsZWQpIC5tcy1OYXYtbGluayB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLm5ldXRyYWxMaWdodFszMDBdfTtcbiAgICAgIH1cblxuICAgICAgLm1zLU5hdi1saW5rIHtcbiAgICAgICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbODAwXX07XG5cbiAgICAgICAgPiAqID4gLm1zLUJ1dHRvbi1pY29uOm5vdCg6ZW1wdHkpIHtcbiAgICAgICAgICBtYXJnaW4tbGVmdDogMjhweDtcbiAgICAgICAgfVxuICAgICAgICAubXMtSWNvbiB7XG4gICAgICAgICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMudGhlbWUuY29sb3JzLmdyYXlbODAwXX07XG4gICAgICAgIH1cbiAgICAgICAgOmhvdmVyIHtcbiAgICAgICAgICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy50aGVtZS5jb2xvcnMucHVycGxlWzUwMF19O1xuICAgICAgICAgIC5tcy1JY29uIHtcbiAgICAgICAgICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNTAwXX07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIDo6YWZ0ZXIge1xuICAgICAgICAgIGJvcmRlci1sZWZ0OiAke3Byb3BzID0+IHByb3BzLnRoZW1lLmNvbG9ycy5wdXJwbGVbNTAwXX0gNHB4IHNvbGlkO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5gXG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sVUFBVSxXQUFXO0FBQzVCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsZ0JBQWdCLFdBQVc7QUFNN0IsYUFBTSxrQkFBa0IsT0FBTyxVQUFVO0FBQUEsc0JBQzFCLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVd4RCxXQUFTLENBQUMsTUFBTSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLVCxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLakQsV0FBUyxNQUFNLE1BQU0sT0FBTztBQUFBLGlCQUN4QixXQUFTLE1BQU0sTUFBTSxTQUFTO0FBQUE7QUFBQTtBQUl4QyxhQUFNLGVBQWUsT0FBTyxVQUFVO0FBQUEsV0FDbEMsV0FBUyxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFBQSxnQkFDL0IsV0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBLG1CQUMxQixXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBLGFBR25DLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJdEMsV0FBUyxNQUFNLE1BQU0sT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBO0FBSTVDLGFBQU0sb0JBQW9CLE9BQU87QUFBQTtBQUFBO0FBQUEsU0FHL0IsV0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBO0FBQUEsb0JBRWxCLFdBQVMsTUFBTSxNQUFNLFFBQVE7QUFBQTtBQUcxQyxhQUFNLGVBQWUsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUs1QixhQUFNLG9CQUFvQixPQUFPLGNBQWM7QUFBQSxXQUMzQyxXQUFTLE1BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQSxhQUdsQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQSxlQUdwQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLeEMsV0FBUyxNQUFNLE1BQU0sT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUl0QyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFJNUMsYUFBTSxrQkFBa0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlyQixXQUFTLE1BQU0sTUFBTSxRQUFRO0FBQUEsa0JBQzVCLFdBQVMsTUFBTSxNQUFNLFFBQVE7QUFBQTtBQVF4QyxhQUFNLGNBQWMsT0FBTyxHQUFHO0FBQUEsSUFDakMsV0FBUyxNQUFNLGFBQWE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkJULENBQUFBLFdBQVNBLE9BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXaEQsV0FBUyxNQUFNLFlBQVksU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlsQyxXQUFTLE1BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUWhDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBLDhCQUczQixXQUFTLE1BQU0sTUFBTSxPQUFPLGFBQWEsR0FBRztBQUFBO0FBQUE7QUFBQSxtQkFHdkQsV0FBUyxNQUFNLE1BQU0sT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBO0FBQUEsbUJBR3RDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSXRDLFdBQVMsTUFBTSxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUsvQyxDQUFDLEVBQUUsc0JBQXNCLE1BQU0sTUFBTTtBQUFBO0FBQUE7QUFBQSxnQ0FHZix1QkFBdUIsTUFBTSxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUE7QUFBQTtBQUFBLDhCQUdqRCx1QkFBdUIsTUFBTSxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEscUJBQ3hELHVCQUF1QixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLM0IsdUJBQXVCLE1BQU0sT0FBTyxJQUFJLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUEsc0JBQ3JFLHVCQUF1QixNQUFNLE9BQU8sSUFBSSxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQSx1QkFHbkUsdUJBQXVCLE1BQU0sT0FBTyxJQUFJLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTy9ELFdBQVMsTUFBTSxNQUFNLE9BQU8sYUFBYSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSXZELFdBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1sQyxXQUFTLE1BQU0sTUFBTSxPQUFPLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQSxtQkFHcEMsV0FBUyxNQUFNLE1BQU0sT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBLHFCQUVwQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlsQyxXQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7IiwibmFtZXMiOlsicHJvcHMiXX0=