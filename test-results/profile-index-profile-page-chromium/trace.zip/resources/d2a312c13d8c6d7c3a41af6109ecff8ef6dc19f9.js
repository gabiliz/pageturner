import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/SideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { ContextualMenuItemType, DirectionalHint } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport4_react["useContext"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn } from "/src/shared/components/FlexBox/index.ts";
import AppModuleTitle from "/src/shared/components/modules/AppModuleTitle.tsx";
import { Spinner } from "/src/shared/components/spinner/index.ts";
import { GoBackButton, ModuleContainer, NavContainer, NavContextualMenu, RetractMenuIcon, SideMenuContainer, SideMenuNav } from "/src/shared/components/layout/SideMenu.styles.ts?t=1701096626433";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { usePersistedState } from "/src/shared/hooks/persistedState.ts";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
const SIDE_MENU_STORAGE_KEY = "@auditores:side-menu-collapsed.v1";
const SideMenu = ({
  defaultCollapsed,
  disabledCollapse,
  hasErrorWhenDisabled,
  ...props
}) => {
  _s();
  const {
    spacing,
    colors
  } = useTheme();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    menuCollapsed
  } = useContext(LoadingDataContext);
  const [contextMenuVisible, {
    toggle: toggleContextualMenu,
    setFalse: dismissContextualMenu
  }] = useBoolean(false);
  const [contextMenuTarget, setTarget] = useState();
  const [collapsed, setCollapsed] = usePersistedState(SIDE_MENU_STORAGE_KEY, !!defaultCollapsed);
  useEffect(() => {
    if (disabledCollapse) {
      setCollapsed(false);
    }
    if (defaultCollapsed) {
      setCollapsed(true);
    }
    if (menuCollapsed) {
      setCollapsed(menuCollapsed);
    }
  }, [disabledCollapse, menuCollapsed]);
  const [contextualMenuItems, setContextualMenuItems] = useState([]);
  const toggleRetract = () => setCollapsed((state) => !state);
  const defineMenuItems = (title, navItems) => {
    const items = [];
    items.push({
      text: title,
      key: `header_${title}`,
      itemType: ContextualMenuItemType.Header
    });
    navItems.forEach((item) => {
      items.push({
        text: item.name,
        key: item.key,
        onClick: () => navigate(item.url),
        iconProps: {
          iconName: item.icon
        }
      });
    });
    setContextualMenuItems(items);
  };
  const handleLinkExpand = (ev, item) => {
    if (!collapsed || !ev)
      return;
    setTarget(`.ms-Nav-link[title='${item?.name}']`);
    toggleContextualMenu();
    defineMenuItems(item?.name, item?.links);
  };
  const verifyIsCollapseMenuActive = () => {
    props.groups?.forEach((item) => {
      const linkItem = item?.links?.[0];
      if (linkItem?.links) {
        const selectedNav = document.querySelector(`.ms-Nav-compositeLink[name='${linkItem?.name}']`);
        if (linkItem.links?.some((link) => pathname.includes(link?.key || ""))) {
          selectedNav?.setAttribute("data-active", "true");
        } else {
          selectedNav?.removeAttribute("data-active");
        }
      }
    });
  };
  useEffect(() => {
    if (collapsed)
      verifyIsCollapseMenuActive();
  }, [verifyIsCollapseMenuActive]);
  return /* @__PURE__ */ jsxDEV(SideMenuContainer, { children: [
    !disabledCollapse && /* @__PURE__ */ jsxDEV(RetractMenuIcon, { collapsed: defaultCollapsed || collapsed, iconProps: {
      iconName: "ChevronRight"
    }, onClick: toggleRetract, disabled: defaultCollapsed, style: {
      background: defaultCollapsed ? colors.neutralLight[600] : ""
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 102,
      columnNumber: 29
    }, this),
    /* @__PURE__ */ jsxDEV(FlexColumn, { gap: spacing.xs, children: [
      /* @__PURE__ */ jsxDEV(ModuleContainer, { children: [
        props.goBack && /* @__PURE__ */ jsxDEV(GoBackButton, { iconProps: {
          iconName: "Arrow-left"
        }, onClick: props.goBack }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
          lineNumber: 109,
          columnNumber: 28
        }, this),
        !(defaultCollapsed || collapsed) && /* @__PURE__ */ jsxDEV(AppModuleTitle, { title: props.title }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
          lineNumber: 113,
          columnNumber: 48
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
        lineNumber: 108,
        columnNumber: 9
      }, this),
      props.subtitle && !(defaultCollapsed || collapsed) && props.subtitle
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this),
    props.isLoading ? /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", styles: {
      overflow: "hidden"
    }, children: /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 122,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 119,
      columnNumber: 26
    }, this) : /* @__PURE__ */ jsxDEV(NavContainer, { children: /* @__PURE__ */ jsxDEV(SideMenuNav, { hasErrorWhenDisabled, collapsed: defaultCollapsed || collapsed, onLinkExpandClick: handleLinkExpand, groups: props.groups, onLinkClick: props.onLinkClick, selectedKey: props.selectedKey }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 124,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 123,
      columnNumber: 25
    }, this),
    contextMenuVisible && collapsed && /* @__PURE__ */ jsxDEV(NavContextualMenu, { items: contextualMenuItems, hidden: !contextMenuVisible, target: contextMenuTarget, directionalHint: DirectionalHint.rightTopEdge, onDismiss: dismissContextualMenu }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
      lineNumber: 127,
      columnNumber: 43
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx",
    lineNumber: 101,
    columnNumber: 10
  }, this);
};
_s(SideMenu, "kDw6K8pOKHllTTM3ODwsTuk2msM=", false, function() {
  return [useTheme, useNavigate, useLocation, useBoolean, usePersistedState];
});
_c = SideMenu;
export default SideMenu;
var _c;
$RefreshReg$(_c, "SideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0hROzs7Ozs7Ozs7Ozs7Ozs7O0FBeEhSLFNBQ0VBLHdCQUNBQyx1QkFLSztBQUNQLFNBQStDQyxZQUFZQyxXQUFXQyxnQkFBZ0I7QUFDdEYsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxjQUFjQyxpQkFBaUJDLGNBQWNDLG1CQUFtQkMsaUJBQWlCQyxtQkFBbUJDLG1CQUFtQjtBQUNoSSxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywwQkFBMEI7QUFZbkMsTUFBTUMsd0JBQXdCO0FBRTlCLE1BQU1DLFdBQThCQSxDQUFDO0FBQUEsRUFDbkNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0EsR0FBR0M7QUFDTCxNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBU0M7QUFBQUEsRUFBTyxJQUFJeEIsU0FBUztBQUNyQyxRQUFNeUIsV0FBV1osWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRWE7QUFBQUEsRUFBUyxJQUFJZCxZQUFZO0FBQ2pDLFFBQU07QUFBQSxJQUFFZTtBQUFBQSxFQUFjLElBQUk5QixXQUFXa0Isa0JBQWtCO0FBRXZELFFBQU0sQ0FDSmEsb0JBQ0E7QUFBQSxJQUFFQyxRQUFRQztBQUFBQSxJQUFzQkMsVUFBVUM7QUFBQUEsRUFBc0IsQ0FBQyxJQUMvRHJCLFdBQVcsS0FBSztBQUVwQixRQUFNLENBQUNzQixtQkFBbUJDLFNBQVMsSUFBSW5DLFNBQTZCO0FBRXBFLFFBQU0sQ0FDSm9DLFdBQ0FDLFlBQVksSUFDVnRCLGtCQUEyQkUsdUJBQXVCLENBQUMsQ0FBRUUsZ0JBQWlCO0FBRTFFcEIsWUFBVSxNQUFNO0FBQ2QsUUFBSXFCLGtCQUFrQjtBQUNwQmlCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUNBLFFBQUlsQixrQkFBa0I7QUFDcEJrQixtQkFBYSxJQUFJO0FBQUEsSUFDbkI7QUFDQSxRQUFJVCxlQUFlO0FBQ2pCUyxtQkFBYVQsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRixHQUFHLENBQUNSLGtCQUFrQlEsYUFBYSxDQUFDO0FBRXBDLFFBQU0sQ0FBQ1UscUJBQXFCQyxzQkFBc0IsSUFBSXZDLFNBQWdDLEVBQUU7QUFFeEYsUUFBTXdDLGdCQUFnQkEsTUFBTUgsYUFBYUksV0FBUyxDQUFDQSxLQUFLO0FBRXhELFFBQU1DLGtCQUFrQkEsQ0FBQ0MsT0FBZUMsYUFBeUI7QUFDL0QsVUFBTUMsUUFBK0I7QUFFckNBLFVBQU1DLEtBQUs7QUFBQSxNQUNUQyxNQUFNSjtBQUFBQSxNQUNOSyxLQUFNLFVBQVNMO0FBQUFBLE1BQ2ZNLFVBQVVyRCx1QkFBdUJzRDtBQUFBQSxJQUNuQyxDQUFDO0FBRUROLGFBQVNPLFFBQVFDLFVBQVE7QUFDdkJQLFlBQU1DLEtBQUs7QUFBQSxRQUNUQyxNQUFNSyxLQUFLQztBQUFBQSxRQUNYTCxLQUFLSSxLQUFLSjtBQUFBQSxRQUNWTSxTQUFTQSxNQUFNNUIsU0FBUzBCLEtBQUtHLEdBQUc7QUFBQSxRQUNoQ0MsV0FBVztBQUFBLFVBQUVDLFVBQVVMLEtBQUtNO0FBQUFBLFFBQUs7QUFBQSxNQUNuQyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQ0RuQiwyQkFBdUJNLEtBQUs7QUFBQSxFQUM5QjtBQUVBLFFBQU1jLG1CQUFtQkEsQ0FBQ0MsSUFBdUNSLFNBQW9CO0FBQ25GLFFBQUksQ0FBQ2hCLGFBQWEsQ0FBQ3dCO0FBQUk7QUFFdkJ6QixjQUFXLHVCQUFzQmlCLE1BQU1DLFFBQVE7QUFFL0N0Qix5QkFBcUI7QUFDckJXLG9CQUFnQlUsTUFBTUMsTUFBZ0JELE1BQU1TLEtBQW1CO0FBQUEsRUFDakU7QUFFQSxRQUFNQyw2QkFBNkJBLE1BQU07QUFDdkN4QyxVQUFNeUMsUUFBUVosUUFBUUMsVUFBUTtBQUM1QixZQUFNWSxXQUFXWixNQUFNUyxRQUFRLENBQUM7QUFDaEMsVUFBSUcsVUFBVUgsT0FBTztBQUNuQixjQUFNSSxjQUFjQyxTQUFTQyxjQUFlLCtCQUE4QkgsVUFBVVgsUUFBUTtBQUM1RixZQUFJVyxTQUFTSCxPQUFPTyxLQUFLQyxVQUFRMUMsU0FBUzJDLFNBQVNELE1BQU1yQixPQUFPLEVBQUUsQ0FBQyxHQUFHO0FBQ3BFaUIsdUJBQWFNLGFBQWEsZUFBZSxNQUFNO0FBQUEsUUFDakQsT0FBTztBQUNMTix1QkFBYU8sZ0JBQWdCLGFBQWE7QUFBQSxRQUM1QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUF6RSxZQUFVLE1BQU07QUFDZCxRQUFJcUM7QUFBVzBCLGlDQUEyQjtBQUFBLEVBQzVDLEdBQUcsQ0FBQ0EsMEJBQTBCLENBQUM7QUFFL0IsU0FDRSx1QkFBQyxxQkFDRTtBQUFBLEtBQUMxQyxvQkFDQSx1QkFBQyxtQkFDQyxXQUFXRCxvQkFBb0JpQixXQUMvQixXQUFXO0FBQUEsTUFBRXFCLFVBQVU7QUFBQSxJQUFlLEdBQ3RDLFNBQVNqQixlQUNULFVBQVVyQixrQkFDVixPQUFPO0FBQUEsTUFDTHNELFlBQVl0RCxtQkFBbUJNLE9BQU9pRCxhQUFhLEdBQUcsSUFBSTtBQUFBLElBQzVELEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9JO0FBQUEsSUFHTix1QkFBQyxjQUFXLEtBQUtsRCxRQUFRbUQsSUFDdkI7QUFBQSw2QkFBQyxtQkFDRXJEO0FBQUFBLGNBQU1zRCxVQUNOLHVCQUFDLGdCQUNDLFdBQVc7QUFBQSxVQUFFbkIsVUFBVTtBQUFBLFFBQWEsR0FDcEMsU0FBU25DLE1BQU1zRCxVQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRXdCO0FBQUEsUUFJeEIsRUFBRXpELG9CQUFvQmlCLGNBQWMsdUJBQUMsa0JBQWUsT0FBT2QsTUFBTXFCLFNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxXQVIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVFckIsTUFBTXVELFlBQVksRUFBRTFELG9CQUFvQmlCLGNBQWVkLE1BQU11RDtBQUFBQSxTQVpqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVDdkQsTUFBTXdELFlBQ0gsdUJBQUMsY0FDRCxpQkFBZ0IsVUFDaEIsUUFBUTtBQUFBLE1BQUVDLFVBQVU7QUFBQSxJQUFTLEdBRTdCLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRLEtBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtGLElBQ0UsdUJBQUMsZ0JBQ0QsaUNBQUMsZUFDQyxzQkFDQSxXQUFXNUQsb0JBQW9CaUIsV0FDL0IsbUJBQW1CdUIsa0JBQ25CLFFBQVFyQyxNQUFNeUMsUUFDZCxhQUFhekMsTUFBTTBELGFBQ25CLGFBQWExRCxNQUFNMkQsZUFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1pQyxLQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0Y7QUFBQSxJQUdEcEQsc0JBQXNCTyxhQUN0Qix1QkFBQyxxQkFDQyxPQUFPRSxxQkFDUCxRQUFRLENBQUNULG9CQUNULFFBQVFLLG1CQUNSLGlCQUFpQnJDLGdCQUFnQnFGLGNBQ2pDLFdBQVdqRCx5QkFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS21DO0FBQUEsT0FwRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1REE7QUFFSjtBQUFDVixHQWhKS0wsVUFBMkI7QUFBQSxVQU1IakIsVUFDWGEsYUFDSUQsYUFNakJELFlBT0FHLGlCQUFpQjtBQUFBO0FBQUFvRSxLQXJCakJqRTtBQWtKTixlQUFlQTtBQUFRLElBQUFpRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udGV4dHVhbE1lbnVJdGVtVHlwZSIsIkRpcmVjdGlvbmFsSGludCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVRoZW1lIiwiRmxleENvbHVtbiIsIkFwcE1vZHVsZVRpdGxlIiwiU3Bpbm5lciIsIkdvQmFja0J1dHRvbiIsIk1vZHVsZUNvbnRhaW5lciIsIk5hdkNvbnRhaW5lciIsIk5hdkNvbnRleHR1YWxNZW51IiwiUmV0cmFjdE1lbnVJY29uIiwiU2lkZU1lbnVDb250YWluZXIiLCJTaWRlTWVudU5hdiIsInVzZUJvb2xlYW4iLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGVyc2lzdGVkU3RhdGUiLCJMb2FkaW5nRGF0YUNvbnRleHQiLCJTSURFX01FTlVfU1RPUkFHRV9LRVkiLCJTaWRlTWVudSIsImRlZmF1bHRDb2xsYXBzZWQiLCJkaXNhYmxlZENvbGxhcHNlIiwiaGFzRXJyb3JXaGVuRGlzYWJsZWQiLCJwcm9wcyIsIl9zIiwic3BhY2luZyIsImNvbG9ycyIsIm5hdmlnYXRlIiwicGF0aG5hbWUiLCJtZW51Q29sbGFwc2VkIiwiY29udGV4dE1lbnVWaXNpYmxlIiwidG9nZ2xlIiwidG9nZ2xlQ29udGV4dHVhbE1lbnUiLCJzZXRGYWxzZSIsImRpc21pc3NDb250ZXh0dWFsTWVudSIsImNvbnRleHRNZW51VGFyZ2V0Iiwic2V0VGFyZ2V0IiwiY29sbGFwc2VkIiwic2V0Q29sbGFwc2VkIiwiY29udGV4dHVhbE1lbnVJdGVtcyIsInNldENvbnRleHR1YWxNZW51SXRlbXMiLCJ0b2dnbGVSZXRyYWN0Iiwic3RhdGUiLCJkZWZpbmVNZW51SXRlbXMiLCJ0aXRsZSIsIm5hdkl0ZW1zIiwiaXRlbXMiLCJwdXNoIiwidGV4dCIsImtleSIsIml0ZW1UeXBlIiwiSGVhZGVyIiwiZm9yRWFjaCIsIml0ZW0iLCJuYW1lIiwib25DbGljayIsInVybCIsImljb25Qcm9wcyIsImljb25OYW1lIiwiaWNvbiIsImhhbmRsZUxpbmtFeHBhbmQiLCJldiIsImxpbmtzIiwidmVyaWZ5SXNDb2xsYXBzZU1lbnVBY3RpdmUiLCJncm91cHMiLCJsaW5rSXRlbSIsInNlbGVjdGVkTmF2IiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwic29tZSIsImxpbmsiLCJpbmNsdWRlcyIsInNldEF0dHJpYnV0ZSIsInJlbW92ZUF0dHJpYnV0ZSIsImJhY2tncm91bmQiLCJuZXV0cmFsTGlnaHQiLCJ4cyIsImdvQmFjayIsInN1YnRpdGxlIiwiaXNMb2FkaW5nIiwib3ZlcmZsb3ciLCJvbkxpbmtDbGljayIsInNlbGVjdGVkS2V5IiwicmlnaHRUb3BFZGdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9sYXlvdXQvU2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ29udGV4dHVhbE1lbnVJdGVtVHlwZSxcbiAgRGlyZWN0aW9uYWxIaW50LFxuICBJQ29udGV4dHVhbE1lbnVJdGVtLFxuICBJTmF2TGluayxcbiAgSU5hdlByb3BzLFxuICBUYXJnZXQsXG59IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcbmltcG9ydCB7IEZDLCBNb3VzZUV2ZW50IGFzIE1vdXNlRXYsIFJlYWN0Tm9kZSwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEZsZXhDb2x1bW4gfSBmcm9tICcuLi9GbGV4Qm94J1xuaW1wb3J0IEFwcE1vZHVsZVRpdGxlIGZyb20gJy4uL21vZHVsZXMvQXBwTW9kdWxlVGl0bGUnXG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnLi4vc3Bpbm5lcidcbmltcG9ydCB7IEdvQmFja0J1dHRvbiwgTW9kdWxlQ29udGFpbmVyLCBOYXZDb250YWluZXIsIE5hdkNvbnRleHR1YWxNZW51LCBSZXRyYWN0TWVudUljb24sIFNpZGVNZW51Q29udGFpbmVyLCBTaWRlTWVudU5hdiB9IGZyb20gJy4vU2lkZU1lbnUuc3R5bGVzJ1xuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VQZXJzaXN0ZWRTdGF0ZSB9IGZyb20gJy4uLy4uL2hvb2tzL3BlcnNpc3RlZFN0YXRlJ1xuaW1wb3J0IHsgTG9hZGluZ0RhdGFDb250ZXh0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9Mb2FkaW5nRGF0YUNvbnRleHQnXG5cbmludGVyZmFjZSBTaWRlTWVudVByb3BzIGV4dGVuZHMgSU5hdlByb3BzIHtcbiAgdGl0bGU6IHN0cmluZyxcbiAgZ29CYWNrPzogKCkgPT4gdm9pZFxuICBzdWJ0aXRsZT86IHN0cmluZ3xSZWFjdE5vZGVcbiAgaXNMb2FkaW5nPzogYm9vbGVhblxuICBkZWZhdWx0Q29sbGFwc2VkPzogYm9vbGVhblxuICBkaXNhYmxlZENvbGxhcHNlPzogYm9vbGVhblxuICBoYXNFcnJvcldoZW5EaXNhYmxlZD86IGJvb2xlYW5cbn1cblxuY29uc3QgU0lERV9NRU5VX1NUT1JBR0VfS0VZID0gJ0BhdWRpdG9yZXM6c2lkZS1tZW51LWNvbGxhcHNlZC52MSdcblxuY29uc3QgU2lkZU1lbnU6IEZDPFNpZGVNZW51UHJvcHM+ID0gKHtcbiAgZGVmYXVsdENvbGxhcHNlZCxcbiAgZGlzYWJsZWRDb2xsYXBzZSxcbiAgaGFzRXJyb3JXaGVuRGlzYWJsZWQsXG4gIC4uLnByb3BzXG59KSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IHsgbWVudUNvbGxhcHNlZCB9ID0gdXNlQ29udGV4dChMb2FkaW5nRGF0YUNvbnRleHQpXG5cbiAgY29uc3QgW1xuICAgIGNvbnRleHRNZW51VmlzaWJsZSxcbiAgICB7IHRvZ2dsZTogdG9nZ2xlQ29udGV4dHVhbE1lbnUsIHNldEZhbHNlOiBkaXNtaXNzQ29udGV4dHVhbE1lbnUgfSxcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXG5cbiAgY29uc3QgW2NvbnRleHRNZW51VGFyZ2V0LCBzZXRUYXJnZXRdID0gdXNlU3RhdGU8VGFyZ2V0IHwgdW5kZWZpbmVkPigpXG5cbiAgY29uc3QgW1xuICAgIGNvbGxhcHNlZCxcbiAgICBzZXRDb2xsYXBzZWQsXG4gIF0gPSB1c2VQZXJzaXN0ZWRTdGF0ZTxib29sZWFuPihTSURFX01FTlVfU1RPUkFHRV9LRVksICEhKGRlZmF1bHRDb2xsYXBzZWQpKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkQ29sbGFwc2UpIHtcbiAgICAgIHNldENvbGxhcHNlZChmYWxzZSlcbiAgICB9XG4gICAgaWYgKGRlZmF1bHRDb2xsYXBzZWQpIHtcbiAgICAgIHNldENvbGxhcHNlZCh0cnVlKVxuICAgIH1cbiAgICBpZiAobWVudUNvbGxhcHNlZCkge1xuICAgICAgc2V0Q29sbGFwc2VkKG1lbnVDb2xsYXBzZWQpXG4gICAgfVxuICB9LCBbZGlzYWJsZWRDb2xsYXBzZSwgbWVudUNvbGxhcHNlZF0pXG5cbiAgY29uc3QgW2NvbnRleHR1YWxNZW51SXRlbXMsIHNldENvbnRleHR1YWxNZW51SXRlbXNdID0gdXNlU3RhdGU8SUNvbnRleHR1YWxNZW51SXRlbVtdPihbXSlcblxuICBjb25zdCB0b2dnbGVSZXRyYWN0ID0gKCkgPT4gc2V0Q29sbGFwc2VkKHN0YXRlID0+ICFzdGF0ZSlcblxuICBjb25zdCBkZWZpbmVNZW51SXRlbXMgPSAodGl0bGU6IHN0cmluZywgbmF2SXRlbXM6IElOYXZMaW5rW10pID0+IHtcbiAgICBjb25zdCBpdGVtczogSUNvbnRleHR1YWxNZW51SXRlbVtdID0gW11cblxuICAgIGl0ZW1zLnB1c2goe1xuICAgICAgdGV4dDogdGl0bGUsXG4gICAgICBrZXk6IGBoZWFkZXJfJHt0aXRsZX1gLFxuICAgICAgaXRlbVR5cGU6IENvbnRleHR1YWxNZW51SXRlbVR5cGUuSGVhZGVyLFxuICAgIH0pXG5cbiAgICBuYXZJdGVtcy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgIHRleHQ6IGl0ZW0ubmFtZSxcbiAgICAgICAga2V5OiBpdGVtLmtleSBhcyBzdHJpbmcsXG4gICAgICAgIG9uQ2xpY2s6ICgpID0+IG5hdmlnYXRlKGl0ZW0udXJsKSxcbiAgICAgICAgaWNvblByb3BzOiB7IGljb25OYW1lOiBpdGVtLmljb24gfSxcbiAgICAgIH0pXG4gICAgfSlcbiAgICBzZXRDb250ZXh0dWFsTWVudUl0ZW1zKGl0ZW1zKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTGlua0V4cGFuZCA9IChldj86IE1vdXNlRXY8SFRNTEVsZW1lbnQsIE1vdXNlRXZlbnQ+LCBpdGVtPzogSU5hdkxpbmspID0+IHtcbiAgICBpZiAoIWNvbGxhcHNlZCB8fCAhZXYpIHJldHVyblxuXG4gICAgc2V0VGFyZ2V0KGAubXMtTmF2LWxpbmtbdGl0bGU9JyR7aXRlbT8ubmFtZX0nXWApXG5cbiAgICB0b2dnbGVDb250ZXh0dWFsTWVudSgpXG4gICAgZGVmaW5lTWVudUl0ZW1zKGl0ZW0/Lm5hbWUgYXMgc3RyaW5nLCBpdGVtPy5saW5rcyBhcyBJTmF2TGlua1tdKVxuICB9XG5cbiAgY29uc3QgdmVyaWZ5SXNDb2xsYXBzZU1lbnVBY3RpdmUgPSAoKSA9PiB7XG4gICAgcHJvcHMuZ3JvdXBzPy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgY29uc3QgbGlua0l0ZW0gPSBpdGVtPy5saW5rcz8uWzBdXG4gICAgICBpZiAobGlua0l0ZW0/LmxpbmtzKSB7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkTmF2ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgLm1zLU5hdi1jb21wb3NpdGVMaW5rW25hbWU9JyR7bGlua0l0ZW0/Lm5hbWV9J11gKVxuICAgICAgICBpZiAobGlua0l0ZW0ubGlua3M/LnNvbWUobGluayA9PiBwYXRobmFtZS5pbmNsdWRlcyhsaW5rPy5rZXkgfHwgJycpKSkge1xuICAgICAgICAgIHNlbGVjdGVkTmF2Py5zZXRBdHRyaWJ1dGUoJ2RhdGEtYWN0aXZlJywgJ3RydWUnKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbGVjdGVkTmF2Py5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtYWN0aXZlJylcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjb2xsYXBzZWQpIHZlcmlmeUlzQ29sbGFwc2VNZW51QWN0aXZlKClcbiAgfSwgW3ZlcmlmeUlzQ29sbGFwc2VNZW51QWN0aXZlXSlcblxuICByZXR1cm4gKFxuICAgIDxTaWRlTWVudUNvbnRhaW5lcj5cbiAgICAgIHshZGlzYWJsZWRDb2xsYXBzZSAmJlxuICAgICAgICA8UmV0cmFjdE1lbnVJY29uXG4gICAgICAgICAgY29sbGFwc2VkPXtkZWZhdWx0Q29sbGFwc2VkIHx8IGNvbGxhcHNlZH1cbiAgICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdDaGV2cm9uUmlnaHQnIH19XG4gICAgICAgICAgb25DbGljaz17dG9nZ2xlUmV0cmFjdH1cbiAgICAgICAgICBkaXNhYmxlZD17ZGVmYXVsdENvbGxhcHNlZH1cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgYmFja2dyb3VuZDogZGVmYXVsdENvbGxhcHNlZCA/IGNvbG9ycy5uZXV0cmFsTGlnaHRbNjAwXSA6ICcnLFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICB9XG4gICAgICA8RmxleENvbHVtbiBnYXA9e3NwYWNpbmcueHN9PlxuICAgICAgICA8TW9kdWxlQ29udGFpbmVyPlxuICAgICAgICAgIHtwcm9wcy5nb0JhY2sgJiZcbiAgICAgICAgICAgPEdvQmFja0J1dHRvblxuICAgICAgICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0Fycm93LWxlZnQnIH19XG4gICAgICAgICAgICAgb25DbGljaz17cHJvcHMuZ29CYWNrfVxuICAgICAgICAgICAvPlxuICAgICAgICAgIH1cblxuICAgICAgICAgIHshKGRlZmF1bHRDb2xsYXBzZWQgfHwgY29sbGFwc2VkKSAmJiA8QXBwTW9kdWxlVGl0bGUgdGl0bGU9e3Byb3BzLnRpdGxlfS8+fVxuICAgICAgICA8L01vZHVsZUNvbnRhaW5lcj5cblxuICAgICAgICB7KHByb3BzLnN1YnRpdGxlICYmICEoZGVmYXVsdENvbGxhcHNlZCB8fCBjb2xsYXBzZWQpKSAmJiBwcm9wcy5zdWJ0aXRsZX1cbiAgICAgIDwvRmxleENvbHVtbj5cblxuICAgICAge3Byb3BzLmlzTG9hZGluZ1xuICAgICAgICA/IDxGbGV4Q29sdW1uXG4gICAgICAgICAgaG9yaXpvbnRhbEFsaWduPSdjZW50ZXInXG4gICAgICAgICAgc3R5bGVzPXt7IG92ZXJmbG93OiAnaGlkZGVuJyB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFNwaW5uZXIgLz5cbiAgICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAgICA6IDxOYXZDb250YWluZXI+XG4gICAgICAgICAgPFNpZGVNZW51TmF2XG4gICAgICAgICAgICBoYXNFcnJvcldoZW5EaXNhYmxlZD17aGFzRXJyb3JXaGVuRGlzYWJsZWR9XG4gICAgICAgICAgICBjb2xsYXBzZWQ9e2RlZmF1bHRDb2xsYXBzZWQgfHwgY29sbGFwc2VkfVxuICAgICAgICAgICAgb25MaW5rRXhwYW5kQ2xpY2s9e2hhbmRsZUxpbmtFeHBhbmR9XG4gICAgICAgICAgICBncm91cHM9e3Byb3BzLmdyb3Vwc31cbiAgICAgICAgICAgIG9uTGlua0NsaWNrPXtwcm9wcy5vbkxpbmtDbGlja31cbiAgICAgICAgICAgIHNlbGVjdGVkS2V5PXtwcm9wcy5zZWxlY3RlZEtleX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L05hdkNvbnRhaW5lcj5cbiAgICAgIH1cblxuICAgICAge2NvbnRleHRNZW51VmlzaWJsZSAmJiBjb2xsYXBzZWQgJiZcbiAgICAgICA8TmF2Q29udGV4dHVhbE1lbnVcbiAgICAgICAgIGl0ZW1zPXtjb250ZXh0dWFsTWVudUl0ZW1zfVxuICAgICAgICAgaGlkZGVuPXshY29udGV4dE1lbnVWaXNpYmxlfVxuICAgICAgICAgdGFyZ2V0PXtjb250ZXh0TWVudVRhcmdldH1cbiAgICAgICAgIGRpcmVjdGlvbmFsSGludD17RGlyZWN0aW9uYWxIaW50LnJpZ2h0VG9wRWRnZX1cbiAgICAgICAgIG9uRGlzbWlzcz17ZGlzbWlzc0NvbnRleHR1YWxNZW51fVxuICAgICAgIC8+XG4gICAgICB9XG4gICAgPC9TaWRlTWVudUNvbnRhaW5lcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBTaWRlTWVudVxuIl19