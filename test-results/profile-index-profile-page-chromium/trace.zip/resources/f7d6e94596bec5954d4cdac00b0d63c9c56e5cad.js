import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/choiceGroup/ChoiceGroup.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/ChoiceGroup.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ChoiceGroup as Radio } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_merge-styles.js?v=9f90a7ff";
import { useThemeColors } from "/src/shared/hooks/index.ts";
const ChoiceGroup = (props) => {
  _s();
  const styles = useStyles(props);
  return /* @__PURE__ */ jsxDEV(Radio, { ...props, className: styles.container }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/ChoiceGroup.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
};
_s(ChoiceGroup, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = ChoiceGroup;
export default ChoiceGroup;
const useStyles = (props) => {
  _s2();
  const {
    disabled
  } = props;
  const colors = useThemeColors();
  return mergeStyleSets({
    container: {
      ".is-checked::after": {
        borderColor: disabled ? colors.gray[600] : props.color ? props.color : colors.primary
      },
      ".is-checked::before": {
        borderColor: disabled ? colors.gray[600] : props.color ? props.color : colors.primary
      },
      ".is-checked:hover::after": {
        borderColor: disabled ? colors.gray[600] : props.color ? props.color : colors.purple[600]
      },
      ".is-checked:hover::before": {
        borderColor: disabled ? colors.gray[600] : props.color ? props.color : colors.purple[600]
      }
    }
  });
};
_s2(useStyles, "Px6fgPPjYcBsu3RBjpFAm2DJYxg=", false, function() {
  return [useThemeColors];
});
var _c;
$RefreshReg$(_c, "ChoiceGroup");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/choiceGroup/ChoiceGroup.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYSixTQUFTQSxlQUFlQyxhQUFnQztBQUN4RCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msc0JBQXNCO0FBTS9CLE1BQU1ILGNBQXFDSSxXQUFVO0FBQUFDLEtBQUE7QUFDbkQsUUFBTUMsU0FBU0MsVUFBVUgsS0FBSztBQUM5QixTQUNFLHVCQUFDLFNBQU0sR0FBSUEsT0FBTyxXQUFXRSxPQUFPRSxhQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThDO0FBRWxEO0FBQUNILEdBTEtMLGFBQWlDO0FBQUEsVUFDdEJPLFNBQVM7QUFBQTtBQUFBRSxLQURwQlQ7QUFPTixlQUFlQTtBQUVmLE1BQU1PLFlBQVlBLENBQUNILFVBQTRCO0FBQUFNLE1BQUE7QUFDN0MsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVMsSUFBSVA7QUFDckIsUUFBTVEsU0FBU1QsZUFBZTtBQUM5QixTQUFPRCxlQUFlO0FBQUEsSUFDcEJNLFdBQVc7QUFBQSxNQUNULHNCQUFzQjtBQUFBLFFBQ3BCSyxhQUFhRixXQUFXQyxPQUFPRSxLQUFLLEdBQUcsSUFBSVYsTUFBTVcsUUFBUVgsTUFBTVcsUUFBUUgsT0FBT0k7QUFBQUEsTUFDaEY7QUFBQSxNQUNBLHVCQUF1QjtBQUFBLFFBQ3JCSCxhQUFhRixXQUFXQyxPQUFPRSxLQUFLLEdBQUcsSUFBSVYsTUFBTVcsUUFBUVgsTUFBTVcsUUFBUUgsT0FBT0k7QUFBQUEsTUFDaEY7QUFBQSxNQUNBLDRCQUE0QjtBQUFBLFFBQzFCSCxhQUFhRixXQUFXQyxPQUFPRSxLQUFLLEdBQUcsSUFBSVYsTUFBTVcsUUFBUVgsTUFBTVcsUUFBUUgsT0FBT0ssT0FBTyxHQUFHO0FBQUEsTUFDMUY7QUFBQSxNQUNBLDZCQUE2QjtBQUFBLFFBQzNCSixhQUFhRixXQUFXQyxPQUFPRSxLQUFLLEdBQUcsSUFBSVYsTUFBTVcsUUFBUVgsTUFBTVcsUUFBUUgsT0FBT0ssT0FBTyxHQUFHO0FBQUEsTUFDMUY7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ1AsSUFuQktILFdBQVM7QUFBQSxVQUVFSixjQUFjO0FBQUE7QUFBQSxJQUFBTTtBQUFBUyxhQUFBVCxJQUFBIiwibmFtZXMiOlsiQ2hvaWNlR3JvdXAiLCJSYWRpbyIsIm1lcmdlU3R5bGVTZXRzIiwidXNlVGhlbWVDb2xvcnMiLCJwcm9wcyIsIl9zIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiY29udGFpbmVyIiwiX2MiLCJfczIiLCJkaXNhYmxlZCIsImNvbG9ycyIsImJvcmRlckNvbG9yIiwiZ3JheSIsImNvbG9yIiwicHJpbWFyeSIsInB1cnBsZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNob2ljZUdyb3VwLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2Nob2ljZUdyb3VwL0Nob2ljZUdyb3VwLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDaG9pY2VHcm91cCBhcyBSYWRpbywgSUNob2ljZUdyb3VwUHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9tZXJnZS1zdHlsZXMnXG5pbXBvcnQgeyB1c2VUaGVtZUNvbG9ycyB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5pbnRlcmZhY2UgQ2hvaWNlR3JvdXBQcm9wcyBleHRlbmRzIElDaG9pY2VHcm91cFByb3BzIHtcbiAgY29sb3I/OiBzdHJpbmdcbn1cblxuY29uc3QgQ2hvaWNlR3JvdXA6RkM8SUNob2ljZUdyb3VwUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlcyhwcm9wcylcbiAgcmV0dXJuIChcbiAgICA8UmFkaW8gey4uLnByb3BzfSBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9Lz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDaG9pY2VHcm91cFxuXG5jb25zdCB1c2VTdHlsZXMgPSAocHJvcHM6IENob2ljZUdyb3VwUHJvcHMpID0+IHtcbiAgY29uc3QgeyBkaXNhYmxlZCB9ID0gcHJvcHNcbiAgY29uc3QgY29sb3JzID0gdXNlVGhlbWVDb2xvcnMoKVxuICByZXR1cm4gbWVyZ2VTdHlsZVNldHMoe1xuICAgIGNvbnRhaW5lcjoge1xuICAgICAgJy5pcy1jaGVja2VkOjphZnRlcic6IHtcbiAgICAgICAgYm9yZGVyQ29sb3I6IGRpc2FibGVkID8gY29sb3JzLmdyYXlbNjAwXSA6IHByb3BzLmNvbG9yID8gcHJvcHMuY29sb3IgOiBjb2xvcnMucHJpbWFyeSxcbiAgICAgIH0sXG4gICAgICAnLmlzLWNoZWNrZWQ6OmJlZm9yZSc6IHtcbiAgICAgICAgYm9yZGVyQ29sb3I6IGRpc2FibGVkID8gY29sb3JzLmdyYXlbNjAwXSA6IHByb3BzLmNvbG9yID8gcHJvcHMuY29sb3IgOiBjb2xvcnMucHJpbWFyeSxcbiAgICAgIH0sXG4gICAgICAnLmlzLWNoZWNrZWQ6aG92ZXI6OmFmdGVyJzoge1xuICAgICAgICBib3JkZXJDb2xvcjogZGlzYWJsZWQgPyBjb2xvcnMuZ3JheVs2MDBdIDogcHJvcHMuY29sb3IgPyBwcm9wcy5jb2xvciA6IGNvbG9ycy5wdXJwbGVbNjAwXSxcbiAgICAgIH0sXG4gICAgICAnLmlzLWNoZWNrZWQ6aG92ZXI6OmJlZm9yZSc6IHtcbiAgICAgICAgYm9yZGVyQ29sb3I6IGRpc2FibGVkID8gY29sb3JzLmdyYXlbNjAwXSA6IHByb3BzLmNvbG9yID8gcHJvcHMuY29sb3IgOiBjb2xvcnMucHVycGxlWzYwMF0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0pXG59XG4iXX0=