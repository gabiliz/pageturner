export var NotificationTypeEnum = /* @__PURE__ */ ((NotificationTypeEnum2) => {
  NotificationTypeEnum2[NotificationTypeEnum2["NoAction"] = 0] = "NoAction";
  NotificationTypeEnum2[NotificationTypeEnum2["Redirecionamento"] = 1] = "Redirecionamento";
  NotificationTypeEnum2[NotificationTypeEnum2["Download"] = 2] = "Download";
  return NotificationTypeEnum2;
})(NotificationTypeEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvblR5cGVFbnVtLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBlbnVtIE5vdGlmaWNhdGlvblR5cGVFbnVte1xuICBOb0FjdGlvbiA9IDAsXG4gIFJlZGlyZWNpb25hbWVudG8gPSAxLFxuICBEb3dubG9hZCA9IDJcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQU8sV0FBSyx1QkFBTCxrQkFBS0EsMEJBQUw7QUFDTCxFQUFBQSw0Q0FBQSxjQUFXLEtBQVg7QUFDQSxFQUFBQSw0Q0FBQSxzQkFBbUIsS0FBbkI7QUFDQSxFQUFBQSw0Q0FBQSxjQUFXLEtBQVg7QUFIVSxTQUFBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiTm90aWZpY2F0aW9uVHlwZUVudW0iXX0=