import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/modules/ModulesMenuNav.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenuNav.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Nav } from "/node_modules/.vite/deps/@fluentui_react_lib_Nav.js?v=9f90a7ff";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { useTheme as useThemeFluent } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
const ModulesMenuNav = (props) => {
  _s();
  const {
    onDismiss
  } = props;
  const navigate = useNavigate();
  const {
    fiscalIconStyles,
    adminIconStyles,
    auditorIconStyles,
    navStyles,
    monitorIconStyles
  } = useStyles();
  const {
    module
  } = useParams();
  const {
    hasModule
  } = usePermissions();
  const navLinkGroups = [{
    links: [{
      iconProps: {
        iconName: "CheckList",
        styles: monitorIconStyles()
      },
      key: "backlog-monitor",
      title: "backlog-monitor",
      permission: "backlog-monitor",
      name: "Monitor de pendências",
      url: "/"
    }, {
      iconProps: {
        iconName: "ContactCard",
        styles: adminIconStyles()
      },
      title: "Administrativo",
      permission: "Administrativo",
      key: "admin",
      name: "Administrativo",
      url: "/admin"
    }, {
      iconProps: {
        iconName: "Money",
        styles: fiscalIconStyles()
      },
      title: "Fiscal",
      permission: "Fiscal",
      key: "fiscal",
      name: "Fiscal",
      url: "/fiscal"
    }, {
      iconProps: {
        iconName: "IssueTracking",
        styles: auditorIconStyles()
      },
      title: "Projetos",
      permission: "Auditoria",
      key: module === "audit" ? "audit" : "risk-panel",
      name: "Projetos",
      url: "/audit"
    }]
  }];
  const permissionNav = useMemo(() => {
    return navLinkGroups[0].links.filter((navLink) => navLink.key === "backlog-monitor" || hasModule(navLink.permission));
  }, []);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      navigate(item.url);
      onDismiss();
    }
  };
  return /* @__PURE__ */ jsxDEV(Nav, { groups: [{
    links: permissionNav
  }], styles: navStyles(), onLinkClick: handleClick, selectedKey: module }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenuNav.tsx",
    lineNumber: 84,
    columnNumber: 10
  }, this);
};
_s(ModulesMenuNav, "EJtVscCq24cAT9gWlCekXD8ZYEU=", false, function() {
  return [useNavigate, useStyles, useParams, usePermissions];
});
_c = ModulesMenuNav;
const useStyles = () => {
  _s2();
  const {
    effects
  } = useThemeFluent();
  const {
    spacing,
    colors
  } = useTheme();
  const navStyles = useCallback(() => (props) => ({
    link: {
      width: "90% ",
      margin: spacing.lg,
      backgroundColor: "transparent",
      boxShadow: props.isSelected ? effects.elevation8 : "none",
      selectors: {
        ":hover": {
          color: colors.primary,
          boxShadow: effects.elevation8,
          backgroundColor: colors.white
        },
        ":focus": {
          boxShadow: effects.elevation8,
          backgroundColor: colors.white
        },
        ":active": {
          boxShadow: effects.elevation8,
          backgroundColor: colors.white
        },
        "::after": {
          borderLeft: "none",
          backgroundColor: "transparent",
          boxShadow: effects.elevation8
        }
      }
    }
  }), []);
  const monitorIconStyles = useCallback(() => () => ({
    root: {
      color: colors.primary
    }
  }), []);
  const adminIconStyles = useCallback(() => () => ({
    root: {
      color: colors.blue[600]
    }
  }), []);
  const fiscalIconStyles = useCallback(() => () => ({
    root: {
      color: colors.green[600]
    }
  }), []);
  const auditorIconStyles = useCallback(() => () => ({
    root: {
      color: colors.orange[600]
    }
  }), []);
  return {
    navStyles,
    adminIconStyles,
    fiscalIconStyles,
    auditorIconStyles,
    monitorIconStyles
  };
};
_s2(useStyles, "4plcBjkEATtuIsgezBl6Cz2Dpyg=", false, function() {
  return [useThemeFluent, useTheme];
});
export default ModulesMenuNav;
var _c;
$RefreshReg$(_c, "ModulesMenuNav");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modules/ModulesMenuNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZJOzs7Ozs7Ozs7Ozs7Ozs7O0FBekZKLFNBQXlCQSxhQUFhQyxlQUFlO0FBQ3JELFNBQVNDLFdBQWdFO0FBQ3pFLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFzQkMsWUFBWUMsc0JBQXNCO0FBQ3hELFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTRixnQkFBZ0I7QUFNekIsTUFBTUcsaUJBQXdDQyxXQUFVO0FBQUFDLEtBQUE7QUFDdEQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVUsSUFBSUY7QUFDdEIsUUFBTUcsV0FBV1QsWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFDSlU7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJQyxVQUFVO0FBRWQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSWYsVUFBVTtBQUU3QixRQUFNO0FBQUEsSUFBRWdCO0FBQUFBLEVBQVUsSUFBSWIsZUFBZTtBQUVyQyxRQUFNYyxnQkFBaUMsQ0FDckM7QUFBQSxJQUNFQyxPQUFPLENBQ0w7QUFBQSxNQUNFQyxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFSLGtCQUFrQjtBQUFBLE1BQzVCO0FBQUEsTUFDQVMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFYLGdCQUFnQjtBQUFBLE1BQzFCO0FBQUEsTUFDQWEsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaRixLQUFLO0FBQUEsTUFDTEcsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFaLGlCQUFpQjtBQUFBLE1BQzNCO0FBQUEsTUFDQWMsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaRixLQUFLO0FBQUEsTUFDTEcsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxJQUNQLEdBQ0E7QUFBQSxNQUNFUCxXQUFXO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFWLGtCQUFrQjtBQUFBLE1BQzVCO0FBQUEsTUFDQVksT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaRixLQUFLUCxXQUFXLFVBQVUsVUFBVTtBQUFBLE1BQ3BDVSxNQUFNO0FBQUEsTUFDTkMsS0FBSztBQUFBLElBQ1AsQ0FBQztBQUFBLEVBRUwsQ0FBQztBQUVILFFBQU1DLGdCQUFnQjlCLFFBQVEsTUFBTTtBQUNsQyxXQUFPb0IsY0FBYyxDQUFDLEVBQUVDLE1BQU1VLE9BQU9DLGFBQVdBLFFBQVFQLFFBQVEscUJBQXFCTixVQUFVYSxRQUFRTCxVQUFvQixDQUFDO0FBQUEsRUFDOUgsR0FBRyxFQUFFO0FBRUwsUUFBTU0sY0FBY0EsQ0FBQ0MsSUFBaUJDLFNBQW9CO0FBQ3hELFFBQUlELE9BQU9FLFVBQWFELFNBQVNDLFFBQVc7QUFDMUNGLFNBQUdHLGVBQWU7QUFDbEIxQixlQUFTd0IsS0FBS04sR0FBRztBQUNqQm5CLGdCQUFVO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLE9BQ0MsUUFBUSxDQUFDO0FBQUEsSUFBRVcsT0FBT1M7QUFBQUEsRUFBYyxDQUFDLEdBQ2pDLFFBQVFmLFVBQVUsR0FDbEIsYUFBYWtCLGFBQ2IsYUFBYWYsVUFKZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSXNCO0FBRzFCO0FBQUNULEdBckZLRixnQkFBb0M7QUFBQSxVQUV2QkwsYUFPYmUsV0FFZWQsV0FFR0csY0FBYztBQUFBO0FBQUFnQyxLQWJoQy9CO0FBdUZOLE1BQU1VLFlBQVlBLE1BQU07QUFBQXNCLE1BQUE7QUFDdEIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVEsSUFBSW5DLGVBQWU7QUFDbkMsUUFBTTtBQUFBLElBQUVvQztBQUFBQSxJQUFTQztBQUFBQSxFQUFPLElBQUl0QyxTQUFTO0FBRXJDLFFBQU1XLFlBQVloQixZQUFZLE1BQU0sQ0FBQ1MsV0FBK0M7QUFBQSxJQUNsRm1DLE1BQU07QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsUUFBUUosUUFBUUs7QUFBQUEsTUFDaEJDLGlCQUFpQjtBQUFBLE1BQ2pCQyxXQUFXeEMsTUFBTXlDLGFBQWFULFFBQVFVLGFBQWE7QUFBQSxNQUNuREMsV0FBVztBQUFBLFFBQ1QsVUFBVTtBQUFBLFVBQ1JDLE9BQU9WLE9BQU9XO0FBQUFBLFVBQ2RMLFdBQVdSLFFBQVFVO0FBQUFBLFVBQ25CSCxpQkFBaUJMLE9BQU9ZO0FBQUFBLFFBQzFCO0FBQUEsUUFDQSxVQUFVO0FBQUEsVUFDUk4sV0FBV1IsUUFBUVU7QUFBQUEsVUFDbkJILGlCQUFpQkwsT0FBT1k7QUFBQUEsUUFDMUI7QUFBQSxRQUNBLFdBQVc7QUFBQSxVQUNUTixXQUFXUixRQUFRVTtBQUFBQSxVQUNuQkgsaUJBQWlCTCxPQUFPWTtBQUFBQSxRQUMxQjtBQUFBLFFBQ0EsV0FBVztBQUFBLFVBQ1RDLFlBQVk7QUFBQSxVQUNaUixpQkFBaUI7QUFBQSxVQUNqQkMsV0FBV1IsUUFBUVU7QUFBQUEsUUFDckI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsSUFBSSxFQUFFO0FBRU4sUUFBTWxDLG9CQUFvQmpCLFlBQVksTUFBTSxPQUE2QjtBQUFBLElBQ3ZFeUQsTUFBTTtBQUFBLE1BQ0pKLE9BQU9WLE9BQU9XO0FBQUFBLElBQ2hCO0FBQUEsRUFDRixJQUFJLEVBQUU7QUFFTixRQUFNeEMsa0JBQWtCZCxZQUFZLE1BQU0sT0FBNkI7QUFBQSxJQUNyRXlELE1BQU07QUFBQSxNQUNKSixPQUFPVixPQUFPZSxLQUFLLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsSUFBSSxFQUFFO0FBRU4sUUFBTTdDLG1CQUFtQmIsWUFBWSxNQUFNLE9BQTZCO0FBQUEsSUFDdEV5RCxNQUFNO0FBQUEsTUFDSkosT0FBT1YsT0FBT2dCLE1BQU0sR0FBRztBQUFBLElBQ3pCO0FBQUEsRUFDRixJQUFJLEVBQUU7QUFFTixRQUFNNUMsb0JBQW9CZixZQUFZLE1BQU0sT0FBNkI7QUFBQSxJQUN2RXlELE1BQU07QUFBQSxNQUNKSixPQUFPVixPQUFPaUIsT0FBTyxHQUFHO0FBQUEsSUFDMUI7QUFBQSxFQUNGLElBQUksRUFBRTtBQUVOLFNBQU87QUFBQSxJQUNMNUM7QUFBQUEsSUFDQUY7QUFBQUEsSUFDQUQ7QUFBQUEsSUFDQUU7QUFBQUEsSUFDQUU7QUFBQUEsRUFDRjtBQUNGO0FBQUN1QixJQWhFS3RCLFdBQVM7QUFBQSxVQUNPWixnQkFDUUQsUUFBUTtBQUFBO0FBZ0V0QyxlQUFlRztBQUFjLElBQUErQjtBQUFBc0IsYUFBQXRCLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZU1lbW8iLCJOYXYiLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVRoZW1lIiwidXNlVGhlbWVGbHVlbnQiLCJ1c2VQZXJtaXNzaW9ucyIsIk1vZHVsZXNNZW51TmF2IiwicHJvcHMiLCJfcyIsIm9uRGlzbWlzcyIsIm5hdmlnYXRlIiwiZmlzY2FsSWNvblN0eWxlcyIsImFkbWluSWNvblN0eWxlcyIsImF1ZGl0b3JJY29uU3R5bGVzIiwibmF2U3R5bGVzIiwibW9uaXRvckljb25TdHlsZXMiLCJ1c2VTdHlsZXMiLCJtb2R1bGUiLCJoYXNNb2R1bGUiLCJuYXZMaW5rR3JvdXBzIiwibGlua3MiLCJpY29uUHJvcHMiLCJpY29uTmFtZSIsInN0eWxlcyIsImtleSIsInRpdGxlIiwicGVybWlzc2lvbiIsIm5hbWUiLCJ1cmwiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyIiwibmF2TGluayIsImhhbmRsZUNsaWNrIiwiZXYiLCJpdGVtIiwidW5kZWZpbmVkIiwicHJldmVudERlZmF1bHQiLCJfYyIsIl9zMiIsImVmZmVjdHMiLCJzcGFjaW5nIiwiY29sb3JzIiwibGluayIsIndpZHRoIiwibWFyZ2luIiwibGciLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3hTaGFkb3ciLCJpc1NlbGVjdGVkIiwiZWxldmF0aW9uOCIsInNlbGVjdG9ycyIsImNvbG9yIiwicHJpbWFyeSIsIndoaXRlIiwiYm9yZGVyTGVmdCIsInJvb3QiLCJibHVlIiwiZ3JlZW4iLCJvcmFuZ2UiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNb2R1bGVzTWVudU5hdi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9tb2R1bGVzL01vZHVsZXNNZW51TmF2LnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBNb3VzZUV2ZW50LCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTmF2LCBJTmF2TGlua0dyb3VwLCBJTmF2TGluaywgSU5hdlN0eWxlcywgSU5hdlN0eWxlUHJvcHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QvbGliL05hdidcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgSUljb25TdHlsZXMsIHVzZVRoZW1lIGFzIHVzZVRoZW1lRmx1ZW50IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5pbnRlcmZhY2UgTW9kdWxlc01lbnVQcm9wcyB7XG4gIG9uRGlzbWlzczogKCkgPT4gdm9pZFxufVxuXG5jb25zdCBNb2R1bGVzTWVudU5hdjogRkM8TW9kdWxlc01lbnVQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBvbkRpc21pc3MgfSA9IHByb3BzXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7XG4gICAgZmlzY2FsSWNvblN0eWxlcyxcbiAgICBhZG1pbkljb25TdHlsZXMsXG4gICAgYXVkaXRvckljb25TdHlsZXMsXG4gICAgbmF2U3R5bGVzLFxuICAgIG1vbml0b3JJY29uU3R5bGVzLFxuICB9ID0gdXNlU3R5bGVzKClcblxuICBjb25zdCB7IG1vZHVsZSB9ID0gdXNlUGFyYW1zKClcblxuICBjb25zdCB7IGhhc01vZHVsZSB9ID0gdXNlUGVybWlzc2lvbnMoKVxuXG4gIGNvbnN0IG5hdkxpbmtHcm91cHM6IElOYXZMaW5rR3JvdXBbXSA9IFtcbiAgICB7XG4gICAgICBsaW5rczogW1xuICAgICAgICB7XG4gICAgICAgICAgaWNvblByb3BzOiB7XG4gICAgICAgICAgICBpY29uTmFtZTogJ0NoZWNrTGlzdCcsXG4gICAgICAgICAgICBzdHlsZXM6IG1vbml0b3JJY29uU3R5bGVzKCksXG4gICAgICAgICAgfSxcbiAgICAgICAgICBrZXk6ICdiYWNrbG9nLW1vbml0b3InLFxuICAgICAgICAgIHRpdGxlOiAnYmFja2xvZy1tb25pdG9yJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnYmFja2xvZy1tb25pdG9yJyxcbiAgICAgICAgICBuYW1lOiAnTW9uaXRvciBkZSBwZW5kw6puY2lhcycsXG4gICAgICAgICAgdXJsOiAnLycsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBpY29uUHJvcHM6IHtcbiAgICAgICAgICAgIGljb25OYW1lOiAnQ29udGFjdENhcmQnLFxuICAgICAgICAgICAgc3R5bGVzOiBhZG1pbkljb25TdHlsZXMoKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpdGxlOiAnQWRtaW5pc3RyYXRpdm8nLFxuICAgICAgICAgIHBlcm1pc3Npb246ICdBZG1pbmlzdHJhdGl2bycsXG4gICAgICAgICAga2V5OiAnYWRtaW4nLFxuICAgICAgICAgIG5hbWU6ICdBZG1pbmlzdHJhdGl2bycsXG4gICAgICAgICAgdXJsOiAnL2FkbWluJyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGljb25Qcm9wczoge1xuICAgICAgICAgICAgaWNvbk5hbWU6ICdNb25leScsXG4gICAgICAgICAgICBzdHlsZXM6IGZpc2NhbEljb25TdHlsZXMoKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpdGxlOiAnRmlzY2FsJyxcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnRmlzY2FsJyxcbiAgICAgICAgICBrZXk6ICdmaXNjYWwnLFxuICAgICAgICAgIG5hbWU6ICdGaXNjYWwnLFxuICAgICAgICAgIHVybDogJy9maXNjYWwnLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgaWNvblByb3BzOiB7XG4gICAgICAgICAgICBpY29uTmFtZTogJ0lzc3VlVHJhY2tpbmcnLFxuICAgICAgICAgICAgc3R5bGVzOiBhdWRpdG9ySWNvblN0eWxlcygpLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdGl0bGU6ICdQcm9qZXRvcycsXG4gICAgICAgICAgcGVybWlzc2lvbjogJ0F1ZGl0b3JpYScsXG4gICAgICAgICAga2V5OiBtb2R1bGUgPT09ICdhdWRpdCcgPyAnYXVkaXQnIDogJ3Jpc2stcGFuZWwnLFxuICAgICAgICAgIG5hbWU6ICdQcm9qZXRvcycsXG4gICAgICAgICAgdXJsOiAnL2F1ZGl0JyxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSxcbiAgXVxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIG5hdkxpbmtHcm91cHNbMF0ubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gbmF2TGluay5rZXkgPT09ICdiYWNrbG9nLW1vbml0b3InIHx8IGhhc01vZHVsZShuYXZMaW5rLnBlcm1pc3Npb24gYXMgc3RyaW5nKSlcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoZXY/OiBNb3VzZUV2ZW50LCBpdGVtPzogSU5hdkxpbmspID0+IHtcbiAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCAmJiBpdGVtICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcbiAgICAgIG5hdmlnYXRlKGl0ZW0udXJsKVxuICAgICAgb25EaXNtaXNzKClcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxOYXZcbiAgICAgIGdyb3Vwcz17W3sgbGlua3M6IHBlcm1pc3Npb25OYXYgfV19XG4gICAgICBzdHlsZXM9e25hdlN0eWxlcygpfVxuICAgICAgb25MaW5rQ2xpY2s9e2hhbmRsZUNsaWNrfVxuICAgICAgc2VsZWN0ZWRLZXk9e21vZHVsZX1cbiAgICAvPlxuICApXG59XG5cbmNvbnN0IHVzZVN0eWxlcyA9ICgpID0+IHtcbiAgY29uc3QgeyBlZmZlY3RzIH0gPSB1c2VUaGVtZUZsdWVudCgpXG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG5cbiAgY29uc3QgbmF2U3R5bGVzID0gdXNlQ2FsbGJhY2soKCkgPT4gKHByb3BzOklOYXZTdHlsZVByb3BzKTogUGFydGlhbDxJTmF2U3R5bGVzPiA9PiAoe1xuICAgIGxpbms6IHtcbiAgICAgIHdpZHRoOiAnOTAlICcsXG4gICAgICBtYXJnaW46IHNwYWNpbmcubGcsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgICBib3hTaGFkb3c6IHByb3BzLmlzU2VsZWN0ZWQgPyBlZmZlY3RzLmVsZXZhdGlvbjggOiAnbm9uZScsXG4gICAgICBzZWxlY3RvcnM6IHtcbiAgICAgICAgJzpob3Zlcic6IHtcbiAgICAgICAgICBjb2xvcjogY29sb3JzLnByaW1hcnksXG4gICAgICAgICAgYm94U2hhZG93OiBlZmZlY3RzLmVsZXZhdGlvbjgsXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICAgIH0sXG4gICAgICAgICc6Zm9jdXMnOiB7XG4gICAgICAgICAgYm94U2hhZG93OiBlZmZlY3RzLmVsZXZhdGlvbjgsXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMud2hpdGUsXG4gICAgICAgIH0sXG4gICAgICAgICc6YWN0aXZlJzoge1xuICAgICAgICAgIGJveFNoYWRvdzogZWZmZWN0cy5lbGV2YXRpb244LFxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLndoaXRlLFxuICAgICAgICB9LFxuICAgICAgICAnOjphZnRlcic6IHtcbiAgICAgICAgICBib3JkZXJMZWZ0OiAnbm9uZScsXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgIGJveFNoYWRvdzogZWZmZWN0cy5lbGV2YXRpb244LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9KSwgW10pXG5cbiAgY29uc3QgbW9uaXRvckljb25TdHlsZXMgPSB1c2VDYWxsYmFjaygoKSA9PiAoKTogUGFydGlhbDxJSWNvblN0eWxlcz4gPT4gKHtcbiAgICByb290OiB7XG4gICAgICBjb2xvcjogY29sb3JzLnByaW1hcnksXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIGNvbnN0IGFkbWluSWNvblN0eWxlcyA9IHVzZUNhbGxiYWNrKCgpID0+ICgpOiBQYXJ0aWFsPElJY29uU3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMuYmx1ZVs2MDBdLFxuICAgIH0sXG4gIH0pLCBbXSlcblxuICBjb25zdCBmaXNjYWxJY29uU3R5bGVzID0gdXNlQ2FsbGJhY2soKCkgPT4gKCk6IFBhcnRpYWw8SUljb25TdHlsZXM+ID0+ICh7XG4gICAgcm9vdDoge1xuICAgICAgY29sb3I6IGNvbG9ycy5ncmVlbls2MDBdLFxuICAgIH0sXG4gIH0pLCBbXSlcblxuICBjb25zdCBhdWRpdG9ySWNvblN0eWxlcyA9IHVzZUNhbGxiYWNrKCgpID0+ICgpOiBQYXJ0aWFsPElJY29uU3R5bGVzPiA9PiAoe1xuICAgIHJvb3Q6IHtcbiAgICAgIGNvbG9yOiBjb2xvcnMub3JhbmdlWzYwMF0sXG4gICAgfSxcbiAgfSksIFtdKVxuXG4gIHJldHVybiB7XG4gICAgbmF2U3R5bGVzLFxuICAgIGFkbWluSWNvblN0eWxlcyxcbiAgICBmaXNjYWxJY29uU3R5bGVzLFxuICAgIGF1ZGl0b3JJY29uU3R5bGVzLFxuICAgIG1vbml0b3JJY29uU3R5bGVzLFxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IE1vZHVsZXNNZW51TmF2XG4iXX0=