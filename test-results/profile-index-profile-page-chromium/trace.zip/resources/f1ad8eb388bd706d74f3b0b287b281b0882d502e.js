import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/modal/Modal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Modal as FluentModal, mergeStyleSets, Text, IconButton } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
const Modal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    title,
    renderTitle,
    children,
    width,
    isBlocking = false,
    handleCloseButton = true,
    isFullsize = false
  } = props;
  const styles = useStyles(width, isFullsize);
  return /* @__PURE__ */ jsxDEV(FluentModal, { isOpen, onDismiss, isBlocking, containerClassName: styles.container, layerProps: {
    styles: {
      root: {
        zIndex: 998
      }
    }
  }, children: [
    /* @__PURE__ */ jsxDEV("header", { className: styles.header, children: [
      renderTitle ? renderTitle() : /* @__PURE__ */ jsxDEV(Text, { variant: "xLargePlus", children: title }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx",
        lineNumber: 36,
        columnNumber: 40
      }, this),
      handleCloseButton && /* @__PURE__ */ jsxDEV(IconButton, { className: styles.closeButton, iconProps: {
        iconName: "Cancel"
      }, ariaLabel: "Close popup modal", onClick: () => onDismiss() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx",
        lineNumber: 37,
        columnNumber: 31
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.body, children }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
};
_s(Modal, "3bjLmUB54uhXRX+frDMowQzU8P8=", false, function() {
  return [useStyles];
});
_c = Modal;
const useStyles = (width, isFullsize) => {
  _s2();
  const {
    spacing,
    colors
  } = useTheme();
  return mergeStyleSets({
    container: {
      display: "flex",
      flexFlow: "column nowrap",
      alignItems: "stretch",
      width: isFullsize ? "100%" : width ? `${width}px` : "800px",
      "@media(max-whidth: 850px)": {
        maxWidth: "800px"
      },
      height: isFullsize ? "100%" : "auto"
    },
    header: {
      borderTop: `4px solid ${colors.purple[300]}`,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "start",
      padding: spacing.xxl,
      paddingBottom: `${spacing.lg}`,
      minWidth: "100%"
    },
    closeButton: {
      marginLeft: spacing.lg
    },
    body: {
      padding: isFullsize ? 0 : spacing.xxl,
      paddingTop: 0
    }
  });
};
_s2(useStyles, "DYbly3eZemev0s+b4AhenF5M69k=", false, function() {
  return [useTheme];
});
export default Modal;
var _c;
$RefreshReg$(_c, "Modal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/modal/Modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENZOzs7Ozs7Ozs7Ozs7Ozs7O0FBekNaLFNBQVNBLFNBQVNDLGFBQTBCQyxnQkFBZ0JDLE1BQU1DLGtCQUFrQjtBQUNwRixTQUFTQyxnQkFBZ0I7QUFjekIsTUFBTUwsUUFBeUJNLFdBQVU7QUFBQUMsS0FBQTtBQUN2QyxRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsYUFBYTtBQUFBLElBQ2JDLG9CQUFvQjtBQUFBLElBQ3BCQyxhQUFhO0FBQUEsRUFDZixJQUFJVjtBQUVKLFFBQU1XLFNBQVNDLFVBQVVMLE9BQU9HLFVBQVU7QUFFMUMsU0FDRSx1QkFBQyxlQUNDLFFBQ0EsV0FDQSxZQUNBLG9CQUFvQkMsT0FBT0UsV0FDM0IsWUFBWTtBQUFBLElBQUVGLFFBQVE7QUFBQSxNQUFFRyxNQUFNO0FBQUEsUUFBRUMsUUFBUTtBQUFBLE1BQUk7QUFBQSxJQUFFO0FBQUEsRUFBRSxHQUVoRDtBQUFBLDJCQUFDLFlBQU8sV0FBV0osT0FBT0ssUUFDdkJYO0FBQUFBLG9CQUNHQSxZQUFZLElBQ1osdUJBQUMsUUFBSyxTQUFRLGNBQWNELG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFFckNLLHFCQUNDLHVCQUFDLGNBQ0MsV0FBV0UsT0FBT00sYUFDbEIsV0FBVztBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFTLEdBQ2hDLFdBQVUscUJBQ1YsU0FBUyxNQUFNZixVQUFVLEtBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJNkI7QUFBQSxTQVZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV1EsT0FBT1EsTUFDcEJiLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUNMLEdBMUNLUCxPQUFxQjtBQUFBLFVBYVZrQixTQUFTO0FBQUE7QUFBQVEsS0FicEIxQjtBQTRDTixNQUFNa0IsWUFBWUEsQ0FBQ0wsT0FBZ0JHLGVBQXlCO0FBQUFXLE1BQUE7QUFDMUQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVNDO0FBQUFBLEVBQU8sSUFBSXhCLFNBQVM7QUFDckMsU0FBT0gsZUFBZTtBQUFBLElBQ3BCaUIsV0FBVztBQUFBLE1BQ1RXLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1puQixPQUFPRyxhQUFhLFNBQVNILFFBQVMsR0FBRUEsWUFBWTtBQUFBLE1BQ3BELDZCQUE2QjtBQUFBLFFBQzNCb0IsVUFBVTtBQUFBLE1BQ1o7QUFBQSxNQUNBQyxRQUFRbEIsYUFBYSxTQUFTO0FBQUEsSUFDaEM7QUFBQSxJQUNBTSxRQUFRO0FBQUEsTUFDTmEsV0FBWSxhQUFZTixPQUFPTyxPQUFPLEdBQUc7QUFBQSxNQUN6Q04sU0FBUztBQUFBLE1BQ1RPLGdCQUFnQjtBQUFBLE1BQ2hCTCxZQUFZO0FBQUEsTUFDWk0sU0FBU1YsUUFBUVc7QUFBQUEsTUFDakJDLGVBQWdCLEdBQUVaLFFBQVFhO0FBQUFBLE1BQzFCQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0FuQixhQUFhO0FBQUEsTUFDWG9CLFlBQVlmLFFBQVFhO0FBQUFBLElBQ3RCO0FBQUEsSUFDQWhCLE1BQU07QUFBQSxNQUNKYSxTQUFTdEIsYUFBYSxJQUFJWSxRQUFRVztBQUFBQSxNQUNsQ0ssWUFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUFDakIsSUE5QktULFdBQVM7QUFBQSxVQUNlYixRQUFRO0FBQUE7QUErQnRDLGVBQWVMO0FBQUssSUFBQTBCO0FBQUFtQixhQUFBbkIsSUFBQSIsIm5hbWVzIjpbIk1vZGFsIiwiRmx1ZW50TW9kYWwiLCJtZXJnZVN0eWxlU2V0cyIsIlRleHQiLCJJY29uQnV0dG9uIiwidXNlVGhlbWUiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwidGl0bGUiLCJyZW5kZXJUaXRsZSIsImNoaWxkcmVuIiwid2lkdGgiLCJpc0Jsb2NraW5nIiwiaGFuZGxlQ2xvc2VCdXR0b24iLCJpc0Z1bGxzaXplIiwic3R5bGVzIiwidXNlU3R5bGVzIiwiY29udGFpbmVyIiwicm9vdCIsInpJbmRleCIsImhlYWRlciIsImNsb3NlQnV0dG9uIiwiaWNvbk5hbWUiLCJib2R5IiwiX2MiLCJfczIiLCJzcGFjaW5nIiwiY29sb3JzIiwiZGlzcGxheSIsImZsZXhGbG93IiwiYWxpZ25JdGVtcyIsIm1heFdpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyVG9wIiwicHVycGxlIiwianVzdGlmeUNvbnRlbnQiLCJwYWRkaW5nIiwieHhsIiwicGFkZGluZ0JvdHRvbSIsImxnIiwibWluV2lkdGgiLCJtYXJnaW5MZWZ0IiwicGFkZGluZ1RvcCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1vZGFsLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL21vZGFsL01vZGFsLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IE1vZGFsIGFzIEZsdWVudE1vZGFsLCBJTW9kYWxQcm9wcywgbWVyZ2VTdHlsZVNldHMsIFRleHQsIEljb25CdXR0b24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIE1vZGFsUHJvcHMgZXh0ZW5kcyBQaWNrPFxuUmVxdWlyZWQ8SU1vZGFsUHJvcHM+LFxuJ2lzT3Blbid8J29uRGlzbWlzcydcbj4ge1xuICB0aXRsZT86IHN0cmluZ1xuICByZW5kZXJUaXRsZT86ICgpID0+IFJlYWN0Tm9kZVxuICB3aWR0aD86IG51bWJlclxuICBpc0Jsb2NraW5nPzogYm9vbGVhblxuICBoYW5kbGVDbG9zZUJ1dHRvbj86IGJvb2xlYW5cbiAgaXNGdWxsc2l6ZT86IGJvb2xlYW5cbn1cblxuY29uc3QgTW9kYWw6IEZDPE1vZGFsUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBpc09wZW4sXG4gICAgb25EaXNtaXNzLFxuICAgIHRpdGxlLFxuICAgIHJlbmRlclRpdGxlLFxuICAgIGNoaWxkcmVuLFxuICAgIHdpZHRoLFxuICAgIGlzQmxvY2tpbmcgPSBmYWxzZSxcbiAgICBoYW5kbGVDbG9zZUJ1dHRvbiA9IHRydWUsXG4gICAgaXNGdWxsc2l6ZSA9IGZhbHNlLFxuICB9ID0gcHJvcHNcblxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMod2lkdGgsIGlzRnVsbHNpemUpXG5cbiAgcmV0dXJuIChcbiAgICA8Rmx1ZW50TW9kYWxcbiAgICAgIGlzT3Blbj17aXNPcGVufVxuICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XG4gICAgICBpc0Jsb2NraW5nPXtpc0Jsb2NraW5nfVxuICAgICAgY29udGFpbmVyQ2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfVxuICAgICAgbGF5ZXJQcm9wcz17eyBzdHlsZXM6IHsgcm9vdDogeyB6SW5kZXg6IDk5OCB9IH0gfX1cbiAgICA+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT17c3R5bGVzLmhlYWRlcn0+XG4gICAgICAgIHtyZW5kZXJUaXRsZVxuICAgICAgICAgID8gcmVuZGVyVGl0bGUoKVxuICAgICAgICAgIDogPFRleHQgdmFyaWFudD1cInhMYXJnZVBsdXNcIj57dGl0bGV9PC9UZXh0PlxuICAgICAgICB9XG4gICAgICAgIHtoYW5kbGVDbG9zZUJ1dHRvbiAmJlxuICAgICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5jbG9zZUJ1dHRvbn1cbiAgICAgICAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0NhbmNlbCcgfX1cbiAgICAgICAgICAgIGFyaWFMYWJlbD1cIkNsb3NlIHBvcHVwIG1vZGFsXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGlzbWlzcygpfVxuICAgICAgICAgIC8+XG4gICAgICAgIH1cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5ib2R5fT5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9kaXY+XG4gICAgPC9GbHVlbnRNb2RhbD5cbiAgKVxufVxuXG5jb25zdCB1c2VTdHlsZXMgPSAod2lkdGg/OiBudW1iZXIsIGlzRnVsbHNpemU/OiBib29sZWFuKSA9PiB7XG4gIGNvbnN0IHsgc3BhY2luZywgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XG4gICAgY29udGFpbmVyOiB7XG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBmbGV4RmxvdzogJ2NvbHVtbiBub3dyYXAnLFxuICAgICAgYWxpZ25JdGVtczogJ3N0cmV0Y2gnLFxuICAgICAgd2lkdGg6IGlzRnVsbHNpemUgPyAnMTAwJScgOiB3aWR0aCA/IGAke3dpZHRofXB4YCA6ICc4MDBweCcsXG4gICAgICAnQG1lZGlhKG1heC13aGlkdGg6IDg1MHB4KSc6IHtcbiAgICAgICAgbWF4V2lkdGg6ICc4MDBweCcsXG4gICAgICB9LFxuICAgICAgaGVpZ2h0OiBpc0Z1bGxzaXplID8gJzEwMCUnIDogJ2F1dG8nLFxuICAgIH0sXG4gICAgaGVhZGVyOiB7XG4gICAgICBib3JkZXJUb3A6IGA0cHggc29saWQgJHtjb2xvcnMucHVycGxlWzMwMF19YCxcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gICAgICBhbGlnbkl0ZW1zOiAnc3RhcnQnLFxuICAgICAgcGFkZGluZzogc3BhY2luZy54eGwsXG4gICAgICBwYWRkaW5nQm90dG9tOiBgJHtzcGFjaW5nLmxnfWAsXG4gICAgICBtaW5XaWR0aDogJzEwMCUnLFxuICAgIH0sXG4gICAgY2xvc2VCdXR0b246IHtcbiAgICAgIG1hcmdpbkxlZnQ6IHNwYWNpbmcubGcsXG4gICAgfSxcbiAgICBib2R5OiB7XG4gICAgICBwYWRkaW5nOiBpc0Z1bGxzaXplID8gMCA6IHNwYWNpbmcueHhsLFxuICAgICAgcGFkZGluZ1RvcDogMCxcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBNb2RhbFxuIl19