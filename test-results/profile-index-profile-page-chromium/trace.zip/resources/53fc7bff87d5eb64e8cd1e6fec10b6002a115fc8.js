import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/datatable/DataTableEmptyState.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useTheme } from "/src/shared/hooks/index.ts";
import { FlexColumn, FlexItem } from "/src/shared/components/FlexBox/index.ts";
import NoCompanie from "/src/modules/audit/parameters/components/images/NoCompanie.svg?import";
const DataTableEmptyState = () => {
  _s();
  const {
    colors
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(FlexColumn, { verticalAlign: "center", horizontalAlign: "center", margin: "50px 0 0 0", gap: 20, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV("img", { src: NoCompanie, alt: "icon" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
      lineNumber: 14,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(FlexColumn, { horizontalAlign: "center", verticalAlign: "center", gap: 8, children: [
      /* @__PURE__ */ jsxDEV(Text, { variant: "xxLarge", style: {
        color: colors.gray[600]
      }, children: "Nenhum registro encontrado" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
        lineNumber: 18,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Text, { variant: "large", style: {
        color: colors.gray[500],
        marginBottom: 15
      }, children: "Cadastre um novo registro ou ajuste sua pesquisa" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
        lineNumber: 23,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(DataTableEmptyState, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
_c = DataTableEmptyState;
export default DataTableEmptyState;
var _c;
$RefreshReg$(_c, "DataTableEmptyState");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/datatable/DataTableEmptyState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBakJSLFNBQVNBLFlBQVk7QUFFckIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVlDLGdCQUFnQjtBQUNyQyxPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsc0JBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSU4sU0FBUztBQUU1QixTQUNFLHVCQUFDLGNBQ0MsZUFBYyxVQUNkLGlCQUFnQixVQUNoQixRQUFPLGNBQ1AsS0FBTSxJQUVOO0FBQUEsMkJBQUMsWUFDQyxpQ0FBQyxTQUFJLEtBQUtHLFlBQVksS0FBSSxVQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsWUFDQyxpQ0FBQyxjQUNDLGlCQUFnQixVQUNoQixlQUFjLFVBQ2QsS0FBTSxHQUVOO0FBQUEsNkJBQUMsUUFDQyxTQUFRLFdBQ1IsT0FBTztBQUFBLFFBQUVJLE9BQU9ELE9BQU9FLEtBQUssR0FBRztBQUFBLE1BQUUsR0FBRSwwQ0FGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxRQUNDLFNBQVEsU0FDUixPQUFPO0FBQUEsUUFBRUQsT0FBT0QsT0FBT0UsS0FBSyxHQUFHO0FBQUEsUUFBR0MsY0FBYztBQUFBLE1BQUcsR0FBRSxnRUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUNKLEdBbkNLRCxxQkFBdUI7QUFBQSxVQUNSSixRQUFRO0FBQUE7QUFBQVUsS0FEdkJOO0FBcUNOLGVBQWVBO0FBQW1CLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUZXh0IiwidXNlVGhlbWUiLCJGbGV4Q29sdW1uIiwiRmxleEl0ZW0iLCJOb0NvbXBhbmllIiwiRGF0YVRhYmxlRW1wdHlTdGF0ZSIsIl9zIiwiY29sb3JzIiwiY29sb3IiLCJncmF5IiwibWFyZ2luQm90dG9tIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGVFbXB0eVN0YXRlLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2RhdGF0YWJsZS9EYXRhVGFibGVFbXB0eVN0YXRlLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcbmltcG9ydCB7IEZsZXhDb2x1bW4sIEZsZXhJdGVtIH0gZnJvbSAnLi4vRmxleEJveCdcbmltcG9ydCBOb0NvbXBhbmllIGZyb20gJy4uLy4uLy4uL21vZHVsZXMvYXVkaXQvcGFyYW1ldGVycy9jb21wb25lbnRzL2ltYWdlcy9Ob0NvbXBhbmllLnN2ZydcblxuY29uc3QgRGF0YVRhYmxlRW1wdHlTdGF0ZTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgY29sb3JzIH0gPSB1c2VUaGVtZSgpXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleENvbHVtblxuICAgICAgdmVydGljYWxBbGlnbj1cImNlbnRlclwiXG4gICAgICBob3Jpem9udGFsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgbWFyZ2luPVwiNTBweCAwIDAgMFwiXG4gICAgICBnYXA9eyAyMCB9XG4gICAgPlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8aW1nIHNyYz17Tm9Db21wYW5pZX0gYWx0PVwiaWNvblwiIC8+XG4gICAgICA8L0ZsZXhJdGVtPlxuICAgICAgPEZsZXhJdGVtPlxuICAgICAgICA8RmxleENvbHVtblxuICAgICAgICAgIGhvcml6b250YWxBbGlnbj0nY2VudGVyJ1xuICAgICAgICAgIHZlcnRpY2FsQWxpZ249J2NlbnRlcidcbiAgICAgICAgICBnYXA9eyA4IH1cbiAgICAgICAgPlxuICAgICAgICAgIDxUZXh0XG4gICAgICAgICAgICB2YXJpYW50PSd4eExhcmdlJ1xuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0gfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBOZW5odW0gcmVnaXN0cm8gZW5jb250cmFkb1xuICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgICA8VGV4dFxuICAgICAgICAgICAgdmFyaWFudD0nbGFyZ2UnXG4gICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogY29sb3JzLmdyYXlbNTAwXSwgbWFyZ2luQm90dG9tOiAxNSB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIENhZGFzdHJlIHVtIG5vdm8gcmVnaXN0cm8gb3UgYWp1c3RlIHN1YSBwZXNxdWlzYVxuICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgPC9GbGV4Q29sdW1uPlxuICAgICAgPC9GbGV4SXRlbT5cbiAgICA8L0ZsZXhDb2x1bW4+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRGF0YVRhYmxlRW1wdHlTdGF0ZVxuIl19