import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/ModuleMenuRoutes.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/routes/ModuleMenuRoutes.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { ModulesMenuNav } from "/src/shared/components/modules/index.ts?t=1701096626433";
const ModuleMenuRoutes = (props) => {
  const {
    dismissMenu
  } = props;
  return /* @__PURE__ */ jsxDEV(Routes, { children: /* @__PURE__ */ jsxDEV(Route, { path: "/:module/*", element: /* @__PURE__ */ jsxDEV(ModulesMenuNav, { onDismiss: dismissMenu }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/ModuleMenuRoutes.tsx",
    lineNumber: 12,
    columnNumber: 41
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/ModuleMenuRoutes.tsx",
    lineNumber: 12,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/ModuleMenuRoutes.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
};
_c = ModuleMenuRoutes;
export default ModuleMenuRoutes;
var _c;
$RefreshReg$(_c, "ModuleMenuRoutes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/routes/ModuleMenuRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY2lCO0FBZGpCLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLE9BQU9DLGNBQWM7QUFDOUIsU0FBU0Msc0JBQXNCO0FBTS9CLE1BQU1DLG1CQUErQ0MsV0FBVTtBQUM3RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBWSxJQUFJRDtBQUN4QixTQUNFLHVCQUFDLFVBQ0MsaUNBQUMsU0FDQyxNQUFLLGNBQ0wsU0FBUyx1QkFBQyxrQkFDUixXQUFXQyxlQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FDZ0IsS0FIM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlLLEtBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0MsS0FaS0g7QUFjTixlQUFlQTtBQUFnQixJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUm91dGUiLCJSb3V0ZXMiLCJNb2R1bGVzTWVudU5hdiIsIk1vZHVsZU1lbnVSb3V0ZXMiLCJwcm9wcyIsImRpc21pc3NNZW51IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNb2R1bGVNZW51Um91dGVzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3JvdXRlcy9Nb2R1bGVNZW51Um91dGVzLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBSb3V0ZSwgUm91dGVzIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IE1vZHVsZXNNZW51TmF2IH0gZnJvbSAnLi4vc2hhcmVkL2NvbXBvbmVudHMvbW9kdWxlcydcblxuaW50ZXJmYWNlIE1vZHVsZXNNZW51Um91dGVQcm9wcyB7XG4gIGRpc21pc3NNZW51OiAoKSA9PiB2b2lkXG59XG5cbmNvbnN0IE1vZHVsZU1lbnVSb3V0ZXM6IEZDPE1vZHVsZXNNZW51Um91dGVQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgeyBkaXNtaXNzTWVudSB9ID0gcHJvcHNcbiAgcmV0dXJuIChcbiAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvOm1vZHVsZS8qXCJcbiAgICAgICAgZWxlbWVudD17PE1vZHVsZXNNZW51TmF2XG4gICAgICAgICAgb25EaXNtaXNzPXtkaXNtaXNzTWVudX1cbiAgICAgICAgLz59XG4gICAgICAvPlxuICAgIDwvUm91dGVzPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE1vZHVsZU1lbnVSb3V0ZXNcbiJdfQ==