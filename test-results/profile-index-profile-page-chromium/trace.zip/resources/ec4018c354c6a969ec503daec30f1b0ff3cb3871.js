import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/FlexBox/FlexColumn.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexColumn.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const FlexColumn = (props) => {
  const {
    children,
    width,
    height,
    background,
    verticalAlign,
    horizontalAlign,
    wrap,
    gap,
    columnGap,
    rowGap,
    margin,
    padding,
    grow,
    styles,
    className
  } = props;
  return /* @__PURE__ */ jsxDEV("div", { style: {
    display: "flex",
    flexDirection: "column",
    margin,
    padding,
    width,
    height,
    background,
    alignItems: horizontalAlign,
    justifyContent: verticalAlign,
    flexWrap: wrap,
    gap,
    columnGap: columnGap || gap,
    rowGap: rowGap || gap,
    flexGrow: grow,
    ...styles
  }, className, children }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexColumn.tsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
};
_c = FlexColumn;
export default FlexColumn;
var _c;
$RefreshReg$(_c, "FlexColumn");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/FlexBox/FlexColumn.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNJO0FBM0NKLDJCQUF3QkE7QUFBcUIsSUFBRUM7QUFBYztBQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF1QjVFLE1BQU1DLGFBQW1DQyxXQUFVO0FBQ2pELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlmO0FBRUosU0FDRSx1QkFBQyxTQUNDLE9BQU87QUFBQSxJQUNMZ0IsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxJQUNmTjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBVjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBYyxZQUFZWjtBQUFBQSxJQUNaYSxnQkFBZ0JkO0FBQUFBLElBQ2hCZSxVQUFVYjtBQUFBQSxJQUNWQztBQUFBQSxJQUNBQyxXQUFXQSxhQUFhRDtBQUFBQSxJQUN4QkUsUUFBUUEsVUFBVUY7QUFBQUEsSUFDbEJhLFVBQVVSO0FBQUFBLElBQ1YsR0FBR0M7QUFBQUEsRUFDTCxHQUNBLFdBRUNiLFlBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQkE7QUFFSjtBQUFDcUIsS0EzQ0t2QjtBQTZDTixlQUFlQTtBQUFVLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRGV0YWlsZWRIVE1MUHJvcHMiLCJIVE1MQXR0cmlidXRlcyIsIkZsZXhDb2x1bW4iLCJwcm9wcyIsImNoaWxkcmVuIiwid2lkdGgiLCJoZWlnaHQiLCJiYWNrZ3JvdW5kIiwidmVydGljYWxBbGlnbiIsImhvcml6b250YWxBbGlnbiIsIndyYXAiLCJnYXAiLCJjb2x1bW5HYXAiLCJyb3dHYXAiLCJtYXJnaW4iLCJwYWRkaW5nIiwiZ3JvdyIsInN0eWxlcyIsImNsYXNzTmFtZSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZmxleFdyYXAiLCJmbGV4R3JvdyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmxleENvbHVtbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9GbGV4Qm94L0ZsZXhDb2x1bW4udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ1NTUHJvcGVydGllcywgRGV0YWlsZWRIVE1MUHJvcHMsIEZDLCBIVE1MQXR0cmlidXRlcyB9IGZyb20gJ3JlYWN0J1xuXG50eXBlIEFsaWduSXRlbnMgPSAnc3RyZXRjaCcgfCAnZmxleC1zdGFydCcgfCAnZmxleC1lbmQnIHwgJ2NlbnRlcicgfCAnYmFzZWxpbmUnXG50eXBlIEp1c3RpZnlDb250ZW50ID0gJ2ZsZXgtc3RhcnQnIHwgJ2ZsZXgtZW5kJyB8ICdjZW50ZXInIHwgJ3NwYWNlLWJldHdlZW4nIHwgJ3NwYWNlLWFyb3VuZCcgfCAnc3BhY2UtZXZlbmx5J1xudHlwZSBTZXRGbGV4ID0gJ2luaGVyaXQnIHwgJ2luaXRpYWwnIHwgJ3JldmVydCcgfCAndW5zZXQnXG50eXBlIFdyYXAgPSAnbm93cmFwJyB8ICd3cmFwJyB8ICd3cmFwLXJldmVyc2UnXG5pbnRlcmZhY2UgSUZsZXhDb2x1bW5Qcm9wcyBleHRlbmRzIERldGFpbGVkSFRNTFByb3BzPEhUTUxBdHRyaWJ1dGVzPEhUTUxEaXZFbGVtZW50PiwgSFRNTERpdkVsZW1lbnQ+e1xuICB3aWR0aD86IG51bWJlciB8IHN0cmluZ1xuICBoZWlnaHQ/OiBudW1iZXIgfCBzdHJpbmdcbiAgYmFja2dyb3VuZD86IHN0cmluZ1xuICB3cmFwPzogV3JhcFxuICB2ZXJ0aWNhbEFsaWduPzogSnVzdGlmeUNvbnRlbnRcbiAgaG9yaXpvbnRhbEFsaWduPzogQWxpZ25JdGVuc1xuICBnYXA/OiBzdHJpbmcgfCBudW1iZXJcbiAgY29sdW1uR2FwPzogc3RyaW5nIHwgbnVtYmVyXG4gIHJvd0dhcD86IHN0cmluZyB8IG51bWJlclxuICBtYXJnaW4/OiBudW1iZXIgfCBzdHJpbmdcbiAgcGFkZGluZz86IG51bWJlciB8IHN0cmluZ1xuICBncm93PzogbnVtYmVyIHwgU2V0RmxleFxuICBzdHlsZXM/OiBDU1NQcm9wZXJ0aWVzXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufVxuXG5jb25zdCBGbGV4Q29sdW1uOkZDPElGbGV4Q29sdW1uUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgYmFja2dyb3VuZCxcbiAgICB2ZXJ0aWNhbEFsaWduLFxuICAgIGhvcml6b250YWxBbGlnbixcbiAgICB3cmFwLFxuICAgIGdhcCxcbiAgICBjb2x1bW5HYXAsXG4gICAgcm93R2FwLFxuICAgIG1hcmdpbixcbiAgICBwYWRkaW5nLFxuICAgIGdyb3csXG4gICAgc3R5bGVzLFxuICAgIGNsYXNzTmFtZSxcbiAgfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBzdHlsZT17e1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICAgICAgICBtYXJnaW46IG1hcmdpbixcbiAgICAgICAgcGFkZGluZzogcGFkZGluZyxcbiAgICAgICAgd2lkdGg6IHdpZHRoLFxuICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgYmFja2dyb3VuZDogYmFja2dyb3VuZCxcbiAgICAgICAgYWxpZ25JdGVtczogaG9yaXpvbnRhbEFsaWduLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogdmVydGljYWxBbGlnbixcbiAgICAgICAgZmxleFdyYXA6IHdyYXAsXG4gICAgICAgIGdhcDogZ2FwLFxuICAgICAgICBjb2x1bW5HYXA6IGNvbHVtbkdhcCB8fCBnYXAsXG4gICAgICAgIHJvd0dhcDogcm93R2FwIHx8IGdhcCxcbiAgICAgICAgZmxleEdyb3c6IGdyb3csXG4gICAgICAgIC4uLnN0eWxlcyxcbiAgICAgIH19XG4gICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRmxleENvbHVtblxuIl19