import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";
export default require_react();
//# sourceMappingURL=react.js.map
