import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/TermsDisplayModal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/TermsDisplayModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Modal } from "/src/shared/components/index.ts?t=1701096626433";
import { ConfidentialityTermsDisplay, IndependenceTermsDisplay } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
const TermsDisplayModal = (props) => {
  _s();
  const {
    isOpen,
    onDismiss,
    independenceTermsVisible,
    confidentialityTermsVisible,
    setTrueIndependenceTerms,
    setTrueConfidentialityTerms
  } = props;
  const modalTitle = useMemo(() => {
    if (independenceTermsVisible) {
      return "Termos de independência";
    }
    if (confidentialityTermsVisible) {
      return "Termos de confidencialidade";
    }
    return "Termos de independência e confidencialidade";
  }, [independenceTermsVisible, confidentialityTermsVisible]);
  return /* @__PURE__ */ jsxDEV(Modal, { isOpen, onDismiss, title: modalTitle, children: [
    independenceTermsVisible && /* @__PURE__ */ jsxDEV(IndependenceTermsDisplay, { setIndependenceTerms: setTrueIndependenceTerms, toggleIndependenceTermsVisible: onDismiss }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/TermsDisplayModal.tsx",
      lineNumber: 31,
      columnNumber: 34
    }, this),
    confidentialityTermsVisible && /* @__PURE__ */ jsxDEV(ConfidentialityTermsDisplay, { setConfidentialityTerms: setTrueConfidentialityTerms, toggleConfidentialityTermsVisible: onDismiss }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/TermsDisplayModal.tsx",
      lineNumber: 32,
      columnNumber: 37
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/TermsDisplayModal.tsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
};
_s(TermsDisplayModal, "1DZH1CYrZXoFSPaVQ2gYqoxYldM=");
_c = TermsDisplayModal;
export default TermsDisplayModal;
var _c;
$RefreshReg$(_c, "TermsDisplayModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/TermsDisplayModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNpQzs7Ozs7Ozs7Ozs7Ozs7OztBQXpDakMsU0FBd0JBLGVBQWU7QUFDdkMsU0FBU0MsYUFBeUI7QUFDbEMsU0FBU0MsNkJBQTZCQyxnQ0FBZ0M7QUFZdEUsTUFBTUMsb0JBQWlEQyxXQUFVO0FBQUFDLEtBQUE7QUFDL0QsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSVA7QUFFSixRQUFNUSxhQUFhYixRQUFnQixNQUFNO0FBQ3ZDLFFBQUlTLDBCQUEwQjtBQUM1QixhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUlDLDZCQUE2QjtBQUMvQixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNULEdBQUcsQ0FBQ0QsMEJBQTBCQywyQkFBMkIsQ0FBQztBQUUxRCxTQUFPLHVCQUFDLFNBQ04sUUFDQSxXQUNBLE9BQU9HLFlBRU5KO0FBQUFBLGdDQUE0Qix1QkFBQyw0QkFDNUIsc0JBQXNCRSwwQkFDdEIsZ0NBQWdDSCxhQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFZTtBQUFBLElBRTNDRSwrQkFBK0IsdUJBQUMsK0JBQy9CLHlCQUF5QkUsNkJBQ3pCLG1DQUFtQ0osYUFGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWU7QUFBQSxPQVgxQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYVA7QUFDRjtBQUFDRixHQXBDS0YsbUJBQTZDO0FBQUFVLEtBQTdDVjtBQXNDTixlQUFlQTtBQUFpQixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIk1vZGFsIiwiQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5IiwiSW5kZXBlbmRlbmNlVGVybXNEaXNwbGF5IiwiVGVybXNEaXNwbGF5TW9kYWwiLCJwcm9wcyIsIl9zIiwiaXNPcGVuIiwib25EaXNtaXNzIiwiaW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlIiwiY29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlIiwic2V0VHJ1ZUluZGVwZW5kZW5jZVRlcm1zIiwic2V0VHJ1ZUNvbmZpZGVudGlhbGl0eVRlcm1zIiwibW9kYWxUaXRsZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGVybXNEaXNwbGF5TW9kYWwudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jb250cmFjdHMvY29tcG9uZW50cy9UZXJtc0Rpc3BsYXlNb2RhbC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgRm9ybUV2ZW50LCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBNb2RhbCwgTW9kYWxQcm9wcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgQ29uZmlkZW50aWFsaXR5VGVybXNEaXNwbGF5LCBJbmRlcGVuZGVuY2VUZXJtc0Rpc3BsYXkgfSBmcm9tICcuJ1xuXG5pbnRlcmZhY2UgVGVybXNEaXNwbGF5TW9kYWxQcm9wcyBleHRlbmRzIFBpY2s8XG5Nb2RhbFByb3BzLFxuJ2lzT3Blbid8J29uRGlzbWlzcydcbj4ge1xuICBpbmRlcGVuZGVuY2VUZXJtc1Zpc2libGU/OmJvb2xlYW5cbiAgY29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlPzogYm9vbGVhblxuICBzZXRUcnVlSW5kZXBlbmRlbmNlVGVybXM6IChldjogRm9ybUV2ZW50PEhUTUxFbGVtZW50IHwgSFRNTElucHV0RWxlbWVudD4gfCB1bmRlZmluZWQsIHZhbHVlOiBib29sZWFuKSA9PiB2b2lkXG4gIHNldFRydWVDb25maWRlbnRpYWxpdHlUZXJtczogKGV2OiBGb3JtRXZlbnQ8SFRNTEVsZW1lbnQgfCBIVE1MSW5wdXRFbGVtZW50PiB8IHVuZGVmaW5lZCwgdmFsdWU6IGJvb2xlYW4pID0+IHZvaWRcbn1cblxuY29uc3QgVGVybXNEaXNwbGF5TW9kYWw6IEZDPFRlcm1zRGlzcGxheU1vZGFsUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBpc09wZW4sXG4gICAgb25EaXNtaXNzLFxuICAgIGluZGVwZW5kZW5jZVRlcm1zVmlzaWJsZSxcbiAgICBjb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGUsXG4gICAgc2V0VHJ1ZUluZGVwZW5kZW5jZVRlcm1zLFxuICAgIHNldFRydWVDb25maWRlbnRpYWxpdHlUZXJtcyxcbiAgfSA9IHByb3BzXG5cbiAgY29uc3QgbW9kYWxUaXRsZSA9IHVzZU1lbW88c3RyaW5nPigoKSA9PiB7XG4gICAgaWYgKGluZGVwZW5kZW5jZVRlcm1zVmlzaWJsZSkge1xuICAgICAgcmV0dXJuICdUZXJtb3MgZGUgaW5kZXBlbmTDqm5jaWEnXG4gICAgfVxuXG4gICAgaWYgKGNvbmZpZGVudGlhbGl0eVRlcm1zVmlzaWJsZSkge1xuICAgICAgcmV0dXJuICdUZXJtb3MgZGUgY29uZmlkZW5jaWFsaWRhZGUnXG4gICAgfVxuXG4gICAgcmV0dXJuICdUZXJtb3MgZGUgaW5kZXBlbmTDqm5jaWEgZSBjb25maWRlbmNpYWxpZGFkZSdcbiAgfSwgW2luZGVwZW5kZW5jZVRlcm1zVmlzaWJsZSwgY29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlXSlcblxuICByZXR1cm4gPE1vZGFsXG4gICAgaXNPcGVuPXtpc09wZW59XG4gICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XG4gICAgdGl0bGU9e21vZGFsVGl0bGV9XG4gID5cbiAgICB7aW5kZXBlbmRlbmNlVGVybXNWaXNpYmxlICYmIDxJbmRlcGVuZGVuY2VUZXJtc0Rpc3BsYXlcbiAgICAgIHNldEluZGVwZW5kZW5jZVRlcm1zPXtzZXRUcnVlSW5kZXBlbmRlbmNlVGVybXN9XG4gICAgICB0b2dnbGVJbmRlcGVuZGVuY2VUZXJtc1Zpc2libGU9e29uRGlzbWlzc31cbiAgICAvPn1cbiAgICB7Y29uZmlkZW50aWFsaXR5VGVybXNWaXNpYmxlICYmIDxDb25maWRlbnRpYWxpdHlUZXJtc0Rpc3BsYXlcbiAgICAgIHNldENvbmZpZGVudGlhbGl0eVRlcm1zPXtzZXRUcnVlQ29uZmlkZW50aWFsaXR5VGVybXN9XG4gICAgICB0b2dnbGVDb25maWRlbnRpYWxpdHlUZXJtc1Zpc2libGU9e29uRGlzbWlzc31cbiAgICAvPn1cbiAgPC9Nb2RhbD5cbn1cblxuZXhwb3J0IGRlZmF1bHQgVGVybXNEaXNwbGF5TW9kYWxcbiJdfQ==