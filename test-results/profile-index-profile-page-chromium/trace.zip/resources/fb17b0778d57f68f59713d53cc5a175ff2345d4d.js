import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Dropdown, DropdownMenuItemType, SearchBox, Persona } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { Checkbox, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import FlexItem from "/src/shared/components/FlexBox/FlexItem.tsx";
const SearchableDropdown = (props) => {
  _s();
  const {
    hasPersona,
    autoDropdownWidth,
    disabledSelectItems
  } = props;
  const [searchText, setSearchText] = useState("");
  const {
    colors
  } = useTheme();
  const filteredOptions = useMemo(() => {
    return props.options?.map((option) => !option.disabled && option.text.toLowerCase().indexOf(searchText.toLowerCase()) > -1 ? {
      ...option,
      disabled: disabledSelectItems || props.disabled || false
    } : {
      ...option,
      hidden: true,
      disabled: disabledSelectItems
    });
  }, [props.options, props.disabled, disabledSelectItems, searchText]);
  useEffect(() => {
    props.onChangeItems?.(filteredOptions);
  }, [props.onChangeItems, filteredOptions]);
  function renderOption(option) {
    return option.itemType === DropdownMenuItemType.Header && option.key === "FilterHeader" ? /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(SearchBox, { onChange: (_ev, newValue) => newValue ? setSearchText(newValue) : setSearchText(""), underlined: true, placeholder: "Pesquisar", styles: {
      root: {
        maxWidth: autoDropdownWidth ? "auto" : "200px",
        "&.is-active::after": {
          borderColor: colors.purple[500]
        }
      },
      icon: {
        color: colors.purple[500]
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 46,
      columnNumber: 95
    }, this) : option.itemType === DropdownMenuItemType.Header && option.key === "SelectAll" ? /* @__PURE__ */ jsxDEV(FlexItem, { grow: 1, children: /* @__PURE__ */ jsxDEV(TooltipHost, { content: props.disabledSelectAll ? props.disabledSelectAllHint : void 0, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Selecionar todos", disabled: props.disabledSelectAll || disabledSelectItems, onChange: (ev, checked) => props.onSelectAll?.(ev, checked, filteredOptions), checked: props.checked, styles: {
      root: {
        marginTop: 14
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 60,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 59,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 58,
      columnNumber: 101
    }, this) : hasPersona ? /* @__PURE__ */ jsxDEV(Persona, { text: option?.text, size: 8 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 66,
      columnNumber: 36
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: option.text }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
      lineNumber: 66,
      columnNumber: 79
    }, this);
  }
  const finalOptions = useMemo(() => {
    const searchBar = {
      key: "FilterHeader",
      text: "-",
      itemType: DropdownMenuItemType.Header
    };
    const selectAll = {
      key: "SelectAll",
      text: "-",
      itemType: DropdownMenuItemType.Header
    };
    const otherOptions = [{
      key: "divider_filterHeader",
      text: "-",
      itemType: DropdownMenuItemType.Divider
    }];
    if (filteredOptions)
      otherOptions.push(...filteredOptions);
    return props.hasSearch && props.hasSelectAll ? [searchBar, selectAll, ...otherOptions] : !props.hasSearch && props.hasSelectAll ? [selectAll, ...otherOptions] : props.hasSearch && !props.hasSelectAll ? [searchBar, ...otherOptions] : [...otherOptions];
  }, [props, filteredOptions]);
  return /* @__PURE__ */ jsxDEV(Dropdown, { ...props, styles: {
    dropdownItemSelected: {
      ".ms-Checkbox-checkbox": {
        backgroundColor: colors.purple[500],
        borderColor: colors.purple[500]
      },
      "&:hover .ms-Checkbox-checkbox": {
        backgroundColor: colors.purple[600],
        borderColor: colors.purple[600]
      }
    },
    dropdown: {
      "&:active .ms-Dropdown-title": {
        borderColor: colors.purple[800]
      },
      "&:focus::after": {
        borderColor: colors.purple[800]
      }
    },
    ...props.styles
  }, options: finalOptions, onRenderOption: renderOption, onDismiss: () => setSearchText(""), dropdownWidth: autoDropdownWidth ? "auto" : void 0, calloutProps: {
    calloutMaxHeight: 240
  }, required: props.required, errorMessage: props.errorMessage }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx",
    lineNumber: 87,
    columnNumber: 10
  }, this);
};
_s(SearchableDropdown, "VkBS/0VryooBxwGdS0chsgKJKPs=", false, function() {
  return [useTheme];
});
_c = SearchableDropdown;
export default SearchableDropdown;
var _c;
$RefreshReg$(_c, "SearchableDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dropdownsComboBoxes/SearchableDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENRLFNBMENJLFVBMUNKOzs7Ozs7Ozs7Ozs7Ozs7O0FBeENSLFNBQVNBLFVBQVVDLHNCQUFzQkMsV0FBZ0ZDLGVBQWU7QUFDeEksU0FBd0JDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUM1RCxTQUFTQyxVQUFVQyxtQkFBbUI7QUFDdEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGNBQWM7QUFlckIsTUFBTUMscUJBQW1EQyxXQUFVO0FBQUFDLEtBQUE7QUFDakUsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVlDO0FBQUFBLElBQW1CQztBQUFBQSxFQUFvQixJQUFJSjtBQUMvRCxRQUFNLENBQUNLLFlBQVlDLGFBQWEsSUFBSVosU0FBaUIsRUFBRTtBQUN2RCxRQUFNO0FBQUEsSUFBRWE7QUFBQUEsRUFBTyxJQUFJVixTQUFTO0FBRTVCLFFBQU1XLGtCQUFxQ2YsUUFBUSxNQUFNO0FBQ3ZELFdBQU9PLE1BQU1TLFNBQ1RDLElBQUlDLFlBQVUsQ0FBQ0EsT0FBT0MsWUFBWUQsT0FBT0UsS0FBS0MsWUFBWSxFQUN6REMsUUFBUVYsV0FBV1MsWUFBWSxDQUFDLElBQUksS0FDbkM7QUFBQSxNQUFFLEdBQUdIO0FBQUFBLE1BQVFDLFVBQVVSLHVCQUF1QkosTUFBTVksWUFBWTtBQUFBLElBQU0sSUFDdEU7QUFBQSxNQUFFLEdBQUdEO0FBQUFBLE1BQVFLLFFBQVE7QUFBQSxNQUFNSixVQUFVUjtBQUFBQSxJQUFvQixDQUM3RDtBQUFBLEVBQ0osR0FBRyxDQUFDSixNQUFNUyxTQUFTVCxNQUFNWSxVQUFVUixxQkFBcUJDLFVBQVUsQ0FBQztBQUVuRWIsWUFBVSxNQUFNO0FBQ2RRLFVBQU1pQixnQkFBZ0JULGVBQWU7QUFBQSxFQUN2QyxHQUFHLENBQUNSLE1BQU1pQixlQUFlVCxlQUFlLENBQUM7QUFFekMsV0FBU1UsYUFBY1AsUUFBeUI7QUFDOUMsV0FBUUEsT0FBT1EsYUFBYTlCLHFCQUFxQitCLFVBQVVULE9BQU9VLFFBQVEsaUJBQ3RFLHVCQUFDLFlBQVMsTUFBTSxHQUNoQixpQ0FBQyxhQUNDLFVBQVUsQ0FBQ0MsS0FBS0MsYUFBYUEsV0FDekJqQixjQUFjaUIsUUFBa0IsSUFDaENqQixjQUFjLEVBQUUsR0FDcEIsWUFBWSxNQUNaLGFBQVksYUFDWixRQUFRO0FBQUEsTUFDTmtCLE1BQU07QUFBQSxRQUNKQyxVQUFVdEIsb0JBQW9CLFNBQVM7QUFBQSxRQUN2QyxzQkFBc0I7QUFBQSxVQUNwQnVCLGFBQWFuQixPQUFPb0IsT0FBTyxHQUFHO0FBQUEsUUFDaEM7QUFBQSxNQUNGO0FBQUEsTUFDQUMsTUFBTTtBQUFBLFFBQ0pDLE9BQU90QixPQUFPb0IsT0FBTyxHQUFHO0FBQUEsTUFDMUI7QUFBQSxJQUNGLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkksS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CRixJQUNHaEIsT0FBT1EsYUFBYTlCLHFCQUFxQitCLFVBQVVULE9BQU9VLFFBQVEsY0FDakUsdUJBQUMsWUFBUyxNQUFNLEdBQ2hCLGlDQUFDLGVBQ0MsU0FBU3JCLE1BQU04QixvQkFBb0I5QixNQUFNK0Isd0JBQXdCQyxRQUVqRSxpQ0FBQyxZQUNDLE9BQU0sb0JBQ04sVUFBVWhDLE1BQU04QixxQkFBcUIxQixxQkFDckMsVUFBVSxDQUFDNkIsSUFBSUMsWUFBWWxDLE1BQU1tQyxjQUFjRixJQUFJQyxTQUFTMUIsZUFBZSxHQUMzRSxTQUFTUixNQUFNa0MsU0FDZixRQUFRO0FBQUEsTUFDTlYsTUFBTTtBQUFBLFFBQ0pZLFdBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTSSxLQVpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQSxLQWZBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkYsSUFDRWxDLGFBQ0UsdUJBQUMsV0FDRCxNQUFNUyxRQUFRRSxNQUNkLE1BQU0sS0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRVEsSUFFUixtQ0FBR0YsaUJBQU9FLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDekI7QUFFQSxRQUFNd0IsZUFBZTVDLFFBQVEsTUFBTTtBQUNqQyxVQUFNNkMsWUFBWTtBQUFBLE1BQUVqQixLQUFLO0FBQUEsTUFBZ0JSLE1BQU07QUFBQSxNQUFLTSxVQUFVOUIscUJBQXFCK0I7QUFBQUEsSUFBTztBQUMxRixVQUFNbUIsWUFBWTtBQUFBLE1BQUVsQixLQUFLO0FBQUEsTUFBYVIsTUFBTTtBQUFBLE1BQUtNLFVBQVU5QixxQkFBcUIrQjtBQUFBQSxJQUFPO0FBQ3ZGLFVBQU1vQixlQUFrQyxDQUN0QztBQUFBLE1BQUVuQixLQUFLO0FBQUEsTUFBd0JSLE1BQU07QUFBQSxNQUFLTSxVQUFVOUIscUJBQXFCb0Q7QUFBQUEsSUFBUSxDQUFDO0FBR3BGLFFBQUlqQztBQUFpQmdDLG1CQUFhRSxLQUFLLEdBQUdsQyxlQUFlO0FBRXpELFdBQU9SLE1BQU0yQyxhQUFhM0MsTUFBTTRDLGVBQzVCLENBQUNOLFdBQVdDLFdBQVcsR0FBR0MsWUFBWSxJQUN0QyxDQUFDeEMsTUFBTTJDLGFBQWEzQyxNQUFNNEMsZUFDeEIsQ0FBQ0wsV0FBVyxHQUFHQyxZQUFZLElBQzNCeEMsTUFBTTJDLGFBQWEsQ0FBQzNDLE1BQU00QyxlQUN4QixDQUFDTixXQUFXLEdBQUdFLFlBQVksSUFDM0IsQ0FBQyxHQUFHQSxZQUFZO0FBQUEsRUFDMUIsR0FBRyxDQUFDeEMsT0FBT1EsZUFBZSxDQUFDO0FBRTNCLFNBQ0UsdUJBQUMsWUFDQyxHQUFJUixPQUNKLFFBQVE7QUFBQSxJQUNONkMsc0JBQXNCO0FBQUEsTUFDcEIseUJBQXlCO0FBQUEsUUFDdkJDLGlCQUFpQnZDLE9BQU9vQixPQUFPLEdBQUc7QUFBQSxRQUNsQ0QsYUFBYW5CLE9BQU9vQixPQUFPLEdBQUc7QUFBQSxNQUNoQztBQUFBLE1BQ0EsaUNBQWlDO0FBQUEsUUFDL0JtQixpQkFBaUJ2QyxPQUFPb0IsT0FBTyxHQUFHO0FBQUEsUUFDbENELGFBQWFuQixPQUFPb0IsT0FBTyxHQUFHO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBQUEsSUFDQW9CLFVBQVU7QUFBQSxNQUNSLCtCQUErQjtBQUFBLFFBQzdCckIsYUFBYW5CLE9BQU9vQixPQUFPLEdBQUc7QUFBQSxNQUNoQztBQUFBLE1BQ0Esa0JBQWtCO0FBQUEsUUFDaEJELGFBQWFuQixPQUFPb0IsT0FBTyxHQUFHO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFHM0IsTUFBTWdEO0FBQUFBLEVBQ1gsR0FDQSxTQUFTWCxjQUNULGdCQUFnQm5CLGNBQ2hCLFdBQVcsTUFBTVosY0FBYyxFQUFFLEdBQ2pDLGVBQWVILG9CQUFvQixTQUFTNkIsUUFDNUMsY0FBYztBQUFBLElBQ1ppQixrQkFBa0I7QUFBQSxFQUNwQixHQUNBLFVBQVVqRCxNQUFNa0QsVUFDaEIsY0FBY2xELE1BQU1tRCxnQkEvQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQm1DO0FBR3ZDO0FBQUNsRCxHQXZIS0Ysb0JBQStDO0FBQUEsVUFHaENGLFFBQVE7QUFBQTtBQUFBdUQsS0FIdkJyRDtBQXlITixlQUFlQTtBQUFrQixJQUFBcUQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRyb3Bkb3duIiwiRHJvcGRvd25NZW51SXRlbVR5cGUiLCJTZWFyY2hCb3giLCJQZXJzb25hIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ2hlY2tib3giLCJUb29sdGlwSG9zdCIsInVzZVRoZW1lIiwiRmxleEl0ZW0iLCJTZWFyY2hhYmxlRHJvcGRvd24iLCJwcm9wcyIsIl9zIiwiaGFzUGVyc29uYSIsImF1dG9Ecm9wZG93bldpZHRoIiwiZGlzYWJsZWRTZWxlY3RJdGVtcyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiY29sb3JzIiwiZmlsdGVyZWRPcHRpb25zIiwib3B0aW9ucyIsIm1hcCIsIm9wdGlvbiIsImRpc2FibGVkIiwidGV4dCIsInRvTG93ZXJDYXNlIiwiaW5kZXhPZiIsImhpZGRlbiIsIm9uQ2hhbmdlSXRlbXMiLCJyZW5kZXJPcHRpb24iLCJpdGVtVHlwZSIsIkhlYWRlciIsImtleSIsIl9ldiIsIm5ld1ZhbHVlIiwicm9vdCIsIm1heFdpZHRoIiwiYm9yZGVyQ29sb3IiLCJwdXJwbGUiLCJpY29uIiwiY29sb3IiLCJkaXNhYmxlZFNlbGVjdEFsbCIsImRpc2FibGVkU2VsZWN0QWxsSGludCIsInVuZGVmaW5lZCIsImV2IiwiY2hlY2tlZCIsIm9uU2VsZWN0QWxsIiwibWFyZ2luVG9wIiwiZmluYWxPcHRpb25zIiwic2VhcmNoQmFyIiwic2VsZWN0QWxsIiwib3RoZXJPcHRpb25zIiwiRGl2aWRlciIsInB1c2giLCJoYXNTZWFyY2giLCJoYXNTZWxlY3RBbGwiLCJkcm9wZG93bkl0ZW1TZWxlY3RlZCIsImJhY2tncm91bmRDb2xvciIsImRyb3Bkb3duIiwic3R5bGVzIiwiY2FsbG91dE1heEhlaWdodCIsInJlcXVpcmVkIiwiZXJyb3JNZXNzYWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWFyY2hhYmxlRHJvcGRvd24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZHJvcGRvd25zQ29tYm9Cb3hlcy9TZWFyY2hhYmxlRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgaW5kZW50ICovXHJcblxyXG5pbXBvcnQgeyBEcm9wZG93biwgRHJvcGRvd25NZW51SXRlbVR5cGUsIFNlYXJjaEJveCwgSURyb3Bkb3duT3B0aW9uLCBJRHJvcGRvd25Qcm9wcywgSVJlbmRlckZ1bmN0aW9uLCBJU2VsZWN0YWJsZU9wdGlvbiwgUGVyc29uYSB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgRkMsIEZvcm1FdmVudCwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBDaGVja2JveCwgVG9vbHRpcEhvc3QgfSBmcm9tICcuLidcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi9ob29rcydcclxuaW1wb3J0IEZsZXhJdGVtIGZyb20gJy4vLi4vRmxleEJveC9GbGV4SXRlbSdcclxuXHJcbmludGVyZmFjZSBTZWFyY2hhYmxlRHJvcGRvd25Qcm9wcyBleHRlbmRzIElEcm9wZG93blByb3Bze1xyXG4gIGhhc1BlcnNvbmE/OiBib29sZWFuXHJcbiAgYXV0b0Ryb3Bkb3duV2lkdGg/OiBib29sZWFuXHJcbiAgb25TZWxlY3RBbGw/OiAoKGV2PzogRm9ybUV2ZW50PEhUTUxFbGVtZW50IHwgSFRNTElucHV0RWxlbWVudD4gfCB1bmRlZmluZWQsIGNoZWNrZWQ/OiBib29sZWFuIHwgdW5kZWZpbmVkLCBjaGVja2VkT3B0aW9ucz86IElEcm9wZG93bk9wdGlvbltdKSA9PiB2b2lkKSB8IHVuZGVmaW5lZFxyXG4gIGNoZWNrZWQ/OiBib29sZWFuXHJcbiAgaGFzU2VhcmNoPzogYm9vbGVhblxyXG4gIGhhc1NlbGVjdEFsbD86IGJvb2xlYW5cclxuICBkaXNhYmxlZFNlbGVjdEFsbD86IGJvb2xlYW5cclxuICBkaXNhYmxlZFNlbGVjdEFsbEhpbnQ/OiBzdHJpbmdcclxuICBkaXNhYmxlZFNlbGVjdEl0ZW1zPzogYm9vbGVhblxyXG4gIG9uQ2hhbmdlSXRlbXM/OiAob3B0aW9uczogSURyb3Bkb3duT3B0aW9uW10pID0+IHZvaWQ7XHJcbn1cclxuXHJcbmNvbnN0IFNlYXJjaGFibGVEcm9wZG93bjogRkM8U2VhcmNoYWJsZURyb3Bkb3duUHJvcHM+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBoYXNQZXJzb25hLCBhdXRvRHJvcGRvd25XaWR0aCwgZGlzYWJsZWRTZWxlY3RJdGVtcyB9ID0gcHJvcHNcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKVxyXG4gIGNvbnN0IHsgY29sb3JzIH0gPSB1c2VUaGVtZSgpXHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkT3B0aW9uczogSURyb3Bkb3duT3B0aW9uW10gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBwcm9wcy5vcHRpb25zXHJcbiAgICAgID8ubWFwKG9wdGlvbiA9PiAhb3B0aW9uLmRpc2FibGVkICYmIG9wdGlvbi50ZXh0LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAuaW5kZXhPZihzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpID4gLTFcclxuICAgICAgICA/IHsgLi4ub3B0aW9uLCBkaXNhYmxlZDogZGlzYWJsZWRTZWxlY3RJdGVtcyB8fCBwcm9wcy5kaXNhYmxlZCB8fCBmYWxzZSB9XHJcbiAgICAgICAgOiB7IC4uLm9wdGlvbiwgaGlkZGVuOiB0cnVlLCBkaXNhYmxlZDogZGlzYWJsZWRTZWxlY3RJdGVtcyB9LFxyXG4gICAgICApXHJcbiAgfSwgW3Byb3BzLm9wdGlvbnMsIHByb3BzLmRpc2FibGVkLCBkaXNhYmxlZFNlbGVjdEl0ZW1zLCBzZWFyY2hUZXh0XSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHByb3BzLm9uQ2hhbmdlSXRlbXM/LihmaWx0ZXJlZE9wdGlvbnMpXHJcbiAgfSwgW3Byb3BzLm9uQ2hhbmdlSXRlbXMsIGZpbHRlcmVkT3B0aW9uc10pXHJcblxyXG4gIGZ1bmN0aW9uIHJlbmRlck9wdGlvbiAob3B0aW9uOiBJRHJvcGRvd25PcHRpb24pIHtcclxuICAgIHJldHVybiAob3B0aW9uLml0ZW1UeXBlID09PSBEcm9wZG93bk1lbnVJdGVtVHlwZS5IZWFkZXIgJiYgb3B0aW9uLmtleSA9PT0gJ0ZpbHRlckhlYWRlcicpXHJcbiAgICAgID8gPEZsZXhJdGVtIGdyb3c9ezF9PlxyXG4gICAgICAgIDxTZWFyY2hCb3hcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoX2V2LCBuZXdWYWx1ZSkgPT4gbmV3VmFsdWVcclxuICAgICAgICAgICAgPyBzZXRTZWFyY2hUZXh0KG5ld1ZhbHVlIGFzIHN0cmluZylcclxuICAgICAgICAgICAgOiBzZXRTZWFyY2hUZXh0KCcnKX1cclxuICAgICAgICAgIHVuZGVybGluZWQ9e3RydWV9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBlc3F1aXNhclwiXHJcbiAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgIG1heFdpZHRoOiBhdXRvRHJvcGRvd25XaWR0aCA/ICdhdXRvJyA6ICcyMDBweCcsXHJcbiAgICAgICAgICAgICAgJyYuaXMtYWN0aXZlOjphZnRlcic6IHtcclxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaWNvbjoge1xyXG4gICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMucHVycGxlWzUwMF0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgIDogKG9wdGlvbi5pdGVtVHlwZSA9PT0gRHJvcGRvd25NZW51SXRlbVR5cGUuSGVhZGVyICYmIG9wdGlvbi5rZXkgPT09ICdTZWxlY3RBbGwnKVxyXG4gICAgICAgID8gPEZsZXhJdGVtIGdyb3c9ezF9PlxyXG4gICAgICAgICAgPFRvb2x0aXBIb3N0XHJcbiAgICAgICAgICAgIGNvbnRlbnQ9e3Byb3BzLmRpc2FibGVkU2VsZWN0QWxsID8gcHJvcHMuZGlzYWJsZWRTZWxlY3RBbGxIaW50IDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICBsYWJlbD0nU2VsZWNpb25hciB0b2RvcydcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cHJvcHMuZGlzYWJsZWRTZWxlY3RBbGwgfHwgZGlzYWJsZWRTZWxlY3RJdGVtc31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2LCBjaGVja2VkKSA9PiBwcm9wcy5vblNlbGVjdEFsbD8uKGV2LCBjaGVja2VkLCBmaWx0ZXJlZE9wdGlvbnMpfVxyXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e3Byb3BzLmNoZWNrZWR9XHJcbiAgICAgICAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTQsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L1Rvb2x0aXBIb3N0PlxyXG4gICAgICAgIDwvRmxleEl0ZW0+XHJcbiAgICAgICAgOiBoYXNQZXJzb25hXHJcbiAgICAgICAgICA/IDxQZXJzb25hXHJcbiAgICAgICAgICAgIHRleHQ9e29wdGlvbj8udGV4dH1cclxuICAgICAgICAgICAgc2l6ZT17OH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA6IDw+e29wdGlvbi50ZXh0fTwvPlxyXG4gIH1cclxuXHJcbiAgY29uc3QgZmluYWxPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBzZWFyY2hCYXIgPSB7IGtleTogJ0ZpbHRlckhlYWRlcicsIHRleHQ6ICctJywgaXRlbVR5cGU6IERyb3Bkb3duTWVudUl0ZW1UeXBlLkhlYWRlciB9XHJcbiAgICBjb25zdCBzZWxlY3RBbGwgPSB7IGtleTogJ1NlbGVjdEFsbCcsIHRleHQ6ICctJywgaXRlbVR5cGU6IERyb3Bkb3duTWVudUl0ZW1UeXBlLkhlYWRlciB9XHJcbiAgICBjb25zdCBvdGhlck9wdGlvbnM6IElEcm9wZG93bk9wdGlvbltdID0gW1xyXG4gICAgICB7IGtleTogJ2RpdmlkZXJfZmlsdGVySGVhZGVyJywgdGV4dDogJy0nLCBpdGVtVHlwZTogRHJvcGRvd25NZW51SXRlbVR5cGUuRGl2aWRlciB9LFxyXG4gICAgXVxyXG5cclxuICAgIGlmIChmaWx0ZXJlZE9wdGlvbnMpIG90aGVyT3B0aW9ucy5wdXNoKC4uLmZpbHRlcmVkT3B0aW9ucylcclxuXHJcbiAgICByZXR1cm4gcHJvcHMuaGFzU2VhcmNoICYmIHByb3BzLmhhc1NlbGVjdEFsbFxyXG4gICAgICA/IFtzZWFyY2hCYXIsIHNlbGVjdEFsbCwgLi4ub3RoZXJPcHRpb25zXVxyXG4gICAgICA6ICFwcm9wcy5oYXNTZWFyY2ggJiYgcHJvcHMuaGFzU2VsZWN0QWxsXHJcbiAgICAgICAgPyBbc2VsZWN0QWxsLCAuLi5vdGhlck9wdGlvbnNdXHJcbiAgICAgICAgOiBwcm9wcy5oYXNTZWFyY2ggJiYgIXByb3BzLmhhc1NlbGVjdEFsbFxyXG4gICAgICAgICAgPyBbc2VhcmNoQmFyLCAuLi5vdGhlck9wdGlvbnNdXHJcbiAgICAgICAgICA6IFsuLi5vdGhlck9wdGlvbnNdXHJcbiAgfSwgW3Byb3BzLCBmaWx0ZXJlZE9wdGlvbnNdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPERyb3Bkb3duXHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgZHJvcGRvd25JdGVtU2VsZWN0ZWQ6IHtcclxuICAgICAgICAgICcubXMtQ2hlY2tib3gtY2hlY2tib3gnOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgICcmOmhvdmVyIC5tcy1DaGVja2JveC1jaGVja2JveCc6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXHJcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzYwMF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZHJvcGRvd246IHtcclxuICAgICAgICAgICcmOmFjdGl2ZSAubXMtRHJvcGRvd24tdGl0bGUnOiB7XHJcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBjb2xvcnMucHVycGxlWzgwMF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgJyY6Zm9jdXM6OmFmdGVyJzoge1xyXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogY29sb3JzLnB1cnBsZVs4MDBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIC4uLnByb3BzLnN0eWxlcyxcclxuICAgICAgfX1cclxuICAgICAgb3B0aW9ucz17ZmluYWxPcHRpb25zfVxyXG4gICAgICBvblJlbmRlck9wdGlvbj17cmVuZGVyT3B0aW9uIGFzIElSZW5kZXJGdW5jdGlvbjxJU2VsZWN0YWJsZU9wdGlvbj59XHJcbiAgICAgIG9uRGlzbWlzcz17KCkgPT4gc2V0U2VhcmNoVGV4dCgnJyl9XHJcbiAgICAgIGRyb3Bkb3duV2lkdGg9e2F1dG9Ecm9wZG93bldpZHRoID8gJ2F1dG8nIDogdW5kZWZpbmVkfVxyXG4gICAgICBjYWxsb3V0UHJvcHM9e3tcclxuICAgICAgICBjYWxsb3V0TWF4SGVpZ2h0OiAyNDAsXHJcbiAgICAgIH19XHJcbiAgICAgIHJlcXVpcmVkPXtwcm9wcy5yZXF1aXJlZH1cclxuICAgICAgZXJyb3JNZXNzYWdlPXtwcm9wcy5lcnJvck1lc3NhZ2V9XHJcbiAgICAvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2VhcmNoYWJsZURyb3Bkb3duXHJcbiJdfQ==