import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/resource/ResourceList.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useContext = __vite__cjsImport3_react["useContext"];
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { ErrorBoundary } from "/node_modules/.vite/deps/react-error-boundary.js?v=9f90a7ff";
import { ErrorScreen, LoadingScreen, DataTable, ConfirmDeletion } from "/src/shared/components/index.ts?t=1701096626433";
import { ResourceListActions, ResourceEditDrawer, ResourceDetailsDrawer, ResourceCreateDrawer } from "/src/shared/components/resource/index.ts?t=1701096626433";
import { ActiveCompanyContext } from "/src/modules/admin/companies/context/ActiveCompany.ts";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
function ResourceList(props) {
  _s();
  const {
    addTitle,
    editTitle,
    detailsTitle,
    deleteTitle,
    deleteSubtitle,
    service: service2,
    columns,
    editForm,
    detailsView,
    mapMenuOptions,
    findAllParams = [],
    multipleSelection = true,
    selection,
    onSelection,
    onDetailAction,
    onEditAction,
    onAfterSave,
    deletePermission,
    createPermission,
    visualizePermission,
    updatePermission
  } = props;
  const [localSelection, setLocalSelection] = useState([]);
  const [itemsForRemoval, setItemsForRemoval] = useState([]);
  const {
    company
  } = useContext(ActiveCompanyContext);
  const {
    setIsLoading: setGlobalLoading
  } = useContext(LoadingDataContext);
  const [hideConfirmRemoval, {
    setTrue: closeConfirmRemoval,
    setFalse: openConfirmRemoval
  }] = useBoolean(true);
  const [isAddDrawerOpen, {
    setTrue: openAddDrawer,
    setFalse: closeAddDrawer
  }] = useBoolean(false);
  const [isEditDrawerOpen, {
    setTrue: openEditDrawer,
    setFalse: closeEditDrawer
  }] = useBoolean(false);
  const [isDetailsDrawerOpen, {
    setTrue: openDetailsDrawer,
    setFalse: closeDetailsDrawer
  }] = useBoolean(false);
  const {
    isLoading,
    error,
    data
  } = service2.useFindAllPaginated(...findAllParams);
  const {
    mutateAsync: deleteItem
  } = service2.useDelete();
  useEffect(() => {
    setGlobalLoading(isLoading);
  }, [isLoading]);
  useEffect(() => {
    if (selection && selection !== localSelection) {
      setLocalSelection(selection);
    }
  }, [selection, localSelection]);
  const handleSelection = useCallback((items) => {
    setLocalSelection(items);
    onSelection?.(items);
  }, []);
  const askForRemovalConfirmation = useCallback((items) => {
    setItemsForRemoval(items);
    openConfirmRemoval();
  }, []);
  const removeItems = useCallback(async () => {
    await Promise.allSettled(itemsForRemoval.map((item) => item.id ? deleteItem(item) : Promise.resolve()));
    closeConfirmRemoval();
    setItemsForRemoval([]);
    handleSelection([]);
  }, [itemsForRemoval]);
  useEffect(() => {
    service2.invalidateQueries();
  }, [company]);
  const defaultMenuOptions = useCallback((item) => {
    const menu = [];
    if (visualizePermission) {
      menu.push({
        key: "detail",
        text: "Detalhar",
        onClick: onDetailAction ? () => onDetailAction(item) : () => openDetailsDrawer()
      });
      if (updatePermission) {
        menu.push({
          key: "edit",
          text: "Alterar",
          onClick: onEditAction ? () => onEditAction(item) : () => openEditDrawer()
        });
      }
      if (deletePermission) {
        menu.push({
          key: "remove",
          text: "Excluir",
          onClick: () => askForRemovalConfirmation([item])
        });
      }
    }
    return menu;
  }, []);
  const menuOptions = useCallback((item) => mapMenuOptions ? mapMenuOptions(item, defaultMenuOptions(item)) : defaultMenuOptions(item), []);
  const actions = useCallback(() => /* @__PURE__ */ jsxDEV(ResourceListActions, { disabledRemoveButton: localSelection.length === 0, onAddClick: () => openAddDrawer(), onRemoveClick: () => askForRemovalConfirmation(localSelection), deletePermission, createPermission }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
    lineNumber: 145,
    columnNumber: 37
  }, this), [localSelection]);
  if (isLoading)
    return /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 146,
      columnNumber: 25
    }, this);
  if (error)
    return /* @__PURE__ */ jsxDEV(ErrorScreen, { error }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 147,
      columnNumber: 21
    }, this);
  return /* @__PURE__ */ jsxDEV(ErrorBoundary, { fallbackRender: ({
    error: error2
  }) => /* @__PURE__ */ jsxDEV(ErrorScreen, { error: error2 }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
    lineNumber: 150,
    columnNumber: 9
  }, this), children: [
    /* @__PURE__ */ jsxDEV(DataTable, { items: data?.value, columns, hasSearch: true, paginated: true, hasControlsColumn: true, menuOptions, renderActions: actions, hasSelection: true, multipleSelection, selection, onSelection: handleSelection }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    isAddDrawerOpen && /* @__PURE__ */ jsxDEV(ResourceCreateDrawer, { title: addTitle, isOpen: isAddDrawerOpen, editForm, onDismiss: closeAddDrawer, service: service2, onAfterSave }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 152,
      columnNumber: 27
    }, this),
    isEditDrawerOpen && localSelection[0]?.id && /* @__PURE__ */ jsxDEV(ResourceEditDrawer, { title: editTitle, isOpen: isEditDrawerOpen, editForm, onDismiss: closeEditDrawer, service: service2, id: localSelection[0].id }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 153,
      columnNumber: 53
    }, this),
    isDetailsDrawerOpen && detailsView && localSelection[0]?.id && /* @__PURE__ */ jsxDEV(ResourceDetailsDrawer, { title: detailsTitle ?? "", isOpen: isDetailsDrawerOpen, onDismiss: closeDetailsDrawer, service: service2, id: localSelection[0].id, detailsView }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 154,
      columnNumber: 71
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDeletion, { hidden: hideConfirmRemoval, onDismiss: closeConfirmRemoval, onConfirm: removeItems, deleteTitle, deleteSubtitle }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx",
    lineNumber: 148,
    columnNumber: 10
  }, this);
}
_s(ResourceList, "40pVSfesktJrTpp+7gnZ1M48FV0=", false, function() {
  return [useBoolean, useBoolean, useBoolean, useBoolean, service.useFindAllPaginated, service.useDelete];
});
_c = ResourceList;
export default ResourceList;
var _c;
$RefreshReg$(_c, "ResourceList");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/resource/ResourceList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEtJOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUtKLFNBQVNBLFVBQVVDLGFBQWFDLFdBQXlCQyxrQkFBa0I7QUFDM0UsU0FBU0Msa0JBQWtCO0FBRTNCLFNBQVNDLHFCQUFxQjtBQUs5QixTQUVFQyxhQUNBQyxlQUNBQyxXQUNBQyx1QkFDSztBQUNQLFNBQ0VDLHFCQUNBQyxvQkFDQUMsdUJBQ0FDLDRCQUNLO0FBQ1AsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLDBCQUEwQjtBQTBCbkMsU0FBU0MsYUFDUEMsT0FDYztBQUFBQyxLQUFBO0FBQ2QsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLGdCQUFnQjtBQUFBLElBQ2hCQyxvQkFBb0I7QUFBQSxJQUNwQkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJdEI7QUFFSixRQUFNLENBQUN1QixnQkFBZ0JDLGlCQUFpQixJQUFJekMsU0FBYyxFQUFFO0FBQzVELFFBQU0sQ0FBQzBDLGlCQUFpQkMsa0JBQWtCLElBQUkzQyxTQUFjLEVBQUU7QUFFOUQsUUFBTTtBQUFBLElBQUU0QztBQUFBQSxFQUFRLElBQUl6QyxXQUFXVyxvQkFBb0I7QUFDbkQsUUFBTTtBQUFBLElBQUUrQixjQUFjQztBQUFBQSxFQUFpQixJQUFJM0MsV0FBV1ksa0JBQWtCO0FBRXhFLFFBQU0sQ0FDSmdDLG9CQUNBO0FBQUEsSUFBRUMsU0FBU0M7QUFBQUEsSUFBcUJDLFVBQVVDO0FBQUFBLEVBQW1CLENBQUMsSUFDNUQvQyxXQUFXLElBQUk7QUFDbkIsUUFBTSxDQUNKZ0QsaUJBQ0E7QUFBQSxJQUFFSixTQUFTSztBQUFBQSxJQUFlSCxVQUFVSTtBQUFBQSxFQUFlLENBQUMsSUFDbERsRCxXQUFXLEtBQUs7QUFDcEIsUUFBTSxDQUNKbUQsa0JBQ0E7QUFBQSxJQUFFUCxTQUFTUTtBQUFBQSxJQUFnQk4sVUFBVU87QUFBQUEsRUFBZ0IsQ0FBQyxJQUNwRHJELFdBQVcsS0FBSztBQUNwQixRQUFNLENBQ0pzRCxxQkFDQTtBQUFBLElBQUVWLFNBQVNXO0FBQUFBLElBQW1CVCxVQUFVVTtBQUFBQSxFQUFtQixDQUFDLElBQzFEeEQsV0FBVyxLQUFLO0FBRXBCLFFBQU07QUFBQSxJQUFFeUQ7QUFBQUEsSUFBV0M7QUFBQUEsSUFBT0M7QUFBQUEsRUFBSyxJQUFJdkMsU0FBUXdDLG9CQUFvQixHQUFHbkMsYUFBYTtBQUMvRSxRQUFNO0FBQUEsSUFBRW9DLGFBQWFDO0FBQUFBLEVBQVcsSUFBSTFDLFNBQVEyQyxVQUFVO0FBRXREakUsWUFBVSxNQUFNO0FBQ2Q0QyxxQkFBaUJlLFNBQVM7QUFBQSxFQUM1QixHQUFHLENBQUNBLFNBQVMsQ0FBQztBQUVkM0QsWUFBVSxNQUFNO0FBQ2QsUUFBSTZCLGFBQWFBLGNBQWNTLGdCQUFnQjtBQUM3Q0Msd0JBQWtCVixTQUFTO0FBQUEsSUFDN0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsV0FBV1MsY0FBYyxDQUFDO0FBRTlCLFFBQU00QixrQkFBa0JuRSxZQUFZLENBQUNvRSxVQUFlO0FBQ2xENUIsc0JBQWtCNEIsS0FBSztBQUN2QnJDLGtCQUFjcUMsS0FBSztBQUFBLEVBQ3JCLEdBQUcsRUFBRTtBQUVMLFFBQU1DLDRCQUE0QnJFLFlBQVksQ0FBQ29FLFVBQWU7QUFDNUQxQix1QkFBbUIwQixLQUFLO0FBQ3hCbEIsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxFQUFFO0FBRUwsUUFBTW9CLGNBQWN0RSxZQUFZLFlBQVk7QUFDMUMsVUFBTXVFLFFBQVFDLFdBQ1ovQixnQkFBZ0JnQyxJQUFJQyxVQUFRQSxLQUFLQyxLQUM3QlYsV0FBV1MsSUFBSSxJQUNmSCxRQUFRSyxRQUFRLENBQ3BCLENBQ0Y7QUFDQTVCLHdCQUFvQjtBQUNwQk4sdUJBQW1CLEVBQUU7QUFDckJ5QixvQkFBZ0IsRUFBRTtBQUFBLEVBQ3BCLEdBQUcsQ0FBQzFCLGVBQWUsQ0FBQztBQUVwQnhDLFlBQVUsTUFBTTtBQUNkc0IsYUFBUXNELGtCQUFrQjtBQUFBLEVBQzVCLEdBQUcsQ0FBQ2xDLE9BQU8sQ0FBQztBQUVaLFFBQU1tQyxxQkFBcUI5RSxZQUFZLENBQUMwRSxTQUFtQztBQUN6RSxVQUFNSyxPQUFPO0FBQ2IsUUFBSTFDLHFCQUFxQjtBQUN2QjBDLFdBQUtDLEtBQUs7QUFBQSxRQUNSQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLFFBQ05DLFNBQVNuRCxpQkFDTCxNQUFNQSxlQUFlMEMsSUFBSSxJQUN6QixNQUFNaEIsa0JBQWtCO0FBQUEsTUFDOUIsQ0FBQztBQUNELFVBQUlwQixrQkFBa0I7QUFDcEJ5QyxhQUFLQyxLQUFLO0FBQUEsVUFDUkMsS0FBSztBQUFBLFVBQ0xDLE1BQU07QUFBQSxVQUNOQyxTQUFTbEQsZUFDTCxNQUFNQSxhQUFheUMsSUFBSSxJQUN2QixNQUFNbkIsZUFBZTtBQUFBLFFBQzNCLENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSXBCLGtCQUFrQjtBQUNwQjRDLGFBQUtDLEtBQUs7QUFBQSxVQUNSQyxLQUFLO0FBQUEsVUFDTEMsTUFBTTtBQUFBLFVBQ05DLFNBQVNBLE1BQU1kLDBCQUEwQixDQUFDSyxJQUFJLENBQUM7QUFBQSxRQUNqRCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSxXQUFPSztBQUFBQSxFQUNULEdBQUcsRUFBRTtBQUVMLFFBQU1LLGNBQWNwRixZQUFZLENBQUMwRSxTQUMvQi9DLGlCQUNJQSxlQUFlK0MsTUFBTUksbUJBQW1CSixJQUFJLENBQUMsSUFDN0NJLG1CQUFtQkosSUFBSSxHQUMxQixFQUFFO0FBRUwsUUFBTVcsVUFBVXJGLFlBQVksTUFDMUIsdUJBQUMsdUJBQ0Msc0JBQXNCdUMsZUFBZStDLFdBQVcsR0FDaEQsWUFBWSxNQUFNbEMsY0FBYyxHQUNoQyxlQUFlLE1BQU1pQiwwQkFBMEI5QixjQUFjLEdBQzdELGtCQUNBLG9CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLcUMsR0FFcEMsQ0FBQ0EsY0FBYyxDQUFDO0FBRW5CLE1BQUlxQjtBQUFXLFdBQU8sdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBRXBDLE1BQUlDO0FBQU8sV0FBTyx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUU1QyxTQUNFLHVCQUFDLGlCQUNDLGdCQUFnQixDQUFDO0FBQUEsSUFBRUE7QUFBQUEsRUFBTSxNQUN2Qix1QkFBQyxlQUFZLE9BQU9BLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEIsR0FHNUI7QUFBQSwyQkFBQyxhQUNDLE9BQU9DLE1BQU15QixPQUNiLFNBQ0EsV0FBUyxNQUNULFdBQVMsTUFDVCxtQkFBaUIsTUFDakIsYUFDQSxlQUFlRixTQUNmLGNBQVksTUFDWixtQkFDQSxXQUNBLGFBQWFsQixtQkFYZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVytCO0FBQUEsSUFFOUJoQixtQkFBbUIsdUJBQUMsd0JBQ25CLE9BQU9qQyxVQUNQLFFBQVFpQyxpQkFDUixVQUNBLFdBQVdFLGdCQUNYLFNBQVM5QixVQUNULGVBTmtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNTztBQUFBLElBRTFCK0Isb0JBQW9CZixlQUFlLENBQUMsR0FBR29DLE1BQ3RDLHVCQUFDLHNCQUNDLE9BQU94RCxXQUNQLFFBQVFtQyxrQkFDUixVQUNBLFdBQVdFLGlCQUNYLFNBQVNqQyxVQUNULElBQUlnQixlQUFlLENBQUMsRUFBRW9DLE1BTnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNMkI7QUFBQSxJQUc1QmxCLHVCQUF1Qi9CLGVBQWVhLGVBQWUsQ0FBQyxHQUFHb0MsTUFDeEQsdUJBQUMseUJBQ0MsT0FBT3ZELGdCQUFnQixJQUN2QixRQUFRcUMscUJBQ1IsV0FBV0Usb0JBQ1gsU0FBU3BDLFVBQ1QsSUFBSWdCLGVBQWUsQ0FBQyxFQUFFb0MsSUFDdEIsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTTJCO0FBQUEsSUFHN0IsdUJBQUMsbUJBQ0MsUUFBUTdCLG9CQUNSLFdBQVdFLHFCQUNYLFdBQVdzQixhQUNYLGFBQ0Esa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtpQztBQUFBLE9BbkRuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcURBO0FBRUo7QUFBQ3JELEdBbk1RRixjQUFZO0FBQUEsVUFvQ2ZaLFlBSUFBLFlBSUFBLFlBSUFBLFlBRStCb0IsUUFBUXdDLHFCQUNQeEMsUUFBUTJDLFNBQVM7QUFBQTtBQUFBc0IsS0FuRDlDekU7QUFxTVQsZUFBZUE7QUFBWSxJQUFBeUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VDb250ZXh0IiwidXNlQm9vbGVhbiIsIkVycm9yQm91bmRhcnkiLCJFcnJvclNjcmVlbiIsIkxvYWRpbmdTY3JlZW4iLCJEYXRhVGFibGUiLCJDb25maXJtRGVsZXRpb24iLCJSZXNvdXJjZUxpc3RBY3Rpb25zIiwiUmVzb3VyY2VFZGl0RHJhd2VyIiwiUmVzb3VyY2VEZXRhaWxzRHJhd2VyIiwiUmVzb3VyY2VDcmVhdGVEcmF3ZXIiLCJBY3RpdmVDb21wYW55Q29udGV4dCIsIkxvYWRpbmdEYXRhQ29udGV4dCIsIlJlc291cmNlTGlzdCIsInByb3BzIiwiX3MiLCJhZGRUaXRsZSIsImVkaXRUaXRsZSIsImRldGFpbHNUaXRsZSIsImRlbGV0ZVRpdGxlIiwiZGVsZXRlU3VidGl0bGUiLCJzZXJ2aWNlIiwiY29sdW1ucyIsImVkaXRGb3JtIiwiZGV0YWlsc1ZpZXciLCJtYXBNZW51T3B0aW9ucyIsImZpbmRBbGxQYXJhbXMiLCJtdWx0aXBsZVNlbGVjdGlvbiIsInNlbGVjdGlvbiIsIm9uU2VsZWN0aW9uIiwib25EZXRhaWxBY3Rpb24iLCJvbkVkaXRBY3Rpb24iLCJvbkFmdGVyU2F2ZSIsImRlbGV0ZVBlcm1pc3Npb24iLCJjcmVhdGVQZXJtaXNzaW9uIiwidmlzdWFsaXplUGVybWlzc2lvbiIsInVwZGF0ZVBlcm1pc3Npb24iLCJsb2NhbFNlbGVjdGlvbiIsInNldExvY2FsU2VsZWN0aW9uIiwiaXRlbXNGb3JSZW1vdmFsIiwic2V0SXRlbXNGb3JSZW1vdmFsIiwiY29tcGFueSIsInNldElzTG9hZGluZyIsInNldEdsb2JhbExvYWRpbmciLCJoaWRlQ29uZmlybVJlbW92YWwiLCJzZXRUcnVlIiwiY2xvc2VDb25maXJtUmVtb3ZhbCIsInNldEZhbHNlIiwib3BlbkNvbmZpcm1SZW1vdmFsIiwiaXNBZGREcmF3ZXJPcGVuIiwib3BlbkFkZERyYXdlciIsImNsb3NlQWRkRHJhd2VyIiwiaXNFZGl0RHJhd2VyT3BlbiIsIm9wZW5FZGl0RHJhd2VyIiwiY2xvc2VFZGl0RHJhd2VyIiwiaXNEZXRhaWxzRHJhd2VyT3BlbiIsIm9wZW5EZXRhaWxzRHJhd2VyIiwiY2xvc2VEZXRhaWxzRHJhd2VyIiwiaXNMb2FkaW5nIiwiZXJyb3IiLCJkYXRhIiwidXNlRmluZEFsbFBhZ2luYXRlZCIsIm11dGF0ZUFzeW5jIiwiZGVsZXRlSXRlbSIsInVzZURlbGV0ZSIsImhhbmRsZVNlbGVjdGlvbiIsIml0ZW1zIiwiYXNrRm9yUmVtb3ZhbENvbmZpcm1hdGlvbiIsInJlbW92ZUl0ZW1zIiwiUHJvbWlzZSIsImFsbFNldHRsZWQiLCJtYXAiLCJpdGVtIiwiaWQiLCJyZXNvbHZlIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJkZWZhdWx0TWVudU9wdGlvbnMiLCJtZW51IiwicHVzaCIsImtleSIsInRleHQiLCJvbkNsaWNrIiwibWVudU9wdGlvbnMiLCJhY3Rpb25zIiwibGVuZ3RoIiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlc291cmNlTGlzdC50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9yZXNvdXJjZS9SZXNvdXJjZUxpc3QudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcbmltcG9ydCB7IElDb250ZXh0dWFsTWVudUl0ZW0gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG5pbXBvcnQgeyBSZXNvdXJjZVF1ZXJ5U2VydmljZSB9IGZyb20gJy4uLy4uL2FwaS9SZXNvdXJjZVF1ZXJ5U2VydmljZSdcbmltcG9ydCB7IEVkaXRGb3JtIH0gZnJvbSAnLi4vLi4vdHlwZXMvRWRpdEZvcm0nXG5pbXBvcnQgeyBEZXRhaWxzVmlldyB9IGZyb20gJy4uLy4uL3R5cGVzL0RldGFpbHNWaWV3J1xuaW1wb3J0IEVudGl0eSBmcm9tICcuLi8uLi8uLi9kb21haW4vRW50aXR5J1xuaW1wb3J0IHtcbiAgRGF0YVRhYmxlQ29sdW1uLFxuICBFcnJvclNjcmVlbixcbiAgTG9hZGluZ1NjcmVlbixcbiAgRGF0YVRhYmxlLFxuICBDb25maXJtRGVsZXRpb24sXG59IGZyb20gJy4uJ1xuaW1wb3J0IHtcbiAgUmVzb3VyY2VMaXN0QWN0aW9ucyxcbiAgUmVzb3VyY2VFZGl0RHJhd2VyLFxuICBSZXNvdXJjZURldGFpbHNEcmF3ZXIsXG4gIFJlc291cmNlQ3JlYXRlRHJhd2VyLFxufSBmcm9tICcuJ1xuaW1wb3J0IHsgQWN0aXZlQ29tcGFueUNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL2FkbWluL2NvbXBhbmllcy9jb250ZXh0L0FjdGl2ZUNvbXBhbnknXG5pbXBvcnQgeyBMb2FkaW5nRGF0YUNvbnRleHQgfSBmcm9tICcuLi8uLi9jb250ZXh0L0xvYWRpbmdEYXRhQ29udGV4dCdcblxuaW50ZXJmYWNlIFJlc291cmNlTGlzdFByb3BzPFEgZXh0ZW5kcyBFbnRpdHksIEMgZXh0ZW5kcyBFbnRpdHk+IHtcbiAgYWRkVGl0bGU6IHN0cmluZ1xuICBlZGl0VGl0bGU6IHN0cmluZ1xuICBkZXRhaWxzVGl0bGU/OiBzdHJpbmdcbiAgZGVsZXRlVGl0bGU6IHN0cmluZ1xuICBkZWxldGVTdWJ0aXRsZTogc3RyaW5nXG4gIG1hcE1lbnVPcHRpb25zPzogKGl0ZW06IFEsIGRlZmF1bHRPcHRpb25zOiBJQ29udGV4dHVhbE1lbnVJdGVtW10pID0+IElDb250ZXh0dWFsTWVudUl0ZW1bXVxuICBzZXJ2aWNlOiBSZXNvdXJjZVF1ZXJ5U2VydmljZTxRLCBDPlxuICBjb2x1bW5zOiBEYXRhVGFibGVDb2x1bW48UT5bXVxuICBlZGl0Rm9ybTogRWRpdEZvcm08Qz5cbiAgZGV0YWlsc1ZpZXc/OiBEZXRhaWxzVmlldzxRPlxuICBmaW5kQWxsUGFyYW1zPzogdW5rbm93bltdXG4gIG11bHRpcGxlU2VsZWN0aW9uPzogYm9vbGVhblxuICBzZWxlY3Rpb24/OiBRW11cbiAgb25TZWxlY3Rpb24/OiAoaXRlbXM6IFFbXSkgPT4gdm9pZFxuICBvbkRldGFpbEFjdGlvbj86IChpdGVtOiBRKSA9PiB2b2lkXG4gIG9uRWRpdEFjdGlvbj86IChpdGVtOiBRKSA9PiB2b2lkXG4gIG9uQWZ0ZXJTYXZlPzogKGl0ZW06IEMpID0+IHZvaWRcbiAgZGVsZXRlUGVybWlzc2lvbjogYm9vbGVhblxuICBjcmVhdGVQZXJtaXNzaW9uOiBib29sZWFuXG4gIHZpc3VhbGl6ZVBlcm1pc3Npb246IGJvb2xlYW5cbiAgdXBkYXRlUGVybWlzc2lvbjogYm9vbGVhblxufVxuXG5mdW5jdGlvbiBSZXNvdXJjZUxpc3Q8USBleHRlbmRzIEVudGl0eSwgQyBleHRlbmRzIEVudGl0eT4gKFxuICBwcm9wczogUmVzb3VyY2VMaXN0UHJvcHM8USwgQz4sXG4pOiBSZWFjdEVsZW1lbnQge1xuICBjb25zdCB7XG4gICAgYWRkVGl0bGUsXG4gICAgZWRpdFRpdGxlLFxuICAgIGRldGFpbHNUaXRsZSxcbiAgICBkZWxldGVUaXRsZSxcbiAgICBkZWxldGVTdWJ0aXRsZSxcbiAgICBzZXJ2aWNlLFxuICAgIGNvbHVtbnMsXG4gICAgZWRpdEZvcm0sXG4gICAgZGV0YWlsc1ZpZXcsXG4gICAgbWFwTWVudU9wdGlvbnMsXG4gICAgZmluZEFsbFBhcmFtcyA9IFtdLFxuICAgIG11bHRpcGxlU2VsZWN0aW9uID0gdHJ1ZSxcbiAgICBzZWxlY3Rpb24sXG4gICAgb25TZWxlY3Rpb24sXG4gICAgb25EZXRhaWxBY3Rpb24sXG4gICAgb25FZGl0QWN0aW9uLFxuICAgIG9uQWZ0ZXJTYXZlLFxuICAgIGRlbGV0ZVBlcm1pc3Npb24sXG4gICAgY3JlYXRlUGVybWlzc2lvbixcbiAgICB2aXN1YWxpemVQZXJtaXNzaW9uLFxuICAgIHVwZGF0ZVBlcm1pc3Npb24sXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IFtsb2NhbFNlbGVjdGlvbiwgc2V0TG9jYWxTZWxlY3Rpb25dID0gdXNlU3RhdGU8UVtdPihbXSlcbiAgY29uc3QgW2l0ZW1zRm9yUmVtb3ZhbCwgc2V0SXRlbXNGb3JSZW1vdmFsXSA9IHVzZVN0YXRlPFFbXT4oW10pXG5cbiAgY29uc3QgeyBjb21wYW55IH0gPSB1c2VDb250ZXh0KEFjdGl2ZUNvbXBhbnlDb250ZXh0KVxuICBjb25zdCB7IHNldElzTG9hZGluZzogc2V0R2xvYmFsTG9hZGluZyB9ID0gdXNlQ29udGV4dChMb2FkaW5nRGF0YUNvbnRleHQpXG5cbiAgY29uc3QgW1xuICAgIGhpZGVDb25maXJtUmVtb3ZhbCxcbiAgICB7IHNldFRydWU6IGNsb3NlQ29uZmlybVJlbW92YWwsIHNldEZhbHNlOiBvcGVuQ29uZmlybVJlbW92YWwgfSxcbiAgXSA9IHVzZUJvb2xlYW4odHJ1ZSlcbiAgY29uc3QgW1xuICAgIGlzQWRkRHJhd2VyT3BlbixcbiAgICB7IHNldFRydWU6IG9wZW5BZGREcmF3ZXIsIHNldEZhbHNlOiBjbG9zZUFkZERyYXdlciB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcbiAgY29uc3QgW1xuICAgIGlzRWRpdERyYXdlck9wZW4sXG4gICAgeyBzZXRUcnVlOiBvcGVuRWRpdERyYXdlciwgc2V0RmFsc2U6IGNsb3NlRWRpdERyYXdlciB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcbiAgY29uc3QgW1xuICAgIGlzRGV0YWlsc0RyYXdlck9wZW4sXG4gICAgeyBzZXRUcnVlOiBvcGVuRGV0YWlsc0RyYXdlciwgc2V0RmFsc2U6IGNsb3NlRGV0YWlsc0RyYXdlciB9LFxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcblxuICBjb25zdCB7IGlzTG9hZGluZywgZXJyb3IsIGRhdGEgfSA9IHNlcnZpY2UudXNlRmluZEFsbFBhZ2luYXRlZCguLi5maW5kQWxsUGFyYW1zKVxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBkZWxldGVJdGVtIH0gPSBzZXJ2aWNlLnVzZURlbGV0ZSgpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRHbG9iYWxMb2FkaW5nKGlzTG9hZGluZylcbiAgfSwgW2lzTG9hZGluZ10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc2VsZWN0aW9uICYmIHNlbGVjdGlvbiAhPT0gbG9jYWxTZWxlY3Rpb24pIHtcbiAgICAgIHNldExvY2FsU2VsZWN0aW9uKHNlbGVjdGlvbilcbiAgICB9XG4gIH0sIFtzZWxlY3Rpb24sIGxvY2FsU2VsZWN0aW9uXSlcblxuICBjb25zdCBoYW5kbGVTZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoaXRlbXM6IFFbXSkgPT4ge1xuICAgIHNldExvY2FsU2VsZWN0aW9uKGl0ZW1zKVxuICAgIG9uU2VsZWN0aW9uPy4oaXRlbXMpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGFza0ZvclJlbW92YWxDb25maXJtYXRpb24gPSB1c2VDYWxsYmFjaygoaXRlbXM6IFFbXSkgPT4ge1xuICAgIHNldEl0ZW1zRm9yUmVtb3ZhbChpdGVtcylcbiAgICBvcGVuQ29uZmlybVJlbW92YWwoKVxuICB9LCBbXSlcblxuICBjb25zdCByZW1vdmVJdGVtcyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQoXG4gICAgICBpdGVtc0ZvclJlbW92YWwubWFwKGl0ZW0gPT4gaXRlbS5pZFxuICAgICAgICA/IGRlbGV0ZUl0ZW0oaXRlbSlcbiAgICAgICAgOiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICAgICksXG4gICAgKVxuICAgIGNsb3NlQ29uZmlybVJlbW92YWwoKVxuICAgIHNldEl0ZW1zRm9yUmVtb3ZhbChbXSlcbiAgICBoYW5kbGVTZWxlY3Rpb24oW10pXG4gIH0sIFtpdGVtc0ZvclJlbW92YWxdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2VydmljZS5pbnZhbGlkYXRlUXVlcmllcygpXG4gIH0sIFtjb21wYW55XSlcblxuICBjb25zdCBkZWZhdWx0TWVudU9wdGlvbnMgPSB1c2VDYWxsYmFjaygoaXRlbTogUSk6IElDb250ZXh0dWFsTWVudUl0ZW1bXSA9PiB7XG4gICAgY29uc3QgbWVudSA9IFtdXG4gICAgaWYgKHZpc3VhbGl6ZVBlcm1pc3Npb24pIHtcbiAgICAgIG1lbnUucHVzaCh7XG4gICAgICAgIGtleTogJ2RldGFpbCcsXG4gICAgICAgIHRleHQ6ICdEZXRhbGhhcicsXG4gICAgICAgIG9uQ2xpY2s6IG9uRGV0YWlsQWN0aW9uXG4gICAgICAgICAgPyAoKSA9PiBvbkRldGFpbEFjdGlvbihpdGVtKVxuICAgICAgICAgIDogKCkgPT4gb3BlbkRldGFpbHNEcmF3ZXIoKSxcbiAgICAgIH0pXG4gICAgICBpZiAodXBkYXRlUGVybWlzc2lvbikge1xuICAgICAgICBtZW51LnB1c2goe1xuICAgICAgICAgIGtleTogJ2VkaXQnLFxuICAgICAgICAgIHRleHQ6ICdBbHRlcmFyJyxcbiAgICAgICAgICBvbkNsaWNrOiBvbkVkaXRBY3Rpb25cbiAgICAgICAgICAgID8gKCkgPT4gb25FZGl0QWN0aW9uKGl0ZW0pXG4gICAgICAgICAgICA6ICgpID0+IG9wZW5FZGl0RHJhd2VyKCksXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICBpZiAoZGVsZXRlUGVybWlzc2lvbikge1xuICAgICAgICBtZW51LnB1c2goe1xuICAgICAgICAgIGtleTogJ3JlbW92ZScsXG4gICAgICAgICAgdGV4dDogJ0V4Y2x1aXInLFxuICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGFza0ZvclJlbW92YWxDb25maXJtYXRpb24oW2l0ZW1dKSxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG1lbnVcbiAgfSwgW10pXG5cbiAgY29uc3QgbWVudU9wdGlvbnMgPSB1c2VDYWxsYmFjaygoaXRlbTogUSk6IElDb250ZXh0dWFsTWVudUl0ZW1bXSA9PiAoXG4gICAgbWFwTWVudU9wdGlvbnNcbiAgICAgID8gbWFwTWVudU9wdGlvbnMoaXRlbSwgZGVmYXVsdE1lbnVPcHRpb25zKGl0ZW0pKVxuICAgICAgOiBkZWZhdWx0TWVudU9wdGlvbnMoaXRlbSlcbiAgKSwgW10pXG5cbiAgY29uc3QgYWN0aW9ucyA9IHVzZUNhbGxiYWNrKCgpID0+IChcbiAgICA8UmVzb3VyY2VMaXN0QWN0aW9uc1xuICAgICAgZGlzYWJsZWRSZW1vdmVCdXR0b249e2xvY2FsU2VsZWN0aW9uLmxlbmd0aCA9PT0gMH1cbiAgICAgIG9uQWRkQ2xpY2s9eygpID0+IG9wZW5BZGREcmF3ZXIoKX1cbiAgICAgIG9uUmVtb3ZlQ2xpY2s9eygpID0+IGFza0ZvclJlbW92YWxDb25maXJtYXRpb24obG9jYWxTZWxlY3Rpb24pfVxuICAgICAgZGVsZXRlUGVybWlzc2lvbj17ZGVsZXRlUGVybWlzc2lvbn1cbiAgICAgIGNyZWF0ZVBlcm1pc3Npb249e2NyZWF0ZVBlcm1pc3Npb259XG4gICAgLz5cbiAgKSwgW2xvY2FsU2VsZWN0aW9uXSlcblxuICBpZiAoaXNMb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTY3JlZW4gLz5cblxuICBpZiAoZXJyb3IpIHJldHVybiA8RXJyb3JTY3JlZW4gZXJyb3I9e2Vycm9yfSAvPlxuXG4gIHJldHVybiAoXG4gICAgPEVycm9yQm91bmRhcnlcbiAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyBlcnJvciB9KSA9PiAoXG4gICAgICAgIDxFcnJvclNjcmVlbiBlcnJvcj17ZXJyb3J9IC8+XG4gICAgICApfVxuICAgID5cbiAgICAgIDxEYXRhVGFibGVcbiAgICAgICAgaXRlbXM9e2RhdGE/LnZhbHVlIGFzIFFbXX1cbiAgICAgICAgY29sdW1ucz17Y29sdW1uc31cbiAgICAgICAgaGFzU2VhcmNoXG4gICAgICAgIHBhZ2luYXRlZFxuICAgICAgICBoYXNDb250cm9sc0NvbHVtblxuICAgICAgICBtZW51T3B0aW9ucz17bWVudU9wdGlvbnN9XG4gICAgICAgIHJlbmRlckFjdGlvbnM9e2FjdGlvbnN9XG4gICAgICAgIGhhc1NlbGVjdGlvblxuICAgICAgICBtdWx0aXBsZVNlbGVjdGlvbj17bXVsdGlwbGVTZWxlY3Rpb259XG4gICAgICAgIHNlbGVjdGlvbj17c2VsZWN0aW9ufVxuICAgICAgICBvblNlbGVjdGlvbj17aGFuZGxlU2VsZWN0aW9ufVxuICAgICAgLz5cbiAgICAgIHtpc0FkZERyYXdlck9wZW4gJiYgPFJlc291cmNlQ3JlYXRlRHJhd2VyXG4gICAgICAgIHRpdGxlPXthZGRUaXRsZX1cbiAgICAgICAgaXNPcGVuPXtpc0FkZERyYXdlck9wZW59XG4gICAgICAgIGVkaXRGb3JtPXtlZGl0Rm9ybX1cbiAgICAgICAgb25EaXNtaXNzPXtjbG9zZUFkZERyYXdlcn1cbiAgICAgICAgc2VydmljZT17c2VydmljZX1cbiAgICAgICAgb25BZnRlclNhdmU9e29uQWZ0ZXJTYXZlfVxuICAgICAgLz59XG4gICAgICB7aXNFZGl0RHJhd2VyT3BlbiAmJiBsb2NhbFNlbGVjdGlvblswXT8uaWQgJiZcbiAgICAgICAgPFJlc291cmNlRWRpdERyYXdlclxuICAgICAgICAgIHRpdGxlPXtlZGl0VGl0bGV9XG4gICAgICAgICAgaXNPcGVuPXtpc0VkaXREcmF3ZXJPcGVufVxuICAgICAgICAgIGVkaXRGb3JtPXtlZGl0Rm9ybX1cbiAgICAgICAgICBvbkRpc21pc3M9e2Nsb3NlRWRpdERyYXdlcn1cbiAgICAgICAgICBzZXJ2aWNlPXtzZXJ2aWNlfVxuICAgICAgICAgIGlkPXtsb2NhbFNlbGVjdGlvblswXS5pZH1cbiAgICAgICAgLz5cbiAgICAgIH1cbiAgICAgIHtpc0RldGFpbHNEcmF3ZXJPcGVuICYmIGRldGFpbHNWaWV3ICYmIGxvY2FsU2VsZWN0aW9uWzBdPy5pZCAmJlxuICAgICAgICA8UmVzb3VyY2VEZXRhaWxzRHJhd2VyXG4gICAgICAgICAgdGl0bGU9e2RldGFpbHNUaXRsZSA/PyAnJ31cbiAgICAgICAgICBpc09wZW49e2lzRGV0YWlsc0RyYXdlck9wZW59XG4gICAgICAgICAgb25EaXNtaXNzPXtjbG9zZURldGFpbHNEcmF3ZXJ9XG4gICAgICAgICAgc2VydmljZT17c2VydmljZX1cbiAgICAgICAgICBpZD17bG9jYWxTZWxlY3Rpb25bMF0uaWR9XG4gICAgICAgICAgZGV0YWlsc1ZpZXc9e2RldGFpbHNWaWV3fVxuICAgICAgICAvPlxuICAgICAgfVxuICAgICAgPENvbmZpcm1EZWxldGlvblxuICAgICAgICBoaWRkZW49e2hpZGVDb25maXJtUmVtb3ZhbH1cbiAgICAgICAgb25EaXNtaXNzPXtjbG9zZUNvbmZpcm1SZW1vdmFsfVxuICAgICAgICBvbkNvbmZpcm09e3JlbW92ZUl0ZW1zfVxuICAgICAgICBkZWxldGVUaXRsZT17ZGVsZXRlVGl0bGV9XG4gICAgICAgIGRlbGV0ZVN1YnRpdGxlPXtkZWxldGVTdWJ0aXRsZX1cbiAgICAgIC8+XG4gICAgPC9FcnJvckJvdW5kYXJ5PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlc291cmNlTGlzdFxuIl19