// node_modules/tslib/tslib.es6.mjs
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (Object.prototype.hasOwnProperty.call(b2, p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s)
    if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}
function __decorate(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
    r = Reflect.decorate(decorators, target, key, desc);
  else
    for (var i = decorators.length - 1; i >= 0; i--)
      if (d = decorators[i])
        r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2)
    for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar)
          ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
  return to.concat(ar || Array.prototype.slice.call(from));
}

// node_modules/@fluentui/merge-styles/lib/Stylesheet.js
var InjectionMode = {
  /**
   * Avoids style injection, use getRules() to read the styles.
   */
  none: 0,
  /**
   * Inserts rules using the insertRule api.
   */
  insertNode: 1,
  /**
   * Appends rules using appendChild.
   */
  appendChild: 2
};
var STYLESHEET_SETTING = "__stylesheet__";
var REUSE_STYLE_NODE = typeof navigator !== "undefined" && /rv:11.0/.test(navigator.userAgent);
var _global = {};
try {
  _global = window || {};
} catch (_a2) {
}
var _stylesheet;
var Stylesheet = (
  /** @class */
  function() {
    function Stylesheet2(config, serializedStylesheet) {
      var _a2, _b, _c, _d, _e, _f;
      this._rules = [];
      this._preservedRules = [];
      this._counter = 0;
      this._keyToClassName = {};
      this._onInsertRuleCallbacks = [];
      this._onResetCallbacks = [];
      this._classNameToArgs = {};
      this._config = __assign({
        // If there is no document we won't have an element to inject into.
        injectionMode: typeof document === "undefined" ? InjectionMode.none : InjectionMode.insertNode,
        defaultPrefix: "css",
        namespace: void 0,
        cspSettings: void 0
      }, config);
      this._classNameToArgs = (_a2 = serializedStylesheet === null || serializedStylesheet === void 0 ? void 0 : serializedStylesheet.classNameToArgs) !== null && _a2 !== void 0 ? _a2 : this._classNameToArgs;
      this._counter = (_b = serializedStylesheet === null || serializedStylesheet === void 0 ? void 0 : serializedStylesheet.counter) !== null && _b !== void 0 ? _b : this._counter;
      this._keyToClassName = (_d = (_c = this._config.classNameCache) !== null && _c !== void 0 ? _c : serializedStylesheet === null || serializedStylesheet === void 0 ? void 0 : serializedStylesheet.keyToClassName) !== null && _d !== void 0 ? _d : this._keyToClassName;
      this._preservedRules = (_e = serializedStylesheet === null || serializedStylesheet === void 0 ? void 0 : serializedStylesheet.preservedRules) !== null && _e !== void 0 ? _e : this._preservedRules;
      this._rules = (_f = serializedStylesheet === null || serializedStylesheet === void 0 ? void 0 : serializedStylesheet.rules) !== null && _f !== void 0 ? _f : this._rules;
    }
    Stylesheet2.getInstance = function() {
      _stylesheet = _global[STYLESHEET_SETTING];
      if (!_stylesheet || _stylesheet._lastStyleElement && _stylesheet._lastStyleElement.ownerDocument !== document) {
        var fabricConfig = (_global === null || _global === void 0 ? void 0 : _global.FabricConfig) || {};
        var stylesheet = new Stylesheet2(fabricConfig.mergeStyles, fabricConfig.serializedStylesheet);
        _stylesheet = stylesheet;
        _global[STYLESHEET_SETTING] = stylesheet;
      }
      return _stylesheet;
    };
    Stylesheet2.prototype.serialize = function() {
      return JSON.stringify({
        classNameToArgs: this._classNameToArgs,
        counter: this._counter,
        keyToClassName: this._keyToClassName,
        preservedRules: this._preservedRules,
        rules: this._rules
      });
    };
    Stylesheet2.prototype.setConfig = function(config) {
      this._config = __assign(__assign({}, this._config), config);
    };
    Stylesheet2.prototype.onReset = function(callback) {
      var _this = this;
      this._onResetCallbacks.push(callback);
      return function() {
        _this._onResetCallbacks = _this._onResetCallbacks.filter(function(cb) {
          return cb !== callback;
        });
      };
    };
    Stylesheet2.prototype.onInsertRule = function(callback) {
      var _this = this;
      this._onInsertRuleCallbacks.push(callback);
      return function() {
        _this._onInsertRuleCallbacks = _this._onInsertRuleCallbacks.filter(function(cb) {
          return cb !== callback;
        });
      };
    };
    Stylesheet2.prototype.getClassName = function(displayName) {
      var namespace = this._config.namespace;
      var prefix = displayName || this._config.defaultPrefix;
      return "".concat(namespace ? namespace + "-" : "").concat(prefix, "-").concat(this._counter++);
    };
    Stylesheet2.prototype.cacheClassName = function(className, key, args, rules2) {
      this._keyToClassName[key] = className;
      this._classNameToArgs[className] = {
        args,
        rules: rules2
      };
    };
    Stylesheet2.prototype.classNameFromKey = function(key) {
      return this._keyToClassName[key];
    };
    Stylesheet2.prototype.getClassNameCache = function() {
      return this._keyToClassName;
    };
    Stylesheet2.prototype.argsFromClassName = function(className) {
      var entry = this._classNameToArgs[className];
      return entry && entry.args;
    };
    Stylesheet2.prototype.insertedRulesFromClassName = function(className) {
      var entry = this._classNameToArgs[className];
      return entry && entry.rules;
    };
    Stylesheet2.prototype.insertRule = function(rule, preserve) {
      var injectionMode = this._config.injectionMode;
      var element = injectionMode !== InjectionMode.none ? this._getStyleElement() : void 0;
      if (preserve) {
        this._preservedRules.push(rule);
      }
      if (element) {
        switch (injectionMode) {
          case InjectionMode.insertNode:
            var sheet = element.sheet;
            try {
              sheet.insertRule(rule, sheet.cssRules.length);
            } catch (e) {
            }
            break;
          case InjectionMode.appendChild:
            element.appendChild(document.createTextNode(rule));
            break;
        }
      } else {
        this._rules.push(rule);
      }
      if (this._config.onInsertRule) {
        this._config.onInsertRule(rule);
      }
      this._onInsertRuleCallbacks.forEach(function(callback) {
        return callback();
      });
    };
    Stylesheet2.prototype.getRules = function(includePreservedRules) {
      return (includePreservedRules ? this._preservedRules.join("") : "") + this._rules.join("");
    };
    Stylesheet2.prototype.reset = function() {
      this._rules = [];
      this._counter = 0;
      this._classNameToArgs = {};
      this._keyToClassName = {};
      this._onResetCallbacks.forEach(function(callback) {
        return callback();
      });
    };
    Stylesheet2.prototype.resetKeys = function() {
      this._keyToClassName = {};
    };
    Stylesheet2.prototype._getStyleElement = function() {
      var _this = this;
      if (!this._styleElement && typeof document !== "undefined") {
        this._styleElement = this._createStyleElement();
        if (!REUSE_STYLE_NODE) {
          window.requestAnimationFrame(function() {
            _this._styleElement = void 0;
          });
        }
      }
      return this._styleElement;
    };
    Stylesheet2.prototype._createStyleElement = function() {
      var head = document.head;
      var styleElement = document.createElement("style");
      var nodeToInsertBefore = null;
      styleElement.setAttribute("data-merge-styles", "true");
      var cspSettings = this._config.cspSettings;
      if (cspSettings) {
        if (cspSettings.nonce) {
          styleElement.setAttribute("nonce", cspSettings.nonce);
        }
      }
      if (this._lastStyleElement) {
        nodeToInsertBefore = this._lastStyleElement.nextElementSibling;
      } else {
        var placeholderStyleTag = this._findPlaceholderStyleTag();
        if (placeholderStyleTag) {
          nodeToInsertBefore = placeholderStyleTag.nextElementSibling;
        } else {
          nodeToInsertBefore = head.childNodes[0];
        }
      }
      head.insertBefore(styleElement, head.contains(nodeToInsertBefore) ? nodeToInsertBefore : null);
      this._lastStyleElement = styleElement;
      return styleElement;
    };
    Stylesheet2.prototype._findPlaceholderStyleTag = function() {
      var head = document.head;
      if (head) {
        return head.querySelector("style[data-merge-styles]");
      }
      return null;
    };
    return Stylesheet2;
  }()
);

// node_modules/@fluentui/merge-styles/lib/extractStyleParts.js
function extractStyleParts() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  var classes = [];
  var objects = [];
  var stylesheet = Stylesheet.getInstance();
  function _processArgs(argsList) {
    for (var _i2 = 0, argsList_1 = argsList; _i2 < argsList_1.length; _i2++) {
      var arg = argsList_1[_i2];
      if (arg) {
        if (typeof arg === "string") {
          if (arg.indexOf(" ") >= 0) {
            _processArgs(arg.split(" "));
          } else {
            var translatedArgs = stylesheet.argsFromClassName(arg);
            if (translatedArgs) {
              _processArgs(translatedArgs);
            } else {
              if (classes.indexOf(arg) === -1) {
                classes.push(arg);
              }
            }
          }
        } else if (Array.isArray(arg)) {
          _processArgs(arg);
        } else if (typeof arg === "object") {
          objects.push(arg);
        }
      }
    }
  }
  _processArgs(args);
  return {
    classes,
    objects
  };
}

// node_modules/@fluentui/merge-styles/lib/StyleOptionsState.js
function setRTL(isRTL) {
  if (_rtl !== isRTL) {
    _rtl = isRTL;
  }
}
function getRTL() {
  if (_rtl === void 0) {
    _rtl = typeof document !== "undefined" && !!document.documentElement && document.documentElement.getAttribute("dir") === "rtl";
  }
  return _rtl;
}
var _rtl;
_rtl = getRTL();
function getStyleOptions() {
  return {
    rtl: getRTL()
  };
}

// node_modules/@fluentui/merge-styles/lib/transforms/kebabRules.js
var rules = {};
function kebabRules(rulePairs, index) {
  var rule = rulePairs[index];
  if (rule.charAt(0) !== "-") {
    rulePairs[index] = rules[rule] = rules[rule] || rule.replace(/([A-Z])/g, "-$1").toLowerCase();
  }
}

// node_modules/@fluentui/merge-styles/lib/getVendorSettings.js
var _vendorSettings;
function getVendorSettings() {
  var _a2;
  if (!_vendorSettings) {
    var doc = typeof document !== "undefined" ? document : void 0;
    var nav = typeof navigator !== "undefined" ? navigator : void 0;
    var userAgent = (_a2 = nav === null || nav === void 0 ? void 0 : nav.userAgent) === null || _a2 === void 0 ? void 0 : _a2.toLowerCase();
    if (!doc) {
      _vendorSettings = {
        isWebkit: true,
        isMoz: true,
        isOpera: true,
        isMs: true
      };
    } else {
      _vendorSettings = {
        isWebkit: !!(doc && "WebkitAppearance" in doc.documentElement.style),
        isMoz: !!(userAgent && userAgent.indexOf("firefox") > -1),
        isOpera: !!(userAgent && userAgent.indexOf("opera") > -1),
        isMs: !!(nav && (/rv:11.0/i.test(nav.userAgent) || /Edge\/\d./i.test(navigator.userAgent)))
      };
    }
  }
  return _vendorSettings;
}

// node_modules/@fluentui/merge-styles/lib/transforms/prefixRules.js
var autoPrefixNames = {
  "user-select": 1
};
function prefixRules(rulePairs, index) {
  var vendorSettings = getVendorSettings();
  var name = rulePairs[index];
  if (autoPrefixNames[name]) {
    var value = rulePairs[index + 1];
    if (autoPrefixNames[name]) {
      if (vendorSettings.isWebkit) {
        rulePairs.push("-webkit-" + name, value);
      }
      if (vendorSettings.isMoz) {
        rulePairs.push("-moz-" + name, value);
      }
      if (vendorSettings.isMs) {
        rulePairs.push("-ms-" + name, value);
      }
      if (vendorSettings.isOpera) {
        rulePairs.push("-o-" + name, value);
      }
    }
  }
}

// node_modules/@fluentui/merge-styles/lib/transforms/provideUnits.js
var NON_PIXEL_NUMBER_PROPS = [
  "column-count",
  "font-weight",
  "flex",
  "flex-grow",
  "flex-shrink",
  "fill-opacity",
  "opacity",
  "order",
  "z-index",
  "zoom"
];
function provideUnits(rulePairs, index) {
  var name = rulePairs[index];
  var value = rulePairs[index + 1];
  if (typeof value === "number") {
    var isNonPixelProp = NON_PIXEL_NUMBER_PROPS.indexOf(name) > -1;
    var isVariableOrPrefixed = name.indexOf("--") > -1;
    var unit = isNonPixelProp || isVariableOrPrefixed ? "" : "px";
    rulePairs[index + 1] = "".concat(value).concat(unit);
  }
}

// node_modules/@fluentui/merge-styles/lib/transforms/rtlifyRules.js
var _a;
var LEFT = "left";
var RIGHT = "right";
var NO_FLIP = "@noflip";
var NAME_REPLACEMENTS = (_a = {}, _a[LEFT] = RIGHT, _a[RIGHT] = LEFT, _a);
var VALUE_REPLACEMENTS = {
  "w-resize": "e-resize",
  "sw-resize": "se-resize",
  "nw-resize": "ne-resize"
};
function rtlifyRules(options, rulePairs, index) {
  if (options.rtl) {
    var name_1 = rulePairs[index];
    if (!name_1) {
      return;
    }
    var value = rulePairs[index + 1];
    if (typeof value === "string" && value.indexOf(NO_FLIP) >= 0) {
      rulePairs[index + 1] = value.replace(/\s*(?:\/\*\s*)?\@noflip\b(?:\s*\*\/)?\s*?/g, "");
    } else if (name_1.indexOf(LEFT) >= 0) {
      rulePairs[index] = name_1.replace(LEFT, RIGHT);
    } else if (name_1.indexOf(RIGHT) >= 0) {
      rulePairs[index] = name_1.replace(RIGHT, LEFT);
    } else if (String(value).indexOf(LEFT) >= 0) {
      rulePairs[index + 1] = value.replace(LEFT, RIGHT);
    } else if (String(value).indexOf(RIGHT) >= 0) {
      rulePairs[index + 1] = value.replace(RIGHT, LEFT);
    } else if (NAME_REPLACEMENTS[name_1]) {
      rulePairs[index] = NAME_REPLACEMENTS[name_1];
    } else if (VALUE_REPLACEMENTS[value]) {
      rulePairs[index + 1] = VALUE_REPLACEMENTS[value];
    } else {
      switch (name_1) {
        case "margin":
        case "padding":
          rulePairs[index + 1] = flipQuad(value);
          break;
        case "box-shadow":
          rulePairs[index + 1] = negateNum(value, 0);
          break;
      }
    }
  }
}
function negateNum(value, partIndex) {
  var parts = value.split(" ");
  var numberVal = parseInt(parts[partIndex], 10);
  parts[0] = parts[0].replace(String(numberVal), String(numberVal * -1));
  return parts.join(" ");
}
function flipQuad(value) {
  if (typeof value === "string") {
    var parts = value.split(" ");
    if (parts.length === 4) {
      return "".concat(parts[0], " ").concat(parts[3], " ").concat(parts[2], " ").concat(parts[1]);
    }
  }
  return value;
}

// node_modules/@fluentui/merge-styles/lib/tokenizeWithParentheses.js
function tokenizeWithParentheses(value) {
  var parts = [];
  var partStart = 0;
  var parens = 0;
  for (var i = 0; i < value.length; i++) {
    switch (value[i]) {
      case "(":
        parens++;
        break;
      case ")":
        if (parens) {
          parens--;
        }
        break;
      case "	":
      case " ":
        if (!parens) {
          if (i > partStart) {
            parts.push(value.substring(partStart, i));
          }
          partStart = i + 1;
        }
        break;
    }
  }
  if (partStart < value.length) {
    parts.push(value.substring(partStart));
  }
  return parts;
}

// node_modules/@fluentui/merge-styles/lib/styleToClassName.js
var DISPLAY_NAME = "displayName";
function getDisplayName(rules2) {
  var rootStyle = rules2 && rules2["&"];
  return rootStyle ? rootStyle.displayName : void 0;
}
var globalSelectorRegExp = /\:global\((.+?)\)/g;
function expandCommaSeparatedGlobals(selectorWithGlobals) {
  if (!globalSelectorRegExp.test(selectorWithGlobals)) {
    return selectorWithGlobals;
  }
  var replacementInfo = [];
  var findGlobal = /\:global\((.+?)\)/g;
  var match = null;
  while (match = findGlobal.exec(selectorWithGlobals)) {
    if (match[1].indexOf(",") > -1) {
      replacementInfo.push([
        match.index,
        match.index + match[0].length,
        // Wrap each of the found selectors in :global()
        match[1].split(",").map(function(v) {
          return ":global(".concat(v.trim(), ")");
        }).join(", ")
      ]);
    }
  }
  return replacementInfo.reverse().reduce(function(selector, _a2) {
    var matchIndex = _a2[0], matchEndIndex = _a2[1], replacement = _a2[2];
    var prefix = selector.slice(0, matchIndex);
    var suffix = selector.slice(matchEndIndex);
    return prefix + replacement + suffix;
  }, selectorWithGlobals);
}
function expandSelector(newSelector, currentSelector) {
  if (newSelector.indexOf(":global(") >= 0) {
    return newSelector.replace(globalSelectorRegExp, "$1");
  } else if (newSelector.indexOf(":") === 0) {
    return currentSelector + newSelector;
  } else if (newSelector.indexOf("&") < 0) {
    return currentSelector + " " + newSelector;
  }
  return newSelector;
}
function extractSelector(currentSelector, rules2, selector, value) {
  if (rules2 === void 0) {
    rules2 = { __order: [] };
  }
  if (selector.indexOf("@") === 0) {
    selector = selector + "{" + currentSelector;
    extractRules([value], rules2, selector);
  } else if (selector.indexOf(",") > -1) {
    expandCommaSeparatedGlobals(selector).split(",").map(function(s) {
      return s.trim();
    }).forEach(function(separatedSelector) {
      return extractRules([value], rules2, expandSelector(separatedSelector, currentSelector));
    });
  } else {
    extractRules([value], rules2, expandSelector(selector, currentSelector));
  }
}
function extractRules(args, rules2, currentSelector) {
  if (rules2 === void 0) {
    rules2 = { __order: [] };
  }
  if (currentSelector === void 0) {
    currentSelector = "&";
  }
  var stylesheet = Stylesheet.getInstance();
  var currentRules = rules2[currentSelector];
  if (!currentRules) {
    currentRules = {};
    rules2[currentSelector] = currentRules;
    rules2.__order.push(currentSelector);
  }
  for (var _i = 0, args_1 = args; _i < args_1.length; _i++) {
    var arg = args_1[_i];
    if (typeof arg === "string") {
      var expandedRules = stylesheet.argsFromClassName(arg);
      if (expandedRules) {
        extractRules(expandedRules, rules2, currentSelector);
      }
    } else if (Array.isArray(arg)) {
      extractRules(arg, rules2, currentSelector);
    } else {
      for (var prop in arg) {
        if (arg.hasOwnProperty(prop)) {
          var propValue = arg[prop];
          if (prop === "selectors") {
            var selectors = arg.selectors;
            for (var newSelector in selectors) {
              if (selectors.hasOwnProperty(newSelector)) {
                extractSelector(currentSelector, rules2, newSelector, selectors[newSelector]);
              }
            }
          } else if (typeof propValue === "object") {
            if (propValue !== null) {
              extractSelector(currentSelector, rules2, prop, propValue);
            }
          } else {
            if (propValue !== void 0) {
              if (prop === "margin" || prop === "padding") {
                expandQuads(currentRules, prop, propValue);
              } else {
                currentRules[prop] = propValue;
              }
            }
          }
        }
      }
    }
  }
  return rules2;
}
function expandQuads(currentRules, name, value) {
  var parts = typeof value === "string" ? tokenizeWithParentheses(value) : [value];
  if (parts.length === 0) {
    parts.push(value);
  }
  if (parts[parts.length - 1] === "!important") {
    parts = parts.slice(0, -1).map(function(p) {
      return p + " !important";
    });
  }
  currentRules[name + "Top"] = parts[0];
  currentRules[name + "Right"] = parts[1] || parts[0];
  currentRules[name + "Bottom"] = parts[2] || parts[0];
  currentRules[name + "Left"] = parts[3] || parts[1] || parts[0];
}
function getKeyForRules(options, rules2) {
  var serialized = [options.rtl ? "rtl" : "ltr"];
  var hasProps = false;
  for (var _i = 0, _a2 = rules2.__order; _i < _a2.length; _i++) {
    var selector = _a2[_i];
    serialized.push(selector);
    var rulesForSelector = rules2[selector];
    for (var propName in rulesForSelector) {
      if (rulesForSelector.hasOwnProperty(propName) && rulesForSelector[propName] !== void 0) {
        hasProps = true;
        serialized.push(propName, rulesForSelector[propName]);
      }
    }
  }
  return hasProps ? serialized.join("") : void 0;
}
function repeatString(target, count) {
  if (count <= 0) {
    return "";
  }
  if (count === 1) {
    return target;
  }
  return target + repeatString(target, count - 1);
}
function serializeRuleEntries(options, ruleEntries) {
  if (!ruleEntries) {
    return "";
  }
  var allEntries = [];
  for (var entry in ruleEntries) {
    if (ruleEntries.hasOwnProperty(entry) && entry !== DISPLAY_NAME && ruleEntries[entry] !== void 0) {
      allEntries.push(entry, ruleEntries[entry]);
    }
  }
  for (var i = 0; i < allEntries.length; i += 2) {
    kebabRules(allEntries, i);
    provideUnits(allEntries, i);
    rtlifyRules(options, allEntries, i);
    prefixRules(allEntries, i);
  }
  for (var i = 1; i < allEntries.length; i += 4) {
    allEntries.splice(i, 1, ":", allEntries[i], ";");
  }
  return allEntries.join("");
}
function styleToRegistration(options) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  var rules2 = extractRules(args);
  var key = getKeyForRules(options, rules2);
  if (key) {
    var stylesheet = Stylesheet.getInstance();
    var registration = {
      className: stylesheet.classNameFromKey(key),
      key,
      args
    };
    if (!registration.className) {
      registration.className = stylesheet.getClassName(getDisplayName(rules2));
      var rulesToInsert = [];
      for (var _a2 = 0, _b = rules2.__order; _a2 < _b.length; _a2++) {
        var selector = _b[_a2];
        rulesToInsert.push(selector, serializeRuleEntries(options, rules2[selector]));
      }
      registration.rulesToInsert = rulesToInsert;
    }
    return registration;
  }
  return void 0;
}
function applyRegistration(registration, specificityMultiplier) {
  if (specificityMultiplier === void 0) {
    specificityMultiplier = 1;
  }
  var stylesheet = Stylesheet.getInstance();
  var className = registration.className, key = registration.key, args = registration.args, rulesToInsert = registration.rulesToInsert;
  if (rulesToInsert) {
    for (var i = 0; i < rulesToInsert.length; i += 2) {
      var rules2 = rulesToInsert[i + 1];
      if (rules2) {
        var selector = rulesToInsert[i];
        selector = selector.replace(/&/g, repeatString(".".concat(registration.className), specificityMultiplier));
        var processedRule = "".concat(selector, "{").concat(rules2, "}").concat(selector.indexOf("@") === 0 ? "}" : "");
        stylesheet.insertRule(processedRule);
      }
    }
    stylesheet.cacheClassName(className, key, args, rulesToInsert);
  }
}
function styleToClassName(options) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  var registration = styleToRegistration.apply(void 0, __spreadArray([options], args, false));
  if (registration) {
    applyRegistration(registration, options.specificityMultiplier);
    return registration.className;
  }
  return "";
}

// node_modules/@fluentui/merge-styles/lib/mergeStyles.js
function mergeStyles() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  return mergeCss(args, getStyleOptions());
}
function mergeCss(args, options) {
  var styleArgs = args instanceof Array ? args : [args];
  var _a2 = extractStyleParts(styleArgs), classes = _a2.classes, objects = _a2.objects;
  if (objects.length) {
    classes.push(styleToClassName(options || {}, objects));
  }
  return classes.join(" ");
}

// node_modules/@fluentui/merge-styles/lib/concatStyleSets.js
function concatStyleSets() {
  var styleSets = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    styleSets[_i] = arguments[_i];
  }
  if (styleSets && styleSets.length === 1 && styleSets[0] && !styleSets[0].subComponentStyles) {
    return styleSets[0];
  }
  var mergedSet = {};
  var workingSubcomponentStyles = {};
  for (var _a2 = 0, styleSets_1 = styleSets; _a2 < styleSets_1.length; _a2++) {
    var currentSet = styleSets_1[_a2];
    if (currentSet) {
      for (var prop in currentSet) {
        if (currentSet.hasOwnProperty(prop)) {
          if (prop === "subComponentStyles" && currentSet.subComponentStyles !== void 0) {
            var currentComponentStyles = currentSet.subComponentStyles;
            for (var subCompProp in currentComponentStyles) {
              if (currentComponentStyles.hasOwnProperty(subCompProp)) {
                if (workingSubcomponentStyles.hasOwnProperty(subCompProp)) {
                  workingSubcomponentStyles[subCompProp].push(currentComponentStyles[subCompProp]);
                } else {
                  workingSubcomponentStyles[subCompProp] = [currentComponentStyles[subCompProp]];
                }
              }
            }
            continue;
          }
          var mergedValue = mergedSet[prop];
          var currentValue = currentSet[prop];
          if (mergedValue === void 0) {
            mergedSet[prop] = currentValue;
          } else {
            mergedSet[prop] = __spreadArray(__spreadArray([], Array.isArray(mergedValue) ? mergedValue : [mergedValue], true), Array.isArray(currentValue) ? currentValue : [currentValue], true);
          }
        }
      }
    }
  }
  if (Object.keys(workingSubcomponentStyles).length > 0) {
    mergedSet.subComponentStyles = {};
    var mergedSubStyles = mergedSet.subComponentStyles;
    var _loop_1 = function(subCompProp2) {
      if (workingSubcomponentStyles.hasOwnProperty(subCompProp2)) {
        var workingSet_1 = workingSubcomponentStyles[subCompProp2];
        mergedSubStyles[subCompProp2] = function(styleProps) {
          return concatStyleSets.apply(void 0, workingSet_1.map(function(styleFunctionOrObject) {
            return typeof styleFunctionOrObject === "function" ? styleFunctionOrObject(styleProps) : styleFunctionOrObject;
          }));
        };
      }
    };
    for (var subCompProp in workingSubcomponentStyles) {
      _loop_1(subCompProp);
    }
  }
  return mergedSet;
}

// node_modules/@fluentui/merge-styles/lib/mergeStyleSets.js
function mergeStyleSets() {
  var styleSets = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    styleSets[_i] = arguments[_i];
  }
  return mergeCssSets(styleSets, getStyleOptions());
}
function mergeCssSets(styleSets, options) {
  var classNameSet = { subComponentStyles: {} };
  var styleSet = styleSets[0];
  if (!styleSet && styleSets.length <= 1) {
    return { subComponentStyles: {} };
  }
  var concatenatedStyleSet = concatStyleSets.apply(void 0, styleSets);
  var registrations = [];
  for (var styleSetArea in concatenatedStyleSet) {
    if (concatenatedStyleSet.hasOwnProperty(styleSetArea)) {
      if (styleSetArea === "subComponentStyles") {
        classNameSet.subComponentStyles = concatenatedStyleSet.subComponentStyles || {};
        continue;
      }
      var styles = concatenatedStyleSet[styleSetArea];
      var _a2 = extractStyleParts(styles), classes = _a2.classes, objects = _a2.objects;
      if (objects === null || objects === void 0 ? void 0 : objects.length) {
        var registration = styleToRegistration(options || {}, { displayName: styleSetArea }, objects);
        if (registration) {
          registrations.push(registration);
          classNameSet[styleSetArea] = classes.concat([registration.className]).join(" ");
        }
      } else {
        classNameSet[styleSetArea] = classes.join(" ");
      }
    }
  }
  for (var _i = 0, registrations_1 = registrations; _i < registrations_1.length; _i++) {
    var registration = registrations_1[_i];
    if (registration) {
      applyRegistration(registration, options === null || options === void 0 ? void 0 : options.specificityMultiplier);
    }
  }
  return classNameSet;
}

// node_modules/@fluentui/merge-styles/lib/concatStyleSetsWithProps.js
function concatStyleSetsWithProps(styleProps) {
  var allStyles = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    allStyles[_i - 1] = arguments[_i];
  }
  var result = [];
  for (var _a2 = 0, allStyles_1 = allStyles; _a2 < allStyles_1.length; _a2++) {
    var styles = allStyles_1[_a2];
    if (styles) {
      result.push(typeof styles === "function" ? styles(styleProps) : styles);
    }
  }
  if (result.length === 1) {
    return result[0];
  } else if (result.length) {
    return concatStyleSets.apply(void 0, result);
  }
  return {};
}

// node_modules/@fluentui/merge-styles/lib/fontFace.js
function fontFace(font) {
  var stylesheet = Stylesheet.getInstance();
  var rule = serializeRuleEntries(getStyleOptions(), font);
  var className = stylesheet.classNameFromKey(rule);
  if (className) {
    return;
  }
  var name = stylesheet.getClassName();
  stylesheet.insertRule("@font-face{".concat(rule, "}"), true);
  stylesheet.cacheClassName(name, rule, [], ["font-face", rule]);
}

// node_modules/@fluentui/merge-styles/lib/keyframes.js
function keyframes(timeline) {
  var stylesheet = Stylesheet.getInstance();
  var rulesArray = [];
  for (var prop in timeline) {
    if (timeline.hasOwnProperty(prop)) {
      rulesArray.push(prop, "{", serializeRuleEntries(getStyleOptions(), timeline[prop]), "}");
    }
  }
  var rules2 = rulesArray.join("");
  var className = stylesheet.classNameFromKey(rules2);
  if (className) {
    return className;
  }
  var name = stylesheet.getClassName();
  stylesheet.insertRule("@keyframes ".concat(name, "{").concat(rules2, "}"), true);
  stylesheet.cacheClassName(name, rules2, [], ["keyframes", rules2]);
  return name;
}

// node_modules/@fluentui/set-version/lib/setVersion.js
var packagesCache = {};
var _win = void 0;
try {
  _win = window;
} catch (e) {
}
function setVersion(packageName, packageVersion) {
  if (typeof _win !== "undefined") {
    var packages = _win.__packages__ = _win.__packages__ || {};
    if (!packages[packageName] || !packagesCache[packageName]) {
      packagesCache[packageName] = packageVersion;
      var versions = packages[packageName] = packages[packageName] || [];
      versions.push(packageVersion);
    }
  }
}

// node_modules/@fluentui/set-version/lib/index.js
setVersion("@fluentui/set-version", "6.0.0");

// node_modules/@fluentui/merge-styles/lib/version.js
setVersion("@fluentui/merge-styles", "8.5.12");

export {
  __extends,
  __assign,
  __rest,
  __decorate,
  __spreadArray,
  InjectionMode,
  Stylesheet,
  setRTL,
  mergeStyles,
  mergeCss,
  concatStyleSets,
  mergeStyleSets,
  mergeCssSets,
  concatStyleSetsWithProps,
  fontFace,
  keyframes,
  setVersion
};
//# sourceMappingURL=chunk-VMZS5K6Z.js.map
