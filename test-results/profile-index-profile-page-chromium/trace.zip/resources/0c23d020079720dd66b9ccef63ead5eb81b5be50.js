import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractEditForm.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { mergeStyleSets, Label } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { isEqual } from "/node_modules/.vite/deps/lodash-es.js?v=9f90a7ff";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { Checkbox, ComboBox, CurrencyInput, DatePicker, MaskedTextField, MonthDropdown, NumberInput, PhoneInput, Tag, TextField, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { UserAssociatesDropdown, UsersDropdown } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { CompaniesDropdown } from "/src/modules/admin/companies/components/index.ts?t=1701096626433";
import { formatCurrency } from "/src/shared/utils/index.ts";
import { contractService as service } from "/src/modules/admin/contracts/services/index.ts";
import { TaxesEnum } from "/src/shared/enums/TaxesEnum.ts";
import TaxesRercord from "/src/shared/record/TaxesRecord.ts";
import { ContractConfigurationContext } from "/src/modules/admin/contracts/context/ContractConfigurationPageContext.ts";
import { ContractTypeDropdown } from "/src/modules/admin/contracts/components/index.ts?t=1701096626433";
const ContractEditForm = (props) => {
  _s();
  const {
    apiError,
    formData,
    onChange,
    horizontal = false,
    isSubcontract,
    isEditing = false
  } = props;
  const {
    contract
  } = useContext(ContractConfigurationContext);
  const {
    colors
  } = useTheme();
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange,
    onNumberChange,
    onNumberTextChange,
    onMultiDropdownChange,
    onDropdownChange,
    onCheckboxChange,
    onFieldError,
    onDigitsTextChange,
    onDateChange
  } = useFormData(formData);
  const styles = getStyles(horizontal, apiError);
  const getNextProposal = useCallback(async () => {
    if (localFormData.numeroProposta === void 0) {
      const proposal = await service.getNextProposal();
      setLocalFormData({
        ...formData,
        numeroProposta: proposal.numeroProposta
      });
    }
  }, [localFormData]);
  const handlePercentChange = useCallback((_, value) => {
    if (value) {
      const finalVal = value <= 0 ? 0 : value >= 100 ? 100 : value;
      setLocalFormData((prevState) => {
        return {
          ...prevState,
          percentualExito: finalVal
        };
      });
    }
  }, []);
  const handleChangeTaxes = useCallback((_, value) => {
    const oldSelected = formData?.impostos || [];
    let newSelected = [];
    if (value?.key === TaxesEnum.NaoSeAplica) {
      newSelected = value.selected ? [value.key] : oldSelected.filter((item) => item !== value.key);
      setLocalFormData((data) => ({
        ...data,
        impostos: newSelected
      }));
    } else {
      if (value !== void 0) {
        newSelected = value.selected ? [...oldSelected, value.key] : oldSelected.filter((item) => item !== value.key);
      }
      newSelected = newSelected.filter((item) => item !== TaxesEnum.NaoSeAplica);
    }
    setLocalFormData((prevState) => {
      return {
        ...prevState,
        impostos: newSelected
      };
    });
  }, [formData?.impostos]);
  const formatProposalMask = useMemo(() => {
    if (localFormData.numeroPropostaComercial === null) {
      localFormData.numeroPropostaComercial = "";
    }
    return localFormData.numeroPropostaComercial.trim().length < 7 ? "****-***" : "****-****-**";
  }, [localFormData]);
  useEffect(() => {
    getNextProposal();
  }, [getNextProposal]);
  useEffect(() => {
    if (formData && !isEqual(formData, localFormData)) {
      setLocalFormData(formData);
    }
  }, [formData]);
  useEffect(() => {
    onChange?.(localFormData);
  }, [localFormData]);
  useEffect(() => {
    if (localFormData) {
      if (isSubcontract && !localFormData.numeroPropostaComercial && contract) {
        onChange?.({
          ...localFormData,
          numeroPropostaComercial: contract.numeroPropostaComercial
        });
      }
    }
  }, [contract, isSubcontract]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.grid, children: [
    /* @__PURE__ */ jsxDEV("div", { className: styles.numeroProposta, children: /* @__PURE__ */ jsxDEV(MaskedTextField, { label: "Nº do contrato", required: true, placeholder: "Inserir número", value: localFormData.numeroProposta ?? "", onChange: onNumberTextChange("numeroProposta"), mask: "9999-99", maskChar: " ", disabled: true, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("numeroPropostaSub", apiError?.errors?.messages) : onFieldError("numeroProposta", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 125,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.numeroPropostaComercial, children: /* @__PURE__ */ jsxDEV(MaskedTextField, { label: "Nº da proposta", placeholder: "Inserir número", value: localFormData.numeroPropostaComercial ?? "", onChange: onDigitsTextChange("numeroPropostaComercial"), mask: formatProposalMask, maskChar: " ", errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("numeroPropostaComercialSub", apiError?.errors?.messages) : onFieldError("numeroPropostaComercial", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 128,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    isSubcontract && !isEditing && /* @__PURE__ */ jsxDEV("div", { className: styles.geraAuditoria, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Gerar projeto", onChange: onCheckboxChange("geraAuditoria"), checked: localFormData.geraAuditoria }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 130,
      columnNumber: 39
    }, this),
    isSubcontract && isEditing && /* @__PURE__ */ jsxDEV("div", { className: styles.geraAuditoria, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Gerar projeto", checked: localFormData.geraAuditoria, disabled: true }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 134,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 133,
      columnNumber: 38
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelTecnico, children: /* @__PURE__ */ jsxDEV(UserAssociatesDropdown, { label: "Sócio responsável técnico", required: true, filterId: localFormData.responsavelClienteId, placeholder: "Selecionar sócio", selectedKey: localFormData.responsavelTecnicoId, onChange: onDropdownChange("responsavelTecnicoId"), errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("responsavelTecnicoIdSub", apiError?.errors?.messages) : onFieldError("responsavelTecnicoId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 137,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 136,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelCliente, children: /* @__PURE__ */ jsxDEV(UsersDropdown, { label: "Responsável cliente", required: true, filterId: localFormData.responsavelTecnicoId, placeholder: "Selecionar responsável cliente", selectedKey: localFormData.responsavelClienteId, onChange: onDropdownChange("responsavelClienteId"), errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("responsavelClienteIdSub", apiError?.errors?.messages) : onFieldError("responsavelClienteId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 139,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.exercicio, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Exercício", required: true, placeholder: "Exercício", value: localFormData.exercicio?.toString() ?? "", onChange: onNumberChange("exercicio"), maxLength: 4, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("exercicioSub", apiError?.errors?.messages) : onFieldError("exercicio", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 143,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.mesRenovacao, children: /* @__PURE__ */ jsxDEV(MonthDropdown, { label: "Mês renovação", placeholder: "Mês", selectedKey: localFormData.mesRenovacao, onChange: onDropdownChange("mesRenovacao"), errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("mesRenovacaoSub", apiError?.errors?.messages) : onFieldError("mesRenovacao", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 146,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.qtdHoras, children: /* @__PURE__ */ jsxDEV(TextField, { label: "Qtd. horas", placeholder: "Inserir horas", value: localFormData.qtdHoras?.toString() ?? "", onChange: onNumberChange("qtdHoras"), maxLength: 9, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("qtdHorasSub", apiError?.errors?.messages) : onFieldError("qtdHoras", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 149,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.valor, children: /* @__PURE__ */ jsxDEV(CurrencyInput, { label: "Valor", value: localFormData.valor, onChange: onNumberChange("valor"), maxLength: 12, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("valorSub", apiError?.errors?.messages) : onFieldError("valor", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 152,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.valorHora, children: [
      /* @__PURE__ */ jsxDEV(Label, { children: "Valor hora" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
        lineNumber: 155,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(TooltipHost, { content: "Valor Hora", id: "valor-hora-contrato-tooltip", children: /* @__PURE__ */ jsxDEV(Tag, { text: formatCurrency(localFormData.qtdHoras && localFormData.qtdHoras >= 0 && localFormData.valor ? localFormData.valor / localFormData.qtdHoras : 0), backgroundColor: colors.blue[500] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
        lineNumber: 158,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
        lineNumber: 157,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
        lineNumber: 156,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 154,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.empresas, children: !horizontal && /* @__PURE__ */ jsxDEV(CompaniesDropdown, { label: "Empresa", multiSelect: true, clientId: formData?.clienteId, selectedKeys: localFormData?.empresas?.map((x) => x.empresaId), onChange: onMultiDropdownChange("empresas", "empresaId"), contractIds: isSubcontract ? contract?.empresas.map((company) => company.empresaId) : void 0, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("empresasSub", apiError?.errors?.messages) : onFieldError("empresas", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 163,
      columnNumber: 25
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 162,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.despesaViagem, children: /* @__PURE__ */ jsxDEV(ComboBox, { label: "Despesa de viagem", placeholder: "Selecionar", options: travelExpense, selectedKey: localFormData.despesaViagem, onChange: onDropdownChange("despesaViagem"), errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("despesaViagemSub", apiError?.errors?.messages) : onFieldError("despesaViagem", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 166,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.parecer, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Com parecer", onChange: onCheckboxChange("isParecer"), checked: localFormData.isParecer }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 169,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.circularizacao, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Tem circularização", onChange: onCheckboxChange("isCircularizacao"), checked: localFormData.isCircularizacao }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 172,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 171,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.inventario, children: /* @__PURE__ */ jsxDEV(Checkbox, { label: "Tem inventário", onChange: onCheckboxChange("isInventario"), checked: localFormData.isInventario }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 175,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 174,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.observacao, children: /* @__PURE__ */ jsxDEV(TextField, { label: `Descrição ${localFormData.despesaViagem === 2 ? "" : "(opcional)"}`, placeholder: "Inserir descrição do contrato", value: localFormData.observacao, onChange: onTextChange("observacao"), multiline: true, rows: apiError ? 12 : 10, resizable: false, maxLength: 1250, errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("observacaoSub", apiError?.errors?.messages) : onFieldError("observacao", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 178,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 177,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.tipoContrato, children: /* @__PURE__ */ jsxDEV(ContractTypeDropdown, { selectedKey: formData?.tipoContrato, onChange: onDropdownChange("tipoContrato"), errorMessage: apiError?.errors?.messages ? onFieldError("tipoContrato", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 181,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 180,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.impostos, children: /* @__PURE__ */ jsxDEV(ComboBox, { label: "Impostos", multiSelect: true, allowFreeform: true, autoComplete: "on", options: taxesOptions, selectedKey: formData?.impostos, onChange: handleChangeTaxes, errorMessage: apiError?.errors?.messages ? onFieldError("tipoContrato", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 184,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.inicioContrato, children: /* @__PURE__ */ jsxDEV(DatePicker, { label: "Início do contrato", value: localFormData.dataInicio ? new Date(localFormData.dataInicio) : void 0, allowTextInput: true, onSelectDate: onDateChange("dataInicio"), formatString: "dd/MM/yyyy" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 187,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 186,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.finalContrato, children: /* @__PURE__ */ jsxDEV(DatePicker, { label: "Fim do contrato", value: localFormData.dataFim ? new Date(localFormData.dataFim) : void 0, allowTextInput: true, onSelectDate: onDateChange("dataFim"), formatString: "dd/MM/yyyy" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 190,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 189,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.percentualExito, children: /* @__PURE__ */ jsxDEV(NumberInput, { label: "Percentual de êxito", placeholder: "%", value: localFormData.percentualExito !== null ? localFormData.percentualExito : void 0, maxLength: 3, onChange: handlePercentChange, errorMessage: apiError?.errors?.messages ? onFieldError("percentualExito", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 193,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 192,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.contatoCliente, children: /* @__PURE__ */ jsxDEV(TextField, { maxLength: 100, label: "Nome do contato no cliente", value: localFormData.nomeResponsavelCliente || "", onChange: onTextChange("nomeResponsavelCliente"), errorMessage: apiError?.errors?.messages ? onFieldError("nomeResponsavelCliente", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 196,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.contatoEmail, children: /* @__PURE__ */ jsxDEV(TextField, { label: "E-mail do contato no cliente", value: localFormData.emailResponsavelCliente || "", maxLength: 450, onChange: onTextChange("emailResponsavelCliente"), errorMessage: apiError?.errors?.messages ? onFieldError("emailResponsavelCliente", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 199,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 198,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.contatoTelefone, children: /* @__PURE__ */ jsxDEV(PhoneInput, { label: "Telefone do contato no cliente", value: localFormData.telefoneResponsavelCliente || "", onChange: onNumberTextChange("telefoneResponsavelCliente"), errorMessage: apiError?.errors?.messages ? onFieldError("telefoneResponsavelCliente", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 202,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 201,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.responsavelComercial, children: /* @__PURE__ */ jsxDEV(UsersDropdown, { label: "Contato comercial", placeholder: "Selecionar contato comercial", selectedKey: localFormData.responsavelComercialId, onChange: onDropdownChange("responsavelComercialId"), errorMessage: apiError?.errors?.messages ? isSubcontract ? onFieldError("responsavelComercialIdSub", apiError?.errors?.messages) : onFieldError("responsavelComercialId", apiError?.errors?.messages) : void 0 }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 205,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
      lineNumber: 204,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx",
    lineNumber: 123,
    columnNumber: 10
  }, this);
};
_s(ContractEditForm, "dOVrKkDkbAlwPFPDOT+FGkuNWVU=", false, function() {
  return [useTheme, useFormData];
});
_c = ContractEditForm;
const travelExpense = [{
  key: 0,
  text: "Não"
}, {
  key: 1,
  text: "Sim"
}, {
  key: 2,
  text: "Sim/Parcial"
}];
const taxesOptions = [{
  key: TaxesEnum.IPI,
  text: TaxesRercord[TaxesEnum.IPI]
}, {
  key: TaxesEnum.PIS,
  text: TaxesRercord[TaxesEnum.PIS]
}, {
  key: TaxesEnum.COFINS,
  text: TaxesRercord[TaxesEnum.COFINS]
}, {
  key: TaxesEnum.ICMS,
  text: TaxesRercord[TaxesEnum.ICMS]
}, {
  key: TaxesEnum.ICMSST,
  text: TaxesRercord[TaxesEnum.ICMSST]
}, {
  key: TaxesEnum.IRPJ,
  text: TaxesRercord[TaxesEnum.IRPJ]
}, {
  key: TaxesEnum.CSLL,
  text: TaxesRercord[TaxesEnum.CSLL]
}, {
  key: TaxesEnum.INSS,
  text: TaxesRercord[TaxesEnum.INSS]
}, {
  key: TaxesEnum.NaoSeAplica,
  text: TaxesRercord[TaxesEnum.NaoSeAplica]
}];
const getStyles = (horizontal, apiError) => mergeStyleSets({
  grid: {
    display: "grid",
    gap: "12px 16px",
    alignItems: "start",
    alignContent: "center",
    gridTemplate: horizontal ? `
      "n nc ti im di df" auto
      "e q v ci pa ." auto
      "m d h pe in ." auto
      "t t c c cc cc" auto
      "cm cm ct ct rc rc" auto
      "o o o o o o" auto / 1fr 1fr 1fr 1fr 1fr 1fr
      ` : `
      "n n nc nc" auto
      "ga ga . ." auto
      "ti ti ti ti" auto
      "im im im im" auto
      "t t t t" auto
      "c c c c" auto
      "di di df df" auto
      "e e m m" auto
      "q v h h" auto
      "pe pe . ." auto
      "em em em em" auto
      "d d d d" auto
      "pa pa pa pa" auto
      "ci ci ci ci" auto
      "in in in in" auto
      "cc cc cc cc" auto
      "cm cm ct ct" auto
      "rc rc rc rc" auto
      "o o o o" auto / 1fr 1fr 1fr 1fr
      `
  },
  numeroProposta: {
    gridArea: "n",
    height: horizontal && apiError && 83
  },
  numeroPropostaComercial: {
    gridArea: "nc",
    height: horizontal && apiError && 83
  },
  responsavelTecnico: {
    gridArea: "t",
    height: apiError && 83
  },
  responsavelCliente: {
    gridArea: "c"
  },
  responsavelComercial: {
    gridArea: "rc"
  },
  exercicio: {
    gridArea: "e",
    height: apiError && 83
  },
  mesRenovacao: {
    gridArea: "m",
    height: apiError && 83
  },
  qtdHoras: {
    gridArea: "q",
    height: apiError && 83
  },
  valor: {
    gridArea: "v",
    height: apiError && 83
  },
  valorHora: {
    gridArea: "h"
  },
  tipoContrato: {
    gridArea: "ti"
  },
  impostos: {
    gridArea: "im"
  },
  inicioContrato: {
    gridArea: "di"
  },
  finalContrato: {
    gridArea: "df"
  },
  percentualExito: {
    gridArea: "pe"
  },
  contatoCliente: {
    gridArea: "cc"
  },
  contatoEmail: {
    gridArea: "cm"
  },
  contatoTelefone: {
    gridArea: "ct"
  },
  despesaViagem: {
    gridArea: "d"
  },
  parecer: {
    gridArea: "pa",
    marginTop: horizontal && 34
  },
  circularizacao: {
    gridArea: "ci",
    marginTop: horizontal && 34
  },
  inventario: {
    gridArea: "in",
    marginTop: horizontal && 34
  },
  observacao: {
    gridArea: "o"
  },
  empresas: {
    gridArea: "em"
  },
  geraAuditoria: {
    gridArea: "ga"
  }
});
export default ContractEditForm;
var _c;
$RefreshReg$(_c, "ContractEditForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractEditForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0lRLFNBZ0pBLFVBaEpBOzs7Ozs7Ozs7Ozs7Ozs7O0FBeElSLFNBQWFBLGFBQWFDLFlBQVlDLFdBQVdDLGVBQWU7QUFDaEUsU0FBMEJDLGdCQUFnQkMsYUFBOEI7QUFDeEUsU0FBU0MsZUFBZTtBQUV4QixTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0MsVUFBVUMsVUFBVUMsZUFBZUMsWUFBWUMsaUJBQWlCQyxlQUFlQyxhQUFhQyxZQUFZQyxLQUFLQyxXQUFXQyxtQkFBbUI7QUFDcEosU0FBU0Msd0JBQXdCQyxxQkFBcUI7QUFFdEQsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUJDLGVBQWU7QUFHM0MsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxvQ0FBb0M7QUFDN0MsU0FBU0MsNEJBQTRCO0FBUXJDLE1BQU1DLG1CQUErQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQzdELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQztBQUFBQSxJQUFVQyxhQUFhO0FBQUEsSUFBT0M7QUFBQUEsSUFBZUMsWUFBWTtBQUFBLEVBQU0sSUFBSVA7QUFFL0YsUUFBTTtBQUFBLElBQUVRO0FBQUFBLEVBQVMsSUFBSXRDLFdBQVcyQiw0QkFBNEI7QUFDNUQsUUFBTTtBQUFBLElBQUVZO0FBQUFBLEVBQU8sSUFBSWhDLFNBQVM7QUFFNUIsUUFBTTtBQUFBLElBQ0owQixVQUFVTztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUk3QyxZQUEwQjJCLFFBQXdCO0FBRXRELFFBQU1tQixTQUFTQyxVQUFVbEIsWUFBWUgsUUFBUTtBQUU3QyxRQUFNc0Isa0JBQWtCdkQsWUFBWSxZQUFZO0FBQzlDLFFBQUl5QyxjQUFjZSxtQkFBbUJDLFFBQVc7QUFDOUMsWUFBTUMsV0FBVyxNQUFNakMsUUFBUThCLGdCQUFnQjtBQUMvQ1osdUJBQWlCO0FBQUEsUUFDZixHQUFHVDtBQUFBQSxRQUNIc0IsZ0JBQWdCRSxTQUFTRjtBQUFBQSxNQUMzQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxDQUFDZixhQUFhLENBQUM7QUFFbEIsUUFBTWtCLHNCQUFzQjNELFlBQVksQ0FBQzRELEdBQVlDLFVBQStCO0FBQ2xGLFFBQUlBLE9BQU87QUFDVCxZQUFNQyxXQUFXRCxTQUFTLElBQUksSUFBSUEsU0FBUyxNQUFNLE1BQU1BO0FBQ3ZEbEIsdUJBQWlCb0IsZUFBYTtBQUM1QixlQUFPO0FBQUEsVUFDTCxHQUFHQTtBQUFBQSxVQUNIQyxpQkFBaUJGO0FBQUFBLFFBQ25CO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUcsb0JBQW9CakUsWUFBWSxDQUFDNEQsR0FBYUMsVUFBNEI7QUFDOUUsVUFBTUssY0FBY2hDLFVBQVVpQyxZQUFZO0FBQzFDLFFBQUlDLGNBQXdCO0FBRTVCLFFBQUlQLE9BQU9RLFFBQVEzQyxVQUFVNEMsYUFBYTtBQUN4Q0Ysb0JBQWNQLE1BQU1VLFdBQ2hCLENBQUNWLE1BQU1RLEdBQWEsSUFDcEJILFlBQVlNLE9BQU9DLFVBQVFBLFNBQVNaLE1BQU1RLEdBQUc7QUFFakQxQix1QkFBaUIrQixXQUFTO0FBQUEsUUFDeEIsR0FBR0E7QUFBQUEsUUFDSFAsVUFBVUM7QUFBQUEsTUFDWixFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0wsVUFBSVAsVUFBVUosUUFBVztBQUN2Qlcsc0JBQWNQLE1BQU1VLFdBQ2hCLENBQUMsR0FBR0wsYUFBYUwsTUFBTVEsR0FBYSxJQUNwQ0gsWUFBWU0sT0FBT0MsVUFBUUEsU0FBU1osTUFBTVEsR0FBRztBQUFBLE1BQ25EO0FBRUFELG9CQUFjQSxZQUFZSSxPQUFPQyxVQUFRQSxTQUFTL0MsVUFBVTRDLFdBQVc7QUFBQSxJQUN6RTtBQUVBM0IscUJBQWlCb0IsZUFBYTtBQUM1QixhQUFPO0FBQUEsUUFDTCxHQUFHQTtBQUFBQSxRQUNISSxVQUFVQztBQUFBQSxNQUNaO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNsQyxVQUFVaUMsUUFBUSxDQUFDO0FBRXZCLFFBQU1RLHFCQUFxQnhFLFFBQVEsTUFBTTtBQUN2QyxRQUFJc0MsY0FBY21DLDRCQUE0QixNQUFNO0FBQ2xEbkMsb0JBQWNtQywwQkFBMEI7QUFBQSxJQUMxQztBQUNBLFdBQU9uQyxjQUFjbUMsd0JBQXdCQyxLQUFLLEVBQUVDLFNBQVMsSUFDekQsYUFDQTtBQUFBLEVBQ04sR0FBRyxDQUFDckMsYUFBYSxDQUFDO0FBRWxCdkMsWUFBVSxNQUFNO0FBQ2RxRCxvQkFBZ0I7QUFBQSxFQUNsQixHQUFHLENBQUNBLGVBQWUsQ0FBQztBQUVwQnJELFlBQVUsTUFBTTtBQUNkLFFBQUlnQyxZQUFZLENBQUM1QixRQUFRNEIsVUFBVU8sYUFBYSxHQUFHO0FBQ2pERSx1QkFBaUJULFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYmhDLFlBQVUsTUFBTTtBQUNkaUMsZUFBV00sYUFBYTtBQUFBLEVBQzFCLEdBQUcsQ0FBQ0EsYUFBYSxDQUFDO0FBRWxCdkMsWUFBVSxNQUFNO0FBQ2QsUUFBSXVDLGVBQWU7QUFDakIsVUFBSUosaUJBQWlCLENBQUNJLGNBQWNtQywyQkFBMkJyQyxVQUFVO0FBQ3ZFSixtQkFBVztBQUFBLFVBQ1QsR0FBR007QUFBQUEsVUFDSG1DLHlCQUF5QnJDLFNBQVNxQztBQUFBQSxRQUNwQyxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JDLFVBQVVGLGFBQWEsQ0FBQztBQUU1QixTQUNFLHVCQUFDLFNBQUksV0FBV2dCLE9BQU8wQixNQUNyQjtBQUFBLDJCQUFDLFNBQUksV0FBVzFCLE9BQU9HLGdCQUNyQixpQ0FBQyxtQkFDQyxPQUFNLGtCQUNOLFVBQVEsTUFDUixhQUFZLGtCQUNaLE9BQU9mLGNBQWNlLGtCQUFrQixJQUN2QyxVQUFVVixtQkFBbUIsZ0JBQWdCLEdBQzdDLE1BQUssV0FDTCxVQUFTLEtBQ1QsVUFBUSxNQUNSLGNBQWNiLFVBQVUrQyxRQUFRQyxXQUM1QjVDLGdCQUNFYSxhQUFhLHFCQUFxQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQzVEL0IsYUFBYSxrQkFBa0JqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUMzRHhCLFVBYk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNHLEtBZkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPdUIseUJBQ3JCLGlDQUFDLG1CQUNDLE9BQU0sa0JBQ04sYUFBWSxrQkFDWixPQUFPbkMsY0FBY21DLDJCQUEyQixJQUNoRCxVQUFVekIsbUJBQW1CLHlCQUF5QixHQUN0RCxNQUFNd0Isb0JBQ04sVUFBUyxLQUNULGNBQWMxQyxVQUFVK0MsUUFBUUMsV0FDNUI1QyxnQkFDRWEsYUFBYSw4QkFBOEJqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUNyRS9CLGFBQWEsMkJBQTJCakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDcEV4QixVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZRyxLQWJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBQ0NwQixpQkFBaUIsQ0FBQ0MsYUFDbkIsdUJBQUMsU0FBSSxXQUFXZSxPQUFPNkIsZUFDckIsaUNBQUMsWUFDQyxPQUFNLGlCQUNOLFVBQVVqQyxpQkFBaUIsZUFBZSxHQUMxQyxTQUFTUixjQUFjeUMsaUJBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHdUMsS0FKekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQzdDLGlCQUFpQkMsYUFDbEIsdUJBQUMsU0FBSSxXQUFXZSxPQUFPNkIsZUFDckIsaUNBQUMsWUFDQyxPQUFNLGlCQUNOLFNBQVN6QyxjQUFjeUMsZUFDdkIsVUFBVSxRQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHaUIsS0FKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVc3QixPQUFPOEIsb0JBQ3JCLGlDQUFDLDBCQUNDLE9BQU0sNkJBQ04sVUFBUSxNQUNSLFVBQVUxQyxjQUFjMkMsc0JBQ3hCLGFBQVksb0JBQ1osYUFBYTNDLGNBQWM0QyxzQkFDM0IsVUFBVXJDLGlCQUFpQixzQkFBc0IsR0FDakQsY0FBY2YsVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsMkJBQTJCakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDbEUvQixhQUFhLHdCQUF3QmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ2pFeEIsVUFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUcsS0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT2lDLG9CQUNyQixpQ0FBQyxpQkFDQyxPQUFNLHVCQUNOLFVBQVEsTUFDUixVQUFVN0MsY0FBYzRDLHNCQUN4QixhQUFZLGtDQUNaLGFBQWE1QyxjQUFjMkMsc0JBQzNCLFVBQVVwQyxpQkFBaUIsc0JBQXNCLEdBQ2pELGNBQWNmLFVBQVUrQyxRQUFRQyxXQUM1QjVDLGdCQUNFYSxhQUFhLDJCQUEyQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ2xFL0IsYUFBYSx3QkFBd0JqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUNqRXhCLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlHLEtBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdKLE9BQU9rQyxXQUNyQixpQ0FBQyxhQUNDLE9BQU0sYUFDTixVQUFRLE1BQ1IsYUFBWSxhQUNaLE9BQU85QyxjQUFjOEMsV0FBV0MsU0FBUyxLQUFLLElBQzlDLFVBQVUzQyxlQUFlLFdBQVcsR0FDcEMsV0FBVyxHQUNYLGNBQWNaLFVBQVUrQyxRQUFRQyxXQUM1QjVDLGdCQUNFYSxhQUFhLGdCQUFnQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ3ZEL0IsYUFBYSxhQUFhakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDdER4QixVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZRyxLQWJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPb0MsY0FDckIsaUNBQUMsaUJBQ0MsT0FBTSxpQkFDTixhQUFZLE9BQ1osYUFBYWhELGNBQWNnRCxjQUMzQixVQUFVekMsaUJBQWlCLGNBQWMsR0FDekMsY0FBY2YsVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsbUJBQW1CakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDMUQvQixhQUFhLGdCQUFnQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ3pEeEIsVUFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUcsS0FYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT3FDLFVBQ3JCLGlDQUFDLGFBQ0MsT0FBTSxjQUNOLGFBQVksaUJBQ1osT0FBT2pELGNBQWNpRCxVQUFVRixTQUFTLEtBQUssSUFDN0MsVUFBVTNDLGVBQWUsVUFBVSxHQUNuQyxXQUFXLEdBQ1gsY0FBY1osVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsZUFBZWpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ3REL0IsYUFBYSxZQUFZakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDckR4QixVQVZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXRyxLQVpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPc0MsT0FDckIsaUNBQUMsaUJBQ0MsT0FBTSxTQUNOLE9BQU9sRCxjQUFja0QsT0FDckIsVUFBVTlDLGVBQWUsT0FBTyxHQUNoQyxXQUFXLElBQ1gsY0FBY1osVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsWUFBWWpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ25EL0IsYUFBYSxTQUFTakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDbER4QixVQVROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVRyxLQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPdUMsV0FDckI7QUFBQSw2QkFBQyxTQUFNLDBCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUNqQixtQ0FDRSxpQ0FBQyxlQUNDLFNBQVMsY0FDVCxJQUFHLCtCQUVILGlDQUFDLE9BQUksTUFBTXJFLGVBQWVrQixjQUFjaUQsWUFBWWpELGNBQWNpRCxZQUFZLEtBQUtqRCxjQUFja0QsUUFDN0ZsRCxjQUFja0QsUUFBUWxELGNBQWNpRCxXQUNwQyxDQUFDLEdBRUwsaUJBQWlCbEQsT0FBT3FELEtBQUssR0FBRyxLQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSWtDLEtBUnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVd4QyxPQUFPeUMsVUFDcEIsV0FBQzFELGNBQWMsdUJBQUMscUJBQ2YsT0FBTSxXQUNOLGFBQVcsTUFDWCxVQUFVRixVQUFVNkQsV0FDcEIsY0FBY3RELGVBQWVxRCxVQUFVRSxJQUFJQyxPQUFLQSxFQUFFQyxTQUFTLEdBQzNELFVBQVVuRCxzQkFBc0IsWUFBWSxXQUFXLEdBQ3ZELGFBQWFWLGdCQUFnQkUsVUFBVXVELFNBQVNFLElBQUlHLGFBQVdBLFFBQVFELFNBQVMsSUFBSXpDLFFBQ3BGLGNBQWN4QixVQUFVK0MsUUFBUUMsV0FDNUI1QyxnQkFDRWEsYUFBYSxlQUFlakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDdEQvQixhQUFhLFlBQVlqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUNyRHhCLFVBWFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVliLEtBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdKLE9BQU8rQyxlQUNyQixpQ0FBQyxZQUNDLE9BQU0scUJBQ04sYUFBWSxjQUNaLFNBQVNDLGVBQ1QsYUFBYTVELGNBQWMyRCxlQUMzQixVQUFVcEQsaUJBQWlCLGVBQWUsR0FDMUMsY0FBY2YsVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsb0JBQW9CakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDM0QvQixhQUFhLGlCQUFpQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQzFEeEIsVUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0csS0FaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT2lELFNBQ3JCLGlDQUFDLFlBQ0MsT0FBTSxlQUNOLFVBQVVyRCxpQkFBaUIsV0FBVyxHQUN0QyxTQUFTUixjQUFjOEQsYUFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdtQyxLQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV2xELE9BQU9tRCxnQkFDckIsaUNBQUMsWUFDQyxPQUFNLHNCQUNOLFVBQVV2RCxpQkFBaUIsa0JBQWtCLEdBQzdDLFNBQVNSLGNBQWNnRSxvQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUcwQyxLQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV3BELE9BQU9xRCxZQUNyQixpQ0FBQyxZQUNDLE9BQU0sa0JBQ04sVUFBVXpELGlCQUFpQixjQUFjLEdBQ3pDLFNBQVNSLGNBQWNrRSxnQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdzQyxLQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV3RELE9BQU91RCxZQUNyQixpQ0FBQyxhQUNDLE9BQVEsYUFBWW5FLGNBQWMyRCxrQkFBa0IsSUFBSSxLQUFLLGdCQUM3RCxhQUFZLGlDQUNaLE9BQU8zRCxjQUFjbUUsWUFDckIsVUFBVWhFLGFBQWEsWUFBWSxHQUNuQyxXQUFTLE1BQ1QsTUFBTVgsV0FBVyxLQUFLLElBQ3RCLFdBQVcsT0FDWCxXQUFXLE1BQ1gsY0FBY0EsVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsaUJBQWlCakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDeEQvQixhQUFhLGNBQWNqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUN2RHhCLFVBYk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNHLEtBZkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPd0QsY0FDckIsaUNBQUMsd0JBQ0MsYUFBYTNFLFVBQVUyRSxjQUN2QixVQUFVN0QsaUJBQWlCLGNBQWMsR0FDekMsY0FBY2YsVUFBVStDLFFBQVFDLFdBQzVCL0IsYUFBYSxnQkFBZ0JqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUN2RHhCLFVBTE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtnQixLQU5sQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT2MsVUFDckIsaUNBQUMsWUFDQyxPQUFNLFlBQ04sYUFBVyxNQUNYLGVBQWUsTUFDZixjQUFhLE1BQ2IsU0FBUzJDLGNBQ1QsYUFBYTVFLFVBQVVpQyxVQUN2QixVQUFVRixtQkFDVixjQUFjaEMsVUFBVStDLFFBQVFDLFdBQzVCL0IsYUFBYSxnQkFBZ0JqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUN2RHhCLFVBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdHLEtBWkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdKLE9BQU8wRCxnQkFDckIsaUNBQUMsY0FDQyxPQUFNLHNCQUNOLE9BQU90RSxjQUFjdUUsYUFBYSxJQUFJQyxLQUFLeEUsY0FBY3VFLFVBQVUsSUFBSXZELFFBQ3ZFLGdCQUFjLE1BQ2QsY0FBY0wsYUFBYSxZQUFZLEdBQ3ZDLGNBQWMsZ0JBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLNkIsS0FOL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVdDLE9BQU82RCxlQUNyQixpQ0FBQyxjQUNDLE9BQU0sbUJBQ04sT0FBT3pFLGNBQWMwRSxVQUFVLElBQUlGLEtBQUt4RSxjQUFjMEUsT0FBTyxJQUFJMUQsUUFDakUsZ0JBQWMsTUFDZCxjQUFjTCxhQUFhLFNBQVMsR0FDcEMsY0FBYyxnQkFMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUs2QixLQU4vQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0MsT0FBT1csaUJBQ3JCLGlDQUFDLGVBQ0MsT0FBTSx1QkFDTixhQUFZLEtBQ1osT0FBT3ZCLGNBQWN1QixvQkFBb0IsT0FBT3ZCLGNBQWN1QixrQkFBa0JQLFFBQ2hGLFdBQVcsR0FDWCxVQUFVRSxxQkFDVixjQUFjMUIsVUFBVStDLFFBQVFDLFdBQzVCL0IsYUFBYSxtQkFBbUJqQixVQUFVK0MsUUFBUUMsUUFBUSxJQUMxRHhCLFVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFnQixLQVRsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBTytELGdCQUNyQixpQ0FBQyxhQUNDLFdBQVcsS0FDWCxPQUFNLDhCQUNOLE9BQU8zRSxjQUFjNEUsMEJBQTBCLElBQy9DLFVBQVV6RSxhQUFhLHdCQUF3QixHQUMvQyxjQUFjWCxVQUFVK0MsUUFBUUMsV0FDNUIvQixhQUFhLDBCQUEwQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ2pFeEIsVUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUcsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT2lFLGNBQ3JCLGlDQUFDLGFBQ0MsT0FBTSxnQ0FDTixPQUFPN0UsY0FBYzhFLDJCQUEyQixJQUNoRCxXQUFXLEtBQ1gsVUFBVTNFLGFBQWEseUJBQXlCLEdBQ2hELGNBQWNYLFVBQVUrQyxRQUFRQyxXQUM1Qi9CLGFBQWEsMkJBQTJCakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDbEV4QixVQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRRyxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXSixPQUFPbUUsaUJBQ3JCLGlDQUFDLGNBQ0MsT0FBTSxrQ0FDTixPQUFPL0UsY0FBY2dGLDhCQUE4QixJQUNuRCxVQUFVM0UsbUJBQW1CLDRCQUE0QixHQUN6RCxjQUFjYixVQUFVK0MsUUFBUUMsV0FDNUIvQixhQUFhLDhCQUE4QmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ3JFeEIsVUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0csS0FSTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBV0osT0FBT3FFLHNCQUNyQixpQ0FBQyxpQkFDQyxPQUFNLHFCQUNOLGFBQVksZ0NBQ1osYUFBYWpGLGNBQWNrRix3QkFDM0IsVUFBVTNFLGlCQUFpQix3QkFBd0IsR0FDbkQsY0FBY2YsVUFBVStDLFFBQVFDLFdBQzVCNUMsZ0JBQ0VhLGFBQWEsNkJBQTZCakIsVUFBVStDLFFBQVFDLFFBQVEsSUFDcEUvQixhQUFhLDBCQUEwQmpCLFVBQVUrQyxRQUFRQyxRQUFRLElBQ25FeEIsVUFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUcsS0FYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQTVVRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNlVBO0FBRUo7QUFBQ3pCLEdBN2JLRixrQkFBMkM7QUFBQSxVQUk1QnRCLFVBY2ZELFdBQVc7QUFBQTtBQUFBcUgsS0FsQlg5RjtBQStiTixNQUFNdUUsZ0JBQW1DLENBQ3ZDO0FBQUEsRUFBRWhDLEtBQUs7QUFBQSxFQUFHd0QsTUFBTTtBQUFNLEdBQ3RCO0FBQUEsRUFBRXhELEtBQUs7QUFBQSxFQUFHd0QsTUFBTTtBQUFNLEdBQ3RCO0FBQUEsRUFBRXhELEtBQUs7QUFBQSxFQUFHd0QsTUFBTTtBQUFjLENBQUM7QUFHakMsTUFBTWYsZUFBa0MsQ0FDdEM7QUFBQSxFQUNFekMsS0FBSzNDLFVBQVVvRztBQUFBQSxFQUNmRCxNQUFNbEcsYUFBYUQsVUFBVW9HLEdBQUc7QUFDbEMsR0FDQTtBQUFBLEVBQ0V6RCxLQUFLM0MsVUFBVXFHO0FBQUFBLEVBQ2ZGLE1BQU1sRyxhQUFhRCxVQUFVcUcsR0FBRztBQUNsQyxHQUNBO0FBQUEsRUFDRTFELEtBQUszQyxVQUFVc0c7QUFBQUEsRUFDZkgsTUFBTWxHLGFBQWFELFVBQVVzRyxNQUFNO0FBQ3JDLEdBQ0E7QUFBQSxFQUNFM0QsS0FBSzNDLFVBQVV1RztBQUFBQSxFQUNmSixNQUFNbEcsYUFBYUQsVUFBVXVHLElBQUk7QUFDbkMsR0FDQTtBQUFBLEVBQ0U1RCxLQUFLM0MsVUFBVXdHO0FBQUFBLEVBQ2ZMLE1BQU1sRyxhQUFhRCxVQUFVd0csTUFBTTtBQUNyQyxHQUNBO0FBQUEsRUFDRTdELEtBQUszQyxVQUFVeUc7QUFBQUEsRUFDZk4sTUFBTWxHLGFBQWFELFVBQVV5RyxJQUFJO0FBQ25DLEdBQ0E7QUFBQSxFQUNFOUQsS0FBSzNDLFVBQVUwRztBQUFBQSxFQUNmUCxNQUFNbEcsYUFBYUQsVUFBVTBHLElBQUk7QUFDbkMsR0FDQTtBQUFBLEVBQ0UvRCxLQUFLM0MsVUFBVTJHO0FBQUFBLEVBQ2ZSLE1BQU1sRyxhQUFhRCxVQUFVMkcsSUFBSTtBQUNuQyxHQUNBO0FBQUEsRUFDRWhFLEtBQUszQyxVQUFVNEM7QUFBQUEsRUFDZnVELE1BQU1sRyxhQUFhRCxVQUFVNEMsV0FBVztBQUMxQyxDQUFDO0FBR0gsTUFBTWhCLFlBQVlBLENBQUNsQixZQUFxQkgsYUFBd0I3QixlQUFlO0FBQUEsRUFDN0UyRSxNQUFNO0FBQUEsSUFDSnVELFNBQVM7QUFBQSxJQUNUQyxLQUFLO0FBQUEsSUFDTEMsWUFBWTtBQUFBLElBQ1pDLGNBQWM7QUFBQSxJQUNkQyxjQUFjdEcsYUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxQlA7QUFBQSxFQUNBb0IsZ0JBQWdCO0FBQUEsSUFBRW1GLFVBQVU7QUFBQSxJQUFLQyxRQUFReEcsY0FBY0gsWUFBWTtBQUFBLEVBQUc7QUFBQSxFQUN0RTJDLHlCQUF5QjtBQUFBLElBQUUrRCxVQUFVO0FBQUEsSUFBTUMsUUFBUXhHLGNBQWNILFlBQVk7QUFBQSxFQUFHO0FBQUEsRUFDaEZrRCxvQkFBb0I7QUFBQSxJQUFFd0QsVUFBVTtBQUFBLElBQUtDLFFBQVEzRyxZQUFZO0FBQUEsRUFBRztBQUFBLEVBQzVEcUQsb0JBQW9CO0FBQUEsSUFBRXFELFVBQVU7QUFBQSxFQUFJO0FBQUEsRUFDcENqQixzQkFBc0I7QUFBQSxJQUFFaUIsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUN2Q3BELFdBQVc7QUFBQSxJQUFFb0QsVUFBVTtBQUFBLElBQUtDLFFBQVEzRyxZQUFZO0FBQUEsRUFBRztBQUFBLEVBQ25Ed0QsY0FBYztBQUFBLElBQUVrRCxVQUFVO0FBQUEsSUFBS0MsUUFBUTNHLFlBQVk7QUFBQSxFQUFHO0FBQUEsRUFDdER5RCxVQUFVO0FBQUEsSUFBRWlELFVBQVU7QUFBQSxJQUFLQyxRQUFRM0csWUFBWTtBQUFBLEVBQUc7QUFBQSxFQUNsRDBELE9BQU87QUFBQSxJQUFFZ0QsVUFBVTtBQUFBLElBQUtDLFFBQVEzRyxZQUFZO0FBQUEsRUFBRztBQUFBLEVBQy9DMkQsV0FBVztBQUFBLElBQUUrQyxVQUFVO0FBQUEsRUFBSTtBQUFBLEVBQzNCOUIsY0FBYztBQUFBLElBQUU4QixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQy9CeEUsVUFBVTtBQUFBLElBQUV3RSxVQUFVO0FBQUEsRUFBSztBQUFBLEVBQzNCNUIsZ0JBQWdCO0FBQUEsSUFBRTRCLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDakN6QixlQUFlO0FBQUEsSUFBRXlCLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDaEMzRSxpQkFBaUI7QUFBQSxJQUFFMkUsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUNsQ3ZCLGdCQUFnQjtBQUFBLElBQUV1QixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQ2pDckIsY0FBYztBQUFBLElBQUVxQixVQUFVO0FBQUEsRUFBSztBQUFBLEVBQy9CbkIsaUJBQWlCO0FBQUEsSUFBRW1CLFVBQVU7QUFBQSxFQUFLO0FBQUEsRUFDbEN2QyxlQUFlO0FBQUEsSUFBRXVDLFVBQVU7QUFBQSxFQUFJO0FBQUEsRUFDL0JyQyxTQUFTO0FBQUEsSUFBRXFDLFVBQVU7QUFBQSxJQUFNRSxXQUFXekcsY0FBYztBQUFBLEVBQUc7QUFBQSxFQUN2RG9FLGdCQUFnQjtBQUFBLElBQUVtQyxVQUFVO0FBQUEsSUFBTUUsV0FBV3pHLGNBQWM7QUFBQSxFQUFHO0FBQUEsRUFDOURzRSxZQUFZO0FBQUEsSUFBRWlDLFVBQVU7QUFBQSxJQUFNRSxXQUFXekcsY0FBYztBQUFBLEVBQUc7QUFBQSxFQUMxRHdFLFlBQVk7QUFBQSxJQUFFK0IsVUFBVTtBQUFBLEVBQUk7QUFBQSxFQUM1QjdDLFVBQVU7QUFBQSxJQUFFNkMsVUFBVTtBQUFBLEVBQUs7QUFBQSxFQUMzQnpELGVBQWU7QUFBQSxJQUFFeUQsVUFBVTtBQUFBLEVBQUs7QUFDbEMsQ0FBQztBQUVELGVBQWU3RztBQUFnQixJQUFBOEY7QUFBQWtCLGFBQUFsQixJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsIm1lcmdlU3R5bGVTZXRzIiwiTGFiZWwiLCJpc0VxdWFsIiwidXNlRm9ybURhdGEiLCJ1c2VUaGVtZSIsIkNoZWNrYm94IiwiQ29tYm9Cb3giLCJDdXJyZW5jeUlucHV0IiwiRGF0ZVBpY2tlciIsIk1hc2tlZFRleHRGaWVsZCIsIk1vbnRoRHJvcGRvd24iLCJOdW1iZXJJbnB1dCIsIlBob25lSW5wdXQiLCJUYWciLCJUZXh0RmllbGQiLCJUb29sdGlwSG9zdCIsIlVzZXJBc3NvY2lhdGVzRHJvcGRvd24iLCJVc2Vyc0Ryb3Bkb3duIiwiQ29tcGFuaWVzRHJvcGRvd24iLCJmb3JtYXRDdXJyZW5jeSIsImNvbnRyYWN0U2VydmljZSIsInNlcnZpY2UiLCJUYXhlc0VudW0iLCJUYXhlc1JlcmNvcmQiLCJDb250cmFjdENvbmZpZ3VyYXRpb25Db250ZXh0IiwiQ29udHJhY3RUeXBlRHJvcGRvd24iLCJDb250cmFjdEVkaXRGb3JtIiwicHJvcHMiLCJfcyIsImFwaUVycm9yIiwiZm9ybURhdGEiLCJvbkNoYW5nZSIsImhvcml6b250YWwiLCJpc1N1YmNvbnRyYWN0IiwiaXNFZGl0aW5nIiwiY29udHJhY3QiLCJjb2xvcnMiLCJsb2NhbEZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJzZXRMb2NhbEZvcm1EYXRhIiwib25UZXh0Q2hhbmdlIiwib25OdW1iZXJDaGFuZ2UiLCJvbk51bWJlclRleHRDaGFuZ2UiLCJvbk11bHRpRHJvcGRvd25DaGFuZ2UiLCJvbkRyb3Bkb3duQ2hhbmdlIiwib25DaGVja2JveENoYW5nZSIsIm9uRmllbGRFcnJvciIsIm9uRGlnaXRzVGV4dENoYW5nZSIsIm9uRGF0ZUNoYW5nZSIsInN0eWxlcyIsImdldFN0eWxlcyIsImdldE5leHRQcm9wb3NhbCIsIm51bWVyb1Byb3Bvc3RhIiwidW5kZWZpbmVkIiwicHJvcG9zYWwiLCJoYW5kbGVQZXJjZW50Q2hhbmdlIiwiXyIsInZhbHVlIiwiZmluYWxWYWwiLCJwcmV2U3RhdGUiLCJwZXJjZW50dWFsRXhpdG8iLCJoYW5kbGVDaGFuZ2VUYXhlcyIsIm9sZFNlbGVjdGVkIiwiaW1wb3N0b3MiLCJuZXdTZWxlY3RlZCIsImtleSIsIk5hb1NlQXBsaWNhIiwic2VsZWN0ZWQiLCJmaWx0ZXIiLCJpdGVtIiwiZGF0YSIsImZvcm1hdFByb3Bvc2FsTWFzayIsIm51bWVyb1Byb3Bvc3RhQ29tZXJjaWFsIiwidHJpbSIsImxlbmd0aCIsImdyaWQiLCJlcnJvcnMiLCJtZXNzYWdlcyIsImdlcmFBdWRpdG9yaWEiLCJyZXNwb25zYXZlbFRlY25pY28iLCJyZXNwb25zYXZlbENsaWVudGVJZCIsInJlc3BvbnNhdmVsVGVjbmljb0lkIiwicmVzcG9uc2F2ZWxDbGllbnRlIiwiZXhlcmNpY2lvIiwidG9TdHJpbmciLCJtZXNSZW5vdmFjYW8iLCJxdGRIb3JhcyIsInZhbG9yIiwidmFsb3JIb3JhIiwiYmx1ZSIsImVtcHJlc2FzIiwiY2xpZW50ZUlkIiwibWFwIiwieCIsImVtcHJlc2FJZCIsImNvbXBhbnkiLCJkZXNwZXNhVmlhZ2VtIiwidHJhdmVsRXhwZW5zZSIsInBhcmVjZXIiLCJpc1BhcmVjZXIiLCJjaXJjdWxhcml6YWNhbyIsImlzQ2lyY3VsYXJpemFjYW8iLCJpbnZlbnRhcmlvIiwiaXNJbnZlbnRhcmlvIiwib2JzZXJ2YWNhbyIsInRpcG9Db250cmF0byIsInRheGVzT3B0aW9ucyIsImluaWNpb0NvbnRyYXRvIiwiZGF0YUluaWNpbyIsIkRhdGUiLCJmaW5hbENvbnRyYXRvIiwiZGF0YUZpbSIsImNvbnRhdG9DbGllbnRlIiwibm9tZVJlc3BvbnNhdmVsQ2xpZW50ZSIsImNvbnRhdG9FbWFpbCIsImVtYWlsUmVzcG9uc2F2ZWxDbGllbnRlIiwiY29udGF0b1RlbGVmb25lIiwidGVsZWZvbmVSZXNwb25zYXZlbENsaWVudGUiLCJyZXNwb25zYXZlbENvbWVyY2lhbCIsInJlc3BvbnNhdmVsQ29tZXJjaWFsSWQiLCJfYyIsInRleHQiLCJJUEkiLCJQSVMiLCJDT0ZJTlMiLCJJQ01TIiwiSUNNU1NUIiwiSVJQSiIsIkNTTEwiLCJJTlNTIiwiZGlzcGxheSIsImdhcCIsImFsaWduSXRlbXMiLCJhbGlnbkNvbnRlbnQiLCJncmlkVGVtcGxhdGUiLCJncmlkQXJlYSIsImhlaWdodCIsIm1hcmdpblRvcCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyYWN0RWRpdEZvcm0udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi9jb250cmFjdHMvY29tcG9uZW50cy9Db250cmFjdEVkaXRGb3JtLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IElEcm9wZG93bk9wdGlvbiwgbWVyZ2VTdHlsZVNldHMsIExhYmVsLCBJQ29tYm9Cb3hPcHRpb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IGlzRXF1YWwgfSBmcm9tICdsb2Rhc2gtZXMnXHJcbmltcG9ydCB7IEJhc2VDb250cmFjdCB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9Db250cmFjdCdcclxuaW1wb3J0IHsgdXNlRm9ybURhdGEsIHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBDaGVja2JveCwgQ29tYm9Cb3gsIEN1cnJlbmN5SW5wdXQsIERhdGVQaWNrZXIsIE1hc2tlZFRleHRGaWVsZCwgTW9udGhEcm9wZG93biwgTnVtYmVySW5wdXQsIFBob25lSW5wdXQsIFRhZywgVGV4dEZpZWxkLCBUb29sdGlwSG9zdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBVc2VyQXNzb2NpYXRlc0Ryb3Bkb3duLCBVc2Vyc0Ryb3Bkb3duIH0gZnJvbSAnLi4vLi4vdXNlcnMvY29tcG9uZW50cydcclxuaW1wb3J0IHsgRWRpdEZvcm1Qcm9wcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC90eXBlcy9FZGl0Rm9ybSdcclxuaW1wb3J0IHsgQ29tcGFuaWVzRHJvcGRvd24gfSBmcm9tICcuLi8uLi9jb21wYW5pZXMvY29tcG9uZW50cydcclxuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdXRpbHMnXHJcbmltcG9ydCB7IGNvbnRyYWN0U2VydmljZSBhcyBzZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2Vycm9ycydcclxuaW1wb3J0IHsgQ29udHJhY3RUeXBlRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9Db250cmFjdFR5cGVFbnVtJ1xyXG5pbXBvcnQgeyBUYXhlc0VudW0gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvZW51bXMvVGF4ZXNFbnVtJ1xyXG5pbXBvcnQgVGF4ZXNSZXJjb3JkIGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQvVGF4ZXNSZWNvcmQnXHJcbmltcG9ydCB7IENvbnRyYWN0Q29uZmlndXJhdGlvbkNvbnRleHQgfSBmcm9tICcuLi9jb250ZXh0L0NvbnRyYWN0Q29uZmlndXJhdGlvblBhZ2VDb250ZXh0J1xyXG5pbXBvcnQgeyBDb250cmFjdFR5cGVEcm9wZG93biB9IGZyb20gJy4nXHJcblxyXG5pbnRlcmZhY2UgQ29udHJhY3RFZGl0Rm9ybVByb3BzIGV4dGVuZHMgRWRpdEZvcm1Qcm9wczxCYXNlQ29udHJhY3Q+e1xyXG4gIGhvcml6b250YWw/OiBib29sZWFuXHJcbiAgaXNTdWJjb250cmFjdD86IGJvb2xlYW5cclxuICBpc0VkaXRpbmc/OiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IENvbnRyYWN0RWRpdEZvcm06IEZDPENvbnRyYWN0RWRpdEZvcm1Qcm9wcz4gPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IGFwaUVycm9yLCBmb3JtRGF0YSwgb25DaGFuZ2UsIGhvcml6b250YWwgPSBmYWxzZSwgaXNTdWJjb250cmFjdCwgaXNFZGl0aW5nID0gZmFsc2UgfSA9IHByb3BzXHJcblxyXG4gIGNvbnN0IHsgY29udHJhY3QgfSA9IHVzZUNvbnRleHQoQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dClcclxuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxyXG5cclxuICBjb25zdCB7XHJcbiAgICBmb3JtRGF0YTogbG9jYWxGb3JtRGF0YSxcclxuICAgIHNldEZvcm1EYXRhOiBzZXRMb2NhbEZvcm1EYXRhLFxyXG4gICAgb25UZXh0Q2hhbmdlLFxyXG4gICAgb25OdW1iZXJDaGFuZ2UsXHJcbiAgICBvbk51bWJlclRleHRDaGFuZ2UsXHJcbiAgICBvbk11bHRpRHJvcGRvd25DaGFuZ2UsXHJcbiAgICBvbkRyb3Bkb3duQ2hhbmdlLFxyXG4gICAgb25DaGVja2JveENoYW5nZSxcclxuICAgIG9uRmllbGRFcnJvcixcclxuICAgIG9uRGlnaXRzVGV4dENoYW5nZSxcclxuICAgIG9uRGF0ZUNoYW5nZSxcclxuICB9ID0gdXNlRm9ybURhdGE8QmFzZUNvbnRyYWN0Pihmb3JtRGF0YSBhcyBCYXNlQ29udHJhY3QpXHJcblxyXG4gIGNvbnN0IHN0eWxlcyA9IGdldFN0eWxlcyhob3Jpem9udGFsLCBhcGlFcnJvcilcclxuXHJcbiAgY29uc3QgZ2V0TmV4dFByb3Bvc2FsID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGxvY2FsRm9ybURhdGEubnVtZXJvUHJvcG9zdGEgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBjb25zdCBwcm9wb3NhbCA9IGF3YWl0IHNlcnZpY2UuZ2V0TmV4dFByb3Bvc2FsKClcclxuICAgICAgc2V0TG9jYWxGb3JtRGF0YSh7XHJcbiAgICAgICAgLi4uZm9ybURhdGEgYXMgQmFzZUNvbnRyYWN0LFxyXG4gICAgICAgIG51bWVyb1Byb3Bvc3RhOiBwcm9wb3NhbC5udW1lcm9Qcm9wb3N0YSxcclxuICAgICAgfSlcclxuICAgIH1cclxuICB9LCBbbG9jYWxGb3JtRGF0YV0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZVBlcmNlbnRDaGFuZ2UgPSB1c2VDYWxsYmFjaygoXzogdW5rbm93biwgdmFsdWU/OiBudW1iZXIgfCB1bmRlZmluZWQpID0+IHtcclxuICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICBjb25zdCBmaW5hbFZhbCA9IHZhbHVlIDw9IDAgPyAwIDogdmFsdWUgPj0gMTAwID8gMTAwIDogdmFsdWVcclxuICAgICAgc2V0TG9jYWxGb3JtRGF0YShwcmV2U3RhdGUgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgICAgICBwZXJjZW50dWFsRXhpdG86IGZpbmFsVmFsLFxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlVGF4ZXMgPSB1c2VDYWxsYmFjaygoXz86IHVua25vd24sIHZhbHVlPzogSUNvbWJvQm94T3B0aW9uKSA9PiB7XHJcbiAgICBjb25zdCBvbGRTZWxlY3RlZCA9IGZvcm1EYXRhPy5pbXBvc3RvcyB8fCBbXVxyXG4gICAgbGV0IG5ld1NlbGVjdGVkOiBudW1iZXJbXSA9IFtdXHJcblxyXG4gICAgaWYgKHZhbHVlPy5rZXkgPT09IFRheGVzRW51bS5OYW9TZUFwbGljYSkge1xyXG4gICAgICBuZXdTZWxlY3RlZCA9IHZhbHVlLnNlbGVjdGVkXHJcbiAgICAgICAgPyBbdmFsdWUua2V5IGFzIG51bWJlcl1cclxuICAgICAgICA6IG9sZFNlbGVjdGVkLmZpbHRlcihpdGVtID0+IGl0ZW0gIT09IHZhbHVlLmtleSlcclxuXHJcbiAgICAgIHNldExvY2FsRm9ybURhdGEoZGF0YSA9PiAoe1xyXG4gICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgaW1wb3N0b3M6IG5ld1NlbGVjdGVkLFxyXG4gICAgICB9KSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgbmV3U2VsZWN0ZWQgPSB2YWx1ZS5zZWxlY3RlZFxyXG4gICAgICAgICAgPyBbLi4ub2xkU2VsZWN0ZWQsIHZhbHVlLmtleSBhcyBudW1iZXJdXHJcbiAgICAgICAgICA6IG9sZFNlbGVjdGVkLmZpbHRlcihpdGVtID0+IGl0ZW0gIT09IHZhbHVlLmtleSlcclxuICAgICAgfVxyXG5cclxuICAgICAgbmV3U2VsZWN0ZWQgPSBuZXdTZWxlY3RlZC5maWx0ZXIoaXRlbSA9PiBpdGVtICE9PSBUYXhlc0VudW0uTmFvU2VBcGxpY2EpXHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9jYWxGb3JtRGF0YShwcmV2U3RhdGUgPT4ge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgICBpbXBvc3RvczogbmV3U2VsZWN0ZWQsXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfSwgW2Zvcm1EYXRhPy5pbXBvc3Rvc10pXHJcblxyXG4gIGNvbnN0IGZvcm1hdFByb3Bvc2FsTWFzayA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKGxvY2FsRm9ybURhdGEubnVtZXJvUHJvcG9zdGFDb21lcmNpYWwgPT09IG51bGwpIHtcclxuICAgICAgbG9jYWxGb3JtRGF0YS5udW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCA9ICcnXHJcbiAgICB9XHJcbiAgICByZXR1cm4gbG9jYWxGb3JtRGF0YS5udW1lcm9Qcm9wb3N0YUNvbWVyY2lhbC50cmltKCkubGVuZ3RoIDwgN1xyXG4gICAgICA/ICcqKioqLSoqKidcclxuICAgICAgOiAnKioqKi0qKioqLSoqJ1xyXG4gIH0sIFtsb2NhbEZvcm1EYXRhXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGdldE5leHRQcm9wb3NhbCgpXHJcbiAgfSwgW2dldE5leHRQcm9wb3NhbF0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZm9ybURhdGEgJiYgIWlzRXF1YWwoZm9ybURhdGEsIGxvY2FsRm9ybURhdGEpKSB7XHJcbiAgICAgIHNldExvY2FsRm9ybURhdGEoZm9ybURhdGEpXHJcbiAgICB9XHJcbiAgfSwgW2Zvcm1EYXRhXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIG9uQ2hhbmdlPy4obG9jYWxGb3JtRGF0YSlcclxuICB9LCBbbG9jYWxGb3JtRGF0YV0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAobG9jYWxGb3JtRGF0YSkge1xyXG4gICAgICBpZiAoaXNTdWJjb250cmFjdCAmJiAhbG9jYWxGb3JtRGF0YS5udW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCAmJiBjb250cmFjdCkge1xyXG4gICAgICAgIG9uQ2hhbmdlPy4oe1xyXG4gICAgICAgICAgLi4ubG9jYWxGb3JtRGF0YSxcclxuICAgICAgICAgIG51bWVyb1Byb3Bvc3RhQ29tZXJjaWFsOiBjb250cmFjdC5udW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCxcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW2NvbnRyYWN0LCBpc1N1YmNvbnRyYWN0XSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZ3JpZH0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubnVtZXJvUHJvcG9zdGF9PlxyXG4gICAgICAgIDxNYXNrZWRUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiTsK6IGRvIGNvbnRyYXRvXCJcclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluc2VyaXIgbsO6bWVyb1wiXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5udW1lcm9Qcm9wb3N0YSA/PyAnJ31cclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbk51bWJlclRleHRDaGFuZ2UoJ251bWVyb1Byb3Bvc3RhJyl9XHJcbiAgICAgICAgICBtYXNrPVwiOTk5OS05OVwiXHJcbiAgICAgICAgICBtYXNrQ2hhcj1cIiBcIlxyXG4gICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBpc1N1YmNvbnRyYWN0XHJcbiAgICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ251bWVyb1Byb3Bvc3RhU3ViJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgICAgOiBvbkZpZWxkRXJyb3IoJ251bWVyb1Byb3Bvc3RhJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubnVtZXJvUHJvcG9zdGFDb21lcmNpYWx9PlxyXG4gICAgICAgIDxNYXNrZWRUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiTsK6IGRhIHByb3Bvc3RhXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSW5zZXJpciBuw7ptZXJvXCJcclxuICAgICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLm51bWVyb1Byb3Bvc3RhQ29tZXJjaWFsID8/ICcnfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uRGlnaXRzVGV4dENoYW5nZSgnbnVtZXJvUHJvcG9zdGFDb21lcmNpYWwnKX1cclxuICAgICAgICAgIG1hc2s9e2Zvcm1hdFByb3Bvc2FsTWFza31cclxuICAgICAgICAgIG1hc2tDaGFyPVwiIFwiXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdudW1lcm9Qcm9wb3N0YUNvbWVyY2lhbFN1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCdudW1lcm9Qcm9wb3N0YUNvbWVyY2lhbCcsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7aXNTdWJjb250cmFjdCAmJiAhaXNFZGl0aW5nICYmXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZ2VyYUF1ZGl0b3JpYX0+XHJcbiAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICBsYWJlbD0nR2VyYXIgcHJvamV0bydcclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdnZXJhQXVkaXRvcmlhJyl9XHJcbiAgICAgICAgICBjaGVja2VkPXtsb2NhbEZvcm1EYXRhLmdlcmFBdWRpdG9yaWF9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIH1cclxuICAgICAge2lzU3ViY29udHJhY3QgJiYgaXNFZGl0aW5nICYmXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZ2VyYUF1ZGl0b3JpYX0+XHJcbiAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICBsYWJlbD0nR2VyYXIgcHJvamV0bydcclxuICAgICAgICAgIGNoZWNrZWQ9e2xvY2FsRm9ybURhdGEuZ2VyYUF1ZGl0b3JpYX1cclxuICAgICAgICAgIGRpc2FibGVkPXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB9XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucmVzcG9uc2F2ZWxUZWNuaWNvfT5cclxuICAgICAgICA8VXNlckFzc29jaWF0ZXNEcm9wZG93blxyXG4gICAgICAgICAgbGFiZWw9XCJTw7NjaW8gcmVzcG9uc8OhdmVsIHTDqWNuaWNvXCJcclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICBmaWx0ZXJJZD17bG9jYWxGb3JtRGF0YS5yZXNwb25zYXZlbENsaWVudGVJZCBhcyBzdHJpbmd9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjaW9uYXIgc8OzY2lvXCJcclxuICAgICAgICAgIHNlbGVjdGVkS2V5PXtsb2NhbEZvcm1EYXRhLnJlc3BvbnNhdmVsVGVjbmljb0lkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uRHJvcGRvd25DaGFuZ2UoJ3Jlc3BvbnNhdmVsVGVjbmljb0lkJyl9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdyZXNwb25zYXZlbFRlY25pY29JZFN1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCdyZXNwb25zYXZlbFRlY25pY29JZCcsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnJlc3BvbnNhdmVsQ2xpZW50ZX0+XHJcbiAgICAgICAgPFVzZXJzRHJvcGRvd25cclxuICAgICAgICAgIGxhYmVsPVwiUmVzcG9uc8OhdmVsIGNsaWVudGVcIlxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIGZpbHRlcklkPXtsb2NhbEZvcm1EYXRhLnJlc3BvbnNhdmVsVGVjbmljb0lkIGFzIHN0cmluZ31cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNpb25hciByZXNwb25zw6F2ZWwgY2xpZW50ZVwiXHJcbiAgICAgICAgICBzZWxlY3RlZEtleT17bG9jYWxGb3JtRGF0YS5yZXNwb25zYXZlbENsaWVudGVJZH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbkRyb3Bkb3duQ2hhbmdlKCdyZXNwb25zYXZlbENsaWVudGVJZCcpfVxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICA/IGlzU3ViY29udHJhY3RcclxuICAgICAgICAgICAgICA/IG9uRmllbGRFcnJvcigncmVzcG9uc2F2ZWxDbGllbnRlSWRTdWInLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IG9uRmllbGRFcnJvcigncmVzcG9uc2F2ZWxDbGllbnRlSWQnLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5leGVyY2ljaW99PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiRXhlcmPDrWNpb1wiXHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeGVyY8OtY2lvXCJcclxuICAgICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLmV4ZXJjaWNpbz8udG9TdHJpbmcoKSA/PyAnJ31cclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbk51bWJlckNoYW5nZSgnZXhlcmNpY2lvJyl9XHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezR9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdleGVyY2ljaW9TdWInLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IG9uRmllbGRFcnJvcignZXhlcmNpY2lvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubWVzUmVub3ZhY2FvfT5cclxuICAgICAgICA8TW9udGhEcm9wZG93blxyXG4gICAgICAgICAgbGFiZWw9XCJNw6pzIHJlbm92YcOnw6NvXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTcOqc1wiXHJcbiAgICAgICAgICBzZWxlY3RlZEtleT17bG9jYWxGb3JtRGF0YS5tZXNSZW5vdmFjYW99XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25Ecm9wZG93bkNoYW5nZSgnbWVzUmVub3ZhY2FvJyl9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdtZXNSZW5vdmFjYW9TdWInLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IG9uRmllbGRFcnJvcignbWVzUmVub3ZhY2FvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucXRkSG9yYXN9PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPVwiUXRkLiBob3Jhc1wiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluc2VyaXIgaG9yYXNcIlxyXG4gICAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEucXRkSG9yYXM/LnRvU3RyaW5nKCkgPz8gJyd9XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25OdW1iZXJDaGFuZ2UoJ3F0ZEhvcmFzJyl9XHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezl9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCdxdGRIb3Jhc1N1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCdxdGRIb3JhcycsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnZhbG9yfT5cclxuICAgICAgICA8Q3VycmVuY3lJbnB1dFxyXG4gICAgICAgICAgbGFiZWw9XCJWYWxvclwiXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS52YWxvcn1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbk51bWJlckNoYW5nZSgndmFsb3InKX1cclxuICAgICAgICAgIG1heExlbmd0aD17MTJ9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gaXNTdWJjb250cmFjdFxyXG4gICAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCd2YWxvclN1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCd2YWxvcicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnZhbG9ySG9yYX0+XHJcbiAgICAgICAgPExhYmVsPlZhbG9yIGhvcmE8L0xhYmVsPlxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8VG9vbHRpcEhvc3RcclxuICAgICAgICAgICAgY29udGVudD17J1ZhbG9yIEhvcmEnfVxyXG4gICAgICAgICAgICBpZD0ndmFsb3ItaG9yYS1jb250cmF0by10b29sdGlwJ1xyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8VGFnIHRleHQ9e2Zvcm1hdEN1cnJlbmN5KGxvY2FsRm9ybURhdGEucXRkSG9yYXMgJiYgbG9jYWxGb3JtRGF0YS5xdGRIb3JhcyA+PSAwICYmIGxvY2FsRm9ybURhdGEudmFsb3JcclxuICAgICAgICAgICAgICA/IGxvY2FsRm9ybURhdGEudmFsb3IgLyBsb2NhbEZvcm1EYXRhLnF0ZEhvcmFzXHJcbiAgICAgICAgICAgICAgOiAwKX1cclxuXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcj17Y29sb3JzLmJsdWVbNTAwXX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvVG9vbHRpcEhvc3Q+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmVtcHJlc2FzfT5cclxuICAgICAgICB7IWhvcml6b250YWwgJiYgPENvbXBhbmllc0Ryb3Bkb3duXHJcbiAgICAgICAgICBsYWJlbD0nRW1wcmVzYSdcclxuICAgICAgICAgIG11bHRpU2VsZWN0XHJcbiAgICAgICAgICBjbGllbnRJZD17Zm9ybURhdGE/LmNsaWVudGVJZCBhcyBzdHJpbmd9XHJcbiAgICAgICAgICBzZWxlY3RlZEtleXM9e2xvY2FsRm9ybURhdGE/LmVtcHJlc2FzPy5tYXAoeCA9PiB4LmVtcHJlc2FJZCl9XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25NdWx0aURyb3Bkb3duQ2hhbmdlKCdlbXByZXNhcycsICdlbXByZXNhSWQnKX1cclxuICAgICAgICAgIGNvbnRyYWN0SWRzPXtpc1N1YmNvbnRyYWN0ID8gY29udHJhY3Q/LmVtcHJlc2FzLm1hcChjb21wYW55ID0+IGNvbXBhbnkuZW1wcmVzYUlkKSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBpc1N1YmNvbnRyYWN0XHJcbiAgICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ2VtcHJlc2FzU3ViJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgICAgOiBvbkZpZWxkRXJyb3IoJ2VtcHJlc2FzJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz59XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmRlc3Blc2FWaWFnZW19PlxyXG4gICAgICAgIDxDb21ib0JveFxyXG4gICAgICAgICAgbGFiZWw9XCJEZXNwZXNhIGRlIHZpYWdlbVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjaW9uYXJcIlxyXG4gICAgICAgICAgb3B0aW9ucz17dHJhdmVsRXhwZW5zZX1cclxuICAgICAgICAgIHNlbGVjdGVkS2V5PXtsb2NhbEZvcm1EYXRhLmRlc3Blc2FWaWFnZW19XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25Ecm9wZG93bkNoYW5nZSgnZGVzcGVzYVZpYWdlbScpfVxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICA/IGlzU3ViY29udHJhY3RcclxuICAgICAgICAgICAgICA/IG9uRmllbGRFcnJvcignZGVzcGVzYVZpYWdlbVN1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCdkZXNwZXNhVmlhZ2VtJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucGFyZWNlcn0+XHJcbiAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICBsYWJlbD0nQ29tIHBhcmVjZXInXHJcbiAgICAgICAgICBvbkNoYW5nZT17b25DaGVja2JveENoYW5nZSgnaXNQYXJlY2VyJyl9XHJcbiAgICAgICAgICBjaGVja2VkPXtsb2NhbEZvcm1EYXRhLmlzUGFyZWNlcn1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jaXJjdWxhcml6YWNhb30+XHJcbiAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICBsYWJlbD0nVGVtIGNpcmN1bGFyaXphw6fDo28nXHJcbiAgICAgICAgICBvbkNoYW5nZT17b25DaGVja2JveENoYW5nZSgnaXNDaXJjdWxhcml6YWNhbycpfVxyXG4gICAgICAgICAgY2hlY2tlZD17bG9jYWxGb3JtRGF0YS5pc0NpcmN1bGFyaXphY2FvfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmludmVudGFyaW99PlxyXG4gICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgbGFiZWw9J1RlbSBpbnZlbnTDoXJpbydcclxuICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoZWNrYm94Q2hhbmdlKCdpc0ludmVudGFyaW8nKX1cclxuICAgICAgICAgIGNoZWNrZWQ9e2xvY2FsRm9ybURhdGEuaXNJbnZlbnRhcmlvfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm9ic2VydmFjYW99PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIGxhYmVsPXtgRGVzY3Jpw6fDo28gJHtsb2NhbEZvcm1EYXRhLmRlc3Blc2FWaWFnZW0gPT09IDIgPyAnJyA6ICcob3BjaW9uYWwpJ31gfVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbnNlcmlyIGRlc2NyacOnw6NvIGRvIGNvbnRyYXRvXCJcclxuICAgICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLm9ic2VydmFjYW99XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25UZXh0Q2hhbmdlKCdvYnNlcnZhY2FvJyl9XHJcbiAgICAgICAgICBtdWx0aWxpbmVcclxuICAgICAgICAgIHJvd3M9e2FwaUVycm9yID8gMTIgOiAxMCB9XHJcbiAgICAgICAgICByZXNpemFibGU9e2ZhbHNlfVxyXG4gICAgICAgICAgbWF4TGVuZ3RoPXsxMjUwfVxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICA/IGlzU3ViY29udHJhY3RcclxuICAgICAgICAgICAgICA/IG9uRmllbGRFcnJvcignb2JzZXJ2YWNhb1N1YicsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICAgIDogb25GaWVsZEVycm9yKCdvYnNlcnZhY2FvJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudGlwb0NvbnRyYXRvfT5cclxuICAgICAgICA8Q29udHJhY3RUeXBlRHJvcGRvd25cclxuICAgICAgICAgIHNlbGVjdGVkS2V5PXtmb3JtRGF0YT8udGlwb0NvbnRyYXRvIGFzIENvbnRyYWN0VHlwZUVudW19XHJcbiAgICAgICAgICBvbkNoYW5nZT17b25Ecm9wZG93bkNoYW5nZSgndGlwb0NvbnRyYXRvJyl9XHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2U9e2FwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzXHJcbiAgICAgICAgICAgID8gb25GaWVsZEVycm9yKCd0aXBvQ29udHJhdG8nLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuaW1wb3N0b3N9PlxyXG4gICAgICAgIDxDb21ib0JveFxyXG4gICAgICAgICAgbGFiZWw9J0ltcG9zdG9zJ1xyXG4gICAgICAgICAgbXVsdGlTZWxlY3RcclxuICAgICAgICAgIGFsbG93RnJlZWZvcm09e3RydWV9XHJcbiAgICAgICAgICBhdXRvQ29tcGxldGU9J29uJ1xyXG4gICAgICAgICAgb3B0aW9ucz17dGF4ZXNPcHRpb25zfVxyXG4gICAgICAgICAgc2VsZWN0ZWRLZXk9e2Zvcm1EYXRhPy5pbXBvc3Rvc31cclxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2VUYXhlc31cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ3RpcG9Db250cmF0bycsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmluaWNpb0NvbnRyYXRvfT5cclxuICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgbGFiZWw9J0luw61jaW8gZG8gY29udHJhdG8nXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5kYXRhSW5pY2lvID8gbmV3IERhdGUobG9jYWxGb3JtRGF0YS5kYXRhSW5pY2lvKSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIGFsbG93VGV4dElucHV0XHJcbiAgICAgICAgICBvblNlbGVjdERhdGU9e29uRGF0ZUNoYW5nZSgnZGF0YUluaWNpbycpfVxyXG4gICAgICAgICAgZm9ybWF0U3RyaW5nPXsnZGQvTU0veXl5eSd9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZmluYWxDb250cmF0b30+XHJcbiAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgIGxhYmVsPSdGaW0gZG8gY29udHJhdG8nXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5kYXRhRmltID8gbmV3IERhdGUobG9jYWxGb3JtRGF0YS5kYXRhRmltKSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIGFsbG93VGV4dElucHV0XHJcbiAgICAgICAgICBvblNlbGVjdERhdGU9e29uRGF0ZUNoYW5nZSgnZGF0YUZpbScpfVxyXG4gICAgICAgICAgZm9ybWF0U3RyaW5nPXsnZGQvTU0veXl5eSd9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucGVyY2VudHVhbEV4aXRvfT5cclxuICAgICAgICA8TnVtYmVySW5wdXRcclxuICAgICAgICAgIGxhYmVsPSdQZXJjZW50dWFsIGRlIMOqeGl0bydcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPSclJ1xyXG4gICAgICAgICAgdmFsdWU9e2xvY2FsRm9ybURhdGEucGVyY2VudHVhbEV4aXRvICE9PSBudWxsID8gbG9jYWxGb3JtRGF0YS5wZXJjZW50dWFsRXhpdG8gOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezN9XHJcbiAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGVyY2VudENoYW5nZX1cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ3BlcmNlbnR1YWxFeGl0bycsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YXRvQ2xpZW50ZX0+XHJcbiAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgbWF4TGVuZ3RoPXsxMDB9XHJcbiAgICAgICAgICBsYWJlbD0nTm9tZSBkbyBjb250YXRvIG5vIGNsaWVudGUnXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5ub21lUmVzcG9uc2F2ZWxDbGllbnRlIHx8ICcnfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnbm9tZVJlc3BvbnNhdmVsQ2xpZW50ZScpfVxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlPXthcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlc1xyXG4gICAgICAgICAgICA/IG9uRmllbGRFcnJvcignbm9tZVJlc3BvbnNhdmVsQ2xpZW50ZScsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhdG9FbWFpbH0+XHJcbiAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgbGFiZWw9J0UtbWFpbCBkbyBjb250YXRvIG5vIGNsaWVudGUnXHJcbiAgICAgICAgICB2YWx1ZT17bG9jYWxGb3JtRGF0YS5lbWFpbFJlc3BvbnNhdmVsQ2xpZW50ZSB8fCAnJ31cclxuICAgICAgICAgIG1heExlbmd0aD17NDUwfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uVGV4dENoYW5nZSgnZW1haWxSZXNwb25zYXZlbENsaWVudGUnKX1cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ2VtYWlsUmVzcG9uc2F2ZWxDbGllbnRlJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGF0b1RlbGVmb25lfT5cclxuICAgICAgICA8UGhvbmVJbnB1dFxyXG4gICAgICAgICAgbGFiZWw9J1RlbGVmb25lIGRvIGNvbnRhdG8gbm8gY2xpZW50ZSdcclxuICAgICAgICAgIHZhbHVlPXtsb2NhbEZvcm1EYXRhLnRlbGVmb25lUmVzcG9uc2F2ZWxDbGllbnRlIHx8ICcnfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uTnVtYmVyVGV4dENoYW5nZSgndGVsZWZvbmVSZXNwb25zYXZlbENsaWVudGUnKX1cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ3RlbGVmb25lUmVzcG9uc2F2ZWxDbGllbnRlJywgYXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXMpXHJcbiAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucmVzcG9uc2F2ZWxDb21lcmNpYWx9PlxyXG4gICAgICAgIDxVc2Vyc0Ryb3Bkb3duXHJcbiAgICAgICAgICBsYWJlbD1cIkNvbnRhdG8gY29tZXJjaWFsXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNpb25hciBjb250YXRvIGNvbWVyY2lhbFwiXHJcbiAgICAgICAgICBzZWxlY3RlZEtleT17bG9jYWxGb3JtRGF0YS5yZXNwb25zYXZlbENvbWVyY2lhbElkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e29uRHJvcGRvd25DaGFuZ2UoJ3Jlc3BvbnNhdmVsQ29tZXJjaWFsSWQnKX1cclxuICAgICAgICAgIGVycm9yTWVzc2FnZT17YXBpRXJyb3I/LmVycm9ycz8ubWVzc2FnZXNcclxuICAgICAgICAgICAgPyBpc1N1YmNvbnRyYWN0XHJcbiAgICAgICAgICAgICAgPyBvbkZpZWxkRXJyb3IoJ3Jlc3BvbnNhdmVsQ29tZXJjaWFsSWRTdWInLCBhcGlFcnJvcj8uZXJyb3JzPy5tZXNzYWdlcylcclxuICAgICAgICAgICAgICA6IG9uRmllbGRFcnJvcigncmVzcG9uc2F2ZWxDb21lcmNpYWxJZCcsIGFwaUVycm9yPy5lcnJvcnM/Lm1lc3NhZ2VzKVxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB0cmF2ZWxFeHBlbnNlOiBJRHJvcGRvd25PcHRpb25bXSA9IFtcclxuICB7IGtleTogMCwgdGV4dDogJ07Do28nIH0sXHJcbiAgeyBrZXk6IDEsIHRleHQ6ICdTaW0nIH0sXHJcbiAgeyBrZXk6IDIsIHRleHQ6ICdTaW0vUGFyY2lhbCcgfSxcclxuXVxyXG5cclxuY29uc3QgdGF4ZXNPcHRpb25zOiBJQ29tYm9Cb3hPcHRpb25bXSA9IFtcclxuICB7XHJcbiAgICBrZXk6IFRheGVzRW51bS5JUEksXHJcbiAgICB0ZXh0OiBUYXhlc1JlcmNvcmRbVGF4ZXNFbnVtLklQSV0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFRheGVzRW51bS5QSVMsXHJcbiAgICB0ZXh0OiBUYXhlc1JlcmNvcmRbVGF4ZXNFbnVtLlBJU10sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFRheGVzRW51bS5DT0ZJTlMsXHJcbiAgICB0ZXh0OiBUYXhlc1JlcmNvcmRbVGF4ZXNFbnVtLkNPRklOU10sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFRheGVzRW51bS5JQ01TLFxyXG4gICAgdGV4dDogVGF4ZXNSZXJjb3JkW1RheGVzRW51bS5JQ01TXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogVGF4ZXNFbnVtLklDTVNTVCxcclxuICAgIHRleHQ6IFRheGVzUmVyY29yZFtUYXhlc0VudW0uSUNNU1NUXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogVGF4ZXNFbnVtLklSUEosXHJcbiAgICB0ZXh0OiBUYXhlc1JlcmNvcmRbVGF4ZXNFbnVtLklSUEpdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAga2V5OiBUYXhlc0VudW0uQ1NMTCxcclxuICAgIHRleHQ6IFRheGVzUmVyY29yZFtUYXhlc0VudW0uQ1NMTF0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFRheGVzRW51bS5JTlNTLFxyXG4gICAgdGV4dDogVGF4ZXNSZXJjb3JkW1RheGVzRW51bS5JTlNTXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogVGF4ZXNFbnVtLk5hb1NlQXBsaWNhLFxyXG4gICAgdGV4dDogVGF4ZXNSZXJjb3JkW1RheGVzRW51bS5OYW9TZUFwbGljYV0sXHJcbiAgfSxcclxuXVxyXG5cclxuY29uc3QgZ2V0U3R5bGVzID0gKGhvcml6b250YWw6IGJvb2xlYW4sIGFwaUVycm9yPzogQXBpRXJyb3IpID0+IG1lcmdlU3R5bGVTZXRzKHtcclxuICBncmlkOiB7XHJcbiAgICBkaXNwbGF5OiAnZ3JpZCcsXHJcbiAgICBnYXA6ICcxMnB4IDE2cHgnLFxyXG4gICAgYWxpZ25JdGVtczogJ3N0YXJ0JyxcclxuICAgIGFsaWduQ29udGVudDogJ2NlbnRlcicsXHJcbiAgICBncmlkVGVtcGxhdGU6IGhvcml6b250YWxcclxuICAgICAgPyBgXHJcbiAgICAgIFwibiBuYyB0aSBpbSBkaSBkZlwiIGF1dG9cclxuICAgICAgXCJlIHEgdiBjaSBwYSAuXCIgYXV0b1xyXG4gICAgICBcIm0gZCBoIHBlIGluIC5cIiBhdXRvXHJcbiAgICAgIFwidCB0IGMgYyBjYyBjY1wiIGF1dG9cclxuICAgICAgXCJjbSBjbSBjdCBjdCByYyByY1wiIGF1dG9cclxuICAgICAgXCJvIG8gbyBvIG8gb1wiIGF1dG8gLyAxZnIgMWZyIDFmciAxZnIgMWZyIDFmclxyXG4gICAgICBgXHJcbiAgICAgIDogYFxyXG4gICAgICBcIm4gbiBuYyBuY1wiIGF1dG9cclxuICAgICAgXCJnYSBnYSAuIC5cIiBhdXRvXHJcbiAgICAgIFwidGkgdGkgdGkgdGlcIiBhdXRvXHJcbiAgICAgIFwiaW0gaW0gaW0gaW1cIiBhdXRvXHJcbiAgICAgIFwidCB0IHQgdFwiIGF1dG9cclxuICAgICAgXCJjIGMgYyBjXCIgYXV0b1xyXG4gICAgICBcImRpIGRpIGRmIGRmXCIgYXV0b1xyXG4gICAgICBcImUgZSBtIG1cIiBhdXRvXHJcbiAgICAgIFwicSB2IGggaFwiIGF1dG9cclxuICAgICAgXCJwZSBwZSAuIC5cIiBhdXRvXHJcbiAgICAgIFwiZW0gZW0gZW0gZW1cIiBhdXRvXHJcbiAgICAgIFwiZCBkIGQgZFwiIGF1dG9cclxuICAgICAgXCJwYSBwYSBwYSBwYVwiIGF1dG9cclxuICAgICAgXCJjaSBjaSBjaSBjaVwiIGF1dG9cclxuICAgICAgXCJpbiBpbiBpbiBpblwiIGF1dG9cclxuICAgICAgXCJjYyBjYyBjYyBjY1wiIGF1dG9cclxuICAgICAgXCJjbSBjbSBjdCBjdFwiIGF1dG9cclxuICAgICAgXCJyYyByYyByYyByY1wiIGF1dG9cclxuICAgICAgXCJvIG8gbyBvXCIgYXV0byAvIDFmciAxZnIgMWZyIDFmclxyXG4gICAgICBgLFxyXG4gIH0sXHJcbiAgbnVtZXJvUHJvcG9zdGE6IHsgZ3JpZEFyZWE6ICduJywgaGVpZ2h0OiBob3Jpem9udGFsICYmIGFwaUVycm9yICYmIDgzIH0sXHJcbiAgbnVtZXJvUHJvcG9zdGFDb21lcmNpYWw6IHsgZ3JpZEFyZWE6ICduYycsIGhlaWdodDogaG9yaXpvbnRhbCAmJiBhcGlFcnJvciAmJiA4MyB9LFxyXG4gIHJlc3BvbnNhdmVsVGVjbmljbzogeyBncmlkQXJlYTogJ3QnLCBoZWlnaHQ6IGFwaUVycm9yICYmIDgzIH0sXHJcbiAgcmVzcG9uc2F2ZWxDbGllbnRlOiB7IGdyaWRBcmVhOiAnYycgfSxcclxuICByZXNwb25zYXZlbENvbWVyY2lhbDogeyBncmlkQXJlYTogJ3JjJyB9LFxyXG4gIGV4ZXJjaWNpbzogeyBncmlkQXJlYTogJ2UnLCBoZWlnaHQ6IGFwaUVycm9yICYmIDgzIH0sXHJcbiAgbWVzUmVub3ZhY2FvOiB7IGdyaWRBcmVhOiAnbScsIGhlaWdodDogYXBpRXJyb3IgJiYgODMgfSxcclxuICBxdGRIb3JhczogeyBncmlkQXJlYTogJ3EnLCBoZWlnaHQ6IGFwaUVycm9yICYmIDgzIH0sXHJcbiAgdmFsb3I6IHsgZ3JpZEFyZWE6ICd2JywgaGVpZ2h0OiBhcGlFcnJvciAmJiA4MyB9LFxyXG4gIHZhbG9ySG9yYTogeyBncmlkQXJlYTogJ2gnIH0sXHJcbiAgdGlwb0NvbnRyYXRvOiB7IGdyaWRBcmVhOiAndGknIH0sXHJcbiAgaW1wb3N0b3M6IHsgZ3JpZEFyZWE6ICdpbScgfSxcclxuICBpbmljaW9Db250cmF0bzogeyBncmlkQXJlYTogJ2RpJyB9LFxyXG4gIGZpbmFsQ29udHJhdG86IHsgZ3JpZEFyZWE6ICdkZicgfSxcclxuICBwZXJjZW50dWFsRXhpdG86IHsgZ3JpZEFyZWE6ICdwZScgfSxcclxuICBjb250YXRvQ2xpZW50ZTogeyBncmlkQXJlYTogJ2NjJyB9LFxyXG4gIGNvbnRhdG9FbWFpbDogeyBncmlkQXJlYTogJ2NtJyB9LFxyXG4gIGNvbnRhdG9UZWxlZm9uZTogeyBncmlkQXJlYTogJ2N0JyB9LFxyXG4gIGRlc3Blc2FWaWFnZW06IHsgZ3JpZEFyZWE6ICdkJyB9LFxyXG4gIHBhcmVjZXI6IHsgZ3JpZEFyZWE6ICdwYScsIG1hcmdpblRvcDogaG9yaXpvbnRhbCAmJiAzNCB9LFxyXG4gIGNpcmN1bGFyaXphY2FvOiB7IGdyaWRBcmVhOiAnY2knLCBtYXJnaW5Ub3A6IGhvcml6b250YWwgJiYgMzQgfSxcclxuICBpbnZlbnRhcmlvOiB7IGdyaWRBcmVhOiAnaW4nLCBtYXJnaW5Ub3A6IGhvcml6b250YWwgJiYgMzQgfSxcclxuICBvYnNlcnZhY2FvOiB7IGdyaWRBcmVhOiAnbycgfSxcclxuICBlbXByZXNhczogeyBncmlkQXJlYTogJ2VtJyB9LFxyXG4gIGdlcmFBdWRpdG9yaWE6IHsgZ3JpZEFyZWE6ICdnYScgfSxcclxufSlcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0RWRpdEZvcm1cclxuIl19