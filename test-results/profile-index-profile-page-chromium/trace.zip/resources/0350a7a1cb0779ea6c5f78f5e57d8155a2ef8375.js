export var ComplexityEnum = /* @__PURE__ */ ((ComplexityEnum2) => {
  ComplexityEnum2[ComplexityEnum2["INEXISTENTE"] = 0] = "INEXISTENTE";
  ComplexityEnum2[ComplexityEnum2["BAIXA"] = 1] = "BAIXA";
  ComplexityEnum2[ComplexityEnum2["MEDIA"] = 2] = "MEDIA";
  ComplexityEnum2[ComplexityEnum2["ALTA"] = 3] = "ALTA";
  return ComplexityEnum2;
})(ComplexityEnum || {});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNvbXBsZXhpdHlFbnVtLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmV4cG9ydCBlbnVtIENvbXBsZXhpdHlFbnVtIHtcclxuICBJTkVYSVNURU5URSA9IDAsXHJcbiAgQkFJWEEgPSAxLFxyXG4gIE1FRElBID0gMixcclxuICBBTFRBID0gMyxcclxufVxyXG4iXSwibWFwcGluZ3MiOiJBQUNPLFdBQUssaUJBQUwsa0JBQUtBLG9CQUFMO0FBQ0wsRUFBQUEsZ0NBQUEsaUJBQWMsS0FBZDtBQUNBLEVBQUFBLGdDQUFBLFdBQVEsS0FBUjtBQUNBLEVBQUFBLGdDQUFBLFdBQVEsS0FBUjtBQUNBLEVBQUFBLGdDQUFBLFVBQU8sS0FBUDtBQUpVLFNBQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6WyJDb21wbGV4aXR5RW51bSJdfQ==