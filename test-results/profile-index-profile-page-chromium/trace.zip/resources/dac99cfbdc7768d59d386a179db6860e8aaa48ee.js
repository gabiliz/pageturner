import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractConfigurationActions.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { ContractConfigurationContext } from "/src/modules/admin/contracts/context/ContractConfigurationPageContext.ts";
import { PrimaryButton, DefaultButton, FlexRow, CommandButton } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { useAuth } from "/src/modules/auth/store/auth.ts";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { StepsContractDetailDrawer } from "/src/modules/admin/backlogMonitor/components/index.ts?t=1701096626433";
const ContractConfigurationControls = () => {
  _s();
  const {
    isEditing,
    isSaving,
    startEditing,
    contract,
    stopEditing,
    cancelChanges,
    saveChanges,
    closeConfiguration
  } = useContext(ContractConfigurationContext);
  const theme = useTheme();
  const {
    hasPermission
  } = usePermissions();
  const {
    currentAccount
  } = useAuth();
  const [isStepOneDrawerOpen, {
    setTrue: openStepOneDrawer,
    setFalse: closeStepOneDrawer
  }] = useBoolean(false);
  const handleSave = useCallback(async () => {
    await saveChanges();
    stopEditing();
  }, [saveChanges, stopEditing]);
  return /* @__PURE__ */ jsxDEV(FlexRow, { gap: theme.spacing.lg, children: [
    isEditing && /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Cancelar", onClick: cancelChanges, disabled: isSaving, styles: {
      root: {
        border: "none"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 38,
      columnNumber: 21
    }, this),
    !isEditing && /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Voltar", onClick: closeConfiguration, styles: {
      root: {
        border: "none"
      }
    } }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 43,
      columnNumber: 22
    }, this),
    !isEditing && hasPermission("Contrato", "Alterar") && /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Alterar", onClick: startEditing }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 48,
      columnNumber: 62
    }, this),
    isEditing && /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Salvar", onClick: handleSave, disabled: isSaving }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 49,
      columnNumber: 21
    }, this),
    contract?.situacao === 0 && contract.responsavelTecnico?.id === currentAccount.value?.id && /* @__PURE__ */ jsxDEV(CommandButton, { text: "Aprovar contrato", onClick: openStepOneDrawer }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 50,
      columnNumber: 112
    }, this),
    isStepOneDrawerOpen && /* @__PURE__ */ jsxDEV(StepsContractDetailDrawer, { isOpen: isStepOneDrawerOpen, onDismiss: closeStepOneDrawer, contractId: contract?.id }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
      lineNumber: 51,
      columnNumber: 31
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx",
    lineNumber: 37,
    columnNumber: 10
  }, this);
};
_s(ContractConfigurationControls, "DnSjrINF4DwbPmsQw4623oDDwpg=", false, function() {
  return [useTheme, usePermissions, useAuth, useBoolean];
});
_c = ContractConfigurationControls;
export default ContractConfigurationControls;
var _c;
$RefreshReg$(_c, "ContractConfigurationControls");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNROzs7Ozs7Ozs7Ozs7Ozs7O0FBdkNSLFNBQWFBLFlBQVlDLG1CQUFtQjtBQUM1QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msb0NBQW9DO0FBQzdDLFNBQVNDLGVBQWVDLGVBQWVDLFNBQVNDLHFCQUFxQjtBQUNyRSxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUNBQWlDO0FBRTFDLE1BQU1DLGdDQUFvQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzlDLFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlyQixXQUFXRyw0QkFBNEI7QUFFM0MsUUFBTW1CLFFBQVFkLFNBQVM7QUFDdkIsUUFBTTtBQUFBLElBQUVlO0FBQUFBLEVBQWMsSUFBSXJCLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVzQjtBQUFBQSxFQUFlLElBQUlmLFFBQVE7QUFDbkMsUUFBTSxDQUNKZ0IscUJBQ0E7QUFBQSxJQUFFQyxTQUFTQztBQUFBQSxJQUFtQkMsVUFBVUM7QUFBQUEsRUFBbUIsQ0FBQyxJQUMxRG5CLFdBQVcsS0FBSztBQUVwQixRQUFNb0IsYUFBYTdCLFlBQVksWUFBWTtBQUN6QyxVQUFNbUIsWUFBWTtBQUNsQkYsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ0UsYUFBYUYsV0FBVyxDQUFDO0FBRTdCLFNBQ0UsdUJBQUMsV0FDQyxLQUFNSSxNQUFNUyxRQUFRQyxJQUVuQmxCO0FBQUFBLGlCQUNDLHVCQUFDLGlCQUNDLE1BQUssWUFDTCxTQUFTSyxlQUNULFVBQVVKLFVBQ1YsUUFBUTtBQUFBLE1BQ05rQixNQUFNO0FBQUEsUUFDSkMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFJO0FBQUEsSUFHTCxDQUFDcEIsYUFDQSx1QkFBQyxpQkFDQyxNQUFLLFVBQ0wsU0FBU08sb0JBQ1QsUUFBUTtBQUFBLE1BQ05ZLE1BQU07QUFBQSxRQUNKQyxRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0YsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0k7QUFBQSxJQUdMLENBQUNwQixhQUFhUyxjQUFjLFlBQVksU0FBUyxLQUNoRCx1QkFBQyxpQkFDQyxNQUFLLFdBQ0wsU0FBU1AsZ0JBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUV3QjtBQUFBLElBR3pCRixhQUNDLHVCQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTZ0IsWUFDVCxVQUFVZixZQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHcUI7QUFBQSxJQUd0QkUsVUFBVWtCLGFBQWEsS0FDdkJsQixTQUFTbUIsb0JBQW9CQyxPQUFrQmIsZUFBZWMsT0FBT0QsTUFDcEUsdUJBQUMsaUJBQWMsTUFBSyxvQkFDbEIsU0FBU1YscUJBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUM2QjtBQUFBLElBRTlCRix1QkFBdUIsdUJBQUMsNkJBQ3ZCLFFBQVFBLHFCQUNSLFdBQVdJLG9CQUNYLFlBQVlaLFVBQVVvQixNQUhBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHYTtBQUFBLE9BL0N2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaURBO0FBRUo7QUFBQ3hCLEdBN0VLRCwrQkFBaUM7QUFBQSxVQVl2QkosVUFDWU4sZ0JBQ0NPLFNBSXZCQyxVQUFVO0FBQUE7QUFBQTZCLEtBbEJWM0I7QUErRU4sZUFBZUE7QUFBNkIsSUFBQTJCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VQZXJtaXNzaW9ucyIsIkNvbnRyYWN0Q29uZmlndXJhdGlvbkNvbnRleHQiLCJQcmltYXJ5QnV0dG9uIiwiRGVmYXVsdEJ1dHRvbiIsIkZsZXhSb3ciLCJDb21tYW5kQnV0dG9uIiwidXNlVGhlbWUiLCJ1c2VBdXRoIiwidXNlQm9vbGVhbiIsIlN0ZXBzQ29udHJhY3REZXRhaWxEcmF3ZXIiLCJDb250cmFjdENvbmZpZ3VyYXRpb25Db250cm9scyIsIl9zIiwiaXNFZGl0aW5nIiwiaXNTYXZpbmciLCJzdGFydEVkaXRpbmciLCJjb250cmFjdCIsInN0b3BFZGl0aW5nIiwiY2FuY2VsQ2hhbmdlcyIsInNhdmVDaGFuZ2VzIiwiY2xvc2VDb25maWd1cmF0aW9uIiwidGhlbWUiLCJoYXNQZXJtaXNzaW9uIiwiY3VycmVudEFjY291bnQiLCJpc1N0ZXBPbmVEcmF3ZXJPcGVuIiwic2V0VHJ1ZSIsIm9wZW5TdGVwT25lRHJhd2VyIiwic2V0RmFsc2UiLCJjbG9zZVN0ZXBPbmVEcmF3ZXIiLCJoYW5kbGVTYXZlIiwic3BhY2luZyIsImxnIiwicm9vdCIsImJvcmRlciIsInNpdHVhY2FvIiwicmVzcG9uc2F2ZWxUZWNuaWNvIiwiaWQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJhY3RDb25maWd1cmF0aW9uQWN0aW9ucy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0Q29uZmlndXJhdGlvbkFjdGlvbnMudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNvbnRleHQsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2F1dGgvaG9va3MvcGVybWlzc2lvbnMnXG5pbXBvcnQgeyBDb250cmFjdENvbmZpZ3VyYXRpb25Db250ZXh0IH0gZnJvbSAnLi4vY29udGV4dC9Db250cmFjdENvbmZpZ3VyYXRpb25QYWdlQ29udGV4dCdcbmltcG9ydCB7IFByaW1hcnlCdXR0b24sIERlZmF1bHRCdXR0b24sIEZsZXhSb3csIENvbW1hbmRCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2F1dGgvc3RvcmUvYXV0aCdcbmltcG9ydCB7IHVzZUJvb2xlYW4gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QtaG9va3MnXG5pbXBvcnQgeyBTdGVwc0NvbnRyYWN0RGV0YWlsRHJhd2VyIH0gZnJvbSAnLi4vLi4vYmFja2xvZ01vbml0b3IvY29tcG9uZW50cydcblxuY29uc3QgQ29udHJhY3RDb25maWd1cmF0aW9uQ29udHJvbHM6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7XG4gICAgaXNFZGl0aW5nLFxuICAgIGlzU2F2aW5nLFxuICAgIHN0YXJ0RWRpdGluZyxcbiAgICBjb250cmFjdCxcbiAgICBzdG9wRWRpdGluZyxcbiAgICBjYW5jZWxDaGFuZ2VzLFxuICAgIHNhdmVDaGFuZ2VzLFxuICAgIGNsb3NlQ29uZmlndXJhdGlvbixcbiAgfSA9IHVzZUNvbnRleHQoQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dClcblxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXG4gIGNvbnN0IHsgY3VycmVudEFjY291bnQgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbXG4gICAgaXNTdGVwT25lRHJhd2VyT3BlbixcbiAgICB7IHNldFRydWU6IG9wZW5TdGVwT25lRHJhd2VyLCBzZXRGYWxzZTogY2xvc2VTdGVwT25lRHJhd2VyIH0sXG4gIF0gPSB1c2VCb29sZWFuKGZhbHNlKVxuXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgc2F2ZUNoYW5nZXMoKVxuICAgIHN0b3BFZGl0aW5nKClcbiAgfSwgW3NhdmVDaGFuZ2VzLCBzdG9wRWRpdGluZ10pXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleFJvd1xuICAgICAgZ2FwPXsgdGhlbWUuc3BhY2luZy5sZyB9XG4gICAgPlxuICAgICAge2lzRWRpdGluZyAmJiAoXG4gICAgICAgIDxEZWZhdWx0QnV0dG9uXG4gICAgICAgICAgdGV4dD1cIkNhbmNlbGFyXCJcbiAgICAgICAgICBvbkNsaWNrPXtjYW5jZWxDaGFuZ2VzfVxuICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZ31cbiAgICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgICAgeyFpc0VkaXRpbmcgJiYgKFxuICAgICAgICA8RGVmYXVsdEJ1dHRvblxuICAgICAgICAgIHRleHQ9XCJWb2x0YXJcIlxuICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlQ29uZmlndXJhdGlvbn1cbiAgICAgICAgICBzdHlsZXM9e3tcbiAgICAgICAgICAgIHJvb3Q6IHtcbiAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgICAgeyFpc0VkaXRpbmcgJiYgaGFzUGVybWlzc2lvbignQ29udHJhdG8nLCAnQWx0ZXJhcicpICYmIChcbiAgICAgICAgPFByaW1hcnlCdXR0b25cbiAgICAgICAgICB0ZXh0PVwiQWx0ZXJhclwiXG4gICAgICAgICAgb25DbGljaz17c3RhcnRFZGl0aW5nfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICAgIHtpc0VkaXRpbmcgJiYgKFxuICAgICAgICA8UHJpbWFyeUJ1dHRvblxuICAgICAgICAgIHRleHQ9XCJTYWx2YXJcIlxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICAgIHtjb250cmFjdD8uc2l0dWFjYW8gPT09IDAgJiZcbiAgICAgIChjb250cmFjdC5yZXNwb25zYXZlbFRlY25pY28/LmlkIGFzIHN0cmluZykgPT09IGN1cnJlbnRBY2NvdW50LnZhbHVlPy5pZCAmJlxuICAgICAgICA8Q29tbWFuZEJ1dHRvbiB0ZXh0PSdBcHJvdmFyIGNvbnRyYXRvJ1xuICAgICAgICAgIG9uQ2xpY2s9e29wZW5TdGVwT25lRHJhd2VyfS8+XG4gICAgICB9XG4gICAgICB7aXNTdGVwT25lRHJhd2VyT3BlbiAmJiA8U3RlcHNDb250cmFjdERldGFpbERyYXdlclxuICAgICAgICBpc09wZW49e2lzU3RlcE9uZURyYXdlck9wZW59XG4gICAgICAgIG9uRGlzbWlzcz17Y2xvc2VTdGVwT25lRHJhd2VyfVxuICAgICAgICBjb250cmFjdElkPXtjb250cmFjdD8uaWQgYXMgc3RyaW5nfVxuICAgICAgLz59XG4gICAgPC9GbGV4Um93PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0Q29uZmlndXJhdGlvbkNvbnRyb2xzXG4iXX0=