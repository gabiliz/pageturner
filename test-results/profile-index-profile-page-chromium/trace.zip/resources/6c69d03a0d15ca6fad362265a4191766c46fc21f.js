import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/emptyState/PageUnderConstruction.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Image, Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { FlexColumn, FlexItem, FlexRow } from "/src/shared/components/FlexBox/index.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
const PageUnderConstruction = () => {
  _s();
  const {
    colors
  } = useTheme();
  return /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", horizontalAlign: "center", margin: "50px 0 0 0", grow: 1, height: "100%", width: "100%", children: /* @__PURE__ */ jsxDEV(FlexColumn, { verticalAlign: "center", horizontalAlign: "center", gap: 20, width: 300, children: [
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(Image, { src: "/construcao.svg" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
      lineNumber: 14,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
      lineNumber: 13,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(FlexItem, { children: /* @__PURE__ */ jsxDEV(Text, { variant: "large", style: {
      color: colors.gray[600]
    }, children: "Página em construção" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
      lineNumber: 17,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
    lineNumber: 12,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
};
_s(PageUnderConstruction, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
_c = PageUnderConstruction;
export default PageUnderConstruction;
var _c;
$RefreshReg$(_c, "PageUnderConstruction");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/emptyState/PageUnderConstruction.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkJWLFNBQVNBLE9BQU9DLFlBQVk7QUFDNUIsU0FBU0MsWUFBWUMsVUFBVUMsZUFBZTtBQUM5QyxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsd0JBQTRCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU8sSUFBSUgsU0FBUztBQUM1QixTQUVFLHVCQUFDLFdBQ0MsZUFBYyxVQUNkLGlCQUFnQixVQUNoQixRQUFPLGNBQ1AsTUFBTSxHQUNOLFFBQU8sUUFDUCxPQUFNLFFBRU4saUNBQUMsY0FDQyxlQUFjLFVBQ2QsaUJBQWdCLFVBQ2hCLEtBQU0sSUFDTixPQUFPLEtBRVA7QUFBQSwyQkFBQyxZQUNDLGlDQUFDLFNBQU0sS0FBSSxxQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsWUFDQyxpQ0FBQyxRQUNDLFNBQVEsU0FDUixPQUFPO0FBQUEsTUFBRUksT0FBT0QsT0FBT0UsS0FBSyxHQUFHO0FBQUEsSUFBRSxHQUFFLG9DQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBLEtBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFDSCxHQWhDS0QsdUJBQXlCO0FBQUEsVUFDVkQsUUFBUTtBQUFBO0FBQUFNLEtBRHZCTDtBQWtDTixlQUFlQTtBQUFxQixJQUFBSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiSW1hZ2UiLCJUZXh0IiwiRmxleENvbHVtbiIsIkZsZXhJdGVtIiwiRmxleFJvdyIsInVzZVRoZW1lIiwiUGFnZVVuZGVyQ29uc3RydWN0aW9uIiwiX3MiLCJjb2xvcnMiLCJjb2xvciIsImdyYXkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2VVbmRlckNvbnN0cnVjdGlvbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9lbXB0eVN0YXRlL1BhZ2VVbmRlckNvbnN0cnVjdGlvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSW1hZ2UsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGbGV4Q29sdW1uLCBGbGV4SXRlbSwgRmxleFJvdyB9IGZyb20gJy4uL0ZsZXhCb3gnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uLy4uL2hvb2tzJ1xuXG5jb25zdCBQYWdlVW5kZXJDb25zdHJ1Y3Rpb246IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNvbG9ycyB9ID0gdXNlVGhlbWUoKVxuICByZXR1cm4gKFxuXG4gICAgPEZsZXhSb3dcbiAgICAgIHZlcnRpY2FsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgaG9yaXpvbnRhbEFsaWduPVwiY2VudGVyXCJcbiAgICAgIG1hcmdpbj1cIjUwcHggMCAwIDBcIlxuICAgICAgZ3Jvdz17MX1cbiAgICAgIGhlaWdodD0nMTAwJSdcbiAgICAgIHdpZHRoPScxMDAlJ1xuICAgID5cbiAgICAgIDxGbGV4Q29sdW1uXG4gICAgICAgIHZlcnRpY2FsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgICBob3Jpem9udGFsQWxpZ249XCJjZW50ZXJcIlxuICAgICAgICBnYXA9eyAyMCB9XG4gICAgICAgIHdpZHRoPXszMDB9XG4gICAgICA+XG4gICAgICAgIDxGbGV4SXRlbT5cbiAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2NvbnN0cnVjYW8uc3ZnXCIvPlxuICAgICAgICA8L0ZsZXhJdGVtPlxuICAgICAgICA8RmxleEl0ZW0+XG4gICAgICAgICAgPFRleHRcbiAgICAgICAgICAgIHZhcmlhbnQ9J2xhcmdlJ1xuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0gfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBQw6FnaW5hIGVtIGNvbnN0cnXDp8Ojb1xuICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgPC9GbGV4SXRlbT5cbiAgICAgIDwvRmxleENvbHVtbj5cbiAgICA8L0ZsZXhSb3c+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGFnZVVuZGVyQ29uc3RydWN0aW9uXG4iXX0=