import {
  require_react
} from "/node_modules/.vite/deps/chunk-TTDEEOQS.js?v=9f90a7ff";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-HYZYPRER.js?v=9f90a7ff";

// node_modules/@uifabric/set-version/lib/setVersion.js
var packagesCache = {};
var _win = void 0;
try {
  _win = window;
} catch (e) {
}
function setVersion(packageName, packageVersion) {
  if (typeof _win !== "undefined") {
    var packages = _win.__packages__ = _win.__packages__ || {};
    if (!packages[packageName] || !packagesCache[packageName]) {
      packagesCache[packageName] = packageVersion;
      var versions = packages[packageName] = packages[packageName] || [];
      versions.push(packageVersion);
    }
  }
}

// node_modules/@uifabric/set-version/lib/index.js
setVersion("@uifabric/set-version", "6.0.0");

// node_modules/@uifabric/react-hooks/lib/version.js
setVersion("@uifabric/react-hooks", "7.16.3");

// node_modules/@uifabric/utilities/lib/dom/setSSR.js
var _isSSR = false;

// node_modules/@uifabric/utilities/lib/dom/getWindow.js
var _window = void 0;
try {
  _window = window;
} catch (e) {
}
function getWindow(rootElement) {
  if (_isSSR || typeof _window === "undefined") {
    return void 0;
  } else {
    var el = rootElement;
    return el && el.ownerDocument && el.ownerDocument.defaultView ? el.ownerDocument.defaultView : _window;
  }
}

// node_modules/@uifabric/utilities/lib/Async.js
var Async = (
  /** @class */
  function() {
    function Async2(parent, onError) {
      this._timeoutIds = null;
      this._immediateIds = null;
      this._intervalIds = null;
      this._animationFrameIds = null;
      this._isDisposed = false;
      this._parent = parent || null;
      this._onErrorHandler = onError;
      this._noop = function() {
      };
    }
    Async2.prototype.dispose = function() {
      var id;
      this._isDisposed = true;
      this._parent = null;
      if (this._timeoutIds) {
        for (id in this._timeoutIds) {
          if (this._timeoutIds.hasOwnProperty(id)) {
            this.clearTimeout(parseInt(id, 10));
          }
        }
        this._timeoutIds = null;
      }
      if (this._immediateIds) {
        for (id in this._immediateIds) {
          if (this._immediateIds.hasOwnProperty(id)) {
            this.clearImmediate(parseInt(id, 10));
          }
        }
        this._immediateIds = null;
      }
      if (this._intervalIds) {
        for (id in this._intervalIds) {
          if (this._intervalIds.hasOwnProperty(id)) {
            this.clearInterval(parseInt(id, 10));
          }
        }
        this._intervalIds = null;
      }
      if (this._animationFrameIds) {
        for (id in this._animationFrameIds) {
          if (this._animationFrameIds.hasOwnProperty(id)) {
            this.cancelAnimationFrame(parseInt(id, 10));
          }
        }
        this._animationFrameIds = null;
      }
    };
    Async2.prototype.setTimeout = function(callback, duration) {
      var _this = this;
      var timeoutId = 0;
      if (!this._isDisposed) {
        if (!this._timeoutIds) {
          this._timeoutIds = {};
        }
        timeoutId = setTimeout(function() {
          try {
            if (_this._timeoutIds) {
              delete _this._timeoutIds[timeoutId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            if (_this._onErrorHandler) {
              _this._onErrorHandler(e);
            }
          }
        }, duration);
        this._timeoutIds[timeoutId] = true;
      }
      return timeoutId;
    };
    Async2.prototype.clearTimeout = function(id) {
      if (this._timeoutIds && this._timeoutIds[id]) {
        clearTimeout(id);
        delete this._timeoutIds[id];
      }
    };
    Async2.prototype.setImmediate = function(callback, targetElement) {
      var _this = this;
      var immediateId = 0;
      var win = getWindow(targetElement);
      if (!this._isDisposed) {
        if (!this._immediateIds) {
          this._immediateIds = {};
        }
        var setImmediateCallback = function() {
          try {
            if (_this._immediateIds) {
              delete _this._immediateIds[immediateId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        };
        immediateId = win.setTimeout(setImmediateCallback, 0);
        this._immediateIds[immediateId] = true;
      }
      return immediateId;
    };
    Async2.prototype.clearImmediate = function(id, targetElement) {
      var win = getWindow(targetElement);
      if (this._immediateIds && this._immediateIds[id]) {
        win.clearTimeout(id);
        delete this._immediateIds[id];
      }
    };
    Async2.prototype.setInterval = function(callback, duration) {
      var _this = this;
      var intervalId = 0;
      if (!this._isDisposed) {
        if (!this._intervalIds) {
          this._intervalIds = {};
        }
        intervalId = setInterval(function() {
          try {
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        }, duration);
        this._intervalIds[intervalId] = true;
      }
      return intervalId;
    };
    Async2.prototype.clearInterval = function(id) {
      if (this._intervalIds && this._intervalIds[id]) {
        clearInterval(id);
        delete this._intervalIds[id];
      }
    };
    Async2.prototype.throttle = function(func, wait, options) {
      var _this = this;
      if (this._isDisposed) {
        return this._noop;
      }
      var waitMS = wait || 0;
      var leading = true;
      var trailing = true;
      var lastExecuteTime = 0;
      var lastResult;
      var lastArgs;
      var timeoutId = null;
      if (options && typeof options.leading === "boolean") {
        leading = options.leading;
      }
      if (options && typeof options.trailing === "boolean") {
        trailing = options.trailing;
      }
      var callback = function(userCall) {
        var now2 = Date.now();
        var delta = now2 - lastExecuteTime;
        var waitLength = leading ? waitMS - delta : waitMS;
        if (delta >= waitMS && (!userCall || leading)) {
          lastExecuteTime = now2;
          if (timeoutId) {
            _this.clearTimeout(timeoutId);
            timeoutId = null;
          }
          lastResult = func.apply(_this._parent, lastArgs);
        } else if (timeoutId === null && trailing) {
          timeoutId = _this.setTimeout(callback, waitLength);
        }
        return lastResult;
      };
      var resultFunction = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        lastArgs = args;
        return callback(true);
      };
      return resultFunction;
    };
    Async2.prototype.debounce = function(func, wait, options) {
      var _this = this;
      if (this._isDisposed) {
        var noOpFunction = function() {
        };
        noOpFunction.cancel = function() {
          return;
        };
        noOpFunction.flush = function() {
          return null;
        };
        noOpFunction.pending = function() {
          return false;
        };
        return noOpFunction;
      }
      var waitMS = wait || 0;
      var leading = false;
      var trailing = true;
      var maxWait = null;
      var lastCallTime = 0;
      var lastExecuteTime = Date.now();
      var lastResult;
      var lastArgs;
      var timeoutId = null;
      if (options && typeof options.leading === "boolean") {
        leading = options.leading;
      }
      if (options && typeof options.trailing === "boolean") {
        trailing = options.trailing;
      }
      if (options && typeof options.maxWait === "number" && !isNaN(options.maxWait)) {
        maxWait = options.maxWait;
      }
      var markExecuted = function(time) {
        if (timeoutId) {
          _this.clearTimeout(timeoutId);
          timeoutId = null;
        }
        lastExecuteTime = time;
      };
      var invokeFunction = function(time) {
        markExecuted(time);
        lastResult = func.apply(_this._parent, lastArgs);
      };
      var callback = function(userCall) {
        var now2 = Date.now();
        var executeImmediately = false;
        if (userCall) {
          if (leading && now2 - lastCallTime >= waitMS) {
            executeImmediately = true;
          }
          lastCallTime = now2;
        }
        var delta = now2 - lastCallTime;
        var waitLength = waitMS - delta;
        var maxWaitDelta = now2 - lastExecuteTime;
        var maxWaitExpired = false;
        if (maxWait !== null) {
          if (maxWaitDelta >= maxWait && timeoutId) {
            maxWaitExpired = true;
          } else {
            waitLength = Math.min(waitLength, maxWait - maxWaitDelta);
          }
        }
        if (delta >= waitMS || maxWaitExpired || executeImmediately) {
          invokeFunction(now2);
        } else if ((timeoutId === null || !userCall) && trailing) {
          timeoutId = _this.setTimeout(callback, waitLength);
        }
        return lastResult;
      };
      var pending = function() {
        return !!timeoutId;
      };
      var cancel = function() {
        if (pending()) {
          markExecuted(Date.now());
        }
      };
      var flush = function() {
        if (pending()) {
          invokeFunction(Date.now());
        }
        return lastResult;
      };
      var resultFunction = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        lastArgs = args;
        return callback(true);
      };
      resultFunction.cancel = cancel;
      resultFunction.flush = flush;
      resultFunction.pending = pending;
      return resultFunction;
    };
    Async2.prototype.requestAnimationFrame = function(callback, targetElement) {
      var _this = this;
      var animationFrameId = 0;
      var win = getWindow(targetElement);
      if (!this._isDisposed) {
        if (!this._animationFrameIds) {
          this._animationFrameIds = {};
        }
        var animationFrameCallback = function() {
          try {
            if (_this._animationFrameIds) {
              delete _this._animationFrameIds[animationFrameId];
            }
            callback.apply(_this._parent);
          } catch (e) {
            _this._logError(e);
          }
        };
        animationFrameId = win.requestAnimationFrame ? win.requestAnimationFrame(animationFrameCallback) : win.setTimeout(animationFrameCallback, 0);
        this._animationFrameIds[animationFrameId] = true;
      }
      return animationFrameId;
    };
    Async2.prototype.cancelAnimationFrame = function(id, targetElement) {
      var win = getWindow(targetElement);
      if (this._animationFrameIds && this._animationFrameIds[id]) {
        win.cancelAnimationFrame ? win.cancelAnimationFrame(id) : win.clearTimeout(id);
        delete this._animationFrameIds[id];
      }
    };
    Async2.prototype._logError = function(e) {
      if (this._onErrorHandler) {
        this._onErrorHandler(e);
      }
    };
    return Async2;
  }()
);

// node_modules/@uifabric/utilities/lib/object.js
function shallowCompare(a, b) {
  for (var propName in a) {
    if (a.hasOwnProperty(propName)) {
      if (!b.hasOwnProperty(propName) || b[propName] !== a[propName]) {
        return false;
      }
    }
  }
  for (var propName in b) {
    if (b.hasOwnProperty(propName)) {
      if (!a.hasOwnProperty(propName)) {
        return false;
      }
    }
  }
  return true;
}
function assign(target) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  return filteredAssign.apply(this, [null, target].concat(args));
}
function filteredAssign(isAllowed, target) {
  var args = [];
  for (var _i = 2; _i < arguments.length; _i++) {
    args[_i - 2] = arguments[_i];
  }
  target = target || {};
  for (var _a3 = 0, args_1 = args; _a3 < args_1.length; _a3++) {
    var sourceObject = args_1[_a3];
    if (sourceObject) {
      for (var propName in sourceObject) {
        if (sourceObject.hasOwnProperty(propName) && (!isAllowed || isAllowed(propName))) {
          target[propName] = sourceObject[propName];
        }
      }
    }
  }
  return target;
}
function values(obj) {
  return Object.keys(obj).reduce(function(arr, key) {
    arr.push(obj[key]);
    return arr;
  }, []);
}
function omit(obj, exclusions) {
  var result = {};
  for (var key in obj) {
    if (exclusions.indexOf(key) === -1 && obj.hasOwnProperty(key)) {
      result[key] = obj[key];
    }
  }
  return result;
}

// node_modules/@uifabric/utilities/lib/EventGroup.js
var EventGroup = (
  /** @class */
  function() {
    function EventGroup2(parent) {
      this._id = EventGroup2._uniqueId++;
      this._parent = parent;
      this._eventRecords = [];
    }
    EventGroup2.raise = function(target, eventName, eventArgs, bubbleEvent) {
      var retVal2;
      if (EventGroup2._isElement(target)) {
        if (typeof document !== "undefined" && document.createEvent) {
          var ev = document.createEvent("HTMLEvents");
          ev.initEvent(eventName, bubbleEvent || false, true);
          assign(ev, eventArgs);
          retVal2 = target.dispatchEvent(ev);
        } else if (typeof document !== "undefined" && document.createEventObject) {
          var evObj = document.createEventObject(eventArgs);
          target.fireEvent("on" + eventName, evObj);
        }
      } else {
        while (target && retVal2 !== false) {
          var events = target.__events__;
          var eventRecords = events ? events[eventName] : null;
          if (eventRecords) {
            for (var id in eventRecords) {
              if (eventRecords.hasOwnProperty(id)) {
                var eventRecordList = eventRecords[id];
                for (var listIndex = 0; retVal2 !== false && listIndex < eventRecordList.length; listIndex++) {
                  var record = eventRecordList[listIndex];
                  if (record.objectCallback) {
                    retVal2 = record.objectCallback.call(record.parent, eventArgs);
                  }
                }
              }
            }
          }
          target = bubbleEvent ? target.parent : null;
        }
      }
      return retVal2;
    };
    EventGroup2.isObserved = function(target, eventName) {
      var events = target && target.__events__;
      return !!events && !!events[eventName];
    };
    EventGroup2.isDeclared = function(target, eventName) {
      var declaredEvents = target && target.__declaredEvents;
      return !!declaredEvents && !!declaredEvents[eventName];
    };
    EventGroup2.stopPropagation = function(event) {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    };
    EventGroup2._isElement = function(target) {
      return !!target && (!!target.addEventListener || typeof HTMLElement !== "undefined" && target instanceof HTMLElement);
    };
    EventGroup2.prototype.dispose = function() {
      if (!this._isDisposed) {
        this._isDisposed = true;
        this.off();
        this._parent = null;
      }
    };
    EventGroup2.prototype.onAll = function(target, events, useCapture) {
      for (var eventName in events) {
        if (events.hasOwnProperty(eventName)) {
          this.on(target, eventName, events[eventName], useCapture);
        }
      }
    };
    EventGroup2.prototype.on = function(target, eventName, callback, options) {
      var _this = this;
      if (eventName.indexOf(",") > -1) {
        var events = eventName.split(/[ ,]+/);
        for (var i = 0; i < events.length; i++) {
          this.on(target, events[i], callback, options);
        }
      } else {
        var parent_1 = this._parent;
        var eventRecord = {
          target,
          eventName,
          parent: parent_1,
          callback,
          options
        };
        var events = target.__events__ = target.__events__ || {};
        events[eventName] = events[eventName] || {
          count: 0
        };
        events[eventName][this._id] = events[eventName][this._id] || [];
        events[eventName][this._id].push(eventRecord);
        events[eventName].count++;
        if (EventGroup2._isElement(target)) {
          var processElementEvent = function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            if (_this._isDisposed) {
              return;
            }
            var result;
            try {
              result = callback.apply(parent_1, args);
              if (result === false && args[0]) {
                var e = args[0];
                if (e.preventDefault) {
                  e.preventDefault();
                }
                if (e.stopPropagation) {
                  e.stopPropagation();
                }
                e.cancelBubble = true;
              }
            } catch (e2) {
            }
            return result;
          };
          eventRecord.elementCallback = processElementEvent;
          if (target.addEventListener) {
            target.addEventListener(eventName, processElementEvent, options);
          } else if (target.attachEvent) {
            target.attachEvent("on" + eventName, processElementEvent);
          }
        } else {
          var processObjectEvent = function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            if (_this._isDisposed) {
              return;
            }
            return callback.apply(parent_1, args);
          };
          eventRecord.objectCallback = processObjectEvent;
        }
        this._eventRecords.push(eventRecord);
      }
    };
    EventGroup2.prototype.off = function(target, eventName, callback, options) {
      for (var i = 0; i < this._eventRecords.length; i++) {
        var eventRecord = this._eventRecords[i];
        if ((!target || target === eventRecord.target) && (!eventName || eventName === eventRecord.eventName) && (!callback || callback === eventRecord.callback) && (typeof options !== "boolean" || options === eventRecord.options)) {
          var events = eventRecord.target.__events__;
          var targetArrayLookup = events[eventRecord.eventName];
          var targetArray = targetArrayLookup ? targetArrayLookup[this._id] : null;
          if (targetArray) {
            if (targetArray.length === 1 || !callback) {
              targetArrayLookup.count -= targetArray.length;
              delete events[eventRecord.eventName][this._id];
            } else {
              targetArrayLookup.count--;
              targetArray.splice(targetArray.indexOf(eventRecord), 1);
            }
            if (!targetArrayLookup.count) {
              delete events[eventRecord.eventName];
            }
          }
          if (eventRecord.elementCallback) {
            if (eventRecord.target.removeEventListener) {
              eventRecord.target.removeEventListener(eventRecord.eventName, eventRecord.elementCallback, eventRecord.options);
            } else if (eventRecord.target.detachEvent) {
              eventRecord.target.detachEvent("on" + eventRecord.eventName, eventRecord.elementCallback);
            }
          }
          this._eventRecords.splice(i--, 1);
        }
      }
    };
    EventGroup2.prototype.raise = function(eventName, eventArgs, bubbleEvent) {
      return EventGroup2.raise(this._parent, eventName, eventArgs, bubbleEvent);
    };
    EventGroup2.prototype.declare = function(event) {
      var declaredEvents = this._parent.__declaredEvents = this._parent.__declaredEvents || {};
      if (typeof event === "string") {
        declaredEvents[event] = true;
      } else {
        for (var i = 0; i < event.length; i++) {
          declaredEvents[event[i]] = true;
        }
      }
    };
    EventGroup2._uniqueId = 0;
    return EventGroup2;
  }()
);

// node_modules/@uifabric/utilities/lib/dom/getDocument.js
function getDocument(rootElement) {
  if (_isSSR || typeof document === "undefined") {
    return void 0;
  } else {
    var el = rootElement;
    return el && el.ownerDocument ? el.ownerDocument : document;
  }
}

// node_modules/@uifabric/merge-styles/node_modules/tslib/tslib.es6.js
var __assign = function() {
  __assign = Object.assign || function __assign4(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __spreadArrays() {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++)
    s += arguments[i].length;
  for (var r = Array(s), k = 0, i = 0; i < il; i++)
    for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
      r[k] = a[j];
  return r;
}

// node_modules/@uifabric/merge-styles/lib/Stylesheet.js
var InjectionMode = {
  /**
   * Avoids style injection, use getRules() to read the styles.
   */
  none: 0,
  /**
   * Inserts rules using the insertRule api.
   */
  insertNode: 1,
  /**
   * Appends rules using appendChild.
   */
  appendChild: 2
};
var STYLESHEET_SETTING = "__stylesheet__";
var REUSE_STYLE_NODE = typeof navigator !== "undefined" && /rv:11.0/.test(navigator.userAgent);
var _global = {};
try {
  _global = window;
} catch (_a3) {
}
var _stylesheet;
var Stylesheet = (
  /** @class */
  function() {
    function Stylesheet2(config) {
      this._rules = [];
      this._preservedRules = [];
      this._rulesToInsert = [];
      this._counter = 0;
      this._keyToClassName = {};
      this._onResetCallbacks = [];
      this._classNameToArgs = {};
      this._config = __assign({ injectionMode: InjectionMode.insertNode, defaultPrefix: "css", namespace: void 0, cspSettings: void 0 }, config);
      this._keyToClassName = this._config.classNameCache || {};
    }
    Stylesheet2.getInstance = function() {
      var _a3;
      _stylesheet = _global[STYLESHEET_SETTING];
      if (!_stylesheet || _stylesheet._lastStyleElement && _stylesheet._lastStyleElement.ownerDocument !== document) {
        var fabricConfig = ((_a3 = _global) === null || _a3 === void 0 ? void 0 : _a3.FabricConfig) || {};
        _stylesheet = _global[STYLESHEET_SETTING] = new Stylesheet2(fabricConfig.mergeStyles);
      }
      return _stylesheet;
    };
    Stylesheet2.prototype.setConfig = function(config) {
      this._config = __assign(__assign({}, this._config), config);
    };
    Stylesheet2.prototype.onReset = function(callback) {
      this._onResetCallbacks.push(callback);
    };
    Stylesheet2.prototype.getClassName = function(displayName) {
      var namespace = this._config.namespace;
      var prefix = displayName || this._config.defaultPrefix;
      return (namespace ? namespace + "-" : "") + prefix + "-" + this._counter++;
    };
    Stylesheet2.prototype.cacheClassName = function(className, key, args, rules2) {
      this._keyToClassName[key] = className;
      this._classNameToArgs[className] = {
        args,
        rules: rules2
      };
    };
    Stylesheet2.prototype.classNameFromKey = function(key) {
      return this._keyToClassName[key];
    };
    Stylesheet2.prototype.getClassNameCache = function() {
      return this._keyToClassName;
    };
    Stylesheet2.prototype.argsFromClassName = function(className) {
      var entry = this._classNameToArgs[className];
      return entry && entry.args;
    };
    Stylesheet2.prototype.insertedRulesFromClassName = function(className) {
      var entry = this._classNameToArgs[className];
      return entry && entry.rules;
    };
    Stylesheet2.prototype.insertRule = function(rule, preserve) {
      var injectionMode = this._config.injectionMode;
      var element = injectionMode !== InjectionMode.none ? this._getStyleElement() : void 0;
      if (preserve) {
        this._preservedRules.push(rule);
      }
      if (element) {
        switch (this._config.injectionMode) {
          case InjectionMode.insertNode:
            var sheet = element.sheet;
            try {
              sheet.insertRule(rule, sheet.cssRules.length);
            } catch (e) {
            }
            break;
          case InjectionMode.appendChild:
            element.appendChild(document.createTextNode(rule));
            break;
        }
      } else {
        this._rules.push(rule);
      }
      if (this._config.onInsertRule) {
        this._config.onInsertRule(rule);
      }
    };
    Stylesheet2.prototype.getRules = function(includePreservedRules) {
      return (includePreservedRules ? this._preservedRules.join("") : "") + this._rules.join("") + this._rulesToInsert.join("");
    };
    Stylesheet2.prototype.reset = function() {
      this._rules = [];
      this._rulesToInsert = [];
      this._counter = 0;
      this._classNameToArgs = {};
      this._keyToClassName = {};
      this._onResetCallbacks.forEach(function(callback) {
        return callback();
      });
    };
    Stylesheet2.prototype.resetKeys = function() {
      this._keyToClassName = {};
    };
    Stylesheet2.prototype._getStyleElement = function() {
      var _this = this;
      if (!this._styleElement && typeof document !== "undefined") {
        this._styleElement = this._createStyleElement();
        if (!REUSE_STYLE_NODE) {
          window.requestAnimationFrame(function() {
            _this._styleElement = void 0;
          });
        }
      }
      return this._styleElement;
    };
    Stylesheet2.prototype._createStyleElement = function() {
      var head = document.head;
      var styleElement = document.createElement("style");
      var nodeToInsertBefore = null;
      styleElement.setAttribute("data-merge-styles", "true");
      var cspSettings = this._config.cspSettings;
      if (cspSettings) {
        if (cspSettings.nonce) {
          styleElement.setAttribute("nonce", cspSettings.nonce);
        }
      }
      if (this._lastStyleElement) {
        nodeToInsertBefore = this._lastStyleElement.nextElementSibling;
      } else {
        var placeholderStyleTag = this._findPlaceholderStyleTag();
        if (placeholderStyleTag) {
          nodeToInsertBefore = placeholderStyleTag.nextElementSibling;
        } else {
          nodeToInsertBefore = head.childNodes[0];
        }
      }
      head.insertBefore(styleElement, head.contains(nodeToInsertBefore) ? nodeToInsertBefore : null);
      this._lastStyleElement = styleElement;
      return styleElement;
    };
    Stylesheet2.prototype._findPlaceholderStyleTag = function() {
      var head = document.head;
      if (head) {
        return head.querySelector("style[data-merge-styles]");
      }
      return null;
    };
    return Stylesheet2;
  }()
);

// node_modules/@uifabric/merge-styles/lib/extractStyleParts.js
function extractStyleParts() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  var classes = [];
  var objects = [];
  var stylesheet2 = Stylesheet.getInstance();
  function _processArgs(argsList) {
    for (var _i2 = 0, argsList_1 = argsList; _i2 < argsList_1.length; _i2++) {
      var arg = argsList_1[_i2];
      if (arg) {
        if (typeof arg === "string") {
          if (arg.indexOf(" ") >= 0) {
            _processArgs(arg.split(" "));
          } else {
            var translatedArgs = stylesheet2.argsFromClassName(arg);
            if (translatedArgs) {
              _processArgs(translatedArgs);
            } else {
              if (classes.indexOf(arg) === -1) {
                classes.push(arg);
              }
            }
          }
        } else if (Array.isArray(arg)) {
          _processArgs(arg);
        } else if (typeof arg === "object") {
          objects.push(arg);
        }
      }
    }
  }
  _processArgs(args);
  return {
    classes,
    objects
  };
}

// node_modules/@uifabric/merge-styles/lib/StyleOptionsState.js
function setRTL(isRTL) {
  if (_rtl !== isRTL) {
    _rtl = isRTL;
  }
}
function getRTL() {
  if (_rtl === void 0) {
    _rtl = typeof document !== "undefined" && !!document.documentElement && document.documentElement.getAttribute("dir") === "rtl";
  }
  return _rtl;
}
var _rtl;
_rtl = getRTL();
function getStyleOptions() {
  return {
    rtl: getRTL()
  };
}

// node_modules/@uifabric/merge-styles/lib/transforms/kebabRules.js
var rules = {};
function kebabRules(rulePairs, index) {
  var rule = rulePairs[index];
  if (rule.charAt(0) !== "-") {
    rulePairs[index] = rules[rule] = rules[rule] || rule.replace(/([A-Z])/g, "-$1").toLowerCase();
  }
}

// node_modules/@uifabric/merge-styles/lib/getVendorSettings.js
var _vendorSettings;
function getVendorSettings() {
  var _a3, _b;
  if (!_vendorSettings) {
    var doc = typeof document !== "undefined" ? document : void 0;
    var nav = typeof navigator !== "undefined" ? navigator : void 0;
    var userAgent = (_b = (_a3 = nav) === null || _a3 === void 0 ? void 0 : _a3.userAgent) === null || _b === void 0 ? void 0 : _b.toLowerCase();
    if (!doc) {
      _vendorSettings = {
        isWebkit: true,
        isMoz: true,
        isOpera: true,
        isMs: true
      };
    } else {
      _vendorSettings = {
        isWebkit: !!(doc && "WebkitAppearance" in doc.documentElement.style),
        isMoz: !!(userAgent && userAgent.indexOf("firefox") > -1),
        isOpera: !!(userAgent && userAgent.indexOf("opera") > -1),
        isMs: !!(nav && (/rv:11.0/i.test(nav.userAgent) || /Edge\/\d./i.test(navigator.userAgent)))
      };
    }
  }
  return _vendorSettings;
}

// node_modules/@uifabric/merge-styles/lib/transforms/prefixRules.js
var autoPrefixNames = {
  "user-select": 1
};
function prefixRules(rulePairs, index) {
  var vendorSettings = getVendorSettings();
  var name = rulePairs[index];
  if (autoPrefixNames[name]) {
    var value = rulePairs[index + 1];
    if (autoPrefixNames[name]) {
      if (vendorSettings.isWebkit) {
        rulePairs.push("-webkit-" + name, value);
      }
      if (vendorSettings.isMoz) {
        rulePairs.push("-moz-" + name, value);
      }
      if (vendorSettings.isMs) {
        rulePairs.push("-ms-" + name, value);
      }
      if (vendorSettings.isOpera) {
        rulePairs.push("-o-" + name, value);
      }
    }
  }
}

// node_modules/@uifabric/merge-styles/lib/transforms/provideUnits.js
var NON_PIXEL_NUMBER_PROPS = [
  "column-count",
  "font-weight",
  "flex",
  "flex-grow",
  "flex-shrink",
  "fill-opacity",
  "opacity",
  "order",
  "z-index",
  "zoom"
];
function provideUnits(rulePairs, index) {
  var name = rulePairs[index];
  var value = rulePairs[index + 1];
  if (typeof value === "number") {
    var isNonPixelProp = NON_PIXEL_NUMBER_PROPS.indexOf(name) > -1;
    var isVariableOrPrefixed = name.indexOf("--") > -1;
    var unit = isNonPixelProp || isVariableOrPrefixed ? "" : "px";
    rulePairs[index + 1] = "" + value + unit;
  }
}

// node_modules/@uifabric/merge-styles/lib/transforms/rtlifyRules.js
var _a;
var LEFT = "left";
var RIGHT = "right";
var NO_FLIP = "@noflip";
var NAME_REPLACEMENTS = (_a = {}, _a[LEFT] = RIGHT, _a[RIGHT] = LEFT, _a);
var VALUE_REPLACEMENTS = {
  "w-resize": "e-resize",
  "sw-resize": "se-resize",
  "nw-resize": "ne-resize"
};
function rtlifyRules(options, rulePairs, index) {
  if (options.rtl) {
    var name_1 = rulePairs[index];
    if (!name_1) {
      return;
    }
    var value = rulePairs[index + 1];
    if (typeof value === "string" && value.indexOf(NO_FLIP) >= 0) {
      rulePairs[index + 1] = value.replace(/\s*(?:\/\*\s*)?\@noflip\b(?:\s*\*\/)?\s*?/g, "");
    } else if (name_1.indexOf(LEFT) >= 0) {
      rulePairs[index] = name_1.replace(LEFT, RIGHT);
    } else if (name_1.indexOf(RIGHT) >= 0) {
      rulePairs[index] = name_1.replace(RIGHT, LEFT);
    } else if (String(value).indexOf(LEFT) >= 0) {
      rulePairs[index + 1] = value.replace(LEFT, RIGHT);
    } else if (String(value).indexOf(RIGHT) >= 0) {
      rulePairs[index + 1] = value.replace(RIGHT, LEFT);
    } else if (NAME_REPLACEMENTS[name_1]) {
      rulePairs[index] = NAME_REPLACEMENTS[name_1];
    } else if (VALUE_REPLACEMENTS[value]) {
      rulePairs[index + 1] = VALUE_REPLACEMENTS[value];
    } else {
      switch (name_1) {
        case "margin":
        case "padding":
          rulePairs[index + 1] = flipQuad(value);
          break;
        case "box-shadow":
          rulePairs[index + 1] = negateNum(value, 0);
          break;
      }
    }
  }
}
function negateNum(value, partIndex) {
  var parts = value.split(" ");
  var numberVal = parseInt(parts[partIndex], 10);
  parts[0] = parts[0].replace(String(numberVal), String(numberVal * -1));
  return parts.join(" ");
}
function flipQuad(value) {
  if (typeof value === "string") {
    var parts = value.split(" ");
    if (parts.length === 4) {
      return parts[0] + " " + parts[3] + " " + parts[2] + " " + parts[1];
    }
  }
  return value;
}

// node_modules/@uifabric/merge-styles/lib/styleToClassName.js
var DISPLAY_NAME = "displayName";
function getDisplayName(rules2) {
  var rootStyle = rules2 && rules2["&"];
  return rootStyle ? rootStyle.displayName : void 0;
}
var globalSelectorRegExp = /\:global\((.+?)\)/g;
function expandCommaSeparatedGlobals(selectorWithGlobals) {
  if (!globalSelectorRegExp.test(selectorWithGlobals)) {
    return selectorWithGlobals;
  }
  var replacementInfo = [];
  var findGlobal = /\:global\((.+?)\)/g;
  var match = null;
  while (match = findGlobal.exec(selectorWithGlobals)) {
    if (match[1].indexOf(",") > -1) {
      replacementInfo.push([
        match.index,
        match.index + match[0].length,
        // Wrap each of the found selectors in :global()
        match[1].split(",").map(function(v) {
          return ":global(" + v.trim() + ")";
        }).join(", ")
      ]);
    }
  }
  return replacementInfo.reverse().reduce(function(selector, _a3) {
    var matchIndex = _a3[0], matchEndIndex = _a3[1], replacement = _a3[2];
    var prefix = selector.slice(0, matchIndex);
    var suffix = selector.slice(matchEndIndex);
    return prefix + replacement + suffix;
  }, selectorWithGlobals);
}
function expandSelector(newSelector, currentSelector) {
  if (newSelector.indexOf(":global(") >= 0) {
    return newSelector.replace(globalSelectorRegExp, "$1");
  } else if (newSelector.indexOf(":") === 0) {
    return currentSelector + newSelector;
  } else if (newSelector.indexOf("&") < 0) {
    return currentSelector + " " + newSelector;
  }
  return newSelector;
}
function extractSelector(currentSelector, rules2, selector, value) {
  if (rules2 === void 0) {
    rules2 = { __order: [] };
  }
  if (selector.indexOf("@") === 0) {
    selector = selector + "{" + currentSelector;
    extractRules([value], rules2, selector);
  } else if (selector.indexOf(",") > -1) {
    expandCommaSeparatedGlobals(selector).split(",").map(function(s) {
      return s.trim();
    }).forEach(function(separatedSelector) {
      return extractRules([value], rules2, expandSelector(separatedSelector, currentSelector));
    });
  } else {
    extractRules([value], rules2, expandSelector(selector, currentSelector));
  }
}
function extractRules(args, rules2, currentSelector) {
  if (rules2 === void 0) {
    rules2 = { __order: [] };
  }
  if (currentSelector === void 0) {
    currentSelector = "&";
  }
  var stylesheet2 = Stylesheet.getInstance();
  var currentRules = rules2[currentSelector];
  if (!currentRules) {
    currentRules = {};
    rules2[currentSelector] = currentRules;
    rules2.__order.push(currentSelector);
  }
  for (var _i = 0, args_1 = args; _i < args_1.length; _i++) {
    var arg = args_1[_i];
    if (typeof arg === "string") {
      var expandedRules = stylesheet2.argsFromClassName(arg);
      if (expandedRules) {
        extractRules(expandedRules, rules2, currentSelector);
      }
    } else if (Array.isArray(arg)) {
      extractRules(arg, rules2, currentSelector);
    } else {
      for (var prop in arg) {
        if (arg.hasOwnProperty(prop)) {
          var propValue = arg[prop];
          if (prop === "selectors") {
            var selectors = arg.selectors;
            for (var newSelector in selectors) {
              if (selectors.hasOwnProperty(newSelector)) {
                extractSelector(currentSelector, rules2, newSelector, selectors[newSelector]);
              }
            }
          } else if (typeof propValue === "object") {
            if (propValue !== null) {
              extractSelector(currentSelector, rules2, prop, propValue);
            }
          } else {
            if (propValue !== void 0) {
              if (prop === "margin" || prop === "padding") {
                expandQuads(currentRules, prop, propValue);
              } else {
                currentRules[prop] = propValue;
              }
            }
          }
        }
      }
    }
  }
  return rules2;
}
function expandQuads(currentRules, name, value) {
  var parts = typeof value === "string" ? value.split(" ") : [value];
  currentRules[name + "Top"] = parts[0];
  currentRules[name + "Right"] = parts[1] || parts[0];
  currentRules[name + "Bottom"] = parts[2] || parts[0];
  currentRules[name + "Left"] = parts[3] || parts[1] || parts[0];
}
function getKeyForRules(options, rules2) {
  var serialized = [options.rtl ? "rtl" : "ltr"];
  var hasProps = false;
  for (var _i = 0, _a3 = rules2.__order; _i < _a3.length; _i++) {
    var selector = _a3[_i];
    serialized.push(selector);
    var rulesForSelector = rules2[selector];
    for (var propName in rulesForSelector) {
      if (rulesForSelector.hasOwnProperty(propName) && rulesForSelector[propName] !== void 0) {
        hasProps = true;
        serialized.push(propName, rulesForSelector[propName]);
      }
    }
  }
  return hasProps ? serialized.join("") : void 0;
}
function repeatString(target, count) {
  if (count <= 0) {
    return "";
  }
  if (count === 1) {
    return target;
  }
  return target + repeatString(target, count - 1);
}
function serializeRuleEntries(options, ruleEntries) {
  if (!ruleEntries) {
    return "";
  }
  var allEntries = [];
  for (var entry in ruleEntries) {
    if (ruleEntries.hasOwnProperty(entry) && entry !== DISPLAY_NAME && ruleEntries[entry] !== void 0) {
      allEntries.push(entry, ruleEntries[entry]);
    }
  }
  for (var i = 0; i < allEntries.length; i += 2) {
    kebabRules(allEntries, i);
    provideUnits(allEntries, i);
    rtlifyRules(options, allEntries, i);
    prefixRules(allEntries, i);
  }
  for (var i = 1; i < allEntries.length; i += 4) {
    allEntries.splice(i, 1, ":", allEntries[i], ";");
  }
  return allEntries.join("");
}
function styleToRegistration(options) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  var rules2 = extractRules(args);
  var key = getKeyForRules(options, rules2);
  if (key) {
    var stylesheet2 = Stylesheet.getInstance();
    var registration = {
      className: stylesheet2.classNameFromKey(key),
      key,
      args
    };
    if (!registration.className) {
      registration.className = stylesheet2.getClassName(getDisplayName(rules2));
      var rulesToInsert = [];
      for (var _a3 = 0, _b = rules2.__order; _a3 < _b.length; _a3++) {
        var selector = _b[_a3];
        rulesToInsert.push(selector, serializeRuleEntries(options, rules2[selector]));
      }
      registration.rulesToInsert = rulesToInsert;
    }
    return registration;
  }
  return void 0;
}
function applyRegistration(registration, specificityMultiplier) {
  if (specificityMultiplier === void 0) {
    specificityMultiplier = 1;
  }
  var stylesheet2 = Stylesheet.getInstance();
  var className = registration.className, key = registration.key, args = registration.args, rulesToInsert = registration.rulesToInsert;
  if (rulesToInsert) {
    for (var i = 0; i < rulesToInsert.length; i += 2) {
      var rules2 = rulesToInsert[i + 1];
      if (rules2) {
        var selector = rulesToInsert[i];
        selector = selector.replace(/&/g, repeatString("." + registration.className, specificityMultiplier));
        var processedRule = selector + "{" + rules2 + "}" + (selector.indexOf("@") === 0 ? "}" : "");
        stylesheet2.insertRule(processedRule);
      }
    }
    stylesheet2.cacheClassName(className, key, args, rulesToInsert);
  }
}
function styleToClassName(options) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  var registration = styleToRegistration.apply(void 0, __spreadArrays([options], args));
  if (registration) {
    applyRegistration(registration, options.specificityMultiplier);
    return registration.className;
  }
  return "";
}

// node_modules/@uifabric/merge-styles/lib/mergeStyles.js
function mergeStyles() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  return mergeCss(args, getStyleOptions());
}
function mergeCss(args, options) {
  var styleArgs = args instanceof Array ? args : [args];
  var _a3 = extractStyleParts(styleArgs), classes = _a3.classes, objects = _a3.objects;
  if (objects.length) {
    classes.push(styleToClassName(options || {}, objects));
  }
  return classes.join(" ");
}

// node_modules/@uifabric/merge-styles/lib/concatStyleSets.js
function concatStyleSets() {
  var styleSets = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    styleSets[_i] = arguments[_i];
  }
  if (styleSets && styleSets.length === 1 && styleSets[0] && !styleSets[0].subComponentStyles) {
    return styleSets[0];
  }
  var mergedSet = {};
  var workingSubcomponentStyles = {};
  for (var _a3 = 0, styleSets_1 = styleSets; _a3 < styleSets_1.length; _a3++) {
    var currentSet = styleSets_1[_a3];
    if (currentSet) {
      for (var prop in currentSet) {
        if (currentSet.hasOwnProperty(prop)) {
          if (prop === "subComponentStyles" && currentSet.subComponentStyles !== void 0) {
            var currentComponentStyles = currentSet.subComponentStyles;
            for (var subCompProp in currentComponentStyles) {
              if (currentComponentStyles.hasOwnProperty(subCompProp)) {
                if (workingSubcomponentStyles.hasOwnProperty(subCompProp)) {
                  workingSubcomponentStyles[subCompProp].push(currentComponentStyles[subCompProp]);
                } else {
                  workingSubcomponentStyles[subCompProp] = [currentComponentStyles[subCompProp]];
                }
              }
            }
            continue;
          }
          var mergedValue = mergedSet[prop];
          var currentValue = currentSet[prop];
          if (mergedValue === void 0) {
            mergedSet[prop] = currentValue;
          } else {
            mergedSet[prop] = __spreadArrays(Array.isArray(mergedValue) ? mergedValue : [mergedValue], Array.isArray(currentValue) ? currentValue : [currentValue]);
          }
        }
      }
    }
  }
  if (Object.keys(workingSubcomponentStyles).length > 0) {
    mergedSet.subComponentStyles = {};
    var mergedSubStyles = mergedSet.subComponentStyles;
    var _loop_1 = function(subCompProp2) {
      if (workingSubcomponentStyles.hasOwnProperty(subCompProp2)) {
        var workingSet_1 = workingSubcomponentStyles[subCompProp2];
        mergedSubStyles[subCompProp2] = function(styleProps) {
          return concatStyleSets.apply(void 0, workingSet_1.map(function(styleFunctionOrObject) {
            return typeof styleFunctionOrObject === "function" ? styleFunctionOrObject(styleProps) : styleFunctionOrObject;
          }));
        };
      }
    };
    for (var subCompProp in workingSubcomponentStyles) {
      _loop_1(subCompProp);
    }
  }
  return mergedSet;
}

// node_modules/@uifabric/merge-styles/lib/mergeStyleSets.js
function mergeStyleSets() {
  var styleSets = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    styleSets[_i] = arguments[_i];
  }
  return mergeCssSets(styleSets, getStyleOptions());
}
function mergeCssSets(styleSets, options) {
  var _a3, _b;
  var classNameSet = { subComponentStyles: {} };
  var styleSet = styleSets[0];
  if (!styleSet && styleSets.length <= 1) {
    return { subComponentStyles: {} };
  }
  var concatenatedStyleSet = concatStyleSets.apply(void 0, styleSets);
  var registrations = [];
  for (var styleSetArea in concatenatedStyleSet) {
    if (concatenatedStyleSet.hasOwnProperty(styleSetArea)) {
      if (styleSetArea === "subComponentStyles") {
        classNameSet.subComponentStyles = concatenatedStyleSet.subComponentStyles || {};
        continue;
      }
      var styles = concatenatedStyleSet[styleSetArea];
      var _c = extractStyleParts(styles), classes = _c.classes, objects = _c.objects;
      if ((_a3 = objects) === null || _a3 === void 0 ? void 0 : _a3.length) {
        var registration = styleToRegistration(options || {}, { displayName: styleSetArea }, objects);
        if (registration) {
          registrations.push(registration);
          classNameSet[styleSetArea] = classes.concat([registration.className]).join(" ");
        }
      } else {
        classNameSet[styleSetArea] = classes.join(" ");
      }
    }
  }
  for (var _i = 0, registrations_1 = registrations; _i < registrations_1.length; _i++) {
    var registration = registrations_1[_i];
    if (registration) {
      applyRegistration(registration, (_b = options) === null || _b === void 0 ? void 0 : _b.specificityMultiplier);
    }
  }
  return classNameSet;
}

// node_modules/@uifabric/merge-styles/lib/concatStyleSetsWithProps.js
function concatStyleSetsWithProps(styleProps) {
  var allStyles = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    allStyles[_i - 1] = arguments[_i];
  }
  var result = [];
  for (var _a3 = 0, allStyles_1 = allStyles; _a3 < allStyles_1.length; _a3++) {
    var styles = allStyles_1[_a3];
    if (styles) {
      result.push(typeof styles === "function" ? styles(styleProps) : styles);
    }
  }
  if (result.length === 1) {
    return result[0];
  } else if (result.length) {
    return concatStyleSets.apply(void 0, result);
  }
  return {};
}

// node_modules/@uifabric/merge-styles/lib/fontFace.js
function fontFace(font) {
  Stylesheet.getInstance().insertRule("@font-face{" + serializeRuleEntries(getStyleOptions(), font) + "}", true);
}

// node_modules/@uifabric/merge-styles/lib/keyframes.js
function keyframes(timeline) {
  var stylesheet2 = Stylesheet.getInstance();
  var name = stylesheet2.getClassName();
  var rulesArray = [];
  for (var prop in timeline) {
    if (timeline.hasOwnProperty(prop)) {
      rulesArray.push(prop, "{", serializeRuleEntries(getStyleOptions(), timeline[prop]), "}");
    }
  }
  var rules2 = rulesArray.join("");
  stylesheet2.insertRule("@keyframes " + name + "{" + rules2 + "}", true);
  stylesheet2.cacheClassName(name, rules2, [], ["keyframes", rules2]);
  return name;
}

// node_modules/@uifabric/merge-styles/lib/version.js
setVersion("@uifabric/merge-styles", "7.20.1");

// node_modules/@uifabric/utilities/lib/scroll.js
var _scrollbarWidth;
var _bodyScrollDisabledCount = 0;
var DisabledScrollClassName = mergeStyles({
  overflow: "hidden !important"
});
var DATA_IS_SCROLLABLE_ATTRIBUTE = "data-is-scrollable";
var allowScrollOnElement = function(element, events) {
  if (!element) {
    return;
  }
  var _previousClientY = 0;
  var _element = null;
  var _saveClientY = function(event) {
    if (event.targetTouches.length === 1) {
      _previousClientY = event.targetTouches[0].clientY;
    }
  };
  var _preventOverscrolling = function(event) {
    if (event.targetTouches.length !== 1) {
      return;
    }
    event.stopPropagation();
    if (!_element) {
      return;
    }
    var clientY = event.targetTouches[0].clientY - _previousClientY;
    var scrollableParent = findScrollableParent(event.target);
    if (scrollableParent) {
      _element = scrollableParent;
    }
    if (_element.scrollTop === 0 && clientY > 0) {
      event.preventDefault();
    }
    if (_element.scrollHeight - Math.ceil(_element.scrollTop) <= _element.clientHeight && clientY < 0) {
      event.preventDefault();
    }
  };
  events.on(element, "touchstart", _saveClientY, { passive: false });
  events.on(element, "touchmove", _preventOverscrolling, { passive: false });
  _element = element;
};
var allowOverscrollOnElement = function(element, events) {
  if (!element) {
    return;
  }
  var _allowElementScroll = function(event) {
    event.stopPropagation();
  };
  events.on(element, "touchmove", _allowElementScroll, { passive: false });
};
var _disableIosBodyScroll = function(event) {
  event.preventDefault();
};
function disableBodyScroll() {
  var doc = getDocument();
  if (doc && doc.body && !_bodyScrollDisabledCount) {
    doc.body.classList.add(DisabledScrollClassName);
    doc.body.addEventListener("touchmove", _disableIosBodyScroll, { passive: false, capture: false });
  }
  _bodyScrollDisabledCount++;
}
function enableBodyScroll() {
  if (_bodyScrollDisabledCount > 0) {
    var doc = getDocument();
    if (doc && doc.body && _bodyScrollDisabledCount === 1) {
      doc.body.classList.remove(DisabledScrollClassName);
      doc.body.removeEventListener("touchmove", _disableIosBodyScroll);
    }
    _bodyScrollDisabledCount--;
  }
}
function getScrollbarWidth() {
  if (_scrollbarWidth === void 0) {
    var scrollDiv = document.createElement("div");
    scrollDiv.style.setProperty("width", "100px");
    scrollDiv.style.setProperty("height", "100px");
    scrollDiv.style.setProperty("overflow", "scroll");
    scrollDiv.style.setProperty("position", "absolute");
    scrollDiv.style.setProperty("top", "-9999px");
    document.body.appendChild(scrollDiv);
    _scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
    document.body.removeChild(scrollDiv);
  }
  return _scrollbarWidth;
}
function findScrollableParent(startingElement) {
  var el = startingElement;
  var doc = getDocument(startingElement);
  while (el && el !== doc.body) {
    if (el.getAttribute(DATA_IS_SCROLLABLE_ATTRIBUTE) === "true") {
      return el;
    }
    el = el.parentElement;
  }
  el = startingElement;
  while (el && el !== doc.body) {
    if (el.getAttribute(DATA_IS_SCROLLABLE_ATTRIBUTE) !== "false") {
      var computedStyles = getComputedStyle(el);
      var overflowY = computedStyles ? computedStyles.getPropertyValue("overflow-y") : "";
      if (overflowY && (overflowY === "scroll" || overflowY === "auto")) {
        return el;
      }
    }
    el = el.parentElement;
  }
  if (!el || el === doc.body) {
    el = getWindow(startingElement);
  }
  return el;
}

// node_modules/@uifabric/utilities/lib/dom/getRect.js
function getRect(element) {
  var rect;
  if (element) {
    if (element === window) {
      rect = {
        left: 0,
        top: 0,
        width: window.innerWidth,
        height: window.innerHeight,
        right: window.innerWidth,
        bottom: window.innerHeight
      };
    } else if (element.getBoundingClientRect) {
      rect = element.getBoundingClientRect();
    }
  }
  return rect;
}

// node_modules/@uifabric/utilities/lib/AutoScroll.js
var SCROLL_ITERATION_DELAY = 16;
var SCROLL_GUTTER = 100;
var MAX_SCROLL_VELOCITY = 15;
var AutoScroll = (
  /** @class */
  function() {
    function AutoScroll2(element) {
      this._events = new EventGroup(this);
      this._scrollableParent = findScrollableParent(element);
      this._incrementScroll = this._incrementScroll.bind(this);
      this._scrollRect = getRect(this._scrollableParent);
      if (this._scrollableParent === window) {
        this._scrollableParent = document.body;
      }
      if (this._scrollableParent) {
        this._events.on(window, "mousemove", this._onMouseMove, true);
        this._events.on(window, "touchmove", this._onTouchMove, true);
      }
    }
    AutoScroll2.prototype.dispose = function() {
      this._events.dispose();
      this._stopScroll();
    };
    AutoScroll2.prototype._onMouseMove = function(ev) {
      this._computeScrollVelocity(ev);
    };
    AutoScroll2.prototype._onTouchMove = function(ev) {
      if (ev.touches.length > 0) {
        this._computeScrollVelocity(ev);
      }
    };
    AutoScroll2.prototype._computeScrollVelocity = function(ev) {
      if (!this._scrollRect) {
        return;
      }
      var clientX;
      var clientY;
      if ("clientX" in ev) {
        clientX = ev.clientX;
        clientY = ev.clientY;
      } else {
        clientX = ev.touches[0].clientX;
        clientY = ev.touches[0].clientY;
      }
      var scrollRectTop = this._scrollRect.top;
      var scrollRectLeft = this._scrollRect.left;
      var scrollClientBottom = scrollRectTop + this._scrollRect.height - SCROLL_GUTTER;
      var scrollClientRight = scrollRectLeft + this._scrollRect.width - SCROLL_GUTTER;
      var scrollRect;
      var clientDirection;
      var scrollClient;
      if (clientY < scrollRectTop + SCROLL_GUTTER || clientY > scrollClientBottom) {
        clientDirection = clientY;
        scrollRect = scrollRectTop;
        scrollClient = scrollClientBottom;
        this._isVerticalScroll = true;
      } else {
        clientDirection = clientX;
        scrollRect = scrollRectLeft;
        scrollClient = scrollClientRight;
        this._isVerticalScroll = false;
      }
      if (clientDirection < scrollRect + SCROLL_GUTTER) {
        this._scrollVelocity = Math.max(-MAX_SCROLL_VELOCITY, -MAX_SCROLL_VELOCITY * ((SCROLL_GUTTER - (clientDirection - scrollRect)) / SCROLL_GUTTER));
      } else if (clientDirection > scrollClient) {
        this._scrollVelocity = Math.min(MAX_SCROLL_VELOCITY, MAX_SCROLL_VELOCITY * ((clientDirection - scrollClient) / SCROLL_GUTTER));
      } else {
        this._scrollVelocity = 0;
      }
      if (this._scrollVelocity) {
        this._startScroll();
      } else {
        this._stopScroll();
      }
    };
    AutoScroll2.prototype._startScroll = function() {
      if (!this._timeoutId) {
        this._incrementScroll();
      }
    };
    AutoScroll2.prototype._incrementScroll = function() {
      if (this._scrollableParent) {
        if (this._isVerticalScroll) {
          this._scrollableParent.scrollTop += Math.round(this._scrollVelocity);
        } else {
          this._scrollableParent.scrollLeft += Math.round(this._scrollVelocity);
        }
      }
      this._timeoutId = setTimeout(this._incrementScroll, SCROLL_ITERATION_DELAY);
    };
    AutoScroll2.prototype._stopScroll = function() {
      if (this._timeoutId) {
        clearTimeout(this._timeoutId);
        delete this._timeoutId;
      }
    };
    return AutoScroll2;
  }()
);

// node_modules/@uifabric/utilities/node_modules/tslib/tslib.es6.js
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (b2.hasOwnProperty(p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign2 = function() {
  __assign2 = Object.assign || function __assign4(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign2.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s)
    if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}

// node_modules/@uifabric/utilities/lib/BaseComponent.js
var React = __toESM(require_react());

// node_modules/@uifabric/utilities/lib/warn/warn.js
var _warningCallback = void 0;
function warn(message) {
  if (_warningCallback && true) {
    _warningCallback(message);
  } else if (console && console.warn) {
    console.warn(message);
  }
}

// node_modules/@uifabric/utilities/lib/warn/warnConditionallyRequiredProps.js
function warnConditionallyRequiredProps(componentName, props, requiredProps, conditionalPropName, condition) {
  if (condition === true && true) {
    for (var _i = 0, requiredProps_1 = requiredProps; _i < requiredProps_1.length; _i++) {
      var requiredPropName = requiredProps_1[_i];
      if (!(requiredPropName in props)) {
        warn(componentName + " property '" + requiredPropName + "' is required when '" + conditionalPropName + "' is used.'");
      }
    }
  }
}

// node_modules/@uifabric/utilities/lib/warn/warnMutuallyExclusive.js
function warnMutuallyExclusive(componentName, props, exclusiveMap) {
  if (true) {
    for (var propName in exclusiveMap) {
      if (props && props[propName] !== void 0) {
        var propInExclusiveMapValue = exclusiveMap[propName];
        if (propInExclusiveMapValue && props[propInExclusiveMapValue] !== void 0) {
          warn(componentName + " property '" + propName + "' is mutually exclusive with '" + exclusiveMap[propName] + "'. Use one or the other.");
        }
      }
    }
  }
}

// node_modules/@uifabric/utilities/lib/warn/warnDeprecations.js
function warnDeprecations(componentName, props, deprecationMap) {
  if (true) {
    for (var propName in deprecationMap) {
      if (props && propName in props) {
        var deprecationMessage = componentName + " property '" + propName + "' was used but has been deprecated.";
        var replacementPropName = deprecationMap[propName];
        if (replacementPropName) {
          deprecationMessage += " Use '" + replacementPropName + "' instead.";
        }
        warn(deprecationMessage);
      }
    }
  }
}

// node_modules/@uifabric/utilities/lib/BaseComponent.js
var BaseComponent = (
  /** @class */
  function(_super) {
    __extends(BaseComponent2, _super);
    function BaseComponent2(props, context) {
      var _this = _super.call(this, props, context) || this;
      _makeAllSafe(_this, BaseComponent2.prototype, [
        "componentDidMount",
        "shouldComponentUpdate",
        "getSnapshotBeforeUpdate",
        "render",
        "componentDidUpdate",
        "componentWillUnmount"
      ]);
      return _this;
    }
    BaseComponent2.prototype.componentDidUpdate = function(prevProps, prevState) {
      this._updateComponentRef(prevProps, this.props);
    };
    BaseComponent2.prototype.componentDidMount = function() {
      this._setComponentRef(this.props.componentRef, this);
    };
    BaseComponent2.prototype.componentWillUnmount = function() {
      this._setComponentRef(this.props.componentRef, null);
      if (this.__disposables) {
        for (var i = 0, len = this._disposables.length; i < len; i++) {
          var disposable = this.__disposables[i];
          if (disposable.dispose) {
            disposable.dispose();
          }
        }
        this.__disposables = null;
      }
    };
    Object.defineProperty(BaseComponent2.prototype, "className", {
      /**
       * Gets the object's class name.
       */
      get: function() {
        if (!this.__className) {
          var funcNameRegex = /function (.{1,})\(/;
          var results = funcNameRegex.exec(this.constructor.toString());
          this.__className = results && results.length > 1 ? results[1] : "";
        }
        return this.__className;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_disposables", {
      /**
       * Allows subclasses to push things to this._disposables to be auto disposed.
       */
      get: function() {
        if (!this.__disposables) {
          this.__disposables = [];
        }
        return this.__disposables;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_async", {
      /**
       * Gets the async instance associated with the component, created on demand. The async instance gives
       * subclasses a way to execute setTimeout/setInterval async calls safely, where the callbacks
       * will be cleared/ignored automatically after unmounting. The helpers within the async object also
       * preserve the this pointer so that you don't need to "bind" the callbacks.
       */
      get: function() {
        if (!this.__async) {
          this.__async = new Async(this);
          this._disposables.push(this.__async);
        }
        return this.__async;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(BaseComponent2.prototype, "_events", {
      /**
       * Gets the event group instance assocaited with the component, created on demand. The event instance
       * provides on/off methods for listening to DOM (or regular javascript object) events. The event callbacks
       * will be automatically disconnected after unmounting. The helpers within the events object also
       * preserve the this reference so that you don't need to "bind" the callbacks.
       */
      get: function() {
        if (!this.__events) {
          this.__events = new EventGroup(this);
          this._disposables.push(this.__events);
        }
        return this.__events;
      },
      enumerable: true,
      configurable: true
    });
    BaseComponent2.prototype._resolveRef = function(refName) {
      var _this = this;
      if (!this.__resolves) {
        this.__resolves = {};
      }
      if (!this.__resolves[refName]) {
        this.__resolves[refName] = function(ref) {
          return _this[refName] = ref;
        };
      }
      return this.__resolves[refName];
    };
    BaseComponent2.prototype._updateComponentRef = function(currentProps, newProps) {
      if (newProps === void 0) {
        newProps = {};
      }
      if (currentProps && newProps && currentProps.componentRef !== newProps.componentRef) {
        this._setComponentRef(currentProps.componentRef, null);
        this._setComponentRef(newProps.componentRef, this);
      }
    };
    BaseComponent2.prototype._warnDeprecations = function(deprecationMap) {
      warnDeprecations(this.className, this.props, deprecationMap);
    };
    BaseComponent2.prototype._warnMutuallyExclusive = function(mutuallyExclusiveMap) {
      warnMutuallyExclusive(this.className, this.props, mutuallyExclusiveMap);
    };
    BaseComponent2.prototype._warnConditionallyRequiredProps = function(requiredProps, conditionalPropName, condition) {
      warnConditionallyRequiredProps(this.className, this.props, requiredProps, conditionalPropName, condition);
    };
    BaseComponent2.prototype._setComponentRef = function(ref, value) {
      if (!this._skipComponentRefResolution && ref) {
        if (typeof ref === "function") {
          ref(value);
        }
        if (typeof ref === "object") {
          ref.current = value;
        }
      }
    };
    return BaseComponent2;
  }(React.Component)
);
function _makeAllSafe(obj, prototype, methodNames) {
  for (var i = 0, len = methodNames.length; i < len; i++) {
    _makeSafe(obj, prototype, methodNames[i]);
  }
}
function _makeSafe(obj, prototype, methodName) {
  var classMethod = obj[methodName];
  var prototypeMethod = prototype[methodName];
  if (classMethod || prototypeMethod) {
    obj[methodName] = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var retVal2;
      if (prototypeMethod) {
        retVal2 = prototypeMethod.apply(this, args);
      }
      if (classMethod !== prototypeMethod) {
        retVal2 = classMethod.apply(this, args);
      }
      return retVal2;
    };
  }
}
function nullRender() {
  return null;
}

// node_modules/@uifabric/utilities/lib/DelayedRender.js
var React2 = __toESM(require_react());
var DelayedRender = (
  /** @class */
  function(_super) {
    __extends(DelayedRender2, _super);
    function DelayedRender2(props) {
      var _this = _super.call(this, props) || this;
      _this.state = {
        isRendered: false
      };
      return _this;
    }
    DelayedRender2.prototype.componentDidMount = function() {
      var _this = this;
      var delay = this.props.delay;
      this._timeoutId = window.setTimeout(function() {
        _this.setState({
          isRendered: true
        });
      }, delay);
    };
    DelayedRender2.prototype.componentWillUnmount = function() {
      if (this._timeoutId) {
        clearTimeout(this._timeoutId);
      }
    };
    DelayedRender2.prototype.render = function() {
      return this.state.isRendered ? React2.Children.only(this.props.children) : null;
    };
    DelayedRender2.defaultProps = {
      delay: 0
    };
    return DelayedRender2;
  }(React2.Component)
);

// node_modules/@uifabric/utilities/lib/FabricPerformance.js
var now = function() {
  return typeof performance !== "undefined" && !!performance.now ? performance.now() : Date.now();
};
var RESET_INTERVAL = 3 * 60 * 1e3;
var FabricPerformance = (
  /** @class */
  function() {
    function FabricPerformance2() {
    }
    FabricPerformance2.measure = function(name, func) {
      if (FabricPerformance2._timeoutId) {
        FabricPerformance2.setPeriodicReset();
      }
      var start = now();
      func();
      var end = now();
      var measurement = FabricPerformance2.summary[name] || {
        totalDuration: 0,
        count: 0,
        all: []
      };
      var duration = end - start;
      measurement.totalDuration += duration;
      measurement.count++;
      measurement.all.push({
        duration,
        timeStamp: end
      });
      FabricPerformance2.summary[name] = measurement;
    };
    FabricPerformance2.reset = function() {
      FabricPerformance2.summary = {};
      clearTimeout(FabricPerformance2._timeoutId);
      FabricPerformance2._timeoutId = NaN;
    };
    FabricPerformance2.setPeriodicReset = function() {
      FabricPerformance2._timeoutId = setTimeout(function() {
        return FabricPerformance2.reset();
      }, RESET_INTERVAL);
    };
    FabricPerformance2.summary = {};
    return FabricPerformance2;
  }()
);

// node_modules/@uifabric/utilities/lib/GlobalSettings.js
var GLOBAL_SETTINGS_PROP_NAME = "__globalSettings__";
var CALLBACK_STATE_PROP_NAME = "__callbacks__";
var _counter = 0;
var GlobalSettings = (
  /** @class */
  function() {
    function GlobalSettings2() {
    }
    GlobalSettings2.getValue = function(key, defaultValue) {
      var globalSettings = _getGlobalSettings();
      if (globalSettings[key] === void 0) {
        globalSettings[key] = typeof defaultValue === "function" ? defaultValue() : defaultValue;
      }
      return globalSettings[key];
    };
    GlobalSettings2.setValue = function(key, value) {
      var globalSettings = _getGlobalSettings();
      var callbacks = globalSettings[CALLBACK_STATE_PROP_NAME];
      var oldValue = globalSettings[key];
      if (value !== oldValue) {
        globalSettings[key] = value;
        var changeDescription = {
          oldValue,
          value,
          key
        };
        for (var id in callbacks) {
          if (callbacks.hasOwnProperty(id)) {
            callbacks[id](changeDescription);
          }
        }
      }
      return value;
    };
    GlobalSettings2.addChangeListener = function(cb) {
      var id = cb.__id__;
      var callbacks = _getCallbacks();
      if (!id) {
        id = cb.__id__ = String(_counter++);
      }
      callbacks[id] = cb;
    };
    GlobalSettings2.removeChangeListener = function(cb) {
      var callbacks = _getCallbacks();
      delete callbacks[cb.__id__];
    };
    return GlobalSettings2;
  }()
);
function _getGlobalSettings() {
  var _a3;
  var win = getWindow();
  var globalObj = win || {};
  if (!globalObj[GLOBAL_SETTINGS_PROP_NAME]) {
    globalObj[GLOBAL_SETTINGS_PROP_NAME] = (_a3 = {}, _a3[CALLBACK_STATE_PROP_NAME] = {}, _a3);
  }
  return globalObj[GLOBAL_SETTINGS_PROP_NAME];
}
function _getCallbacks() {
  var globalSettings = _getGlobalSettings();
  return globalSettings[CALLBACK_STATE_PROP_NAME];
}

// node_modules/@uifabric/utilities/lib/KeyCodes.js
var KeyCodes = {
  backspace: 8,
  tab: 9,
  enter: 13,
  shift: 16,
  ctrl: 17,
  alt: 18,
  pauseBreak: 19,
  capslock: 20,
  escape: 27,
  space: 32,
  pageUp: 33,
  pageDown: 34,
  end: 35,
  home: 36,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  insert: 45,
  del: 46,
  zero: 48,
  one: 49,
  two: 50,
  three: 51,
  four: 52,
  five: 53,
  six: 54,
  seven: 55,
  eight: 56,
  nine: 57,
  a: 65,
  b: 66,
  c: 67,
  d: 68,
  e: 69,
  f: 70,
  g: 71,
  h: 72,
  i: 73,
  j: 74,
  k: 75,
  l: 76,
  m: 77,
  n: 78,
  o: 79,
  p: 80,
  q: 81,
  r: 82,
  s: 83,
  t: 84,
  u: 85,
  v: 86,
  w: 87,
  x: 88,
  y: 89,
  z: 90,
  leftWindow: 91,
  rightWindow: 92,
  select: 93,
  /* eslint-disable @typescript-eslint/naming-convention */
  zero_numpad: 96,
  one_numpad: 97,
  two_numpad: 98,
  three_numpad: 99,
  four_numpad: 100,
  five_numpad: 101,
  six_numpad: 102,
  seven_numpad: 103,
  eight_numpad: 104,
  nine_numpad: 105,
  /* eslint-enable @typescript-eslint/naming-convention */
  multiply: 106,
  add: 107,
  subtract: 109,
  decimalPoint: 110,
  divide: 111,
  f1: 112,
  f2: 113,
  f3: 114,
  f4: 115,
  f5: 116,
  f6: 117,
  f7: 118,
  f8: 119,
  f9: 120,
  f10: 121,
  f11: 122,
  f12: 123,
  numlock: 144,
  scrollLock: 145,
  semicolon: 186,
  equalSign: 187,
  comma: 188,
  dash: 189,
  period: 190,
  forwardSlash: 191,
  graveAccent: 192,
  openBracket: 219,
  backSlash: 220,
  closeBracket: 221,
  singleQuote: 222
};

// node_modules/@uifabric/utilities/lib/Rectangle.js
var Rectangle = (
  /** @class */
  function() {
    function Rectangle2(left, right, top, bottom) {
      if (left === void 0) {
        left = 0;
      }
      if (right === void 0) {
        right = 0;
      }
      if (top === void 0) {
        top = 0;
      }
      if (bottom === void 0) {
        bottom = 0;
      }
      this.top = top;
      this.bottom = bottom;
      this.left = left;
      this.right = right;
    }
    Object.defineProperty(Rectangle2.prototype, "width", {
      /**
       * Calculated automatically by subtracting the right from left
       */
      get: function() {
        return this.right - this.left;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(Rectangle2.prototype, "height", {
      /**
       * Calculated automatically by subtracting the bottom from top.
       */
      get: function() {
        return this.bottom - this.top;
      },
      enumerable: true,
      configurable: true
    });
    Rectangle2.prototype.equals = function(rect) {
      return parseFloat(this.top.toFixed(4)) === parseFloat(rect.top.toFixed(4)) && parseFloat(this.bottom.toFixed(4)) === parseFloat(rect.bottom.toFixed(4)) && parseFloat(this.left.toFixed(4)) === parseFloat(rect.left.toFixed(4)) && parseFloat(this.right.toFixed(4)) === parseFloat(rect.right.toFixed(4));
    };
    return Rectangle2;
  }()
);

// node_modules/@uifabric/utilities/lib/appendFunction.js
function appendFunction(parent) {
  var functions = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    functions[_i - 1] = arguments[_i];
  }
  if (functions.length < 2) {
    return functions[0];
  }
  return function() {
    var args = [];
    for (var _i2 = 0; _i2 < arguments.length; _i2++) {
      args[_i2] = arguments[_i2];
    }
    functions.forEach(function(f) {
      return f && f.apply(parent, args);
    });
  };
}

// node_modules/@uifabric/utilities/lib/aria.js
function mergeAriaAttributeValues() {
  var ariaAttributes = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    ariaAttributes[_i] = arguments[_i];
  }
  var mergedAttribute = ariaAttributes.filter(function(arg) {
    return arg;
  }).join(" ").trim();
  return mergedAttribute === "" ? void 0 : mergedAttribute;
}

// node_modules/@uifabric/utilities/lib/array.js
function findIndex(array, cb, fromIndex) {
  if (fromIndex === void 0) {
    fromIndex = 0;
  }
  var index = -1;
  for (var i = fromIndex; array && i < array.length; i++) {
    if (cb(array[i], i)) {
      index = i;
      break;
    }
  }
  return index;
}
function find(array, cb) {
  var index = findIndex(array, cb);
  if (index < 0) {
    return void 0;
  }
  return array[index];
}
function toMatrix(items, columnCount) {
  return items.reduce(function(rows, currentValue, index) {
    if (index % columnCount === 0) {
      rows.push([currentValue]);
    } else {
      rows[rows.length - 1].push(currentValue);
    }
    return rows;
  }, []);
}
function addElementAtIndex(array, index, itemToAdd) {
  var copy = array.slice();
  copy.splice(index, 0, itemToAdd);
  return copy;
}
function arraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }
  for (var i = 0; i < array1.length; i++) {
    if (array1[i] !== array2[i]) {
      return false;
    }
  }
  return true;
}

// node_modules/@uifabric/utilities/lib/asAsync.js
var React3 = __toESM(require_react());

// node_modules/@uifabric/utilities/lib/sessionStorage.js
function getItem(key) {
  var result = null;
  try {
    var win = getWindow();
    result = win ? win.sessionStorage.getItem(key) : null;
  } catch (e) {
  }
  return result;
}
function setItem(key, data) {
  var _a3;
  try {
    (_a3 = getWindow()) === null || _a3 === void 0 ? void 0 : _a3.sessionStorage.setItem(key, data);
  } catch (e) {
  }
}

// node_modules/@uifabric/utilities/lib/rtl.js
var RTL_LOCAL_STORAGE_KEY = "isRTL";
var _isRTL;
function getRTL2(theme) {
  if (theme === void 0) {
    theme = {};
  }
  if (theme.rtl !== void 0) {
    return theme.rtl;
  }
  if (_isRTL === void 0) {
    var savedRTL = getItem(RTL_LOCAL_STORAGE_KEY);
    if (savedRTL !== null) {
      _isRTL = savedRTL === "1";
      setRTL2(_isRTL);
    }
    var doc = getDocument();
    if (_isRTL === void 0 && doc) {
      _isRTL = (doc.body && doc.body.getAttribute("dir") || doc.documentElement.getAttribute("dir")) === "rtl";
      setRTL(_isRTL);
    }
  }
  return !!_isRTL;
}
function setRTL2(isRTL, persistSetting) {
  if (persistSetting === void 0) {
    persistSetting = false;
  }
  var doc = getDocument();
  if (doc) {
    doc.documentElement.setAttribute("dir", isRTL ? "rtl" : "ltr");
  }
  if (persistSetting) {
    setItem(RTL_LOCAL_STORAGE_KEY, isRTL ? "1" : "0");
  }
  _isRTL = isRTL;
  setRTL(_isRTL);
}
function getRTLSafeKeyCode(key, theme) {
  if (theme === void 0) {
    theme = {};
  }
  if (getRTL2(theme)) {
    if (key === KeyCodes.left) {
      key = KeyCodes.right;
    } else if (key === KeyCodes.right) {
      key = KeyCodes.left;
    }
  }
  return key;
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/isVirtualElement.js
function isVirtualElement(element) {
  return element && !!element._virtual;
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/getVirtualParent.js
function getVirtualParent(child) {
  var parent;
  if (child && isVirtualElement(child)) {
    parent = child._virtual.parent;
  }
  return parent;
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/getParent.js
function getParent(child, allowVirtualParents) {
  if (allowVirtualParents === void 0) {
    allowVirtualParents = true;
  }
  return child && (allowVirtualParents && getVirtualParent(child) || child.parentNode && child.parentNode);
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/elementContains.js
function elementContains(parent, child, allowVirtualParents) {
  if (allowVirtualParents === void 0) {
    allowVirtualParents = true;
  }
  var isContained = false;
  if (parent && child) {
    if (allowVirtualParents) {
      if (parent === child) {
        isContained = true;
      } else {
        isContained = false;
        while (child) {
          var nextParent = getParent(child);
          if (nextParent === parent) {
            isContained = true;
            break;
          }
          child = nextParent;
        }
      }
    } else if (parent.contains) {
      isContained = parent.contains(child);
    }
  }
  return isContained;
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/findElementRecursive.js
function findElementRecursive(element, matchFunction) {
  if (!element || element === document.body) {
    return null;
  }
  return matchFunction(element) ? element : findElementRecursive(getParent(element), matchFunction);
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/elementContainsAttribute.js
function elementContainsAttribute(element, attribute) {
  var elementMatch = findElementRecursive(element, function(testElement) {
    return testElement.hasAttribute(attribute);
  });
  return elementMatch && elementMatch.getAttribute(attribute);
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/setPortalAttribute.js
var DATA_PORTAL_ATTRIBUTE = "data-portal-element";
function setPortalAttribute(element) {
  element.setAttribute(DATA_PORTAL_ATTRIBUTE, "true");
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/portalContainsElement.js
function portalContainsElement(target, parent) {
  var elementMatch = findElementRecursive(target, function(testElement) {
    return parent === testElement || testElement.hasAttribute(DATA_PORTAL_ATTRIBUTE);
  });
  return elementMatch !== null && elementMatch.hasAttribute(DATA_PORTAL_ATTRIBUTE);
}

// node_modules/@uifabric/utilities/node_modules/@fluentui/dom-utilities/lib/setVirtualParent.js
function setVirtualParent(child, parent) {
  var virtualChild = child;
  var virtualParent = parent;
  if (!virtualChild._virtual) {
    virtualChild._virtual = {
      children: []
    };
  }
  var oldParent = virtualChild._virtual.parent;
  if (oldParent && oldParent !== parent) {
    var index = oldParent._virtual.children.indexOf(virtualChild);
    if (index > -1) {
      oldParent._virtual.children.splice(index, 1);
    }
  }
  virtualChild._virtual.parent = virtualParent || void 0;
  if (virtualParent) {
    if (!virtualParent._virtual) {
      virtualParent._virtual = {
        children: []
      };
    }
    virtualParent._virtual.children.push(virtualChild);
  }
}

// node_modules/@uifabric/utilities/lib/dom/on.js
function on(element, eventName, callback, options) {
  element.addEventListener(eventName, callback, options);
  return function() {
    return element.removeEventListener(eventName, callback, options);
  };
}

// node_modules/@uifabric/utilities/lib/classNamesFunction.js
var MAX_CACHE_COUNT = 50;
var DEFAULT_SPECIFICITY_MULTIPLIER = 5;
var _memoizedClassNames = 0;
var stylesheet = Stylesheet.getInstance();
if (stylesheet && stylesheet.onReset) {
  stylesheet.onReset(function() {
    return _memoizedClassNames++;
  });
}
var retVal = "__retval__";
function classNamesFunction(options) {
  if (options === void 0) {
    options = {};
  }
  var map = /* @__PURE__ */ new Map();
  var styleCalcCount = 0;
  var getClassNamesCount = 0;
  var currentMemoizedClassNames = _memoizedClassNames;
  var getClassNames = function(styleFunctionOrObject, styleProps) {
    if (styleProps === void 0) {
      styleProps = {};
    }
    var _a3, _b;
    if (options.useStaticStyles && typeof styleFunctionOrObject === "function" && styleFunctionOrObject.__noStyleOverride__) {
      return styleFunctionOrObject(styleProps);
    }
    getClassNamesCount++;
    var current = map;
    var theme = styleProps.theme;
    var rtl = theme && theme.rtl !== void 0 ? theme.rtl : getRTL2();
    var disableCaching = options.disableCaching;
    if (currentMemoizedClassNames !== _memoizedClassNames) {
      currentMemoizedClassNames = _memoizedClassNames;
      map = /* @__PURE__ */ new Map();
      styleCalcCount = 0;
    }
    if (!options.disableCaching) {
      current = _traverseMap(map, styleFunctionOrObject);
      current = _traverseMap(current, styleProps);
    }
    if (disableCaching || !current[retVal]) {
      if (styleFunctionOrObject === void 0) {
        current[retVal] = {};
      } else {
        current[retVal] = mergeCssSets([
          typeof styleFunctionOrObject === "function" ? styleFunctionOrObject(styleProps) : styleFunctionOrObject
        ], { rtl: !!rtl, specificityMultiplier: options.useStaticStyles ? DEFAULT_SPECIFICITY_MULTIPLIER : void 0 });
      }
      if (!disableCaching) {
        styleCalcCount++;
      }
    }
    if (styleCalcCount > (options.cacheSize || MAX_CACHE_COUNT)) {
      var win = getWindow();
      if ((_b = (_a3 = win) === null || _a3 === void 0 ? void 0 : _a3.FabricConfig) === null || _b === void 0 ? void 0 : _b.enableClassNameCacheFullWarning) {
        console.warn("Styles are being recalculated too frequently. Cache miss rate is " + styleCalcCount + "/" + getClassNamesCount + ".");
        console.trace();
      }
      map.clear();
      styleCalcCount = 0;
      options.disableCaching = true;
    }
    return current[retVal];
  };
  return getClassNames;
}
function _traverseEdge(current, value) {
  value = _normalizeValue(value);
  if (!current.has(value)) {
    current.set(value, /* @__PURE__ */ new Map());
  }
  return current.get(value);
}
function _traverseMap(current, inputs) {
  if (typeof inputs === "function") {
    var cachedInputsFromStyled = inputs.__cachedInputs__;
    if (cachedInputsFromStyled) {
      for (var _i = 0, _a3 = inputs.__cachedInputs__; _i < _a3.length; _i++) {
        var input = _a3[_i];
        current = _traverseEdge(current, input);
      }
    } else {
      current = _traverseEdge(current, inputs);
    }
  } else if (typeof inputs === "object") {
    for (var propName in inputs) {
      if (inputs.hasOwnProperty(propName)) {
        current = _traverseEdge(current, inputs[propName]);
      }
    }
  }
  return current;
}
function _normalizeValue(value) {
  switch (value) {
    case void 0:
      return "__undefined__";
    case null:
      return "__null__";
    default:
      return value;
  }
}

// node_modules/@uifabric/utilities/lib/componentAs/composeComponentAs.js
var React4 = __toESM(require_react());

// node_modules/@uifabric/utilities/lib/memoize.js
var _initializedStylesheetResets = false;
var _resetCounter = 0;
var _emptyObject = { empty: true };
var _dictionary = {};
var _weakMap = typeof WeakMap === "undefined" ? null : WeakMap;
function resetMemoizations() {
  _resetCounter++;
}
function memoizeFunction(cb, maxCacheSize, ignoreNullOrUndefinedResult) {
  if (maxCacheSize === void 0) {
    maxCacheSize = 100;
  }
  if (ignoreNullOrUndefinedResult === void 0) {
    ignoreNullOrUndefinedResult = false;
  }
  if (!_weakMap) {
    return cb;
  }
  if (!_initializedStylesheetResets) {
    var stylesheet2 = Stylesheet.getInstance();
    if (stylesheet2 && stylesheet2.onReset) {
      Stylesheet.getInstance().onReset(resetMemoizations);
    }
    _initializedStylesheetResets = true;
  }
  var rootNode;
  var cacheSize = 0;
  var localResetCounter = _resetCounter;
  return function memoizedFunction() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      args[_i] = arguments[_i];
    }
    var currentNode = rootNode;
    if (rootNode === void 0 || localResetCounter !== _resetCounter || maxCacheSize > 0 && cacheSize > maxCacheSize) {
      rootNode = _createNode();
      cacheSize = 0;
      localResetCounter = _resetCounter;
    }
    currentNode = rootNode;
    for (var i = 0; i < args.length; i++) {
      var arg = _normalizeArg(args[i]);
      if (!currentNode.map.has(arg)) {
        currentNode.map.set(arg, _createNode());
      }
      currentNode = currentNode.map.get(arg);
    }
    if (!currentNode.hasOwnProperty("value")) {
      currentNode.value = cb.apply(void 0, args);
      cacheSize++;
    }
    if (ignoreNullOrUndefinedResult && (currentNode.value === null || currentNode.value === void 0)) {
      currentNode.value = cb.apply(void 0, args);
    }
    return currentNode.value;
  };
}
function createMemoizer(getValue) {
  if (!_weakMap) {
    return getValue;
  }
  var cache = new _weakMap();
  function memoizedGetValue(input) {
    if (!input || typeof input !== "function" && typeof input !== "object") {
      return getValue(input);
    }
    if (cache.has(input)) {
      return cache.get(input);
    }
    var value = getValue(input);
    cache.set(input, value);
    return value;
  }
  return memoizedGetValue;
}
function _normalizeArg(val) {
  if (!val) {
    return _emptyObject;
  } else if (typeof val === "object" || typeof val === "function") {
    return val;
  } else if (!_dictionary[val]) {
    _dictionary[val] = { val };
  }
  return _dictionary[val];
}
function _createNode() {
  return {
    map: _weakMap ? new _weakMap() : null
  };
}

// node_modules/@uifabric/utilities/lib/componentAs/composeComponentAs.js
function createComposedComponent(outer) {
  var Outer = outer;
  var outerMemoizer = createMemoizer(function(inner) {
    if (outer === inner) {
      throw new Error("Attempted to compose a component with itself.");
    }
    var Inner = inner;
    var innerMemoizer = createMemoizer(function(defaultRender) {
      var InnerWithDefaultRender = function(innerProps) {
        return React4.createElement(Inner, __assign2({}, innerProps, { defaultRender }));
      };
      return InnerWithDefaultRender;
    });
    var OuterWithDefaultRender = function(outerProps) {
      var defaultRender = outerProps.defaultRender;
      return React4.createElement(Outer, __assign2({}, outerProps, { defaultRender: defaultRender ? innerMemoizer(defaultRender) : Inner }));
    };
    return OuterWithDefaultRender;
  });
  return outerMemoizer;
}
var componentAsMemoizer = createMemoizer(createComposedComponent);
function composeComponentAs(outer, inner) {
  return componentAsMemoizer(outer)(inner);
}

// node_modules/@uifabric/utilities/lib/controlled.js
function isControlled(props, valueProp) {
  return props[valueProp] !== void 0 && props[valueProp] !== null;
}

// node_modules/@uifabric/utilities/lib/css.js
function css() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  var classes = [];
  for (var _a3 = 0, args_1 = args; _a3 < args_1.length; _a3++) {
    var arg = args_1[_a3];
    if (arg) {
      if (typeof arg === "string") {
        classes.push(arg);
      } else if (arg.hasOwnProperty("toString") && typeof arg.toString === "function") {
        classes.push(arg.toString());
      } else {
        for (var key in arg) {
          if (arg[key]) {
            classes.push(key);
          }
        }
      }
    }
  }
  return classes.join(" ");
}

// node_modules/@uifabric/utilities/lib/customizations/Customizations.js
var CustomizationsGlobalKey = "customizations";
var NO_CUSTOMIZATIONS = { settings: {}, scopedSettings: {}, inCustomizerContext: false };
var _allSettings = GlobalSettings.getValue(CustomizationsGlobalKey, {
  settings: {},
  scopedSettings: {},
  inCustomizerContext: false
});
var _events = [];
var Customizations = (
  /** @class */
  function() {
    function Customizations2() {
    }
    Customizations2.reset = function() {
      _allSettings.settings = {};
      _allSettings.scopedSettings = {};
    };
    Customizations2.applySettings = function(settings) {
      _allSettings.settings = __assign2(__assign2({}, _allSettings.settings), settings);
      Customizations2._raiseChange();
    };
    Customizations2.applyScopedSettings = function(scopeName, settings) {
      _allSettings.scopedSettings[scopeName] = __assign2(__assign2({}, _allSettings.scopedSettings[scopeName]), settings);
      Customizations2._raiseChange();
    };
    Customizations2.getSettings = function(properties, scopeName, localSettings) {
      if (localSettings === void 0) {
        localSettings = NO_CUSTOMIZATIONS;
      }
      var settings = {};
      var localScopedSettings = scopeName && localSettings.scopedSettings[scopeName] || {};
      var globalScopedSettings = scopeName && _allSettings.scopedSettings[scopeName] || {};
      for (var _i = 0, properties_1 = properties; _i < properties_1.length; _i++) {
        var property = properties_1[_i];
        settings[property] = localScopedSettings[property] || localSettings.settings[property] || globalScopedSettings[property] || _allSettings.settings[property];
      }
      return settings;
    };
    Customizations2.applyBatchedUpdates = function(code, suppressUpdate) {
      Customizations2._suppressUpdates = true;
      try {
        code();
      } catch (_a3) {
      }
      Customizations2._suppressUpdates = false;
      if (!suppressUpdate) {
        Customizations2._raiseChange();
      }
    };
    Customizations2.observe = function(onChange) {
      _events.push(onChange);
    };
    Customizations2.unobserve = function(onChange) {
      _events = _events.filter(function(cb) {
        return cb !== onChange;
      });
    };
    Customizations2._raiseChange = function() {
      if (!Customizations2._suppressUpdates) {
        _events.forEach(function(cb) {
          return cb();
        });
      }
    };
    return Customizations2;
  }()
);

// node_modules/@uifabric/utilities/lib/customizations/Customizer.js
var React6 = __toESM(require_react());

// node_modules/@uifabric/utilities/lib/customizations/CustomizerContext.js
var React5 = __toESM(require_react());
var CustomizerContext = React5.createContext({
  customizations: {
    inCustomizerContext: false,
    settings: {},
    scopedSettings: {}
  }
});

// node_modules/@uifabric/utilities/lib/customizations/mergeSettings.js
function mergeSettings(oldSettings, newSettings) {
  if (oldSettings === void 0) {
    oldSettings = {};
  }
  var mergeSettingsWith = _isSettingsFunction(newSettings) ? newSettings : _settingsMergeWith(newSettings);
  return mergeSettingsWith(oldSettings);
}
function mergeScopedSettings(oldSettings, newSettings) {
  if (oldSettings === void 0) {
    oldSettings = {};
  }
  var mergeSettingsWith = _isSettingsFunction(newSettings) ? newSettings : _scopedSettingsMergeWith(newSettings);
  return mergeSettingsWith(oldSettings);
}
function _isSettingsFunction(settings) {
  return typeof settings === "function";
}
function _settingsMergeWith(newSettings) {
  return function(settings) {
    return newSettings ? __assign2(__assign2({}, settings), newSettings) : settings;
  };
}
function _scopedSettingsMergeWith(scopedSettingsFromProps) {
  if (scopedSettingsFromProps === void 0) {
    scopedSettingsFromProps = {};
  }
  return function(oldScopedSettings) {
    var newScopedSettings = __assign2({}, oldScopedSettings);
    for (var scopeName in scopedSettingsFromProps) {
      if (scopedSettingsFromProps.hasOwnProperty(scopeName)) {
        newScopedSettings[scopeName] = __assign2(__assign2({}, oldScopedSettings[scopeName]), scopedSettingsFromProps[scopeName]);
      }
    }
    return newScopedSettings;
  };
}

// node_modules/@uifabric/utilities/lib/customizations/mergeCustomizations.js
function mergeCustomizations(props, parentContext) {
  var _a3 = (parentContext || {}).customizations, customizations = _a3 === void 0 ? { settings: {}, scopedSettings: {} } : _a3;
  return {
    customizations: {
      settings: mergeSettings(customizations.settings, props.settings),
      scopedSettings: mergeScopedSettings(customizations.scopedSettings, props.scopedSettings),
      inCustomizerContext: true
    }
  };
}

// node_modules/@uifabric/utilities/lib/customizations/Customizer.js
var Customizer = (
  /** @class */
  function(_super) {
    __extends(Customizer2, _super);
    function Customizer2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this._onCustomizationChange = function() {
        return _this.forceUpdate();
      };
      return _this;
    }
    Customizer2.prototype.componentDidMount = function() {
      Customizations.observe(this._onCustomizationChange);
    };
    Customizer2.prototype.componentWillUnmount = function() {
      Customizations.unobserve(this._onCustomizationChange);
    };
    Customizer2.prototype.render = function() {
      var _this = this;
      var contextTransform = this.props.contextTransform;
      return React6.createElement(CustomizerContext.Consumer, null, function(parentContext) {
        var newContext = mergeCustomizations(_this.props, parentContext);
        if (contextTransform) {
          newContext = contextTransform(newContext);
        }
        return React6.createElement(CustomizerContext.Provider, { value: newContext }, _this.props.children);
      });
    };
    return Customizer2;
  }(React6.Component)
);

// node_modules/@uifabric/utilities/lib/customizations/customizable.js
var React7 = __toESM(require_react());

// node_modules/@uifabric/utilities/lib/hoistStatics.js
function hoistStatics(source, dest) {
  for (var name_1 in source) {
    if (source.hasOwnProperty(name_1)) {
      dest[name_1] = source[name_1];
    }
  }
  return dest;
}

// node_modules/@uifabric/utilities/lib/customizations/customizable.js
function customizable(scope, fields, concatStyles) {
  return function customizableFactory(ComposedComponent) {
    var _a3;
    var resultClass = (_a3 = /** @class */
    function(_super) {
      __extends(ComponentWithInjectedProps, _super);
      function ComponentWithInjectedProps(props) {
        var _this = _super.call(this, props) || this;
        _this._styleCache = {};
        _this._onSettingChanged = _this._onSettingChanged.bind(_this);
        return _this;
      }
      ComponentWithInjectedProps.prototype.componentDidMount = function() {
        Customizations.observe(this._onSettingChanged);
      };
      ComponentWithInjectedProps.prototype.componentWillUnmount = function() {
        Customizations.unobserve(this._onSettingChanged);
      };
      ComponentWithInjectedProps.prototype.render = function() {
        var _this = this;
        return React7.createElement(CustomizerContext.Consumer, null, function(context) {
          var defaultProps = Customizations.getSettings(fields, scope, context.customizations);
          var componentProps = _this.props;
          if (defaultProps.styles && typeof defaultProps.styles === "function") {
            defaultProps.styles = defaultProps.styles(__assign2(__assign2({}, defaultProps), componentProps));
          }
          if (concatStyles && defaultProps.styles) {
            if (_this._styleCache.default !== defaultProps.styles || _this._styleCache.component !== componentProps.styles) {
              var mergedStyles = concatStyleSets(defaultProps.styles, componentProps.styles);
              _this._styleCache.default = defaultProps.styles;
              _this._styleCache.component = componentProps.styles;
              _this._styleCache.merged = mergedStyles;
            }
            return React7.createElement(ComposedComponent, __assign2({}, defaultProps, componentProps, { styles: _this._styleCache.merged }));
          }
          return React7.createElement(ComposedComponent, __assign2({}, defaultProps, componentProps));
        });
      };
      ComponentWithInjectedProps.prototype._onSettingChanged = function() {
        this.forceUpdate();
      };
      return ComponentWithInjectedProps;
    }(React7.Component), _a3.displayName = "Customized" + scope, _a3);
    return hoistStatics(ComposedComponent, resultClass);
  };
}

// node_modules/@uifabric/utilities/lib/customizations/useCustomizationSettings.js
var React8 = __toESM(require_react());
function useCustomizationSettings(properties, scopeName) {
  var forceUpdate = useForceUpdate();
  var customizations = React8.useContext(CustomizerContext).customizations;
  var inCustomizerContext = customizations.inCustomizerContext;
  React8.useEffect(function() {
    if (!inCustomizerContext) {
      Customizations.observe(forceUpdate);
    }
    return function() {
      if (!inCustomizerContext) {
        Customizations.unobserve(forceUpdate);
      }
    };
  }, [inCustomizerContext]);
  return Customizations.getSettings(properties, scopeName, customizations);
}
function useForceUpdate() {
  var _a3 = React8.useState(0), setValue = _a3[1];
  return function() {
    return setValue(function(value) {
      return ++value;
    });
  };
}

// node_modules/@uifabric/utilities/lib/extendComponent.js
function extendComponent(parent, methods) {
  for (var name_1 in methods) {
    if (methods.hasOwnProperty(name_1)) {
      parent[name_1] = appendFunction(parent, parent[name_1], methods[name_1]);
    }
  }
}

// node_modules/@uifabric/utilities/lib/focus.js
var IS_FOCUSABLE_ATTRIBUTE = "data-is-focusable";
var IS_VISIBLE_ATTRIBUTE = "data-is-visible";
var FOCUSZONE_ID_ATTRIBUTE = "data-focuszone-id";
var FOCUSZONE_SUB_ATTRIBUTE = "data-is-sub-focuszone";
function getFirstFocusable(rootElement, currentElement, includeElementsInFocusZones) {
  return getNextElement(rootElement, currentElement, true, false, false, includeElementsInFocusZones);
}
function getLastFocusable(rootElement, currentElement, includeElementsInFocusZones) {
  return getPreviousElement(rootElement, currentElement, true, false, true, includeElementsInFocusZones);
}
function getFirstTabbable(rootElement, currentElement, includeElementsInFocusZones, checkNode) {
  if (checkNode === void 0) {
    checkNode = true;
  }
  return getNextElement(
    rootElement,
    currentElement,
    checkNode,
    false,
    false,
    includeElementsInFocusZones,
    false,
    true
    /*tabbable*/
  );
}
function getLastTabbable(rootElement, currentElement, includeElementsInFocusZones, checkNode) {
  if (checkNode === void 0) {
    checkNode = true;
  }
  return getPreviousElement(
    rootElement,
    currentElement,
    checkNode,
    false,
    true,
    includeElementsInFocusZones,
    false,
    true
    /*tabbable*/
  );
}
function focusFirstChild(rootElement) {
  var element = getNextElement(rootElement, rootElement, true, false, false, true);
  if (element) {
    focusAsync(element);
    return true;
  }
  return false;
}
function getPreviousElement(rootElement, currentElement, checkNode, suppressParentTraversal, traverseChildren, includeElementsInFocusZones, allowFocusRoot, tabbable) {
  if (!currentElement || !allowFocusRoot && currentElement === rootElement) {
    return null;
  }
  var isCurrentElementVisible = isElementVisible(currentElement);
  if (traverseChildren && isCurrentElementVisible && (includeElementsInFocusZones || !(isElementFocusZone(currentElement) || isElementFocusSubZone(currentElement)))) {
    var childMatch = getPreviousElement(rootElement, currentElement.lastElementChild, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
    if (childMatch) {
      if (tabbable && isElementTabbable(childMatch, true) || !tabbable) {
        return childMatch;
      }
      var childMatchSiblingMatch = getPreviousElement(rootElement, childMatch.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
      if (childMatchSiblingMatch) {
        return childMatchSiblingMatch;
      }
      var childMatchParent = childMatch.parentElement;
      while (childMatchParent && childMatchParent !== currentElement) {
        var childMatchParentMatch = getPreviousElement(rootElement, childMatchParent.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
        if (childMatchParentMatch) {
          return childMatchParentMatch;
        }
        childMatchParent = childMatchParent.parentElement;
      }
    }
  }
  if (checkNode && isCurrentElementVisible && isElementTabbable(currentElement, tabbable)) {
    return currentElement;
  }
  var siblingMatch = getPreviousElement(rootElement, currentElement.previousElementSibling, true, true, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
  if (siblingMatch) {
    return siblingMatch;
  }
  if (!suppressParentTraversal) {
    return getPreviousElement(rootElement, currentElement.parentElement, true, false, false, includeElementsInFocusZones, allowFocusRoot, tabbable);
  }
  return null;
}
function getNextElement(rootElement, currentElement, checkNode, suppressParentTraversal, suppressChildTraversal, includeElementsInFocusZones, allowFocusRoot, tabbable) {
  if (!currentElement || currentElement === rootElement && suppressChildTraversal && !allowFocusRoot) {
    return null;
  }
  var isCurrentElementVisible = isElementVisible(currentElement);
  if (checkNode && isCurrentElementVisible && isElementTabbable(currentElement, tabbable)) {
    return currentElement;
  }
  if (!suppressChildTraversal && isCurrentElementVisible && (includeElementsInFocusZones || !(isElementFocusZone(currentElement) || isElementFocusSubZone(currentElement)))) {
    var childMatch = getNextElement(rootElement, currentElement.firstElementChild, true, true, false, includeElementsInFocusZones, allowFocusRoot, tabbable);
    if (childMatch) {
      return childMatch;
    }
  }
  if (currentElement === rootElement) {
    return null;
  }
  var siblingMatch = getNextElement(rootElement, currentElement.nextElementSibling, true, true, false, includeElementsInFocusZones, allowFocusRoot, tabbable);
  if (siblingMatch) {
    return siblingMatch;
  }
  if (!suppressParentTraversal) {
    return getNextElement(rootElement, currentElement.parentElement, false, false, true, includeElementsInFocusZones, allowFocusRoot, tabbable);
  }
  return null;
}
function isElementVisible(element) {
  if (!element || !element.getAttribute) {
    return false;
  }
  var visibilityAttribute = element.getAttribute(IS_VISIBLE_ATTRIBUTE);
  if (visibilityAttribute !== null && visibilityAttribute !== void 0) {
    return visibilityAttribute === "true";
  }
  return element.offsetHeight !== 0 || element.offsetParent !== null || // eslint-disable-next-line @typescript-eslint/no-explicit-any
  element.isVisible === true;
}
function isElementTabbable(element, checkTabIndex) {
  if (!element || element.disabled) {
    return false;
  }
  var tabIndex = 0;
  var tabIndexAttributeValue = null;
  if (element && element.getAttribute) {
    tabIndexAttributeValue = element.getAttribute("tabIndex");
    if (tabIndexAttributeValue) {
      tabIndex = parseInt(tabIndexAttributeValue, 10);
    }
  }
  var isFocusableAttribute = element.getAttribute ? element.getAttribute(IS_FOCUSABLE_ATTRIBUTE) : null;
  var isTabIndexSet = tabIndexAttributeValue !== null && tabIndex >= 0;
  var result = !!element && isFocusableAttribute !== "false" && (element.tagName === "A" || element.tagName === "BUTTON" || element.tagName === "INPUT" || element.tagName === "TEXTAREA" || element.tagName === "SELECT" || isFocusableAttribute === "true" || isTabIndexSet);
  return checkTabIndex ? tabIndex !== -1 && result : result;
}
function isElementFocusZone(element) {
  return !!(element && element.getAttribute && !!element.getAttribute(FOCUSZONE_ID_ATTRIBUTE));
}
function isElementFocusSubZone(element) {
  return !!(element && element.getAttribute && element.getAttribute(FOCUSZONE_SUB_ATTRIBUTE) === "true");
}
function doesElementContainFocus(element) {
  var document2 = getDocument(element);
  var currentActiveElement = document2 && document2.activeElement;
  if (currentActiveElement && elementContains(element, currentActiveElement)) {
    return true;
  }
  return false;
}
function shouldWrapFocus(element, noWrapDataAttribute) {
  return elementContainsAttribute(element, noWrapDataAttribute) === "true" ? false : true;
}
var targetToFocusOnNextRepaint = void 0;
function focusAsync(element) {
  if (element) {
    if (targetToFocusOnNextRepaint) {
      targetToFocusOnNextRepaint = element;
      return;
    }
    targetToFocusOnNextRepaint = element;
    var win = getWindow(element);
    if (win) {
      win.requestAnimationFrame(function() {
        var focusableElement = targetToFocusOnNextRepaint;
        targetToFocusOnNextRepaint = void 0;
        if (focusableElement) {
          if (focusableElement.getAttribute && focusableElement.getAttribute(IS_FOCUSABLE_ATTRIBUTE) === "true") {
            if (!focusableElement.getAttribute("tabindex")) {
              focusableElement.setAttribute("tabindex", "0");
            }
          }
          focusableElement.focus();
        }
      });
    }
  }
}
function getFocusableByIndexPath(parent, path) {
  var element = parent;
  for (var _i = 0, path_1 = path; _i < path_1.length; _i++) {
    var index = path_1[_i];
    var nextChild = element.children[Math.min(index, element.children.length - 1)];
    if (!nextChild) {
      break;
    }
    element = nextChild;
  }
  element = isElementTabbable(element) && isElementVisible(element) ? element : getNextElement(parent, element, true) || getPreviousElement(parent, element);
  return element;
}
function getElementIndexPath(fromElement, toElement) {
  var path = [];
  while (toElement && fromElement && toElement !== fromElement) {
    var parent_1 = getParent(toElement, true);
    if (parent_1 === null) {
      return [];
    }
    path.unshift(Array.prototype.indexOf.call(parent_1.children, toElement));
    toElement = parent_1;
  }
  return path;
}

// node_modules/@uifabric/utilities/lib/getId.js
var CURRENT_ID_PROPERTY = "__currentId__";
var DEFAULT_ID_STRING = "id__";
var _global2 = getWindow() || {};
if (_global2[CURRENT_ID_PROPERTY] === void 0) {
  _global2[CURRENT_ID_PROPERTY] = 0;
}
var _initializedStylesheetResets2 = false;
function getId(prefix) {
  if (!_initializedStylesheetResets2) {
    var stylesheet2 = Stylesheet.getInstance();
    if (stylesheet2 && stylesheet2.onReset) {
      stylesheet2.onReset(resetIds);
    }
    _initializedStylesheetResets2 = true;
  }
  var index = _global2[CURRENT_ID_PROPERTY]++;
  return (prefix === void 0 ? DEFAULT_ID_STRING : prefix) + index;
}
function resetIds(counter) {
  if (counter === void 0) {
    counter = 0;
  }
  _global2[CURRENT_ID_PROPERTY] = counter;
}

// node_modules/@uifabric/utilities/lib/properties.js
var toObjectMap = function() {
  var items = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    items[_i] = arguments[_i];
  }
  var result = {};
  for (var _a3 = 0, items_1 = items; _a3 < items_1.length; _a3++) {
    var item = items_1[_a3];
    var keys = Array.isArray(item) ? item : Object.keys(item);
    for (var _b = 0, keys_1 = keys; _b < keys_1.length; _b++) {
      var key = keys_1[_b];
      result[key] = 1;
    }
  }
  return result;
};
var baseElementEvents = toObjectMap([
  "onCopy",
  "onCut",
  "onPaste",
  "onCompositionEnd",
  "onCompositionStart",
  "onCompositionUpdate",
  "onFocus",
  "onFocusCapture",
  "onBlur",
  "onBlurCapture",
  "onChange",
  "onInput",
  "onSubmit",
  "onLoad",
  "onError",
  "onKeyDown",
  "onKeyDownCapture",
  "onKeyPress",
  "onKeyUp",
  "onAbort",
  "onCanPlay",
  "onCanPlayThrough",
  "onDurationChange",
  "onEmptied",
  "onEncrypted",
  "onEnded",
  "onLoadedData",
  "onLoadedMetadata",
  "onLoadStart",
  "onPause",
  "onPlay",
  "onPlaying",
  "onProgress",
  "onRateChange",
  "onSeeked",
  "onSeeking",
  "onStalled",
  "onSuspend",
  "onTimeUpdate",
  "onVolumeChange",
  "onWaiting",
  "onClick",
  "onClickCapture",
  "onContextMenu",
  "onDoubleClick",
  "onDrag",
  "onDragEnd",
  "onDragEnter",
  "onDragExit",
  "onDragLeave",
  "onDragOver",
  "onDragStart",
  "onDrop",
  "onMouseDown",
  "onMouseDownCapture",
  "onMouseEnter",
  "onMouseLeave",
  "onMouseMove",
  "onMouseOut",
  "onMouseOver",
  "onMouseUp",
  "onMouseUpCapture",
  "onSelect",
  "onTouchCancel",
  "onTouchEnd",
  "onTouchMove",
  "onTouchStart",
  "onScroll",
  "onWheel",
  "onPointerCancel",
  "onPointerDown",
  "onPointerEnter",
  "onPointerLeave",
  "onPointerMove",
  "onPointerOut",
  "onPointerOver",
  "onPointerUp",
  "onGotPointerCapture",
  "onLostPointerCapture"
]);
var baseElementProperties = toObjectMap([
  "accessKey",
  "children",
  "className",
  "contentEditable",
  "dir",
  "draggable",
  "hidden",
  "htmlFor",
  "id",
  "lang",
  "ref",
  "role",
  "style",
  "tabIndex",
  "title",
  "translate",
  "spellCheck",
  "name"
]);
var htmlElementProperties = toObjectMap(baseElementProperties, baseElementEvents);
var labelProperties = toObjectMap(htmlElementProperties, [
  "form"
]);
var audioProperties = toObjectMap(htmlElementProperties, [
  "height",
  "loop",
  "muted",
  "preload",
  "src",
  "width"
]);
var videoProperties = toObjectMap(audioProperties, [
  "poster"
]);
var olProperties = toObjectMap(htmlElementProperties, [
  "start"
]);
var liProperties = toObjectMap(htmlElementProperties, [
  "value"
]);
var anchorProperties = toObjectMap(htmlElementProperties, [
  "download",
  "href",
  "hrefLang",
  "media",
  "rel",
  "target",
  "type"
]);
var buttonProperties = toObjectMap(htmlElementProperties, [
  "autoFocus",
  "disabled",
  "form",
  "formAction",
  "formEncType",
  "formMethod",
  "formNoValidate",
  "formTarget",
  "type",
  "value"
]);
var inputProperties = toObjectMap(buttonProperties, [
  "accept",
  "alt",
  "autoCapitalize",
  "autoComplete",
  "checked",
  "dirname",
  "form",
  "height",
  "inputMode",
  "list",
  "max",
  "maxLength",
  "min",
  "multiple",
  "pattern",
  "placeholder",
  "readOnly",
  "required",
  "src",
  "step",
  "size",
  "type",
  "value",
  "width"
]);
var textAreaProperties = toObjectMap(buttonProperties, [
  "autoCapitalize",
  "cols",
  "dirname",
  "form",
  "maxLength",
  "placeholder",
  "readOnly",
  "required",
  "rows",
  "wrap"
]);
var selectProperties = toObjectMap(buttonProperties, [
  "form",
  "multiple",
  "required"
]);
var optionProperties = toObjectMap(htmlElementProperties, [
  "selected",
  "value"
]);
var tableProperties = toObjectMap(htmlElementProperties, [
  "cellPadding",
  "cellSpacing"
]);
var trProperties = htmlElementProperties;
var thProperties = toObjectMap(htmlElementProperties, [
  "rowSpan",
  "scope"
]);
var tdProperties = toObjectMap(htmlElementProperties, [
  "colSpan",
  "headers",
  "rowSpan",
  "scope"
]);
var colGroupProperties = toObjectMap(htmlElementProperties, [
  "span"
]);
var colProperties = toObjectMap(htmlElementProperties, [
  "span"
]);
var formProperties = toObjectMap(htmlElementProperties, [
  "acceptCharset",
  "action",
  "encType",
  "encType",
  "method",
  "noValidate",
  "target"
]);
var iframeProperties = toObjectMap(htmlElementProperties, [
  "allow",
  "allowFullScreen",
  "allowPaymentRequest",
  "allowTransparency",
  "csp",
  "height",
  "importance",
  "referrerPolicy",
  "sandbox",
  "src",
  "srcDoc",
  "width"
]);
var imgProperties = toObjectMap(htmlElementProperties, [
  "alt",
  "crossOrigin",
  "height",
  "src",
  "srcSet",
  "useMap",
  "width"
]);
var divProperties = htmlElementProperties;
function getNativeProps(props, allowedPropNames, excludedPropNames) {
  var _a3;
  var isArray = Array.isArray(allowedPropNames);
  var result = {};
  var keys = Object.keys(props);
  for (var _i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
    var key = keys_2[_i];
    var isNativeProp = !isArray && allowedPropNames[key] || isArray && allowedPropNames.indexOf(key) >= 0 || key.indexOf("data-") === 0 || key.indexOf("aria-") === 0;
    if (isNativeProp && (!excludedPropNames || ((_a3 = excludedPropNames) === null || _a3 === void 0 ? void 0 : _a3.indexOf(key)) === -1)) {
      result[key] = props[key];
    }
  }
  return result;
}

// node_modules/@uifabric/utilities/lib/getNativeElementProps.js
var nativeElementMap = {
  label: labelProperties,
  audio: audioProperties,
  video: videoProperties,
  ol: olProperties,
  li: liProperties,
  a: anchorProperties,
  button: buttonProperties,
  input: inputProperties,
  textarea: textAreaProperties,
  select: selectProperties,
  option: optionProperties,
  table: tableProperties,
  tr: trProperties,
  th: thProperties,
  td: tdProperties,
  colGroup: colGroupProperties,
  col: colProperties,
  form: formProperties,
  iframe: iframeProperties,
  img: imgProperties
};
function getNativeElementProps(tagName, props, excludedPropNames) {
  var allowedPropNames = tagName && nativeElementMap[tagName] || htmlElementProperties;
  return getNativeProps(props, allowedPropNames, excludedPropNames);
}

// node_modules/@uifabric/utilities/lib/hoist.js
var REACT_LIFECYCLE_EXCLUSIONS = [
  "setState",
  "render",
  "componentWillMount",
  "UNSAFE_componentWillMount",
  "componentDidMount",
  "componentWillReceiveProps",
  "UNSAFE_componentWillReceiveProps",
  "shouldComponentUpdate",
  "componentWillUpdate",
  "getSnapshotBeforeUpdate",
  "UNSAFE_componentWillUpdate",
  "componentDidUpdate",
  "componentWillUnmount"
];
function hoistMethods(destination, source, exclusions) {
  if (exclusions === void 0) {
    exclusions = REACT_LIFECYCLE_EXCLUSIONS;
  }
  var hoisted = [];
  var _loop_1 = function(methodName2) {
    if (typeof source[methodName2] === "function" && destination[methodName2] === void 0 && (!exclusions || exclusions.indexOf(methodName2) === -1)) {
      hoisted.push(methodName2);
      destination[methodName2] = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        source[methodName2].apply(source, args);
      };
    }
  };
  for (var methodName in source) {
    _loop_1(methodName);
  }
  return hoisted;
}
function unhoistMethods(source, methodNames) {
  methodNames.forEach(function(methodName) {
    return delete source[methodName];
  });
}

// node_modules/@uifabric/utilities/lib/initializeComponentRef.js
function initializeComponentRef(obj) {
  extendComponent(obj, {
    componentDidMount: _onMount,
    componentDidUpdate: _onUpdate,
    componentWillUnmount: _onUnmount
  });
}
function _onMount() {
  _setComponentRef(this.props.componentRef, this);
}
function _onUpdate(prevProps) {
  if (prevProps.componentRef !== this.props.componentRef) {
    _setComponentRef(prevProps.componentRef, null);
    _setComponentRef(this.props.componentRef, this);
  }
}
function _onUnmount() {
  _setComponentRef(this.props.componentRef, null);
}
function _setComponentRef(componentRef, value) {
  if (componentRef) {
    if (typeof componentRef === "object") {
      componentRef.current = value;
    } else if (typeof componentRef === "function") {
      componentRef(value);
    }
  }
}

// node_modules/@uifabric/utilities/lib/keyboard.js
var _a2;
var DirectionalKeyCodes = (_a2 = {}, _a2[KeyCodes.up] = 1, _a2[KeyCodes.down] = 1, _a2[KeyCodes.left] = 1, _a2[KeyCodes.right] = 1, _a2[KeyCodes.home] = 1, _a2[KeyCodes.end] = 1, _a2[KeyCodes.tab] = 1, _a2[KeyCodes.pageUp] = 1, _a2[KeyCodes.pageDown] = 1, _a2);
function isDirectionalKeyCode(which) {
  return !!DirectionalKeyCodes[which];
}

// node_modules/@uifabric/utilities/lib/setFocusVisibility.js
var IsFocusVisibleClassName = "ms-Fabric--isFocusVisible";
var IsFocusHiddenClassName = "ms-Fabric--isFocusHidden";
function setFocusVisibility(enabled, target) {
  var win = target ? getWindow(target) : getWindow();
  if (win) {
    var classList = win.document.body.classList;
    classList.add(enabled ? IsFocusVisibleClassName : IsFocusHiddenClassName);
    classList.remove(enabled ? IsFocusHiddenClassName : IsFocusVisibleClassName);
  }
}

// node_modules/@uifabric/utilities/lib/useFocusRects.js
var React9 = __toESM(require_react());
var mountCounters = /* @__PURE__ */ new WeakMap();
function setMountCounters(key, delta) {
  var newValue;
  var currValue = mountCounters.get(key);
  if (currValue) {
    newValue = currValue + delta;
  } else {
    newValue = 1;
  }
  mountCounters.set(key, newValue);
  return newValue;
}
function useFocusRects(rootRef) {
  React9.useEffect(function() {
    var _a3, _b;
    var win = getWindow((_a3 = rootRef) === null || _a3 === void 0 ? void 0 : _a3.current);
    if (!win || ((_b = win.FabricConfig) === null || _b === void 0 ? void 0 : _b.disableFocusRects) === true) {
      return void 0;
    }
    var count = setMountCounters(win, 1);
    if (count <= 1) {
      win.addEventListener("mousedown", _onMouseDown, true);
      win.addEventListener("pointerdown", _onPointerDown, true);
      win.addEventListener("keydown", _onKeyDown, true);
    }
    return function() {
      var _a4;
      if (!win || ((_a4 = win.FabricConfig) === null || _a4 === void 0 ? void 0 : _a4.disableFocusRects) === true) {
        return;
      }
      count = setMountCounters(win, -1);
      if (count === 0) {
        win.removeEventListener("mousedown", _onMouseDown, true);
        win.removeEventListener("pointerdown", _onPointerDown, true);
        win.removeEventListener("keydown", _onKeyDown, true);
      }
    };
  }, [rootRef]);
}
var FocusRects = function(props) {
  useFocusRects(props.rootRef);
  return null;
};
function _onMouseDown(ev) {
  setFocusVisibility(false, ev.target);
}
function _onPointerDown(ev) {
  if (ev.pointerType !== "mouse") {
    setFocusVisibility(false, ev.target);
  }
}
function _onKeyDown(ev) {
  if (isDirectionalKeyCode(ev.which)) {
    setFocusVisibility(true, ev.target);
  }
}

// node_modules/@uifabric/utilities/lib/initials.js
var UNWANTED_ENCLOSURES_REGEX = /[\(\[\{][^\)\]\}]*[\)\]\}]/g;
var UNWANTED_CHARS_REGEX = /[\0-\u001F\!-/:-@\[-`\{-\u00BF\u0250-\u036F\uD800-\uFFFF]/g;
var PHONENUMBER_REGEX = /^\d+[\d\s]*(:?ext|x|)\s*\d+$/i;
var MULTIPLE_WHITESPACES_REGEX = /\s+/g;
var UNSUPPORTED_TEXT_REGEX = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uAC00-\uD7AF\uD7B0-\uD7FF\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]|[\uD840-\uD869][\uDC00-\uDED6]/;
function getInitialsLatin(displayName, isRtl) {
  var initials = "";
  var splits = displayName.split(" ");
  if (splits.length === 2) {
    initials += splits[0].charAt(0).toUpperCase();
    initials += splits[1].charAt(0).toUpperCase();
  } else if (splits.length === 3) {
    initials += splits[0].charAt(0).toUpperCase();
    initials += splits[2].charAt(0).toUpperCase();
  } else if (splits.length !== 0) {
    initials += splits[0].charAt(0).toUpperCase();
  }
  if (isRtl && initials.length > 1) {
    return initials.charAt(1) + initials.charAt(0);
  }
  return initials;
}
function cleanupDisplayName(displayName) {
  displayName = displayName.replace(UNWANTED_ENCLOSURES_REGEX, "");
  displayName = displayName.replace(UNWANTED_CHARS_REGEX, "");
  displayName = displayName.replace(MULTIPLE_WHITESPACES_REGEX, " ");
  displayName = displayName.trim();
  return displayName;
}
function getInitials(displayName, isRtl, allowPhoneInitials) {
  if (!displayName) {
    return "";
  }
  displayName = cleanupDisplayName(displayName);
  if (UNSUPPORTED_TEXT_REGEX.test(displayName) || !allowPhoneInitials && PHONENUMBER_REGEX.test(displayName)) {
    return "";
  }
  return getInitialsLatin(displayName, isRtl);
}

// node_modules/@uifabric/utilities/lib/localStorage.js
function getItem2(key) {
  var result = null;
  try {
    var win = getWindow();
    result = win ? win.localStorage.getItem(key) : null;
  } catch (e) {
  }
  return result;
}

// node_modules/@uifabric/utilities/lib/language.js
var _language;
var STORAGE_KEY = "language";
function getLanguage(persistenceType) {
  if (persistenceType === void 0) {
    persistenceType = "localStorage";
  }
  if (_language === void 0) {
    var doc = getDocument();
    var savedLanguage = persistenceType === "localStorage" ? getItem2(STORAGE_KEY) : persistenceType === "sessionStorage" ? getItem(STORAGE_KEY) : void 0;
    if (savedLanguage) {
      _language = savedLanguage;
    }
    if (_language === void 0 && doc) {
      _language = doc.documentElement.getAttribute("lang");
    }
    if (_language === void 0) {
      _language = "en";
    }
  }
  return _language;
}

// node_modules/@uifabric/utilities/lib/math.js
function getDistanceBetweenPoints(point1, point2) {
  var left1 = point1.left || point1.x || 0;
  var top1 = point1.top || point1.y || 0;
  var left2 = point2.left || point2.x || 0;
  var top2 = point2.top || point2.y || 0;
  var distance = Math.sqrt(Math.pow(left1 - left2, 2) + Math.pow(top1 - top2, 2));
  return distance;
}
function calculatePrecision(value) {
  var groups = /[1-9]([0]+$)|\.([0-9]*)/.exec(String(value));
  if (!groups) {
    return 0;
  }
  if (groups[1]) {
    return -groups[1].length;
  }
  if (groups[2]) {
    return groups[2].length;
  }
  return 0;
}
function precisionRound(value, precision, base) {
  if (base === void 0) {
    base = 10;
  }
  var exp = Math.pow(base, precision);
  return Math.round(value * exp) / exp;
}

// node_modules/@uifabric/utilities/lib/merge.js
function merge(target) {
  var args = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    args[_i - 1] = arguments[_i];
  }
  for (var _a3 = 0, args_1 = args; _a3 < args_1.length; _a3++) {
    var arg = args_1[_a3];
    _merge(target || {}, arg);
  }
  return target;
}
function _merge(target, source, circularReferences) {
  if (circularReferences === void 0) {
    circularReferences = [];
  }
  circularReferences.push(source);
  for (var name_1 in source) {
    if (source.hasOwnProperty(name_1)) {
      if (name_1 !== "__proto__" && name_1 !== "constructor" && name_1 !== "prototype") {
        var value = source[name_1];
        if (typeof value === "object" && value !== null && !Array.isArray(value)) {
          var isCircularReference = circularReferences.indexOf(value) > -1;
          target[name_1] = isCircularReference ? value : _merge(target[name_1] || {}, value, circularReferences);
        } else {
          target[name_1] = value;
        }
      }
    }
  }
  circularReferences.pop();
  return target;
}

// node_modules/@uifabric/utilities/lib/mobileDetector.js
var isIOS = function() {
  if (!window || !window.navigator || !window.navigator.userAgent) {
    return false;
  }
  return /iPad|iPhone|iPod/i.test(window.navigator.userAgent);
};

// node_modules/@uifabric/utilities/lib/modalize.js
function modalize(target) {
  var _a3;
  var affectedNodes = [];
  var targetDocument = getDocument(target) || document;
  while (target !== targetDocument.body) {
    for (var _i = 0, _b = target.parentElement.children; _i < _b.length; _i++) {
      var sibling = _b[_i];
      if (sibling !== target && ((_a3 = sibling.getAttribute("aria-hidden")) === null || _a3 === void 0 ? void 0 : _a3.toLowerCase()) !== "true") {
        affectedNodes.push(sibling);
      }
    }
    if (!target.parentElement) {
      break;
    }
    target = target.parentElement;
  }
  affectedNodes.forEach(function(node) {
    node.setAttribute("aria-hidden", "true");
  });
  return function() {
    unmodalize(affectedNodes);
    affectedNodes = [];
  };
}
function unmodalize(affectedNodes) {
  affectedNodes.forEach(function(node) {
    node.setAttribute("aria-hidden", "false");
  });
}

// node_modules/@uifabric/utilities/lib/osDetector.js
var isMacResult;
function isMac(reset) {
  if (typeof isMacResult === "undefined" || reset) {
    var win = getWindow();
    var userAgent = win && win.navigator.userAgent;
    isMacResult = !!userAgent && userAgent.indexOf("Macintosh") !== -1;
  }
  return !!isMacResult;
}

// node_modules/@uifabric/utilities/lib/overflow.js
function hasHorizontalOverflow(element) {
  return element.clientWidth < element.scrollWidth;
}
function hasVerticalOverflow(element) {
  return element.clientHeight < element.scrollHeight;
}
function hasOverflow(element) {
  return hasHorizontalOverflow(element) || hasVerticalOverflow(element);
}

// node_modules/@uifabric/utilities/lib/renderFunction/composeRenderFunction.js
function createComposedRenderFunction(outer) {
  var outerMemoizer = createMemoizer(function(inner) {
    var innerMemoizer = createMemoizer(function(defaultRender) {
      return function(innerProps) {
        return inner(innerProps, defaultRender);
      };
    });
    return function(outerProps, defaultRender) {
      return outer(outerProps, defaultRender ? innerMemoizer(defaultRender) : inner);
    };
  });
  return outerMemoizer;
}
var memoizer = createMemoizer(createComposedRenderFunction);
function composeRenderFunction(outer, inner) {
  return memoizer(outer)(inner);
}

// node_modules/@uifabric/utilities/lib/safeRequestAnimationFrame.js
var safeRequestAnimationFrame = function(component) {
  var activeTimeouts;
  return function(cb) {
    if (!activeTimeouts) {
      activeTimeouts = /* @__PURE__ */ new Set();
      extendComponent(component, {
        componentWillUnmount: function() {
          activeTimeouts.forEach(function(id) {
            return cancelAnimationFrame(id);
          });
        }
      });
    }
    var timeoutId = requestAnimationFrame(function() {
      activeTimeouts.delete(timeoutId);
      cb();
    });
    activeTimeouts.add(timeoutId);
  };
};

// node_modules/@uifabric/utilities/lib/selection/Selection.types.js
var SELECTION_CHANGE = "change";
var SELECTION_ITEMS_CHANGE = "items-change";
var SelectionMode;
(function(SelectionMode2) {
  SelectionMode2[SelectionMode2["none"] = 0] = "none";
  SelectionMode2[SelectionMode2["single"] = 1] = "single";
  SelectionMode2[SelectionMode2["multiple"] = 2] = "multiple";
})(SelectionMode || (SelectionMode = {}));
var SelectionDirection;
(function(SelectionDirection2) {
  SelectionDirection2[SelectionDirection2["horizontal"] = 0] = "horizontal";
  SelectionDirection2[SelectionDirection2["vertical"] = 1] = "vertical";
})(SelectionDirection || (SelectionDirection = {}));

// node_modules/@uifabric/utilities/lib/selection/Selection.js
var Selection = (
  /** @class */
  function() {
    function Selection2() {
      var options = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        options[_i] = arguments[_i];
      }
      var _a3 = options[0] || {}, onSelectionChanged = _a3.onSelectionChanged, onItemsChanged = _a3.onItemsChanged, getKey = _a3.getKey, _b = _a3.canSelectItem, canSelectItem = _b === void 0 ? function() {
        return true;
      } : _b, items = _a3.items, _c = _a3.selectionMode, selectionMode = _c === void 0 ? SelectionMode.multiple : _c;
      this.mode = selectionMode;
      this._getKey = getKey || defaultGetKey;
      this._changeEventSuppressionCount = 0;
      this._exemptedCount = 0;
      this._anchoredIndex = 0;
      this._unselectableCount = 0;
      this._onSelectionChanged = onSelectionChanged;
      this._onItemsChanged = onItemsChanged;
      this._canSelectItem = canSelectItem;
      this._keyToIndexMap = {};
      this._isModal = false;
      this.setItems(items || [], true);
      this.count = this.getSelectedCount();
    }
    Selection2.prototype.canSelectItem = function(item, index) {
      if (typeof index === "number" && index < 0) {
        return false;
      }
      return this._canSelectItem(item, index);
    };
    Selection2.prototype.getKey = function(item, index) {
      var key = this._getKey(item, index);
      return typeof key === "number" || key ? "" + key : "";
    };
    Selection2.prototype.setChangeEvents = function(isEnabled, suppressChange) {
      this._changeEventSuppressionCount += isEnabled ? -1 : 1;
      if (this._changeEventSuppressionCount === 0 && this._hasChanged) {
        this._hasChanged = false;
        if (!suppressChange) {
          this._change();
        }
      }
    };
    Selection2.prototype.isModal = function() {
      return this._isModal;
    };
    Selection2.prototype.setModal = function(isModal) {
      if (this._isModal !== isModal) {
        this.setChangeEvents(false);
        this._isModal = isModal;
        if (!isModal) {
          this.setAllSelected(false);
        }
        this._change();
        this.setChangeEvents(true);
      }
    };
    Selection2.prototype.setItems = function(items, shouldClear) {
      if (shouldClear === void 0) {
        shouldClear = true;
      }
      var newKeyToIndexMap = {};
      var newUnselectableIndices = {};
      var hasSelectionChanged = false;
      this.setChangeEvents(false);
      this._unselectableCount = 0;
      var haveItemsChanged = false;
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (item) {
          var key = this.getKey(item, i);
          if (key) {
            if (!haveItemsChanged && (!(key in this._keyToIndexMap) || this._keyToIndexMap[key] !== i)) {
              haveItemsChanged = true;
            }
            newKeyToIndexMap[key] = i;
          }
        }
        newUnselectableIndices[i] = item && !this.canSelectItem(item);
        if (newUnselectableIndices[i]) {
          this._unselectableCount++;
        }
      }
      if (shouldClear || items.length === 0) {
        this._setAllSelected(false, true);
      }
      var newExemptedIndicies = {};
      var newExemptedCount = 0;
      for (var indexProperty in this._exemptedIndices) {
        if (this._exemptedIndices.hasOwnProperty(indexProperty)) {
          var index = Number(indexProperty);
          var item = this._items[index];
          var exemptKey = item ? this.getKey(item, Number(index)) : void 0;
          var newIndex = exemptKey ? newKeyToIndexMap[exemptKey] : index;
          if (newIndex === void 0) {
            hasSelectionChanged = true;
          } else {
            newExemptedIndicies[newIndex] = true;
            newExemptedCount++;
            hasSelectionChanged = hasSelectionChanged || newIndex !== index;
          }
        }
      }
      if (this._items && this._exemptedCount === 0 && items.length !== this._items.length && this._isAllSelected) {
        hasSelectionChanged = true;
      }
      if (!haveItemsChanged) {
        for (var _i = 0, _a3 = Object.keys(this._keyToIndexMap); _i < _a3.length; _i++) {
          var key = _a3[_i];
          if (!(key in newKeyToIndexMap)) {
            haveItemsChanged = true;
            break;
          }
        }
      }
      this._exemptedIndices = newExemptedIndicies;
      this._exemptedCount = newExemptedCount;
      this._keyToIndexMap = newKeyToIndexMap;
      this._unselectableIndices = newUnselectableIndices;
      this._items = items;
      this._selectedItems = null;
      if (hasSelectionChanged) {
        this._updateCount();
      }
      if (haveItemsChanged) {
        EventGroup.raise(this, SELECTION_ITEMS_CHANGE);
        if (this._onItemsChanged) {
          this._onItemsChanged();
        }
      }
      if (hasSelectionChanged) {
        this._change();
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.getItems = function() {
      return this._items;
    };
    Selection2.prototype.getSelection = function() {
      if (!this._selectedItems) {
        this._selectedItems = [];
        var items = this._items;
        if (items) {
          for (var i = 0; i < items.length; i++) {
            if (this.isIndexSelected(i)) {
              this._selectedItems.push(items[i]);
            }
          }
        }
      }
      return this._selectedItems;
    };
    Selection2.prototype.getSelectedCount = function() {
      return this._isAllSelected ? this._items.length - this._exemptedCount - this._unselectableCount : this._exemptedCount;
    };
    Selection2.prototype.getSelectedIndices = function() {
      if (!this._selectedIndices) {
        this._selectedIndices = [];
        var items = this._items;
        if (items) {
          for (var i = 0; i < items.length; i++) {
            if (this.isIndexSelected(i)) {
              this._selectedIndices.push(i);
            }
          }
        }
      }
      return this._selectedIndices;
    };
    Selection2.prototype.getItemIndex = function(key) {
      var index = this._keyToIndexMap[key];
      return index !== null && index !== void 0 ? index : -1;
    };
    Selection2.prototype.isRangeSelected = function(fromIndex, count) {
      if (count === 0) {
        return false;
      }
      var endIndex = fromIndex + count;
      for (var i = fromIndex; i < endIndex; i++) {
        if (!this.isIndexSelected(i)) {
          return false;
        }
      }
      return true;
    };
    Selection2.prototype.isAllSelected = function() {
      var selectableCount = this._items.length - this._unselectableCount;
      if (this.mode === SelectionMode.single) {
        selectableCount = Math.min(selectableCount, 1);
      }
      return this.count > 0 && this._isAllSelected && this._exemptedCount === 0 || !this._isAllSelected && this._exemptedCount === selectableCount && selectableCount > 0;
    };
    Selection2.prototype.isKeySelected = function(key) {
      var index = this._keyToIndexMap[key];
      return this.isIndexSelected(index);
    };
    Selection2.prototype.isIndexSelected = function(index) {
      return !!(this.count > 0 && this._isAllSelected && !this._exemptedIndices[index] && !this._unselectableIndices[index] || !this._isAllSelected && this._exemptedIndices[index]);
    };
    Selection2.prototype.setAllSelected = function(isAllSelected) {
      if (isAllSelected && this.mode !== SelectionMode.multiple) {
        return;
      }
      var selectableCount = this._items ? this._items.length - this._unselectableCount : 0;
      this.setChangeEvents(false);
      if (selectableCount > 0 && (this._exemptedCount > 0 || isAllSelected !== this._isAllSelected)) {
        this._exemptedIndices = {};
        if (isAllSelected !== this._isAllSelected || this._exemptedCount > 0) {
          this._exemptedCount = 0;
          this._isAllSelected = isAllSelected;
          this._change();
        }
        this._updateCount();
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.setKeySelected = function(key, isSelected, shouldAnchor) {
      var index = this._keyToIndexMap[key];
      if (index >= 0) {
        this.setIndexSelected(index, isSelected, shouldAnchor);
      }
    };
    Selection2.prototype.setIndexSelected = function(index, isSelected, shouldAnchor) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      index = Math.min(Math.max(0, index), this._items.length - 1);
      if (index < 0 || index >= this._items.length) {
        return;
      }
      this.setChangeEvents(false);
      var isExempt = this._exemptedIndices[index];
      var canSelect = !this._unselectableIndices[index];
      if (canSelect) {
        if (isSelected && this.mode === SelectionMode.single) {
          this._setAllSelected(false, true);
        }
        if (isExempt && (isSelected && this._isAllSelected || !isSelected && !this._isAllSelected)) {
          delete this._exemptedIndices[index];
          this._exemptedCount--;
        }
        if (!isExempt && (isSelected && !this._isAllSelected || !isSelected && this._isAllSelected)) {
          this._exemptedIndices[index] = true;
          this._exemptedCount++;
        }
        if (shouldAnchor) {
          this._anchoredIndex = index;
        }
      }
      this._updateCount();
      this.setChangeEvents(true);
    };
    Selection2.prototype.setRangeSelected = function(fromIndex, count, isSelected, shouldAnchor) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      fromIndex = Math.min(Math.max(0, fromIndex), this._items.length - 1);
      count = Math.min(Math.max(0, count), this._items.length - fromIndex);
      if (fromIndex < 0 || fromIndex >= this._items.length || count === 0) {
        return;
      }
      this.setChangeEvents(false);
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = fromIndex;
      var endIndex = fromIndex + count - 1;
      var newAnchorIndex = anchorIndex >= endIndex ? startIndex : endIndex;
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, isSelected, shouldAnchor ? startIndex === newAnchorIndex : false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.selectToKey = function(key, clearSelection) {
      this.selectToIndex(this._keyToIndexMap[key], clearSelection);
    };
    Selection2.prototype.selectToRange = function(fromIndex, count, clearSelection) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      if (this.mode === SelectionMode.single) {
        if (count === 1) {
          this.setIndexSelected(fromIndex, true, true);
        }
        return;
      }
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = Math.min(fromIndex, anchorIndex);
      var endIndex = Math.max(fromIndex + count - 1, anchorIndex);
      this.setChangeEvents(false);
      if (clearSelection) {
        this._setAllSelected(false, true);
      }
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, true, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.selectToIndex = function(index, clearSelection) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      if (this.mode === SelectionMode.single) {
        this.setIndexSelected(index, true, true);
        return;
      }
      var anchorIndex = this._anchoredIndex || 0;
      var startIndex = Math.min(index, anchorIndex);
      var endIndex = Math.max(index, anchorIndex);
      this.setChangeEvents(false);
      if (clearSelection) {
        this._setAllSelected(false, true);
      }
      for (; startIndex <= endIndex; startIndex++) {
        this.setIndexSelected(startIndex, true, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype.toggleAllSelected = function() {
      this.setAllSelected(!this.isAllSelected());
    };
    Selection2.prototype.toggleKeySelected = function(key) {
      this.setKeySelected(key, !this.isKeySelected(key), true);
    };
    Selection2.prototype.toggleIndexSelected = function(index) {
      this.setIndexSelected(index, !this.isIndexSelected(index), true);
    };
    Selection2.prototype.toggleRangeSelected = function(fromIndex, count) {
      if (this.mode === SelectionMode.none) {
        return;
      }
      var isRangeSelected = this.isRangeSelected(fromIndex, count);
      var endIndex = fromIndex + count;
      if (this.mode === SelectionMode.single && count > 1) {
        return;
      }
      this.setChangeEvents(false);
      for (var i = fromIndex; i < endIndex; i++) {
        this.setIndexSelected(i, !isRangeSelected, false);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype._updateCount = function(preserveModalState) {
      if (preserveModalState === void 0) {
        preserveModalState = false;
      }
      var count = this.getSelectedCount();
      if (count !== this.count) {
        this.count = count;
        this._change();
      }
      if (!this.count && !preserveModalState) {
        this.setModal(false);
      }
    };
    Selection2.prototype._setAllSelected = function(isAllSelected, preserveModalState) {
      if (preserveModalState === void 0) {
        preserveModalState = false;
      }
      if (isAllSelected && this.mode !== SelectionMode.multiple) {
        return;
      }
      var selectableCount = this._items ? this._items.length - this._unselectableCount : 0;
      this.setChangeEvents(false);
      if (selectableCount > 0 && (this._exemptedCount > 0 || isAllSelected !== this._isAllSelected)) {
        this._exemptedIndices = {};
        if (isAllSelected !== this._isAllSelected || this._exemptedCount > 0) {
          this._exemptedCount = 0;
          this._isAllSelected = isAllSelected;
          this._change();
        }
        this._updateCount(preserveModalState);
      }
      this.setChangeEvents(true);
    };
    Selection2.prototype._change = function() {
      if (this._changeEventSuppressionCount === 0) {
        this._selectedItems = null;
        this._selectedIndices = void 0;
        EventGroup.raise(this, SELECTION_CHANGE);
        if (this._onSelectionChanged) {
          this._onSelectionChanged();
        }
      } else {
        this._hasChanged = true;
      }
    };
    return Selection2;
  }()
);
function defaultGetKey(item, index) {
  var _a3 = (item || {}).key, key = _a3 === void 0 ? "" + index : _a3;
  return key;
}

// node_modules/@uifabric/utilities/lib/string.js
var FORMAT_ARGS_REGEX = /[\{\}]/g;
var FORMAT_REGEX = /\{\d+\}/g;
function format(s) {
  var values2 = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    values2[_i - 1] = arguments[_i];
  }
  var args = values2;
  function replaceFunc(match) {
    var replacement = args[match.replace(FORMAT_ARGS_REGEX, "")];
    if (replacement === null || replacement === void 0) {
      replacement = "";
    }
    return replacement;
  }
  return s.replace(FORMAT_REGEX, replaceFunc);
}

// node_modules/@uifabric/utilities/lib/styled.js
var React10 = __toESM(require_react());
var DefaultFields = ["theme", "styles"];
function styled(Component6, baseStyles, getProps, customizable2, pure) {
  customizable2 = customizable2 || { scope: "", fields: void 0 };
  var scope = customizable2.scope, _a3 = customizable2.fields, fields = _a3 === void 0 ? DefaultFields : _a3;
  var Wrapped = React10.forwardRef(function(props, forwardedRef) {
    var styles = React10.useRef();
    var settings = useCustomizationSettings(fields, scope);
    var customizedStyles = settings.styles, dir = settings.dir, rest = __rest(settings, ["styles", "dir"]);
    var additionalProps = getProps ? getProps(props) : void 0;
    var cache = styles.current && styles.current.__cachedInputs__ || [];
    if (!styles.current || customizedStyles !== cache[1] || props.styles !== cache[2]) {
      var concatenatedStyles = function(styleProps) {
        return concatStyleSetsWithProps(styleProps, baseStyles, customizedStyles, props.styles);
      };
      concatenatedStyles.__cachedInputs__ = [
        baseStyles,
        customizedStyles,
        props.styles
      ];
      concatenatedStyles.__noStyleOverride__ = !customizedStyles && !props.styles;
      styles.current = concatenatedStyles;
    }
    return React10.createElement(Component6, __assign2({ ref: forwardedRef }, rest, additionalProps, props, { styles: styles.current }));
  });
  Wrapped.displayName = "Styled" + (Component6.displayName || Component6.name);
  var pureComponent = pure ? React10.memo(Wrapped) : Wrapped;
  if (Wrapped.displayName) {
    pureComponent.displayName = Wrapped.displayName;
  }
  return pureComponent;
}

// node_modules/@uifabric/utilities/lib/warn/warnControlledUsage.js
var warningsMap;
if (true) {
  warningsMap = {
    valueOnChange: {},
    valueDefaultValue: {},
    controlledToUncontrolled: {},
    uncontrolledToControlled: {}
  };
}
function warnControlledUsage(params) {
  if (true) {
    var componentId = params.componentId, componentName = params.componentName, defaultValueProp = params.defaultValueProp, props = params.props, oldProps = params.oldProps, onChangeProp = params.onChangeProp, readOnlyProp = params.readOnlyProp, valueProp = params.valueProp;
    var oldIsControlled = oldProps ? isControlled(oldProps, valueProp) : void 0;
    var newIsControlled = isControlled(props, valueProp);
    if (newIsControlled) {
      var hasOnChange = !!props[onChangeProp];
      var isReadOnly = !!(readOnlyProp && props[readOnlyProp]);
      if (!(hasOnChange || isReadOnly) && !warningsMap.valueOnChange[componentId]) {
        warningsMap.valueOnChange[componentId] = true;
        warn("Warning: You provided a '" + valueProp + "' prop to a " + componentName + " without an '" + onChangeProp + "' handler. " + ("This will render a read-only field. If the field should be mutable use '" + defaultValueProp + "'. ") + ("Otherwise, set '" + onChangeProp + "'" + (readOnlyProp ? " or '" + readOnlyProp + "'" : "") + "."));
      }
      var defaultValue = props[defaultValueProp];
      if (defaultValue !== void 0 && defaultValue !== null && !warningsMap.valueDefaultValue[componentId]) {
        warningsMap.valueDefaultValue[componentId] = true;
        warn("Warning: You provided both '" + valueProp + "' and '" + defaultValueProp + "' to a " + componentName + ". " + ("Form fields must be either controlled or uncontrolled (specify either the '" + valueProp + "' prop, ") + ("or the '" + defaultValueProp + "' prop, but not both). Decide between using a controlled or uncontrolled ") + (componentName + " and remove one of these props. More info: https://fb.me/react-controlled-components"));
      }
    }
    if (oldProps && newIsControlled !== oldIsControlled) {
      var oldType = oldIsControlled ? "a controlled" : "an uncontrolled";
      var newType = oldIsControlled ? "uncontrolled" : "controlled";
      var warnMap = oldIsControlled ? warningsMap.controlledToUncontrolled : warningsMap.uncontrolledToControlled;
      if (!warnMap[componentId]) {
        warnMap[componentId] = true;
        warn("Warning: A component is changing " + oldType + " " + componentName + " to be " + newType + ". " + (componentName + "s should not switch from controlled to uncontrolled (or vice versa). ") + "Decide between using controlled or uncontrolled for the lifetime of the component. More info: https://fb.me/react-controlled-components");
      }
    }
  }
}

// node_modules/@uifabric/utilities/lib/ie11Detector.js
var isIE11 = function() {
  var _a3, _b;
  var win = getWindow();
  if (!((_b = (_a3 = win) === null || _a3 === void 0 ? void 0 : _a3.navigator) === null || _b === void 0 ? void 0 : _b.userAgent)) {
    return false;
  }
  return win.navigator.userAgent.indexOf("rv:11.0") > -1;
};

// node_modules/@uifabric/utilities/lib/createMergedRef.js
var createResolver = function(local) {
  return function(newValue) {
    for (var _i = 0, _a3 = local.refs; _i < _a3.length; _i++) {
      var ref = _a3[_i];
      if (typeof ref === "function") {
        ref(newValue);
      } else if (ref) {
        ref.current = newValue;
      }
    }
  };
};
var createMergedRef = function(value) {
  var local = {
    refs: []
  };
  return function() {
    var newRefs = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      newRefs[_i] = arguments[_i];
    }
    if (!local.resolver || !arraysEqual(local.refs, newRefs)) {
      local.resolver = createResolver(local);
    }
    local.refs = newRefs;
    return local.resolver;
  };
};

// node_modules/@uifabric/utilities/lib/version.js
setVersion("@uifabric/utilities", "7.38.1");

// node_modules/@uifabric/react-hooks/lib/useAsync.js
var React12 = __toESM(require_react());

// node_modules/@uifabric/react-hooks/lib/useConst.js
var React11 = __toESM(require_react());
function useConst(initialValue) {
  var ref = React11.useRef();
  if (ref.current === void 0) {
    ref.current = {
      value: typeof initialValue === "function" ? initialValue() : initialValue
    };
  }
  return ref.current.value;
}

// node_modules/@uifabric/react-hooks/lib/useAsync.js
function useAsync() {
  var async = useConst(function() {
    return new Async();
  });
  React12.useEffect(function() {
    return function() {
      return async.dispose();
    };
  }, [async]);
  return async;
}

// node_modules/@uifabric/react-hooks/lib/useBoolean.js
var React13 = __toESM(require_react());
function useBoolean(initialState) {
  var _a3 = React13.useState(initialState), value = _a3[0], setValue = _a3[1];
  var valueRef = React13.useRef(value);
  var setTrue = useConst(function() {
    return function() {
      setValue(true);
      valueRef.current = true;
    };
  });
  var setFalse = useConst(function() {
    return function() {
      setValue(false);
      valueRef.current = false;
    };
  });
  var toggle = useConst(function() {
    return function() {
      return valueRef.current ? setFalse() : setTrue();
    };
  });
  return [value, { setTrue, setFalse, toggle }];
}

// node_modules/@uifabric/react-hooks/lib/useConstCallback.js
var React14 = __toESM(require_react());
function useConstCallback(callback) {
  var ref = React14.useRef();
  if (!ref.current) {
    ref.current = callback;
  }
  return ref.current;
}

// node_modules/@uifabric/react-hooks/lib/useControllableValue.js
var React15 = __toESM(require_react());
function useControllableValue(controlledValue, defaultUncontrolledValue, onChange) {
  var _a3 = React15.useState(defaultUncontrolledValue), value = _a3[0], setValue = _a3[1];
  var isControlled2 = useConst(controlledValue !== void 0);
  var currentValue = isControlled2 ? controlledValue : value;
  var valueRef = React15.useRef(currentValue);
  var onChangeRef = React15.useRef(onChange);
  React15.useEffect(function() {
    valueRef.current = currentValue;
    onChangeRef.current = onChange;
  });
  var setValueOrCallOnChange = useConst(function() {
    return function(update, ev) {
      var newValue = typeof update === "function" ? update(valueRef.current) : update;
      if (onChangeRef.current) {
        onChangeRef.current(ev, newValue);
      }
      if (!isControlled2) {
        setValue(newValue);
      }
    };
  });
  return [currentValue, setValueOrCallOnChange];
}

// node_modules/@uifabric/react-hooks/lib/useEventCallback.js
var React16 = __toESM(require_react());
function useEventCallback(fn) {
  var callbackRef = React16.useRef(function() {
    throw new Error("Cannot call an event handler while rendering");
  });
  React16.useLayoutEffect(function() {
    callbackRef.current = fn;
  }, [fn]);
  return useConst(function() {
    return function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var callback = callbackRef.current;
      return callback.apply(void 0, args);
    };
  });
}

// node_modules/@uifabric/react-hooks/lib/useForceUpdate.js
var React17 = __toESM(require_react());
function useForceUpdate2() {
  var _a3 = React17.useState(0), setValue = _a3[1];
  var forceUpdate = useConst(function() {
    return function() {
      return setValue(function(value) {
        return ++value;
      });
    };
  });
  return forceUpdate;
}

// node_modules/@uifabric/react-hooks/lib/useId.js
var React18 = __toESM(require_react());
function useId(prefix, providedId) {
  var ref = React18.useRef(providedId);
  if (!ref.current) {
    ref.current = getId(prefix);
  }
  return ref.current;
}

// node_modules/@uifabric/react-hooks/node_modules/tslib/tslib.es6.js
var __assign3 = function() {
  __assign3 = Object.assign || function __assign4(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign3.apply(this, arguments);
};
function __spreadArrays2() {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++)
    s += arguments[i].length;
  for (var r = Array(s), k = 0, i = 0; i < il; i++)
    for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
      r[k] = a[j];
  return r;
}

// node_modules/@uifabric/react-hooks/lib/useMergedRefs.js
var React19 = __toESM(require_react());
function useMergedRefs() {
  var refs = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    refs[_i] = arguments[_i];
  }
  var mergedCallback = React19.useCallback(function(value) {
    mergedCallback.current = value;
    for (var _i2 = 0, refs_1 = refs; _i2 < refs_1.length; _i2++) {
      var ref = refs_1[_i2];
      if (typeof ref === "function") {
        ref(value);
      } else if (ref) {
        ref.current = value;
      }
    }
  }, __spreadArrays2(refs));
  return mergedCallback;
}

// node_modules/@uifabric/react-hooks/lib/useOnEvent.js
var React20 = __toESM(require_react());
function useOnEvent(element, eventName, callback, useCapture) {
  var callbackRef = React20.useRef(callback);
  callbackRef.current = callback;
  React20.useEffect(function() {
    var actualElement = element && "current" in element ? element.current : element;
    if (!actualElement) {
      return;
    }
    var dispose = on(actualElement, eventName, function(ev) {
      return callbackRef.current(ev);
    }, useCapture);
    return dispose;
  }, [element, eventName, useCapture]);
}

// node_modules/@uifabric/react-hooks/lib/usePrevious.js
var import_react = __toESM(require_react());
function usePrevious(value) {
  var ref = (0, import_react.useRef)();
  (0, import_react.useEffect)(function() {
    ref.current = value;
  });
  return ref.current;
}

// node_modules/@uifabric/react-hooks/lib/useRefEffect.js
var React21 = __toESM(require_react());
function useRefEffect(callback, initial) {
  if (initial === void 0) {
    initial = null;
  }
  var data = React21.useRef({
    ref: Object.assign(function(value) {
      if (data.ref.current !== value) {
        if (data.cleanup) {
          data.cleanup();
          data.cleanup = void 0;
        }
        data.ref.current = value;
        if (value !== null) {
          data.cleanup = data.callback(value);
        }
      }
    }, {
      current: initial
    }),
    callback
  }).current;
  data.callback = callback;
  return data.ref;
}

// node_modules/@uifabric/react-hooks/lib/useSetInterval.js
var React22 = __toESM(require_react());
var useSetInterval = function() {
  var intervalIds = useConst({});
  React22.useEffect(
    function() {
      return function() {
        for (var _i = 0, _a3 = Object.keys(intervalIds); _i < _a3.length; _i++) {
          var id = _a3[_i];
          clearInterval(id);
        }
      };
    },
    // useConst ensures this will never change, but react-hooks/exhaustive-deps doesn't know that
    [intervalIds]
  );
  return useConst({
    setInterval: function(func, duration) {
      var id = setInterval(func, duration);
      intervalIds[id] = 1;
      return id;
    },
    clearInterval: function(id) {
      delete intervalIds[id];
      clearInterval(id);
    }
  });
};

// node_modules/@uifabric/react-hooks/lib/useSetTimeout.js
var React23 = __toESM(require_react());
var useSetTimeout = function() {
  var timeoutIds = useConst({});
  React23.useEffect(
    function() {
      return function() {
        for (var _i = 0, _a3 = Object.keys(timeoutIds); _i < _a3.length; _i++) {
          var id = _a3[_i];
          clearTimeout(id);
        }
      };
    },
    // useConst ensures this will never change, but react-hooks/exhaustive-deps doesn't know that
    [timeoutIds]
  );
  return useConst({
    setTimeout: function(func, duration) {
      var id = setTimeout(func, duration);
      timeoutIds[id] = 1;
      return id;
    },
    clearTimeout: function(id) {
      delete timeoutIds[id];
      clearTimeout(id);
    }
  });
};

// node_modules/@uifabric/react-hooks/lib/useTarget.js
var React25 = __toESM(require_react());

// node_modules/@uifabric/react-hooks/node_modules/@fluentui/react-window-provider/lib/WindowProvider.js
var React24 = __toESM(require_react());
var WindowContext = React24.createContext({
  window: typeof window === "object" ? window : void 0
});
var useWindow = function() {
  return React24.useContext(WindowContext).window;
};

// node_modules/@uifabric/react-hooks/lib/useTarget.js
function useTarget(target, hostElement) {
  var _a3;
  var previousTargetProp = React25.useRef();
  var targetRef = React25.useRef(null);
  var targetWindow = useWindow();
  if (!target || target !== previousTargetProp.current || typeof target === "string") {
    var currentElement = (_a3 = hostElement) === null || _a3 === void 0 ? void 0 : _a3.current;
    if (target) {
      if (typeof target === "string") {
        var currentDoc = getDocument(currentElement);
        targetRef.current = currentDoc ? currentDoc.querySelector(target) : null;
      } else if ("stopPropagation" in target) {
        targetRef.current = target;
      } else if ("getBoundingClientRect" in target) {
        targetRef.current = target;
      } else if ("current" in target) {
        targetRef.current = target.current;
      } else {
        targetRef.current = target;
      }
    }
    previousTargetProp.current = target;
  }
  return [targetRef, targetWindow];
}

// node_modules/@uifabric/react-hooks/lib/useWarnings.js
var React26 = __toESM(require_react());
var warningId = 0;
function useWarnings(options) {
  if (true) {
    var name_1 = options.name, props = options.props, _a3 = options.other, other = _a3 === void 0 ? [] : _a3, conditionallyRequired = options.conditionallyRequired, deprecations = options.deprecations, mutuallyExclusive = options.mutuallyExclusive, controlledUsage = options.controlledUsage;
    var hasWarnedRef = React26.useRef(false);
    var componentId = useConst(function() {
      return "useWarnings_" + warningId++;
    });
    var oldProps = usePrevious(props);
    if (!hasWarnedRef.current) {
      hasWarnedRef.current = true;
      for (var _i = 0, other_1 = other; _i < other_1.length; _i++) {
        var warning = other_1[_i];
        warn(warning);
      }
      if (conditionallyRequired) {
        for (var _b = 0, conditionallyRequired_1 = conditionallyRequired; _b < conditionallyRequired_1.length; _b++) {
          var req = conditionallyRequired_1[_b];
          warnConditionallyRequiredProps(name_1, props, req.requiredProps, req.conditionalPropName, req.condition);
        }
      }
      deprecations && warnDeprecations(name_1, props, deprecations);
      mutuallyExclusive && warnMutuallyExclusive(name_1, props, mutuallyExclusive);
    }
    controlledUsage && warnControlledUsage(__assign3(__assign3({}, controlledUsage), { componentId, props, componentName: name_1, oldProps }));
  }
}

export {
  setVersion,
  getWindow,
  Async,
  shallowCompare,
  assign,
  values,
  omit,
  EventGroup,
  getDocument,
  Stylesheet,
  mergeStyles,
  mergeCss,
  concatStyleSets,
  mergeStyleSets,
  mergeCssSets,
  concatStyleSetsWithProps,
  fontFace,
  keyframes,
  allowScrollOnElement,
  allowOverscrollOnElement,
  disableBodyScroll,
  enableBodyScroll,
  getScrollbarWidth,
  findScrollableParent,
  getRect,
  AutoScroll,
  warn,
  warnConditionallyRequiredProps,
  warnMutuallyExclusive,
  warnDeprecations,
  nullRender,
  DelayedRender,
  GlobalSettings,
  KeyCodes,
  Rectangle,
  mergeAriaAttributeValues,
  findIndex,
  find,
  toMatrix,
  addElementAtIndex,
  arraysEqual,
  getRTL2 as getRTL,
  getRTLSafeKeyCode,
  getParent,
  elementContains,
  findElementRecursive,
  setPortalAttribute,
  portalContainsElement,
  setVirtualParent,
  on,
  classNamesFunction,
  memoizeFunction,
  composeComponentAs,
  isControlled,
  css,
  Customizations,
  CustomizerContext,
  Customizer,
  hoistStatics,
  customizable,
  useCustomizationSettings,
  getFirstFocusable,
  getLastFocusable,
  getFirstTabbable,
  getLastTabbable,
  focusFirstChild,
  getPreviousElement,
  getNextElement,
  isElementTabbable,
  isElementFocusZone,
  isElementFocusSubZone,
  doesElementContainFocus,
  shouldWrapFocus,
  focusAsync,
  getFocusableByIndexPath,
  getElementIndexPath,
  getId,
  htmlElementProperties,
  anchorProperties,
  buttonProperties,
  inputProperties,
  textAreaProperties,
  imgProperties,
  divProperties,
  getNativeProps,
  getNativeElementProps,
  hoistMethods,
  unhoistMethods,
  initializeComponentRef,
  IsFocusVisibleClassName,
  setFocusVisibility,
  useFocusRects,
  FocusRects,
  getInitials,
  getLanguage,
  getDistanceBetweenPoints,
  calculatePrecision,
  precisionRound,
  merge,
  isIOS,
  modalize,
  isMac,
  hasOverflow,
  composeRenderFunction,
  safeRequestAnimationFrame,
  SELECTION_CHANGE,
  SelectionMode,
  Selection,
  format,
  styled,
  warnControlledUsage,
  isIE11,
  createMergedRef,
  useConst,
  useAsync,
  useBoolean,
  useConstCallback,
  useControllableValue,
  useEventCallback,
  useForceUpdate2 as useForceUpdate,
  useId,
  useMergedRefs,
  useOnEvent,
  usePrevious,
  useRefEffect,
  useSetInterval,
  useSetTimeout,
  useTarget,
  useWarnings
};
/*! Bundled license information:

tslib/tslib.es6.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)

tslib/tslib.es6.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)

tslib/tslib.es6.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)
*/
//# sourceMappingURL=chunk-PTRVX54X.js.map
