import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dragAndDrop/DragAndDrop.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { DragDropContext, Droppable, Draggable } from "/node_modules/.vite/deps/react-beautiful-dnd.js?v=9f90a7ff";
import { useDraggableInPortal } from "/src/shared/hooks/index.ts";
function DragAndDrop(props) {
  _s();
  const {
    itemList,
    setItemList,
    disabled
  } = props;
  const renderDraggable = useDraggableInPortal();
  const handleDrop = (droppedItem) => {
    if (droppedItem.destination) {
      const updatedList = [...itemList];
      const [reorderedItem] = updatedList.splice(droppedItem.source.index, 1);
      updatedList.splice(droppedItem.destination.index, 0, reorderedItem);
      setItemList?.(updatedList);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: /* @__PURE__ */ jsxDEV(DragDropContext, { onDragEnd: handleDrop, children: /* @__PURE__ */ jsxDEV(Droppable, { droppableId: "list-container", children: (provided) => /* @__PURE__ */ jsxDEV("div", { className: "list-container", ...provided.droppableProps, ref: provided.innerRef, children: [
    itemList.map((item, index) => /* @__PURE__ */ jsxDEV(Draggable, { draggableId: index.toString(), index, isDragDisabled: disabled, children: renderDraggable((provided2) => /* @__PURE__ */ jsxDEV("div", { className: "item-container", ref: provided2.innerRef, ...provided2.dragHandleProps, ...provided2.draggableProps, children: item }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
      lineNumber: 32,
      columnNumber: 48
    }, this)) }, index, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
      lineNumber: 31,
      columnNumber: 46
    }, this)),
    provided.placeholder
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
    lineNumber: 30,
    columnNumber: 24
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
    lineNumber: 29,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx",
    lineNumber: 27,
    columnNumber: 10
  }, this);
}
_s(DragAndDrop, "okrmdOfecY17MVCNRKKXQTOhw6o=", false, function() {
  return [useDraggableInPortal];
});
_c = DragAndDrop;
export default DragAndDrop;
var _c;
$RefreshReg$(_c, "DragAndDrop");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dragAndDrop/DragAndDrop.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENvQjs7Ozs7Ozs7Ozs7Ozs7OztBQXpDcEIsU0FBU0EsaUJBQWlCQyxXQUFXQyxpQkFBNkI7QUFFbEUsU0FBU0MsNEJBQTRCO0FBUXJDLFNBQVNDLFlBQStCQyxPQUEwQztBQUFBQyxLQUFBO0FBQ2hGLFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFVQztBQUFBQSxJQUFhQztBQUFBQSxFQUFTLElBQUlKO0FBQzVDLFFBQU1LLGtCQUFrQlAscUJBQXFCO0FBRTdDLFFBQU1RLGFBQWFBLENBQUNDLGdCQUE0QjtBQUM5QyxRQUFJQSxZQUFZQyxhQUFhO0FBQzNCLFlBQU1DLGNBQWMsQ0FBQyxHQUFHUCxRQUFRO0FBQ2hDLFlBQU0sQ0FBQ1EsYUFBYSxJQUFJRCxZQUFZRSxPQUFPSixZQUFZSyxPQUFPQyxPQUFPLENBQUM7QUFDdEVKLGtCQUFZRSxPQUFPSixZQUFZQyxZQUFZSyxPQUFPLEdBQUdILGFBQWE7QUFDbEVQLG9CQUFjTSxXQUFXO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxtQkFBZ0IsV0FBV0gsWUFDMUIsaUNBQUMsYUFBVSxhQUFZLGtCQUNuQlEsd0JBQ0EsdUJBQUMsU0FDQyxXQUFVLGtCQUNWLEdBQUlBLFNBQVNDLGdCQUNiLEtBQUtELFNBQVNFLFVBRWJkO0FBQUFBLGFBQVNlLElBQUksQ0FBQ0MsTUFBTUwsVUFDbkIsdUJBQUMsYUFFQyxhQUFhQSxNQUFNTSxTQUFTLEdBQzVCLE9BQ0EsZ0JBQWdCZixVQUVmQywwQkFBaUJTLGVBQ2hCLHVCQUFDLFNBQ0MsV0FBVSxrQkFDVixLQUFLQSxVQUFTRSxVQUNkLEdBQUlGLFVBQVNNLGlCQUNiLEdBQUlOLFVBQVNPLGdCQUVaSCxrQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsQ0FDRCxLQWRJTCxPQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkEsQ0FDRDtBQUFBLElBQ0FDLFNBQVNRO0FBQUFBLE9BeEJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkEsS0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0JBLEtBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQ0E7QUFFSjtBQUFDckIsR0FqRFFGLGFBQVc7QUFBQSxVQUVNRCxvQkFBb0I7QUFBQTtBQUFBeUIsS0FGckN4QjtBQW1EVCxlQUFlQTtBQUFXLElBQUF3QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRHJhZ0Ryb3BDb250ZXh0IiwiRHJvcHBhYmxlIiwiRHJhZ2dhYmxlIiwidXNlRHJhZ2dhYmxlSW5Qb3J0YWwiLCJEcmFnQW5kRHJvcCIsInByb3BzIiwiX3MiLCJpdGVtTGlzdCIsInNldEl0ZW1MaXN0IiwiZGlzYWJsZWQiLCJyZW5kZXJEcmFnZ2FibGUiLCJoYW5kbGVEcm9wIiwiZHJvcHBlZEl0ZW0iLCJkZXN0aW5hdGlvbiIsInVwZGF0ZWRMaXN0IiwicmVvcmRlcmVkSXRlbSIsInNwbGljZSIsInNvdXJjZSIsImluZGV4IiwicHJvdmlkZWQiLCJkcm9wcGFibGVQcm9wcyIsImlubmVyUmVmIiwibWFwIiwiaXRlbSIsInRvU3RyaW5nIiwiZHJhZ0hhbmRsZVByb3BzIiwiZHJhZ2dhYmxlUHJvcHMiLCJwbGFjZWhvbGRlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRHJhZ0FuZERyb3AudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZHJhZ0FuZERyb3AvRHJhZ0FuZERyb3AudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVhY3RFbGVtZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBEcmFnRHJvcENvbnRleHQsIERyb3BwYWJsZSwgRHJhZ2dhYmxlLCBEcm9wUmVzdWx0IH0gZnJvbSAncmVhY3QtYmVhdXRpZnVsLWRuZCdcbmltcG9ydCBFbnRpdHkgZnJvbSAnLi4vLi4vLi4vZG9tYWluL0VudGl0eSdcbmltcG9ydCB7IHVzZURyYWdnYWJsZUluUG9ydGFsIH0gZnJvbSAnLi4vLi4vaG9va3MnXG5cbmV4cG9ydCBpbnRlcmZhY2UgRHJhZ0FuZERyb3BQcm9wczxTPiB7XG4gIGl0ZW1MaXN0OiBBcnJheTxTPlxuICBzZXRJdGVtTGlzdD86ICh1cGRhdGVkTGlzdDogQXJyYXk8Uz4pID0+IHZvaWRcbiAgZGlzYWJsZWQ/OiBib29sZWFuXG59XG5cbmZ1bmN0aW9uIERyYWdBbmREcm9wPFMgZXh0ZW5kcyBFbnRpdHk+IChwcm9wczogRHJhZ0FuZERyb3BQcm9wczxTPik6IFJlYWN0RWxlbWVudCB7XG4gIGNvbnN0IHsgaXRlbUxpc3QsIHNldEl0ZW1MaXN0LCBkaXNhYmxlZCB9ID0gcHJvcHNcbiAgY29uc3QgcmVuZGVyRHJhZ2dhYmxlID0gdXNlRHJhZ2dhYmxlSW5Qb3J0YWwoKVxuXG4gIGNvbnN0IGhhbmRsZURyb3AgPSAoZHJvcHBlZEl0ZW06IERyb3BSZXN1bHQpID0+IHtcbiAgICBpZiAoZHJvcHBlZEl0ZW0uZGVzdGluYXRpb24pIHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRMaXN0ID0gWy4uLml0ZW1MaXN0XVxuICAgICAgY29uc3QgW3Jlb3JkZXJlZEl0ZW1dID0gdXBkYXRlZExpc3Quc3BsaWNlKGRyb3BwZWRJdGVtLnNvdXJjZS5pbmRleCwgMSlcbiAgICAgIHVwZGF0ZWRMaXN0LnNwbGljZShkcm9wcGVkSXRlbS5kZXN0aW5hdGlvbi5pbmRleCwgMCwgcmVvcmRlcmVkSXRlbSlcbiAgICAgIHNldEl0ZW1MaXN0Py4odXBkYXRlZExpc3QpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcFwiPlxuICAgICAgPERyYWdEcm9wQ29udGV4dCBvbkRyYWdFbmQ9e2hhbmRsZURyb3B9PlxuICAgICAgICA8RHJvcHBhYmxlIGRyb3BwYWJsZUlkPVwibGlzdC1jb250YWluZXJcIj5cbiAgICAgICAgICB7KHByb3ZpZGVkKSA9PiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImxpc3QtY29udGFpbmVyXCJcbiAgICAgICAgICAgICAgey4uLnByb3ZpZGVkLmRyb3BwYWJsZVByb3BzfVxuICAgICAgICAgICAgICByZWY9e3Byb3ZpZGVkLmlubmVyUmVmfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7aXRlbUxpc3QubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDxEcmFnZ2FibGVcbiAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICBkcmFnZ2FibGVJZD17aW5kZXgudG9TdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgIGluZGV4PXtpbmRleH1cbiAgICAgICAgICAgICAgICAgIGlzRHJhZ0Rpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7cmVuZGVyRHJhZ2dhYmxlKChwcm92aWRlZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaXRlbS1jb250YWluZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlZj17cHJvdmlkZWQuaW5uZXJSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgey4uLnByb3ZpZGVkLmRyYWdIYW5kbGVQcm9wc31cbiAgICAgICAgICAgICAgICAgICAgICB7Li4ucHJvdmlkZWQuZHJhZ2dhYmxlUHJvcHN9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L0RyYWdnYWJsZT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIHtwcm92aWRlZC5wbGFjZWhvbGRlcn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvRHJvcHBhYmxlPlxuICAgICAgPC9EcmFnRHJvcENvbnRleHQ+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRHJhZ0FuZERyb3BcbiJdfQ==