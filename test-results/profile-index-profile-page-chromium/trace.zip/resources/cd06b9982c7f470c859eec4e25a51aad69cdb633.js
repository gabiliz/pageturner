import { MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=9f90a7ff";
import { queryClient } from "/src/shared/providers/QueryProvider.tsx";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
export class ResourceQueryService {
  resourceService;
  key;
  successCreateMessage;
  successUpdateMessage;
  successDeleteMessage;
  constructor(key, resourceService, successCreateMessage, successUpdateMessage, successDeleteMessage) {
    this.resourceService = resourceService;
    this.key = key;
    this.successCreateMessage = successCreateMessage;
    this.successUpdateMessage = successUpdateMessage;
    this.successDeleteMessage = successDeleteMessage;
  }
  useFindAllRefetchInterval(interval, ...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findAllPaginated(...options),
      {
        refetchInterval: interval
      }
    );
  }
  useFindOneDisableAutoFetch(id, ...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findOne(id),
      {
        enabled: false
      }
    );
  }
  useFindAllKeepPreviousData(...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findAllPaginated(...options),
      {
        keepPreviousData: true
      }
    );
  }
  useFindOneRefetchInterval(interval, id, ...options) {
    return useQuery(
      [this.key, id, ...options],
      () => this.resourceService.findOne(id, ...options),
      {
        refetchInterval: interval
      }
    );
  }
  useFindAllPaginated(...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findAllPaginated(...options)
    );
  }
  useFindAll(...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findAll(...options)
    );
  }
  useFindOne(id, ...options) {
    return useQuery(
      [this.key, id, ...options],
      () => this.resourceService.findOne(id, ...options)
    );
  }
  useFindOneKeepPreviousData(id, ...options) {
    return useQuery(
      [this.key, id, ...options],
      () => this.resourceService.findOne(id, ...options),
      {
        keepPreviousData: true
      }
    );
  }
  useCreate(...options) {
    const { showNotification } = useNotifications();
    return useMutation(
      (item) => this.resourceService.create(item, ...options),
      {
        onSuccess: () => {
          if (this.successCreateMessage !== "") {
            showNotification({
              message: this.successCreateMessage ?? "Cadastrado com sucesso!",
              type: MessageBarType.success
            });
          }
          this.invalidateQueries();
        },
        onError: (error) => {
          if (error.errors?.messages?.length !== void 0 && error.errors?.messages?.length > 0) {
            error.errors?.messages?.forEach((message) => showNotification({
              message: message.message,
              type: MessageBarType.error
            }));
          } else {
            showNotification({
              message: "Houve um problema no servidor",
              type: MessageBarType.error
            });
          }
        }
      }
    );
  }
  useUpdate(...options) {
    const { showNotification } = useNotifications();
    return useMutation(
      (item) => this.resourceService.update(item, ...options),
      {
        onSuccess: () => {
          if (this.successCreateMessage !== "") {
            showNotification({
              message: this.successUpdateMessage ?? "Atualizado com sucesso!",
              type: MessageBarType.success
            });
          }
          this.invalidateQueries();
        },
        onError: (error) => {
          if (error.errors?.messages?.length !== void 0 && error.errors?.messages?.length > 0) {
            error.errors?.messages?.forEach((message) => showNotification({
              message: message.message,
              type: MessageBarType.error
            }));
          } else {
            showNotification({
              message: "Houve um problema no servidor",
              type: MessageBarType.error
            });
          }
        }
      }
    );
  }
  useDelete(...options) {
    const { showNotification } = useNotifications();
    return useMutation(
      (item) => {
        if (!(item instanceof Array) && item.id) {
          return this.resourceService.delete(item.id, ...options);
        } else if (item instanceof Array && item.length) {
          return this.resourceService.delete(item, ...options);
        }
        return Promise.resolve();
      },
      {
        onSuccess: () => {
          if (this.successDeleteMessage !== "") {
            showNotification({
              message: this.successDeleteMessage ?? "Excluído com sucesso!",
              type: MessageBarType.success
            });
          }
          this.invalidateQueries();
        },
        onError: (error) => {
          if (error.errors?.messages?.length !== void 0 && error.errors?.messages?.length > 0) {
            error.errors?.messages?.forEach((message) => showNotification({
              message: message.message,
              type: MessageBarType.error
            }));
          } else {
            showNotification({
              message: "Houve um problema no servidor",
              type: MessageBarType.error
            });
          }
        }
      }
    );
  }
  useFindAllQuery(...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findQuery(...options)
    );
  }
  useFindAllQueryPaginated(...options) {
    return useQuery(
      [this.key, ...options],
      () => this.resourceService.findQuery(...options),
      {
        keepPreviousData: true
      }
    );
  }
  invalidateQueries() {
    queryClient.invalidateQueries([this.key]);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJlc291cmNlUXVlcnlTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzICovXHJcbmltcG9ydCB7IE1lc3NhZ2VCYXJUeXBlIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgVXNlTXV0YXRpb25SZXN1bHQsIHVzZVF1ZXJ5LCBVc2VRdWVyeVJlc3VsdCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IEVudGl0eSBmcm9tICcuLi8uLi9kb21haW4vRW50aXR5J1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uL2Vycm9ycydcclxuaW1wb3J0IHsgcXVlcnlDbGllbnQgfSBmcm9tICcuLi9wcm92aWRlcnMvUXVlcnlQcm92aWRlcidcclxuaW1wb3J0IHsgdXNlTm90aWZpY2F0aW9ucyB9IGZyb20gJy4uL3N0b3JlL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucydcclxuaW1wb3J0IHsgUGFnaW5hdGVkUmVzcG9uc2UgfSBmcm9tICcuLi90eXBlcy9QYWdpbmF0ZWRSZXNwb25zZSdcclxuaW1wb3J0IHsgUmVzb3VyY2VTZXJ2aWNlIH0gZnJvbSAnLi9SZXNvdXJjZVNlcnZpY2UnXHJcblxyXG5leHBvcnQgY2xhc3MgUmVzb3VyY2VRdWVyeVNlcnZpY2U8USBleHRlbmRzIEVudGl0eSwgQyBleHRlbmRzIEVudGl0eT4ge1xyXG4gIHJlc291cmNlU2VydmljZTogUmVzb3VyY2VTZXJ2aWNlPFEsIEM+XHJcbiAga2V5OiBzdHJpbmdcclxuICBzdWNjZXNzQ3JlYXRlTWVzc2FnZT86IHN0cmluZ1xyXG4gIHN1Y2Nlc3NVcGRhdGVNZXNzYWdlPzogc3RyaW5nXHJcbiAgc3VjY2Vzc0RlbGV0ZU1lc3NhZ2U/OiBzdHJpbmdcclxuXHJcbiAgY29uc3RydWN0b3IgKGtleTogc3RyaW5nLCByZXNvdXJjZVNlcnZpY2U6IFJlc291cmNlU2VydmljZTxRLCBDPiwgc3VjY2Vzc0NyZWF0ZU1lc3NhZ2U/OiBzdHJpbmcsIHN1Y2Nlc3NVcGRhdGVNZXNzYWdlPzogc3RyaW5nLCBzdWNjZXNzRGVsZXRlTWVzc2FnZT86IHN0cmluZykge1xyXG4gICAgdGhpcy5yZXNvdXJjZVNlcnZpY2UgPSByZXNvdXJjZVNlcnZpY2VcclxuICAgIHRoaXMua2V5ID0ga2V5XHJcbiAgICB0aGlzLnN1Y2Nlc3NDcmVhdGVNZXNzYWdlID0gc3VjY2Vzc0NyZWF0ZU1lc3NhZ2VcclxuICAgIHRoaXMuc3VjY2Vzc1VwZGF0ZU1lc3NhZ2UgPSBzdWNjZXNzVXBkYXRlTWVzc2FnZVxyXG4gICAgdGhpcy5zdWNjZXNzRGVsZXRlTWVzc2FnZSA9IHN1Y2Nlc3NEZWxldGVNZXNzYWdlXHJcbiAgfVxyXG5cclxuICB1c2VGaW5kQWxsUmVmZXRjaEludGVydmFsIChpbnRlcnZhbDogbnVtYmVyLCAuLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VRdWVyeVJlc3VsdDxQYWdpbmF0ZWRSZXNwb25zZTxRPiwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCAuLi5vcHRpb25zXSxcclxuICAgICAgKCkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZmluZEFsbFBhZ2luYXRlZCguLi5vcHRpb25zKSxcclxuICAgICAge1xyXG4gICAgICAgIHJlZmV0Y2hJbnRlcnZhbDogaW50ZXJ2YWwsXHJcbiAgICAgIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICB1c2VGaW5kT25lRGlzYWJsZUF1dG9GZXRjaCAoaWQ6IHN0cmluZywgLi4ub3B0aW9uczogdW5rbm93bltdKTogVXNlUXVlcnlSZXN1bHQ8USwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCAuLi5vcHRpb25zXSxcclxuICAgICAgKCkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZmluZE9uZShpZCksXHJcbiAgICAgIHtcclxuICAgICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAgICAgfSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIHVzZUZpbmRBbGxLZWVwUHJldmlvdXNEYXRhICguLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VRdWVyeVJlc3VsdDxQYWdpbmF0ZWRSZXNwb25zZTxRPiwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCAuLi5vcHRpb25zXSxcclxuICAgICAgKCkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZmluZEFsbFBhZ2luYXRlZCguLi5vcHRpb25zKSxcclxuICAgICAge1xyXG4gICAgICAgIGtlZXBQcmV2aW91c0RhdGE6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICB1c2VGaW5kT25lUmVmZXRjaEludGVydmFsIChpbnRlcnZhbDogbnVtYmVyLCBpZDogc3RyaW5nLCAuLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VRdWVyeVJlc3VsdDxRfG51bGwsIEFwaUVycm9yPiB7XHJcbiAgICByZXR1cm4gdXNlUXVlcnkoXHJcbiAgICAgIFt0aGlzLmtleSwgaWQsIC4uLm9wdGlvbnNdLFxyXG4gICAgICAoKSA9PiB0aGlzLnJlc291cmNlU2VydmljZS5maW5kT25lKGlkLCAuLi5vcHRpb25zKSxcclxuICAgICAge1xyXG4gICAgICAgIHJlZmV0Y2hJbnRlcnZhbDogaW50ZXJ2YWwsXHJcbiAgICAgIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICB1c2VGaW5kQWxsUGFnaW5hdGVkICguLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VRdWVyeVJlc3VsdDxQYWdpbmF0ZWRSZXNwb25zZTxRPiwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCAuLi5vcHRpb25zXSxcclxuICAgICAgKCkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZmluZEFsbFBhZ2luYXRlZCguLi5vcHRpb25zKSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIHVzZUZpbmRBbGwgKC4uLm9wdGlvbnM6IHVua25vd25bXSk6IFVzZVF1ZXJ5UmVzdWx0PFFbXSwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCAuLi5vcHRpb25zXSxcclxuICAgICAgKCkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZmluZEFsbCguLi5vcHRpb25zKSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIHVzZUZpbmRPbmUgKGlkOiBzdHJpbmcsIC4uLm9wdGlvbnM6IHVua25vd25bXSk6IFVzZVF1ZXJ5UmVzdWx0PFF8bnVsbCwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCBpZCwgLi4ub3B0aW9uc10sXHJcbiAgICAgICgpID0+IHRoaXMucmVzb3VyY2VTZXJ2aWNlLmZpbmRPbmUoaWQsIC4uLm9wdGlvbnMpLFxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgdXNlRmluZE9uZUtlZXBQcmV2aW91c0RhdGEgKGlkOiBzdHJpbmcsIC4uLm9wdGlvbnM6IHVua25vd25bXSk6IFVzZVF1ZXJ5UmVzdWx0PFF8bnVsbCwgQXBpRXJyb3I+IHtcclxuICAgIHJldHVybiB1c2VRdWVyeShcclxuICAgICAgW3RoaXMua2V5LCBpZCwgLi4ub3B0aW9uc10sXHJcbiAgICAgICgpID0+IHRoaXMucmVzb3VyY2VTZXJ2aWNlLmZpbmRPbmUoaWQsIC4uLm9wdGlvbnMpLFxyXG4gICAgICB7XHJcbiAgICAgICAga2VlcFByZXZpb3VzRGF0YTogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIHVzZUNyZWF0ZSAoLi4ub3B0aW9uczogdW5rbm93bltdKTogVXNlTXV0YXRpb25SZXN1bHQ8Q3xudWxsLCBBcGlFcnJvciwgQz4ge1xyXG4gICAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcclxuICAgIHJldHVybiB1c2VNdXRhdGlvbihcclxuICAgICAgKGl0ZW06IEMpID0+IHRoaXMucmVzb3VyY2VTZXJ2aWNlLmNyZWF0ZShpdGVtLCAuLi5vcHRpb25zKSxcclxuICAgICAge1xyXG4gICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc3VjY2Vzc0NyZWF0ZU1lc3NhZ2UgIT09ICcnKSB7XHJcbiAgICAgICAgICAgIHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuc3VjY2Vzc0NyZWF0ZU1lc3NhZ2UgPz8gJ0NhZGFzdHJhZG8gY29tIHN1Y2Vzc28hJyxcclxuICAgICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5zdWNjZXNzLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy5pbnZhbGlkYXRlUXVlcmllcygpXHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiAoZXJyb3IpID0+IHtcclxuICAgICAgICAgIGlmIChlcnJvci5lcnJvcnM/Lm1lc3NhZ2VzPy5sZW5ndGggIT09IHVuZGVmaW5lZCAmJiBlcnJvci5lcnJvcnM/Lm1lc3NhZ2VzPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGVycm9yLmVycm9ycz8ubWVzc2FnZXM/LmZvckVhY2gobWVzc2FnZSA9PiBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiBtZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuZXJyb3IsXHJcbiAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogJ0hvdXZlIHVtIHByb2JsZW1hIG5vIHNlcnZpZG9yJyxcclxuICAgICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgdXNlVXBkYXRlICguLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VNdXRhdGlvblJlc3VsdDxDfENbXXxudWxsLCBBcGlFcnJvciwgQ3xDW10+IHtcclxuICAgIGNvbnN0IHsgc2hvd05vdGlmaWNhdGlvbiB9ID0gdXNlTm90aWZpY2F0aW9ucygpXHJcbiAgICByZXR1cm4gdXNlTXV0YXRpb24oXHJcbiAgICAgIChpdGVtOiBDfENbXSkgPT4gdGhpcy5yZXNvdXJjZVNlcnZpY2UudXBkYXRlKGl0ZW0sIC4uLm9wdGlvbnMpLFxyXG4gICAgICB7XHJcbiAgICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zdWNjZXNzQ3JlYXRlTWVzc2FnZSAhPT0gJycpIHtcclxuICAgICAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogdGhpcy5zdWNjZXNzVXBkYXRlTWVzc2FnZSA/PyAnQXR1YWxpemFkbyBjb20gc3VjZXNzbyEnLFxyXG4gICAgICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLnN1Y2Nlc3MsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLmludmFsaWRhdGVRdWVyaWVzKClcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uRXJyb3I6IChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgaWYgKGVycm9yLmVycm9ycz8ubWVzc2FnZXM/Lmxlbmd0aCAhPT0gdW5kZWZpbmVkICYmIGVycm9yLmVycm9ycz8ubWVzc2FnZXM/Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgZXJyb3IuZXJyb3JzPy5tZXNzYWdlcz8uZm9yRWFjaChtZXNzYWdlID0+IHNob3dOb3RpZmljYXRpb24oe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UubWVzc2FnZSxcclxuICAgICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiAnSG91dmUgdW0gcHJvYmxlbWEgbm8gc2Vydmlkb3InLFxyXG4gICAgICAgICAgICAgIHR5cGU6IE1lc3NhZ2VCYXJUeXBlLmVycm9yLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICB1c2VEZWxldGUgKC4uLm9wdGlvbnM6IHVua25vd25bXSk6IFVzZU11dGF0aW9uUmVzdWx0PHZvaWQsIEFwaUVycm9yLCBRfHVua25vd25bXT4ge1xyXG4gICAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcclxuICAgIHJldHVybiB1c2VNdXRhdGlvbihcclxuICAgICAgKGl0ZW06IFF8dW5rbm93bltdKSA9PiB7XHJcbiAgICAgICAgaWYgKCEoaXRlbSBpbnN0YW5jZW9mIEFycmF5KSAmJiBpdGVtLmlkKSB7XHJcbiAgICAgICAgICByZXR1cm4gdGhpcy5yZXNvdXJjZVNlcnZpY2UuZGVsZXRlKGl0ZW0uaWQsIC4uLm9wdGlvbnMpXHJcbiAgICAgICAgfSBlbHNlIGlmIChpdGVtIGluc3RhbmNlb2YgQXJyYXkgJiYgaXRlbS5sZW5ndGgpIHtcclxuICAgICAgICAgIHJldHVybiB0aGlzLnJlc291cmNlU2VydmljZS5kZWxldGUoaXRlbSwgLi4ub3B0aW9ucylcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnN1Y2Nlc3NEZWxldGVNZXNzYWdlICE9PSAnJykge1xyXG4gICAgICAgICAgICBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLnN1Y2Nlc3NEZWxldGVNZXNzYWdlID8/ICdFeGNsdcOtZG8gY29tIHN1Y2Vzc28hJyxcclxuICAgICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5zdWNjZXNzLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy5pbnZhbGlkYXRlUXVlcmllcygpXHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkVycm9yOiAoZXJyb3IpID0+IHtcclxuICAgICAgICAgIGlmIChlcnJvci5lcnJvcnM/Lm1lc3NhZ2VzPy5sZW5ndGggIT09IHVuZGVmaW5lZCAmJiBlcnJvci5lcnJvcnM/Lm1lc3NhZ2VzPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGVycm9yLmVycm9ycz8ubWVzc2FnZXM/LmZvckVhY2gobWVzc2FnZSA9PiBzaG93Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiBtZXNzYWdlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgICAgdHlwZTogTWVzc2FnZUJhclR5cGUuZXJyb3IsXHJcbiAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2hvd05vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogJ0hvdXZlIHVtIHByb2JsZW1hIG5vIHNlcnZpZG9yJyxcclxuICAgICAgICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgdXNlRmluZEFsbFF1ZXJ5ICguLi5vcHRpb25zOiB1bmtub3duW10pOiBVc2VRdWVyeVJlc3VsdDxRW10sIEFwaUVycm9yPiB7XHJcbiAgICByZXR1cm4gdXNlUXVlcnkoXHJcbiAgICAgIFt0aGlzLmtleSwgLi4ub3B0aW9uc10sXHJcbiAgICAgICgpID0+IHRoaXMucmVzb3VyY2VTZXJ2aWNlLmZpbmRRdWVyeSguLi5vcHRpb25zKSxcclxuICAgIClcclxuICB9XHJcblxyXG4gIHVzZUZpbmRBbGxRdWVyeVBhZ2luYXRlZCAoLi4ub3B0aW9uczogdW5rbm93bltdKTogVXNlUXVlcnlSZXN1bHQ8UGFnaW5hdGVkUmVzcG9uc2U8UT4sIEFwaUVycm9yPiB7XHJcbiAgICByZXR1cm4gdXNlUXVlcnkoXHJcbiAgICAgIFt0aGlzLmtleSwgLi4ub3B0aW9uc10sXHJcbiAgICAgICgpID0+IHRoaXMucmVzb3VyY2VTZXJ2aWNlLmZpbmRRdWVyeSguLi5vcHRpb25zKSxcclxuICAgICAge1xyXG4gICAgICAgIGtlZXBQcmV2aW91c0RhdGE6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBpbnZhbGlkYXRlUXVlcmllcyAoKTogdm9pZCB7XHJcbiAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyhbdGhpcy5rZXldKVxyXG4gIH1cclxufVxyXG4iXSwibWFwcGluZ3MiOiJBQUNBLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsYUFBZ0MsZ0JBQWdDO0FBR3pFLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsd0JBQXdCO0FBSTFCLGFBQU0scUJBQXlEO0FBQUEsRUFDcEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFFQSxZQUFhLEtBQWEsaUJBQXdDLHNCQUErQixzQkFBK0Isc0JBQStCO0FBQzdKLFNBQUssa0JBQWtCO0FBQ3ZCLFNBQUssTUFBTTtBQUNYLFNBQUssdUJBQXVCO0FBQzVCLFNBQUssdUJBQXVCO0FBQzVCLFNBQUssdUJBQXVCO0FBQUEsRUFDOUI7QUFBQSxFQUVBLDBCQUEyQixhQUFxQixTQUFvRTtBQUNsSCxXQUFPO0FBQUEsTUFDTCxDQUFDLEtBQUssS0FBSyxHQUFHLE9BQU87QUFBQSxNQUNyQixNQUFNLEtBQUssZ0JBQWdCLGlCQUFpQixHQUFHLE9BQU87QUFBQSxNQUN0RDtBQUFBLFFBQ0UsaUJBQWlCO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsMkJBQTRCLE9BQWUsU0FBaUQ7QUFDMUYsV0FBTztBQUFBLE1BQ0wsQ0FBQyxLQUFLLEtBQUssR0FBRyxPQUFPO0FBQUEsTUFDckIsTUFBTSxLQUFLLGdCQUFnQixRQUFRLEVBQUU7QUFBQSxNQUNyQztBQUFBLFFBQ0UsU0FBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsOEJBQStCLFNBQW9FO0FBQ2pHLFdBQU87QUFBQSxNQUNMLENBQUMsS0FBSyxLQUFLLEdBQUcsT0FBTztBQUFBLE1BQ3JCLE1BQU0sS0FBSyxnQkFBZ0IsaUJBQWlCLEdBQUcsT0FBTztBQUFBLE1BQ3REO0FBQUEsUUFDRSxrQkFBa0I7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSwwQkFBMkIsVUFBa0IsT0FBZSxTQUFzRDtBQUNoSCxXQUFPO0FBQUEsTUFDTCxDQUFDLEtBQUssS0FBSyxJQUFJLEdBQUcsT0FBTztBQUFBLE1BQ3pCLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUSxJQUFJLEdBQUcsT0FBTztBQUFBLE1BQ2pEO0FBQUEsUUFDRSxpQkFBaUI7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSx1QkFBd0IsU0FBb0U7QUFDMUYsV0FBTztBQUFBLE1BQ0wsQ0FBQyxLQUFLLEtBQUssR0FBRyxPQUFPO0FBQUEsTUFDckIsTUFBTSxLQUFLLGdCQUFnQixpQkFBaUIsR0FBRyxPQUFPO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxjQUFlLFNBQW1EO0FBQ2hFLFdBQU87QUFBQSxNQUNMLENBQUMsS0FBSyxLQUFLLEdBQUcsT0FBTztBQUFBLE1BQ3JCLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUSxHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFBQSxFQUVBLFdBQVksT0FBZSxTQUFzRDtBQUMvRSxXQUFPO0FBQUEsTUFDTCxDQUFDLEtBQUssS0FBSyxJQUFJLEdBQUcsT0FBTztBQUFBLE1BQ3pCLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUSxJQUFJLEdBQUcsT0FBTztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUFBLEVBRUEsMkJBQTRCLE9BQWUsU0FBc0Q7QUFDL0YsV0FBTztBQUFBLE1BQ0wsQ0FBQyxLQUFLLEtBQUssSUFBSSxHQUFHLE9BQU87QUFBQSxNQUN6QixNQUFNLEtBQUssZ0JBQWdCLFFBQVEsSUFBSSxHQUFHLE9BQU87QUFBQSxNQUNqRDtBQUFBLFFBQ0Usa0JBQWtCO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsYUFBYyxTQUE0RDtBQUN4RSxVQUFNLEVBQUUsaUJBQWlCLElBQUksaUJBQWlCO0FBQzlDLFdBQU87QUFBQSxNQUNMLENBQUMsU0FBWSxLQUFLLGdCQUFnQixPQUFPLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDekQ7QUFBQSxRQUNFLFdBQVcsTUFBTTtBQUNmLGNBQUksS0FBSyx5QkFBeUIsSUFBSTtBQUNwQyw2QkFBaUI7QUFBQSxjQUNmLFNBQVMsS0FBSyx3QkFBd0I7QUFBQSxjQUN0QyxNQUFNLGVBQWU7QUFBQSxZQUN2QixDQUFDO0FBQUEsVUFDSDtBQUNBLGVBQUssa0JBQWtCO0FBQUEsUUFDekI7QUFBQSxRQUNBLFNBQVMsQ0FBQyxVQUFVO0FBQ2xCLGNBQUksTUFBTSxRQUFRLFVBQVUsV0FBVyxVQUFhLE1BQU0sUUFBUSxVQUFVLFNBQVMsR0FBRztBQUN0RixrQkFBTSxRQUFRLFVBQVUsUUFBUSxhQUFXLGlCQUFpQjtBQUFBLGNBQzFELFNBQVMsUUFBUTtBQUFBLGNBQ2pCLE1BQU0sZUFBZTtBQUFBLFlBQ3ZCLENBQUMsQ0FBQztBQUFBLFVBQ0osT0FBTztBQUNMLDZCQUFpQjtBQUFBLGNBQ2YsU0FBUztBQUFBLGNBQ1QsTUFBTSxlQUFlO0FBQUEsWUFDdkIsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxhQUFjLFNBQW9FO0FBQ2hGLFVBQU0sRUFBRSxpQkFBaUIsSUFBSSxpQkFBaUI7QUFDOUMsV0FBTztBQUFBLE1BQ0wsQ0FBQyxTQUFnQixLQUFLLGdCQUFnQixPQUFPLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDN0Q7QUFBQSxRQUNFLFdBQVcsTUFBTTtBQUNmLGNBQUksS0FBSyx5QkFBeUIsSUFBSTtBQUNwQyw2QkFBaUI7QUFBQSxjQUNmLFNBQVMsS0FBSyx3QkFBd0I7QUFBQSxjQUN0QyxNQUFNLGVBQWU7QUFBQSxZQUN2QixDQUFDO0FBQUEsVUFDSDtBQUNBLGVBQUssa0JBQWtCO0FBQUEsUUFDekI7QUFBQSxRQUNBLFNBQVMsQ0FBQyxVQUFVO0FBQ2xCLGNBQUksTUFBTSxRQUFRLFVBQVUsV0FBVyxVQUFhLE1BQU0sUUFBUSxVQUFVLFNBQVMsR0FBRztBQUN0RixrQkFBTSxRQUFRLFVBQVUsUUFBUSxhQUFXLGlCQUFpQjtBQUFBLGNBQzFELFNBQVMsUUFBUTtBQUFBLGNBQ2pCLE1BQU0sZUFBZTtBQUFBLFlBQ3ZCLENBQUMsQ0FBQztBQUFBLFVBQ0osT0FBTztBQUNMLDZCQUFpQjtBQUFBLGNBQ2YsU0FBUztBQUFBLGNBQ1QsTUFBTSxlQUFlO0FBQUEsWUFDdkIsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxhQUFjLFNBQW9FO0FBQ2hGLFVBQU0sRUFBRSxpQkFBaUIsSUFBSSxpQkFBaUI7QUFDOUMsV0FBTztBQUFBLE1BQ0wsQ0FBQyxTQUFzQjtBQUNyQixZQUFJLEVBQUUsZ0JBQWdCLFVBQVUsS0FBSyxJQUFJO0FBQ3ZDLGlCQUFPLEtBQUssZ0JBQWdCLE9BQU8sS0FBSyxJQUFJLEdBQUcsT0FBTztBQUFBLFFBQ3hELFdBQVcsZ0JBQWdCLFNBQVMsS0FBSyxRQUFRO0FBQy9DLGlCQUFPLEtBQUssZ0JBQWdCLE9BQU8sTUFBTSxHQUFHLE9BQU87QUFBQSxRQUNyRDtBQUNBLGVBQU8sUUFBUSxRQUFRO0FBQUEsTUFDekI7QUFBQSxNQUNBO0FBQUEsUUFDRSxXQUFXLE1BQU07QUFDZixjQUFJLEtBQUsseUJBQXlCLElBQUk7QUFDcEMsNkJBQWlCO0FBQUEsY0FDZixTQUFTLEtBQUssd0JBQXdCO0FBQUEsY0FDdEMsTUFBTSxlQUFlO0FBQUEsWUFDdkIsQ0FBQztBQUFBLFVBQ0g7QUFDQSxlQUFLLGtCQUFrQjtBQUFBLFFBQ3pCO0FBQUEsUUFDQSxTQUFTLENBQUMsVUFBVTtBQUNsQixjQUFJLE1BQU0sUUFBUSxVQUFVLFdBQVcsVUFBYSxNQUFNLFFBQVEsVUFBVSxTQUFTLEdBQUc7QUFDdEYsa0JBQU0sUUFBUSxVQUFVLFFBQVEsYUFBVyxpQkFBaUI7QUFBQSxjQUMxRCxTQUFTLFFBQVE7QUFBQSxjQUNqQixNQUFNLGVBQWU7QUFBQSxZQUN2QixDQUFDLENBQUM7QUFBQSxVQUNKLE9BQU87QUFDTCw2QkFBaUI7QUFBQSxjQUNmLFNBQVM7QUFBQSxjQUNULE1BQU0sZUFBZTtBQUFBLFlBQ3ZCLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsbUJBQW9CLFNBQW1EO0FBQ3JFLFdBQU87QUFBQSxNQUNMLENBQUMsS0FBSyxLQUFLLEdBQUcsT0FBTztBQUFBLE1BQ3JCLE1BQU0sS0FBSyxnQkFBZ0IsVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLDRCQUE2QixTQUFvRTtBQUMvRixXQUFPO0FBQUEsTUFDTCxDQUFDLEtBQUssS0FBSyxHQUFHLE9BQU87QUFBQSxNQUNyQixNQUFNLEtBQUssZ0JBQWdCLFVBQVUsR0FBRyxPQUFPO0FBQUEsTUFDL0M7QUFBQSxRQUNFLGtCQUFrQjtBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLG9CQUEyQjtBQUN6QixnQkFBWSxrQkFBa0IsQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUFBLEVBQzFDO0FBQ0Y7IiwibmFtZXMiOltdfQ==