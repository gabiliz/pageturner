import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/layout/SideBar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { SidebarStyled } from "/src/shared/components/layout/SideBar.styles.ts";
const SideBar = ({
  ...props
}) => {
  return /* @__PURE__ */ jsxDEV(SidebarStyled, { ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBar.tsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
};
_c = SideBar;
export default SideBar;
var _c;
$RefreshReg$(_c, "SideBar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/layout/SideBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0k7QUFQSiwyQkFBMkI7QUFBRUEsSUFBaUI7QUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDN0QsU0FBU0MscUJBQXFCO0FBSTlCLE1BQU1DLFVBQTRCQSxDQUFDO0FBQUEsRUFBRSxHQUFHQztBQUFNLE1BQU07QUFDbEQsU0FDRSx1QkFBQyxpQkFDQyxHQUFJQSxTQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FDWTtBQUdoQjtBQUFDQyxLQU5LRjtBQVFOLGVBQWVBO0FBQU8sSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlByb3BzV2l0aENoaWxkcmVuIiwiU2lkZWJhclN0eWxlZCIsIlNpZGVCYXIiLCJwcm9wcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2lkZUJhci50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9sYXlvdXQvU2lkZUJhci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgSFRNTEF0dHJpYnV0ZXMsIFByb3BzV2l0aENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBTaWRlYmFyU3R5bGVkIH0gZnJvbSAnLi9TaWRlQmFyLnN0eWxlcydcblxudHlwZSBTaWRlQmFyUHJvcHMgPSBQcm9wc1dpdGhDaGlsZHJlbjxIVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4+XG5cbmNvbnN0IFNpZGVCYXI6IEZDPFNpZGVCYXJQcm9wcz4gPSAoeyAuLi5wcm9wcyB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPFNpZGViYXJTdHlsZWRcbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFNpZGVCYXJcbiJdfQ==