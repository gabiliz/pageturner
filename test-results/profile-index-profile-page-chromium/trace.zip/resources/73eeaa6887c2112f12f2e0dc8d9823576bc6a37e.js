import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { AppPage } from "/src/shared/components/index.ts?t=1701096626433";
import { FinancialStatementsBreadcrumb, FinancialStatementsList } from "/src/modules/audit/financialStatements/components/index.ts?t=1701096626433";
const FinancialStatementsPage = () => {
  return /* @__PURE__ */ jsxDEV(AppPage, { title: "Demonstrações financeiras", renderBreadCrumb: () => /* @__PURE__ */ jsxDEV(FinancialStatementsBreadcrumb, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx",
    lineNumber: 5,
    columnNumber: 77
  }, this), children: /* @__PURE__ */ jsxDEV(FinancialStatementsList, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
};
_c = FinancialStatementsPage;
export default FinancialStatementsPage;
var _c;
$RefreshReg$(_c, "FinancialStatementsPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/financialStatements/pages/FinancialStatementsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUThCO0FBUjlCLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsK0JBQStCQywrQkFBK0I7QUFFdkUsTUFBTUMsMEJBQThCQSxNQUFNO0FBQ3hDLFNBQ0UsdUJBQUMsV0FDQyxPQUFNLDZCQUNOLGtCQUFrQixNQUFNLHVCQUFDLG1DQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEIsR0FFdEQsaUNBQUMsNkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QixLQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDQyxLQVRLRDtBQVdOLGVBQWVBO0FBQXVCLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJBcHBQYWdlIiwiRmluYW5jaWFsU3RhdGVtZW50c0JyZWFkY3J1bWIiLCJGaW5hbmNpYWxTdGF0ZW1lbnRzTGlzdCIsIkZpbmFuY2lhbFN0YXRlbWVudHNQYWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaW5hbmNpYWxTdGF0ZW1lbnRzUGFnZS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2ZpbmFuY2lhbFN0YXRlbWVudHMvcGFnZXMvRmluYW5jaWFsU3RhdGVtZW50c1BhZ2UudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEFwcFBhZ2UgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IEZpbmFuY2lhbFN0YXRlbWVudHNCcmVhZGNydW1iLCBGaW5hbmNpYWxTdGF0ZW1lbnRzTGlzdCB9IGZyb20gJy4uL2NvbXBvbmVudHMnXG5cbmNvbnN0IEZpbmFuY2lhbFN0YXRlbWVudHNQYWdlOiBGQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8QXBwUGFnZVxuICAgICAgdGl0bGU9J0RlbW9uc3RyYcOnw7VlcyBmaW5hbmNlaXJhcydcbiAgICAgIHJlbmRlckJyZWFkQ3J1bWI9eygpID0+IDxGaW5hbmNpYWxTdGF0ZW1lbnRzQnJlYWRjcnVtYiAvPn1cbiAgICA+XG4gICAgICA8RmluYW5jaWFsU3RhdGVtZW50c0xpc3QgLz5cbiAgICA8L0FwcFBhZ2U+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRmluYW5jaWFsU3RhdGVtZW50c1BhZ2VcbiJdfQ==