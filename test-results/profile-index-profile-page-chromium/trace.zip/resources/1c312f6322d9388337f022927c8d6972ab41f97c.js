import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/dialog/ConfirmDeletion.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDeletion.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { DangerButton, DefaultButton } from "/src/shared/components/index.ts?t=1701096626433";
import ConfirmDialog from "/src/shared/components/dialog/ConfirmDialog.tsx?t=1701096626433";
const ConfirmDeletion = (props) => {
  const {
    hidden,
    onDismiss,
    onConfirm,
    deleteTitle,
    deleteSubtitle
  } = props;
  return /* @__PURE__ */ jsxDEV(ConfirmDialog, { hidden, onDismiss, title: deleteTitle ?? "Deletar Dados?", description: deleteSubtitle ?? "Você tem certeza que deseja excluir esses dados?", actions: () => [/* @__PURE__ */ jsxDEV(DefaultButton, { onClick: onDismiss, children: "Cancelar" }, "cancel", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDeletion.tsx",
    lineNumber: 19,
    columnNumber: 202
  }, this), /* @__PURE__ */ jsxDEV(DangerButton, { onClick: onConfirm, children: "Excluir" }, "confirm", false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDeletion.tsx",
    lineNumber: 21,
    columnNumber: 27
  }, this)] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDeletion.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_c = ConfirmDeletion;
export default ConfirmDeletion;
var _c;
$RefreshReg$(_c, "ConfirmDeletion");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/dialog/ConfirmDeletion.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJRO0FBNUJSLDJCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLFNBQVNBLGNBQWNDLHFCQUFxQjtBQUM1QyxPQUFPQyxtQkFBbUI7QUFVMUIsTUFBTUMsa0JBQTZDQyxXQUFVO0FBQzNELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlMO0FBRUosU0FDRSx1QkFBQyxpQkFDQyxRQUNBLFdBQ0EsT0FBT0ksZUFBZSxrQkFDdEIsYUFBYUMsa0JBQWtCLG9EQUMvQixTQUFTLE1BQU0sQ0FDYix1QkFBQyxpQkFFQyxTQUFTSCxXQUFVLHdCQURmLFVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBLEdBQ0EsdUJBQUMsZ0JBRUMsU0FBU0MsV0FBVSx1QkFEZixXQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxDQUFlLEtBakJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JJO0FBR1I7QUFBQ0csS0EvQktQO0FBaUNOLGVBQWVBO0FBQWUsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRhbmdlckJ1dHRvbiIsIkRlZmF1bHRCdXR0b24iLCJDb25maXJtRGlhbG9nIiwiQ29uZmlybURlbGV0aW9uIiwicHJvcHMiLCJoaWRkZW4iLCJvbkRpc21pc3MiLCJvbkNvbmZpcm0iLCJkZWxldGVUaXRsZSIsImRlbGV0ZVN1YnRpdGxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb25maXJtRGVsZXRpb24udHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZGlhbG9nL0NvbmZpcm1EZWxldGlvbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgRGFuZ2VyQnV0dG9uLCBEZWZhdWx0QnV0dG9uIH0gZnJvbSAnLi4nXG5pbXBvcnQgQ29uZmlybURpYWxvZyBmcm9tICcuL0NvbmZpcm1EaWFsb2cnXG5cbmludGVyZmFjZSBDb25maXJtRGVsZXRpb25Qcm9wcyB7XG4gIGRlbGV0ZVRpdGxlPzogc3RyaW5nXG4gIGRlbGV0ZVN1YnRpdGxlPzogc3RyaW5nXG4gIGhpZGRlbj86IGJvb2xlYW5cbiAgb25EaXNtaXNzPzogKCkgPT4gdm9pZFxuICBvbkNvbmZpcm0/OiAoKSA9PiB2b2lkXG59XG5cbmNvbnN0IENvbmZpcm1EZWxldGlvbjogRkM8Q29uZmlybURlbGV0aW9uUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBoaWRkZW4sXG4gICAgb25EaXNtaXNzLFxuICAgIG9uQ29uZmlybSxcbiAgICBkZWxldGVUaXRsZSxcbiAgICBkZWxldGVTdWJ0aXRsZSxcbiAgfSA9IHByb3BzXG5cbiAgcmV0dXJuIChcbiAgICA8Q29uZmlybURpYWxvZ1xuICAgICAgaGlkZGVuPXtoaWRkZW59XG4gICAgICBvbkRpc21pc3M9e29uRGlzbWlzc31cbiAgICAgIHRpdGxlPXtkZWxldGVUaXRsZSA/PyAnRGVsZXRhciBEYWRvcz8nfVxuICAgICAgZGVzY3JpcHRpb249e2RlbGV0ZVN1YnRpdGxlID8/ICdWb2PDqiB0ZW0gY2VydGV6YSBxdWUgZGVzZWphIGV4Y2x1aXIgZXNzZXMgZGFkb3M/J31cbiAgICAgIGFjdGlvbnM9eygpID0+IFtcbiAgICAgICAgPERlZmF1bHRCdXR0b25cbiAgICAgICAgICBrZXk9XCJjYW5jZWxcIlxuICAgICAgICAgIG9uQ2xpY2s9e29uRGlzbWlzc31cbiAgICAgICAgPlxuICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgIDwvRGVmYXVsdEJ1dHRvbj4sXG4gICAgICAgIDxEYW5nZXJCdXR0b25cbiAgICAgICAgICBrZXk9XCJjb25maXJtXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19XG4gICAgICAgID5cbiAgICAgICAgICBFeGNsdWlyXG4gICAgICAgIDwvRGFuZ2VyQnV0dG9uPixcbiAgICAgIF19XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb25maXJtRGVsZXRpb25cbiJdfQ==