// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? global : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: 0 /* Mode.sync */,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
export function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === 1 /* Mode.async */) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
export function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
export function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
export function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    return setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
export function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
export function clearStyles(option) {
    if (option === void 0) { option = 3 /* ClearStyleOptions.all */; }
    if (option === 3 /* ClearStyleOptions.all */ || option === 2 /* ClearStyleOptions.onlyNonThemable */) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === 3 /* ClearStyleOptions.all */ || option === 1 /* ClearStyleOptions.onlyThemable */) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(1 /* ClearStyleOptions.onlyThemable */);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
export function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                typeof DEBUG !== 'undefined' &&
                DEBUG) {
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
export function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}
                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsNEZBQTRGO0FBQzVGLDJEQUEyRDs7Ozs7Ozs7Ozs7O0FBeUczRCw0RkFBNEY7QUFDNUYseUNBQXlDO0FBQ3pDLElBQU0sS0FBSyxHQUFRLE9BQU8sTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyx5REFBeUQ7QUFFN0gseUdBQXlHO0FBQ3pHLElBQU0sV0FBVyxHQUFXLEtBQUssSUFBSSxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO0FBRWxGLElBQU0sV0FBVyxHQUFnQixvQkFBb0IsRUFBRSxDQUFDO0FBRXhEOztHQUVHO0FBQ0gsSUFBTSxnQkFBZ0IsR0FDcEIsZ0hBQWdILENBQUM7QUFFbkgsSUFBTSxHQUFHLEdBQWlCO0lBQ3hCLE9BQUEsT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFBeEYsQ0FBd0YsQ0FBQztBQUUzRixTQUFTLE9BQU8sQ0FBQyxJQUFnQjtJQUMvQixJQUFNLEtBQUssR0FBVyxHQUFHLEVBQUUsQ0FBQztJQUM1QixJQUFJLEVBQUUsQ0FBQztJQUNQLElBQU0sR0FBRyxHQUFXLEdBQUcsRUFBRSxDQUFDO0lBQzFCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUM7QUFDM0MsQ0FBQztBQUVEOztHQUVHO0FBQ0gsU0FBUyxvQkFBb0I7SUFDM0IsSUFBSSxLQUFLLEdBQWdCLEtBQUssQ0FBQyxjQUFjLElBQUk7UUFDL0MsS0FBSyxFQUFFLFNBQVM7UUFDaEIsZ0JBQWdCLEVBQUUsU0FBUztRQUMzQixnQkFBZ0IsRUFBRSxFQUFFO0tBQ3JCLENBQUM7SUFFRixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTtRQUNuQixLQUFLLHlCQUNBLEtBQUssS0FDUixJQUFJLEVBQUU7Z0JBQ0osS0FBSyxFQUFFLENBQUM7Z0JBQ1IsUUFBUSxFQUFFLENBQUM7YUFDWixFQUNELFFBQVEsRUFBRTtnQkFDUixVQUFVLEVBQUUsQ0FBQztnQkFDYixJQUFJLG1CQUFXO2dCQUNmLE1BQU0sRUFBRSxFQUFFO2FBQ1gsR0FDRixDQUFDO0tBQ0g7SUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixFQUFFO1FBQ25DLEtBQUsseUJBQ0EsS0FBSyxLQUNSLHdCQUF3QixFQUFFLEVBQUUsR0FDN0IsQ0FBQztLQUNIO0lBQ0QsS0FBSyxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDN0IsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFNLFVBQVUsVUFBVSxDQUFDLE1BQThCLEVBQUUsU0FBMEI7SUFBMUIsMEJBQUEsRUFBQSxpQkFBMEI7SUFDbkYsT0FBTyxDQUFDO1FBQ04sSUFBTSxVQUFVLEdBQWtCLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pGLElBQUEsS0FBK0IsV0FBVyxDQUFDLFFBQVEsRUFBakQsSUFBSSxVQUFBLEVBQUUsTUFBTSxZQUFBLEVBQUUsVUFBVSxnQkFBeUIsQ0FBQztRQUMxRCxJQUFJLFNBQVMsSUFBSSxJQUFJLHVCQUFlLEVBQUU7WUFDcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNmLFdBQVcsQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLGVBQWUsRUFBRSxDQUFDO2FBQ3JEO1NBQ0Y7YUFBTTtZQUNMLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ2pDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sVUFBVSxtQkFBbUIsQ0FDakMsWUFBaUc7SUFFakcsV0FBVyxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUM7QUFDeEMsQ0FBQztBQUVEOzs7R0FHRztBQUNILE1BQU0sVUFBVSxnQkFBZ0IsQ0FBQyxJQUFVO0lBQ3pDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUNuQyxDQUFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLFVBQVUsS0FBSztJQUNuQixPQUFPLENBQUM7UUFDTixJQUFNLFdBQVcsR0FBb0IsV0FBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekUsV0FBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2pDLElBQU0sZ0JBQWdCLEdBQW1CLEVBQW9CLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDNUYsSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQy9CLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDdkM7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMsZUFBZTtJQUN0QixPQUFPLFVBQVUsQ0FBQztRQUNoQixXQUFXLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7UUFDcEMsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxTQUFTLG1CQUFtQixDQUFDLFdBQTBCLEVBQUUsV0FBMEI7SUFDakYsSUFBSSxXQUFXLENBQUMsVUFBVSxFQUFFO1FBQzFCLFdBQVcsQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0tBQ3BGO1NBQU07UUFDTCxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDN0I7QUFDSCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sVUFBVSxTQUFTLENBQUMsS0FBeUI7SUFDakQsV0FBVyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFFMUIsaUJBQWlCO0lBQ2pCLFlBQVksRUFBRSxDQUFDO0FBQ2pCLENBQUM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxVQUFVLFdBQVcsQ0FBQyxNQUFpRDtJQUFqRCx1QkFBQSxFQUFBLHNDQUFpRDtJQUMzRSxJQUFJLE1BQU0sa0NBQTBCLElBQUksTUFBTSw4Q0FBc0MsRUFBRTtRQUNwRixtQkFBbUIsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNsRCxXQUFXLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO0tBQ25DO0lBQ0QsSUFBSSxNQUFNLGtDQUEwQixJQUFJLE1BQU0sMkNBQW1DLEVBQUU7UUFDakYsbUJBQW1CLENBQUMsV0FBVyxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDMUQsV0FBVyxDQUFDLHdCQUF3QixHQUFHLEVBQUUsQ0FBQztLQUMzQztBQUNILENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLE9BQXVCO0lBQ2xELE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBQyxXQUF5QjtRQUN4QyxJQUFNLFlBQVksR0FBcUIsV0FBVyxJQUFLLFdBQVcsQ0FBQyxZQUFpQyxDQUFDO1FBQ3JHLElBQUksWUFBWSxJQUFJLFlBQVksQ0FBQyxhQUFhLEVBQUU7WUFDOUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDdEQ7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMsWUFBWTtJQUNuQixJQUFJLFdBQVcsQ0FBQyxLQUFLLEVBQUU7UUFDckIsSUFBTSxjQUFjLEdBQW9CLEVBQUUsQ0FBQztRQUMzQyxLQUEwQixVQUFvQyxFQUFwQyxLQUFBLFdBQVcsQ0FBQyx3QkFBd0IsRUFBcEMsY0FBb0MsRUFBcEMsSUFBb0MsRUFBRTtZQUEzRCxJQUFNLFdBQVcsU0FBQTtZQUNwQixjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUNoRDtRQUNELElBQUksY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDN0IsV0FBVyx3Q0FBZ0MsQ0FBQztZQUM1QyxtQkFBbUIsQ0FBRSxFQUFvQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUM7U0FDN0U7S0FDRjtBQUNILENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLFVBQVUsVUFBVSxDQUFDLE1BQTBCO0lBQ25ELElBQUksTUFBTSxFQUFFO1FBQ1YsTUFBTSxHQUFHLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztLQUNoRTtJQUVELE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxTQUFTLG9CQUFvQixDQUFDLGVBQThCO0lBQ2xELElBQUEsS0FBSyxHQUFrQixXQUFXLE1BQTdCLENBQThCO0lBQzNDLElBQUksUUFBUSxHQUFZLEtBQUssQ0FBQztJQUM5QixvRUFBb0U7SUFDcEUsdURBQXVEO0lBQ3ZELElBQU0sYUFBYSxHQUEyQixDQUFDLGVBQWUsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQ3ZFLFVBQUMsWUFBaUM7UUFDaEMsSUFBTSxTQUFTLEdBQXVCLFlBQVksQ0FBQyxLQUFLLENBQUM7UUFDekQsSUFBSSxTQUFTLEVBQUU7WUFDYixRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ2hCLG9DQUFvQztZQUNwQyxJQUFNLFdBQVcsR0FBdUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUM3RSxJQUFNLFlBQVksR0FBVyxZQUFZLENBQUMsWUFBWSxJQUFJLFNBQVMsQ0FBQztZQUVwRSwwR0FBMEc7WUFDMUcsaUZBQWlGO1lBQ2pGLElBQ0UsS0FBSztnQkFDTCxDQUFDLFdBQVc7Z0JBQ1osT0FBTztnQkFDUCxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQztnQkFDckIsT0FBTyxLQUFLLEtBQUssV0FBVztnQkFDNUIsS0FBSyxFQUNMO2dCQUNBLE9BQU8sQ0FBQyxJQUFJLENBQUMsMkNBQW1DLFNBQVMsbUNBQXVCLFlBQVksUUFBSSxDQUFDLENBQUM7YUFDbkc7WUFFRCxPQUFPLFdBQVcsSUFBSSxZQUFZLENBQUM7U0FDcEM7YUFBTTtZQUNMLHNDQUFzQztZQUN0QyxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUM7U0FDL0I7SUFDSCxDQUFDLENBQ0YsQ0FBQztJQUVGLE9BQU87UUFDTCxXQUFXLEVBQUUsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDbkMsUUFBUSxFQUFFLFFBQVE7S0FDbkIsQ0FBQztBQUNKLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLFVBQVUsV0FBVyxDQUFDLE1BQWM7SUFDeEMsSUFBTSxNQUFNLEdBQWtCLEVBQUUsQ0FBQztJQUNqQyxJQUFJLE1BQU0sRUFBRTtRQUNWLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQyxDQUFDLDhCQUE4QjtRQUNuRCxJQUFJLFVBQVUsU0FBd0IsQ0FBQztRQUN2QyxPQUFPLENBQUMsVUFBVSxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFO1lBQ25ELElBQU0sVUFBVSxHQUFXLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFDNUMsSUFBSSxVQUFVLEdBQUcsR0FBRyxFQUFFO2dCQUNwQixNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNWLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUM7aUJBQzdDLENBQUMsQ0FBQzthQUNKO1lBRUQsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDVixLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDcEIsWUFBWSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7YUFDaEQsQ0FBQyxDQUFDO1lBRUgsdURBQXVEO1lBQ3ZELEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7U0FDbEM7UUFFRCxvREFBb0Q7UUFDcEQsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNWLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztTQUNqQyxDQUFDLENBQUM7S0FDSjtJQUVELE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsY0FBYyxDQUFDLFVBQXlCO0lBQy9DLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxFQUFFO1FBQ25DLE9BQU87S0FDUjtJQUNELElBQU0sSUFBSSxHQUFvQixRQUFRLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkUsSUFBTSxZQUFZLEdBQXFCLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDakUsSUFBQSxLQUE0QixvQkFBb0IsQ0FBQyxVQUFVLENBQUMsRUFBMUQsV0FBVyxpQkFBQSxFQUFFLFFBQVEsY0FBcUMsQ0FBQztJQUVuRSxZQUFZLENBQUMsWUFBWSxDQUFDLHlCQUF5QixFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQzdELElBQUksV0FBVyxFQUFFO1FBQ2YsWUFBWSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7S0FDakQ7SUFDRCxZQUFZLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUMvRCxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3pCLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7SUFFL0IsSUFBTSxFQUFFLEdBQWlELFFBQVEsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUYsRUFBRSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzVFLEVBQUUsQ0FBQyxJQUFJLEdBQUc7UUFDUixRQUFRLEVBQUUsWUFBWTtLQUN2QixDQUFDO0lBQ0YsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUUzQixJQUFNLE1BQU0sR0FBaUI7UUFDM0IsWUFBWSxFQUFFLFlBQVk7UUFDMUIsYUFBYSxFQUFFLFVBQVU7S0FDMUIsQ0FBQztJQUVGLElBQUksUUFBUSxFQUFFO1FBQ1osV0FBVyxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUNuRDtTQUFNO1FBQ0wsV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUMzQztBQUNILENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlLlxuLy8gU2VlIExJQ0VOU0UgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cblxuLyoqXG4gKiBBbiBJVGhlbWluZ0luc3RydWN0aW9uIGNhbiBzcGVjaWZ5IGEgcmF3U3RyaW5nIHRvIGJlIHByZXNlcnZlZCBvciBhIHRoZW1lIHNsb3QgYW5kIGEgZGVmYXVsdCB2YWx1ZVxuICogdG8gdXNlIGlmIHRoYXQgc2xvdCBpcyBub3Qgc3BlY2lmaWVkIGJ5IHRoZSB0aGVtZS5cbiAqL1xuXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdXNlLWJlZm9yZS1kZWZpbmUgKi9cblxuLy8gRGVjbGFyaW5nIGEgZ2xvYmFsIGhlcmUgaW4gY2FzZSB0aGF0IHRoZSBleGVjdXRpb24gZW52aXJvbm1lbnQgaXMgTm9kZS5qcyAod2l0aG91dCBpbXBvcnRpbmcgdGhlXG4vLyBlbnRpcmUgbm9kZS5qcyBkLnRzIGZvciBub3cpXG5kZWNsYXJlIGxldCBnbG9iYWw6IGFueTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVRoZW1pbmdJbnN0cnVjdGlvbiB7XG4gIHRoZW1lPzogc3RyaW5nO1xuICBkZWZhdWx0VmFsdWU/OiBzdHJpbmc7XG4gIHJhd1N0cmluZz86IHN0cmluZztcbn1cblxuZXhwb3J0IHR5cGUgVGhlbWFibGVBcnJheSA9IElUaGVtaW5nSW5zdHJ1Y3Rpb25bXTtcblxuZXhwb3J0IGludGVyZmFjZSBJVGhlbWUge1xuICBba2V5OiBzdHJpbmddOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBJU3R5bGVTaGVldCB7XG4gIGNzc1RleHQ6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIElFeHRlbmRlZEh0bWxTdHlsZUVsZW1lbnQgZXh0ZW5kcyBIVE1MU3R5bGVFbGVtZW50IHtcbiAgc3R5bGVTaGVldDogSVN0eWxlU2hlZXQ7XG59XG5cbi8qKlxuICogUGVyZm9ybWFuY2UgTWVhc3VyZW1lbnQgb2YgbG9hZGluZyBzdHlsZXNcbiAqL1xuaW50ZXJmYWNlIElNZWFzdXJlbWVudCB7XG4gIC8qKlxuICAgKiBDb3VudCBvZiBzdHlsZSBlbGVtZW50IGluamVjdGVkLCB3aGljaCBpcyB0aGUgc2xvdyBvcGVyYXRpb24gaW4gSUVcbiAgICovXG4gIGNvdW50OiBudW1iZXI7XG4gIC8qKlxuICAgKiBUb3RhbCBkdXJhdGlvbiBvZiBhbGwgbG9hZFN0eWxlcyBleGVjdGlvbnNcbiAgICovXG4gIGR1cmF0aW9uOiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBJUnVuU3RhdGUge1xuICBtb2RlOiBNb2RlO1xuICBidWZmZXI6IFRoZW1hYmxlQXJyYXlbXTtcbiAgZmx1c2hUaW1lcjogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgSVRoZW1lU3RhdGUge1xuICB0aGVtZTogSVRoZW1lIHwgdW5kZWZpbmVkO1xuICBsYXN0U3R5bGVFbGVtZW50OiBJRXh0ZW5kZWRIdG1sU3R5bGVFbGVtZW50O1xuICByZWdpc3RlcmVkU3R5bGVzOiBJU3R5bGVSZWNvcmRbXTsgLy8gcmVjb3JkcyBvZiBhbHJlYWR5IHJlZ2lzdGVyZWQgbm9uLXRoZW1hYmxlIHN0eWxlc1xuICByZWdpc3RlcmVkVGhlbWFibGVTdHlsZXM6IElTdHlsZVJlY29yZFtdOyAvLyByZWNvcmRzIG9mIGFscmVhZHkgcmVnaXN0ZXJlZCB0aGVtYWJsZSBzdHlsZXNcbiAgbG9hZFN0eWxlczogKChwcm9jZXNzZWRTdHlsZXM6IHN0cmluZywgcmF3U3R5bGVzPzogc3RyaW5nIHwgVGhlbWFibGVBcnJheSkgPT4gdm9pZCkgfCB1bmRlZmluZWQ7XG4gIHBlcmY6IElNZWFzdXJlbWVudDtcbiAgcnVuU3RhdGU6IElSdW5TdGF0ZTtcbn1cblxuaW50ZXJmYWNlIElTdHlsZVJlY29yZCB7XG4gIHN0eWxlRWxlbWVudDogRWxlbWVudDtcbiAgdGhlbWFibGVTdHlsZTogVGhlbWFibGVBcnJheTtcbn1cblxuaW50ZXJmYWNlIElDdXN0b21FdmVudDxUPiBleHRlbmRzIEV2ZW50IHtcbiAgYXJncz86IFQ7XG59XG5cbi8qKlxuICogb2JqZWN0IHJldHVybmVkIGZyb20gcmVzb2x2ZVRoZW1hYmxlQXJyYXkgZnVuY3Rpb25cbiAqL1xuaW50ZXJmYWNlIElUaGVtYWJsZUFycmF5UmVzb2x2ZVJlc3VsdCB7XG4gIC8qKiB0aGlzIHN0cmluZyBpcyB0aGUgcHJvY2Vzc2VkIHN0eWxlcyBpbiBzdHJpbmcgKi9cbiAgc3R5bGVTdHJpbmc6IHN0cmluZztcblxuICAvKiogdGhpcyBib29sZWFuIGluZGljYXRlcyBpZiB0aGlzIHN0eWxlIGFycmF5IGlzIHRoZW1hYmxlICovXG4gIHRoZW1hYmxlOiBib29sZWFuO1xufVxuXG4vKipcbiAqIEluIHN5bmMgbW9kZSwgc3R5bGVzIGFyZSByZWdpc3RlcmVkIGFzIHN0eWxlIGVsZW1lbnRzIHN5bmNocm9ub3VzbHkgd2l0aCBsb2FkU3R5bGVzKCkgY2FsbC5cbiAqIEluIGFzeW5jIG1vZGUsIHN0eWxlcyBhcmUgYnVmZmVyZWQgYW5kIHJlZ2lzdGVyZWQgYXMgYmF0Y2ggaW4gYXN5bmMgdGltZXIgZm9yIHBlcmZvcm1hbmNlIHB1cnBvc2UuXG4gKi9cbmV4cG9ydCBjb25zdCBlbnVtIE1vZGUge1xuICBzeW5jLFxuICBhc3luY1xufVxuXG4vKipcbiAqIFRoZW1hYmxlIHN0eWxlcyBhbmQgbm9uLXRoZW1hYmxlIHN0eWxlcyBhcmUgdHJhY2tlZCBzZXBhcmF0ZWx5XG4gKiBTcGVjaWZ5IENsZWFyU3R5bGVPcHRpb25zIHdoZW4gY2FsbGluZyBjbGVhclN0eWxlcyBBUEkgdG8gc3BlY2lmeSB3aGljaCBncm91cCBvZiByZWdpc3RlcmVkIHN0eWxlcyBzaG91bGQgYmUgY2xlYXJlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVudW0gQ2xlYXJTdHlsZU9wdGlvbnMge1xuICAvKiogb25seSB0aGVtYWJsZSBzdHlsZXMgd2lsbCBiZSBjbGVhcmVkICovXG4gIG9ubHlUaGVtYWJsZSA9IDEsXG4gIC8qKiBvbmx5IG5vbi10aGVtYWJsZSBzdHlsZXMgd2lsbCBiZSBjbGVhcmVkICovXG4gIG9ubHlOb25UaGVtYWJsZSA9IDIsXG4gIC8qKiBib3RoIHRoZW1hYmxlIGFuZCBub24tdGhlbWFibGUgc3R5bGVzIHdpbGwgYmUgY2xlYXJlZCAqL1xuICBhbGwgPSAzXG59XG5cbi8vIFN0b3JlIHRoZSB0aGVtaW5nIHN0YXRlIGluIF9fdGhlbWVTdGF0ZV9fIGdsb2JhbCBzY29wZSBmb3IgcmV1c2UgaW4gdGhlIGNhc2Ugb2YgZHVwbGljYXRlXG4vLyBsb2FkLXRoZW1lZC1zdHlsZXMgaG9zdGVkIG9uIHRoZSBwYWdlLlxuY29uc3QgX3Jvb3Q6IGFueSA9IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnID8gZ2xvYmFsIDogd2luZG93OyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcblxuLy8gTm9uY2Ugc3RyaW5nIHRvIGluamVjdCBpbnRvIHNjcmlwdCB0YWcgaWYgb25lIHByb3ZpZGVkLiBUaGlzIGlzIHVzZWQgaW4gQ1NQIChDb250ZW50IFNlY3VyaXR5IFBvbGljeSkuXG5jb25zdCBfc3R5bGVOb25jZTogc3RyaW5nID0gX3Jvb3QgJiYgX3Jvb3QuQ1NQU2V0dGluZ3MgJiYgX3Jvb3QuQ1NQU2V0dGluZ3Mubm9uY2U7XG5cbmNvbnN0IF90aGVtZVN0YXRlOiBJVGhlbWVTdGF0ZSA9IGluaXRpYWxpemVUaGVtZVN0YXRlKCk7XG5cbi8qKlxuICogTWF0Y2hlcyB0aGVtaW5nIHRva2Vucy4gRm9yIGV4YW1wbGUsIFwiW3RoZW1lOiB0aGVtZVNsb3ROYW1lLCBkZWZhdWx0OiAjRkZGXVwiIChpbmNsdWRpbmcgdGhlIHF1b3RlcykuXG4gKi9cbmNvbnN0IF90aGVtZVRva2VuUmVnZXg6IFJlZ0V4cCA9XG4gIC9bXFwnXFxcIl1cXFt0aGVtZTpcXHMqKFxcdyspXFxzKig/OlxcLFxccypkZWZhdWx0OlxccyooW1xcXFxcIlxcJ10/W1xcLlxcLFxcKFxcKVxcI1xcLVxcc1xcd10qW1xcLlxcLFxcKFxcKVxcI1xcLVxcd11bXFxcIlxcJ10/KSk/XFxzKlxcXVtcXCdcXFwiXS9nO1xuXG5jb25zdCBub3c6ICgpID0+IG51bWJlciA9ICgpID0+XG4gIHR5cGVvZiBwZXJmb3JtYW5jZSAhPT0gJ3VuZGVmaW5lZCcgJiYgISFwZXJmb3JtYW5jZS5ub3cgPyBwZXJmb3JtYW5jZS5ub3coKSA6IERhdGUubm93KCk7XG5cbmZ1bmN0aW9uIG1lYXN1cmUoZnVuYzogKCkgPT4gdm9pZCk6IHZvaWQge1xuICBjb25zdCBzdGFydDogbnVtYmVyID0gbm93KCk7XG4gIGZ1bmMoKTtcbiAgY29uc3QgZW5kOiBudW1iZXIgPSBub3coKTtcbiAgX3RoZW1lU3RhdGUucGVyZi5kdXJhdGlvbiArPSBlbmQgLSBzdGFydDtcbn1cblxuLyoqXG4gKiBpbml0aWFsaXplIGdsb2JhbCBzdGF0ZSBvYmplY3RcbiAqL1xuZnVuY3Rpb24gaW5pdGlhbGl6ZVRoZW1lU3RhdGUoKTogSVRoZW1lU3RhdGUge1xuICBsZXQgc3RhdGU6IElUaGVtZVN0YXRlID0gX3Jvb3QuX190aGVtZVN0YXRlX18gfHwge1xuICAgIHRoZW1lOiB1bmRlZmluZWQsXG4gICAgbGFzdFN0eWxlRWxlbWVudDogdW5kZWZpbmVkLFxuICAgIHJlZ2lzdGVyZWRTdHlsZXM6IFtdXG4gIH07XG5cbiAgaWYgKCFzdGF0ZS5ydW5TdGF0ZSkge1xuICAgIHN0YXRlID0ge1xuICAgICAgLi4uc3RhdGUsXG4gICAgICBwZXJmOiB7XG4gICAgICAgIGNvdW50OiAwLFxuICAgICAgICBkdXJhdGlvbjogMFxuICAgICAgfSxcbiAgICAgIHJ1blN0YXRlOiB7XG4gICAgICAgIGZsdXNoVGltZXI6IDAsXG4gICAgICAgIG1vZGU6IE1vZGUuc3luYyxcbiAgICAgICAgYnVmZmVyOiBbXVxuICAgICAgfVxuICAgIH07XG4gIH1cbiAgaWYgKCFzdGF0ZS5yZWdpc3RlcmVkVGhlbWFibGVTdHlsZXMpIHtcbiAgICBzdGF0ZSA9IHtcbiAgICAgIC4uLnN0YXRlLFxuICAgICAgcmVnaXN0ZXJlZFRoZW1hYmxlU3R5bGVzOiBbXVxuICAgIH07XG4gIH1cbiAgX3Jvb3QuX190aGVtZVN0YXRlX18gPSBzdGF0ZTtcbiAgcmV0dXJuIHN0YXRlO1xufVxuXG4vKipcbiAqIExvYWRzIGEgc2V0IG9mIHN0eWxlIHRleHQuIElmIGl0IGlzIHJlZ2lzdGVyZWQgdG9vIGVhcmx5LCB3ZSB3aWxsIHJlZ2lzdGVyIGl0IHdoZW4gdGhlIHdpbmRvdy5sb2FkXG4gKiBldmVudCBpcyBmaXJlZC5cbiAqIEBwYXJhbSB7c3RyaW5nIHwgVGhlbWFibGVBcnJheX0gc3R5bGVzIFRoZW1hYmxlIHN0eWxlIHRleHQgdG8gcmVnaXN0ZXIuXG4gKiBAcGFyYW0ge2Jvb2xlYW59IGxvYWRBc3luYyBXaGVuIHRydWUsIGFsd2F5cyBsb2FkIHN0eWxlcyBpbiBhc3luYyBtb2RlLCBpcnJlc3BlY3RpdmUgb2YgY3VycmVudCBzeW5jIG1vZGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb2FkU3R5bGVzKHN0eWxlczogc3RyaW5nIHwgVGhlbWFibGVBcnJheSwgbG9hZEFzeW5jOiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcbiAgbWVhc3VyZSgoKSA9PiB7XG4gICAgY29uc3Qgc3R5bGVQYXJ0czogVGhlbWFibGVBcnJheSA9IEFycmF5LmlzQXJyYXkoc3R5bGVzKSA/IHN0eWxlcyA6IHNwbGl0U3R5bGVzKHN0eWxlcyk7XG4gICAgY29uc3QgeyBtb2RlLCBidWZmZXIsIGZsdXNoVGltZXIgfSA9IF90aGVtZVN0YXRlLnJ1blN0YXRlO1xuICAgIGlmIChsb2FkQXN5bmMgfHwgbW9kZSA9PT0gTW9kZS5hc3luYykge1xuICAgICAgYnVmZmVyLnB1c2goc3R5bGVQYXJ0cyk7XG4gICAgICBpZiAoIWZsdXNoVGltZXIpIHtcbiAgICAgICAgX3RoZW1lU3RhdGUucnVuU3RhdGUuZmx1c2hUaW1lciA9IGFzeW5jTG9hZFN0eWxlcygpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBhcHBseVRoZW1hYmxlU3R5bGVzKHN0eWxlUGFydHMpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8qKlxuICogQWxsb3dzIGZvciBjdXN0b21pemFibGUgbG9hZFN0eWxlcyBsb2dpYy4gZS5nLiBmb3Igc2VydmVyIHNpZGUgcmVuZGVyaW5nIGFwcGxpY2F0aW9uXG4gKiBAcGFyYW0geyhwcm9jZXNzZWRTdHlsZXM6IHN0cmluZywgcmF3U3R5bGVzPzogc3RyaW5nIHwgVGhlbWFibGVBcnJheSkgPT4gdm9pZH1cbiAqIGEgbG9hZFN0eWxlcyBjYWxsYmFjayB0aGF0IGdldHMgY2FsbGVkIHdoZW4gc3R5bGVzIGFyZSBsb2FkZWQgb3IgcmVsb2FkZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmZpZ3VyZUxvYWRTdHlsZXMoXG4gIGxvYWRTdHlsZXNGbjogKChwcm9jZXNzZWRTdHlsZXM6IHN0cmluZywgcmF3U3R5bGVzPzogc3RyaW5nIHwgVGhlbWFibGVBcnJheSkgPT4gdm9pZCkgfCB1bmRlZmluZWRcbik6IHZvaWQge1xuICBfdGhlbWVTdGF0ZS5sb2FkU3R5bGVzID0gbG9hZFN0eWxlc0ZuO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyZSBydW4gbW9kZSBvZiBsb2FkLXRoZW1hYmxlLXN0eWxlc1xuICogQHBhcmFtIG1vZGUgbG9hZC10aGVtYWJsZS1zdHlsZXMgcnVuIG1vZGUsIGFzeW5jIG9yIHN5bmNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmZpZ3VyZVJ1bk1vZGUobW9kZTogTW9kZSk6IHZvaWQge1xuICBfdGhlbWVTdGF0ZS5ydW5TdGF0ZS5tb2RlID0gbW9kZTtcbn1cblxuLyoqXG4gKiBleHRlcm5hbCBjb2RlIGNhbiBjYWxsIGZsdXNoIHRvIHN5bmNocm9ub3VzbHkgZm9yY2UgcHJvY2Vzc2luZyBvZiBjdXJyZW50bHkgYnVmZmVyZWQgc3R5bGVzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmbHVzaCgpOiB2b2lkIHtcbiAgbWVhc3VyZSgoKSA9PiB7XG4gICAgY29uc3Qgc3R5bGVBcnJheXM6IFRoZW1hYmxlQXJyYXlbXSA9IF90aGVtZVN0YXRlLnJ1blN0YXRlLmJ1ZmZlci5zbGljZSgpO1xuICAgIF90aGVtZVN0YXRlLnJ1blN0YXRlLmJ1ZmZlciA9IFtdO1xuICAgIGNvbnN0IG1lcmdlZFN0eWxlQXJyYXk6IFRoZW1hYmxlQXJyYXkgPSAoW10gYXMgVGhlbWFibGVBcnJheSkuY29uY2F0LmFwcGx5KFtdLCBzdHlsZUFycmF5cyk7XG4gICAgaWYgKG1lcmdlZFN0eWxlQXJyYXkubGVuZ3RoID4gMCkge1xuICAgICAgYXBwbHlUaGVtYWJsZVN0eWxlcyhtZXJnZWRTdHlsZUFycmF5KTtcbiAgICB9XG4gIH0pO1xufVxuXG4vKipcbiAqIHJlZ2lzdGVyIGFzeW5jIGxvYWRTdHlsZXNcbiAqL1xuZnVuY3Rpb24gYXN5bmNMb2FkU3R5bGVzKCk6IG51bWJlciB7XG4gIHJldHVybiBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICBfdGhlbWVTdGF0ZS5ydW5TdGF0ZS5mbHVzaFRpbWVyID0gMDtcbiAgICBmbHVzaCgpO1xuICB9LCAwKTtcbn1cblxuLyoqXG4gKiBMb2FkcyBhIHNldCBvZiBzdHlsZSB0ZXh0LiBJZiBpdCBpcyByZWdpc3RlcmVkIHRvbyBlYXJseSwgd2Ugd2lsbCByZWdpc3RlciBpdCB3aGVuIHRoZSB3aW5kb3cubG9hZCBldmVudFxuICogaXMgZmlyZWQuXG4gKiBAcGFyYW0ge3N0cmluZ30gc3R5bGVUZXh0IFN0eWxlIHRvIHJlZ2lzdGVyLlxuICogQHBhcmFtIHtJU3R5bGVSZWNvcmR9IHN0eWxlUmVjb3JkIEV4aXN0aW5nIHN0eWxlIHJlY29yZCB0byByZS1hcHBseS5cbiAqL1xuZnVuY3Rpb24gYXBwbHlUaGVtYWJsZVN0eWxlcyhzdHlsZXNBcnJheTogVGhlbWFibGVBcnJheSwgc3R5bGVSZWNvcmQ/OiBJU3R5bGVSZWNvcmQpOiB2b2lkIHtcbiAgaWYgKF90aGVtZVN0YXRlLmxvYWRTdHlsZXMpIHtcbiAgICBfdGhlbWVTdGF0ZS5sb2FkU3R5bGVzKHJlc29sdmVUaGVtYWJsZUFycmF5KHN0eWxlc0FycmF5KS5zdHlsZVN0cmluZywgc3R5bGVzQXJyYXkpO1xuICB9IGVsc2Uge1xuICAgIHJlZ2lzdGVyU3R5bGVzKHN0eWxlc0FycmF5KTtcbiAgfVxufVxuXG4vKipcbiAqIFJlZ2lzdGVycyBhIHNldCB0aGVtZSB0b2tlbnMgdG8gZmluZCBhbmQgcmVwbGFjZS4gSWYgc3R5bGVzIHdlcmUgYWxyZWFkeSByZWdpc3RlcmVkLCB0aGV5IHdpbGwgYmVcbiAqIHJlcGxhY2VkLlxuICogQHBhcmFtIHt0aGVtZX0gdGhlbWUgSlNPTiBvYmplY3Qgb2YgdGhlbWUgdG9rZW5zIHRvIHZhbHVlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRUaGVtZSh0aGVtZTogSVRoZW1lIHwgdW5kZWZpbmVkKTogdm9pZCB7XG4gIF90aGVtZVN0YXRlLnRoZW1lID0gdGhlbWU7XG5cbiAgLy8gcmVsb2FkIHN0eWxlcy5cbiAgcmVsb2FkU3R5bGVzKCk7XG59XG5cbi8qKlxuICogQ2xlYXIgYWxyZWFkeSByZWdpc3RlcmVkIHN0eWxlIGVsZW1lbnRzIGFuZCBzdHlsZSByZWNvcmRzIGluIHRoZW1lX1N0YXRlIG9iamVjdFxuICogQHBhcmFtIG9wdGlvbiAtIHNwZWNpZnkgd2hpY2ggZ3JvdXAgb2YgcmVnaXN0ZXJlZCBzdHlsZXMgc2hvdWxkIGJlIGNsZWFyZWQuXG4gKiBEZWZhdWx0IHRvIGJlIGJvdGggdGhlbWFibGUgYW5kIG5vbi10aGVtYWJsZSBzdHlsZXMgd2lsbCBiZSBjbGVhcmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbGVhclN0eWxlcyhvcHRpb246IENsZWFyU3R5bGVPcHRpb25zID0gQ2xlYXJTdHlsZU9wdGlvbnMuYWxsKTogdm9pZCB7XG4gIGlmIChvcHRpb24gPT09IENsZWFyU3R5bGVPcHRpb25zLmFsbCB8fCBvcHRpb24gPT09IENsZWFyU3R5bGVPcHRpb25zLm9ubHlOb25UaGVtYWJsZSkge1xuICAgIGNsZWFyU3R5bGVzSW50ZXJuYWwoX3RoZW1lU3RhdGUucmVnaXN0ZXJlZFN0eWxlcyk7XG4gICAgX3RoZW1lU3RhdGUucmVnaXN0ZXJlZFN0eWxlcyA9IFtdO1xuICB9XG4gIGlmIChvcHRpb24gPT09IENsZWFyU3R5bGVPcHRpb25zLmFsbCB8fCBvcHRpb24gPT09IENsZWFyU3R5bGVPcHRpb25zLm9ubHlUaGVtYWJsZSkge1xuICAgIGNsZWFyU3R5bGVzSW50ZXJuYWwoX3RoZW1lU3RhdGUucmVnaXN0ZXJlZFRoZW1hYmxlU3R5bGVzKTtcbiAgICBfdGhlbWVTdGF0ZS5yZWdpc3RlcmVkVGhlbWFibGVTdHlsZXMgPSBbXTtcbiAgfVxufVxuXG5mdW5jdGlvbiBjbGVhclN0eWxlc0ludGVybmFsKHJlY29yZHM6IElTdHlsZVJlY29yZFtdKTogdm9pZCB7XG4gIHJlY29yZHMuZm9yRWFjaCgoc3R5bGVSZWNvcmQ6IElTdHlsZVJlY29yZCkgPT4ge1xuICAgIGNvbnN0IHN0eWxlRWxlbWVudDogSFRNTFN0eWxlRWxlbWVudCA9IHN0eWxlUmVjb3JkICYmIChzdHlsZVJlY29yZC5zdHlsZUVsZW1lbnQgYXMgSFRNTFN0eWxlRWxlbWVudCk7XG4gICAgaWYgKHN0eWxlRWxlbWVudCAmJiBzdHlsZUVsZW1lbnQucGFyZW50RWxlbWVudCkge1xuICAgICAgc3R5bGVFbGVtZW50LnBhcmVudEVsZW1lbnQucmVtb3ZlQ2hpbGQoc3R5bGVFbGVtZW50KTtcbiAgICB9XG4gIH0pO1xufVxuXG4vKipcbiAqIFJlbG9hZHMgc3R5bGVzLlxuICovXG5mdW5jdGlvbiByZWxvYWRTdHlsZXMoKTogdm9pZCB7XG4gIGlmIChfdGhlbWVTdGF0ZS50aGVtZSkge1xuICAgIGNvbnN0IHRoZW1hYmxlU3R5bGVzOiBUaGVtYWJsZUFycmF5W10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHN0eWxlUmVjb3JkIG9mIF90aGVtZVN0YXRlLnJlZ2lzdGVyZWRUaGVtYWJsZVN0eWxlcykge1xuICAgICAgdGhlbWFibGVTdHlsZXMucHVzaChzdHlsZVJlY29yZC50aGVtYWJsZVN0eWxlKTtcbiAgICB9XG4gICAgaWYgKHRoZW1hYmxlU3R5bGVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNsZWFyU3R5bGVzKENsZWFyU3R5bGVPcHRpb25zLm9ubHlUaGVtYWJsZSk7XG4gICAgICBhcHBseVRoZW1hYmxlU3R5bGVzKChbXSBhcyBUaGVtYWJsZUFycmF5KS5jb25jYXQuYXBwbHkoW10sIHRoZW1hYmxlU3R5bGVzKSk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogRmluZCB0aGVtZSB0b2tlbnMgYW5kIHJlcGxhY2VzIHRoZW0gd2l0aCBwcm92aWRlZCB0aGVtZSB2YWx1ZXMuXG4gKiBAcGFyYW0ge3N0cmluZ30gc3R5bGVzIFRva2VuaXplZCBzdHlsZXMgdG8gZml4LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGV0b2tlbml6ZShzdHlsZXM6IHN0cmluZyB8IHVuZGVmaW5lZCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmIChzdHlsZXMpIHtcbiAgICBzdHlsZXMgPSByZXNvbHZlVGhlbWFibGVBcnJheShzcGxpdFN0eWxlcyhzdHlsZXMpKS5zdHlsZVN0cmluZztcbiAgfVxuXG4gIHJldHVybiBzdHlsZXM7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgVGhlbWluZ0luc3RydWN0aW9uIG9iamVjdHMgaW4gYW4gYXJyYXkgYW5kIGpvaW5zIHRoZSByZXN1bHQgaW50byBhIHN0cmluZy5cbiAqIEBwYXJhbSB7VGhlbWFibGVBcnJheX0gc3BsaXRTdHlsZUFycmF5IFRoZW1hYmxlQXJyYXkgdG8gcmVzb2x2ZSBhbmQgam9pbi5cbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZVRoZW1hYmxlQXJyYXkoc3BsaXRTdHlsZUFycmF5OiBUaGVtYWJsZUFycmF5KTogSVRoZW1hYmxlQXJyYXlSZXNvbHZlUmVzdWx0IHtcbiAgY29uc3QgeyB0aGVtZSB9OiBJVGhlbWVTdGF0ZSA9IF90aGVtZVN0YXRlO1xuICBsZXQgdGhlbWFibGU6IGJvb2xlYW4gPSBmYWxzZTtcbiAgLy8gUmVzb2x2ZSB0aGUgYXJyYXkgb2YgdGhlbWluZyBpbnN0cnVjdGlvbnMgdG8gYW4gYXJyYXkgb2Ygc3RyaW5ncy5cbiAgLy8gVGhlbiBqb2luIHRoZSBhcnJheSB0byBwcm9kdWNlIHRoZSBmaW5hbCBDU1Mgc3RyaW5nLlxuICBjb25zdCByZXNvbHZlZEFycmF5OiAoc3RyaW5nIHwgdW5kZWZpbmVkKVtdID0gKHNwbGl0U3R5bGVBcnJheSB8fCBbXSkubWFwKFxuICAgIChjdXJyZW50VmFsdWU6IElUaGVtaW5nSW5zdHJ1Y3Rpb24pID0+IHtcbiAgICAgIGNvbnN0IHRoZW1lU2xvdDogc3RyaW5nIHwgdW5kZWZpbmVkID0gY3VycmVudFZhbHVlLnRoZW1lO1xuICAgICAgaWYgKHRoZW1lU2xvdCkge1xuICAgICAgICB0aGVtYWJsZSA9IHRydWU7XG4gICAgICAgIC8vIEEgdGhlbWluZyBhbm5vdGF0aW9uLiBSZXNvbHZlIGl0LlxuICAgICAgICBjb25zdCB0aGVtZWRWYWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkID0gdGhlbWUgPyB0aGVtZVt0aGVtZVNsb3RdIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBkZWZhdWx0VmFsdWU6IHN0cmluZyA9IGN1cnJlbnRWYWx1ZS5kZWZhdWx0VmFsdWUgfHwgJ2luaGVyaXQnO1xuXG4gICAgICAgIC8vIFdhcm4gdG8gY29uc29sZSBpZiB3ZSBoaXQgYW4gdW50aGVtZWQgdmFsdWUgZXZlbiB3aGVuIHRoZW1lcyBhcmUgcHJvdmlkZWQsIGJ1dCBvbmx5IGlmIFwiREVCVUdcIiBpcyB0cnVlLlxuICAgICAgICAvLyBBbGxvdyB0aGUgdGhlbWVkVmFsdWUgdG8gYmUgdW5kZWZpbmVkIHRvIGV4cGxpY2l0bHkgcmVxdWVzdCB0aGUgZGVmYXVsdCB2YWx1ZS5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHRoZW1lICYmXG4gICAgICAgICAgIXRoZW1lZFZhbHVlICYmXG4gICAgICAgICAgY29uc29sZSAmJlxuICAgICAgICAgICEodGhlbWVTbG90IGluIHRoZW1lKSAmJlxuICAgICAgICAgIHR5cGVvZiBERUJVRyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgICAgICBERUJVR1xuICAgICAgICApIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oYFRoZW1pbmcgdmFsdWUgbm90IHByb3ZpZGVkIGZvciBcIiR7dGhlbWVTbG90fVwiLiBGYWxsaW5nIGJhY2sgdG8gXCIke2RlZmF1bHRWYWx1ZX1cIi5gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGVtZWRWYWx1ZSB8fCBkZWZhdWx0VmFsdWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBBIG5vbi10aGVtYWJsZSBzdHJpbmcuIFByZXNlcnZlIGl0LlxuICAgICAgICByZXR1cm4gY3VycmVudFZhbHVlLnJhd1N0cmluZztcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcmV0dXJuIHtcbiAgICBzdHlsZVN0cmluZzogcmVzb2x2ZWRBcnJheS5qb2luKCcnKSxcbiAgICB0aGVtYWJsZTogdGhlbWFibGVcbiAgfTtcbn1cblxuLyoqXG4gKiBTcGxpdCB0b2tlbml6ZWQgQ1NTIGludG8gYW4gYXJyYXkgb2Ygc3RyaW5ncyBhbmQgdGhlbWUgc3BlY2lmaWNhdGlvbiBvYmplY3RzXG4gKiBAcGFyYW0ge3N0cmluZ30gc3R5bGVzIFRva2VuaXplZCBzdHlsZXMgdG8gc3BsaXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzcGxpdFN0eWxlcyhzdHlsZXM6IHN0cmluZyk6IFRoZW1hYmxlQXJyYXkge1xuICBjb25zdCByZXN1bHQ6IFRoZW1hYmxlQXJyYXkgPSBbXTtcbiAgaWYgKHN0eWxlcykge1xuICAgIGxldCBwb3M6IG51bWJlciA9IDA7IC8vIEN1cnJlbnQgcG9zaXRpb24gaW4gc3R5bGVzLlxuICAgIGxldCB0b2tlbk1hdGNoOiBSZWdFeHBFeGVjQXJyYXkgfCBudWxsO1xuICAgIHdoaWxlICgodG9rZW5NYXRjaCA9IF90aGVtZVRva2VuUmVnZXguZXhlYyhzdHlsZXMpKSkge1xuICAgICAgY29uc3QgbWF0Y2hJbmRleDogbnVtYmVyID0gdG9rZW5NYXRjaC5pbmRleDtcbiAgICAgIGlmIChtYXRjaEluZGV4ID4gcG9zKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICByYXdTdHJpbmc6IHN0eWxlcy5zdWJzdHJpbmcocG9zLCBtYXRjaEluZGV4KVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICB0aGVtZTogdG9rZW5NYXRjaFsxXSxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiB0b2tlbk1hdGNoWzJdIC8vIE1heSBiZSB1bmRlZmluZWRcbiAgICAgIH0pO1xuXG4gICAgICAvLyBpbmRleCBvZiB0aGUgZmlyc3QgY2hhcmFjdGVyIGFmdGVyIHRoZSBjdXJyZW50IG1hdGNoXG4gICAgICBwb3MgPSBfdGhlbWVUb2tlblJlZ2V4Lmxhc3RJbmRleDtcbiAgICB9XG5cbiAgICAvLyBQdXNoIHRoZSByZXN0IG9mIHRoZSBzdHJpbmcgYWZ0ZXIgdGhlIGxhc3QgbWF0Y2guXG4gICAgcmVzdWx0LnB1c2goe1xuICAgICAgcmF3U3RyaW5nOiBzdHlsZXMuc3Vic3RyaW5nKHBvcylcbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKlxuICogUmVnaXN0ZXJzIGEgc2V0IG9mIHN0eWxlIHRleHQuIElmIGl0IGlzIHJlZ2lzdGVyZWQgdG9vIGVhcmx5LCB3ZSB3aWxsIHJlZ2lzdGVyIGl0IHdoZW4gdGhlXG4gKiB3aW5kb3cubG9hZCBldmVudCBpcyBmaXJlZC5cbiAqIEBwYXJhbSB7VGhlbWFibGVBcnJheX0gc3R5bGVBcnJheSBBcnJheSBvZiBJVGhlbWluZ0luc3RydWN0aW9uIG9iamVjdHMgdG8gcmVnaXN0ZXIuXG4gKiBAcGFyYW0ge0lTdHlsZVJlY29yZH0gc3R5bGVSZWNvcmQgTWF5IHNwZWNpZnkgYSBzdHlsZSBFbGVtZW50IHRvIHVwZGF0ZS5cbiAqL1xuZnVuY3Rpb24gcmVnaXN0ZXJTdHlsZXMoc3R5bGVBcnJheTogVGhlbWFibGVBcnJheSk6IHZvaWQge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBoZWFkOiBIVE1MSGVhZEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnaGVhZCcpWzBdO1xuICBjb25zdCBzdHlsZUVsZW1lbnQ6IEhUTUxTdHlsZUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpO1xuICBjb25zdCB7IHN0eWxlU3RyaW5nLCB0aGVtYWJsZSB9ID0gcmVzb2x2ZVRoZW1hYmxlQXJyYXkoc3R5bGVBcnJheSk7XG5cbiAgc3R5bGVFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS1sb2FkLXRoZW1lZC1zdHlsZXMnLCAndHJ1ZScpO1xuICBpZiAoX3N0eWxlTm9uY2UpIHtcbiAgICBzdHlsZUVsZW1lbnQuc2V0QXR0cmlidXRlKCdub25jZScsIF9zdHlsZU5vbmNlKTtcbiAgfVxuICBzdHlsZUVsZW1lbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoc3R5bGVTdHJpbmcpKTtcbiAgX3RoZW1lU3RhdGUucGVyZi5jb3VudCsrO1xuICBoZWFkLmFwcGVuZENoaWxkKHN0eWxlRWxlbWVudCk7XG5cbiAgY29uc3QgZXY6IElDdXN0b21FdmVudDx7IG5ld1N0eWxlOiBIVE1MU3R5bGVFbGVtZW50IH0+ID0gZG9jdW1lbnQuY3JlYXRlRXZlbnQoJ0hUTUxFdmVudHMnKTtcbiAgZXYuaW5pdEV2ZW50KCdzdHlsZWluc2VydCcsIHRydWUgLyogYnViYmxlRXZlbnQgKi8sIGZhbHNlIC8qIGNhbmNlbGFibGUgKi8pO1xuICBldi5hcmdzID0ge1xuICAgIG5ld1N0eWxlOiBzdHlsZUVsZW1lbnRcbiAgfTtcbiAgZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChldik7XG5cbiAgY29uc3QgcmVjb3JkOiBJU3R5bGVSZWNvcmQgPSB7XG4gICAgc3R5bGVFbGVtZW50OiBzdHlsZUVsZW1lbnQsXG4gICAgdGhlbWFibGVTdHlsZTogc3R5bGVBcnJheVxuICB9O1xuXG4gIGlmICh0aGVtYWJsZSkge1xuICAgIF90aGVtZVN0YXRlLnJlZ2lzdGVyZWRUaGVtYWJsZVN0eWxlcy5wdXNoKHJlY29yZCk7XG4gIH0gZWxzZSB7XG4gICAgX3RoZW1lU3RhdGUucmVnaXN0ZXJlZFN0eWxlcy5wdXNoKHJlY29yZCk7XG4gIH1cbn1cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19