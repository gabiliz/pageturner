import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserRoleDetails.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import { userQueryService, userRoleQueryService } from "/src/modules/admin/users/services/index.ts";
import { ConfirmDeletion, DataTable, LoadingScreen, ResourceEditDrawer, ResourceCreateDrawer, PrimaryButton, FlexColumn } from "/src/shared/components/index.ts?t=1701096626433";
import { UserRoleDate, UserRoleEditForm } from "/src/modules/admin/users/components/index.ts?t=1701096626433";
import { RoleName } from "/src/modules/admin/roles/components/index.ts?t=1701096626433";
const UserRoleDetails = (props) => {
  _s();
  const {
    data: user
  } = props;
  const {
    isLoading,
    data
  } = userRoleQueryService.useFindAll(user.id ?? "");
  const {
    mutateAsync: deleteUser
  } = userRoleQueryService.useDelete(user.id ?? "");
  const [item, setItem] = useState();
  const [hideConfirmRemoval, {
    setTrue: closeConfirmRemoval,
    setFalse: openConfirmRemoval
  }] = useBoolean(true);
  const [isEditDrawerOpen, {
    setTrue: openEditDrawer,
    setFalse: closeEditDrawer
  }] = useBoolean(false);
  const [isAddDrawerOpen, {
    setTrue: openAddDrawer,
    setFalse: closeAddDrawer
  }] = useBoolean(false);
  const columns = useMemo(() => [{
    header: "Cargo",
    field: "cargoId",
    format: (item2) => {
      if (item2.cargoId) {
        return /* @__PURE__ */ jsxDEV(RoleName, { id: item2.cargoId }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
          lineNumber: 42,
          columnNumber: 16
        }, this);
      }
    }
  }, {
    header: "Início",
    field: "dataInicial",
    format: (item2) => {
      if (item2.id && user.id) {
        return /* @__PURE__ */ jsxDEV(UserRoleDate, { date: item2.dataInicial }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
          lineNumber: 50,
          columnNumber: 16
        }, this);
      }
    },
    sortable: true
  }, {
    header: "Fim",
    field: "dataFinal",
    format: (item2) => {
      if (item2.id && user.id) {
        return /* @__PURE__ */ jsxDEV(UserRoleDate, { date: item2.dataFinal }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
          lineNumber: 59,
          columnNumber: 16
        }, this);
      }
    },
    sortable: true
  }], [user]);
  const handleAddAction = useCallback(() => {
    setItem(item);
    openAddDrawer();
  }, []);
  const handleEditAction = useCallback((item2) => {
    setItem(item2);
    openEditDrawer();
  }, []);
  const handleRemoveAction = useCallback((item2) => {
    setItem(item2);
    openConfirmRemoval();
  }, []);
  const removeItem = useCallback(async () => {
    item && await deleteUser(item);
    userQueryService.invalidateQueries();
    closeConfirmRemoval();
  }, [item]);
  const menuOptions = useCallback((item2) => [{
    key: "edit",
    text: "Alterar",
    onClick: () => handleEditAction(item2)
  }, {
    key: "remove",
    text: "Excluir",
    onClick: () => handleRemoveAction(item2)
  }], []);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { gap: 12, children: [
    /* @__PURE__ */ jsxDEV(PrimaryButton, { onClick: handleAddAction, styles: {
      root: {
        width: "130px"
      }
    }, iconProps: {
      iconName: "Add",
      style: {
        fontSize: 14
      }
    }, text: "Adicionar" }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
      lineNumber: 101,
      columnNumber: 20
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { items: data ?? [], hasControlsColumn: true, columns, menuOptions, hasSelection: false }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
        lineNumber: 102,
        columnNumber: 11
      }, this),
      user.id && /* @__PURE__ */ jsxDEV(ResourceCreateDrawer, { title: "Adicionar novo cargo", isOpen: isAddDrawerOpen, editForm: UserRoleEditForm, onDismiss: closeAddDrawer, service: userRoleQueryService, serviceParams: [user.id], onAfterSave: () => userQueryService.invalidateQueries() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
        lineNumber: 103,
        columnNumber: 23
      }, this),
      item?.id && user.id && /* @__PURE__ */ jsxDEV(ResourceEditDrawer, { title: "Alterar cargo", isOpen: isEditDrawerOpen, onDismiss: closeEditDrawer, service: userRoleQueryService, id: item.id, serviceParams: [user.id], editForm: UserRoleEditForm, onAfterSave: () => userQueryService.invalidateQueries() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
        lineNumber: 104,
        columnNumber: 35
      }, this),
      /* @__PURE__ */ jsxDEV(ConfirmDeletion, { hidden: hideConfirmRemoval, onDismiss: closeConfirmRemoval, onConfirm: removeItem, deleteTitle: "Excluir cargo", deleteSubtitle: "Você tem certeza que deseja excluir o cargo desse usuário?" }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
        lineNumber: 105,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
      lineNumber: 101,
      columnNumber: 40
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx",
    lineNumber: 90,
    columnNumber: 10
  }, this);
};
_s(UserRoleDetails, "KeXczZG0ojnOybUxpf1XnvU1fnw=", false, function() {
  return [userRoleQueryService.useFindAll, userRoleQueryService.useDelete, useBoolean, useBoolean, useBoolean];
});
_c = UserRoleDetails;
export default UserRoleDetails;
var _c;
$RefreshReg$(_c, "UserRoleDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserRoleDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENpQixTQXNFUCxVQXRFTzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDakIsU0FBYUEsYUFBYUMsVUFBVUMsZUFBZTtBQUVuRCxTQUFTQyxrQkFBa0I7QUFHM0IsU0FBU0Msa0JBQWtCQyw0QkFBNEI7QUFDdkQsU0FDRUMsaUJBQ0FDLFdBRUFDLGVBQ0FDLG9CQUNBQyxzQkFDQUMsZUFDQUMsa0JBQ0s7QUFFUCxTQUFTQyxjQUFjQyx3QkFBd0I7QUFDL0MsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGtCQUErQ0MsV0FBVTtBQUFBQyxLQUFBO0FBQzdELFFBQU07QUFBQSxJQUFFQyxNQUFNQztBQUFBQSxFQUFLLElBQUlIO0FBQ3ZCLFFBQU07QUFBQSxJQUFFSTtBQUFBQSxJQUFXRjtBQUFBQSxFQUFLLElBQUlkLHFCQUFxQmlCLFdBQVdGLEtBQUtHLE1BQU0sRUFBRTtBQUN6RSxRQUFNO0FBQUEsSUFBRUMsYUFBYUM7QUFBQUEsRUFBVyxJQUFJcEIscUJBQXFCcUIsVUFBVU4sS0FBS0csTUFBTSxFQUFFO0FBQ2hGLFFBQU0sQ0FBQ0ksTUFBTUMsT0FBTyxJQUFJM0IsU0FBbUI7QUFDM0MsUUFBTSxDQUNKNEIsb0JBQ0E7QUFBQSxJQUFFQyxTQUFTQztBQUFBQSxJQUFxQkMsVUFBVUM7QUFBQUEsRUFBbUIsQ0FBQyxJQUM1RDlCLFdBQVcsSUFBSTtBQUNuQixRQUFNLENBQ0orQixrQkFDQTtBQUFBLElBQUVKLFNBQVNLO0FBQUFBLElBQWdCSCxVQUFVSTtBQUFBQSxFQUFnQixDQUFDLElBQ3BEakMsV0FBVyxLQUFLO0FBQ3BCLFFBQU0sQ0FDSmtDLGlCQUNBO0FBQUEsSUFBRVAsU0FBU1E7QUFBQUEsSUFBZU4sVUFBVU87QUFBQUEsRUFBZSxDQUFDLElBQ2xEcEMsV0FBVyxLQUFLO0FBRXBCLFFBQU1xQyxVQUF1Q3RDLFFBQVEsTUFBTSxDQUN6RDtBQUFBLElBQ0V1QyxRQUFRO0FBQUEsSUFDUkMsT0FBTztBQUFBLElBQ1BDLFFBQVNoQixXQUFTO0FBQ2hCLFVBQUlBLE1BQUtpQixTQUFTO0FBQ2hCLGVBQU8sdUJBQUMsWUFBUyxJQUFJakIsTUFBS2lCLFdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxNQUNwQztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0E7QUFBQSxJQUNFSCxRQUFRO0FBQUEsSUFDUkMsT0FBTztBQUFBLElBQ1BDLFFBQVNoQixXQUFTO0FBQ2hCLFVBQUlBLE1BQUtKLE1BQU1ILEtBQUtHLElBQUk7QUFDdEIsZUFBTyx1QkFBQyxnQkFBYSxNQUFNSSxNQUFLa0IsZUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUFBLElBQ0FDLFVBQVU7QUFBQSxFQUNaLEdBQ0E7QUFBQSxJQUNFTCxRQUFRO0FBQUEsSUFDUkMsT0FBTztBQUFBLElBQ1BDLFFBQVFBLENBQUNoQixVQUFtQjtBQUMxQixVQUFJQSxNQUFLSixNQUFNSCxLQUFLRyxJQUFJO0FBQ3RCLGVBQU8sdUJBQUMsZ0JBQWEsTUFBTUksTUFBS29CLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxJQUNBRCxVQUFVO0FBQUEsRUFDWixDQUFDLEdBQ0EsQ0FBQzFCLElBQUksQ0FBQztBQUVULFFBQU00QixrQkFBa0JoRCxZQUFZLE1BQU07QUFDeEM0QixZQUFRRCxJQUFJO0FBQ1pXLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxFQUFFO0FBRUwsUUFBTVcsbUJBQW1CakQsWUFBWSxDQUFDMkIsVUFBbUI7QUFDdkRDLFlBQVFELEtBQUk7QUFDWlEsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNZSxxQkFBcUJsRCxZQUFZLENBQUMyQixVQUFtQjtBQUN6REMsWUFBUUQsS0FBSTtBQUNaTSx1QkFBbUI7QUFBQSxFQUNyQixHQUFHLEVBQUU7QUFFTCxRQUFNa0IsYUFBYW5ELFlBQVksWUFBWTtBQUN6QzJCLFlBQVMsTUFBTUYsV0FBV0UsSUFBSTtBQUM5QnZCLHFCQUFpQmdELGtCQUFrQjtBQUNuQ3JCLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ0osSUFBSSxDQUFDO0FBRVQsUUFBTTBCLGNBQWNyRCxZQUFZLENBQUMyQixVQUEwQyxDQUN6RTtBQUFBLElBQ0UyQixLQUFLO0FBQUEsSUFDTEMsTUFBTTtBQUFBLElBQ05DLFNBQVNBLE1BQU1QLGlCQUFpQnRCLEtBQUk7QUFBQSxFQUN0QyxHQUNBO0FBQUEsSUFDRTJCLEtBQUs7QUFBQSxJQUNMQyxNQUFNO0FBQUEsSUFDTkMsU0FBU0EsTUFBTU4sbUJBQW1CdkIsS0FBSTtBQUFBLEVBQ3hDLENBQUMsR0FDQSxFQUFFO0FBRUwsU0FDRSx1QkFBQyxjQUFXLEtBQU0sSUFDaEI7QUFBQSwyQkFBQyxpQkFDQyxTQUFTcUIsaUJBQ1QsUUFBUTtBQUFBLE1BQUVTLE1BQU07QUFBQSxRQUFFQyxPQUFPO0FBQUEsTUFBUTtBQUFBLElBQUUsR0FDbkMsV0FBVztBQUFBLE1BQUVDLFVBQVU7QUFBQSxNQUFPQyxPQUFPO0FBQUEsUUFBRUMsVUFBVTtBQUFBLE1BQUc7QUFBQSxJQUFFLEdBQ3RELE1BQUssZUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSWtCO0FBQUEsSUFFakJ4QyxZQUNHLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxJQUNkLG1DQUNBO0FBQUEsNkJBQUMsYUFDQyxPQUFPRixRQUFRLElBQ2YsbUJBQWlCLE1BQ2pCLFNBQ0EsYUFDQSxjQUFjLFNBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLc0I7QUFBQSxNQUVyQkMsS0FBS0csTUFDRix1QkFBQyx3QkFDQyxPQUFNLHdCQUNOLFFBQVFjLGlCQUNSLFVBQVV2QixrQkFDVixXQUFXeUIsZ0JBQ1gsU0FBU2xDLHNCQUNULGVBQWUsQ0FBQ2UsS0FBS0csRUFBRSxHQUN2QixhQUFhLE1BQU1uQixpQkFBaUJnRCxrQkFBa0IsS0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU8wRDtBQUFBLE1BRzdEekIsTUFBTUosTUFBTUgsS0FBS0csTUFDZCx1QkFBQyxzQkFDQyxPQUFNLGlCQUNOLFFBQVFXLGtCQUNSLFdBQVdFLGlCQUNYLFNBQVMvQixzQkFDVCxJQUFJc0IsS0FBS0osSUFDVCxlQUFlLENBQUNILEtBQUtHLEVBQUUsR0FDdkIsVUFBVVQsa0JBQ1YsYUFBYSxNQUFNVixpQkFBaUJnRCxrQkFBa0IsS0FSeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVEwRDtBQUFBLE1BRzlELHVCQUFDLG1CQUNDLFFBQVF2QixvQkFDUixXQUFXRSxxQkFDWCxXQUFXb0IsWUFDWCxhQUFZLGlCQUNaLGdCQUFlLGdFQUxqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzZFO0FBQUEsU0FwQzdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0Y7QUFBQSxPQS9DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaURBO0FBRUo7QUFBQ2pDLEdBeElLRixpQkFBMkM7QUFBQSxVQUVuQlgscUJBQXFCaUIsWUFDYmpCLHFCQUFxQnFCLFdBS3JEdkIsWUFJQUEsWUFJQUEsVUFBVTtBQUFBO0FBQUEyRCxLQWhCVjlDO0FBMElOLGVBQWVBO0FBQWUsSUFBQThDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZUJvb2xlYW4iLCJ1c2VyUXVlcnlTZXJ2aWNlIiwidXNlclJvbGVRdWVyeVNlcnZpY2UiLCJDb25maXJtRGVsZXRpb24iLCJEYXRhVGFibGUiLCJMb2FkaW5nU2NyZWVuIiwiUmVzb3VyY2VFZGl0RHJhd2VyIiwiUmVzb3VyY2VDcmVhdGVEcmF3ZXIiLCJQcmltYXJ5QnV0dG9uIiwiRmxleENvbHVtbiIsIlVzZXJSb2xlRGF0ZSIsIlVzZXJSb2xlRWRpdEZvcm0iLCJSb2xlTmFtZSIsIlVzZXJSb2xlRGV0YWlscyIsInByb3BzIiwiX3MiLCJkYXRhIiwidXNlciIsImlzTG9hZGluZyIsInVzZUZpbmRBbGwiLCJpZCIsIm11dGF0ZUFzeW5jIiwiZGVsZXRlVXNlciIsInVzZURlbGV0ZSIsIml0ZW0iLCJzZXRJdGVtIiwiaGlkZUNvbmZpcm1SZW1vdmFsIiwic2V0VHJ1ZSIsImNsb3NlQ29uZmlybVJlbW92YWwiLCJzZXRGYWxzZSIsIm9wZW5Db25maXJtUmVtb3ZhbCIsImlzRWRpdERyYXdlck9wZW4iLCJvcGVuRWRpdERyYXdlciIsImNsb3NlRWRpdERyYXdlciIsImlzQWRkRHJhd2VyT3BlbiIsIm9wZW5BZGREcmF3ZXIiLCJjbG9zZUFkZERyYXdlciIsImNvbHVtbnMiLCJoZWFkZXIiLCJmaWVsZCIsImZvcm1hdCIsImNhcmdvSWQiLCJkYXRhSW5pY2lhbCIsInNvcnRhYmxlIiwiZGF0YUZpbmFsIiwiaGFuZGxlQWRkQWN0aW9uIiwiaGFuZGxlRWRpdEFjdGlvbiIsImhhbmRsZVJlbW92ZUFjdGlvbiIsInJlbW92ZUl0ZW0iLCJpbnZhbGlkYXRlUXVlcmllcyIsIm1lbnVPcHRpb25zIiwia2V5IiwidGV4dCIsIm9uQ2xpY2siLCJyb290Iiwid2lkdGgiLCJpY29uTmFtZSIsInN0eWxlIiwiZm9udFNpemUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJSb2xlRGV0YWlscy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL3VzZXJzL2NvbXBvbmVudHMvVXNlclJvbGVEZXRhaWxzLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSUNvbnRleHR1YWxNZW51SXRlbSB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcclxuaW1wb3J0IFVzZXIgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXInXHJcbmltcG9ydCB7IERldGFpbHNWaWV3UHJvcHMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvdHlwZXMvRGV0YWlsc1ZpZXcnXHJcbmltcG9ydCB7IHVzZXJRdWVyeVNlcnZpY2UsIHVzZXJSb2xlUXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXHJcbmltcG9ydCB7XHJcbiAgQ29uZmlybURlbGV0aW9uLFxyXG4gIERhdGFUYWJsZSxcclxuICBEYXRhVGFibGVDb2x1bW4sXHJcbiAgTG9hZGluZ1NjcmVlbixcclxuICBSZXNvdXJjZUVkaXREcmF3ZXIsXHJcbiAgUmVzb3VyY2VDcmVhdGVEcmF3ZXIsXHJcbiAgUHJpbWFyeUJ1dHRvbixcclxuICBGbGV4Q29sdW1uLFxyXG59IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgVXNlclJvbGUgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL1VzZXJSb2xlJ1xyXG5pbXBvcnQgeyBVc2VyUm9sZURhdGUsIFVzZXJSb2xlRWRpdEZvcm0gfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyBSb2xlTmFtZSB9IGZyb20gJy4uLy4uL3JvbGVzL2NvbXBvbmVudHMnXHJcblxyXG5jb25zdCBVc2VyUm9sZURldGFpbHM6IEZDPERldGFpbHNWaWV3UHJvcHM8VXNlcj4+ID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgeyBkYXRhOiB1c2VyIH0gPSBwcm9wc1xyXG4gIGNvbnN0IHsgaXNMb2FkaW5nLCBkYXRhIH0gPSB1c2VyUm9sZVF1ZXJ5U2VydmljZS51c2VGaW5kQWxsKHVzZXIuaWQgPz8gJycpXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogZGVsZXRlVXNlciB9ID0gdXNlclJvbGVRdWVyeVNlcnZpY2UudXNlRGVsZXRlKHVzZXIuaWQgPz8gJycpXHJcbiAgY29uc3QgW2l0ZW0sIHNldEl0ZW1dID0gdXNlU3RhdGU8VXNlclJvbGU+KClcclxuICBjb25zdCBbXHJcbiAgICBoaWRlQ29uZmlybVJlbW92YWwsXHJcbiAgICB7IHNldFRydWU6IGNsb3NlQ29uZmlybVJlbW92YWwsIHNldEZhbHNlOiBvcGVuQ29uZmlybVJlbW92YWwgfSxcclxuICBdID0gdXNlQm9vbGVhbih0cnVlKVxyXG4gIGNvbnN0IFtcclxuICAgIGlzRWRpdERyYXdlck9wZW4sXHJcbiAgICB7IHNldFRydWU6IG9wZW5FZGl0RHJhd2VyLCBzZXRGYWxzZTogY2xvc2VFZGl0RHJhd2VyIH0sXHJcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXHJcbiAgY29uc3QgW1xyXG4gICAgaXNBZGREcmF3ZXJPcGVuLFxyXG4gICAgeyBzZXRUcnVlOiBvcGVuQWRkRHJhd2VyLCBzZXRGYWxzZTogY2xvc2VBZGREcmF3ZXIgfSxcclxuICBdID0gdXNlQm9vbGVhbihmYWxzZSlcclxuXHJcbiAgY29uc3QgY29sdW1uczogRGF0YVRhYmxlQ29sdW1uPFVzZXJSb2xlPltdID0gdXNlTWVtbygoKSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIGhlYWRlcjogJ0NhcmdvJyxcclxuICAgICAgZmllbGQ6ICdjYXJnb0lkJyxcclxuICAgICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLmNhcmdvSWQpIHtcclxuICAgICAgICAgIHJldHVybiA8Um9sZU5hbWUgaWQ9e2l0ZW0uY2FyZ29JZH0vPlxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGhlYWRlcjogJ0luw61jaW8nLFxyXG4gICAgICBmaWVsZDogJ2RhdGFJbmljaWFsJyxcclxuICAgICAgZm9ybWF0OiAoaXRlbSkgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLmlkICYmIHVzZXIuaWQpIHtcclxuICAgICAgICAgIHJldHVybiA8VXNlclJvbGVEYXRlIGRhdGU9e2l0ZW0uZGF0YUluaWNpYWx9Lz5cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHNvcnRhYmxlOiB0cnVlLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaGVhZGVyOiAnRmltJyxcclxuICAgICAgZmllbGQ6ICdkYXRhRmluYWwnLFxyXG4gICAgICBmb3JtYXQ6IChpdGVtOiBVc2VyUm9sZSkgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLmlkICYmIHVzZXIuaWQpIHtcclxuICAgICAgICAgIHJldHVybiA8VXNlclJvbGVEYXRlIGRhdGU9e2l0ZW0uZGF0YUZpbmFsfS8+XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBzb3J0YWJsZTogdHJ1ZSxcclxuICAgIH0sXHJcbiAgXSwgW3VzZXJdKVxyXG5cclxuICBjb25zdCBoYW5kbGVBZGRBY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzZXRJdGVtKGl0ZW0pXHJcbiAgICBvcGVuQWRkRHJhd2VyKClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdEFjdGlvbiA9IHVzZUNhbGxiYWNrKChpdGVtOiBVc2VyUm9sZSkgPT4ge1xyXG4gICAgc2V0SXRlbShpdGVtKVxyXG4gICAgb3BlbkVkaXREcmF3ZXIoKVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVBY3Rpb24gPSB1c2VDYWxsYmFjaygoaXRlbTogVXNlclJvbGUpID0+IHtcclxuICAgIHNldEl0ZW0oaXRlbSlcclxuICAgIG9wZW5Db25maXJtUmVtb3ZhbCgpXHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IHJlbW92ZUl0ZW0gPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBpdGVtICYmIChhd2FpdCBkZWxldGVVc2VyKGl0ZW0pKVxyXG4gICAgdXNlclF1ZXJ5U2VydmljZS5pbnZhbGlkYXRlUXVlcmllcygpXHJcbiAgICBjbG9zZUNvbmZpcm1SZW1vdmFsKClcclxuICB9LCBbaXRlbV0pXHJcblxyXG4gIGNvbnN0IG1lbnVPcHRpb25zID0gdXNlQ2FsbGJhY2soKGl0ZW06IFVzZXJSb2xlKTogSUNvbnRleHR1YWxNZW51SXRlbVtdID0+IFtcclxuICAgIHtcclxuICAgICAga2V5OiAnZWRpdCcsXHJcbiAgICAgIHRleHQ6ICdBbHRlcmFyJyxcclxuICAgICAgb25DbGljazogKCkgPT4gaGFuZGxlRWRpdEFjdGlvbihpdGVtKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogJ3JlbW92ZScsXHJcbiAgICAgIHRleHQ6ICdFeGNsdWlyJyxcclxuICAgICAgb25DbGljazogKCkgPT4gaGFuZGxlUmVtb3ZlQWN0aW9uKGl0ZW0pLFxyXG4gICAgfSxcclxuICBdLCBbXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxGbGV4Q29sdW1uIGdhcD17IDEyIH0+XHJcbiAgICAgIDxQcmltYXJ5QnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17aGFuZGxlQWRkQWN0aW9ufVxyXG4gICAgICAgIHN0eWxlcz17eyByb290OiB7IHdpZHRoOiAnMTMwcHgnIH0gfX1cclxuICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdBZGQnLCBzdHlsZTogeyBmb250U2l6ZTogMTQgfSB9fVxyXG4gICAgICAgIHRleHQ9XCJBZGljaW9uYXJcIlxyXG4gICAgICAvPlxyXG4gICAgICB7aXNMb2FkaW5nXHJcbiAgICAgICAgPyA8TG9hZGluZ1NjcmVlbiAvPlxyXG4gICAgICAgIDogPD5cclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgaXRlbXM9e2RhdGEgPz8gW119XHJcbiAgICAgICAgICAgIGhhc0NvbnRyb2xzQ29sdW1uXHJcbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIG1lbnVPcHRpb25zPXttZW51T3B0aW9uc31cclxuICAgICAgICAgICAgaGFzU2VsZWN0aW9uPXtmYWxzZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7dXNlci5pZCAmJlxyXG4gICAgICAgICAgICAgIDxSZXNvdXJjZUNyZWF0ZURyYXdlclxyXG4gICAgICAgICAgICAgICAgdGl0bGU9J0FkaWNpb25hciBub3ZvIGNhcmdvJ1xyXG4gICAgICAgICAgICAgICAgaXNPcGVuPXtpc0FkZERyYXdlck9wZW59XHJcbiAgICAgICAgICAgICAgICBlZGl0Rm9ybT17VXNlclJvbGVFZGl0Rm9ybX1cclxuICAgICAgICAgICAgICAgIG9uRGlzbWlzcz17Y2xvc2VBZGREcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgICBzZXJ2aWNlPXt1c2VyUm9sZVF1ZXJ5U2VydmljZX1cclxuICAgICAgICAgICAgICAgIHNlcnZpY2VQYXJhbXM9e1t1c2VyLmlkXX1cclxuICAgICAgICAgICAgICAgIG9uQWZ0ZXJTYXZlPXsoKSA9PiB1c2VyUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKCl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHtpdGVtPy5pZCAmJiB1c2VyLmlkICYmXHJcbiAgICAgICAgICAgICAgPFJlc291cmNlRWRpdERyYXdlclxyXG4gICAgICAgICAgICAgICAgdGl0bGU9J0FsdGVyYXIgY2FyZ28nXHJcbiAgICAgICAgICAgICAgICBpc09wZW49e2lzRWRpdERyYXdlck9wZW59XHJcbiAgICAgICAgICAgICAgICBvbkRpc21pc3M9e2Nsb3NlRWRpdERyYXdlcn1cclxuICAgICAgICAgICAgICAgIHNlcnZpY2U9e3VzZXJSb2xlUXVlcnlTZXJ2aWNlfVxyXG4gICAgICAgICAgICAgICAgaWQ9e2l0ZW0uaWR9XHJcbiAgICAgICAgICAgICAgICBzZXJ2aWNlUGFyYW1zPXtbdXNlci5pZF19XHJcbiAgICAgICAgICAgICAgICBlZGl0Rm9ybT17VXNlclJvbGVFZGl0Rm9ybX1cclxuICAgICAgICAgICAgICAgIG9uQWZ0ZXJTYXZlPXsoKSA9PiB1c2VyUXVlcnlTZXJ2aWNlLmludmFsaWRhdGVRdWVyaWVzKCl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDxDb25maXJtRGVsZXRpb25cclxuICAgICAgICAgICAgaGlkZGVuPXtoaWRlQ29uZmlybVJlbW92YWx9XHJcbiAgICAgICAgICAgIG9uRGlzbWlzcz17Y2xvc2VDb25maXJtUmVtb3ZhbH1cclxuICAgICAgICAgICAgb25Db25maXJtPXtyZW1vdmVJdGVtfVxyXG4gICAgICAgICAgICBkZWxldGVUaXRsZT1cIkV4Y2x1aXIgY2FyZ29cIlxyXG4gICAgICAgICAgICBkZWxldGVTdWJ0aXRsZT1cIlZvY8OqIHRlbSBjZXJ0ZXphIHF1ZSBkZXNlamEgZXhjbHVpciBvIGNhcmdvIGRlc3NlIHVzdcOhcmlvP1wiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICB9XHJcbiAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyUm9sZURldGFpbHNcclxuIl19