import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditChangeSituation.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { DirectionalHint, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { useBoolean } from "/node_modules/.vite/deps/@fluentui_react-hooks.js?v=9f90a7ff";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useContext = __vite__cjsImport5_react["useContext"]; const useEffect = __vite__cjsImport5_react["useEffect"];
import { AuditChangeSituationModal, AuditsSituation } from "/src/modules/audit/audits/components/index.ts?t=1701096626433";
import { FlexRow, IconButton, Spinner, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { LoadingDataContext } from "/src/shared/context/LoadingDataContext.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { useFormData, useTheme } from "/src/shared/hooks/index.ts";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { SpinnerSizeEnum } from "/src/shared/enums/SpinnerSizeEnum.ts";
const COMPONENT_MAX_HEIGHT = 25;
const AuditChangeSituation = ({
  auditId
}) => {
  _s();
  const {
    spacing,
    colors
  } = useTheme();
  const {
    button
  } = useIconButtonStyles();
  const {
    data,
    isLoading,
    isFetching
  } = auditQueryService.useFindOne(auditId);
  const {
    mutateAsync: save,
    isLoading: isSaving
  } = auditQueryService.useUpdate();
  const {
    setIsLoading: setGlobalLoading,
    isLoading: globalLoading
  } = useContext(LoadingDataContext);
  const [isModalOpen, {
    setTrue: openModal,
    setFalse: closeModal
  }] = useBoolean(false);
  const {
    formData: localFormData,
    setFormData: setLocalFormData,
    onTextChange
  } = useFormData({
    ...data,
    justificativa: ""
  });
  const resetFormData = useCallback((data2) => {
    setLocalFormData({
      ...data2,
      justificativa: ""
    });
  }, [data]);
  const handleChangeSituation = useCallback((_ev, option) => {
    if (option) {
      setLocalFormData((prev) => ({
        ...prev,
        situacao: parseInt(option.key)
      }));
    }
  }, []);
  const onClose = useCallback(() => {
    if (data) {
      resetFormData(data);
    }
    closeModal();
  }, [data]);
  const saveChanges = useCallback(async (data2) => {
    if (data2) {
      setLocalFormData({
        ...data2
      });
      await save(data2);
    } else if (localFormData) {
      await save({
        ...localFormData
      });
    }
  }, [localFormData]);
  useEffect(() => {
    if (data) {
      resetFormData(data);
    }
  }, [data]);
  useEffect(() => {
    setGlobalLoading(isLoading || isSaving || isFetching);
  }, [isLoading, isSaving, isFetching]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    data && /* @__PURE__ */ jsxDEV(FlexRow, { gap: spacing.sm, children: [
      data.situacao !== void 0 && !globalLoading && /* @__PURE__ */ jsxDEV(AuditsSituation, { situation: data?.situacao, marginLeft: spacing.lg }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
        lineNumber: 96,
        columnNumber: 59
      }, this),
      data.situacao !== void 0 && !globalLoading && /* @__PURE__ */ jsxDEV(TooltipHost, { content: data?.situacao === AuditSituationEnum.Recorrente ? "Auditoria recorrente" : "Alterar situação", directionalHint: DirectionalHint.rightCenter, children: /* @__PURE__ */ jsxDEV(IconButton, { className: button, iconProps: {
        iconName: "Switch"
      }, disabled: data.situacao === AuditSituationEnum.Cancelado, styles: {
        icon: {
          color: colors.blue[500]
        },
        root: {
          maxHeight: COMPONENT_MAX_HEIGHT
        }
      }, onClick: openModal }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
        lineNumber: 98,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
        lineNumber: 97,
        columnNumber: 59
      }, this),
      isModalOpen && /* @__PURE__ */ jsxDEV(AuditChangeSituationModal, { formData: localFormData, isOpen: isModalOpen, onDismiss: onClose, onChangeSituation: handleChangeSituation, onTextChange: onTextChange("justificativaSituacao"), saveChanges, isLoading: globalLoading }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
        lineNumber: 109,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
      lineNumber: 95,
      columnNumber: 16
    }, this),
    globalLoading && /* @__PURE__ */ jsxDEV(Spinner, { size: SpinnerSizeEnum.medium }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
      lineNumber: 111,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx",
    lineNumber: 94,
    columnNumber: 10
  }, this);
};
_s(AuditChangeSituation, "Qn6429Vfx7sBasWnntw4tPApp40=", false, function() {
  return [useTheme, useIconButtonStyles, auditQueryService.useFindOne, auditQueryService.useUpdate, useBoolean, useFormData];
});
_c = AuditChangeSituation;
const useIconButtonStyles = () => {
  _s2();
  const {
    colors
  } = useTheme();
  return mergeStyleSets({
    button: {
      ":hover": {
        backgroundColor: colors.gray[200]
      },
      ":active": {
        backgroundColor: colors.gray[300]
      }
    }
  });
};
_s2(useIconButtonStyles, "/Q6cdUHzgkoetCTF1QsQ9YmUzs0=", false, function() {
  return [useTheme];
});
export default AuditChangeSituation;
var _c;
$RefreshReg$(_c, "AuditChangeSituation");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0ZJLG1CQUlzRCxjQUp0RDs7Ozs7Ozs7Ozs7Ozs7OztBQWhGSixTQUFTQSxpQkFBcUNDLHNCQUFzQjtBQUNwRSxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBd0JDLGFBQWFDLFlBQVlDLGlCQUFpQjtBQUNsRSxTQUFTQywyQkFBMkJDLHVCQUF1QjtBQUUzRCxTQUFTQyxTQUFTQyxZQUFZQyxTQUFTQyxtQkFBbUI7QUFDMUQsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHVCQUF1QjtBQU1oQyxNQUFNQyx1QkFBdUI7QUFFN0IsTUFBTUMsdUJBQXNEQSxDQUFDO0FBQUEsRUFBRUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDM0UsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVNDO0FBQUFBLEVBQU8sSUFBSVIsU0FBUztBQUNyQyxRQUFNO0FBQUEsSUFBRVM7QUFBQUEsRUFBTyxJQUFJQyxvQkFBb0I7QUFDdkMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQU1DO0FBQUFBLElBQVdDO0FBQUFBLEVBQVcsSUFBSVosa0JBQWtCYSxXQUFXVCxPQUFpQjtBQUN0RixRQUFNO0FBQUEsSUFBRVUsYUFBYUM7QUFBQUEsSUFBTUosV0FBV0s7QUFBQUEsRUFBUyxJQUFJaEIsa0JBQWtCaUIsVUFBVTtBQUMvRSxRQUFNO0FBQUEsSUFBRUMsY0FBY0M7QUFBQUEsSUFBa0JSLFdBQVdTO0FBQUFBLEVBQWMsSUFBSWhDLFdBQVdRLGtCQUFrQjtBQUNsRyxRQUFNLENBQ0p5QixhQUNBO0FBQUEsSUFDRUMsU0FBU0M7QUFBQUEsSUFDVEMsVUFBVUM7QUFBQUEsRUFDWixDQUFDLElBQ0N2QyxXQUFXLEtBQUs7QUFDcEIsUUFBTTtBQUFBLElBQ0p3QyxVQUFVQztBQUFBQSxJQUNWQyxhQUFhQztBQUFBQSxJQUNiQztBQUFBQSxFQUNGLElBQUloQyxZQUFtQjtBQUFBLElBQUUsR0FBR1k7QUFBQUEsSUFBTXFCLGVBQWU7QUFBQSxFQUFHLENBQVU7QUFFOUQsUUFBTUMsZ0JBQWdCN0MsWUFBWSxDQUFDdUIsVUFBZ0I7QUFDakRtQixxQkFBaUI7QUFBQSxNQUFFLEdBQUduQjtBQUFBQSxNQUFNcUIsZUFBZTtBQUFBLElBQUcsQ0FBQztBQUFBLEVBQ2pELEdBQUcsQ0FBQ3JCLElBQUksQ0FBQztBQUVULFFBQU11Qix3QkFBd0I5QyxZQUM1QixDQUFDK0MsS0FBaURDLFdBQWdDO0FBQ2hGLFFBQUlBLFFBQVE7QUFDVk4sdUJBQWlCTyxXQUNmO0FBQUEsUUFDRSxHQUFHQTtBQUFBQSxRQUNIQyxVQUFVQyxTQUFTSCxPQUFPSSxHQUFHO0FBQUEsTUFDL0IsRUFDRDtBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVQLFFBQU1DLFVBQVVyRCxZQUFZLE1BQU07QUFDaEMsUUFBSXVCLE1BQU07QUFDUnNCLG9CQUFjdEIsSUFBSTtBQUFBLElBQ3BCO0FBQ0FlLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ2YsSUFBSSxDQUFDO0FBRVQsUUFBTStCLGNBQWN0RCxZQUFZLE9BQU91QixVQUFpQjtBQUN0RCxRQUFJQSxPQUFNO0FBQ1JtQix1QkFBaUI7QUFBQSxRQUFFLEdBQUduQjtBQUFBQSxNQUFLLENBQUM7QUFDNUIsWUFBTUssS0FBS0wsS0FBSTtBQUFBLElBQ2pCLFdBQVdpQixlQUFlO0FBQ3hCLFlBQU1aLEtBQUs7QUFBQSxRQUFFLEdBQUdZO0FBQUFBLE1BQWMsQ0FBQztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUNBLGFBQWEsQ0FBQztBQUVsQnRDLFlBQVUsTUFBTTtBQUNkLFFBQUlxQixNQUFNO0FBQ1JzQixvQkFBY3RCLElBQUk7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxJQUFJLENBQUM7QUFFVHJCLFlBQVUsTUFBTTtBQUNkOEIscUJBQWlCUixhQUFhSyxZQUFZSixVQUFVO0FBQUEsRUFDdEQsR0FBRyxDQUFDRCxXQUFXSyxVQUFVSixVQUFVLENBQUM7QUFFcEMsU0FDRSxtQ0FDR0Y7QUFBQUEsWUFBUSx1QkFBQyxXQUNSLEtBQUtKLFFBQVFvQyxJQUVaaEM7QUFBQUEsV0FBSzJCLGFBQWFNLFVBQWEsQ0FBQ3ZCLGlCQUFpQix1QkFBQyxtQkFDakQsV0FBV1YsTUFBTTJCLFVBQ2pCLFlBQVkvQixRQUFRc0MsTUFGNEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUV6QjtBQUFBLE1BRXhCbEMsS0FBSzJCLGFBQWFNLFVBQWEsQ0FBQ3ZCLGlCQUFpQix1QkFBQyxlQUNqRCxTQUNFVixNQUFNMkIsYUFBYXhDLG1CQUFtQmdELGFBQ2xDLHlCQUNBLG9CQUVOLGlCQUFpQjdELGdCQUFnQjhELGFBRWpDLGlDQUFDLGNBQ0MsV0FBV3RDLFFBQ1gsV0FBVztBQUFBLFFBQUV1QyxVQUFVO0FBQUEsTUFBUyxHQUNoQyxVQUFVckMsS0FBSzJCLGFBQWF4QyxtQkFBbUJtRCxXQUMvQyxRQUFRO0FBQUEsUUFDTkMsTUFBTTtBQUFBLFVBQUVDLE9BQU8zQyxPQUFPNEMsS0FBSyxHQUFHO0FBQUEsUUFBRTtBQUFBLFFBQ2hDQyxNQUFNO0FBQUEsVUFDSkMsV0FBV25EO0FBQUFBLFFBQ2I7QUFBQSxNQUNGLEdBQ0EsU0FBU3FCLGFBVlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVxQixLQWxCMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CbEQ7QUFBQSxNQUNDRixlQUFlLHVCQUFDLDZCQUNmLFVBQVVNLGVBQ1YsUUFBUU4sYUFDUixXQUFXbUIsU0FDWCxtQkFBbUJQLHVCQUNuQixjQUFjSCxhQUFhLHVCQUF1QixHQUNsRCxhQUNBLFdBQVdWLGlCQVBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPVztBQUFBLFNBbkNwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUNUO0FBQUEsSUFDQ0EsaUJBQWlCLHVCQUFDLFdBQVEsTUFBTW5CLGdCQUFnQnFELFVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxPQXZDMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdDQTtBQUVKO0FBQUNqRCxHQXhHS0Ysc0JBQW1EO0FBQUEsVUFDM0JKLFVBQ1RVLHFCQUNxQlQsa0JBQWtCYSxZQUNQYixrQkFBa0JpQixXQVFqRS9CLFlBS0FZLFdBQVc7QUFBQTtBQUFBeUQsS0FqQlhwRDtBQTBHTixNQUFNTSxzQkFBc0JBLE1BQU07QUFBQStDLE1BQUE7QUFDaEMsUUFBTTtBQUFBLElBQUVqRDtBQUFBQSxFQUFPLElBQUlSLFNBQVM7QUFFNUIsU0FBT2QsZUFBZTtBQUFBLElBQ3BCdUIsUUFBUTtBQUFBLE1BQ04sVUFBVTtBQUFBLFFBQ1JpRCxpQkFBaUJsRCxPQUFPbUQsS0FBSyxHQUFHO0FBQUEsTUFDbEM7QUFBQSxNQUNBLFdBQVc7QUFBQSxRQUNURCxpQkFBaUJsRCxPQUFPbUQsS0FBSyxHQUFHO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFBQ0YsSUFiSy9DLHFCQUFtQjtBQUFBLFVBQ0pWLFFBQVE7QUFBQTtBQWM3QixlQUFlSTtBQUFvQixJQUFBb0Q7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbIkRpcmVjdGlvbmFsSGludCIsIm1lcmdlU3R5bGVTZXRzIiwidXNlQm9vbGVhbiIsInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsIkF1ZGl0Q2hhbmdlU2l0dWF0aW9uTW9kYWwiLCJBdWRpdHNTaXR1YXRpb24iLCJGbGV4Um93IiwiSWNvbkJ1dHRvbiIsIlNwaW5uZXIiLCJUb29sdGlwSG9zdCIsIkxvYWRpbmdEYXRhQ29udGV4dCIsIkF1ZGl0U2l0dWF0aW9uRW51bSIsInVzZUZvcm1EYXRhIiwidXNlVGhlbWUiLCJhdWRpdFF1ZXJ5U2VydmljZSIsIlNwaW5uZXJTaXplRW51bSIsIkNPTVBPTkVOVF9NQVhfSEVJR0hUIiwiQXVkaXRDaGFuZ2VTaXR1YXRpb24iLCJhdWRpdElkIiwiX3MiLCJzcGFjaW5nIiwiY29sb3JzIiwiYnV0dG9uIiwidXNlSWNvbkJ1dHRvblN0eWxlcyIsImRhdGEiLCJpc0xvYWRpbmciLCJpc0ZldGNoaW5nIiwidXNlRmluZE9uZSIsIm11dGF0ZUFzeW5jIiwic2F2ZSIsImlzU2F2aW5nIiwidXNlVXBkYXRlIiwic2V0SXNMb2FkaW5nIiwic2V0R2xvYmFsTG9hZGluZyIsImdsb2JhbExvYWRpbmciLCJpc01vZGFsT3BlbiIsInNldFRydWUiLCJvcGVuTW9kYWwiLCJzZXRGYWxzZSIsImNsb3NlTW9kYWwiLCJmb3JtRGF0YSIsImxvY2FsRm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldExvY2FsRm9ybURhdGEiLCJvblRleHRDaGFuZ2UiLCJqdXN0aWZpY2F0aXZhIiwicmVzZXRGb3JtRGF0YSIsImhhbmRsZUNoYW5nZVNpdHVhdGlvbiIsIl9ldiIsIm9wdGlvbiIsInByZXYiLCJzaXR1YWNhbyIsInBhcnNlSW50Iiwia2V5Iiwib25DbG9zZSIsInNhdmVDaGFuZ2VzIiwic20iLCJ1bmRlZmluZWQiLCJsZyIsIlJlY29ycmVudGUiLCJyaWdodENlbnRlciIsImljb25OYW1lIiwiQ2FuY2VsYWRvIiwiaWNvbiIsImNvbG9yIiwiYmx1ZSIsInJvb3QiLCJtYXhIZWlnaHQiLCJtZWRpdW0iLCJfYyIsIl9zMiIsImJhY2tncm91bmRDb2xvciIsImdyYXkiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdENoYW5nZVNpdHVhdGlvbi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2F1ZGl0cy9jb21wb25lbnRzL0F1ZGl0Q2hhbmdlU2l0dWF0aW9uLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGlvbmFsSGludCwgSUNob2ljZUdyb3VwT3B0aW9uLCBtZXJnZVN0eWxlU2V0cyB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdCdcclxuaW1wb3J0IHsgdXNlQm9vbGVhbiB9IGZyb20gJ0BmbHVlbnR1aS9yZWFjdC1ob29rcydcclxuaW1wb3J0IHsgRkMsIEZvcm1FdmVudCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBBdWRpdENoYW5nZVNpdHVhdGlvbk1vZGFsLCBBdWRpdHNTaXR1YXRpb24gfSBmcm9tICcuJ1xyXG5pbXBvcnQgQXVkaXQgZnJvbSAnLi4vLi4vLi4vLi4vZG9tYWluL0F1ZGl0J1xyXG5pbXBvcnQgeyBGbGV4Um93LCBJY29uQnV0dG9uLCBTcGlubmVyLCBUb29sdGlwSG9zdCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBMb2FkaW5nRGF0YUNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29udGV4dC9Mb2FkaW5nRGF0YUNvbnRleHQnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcbmltcG9ydCB7IHVzZUZvcm1EYXRhLCB1c2VUaGVtZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9ob29rcydcclxuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcydcclxuaW1wb3J0IHsgU3Bpbm5lclNpemVFbnVtIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2VudW1zL1NwaW5uZXJTaXplRW51bSdcclxuXHJcbmludGVyZmFjZSBBdWRpdENoYW5nZVNpdHVhdGlvblByb3BzIHtcclxuICBhdWRpdElkOiBzdHJpbmdcclxufVxyXG5cclxuY29uc3QgQ09NUE9ORU5UX01BWF9IRUlHSFQgPSAyNVxyXG5cclxuY29uc3QgQXVkaXRDaGFuZ2VTaXR1YXRpb246IEZDPEF1ZGl0Q2hhbmdlU2l0dWF0aW9uUHJvcHM+ID0gKHsgYXVkaXRJZCB9KSA9PiB7XHJcbiAgY29uc3QgeyBzcGFjaW5nLCBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuICBjb25zdCB7IGJ1dHRvbiB9ID0gdXNlSWNvbkJ1dHRvblN0eWxlcygpXHJcbiAgY29uc3QgeyBkYXRhLCBpc0xvYWRpbmcsIGlzRmV0Y2hpbmcgfSA9IGF1ZGl0UXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoYXVkaXRJZCBhcyBzdHJpbmcpXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogc2F2ZSwgaXNMb2FkaW5nOiBpc1NhdmluZyB9ID0gYXVkaXRRdWVyeVNlcnZpY2UudXNlVXBkYXRlKClcclxuICBjb25zdCB7IHNldElzTG9hZGluZzogc2V0R2xvYmFsTG9hZGluZywgaXNMb2FkaW5nOiBnbG9iYWxMb2FkaW5nIH0gPSB1c2VDb250ZXh0KExvYWRpbmdEYXRhQ29udGV4dClcclxuICBjb25zdCBbXHJcbiAgICBpc01vZGFsT3BlbixcclxuICAgIHtcclxuICAgICAgc2V0VHJ1ZTogb3Blbk1vZGFsLFxyXG4gICAgICBzZXRGYWxzZTogY2xvc2VNb2RhbCxcclxuICAgIH0sXHJcbiAgXSA9IHVzZUJvb2xlYW4oZmFsc2UpXHJcbiAgY29uc3Qge1xyXG4gICAgZm9ybURhdGE6IGxvY2FsRm9ybURhdGEsXHJcbiAgICBzZXRGb3JtRGF0YTogc2V0TG9jYWxGb3JtRGF0YSxcclxuICAgIG9uVGV4dENoYW5nZSxcclxuICB9ID0gdXNlRm9ybURhdGE8QXVkaXQ+KHsgLi4uZGF0YSwganVzdGlmaWNhdGl2YTogJycgfSBhcyBBdWRpdClcclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtRGF0YSA9IHVzZUNhbGxiYWNrKChkYXRhOiBBdWRpdCkgPT4ge1xyXG4gICAgc2V0TG9jYWxGb3JtRGF0YSh7IC4uLmRhdGEsIGp1c3RpZmljYXRpdmE6ICcnIH0pXHJcbiAgfSwgW2RhdGFdKVxyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VTaXR1YXRpb24gPSB1c2VDYWxsYmFjayhcclxuICAgIChfZXY/OiBGb3JtRXZlbnQ8SFRNTEVsZW1lbnQgfCBIVE1MSW5wdXRFbGVtZW50Piwgb3B0aW9uPzogSUNob2ljZUdyb3VwT3B0aW9uKSA9PiB7XHJcbiAgICAgIGlmIChvcHRpb24pIHtcclxuICAgICAgICBzZXRMb2NhbEZvcm1EYXRhKHByZXYgPT4gKFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBzaXR1YWNhbzogcGFyc2VJbnQob3B0aW9uLmtleSksXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgICAgfVxyXG4gICAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG9uQ2xvc2UgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBpZiAoZGF0YSkge1xyXG4gICAgICByZXNldEZvcm1EYXRhKGRhdGEpXHJcbiAgICB9XHJcbiAgICBjbG9zZU1vZGFsKClcclxuICB9LCBbZGF0YV0pXHJcblxyXG4gIGNvbnN0IHNhdmVDaGFuZ2VzID0gdXNlQ2FsbGJhY2soYXN5bmMgKGRhdGE/OiBBdWRpdCkgPT4ge1xyXG4gICAgaWYgKGRhdGEpIHtcclxuICAgICAgc2V0TG9jYWxGb3JtRGF0YSh7IC4uLmRhdGEgfSlcclxuICAgICAgYXdhaXQgc2F2ZShkYXRhKVxyXG4gICAgfSBlbHNlIGlmIChsb2NhbEZvcm1EYXRhKSB7XHJcbiAgICAgIGF3YWl0IHNhdmUoeyAuLi5sb2NhbEZvcm1EYXRhIH0pXHJcbiAgICB9XHJcbiAgfSwgW2xvY2FsRm9ybURhdGFdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGRhdGEpIHtcclxuICAgICAgcmVzZXRGb3JtRGF0YShkYXRhKVxyXG4gICAgfVxyXG4gIH0sIFtkYXRhXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldEdsb2JhbExvYWRpbmcoaXNMb2FkaW5nIHx8IGlzU2F2aW5nIHx8IGlzRmV0Y2hpbmcpXHJcbiAgfSwgW2lzTG9hZGluZywgaXNTYXZpbmcsIGlzRmV0Y2hpbmddKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge2RhdGEgJiYgPEZsZXhSb3dcclxuICAgICAgICBnYXA9e3NwYWNpbmcuc219XHJcbiAgICAgID5cclxuICAgICAgICB7ZGF0YS5zaXR1YWNhbyAhPT0gdW5kZWZpbmVkICYmICFnbG9iYWxMb2FkaW5nICYmIDxBdWRpdHNTaXR1YXRpb25cclxuICAgICAgICAgIHNpdHVhdGlvbj17ZGF0YT8uc2l0dWFjYW8gYXMgQXVkaXRTaXR1YXRpb25FbnVtfVxyXG4gICAgICAgICAgbWFyZ2luTGVmdD17c3BhY2luZy5sZ31cclxuICAgICAgICAvPn1cclxuICAgICAgICB7ZGF0YS5zaXR1YWNhbyAhPT0gdW5kZWZpbmVkICYmICFnbG9iYWxMb2FkaW5nICYmIDxUb29sdGlwSG9zdFxyXG4gICAgICAgICAgY29udGVudD17XHJcbiAgICAgICAgICAgIGRhdGE/LnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uUmVjb3JyZW50ZVxyXG4gICAgICAgICAgICAgID8gJ0F1ZGl0b3JpYSByZWNvcnJlbnRlJ1xyXG4gICAgICAgICAgICAgIDogJ0FsdGVyYXIgc2l0dWHDp8OjbydcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGRpcmVjdGlvbmFsSGludD17RGlyZWN0aW9uYWxIaW50LnJpZ2h0Q2VudGVyfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YnV0dG9ufVxyXG4gICAgICAgICAgICBpY29uUHJvcHM9e3sgaWNvbk5hbWU6ICdTd2l0Y2gnIH19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkYXRhLnNpdHVhY2FvID09PSBBdWRpdFNpdHVhdGlvbkVudW0uQ2FuY2VsYWRvfVxyXG4gICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICBpY29uOiB7IGNvbG9yOiBjb2xvcnMuYmx1ZVs1MDBdIH0sXHJcbiAgICAgICAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAgICAgbWF4SGVpZ2h0OiBDT01QT05FTlRfTUFYX0hFSUdIVCxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvcGVuTW9kYWx9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvVG9vbHRpcEhvc3Q+fVxyXG4gICAgICAgIHtpc01vZGFsT3BlbiAmJiA8QXVkaXRDaGFuZ2VTaXR1YXRpb25Nb2RhbFxyXG4gICAgICAgICAgZm9ybURhdGE9e2xvY2FsRm9ybURhdGF9XHJcbiAgICAgICAgICBpc09wZW49e2lzTW9kYWxPcGVufVxyXG4gICAgICAgICAgb25EaXNtaXNzPXtvbkNsb3NlfVxyXG4gICAgICAgICAgb25DaGFuZ2VTaXR1YXRpb249e2hhbmRsZUNoYW5nZVNpdHVhdGlvbn1cclxuICAgICAgICAgIG9uVGV4dENoYW5nZT17b25UZXh0Q2hhbmdlKCdqdXN0aWZpY2F0aXZhU2l0dWFjYW8nKX1cclxuICAgICAgICAgIHNhdmVDaGFuZ2VzPXtzYXZlQ2hhbmdlc31cclxuICAgICAgICAgIGlzTG9hZGluZz17Z2xvYmFsTG9hZGluZ31cclxuICAgICAgICAvPn1cclxuICAgICAgPC9GbGV4Um93Pn1cclxuICAgICAge2dsb2JhbExvYWRpbmcgJiYgPFNwaW5uZXIgc2l6ZT17U3Bpbm5lclNpemVFbnVtLm1lZGl1bX0gLz59XHJcbiAgICA8Lz5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZUljb25CdXR0b25TdHlsZXMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMgfSA9IHVzZVRoZW1lKClcclxuXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGJ1dHRvbjoge1xyXG4gICAgICAnOmhvdmVyJzoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcclxuICAgICAgfSxcclxuICAgICAgJzphY3RpdmUnOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuZ3JheVszMDBdLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWRpdENoYW5nZVNpdHVhdGlvblxyXG4iXX0=