import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { FontSizes, FontWeights, mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport4_react["useMemo"];
import { useTagsColors } from "/src/shared/hooks/index.ts";
const NotificationCenterTitlePivot = (props) => {
  _s();
  const {
    text,
    module,
    notifications
  } = props;
  const styles = useStyles(1);
  const countNotifications = useMemo(() => {
    const filterefListByView = notifications?.filter((item) => item.pendente);
    if (module) {
      const filteredList = filterefListByView?.filter((item) => item.modulo === module);
      return filteredList.length;
    }
    return filterefListByView.length;
  }, [module, notifications]);
  return /* @__PURE__ */ jsxDEV("div", { className: styles.content, children: [
    text,
    countNotifications > 0 && /* @__PURE__ */ jsxDEV("div", { className: styles.container, children: countNotifications }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx",
      lineNumber: 32,
      columnNumber: 34
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
};
_s(NotificationCenterTitlePivot, "iVjitvr3jR82zWpc6GMDJDpRXBw=", false, function() {
  return [useStyles];
});
_c = NotificationCenterTitlePivot;
export default NotificationCenterTitlePivot;
const useStyles = (props) => {
  _s2();
  const {
    background,
    color
  } = useTagsColors(props, ListTags);
  return mergeStyleSets({
    content: {
      display: "flex",
      flexDirection: "row",
      alignItems: "center"
    },
    container: {
      marginLeft: "5px",
      display: "flex",
      alignItems: "center",
      fontSize: FontSizes.mini,
      fontWeight: FontWeights.bold,
      backgroundColor: background,
      color,
      height: 20,
      padding: "4px",
      borderRadius: "2px"
    }
  });
};
_s2(useStyles, "yAqk/mHsCk1OPWDYazbBUeiAsGM=", false, function() {
  return [useTagsColors];
});
const ListTags = [{
  value: 1,
  type: "Count"
}];
var _c;
$RefreshReg$(_c, "NotificationCenterTitlePivot");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationCenterTitlePivot.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBL0JSLFNBQVNBLFdBQVdDLGFBQWFDLHNCQUFzQjtBQUN2RCxTQUFhQyxlQUFlO0FBRzVCLFNBQVNDLHFCQUFxQjtBQVM5QixNQUFNQywrQkFBdUVDLFdBQVU7QUFBQUMsS0FBQTtBQUNyRixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBTUM7QUFBQUEsSUFBUUM7QUFBQUEsRUFBYyxJQUFJSjtBQUN4QyxRQUFNSyxTQUFTQyxVQUFVLENBQUM7QUFFMUIsUUFBTUMscUJBQXFCVixRQUFRLE1BQU07QUFDdkMsVUFBTVcscUJBQXFCSixlQUFlSyxPQUFPQyxVQUFRQSxLQUFLQyxRQUFRO0FBQ3RFLFFBQUlSLFFBQVE7QUFDVixZQUFNUyxlQUFlSixvQkFBb0JDLE9BQU9DLFVBQVFBLEtBQUtHLFdBQVdWLE1BQU07QUFDOUUsYUFBT1MsYUFBYUU7QUFBQUEsSUFDdEI7QUFFQSxXQUFPTixtQkFBbUJNO0FBQUFBLEVBQzVCLEdBQUcsQ0FBQ1gsUUFBUUMsYUFBYSxDQUFDO0FBRTFCLFNBQ0UsdUJBQUMsU0FBSSxXQUFXQyxPQUFPVSxTQUNwQmI7QUFBQUE7QUFBQUEsSUFDQUsscUJBQXFCLEtBQ3BCLHVCQUFDLFNBQUksV0FBV0YsT0FBT1csV0FBWVQsZ0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxPQUgxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDTixHQXRCS0YsOEJBQW1FO0FBQUEsVUFFeERPLFNBQVM7QUFBQTtBQUFBVyxLQUZwQmxCO0FBd0JOLGVBQWVBO0FBRWYsTUFBTU8sWUFBWUEsQ0FBQ04sVUFBc0I7QUFBQWtCLE1BQUE7QUFDdkMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVlDO0FBQUFBLEVBQU0sSUFBSXRCLGNBQWNFLE9BQU9xQixRQUFRO0FBQzNELFNBQU96QixlQUFlO0FBQUEsSUFDcEJtQixTQUFTO0FBQUEsTUFDUE8sU0FBUztBQUFBLE1BQ1RDLGVBQWU7QUFBQSxNQUNmQyxZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0FSLFdBQVc7QUFBQSxNQUNUUyxZQUFZO0FBQUEsTUFDWkgsU0FBUztBQUFBLE1BQ1RFLFlBQVk7QUFBQSxNQUNaRSxVQUFVaEMsVUFBVWlDO0FBQUFBLE1BQ3BCQyxZQUFZakMsWUFBWWtDO0FBQUFBLE1BQ3hCQyxpQkFBaUJYO0FBQUFBLE1BQ2pCQztBQUFBQSxNQUNBVyxRQUFRO0FBQUEsTUFDUkMsU0FBUztBQUFBLE1BQ1RDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNmLElBckJLWixXQUFTO0FBQUEsVUFDaUJSLGFBQWE7QUFBQTtBQXNCN0MsTUFBTXVCLFdBQVcsQ0FDZjtBQUFBLEVBQ0VhLE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQ1IsQ0FBQztBQUN5QixJQUFBbEI7QUFBQW1CLGFBQUFuQixJQUFBIiwibmFtZXMiOlsiRm9udFNpemVzIiwiRm9udFdlaWdodHMiLCJtZXJnZVN0eWxlU2V0cyIsInVzZU1lbW8iLCJ1c2VUYWdzQ29sb3JzIiwiTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdCIsInByb3BzIiwiX3MiLCJ0ZXh0IiwibW9kdWxlIiwibm90aWZpY2F0aW9ucyIsInN0eWxlcyIsInVzZVN0eWxlcyIsImNvdW50Tm90aWZpY2F0aW9ucyIsImZpbHRlcmVmTGlzdEJ5VmlldyIsImZpbHRlciIsIml0ZW0iLCJwZW5kZW50ZSIsImZpbHRlcmVkTGlzdCIsIm1vZHVsbyIsImxlbmd0aCIsImNvbnRlbnQiLCJjb250YWluZXIiLCJfYyIsIl9zMiIsImJhY2tncm91bmQiLCJjb2xvciIsIkxpc3RUYWdzIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJhbGlnbkl0ZW1zIiwibWFyZ2luTGVmdCIsImZvbnRTaXplIiwibWluaSIsImZvbnRXZWlnaHQiLCJib2xkIiwiYmFja2dyb3VuZENvbG9yIiwiaGVpZ2h0IiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsInZhbHVlIiwidHlwZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbkNlbnRlclRpdGxlUGl2b3QudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvbm90aWZpY2F0aW9ucy9jb21wb25lbnRzL05vdGlmaWNhdGlvbkNlbnRlclRpdGxlUGl2b3QudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRm9udFNpemVzLCBGb250V2VpZ2h0cywgbWVyZ2VTdHlsZVNldHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXG5pbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEFwcE5vdGlmaWNhdGlvbiBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQXBwTm90aWZpY2F0aW9uJ1xuaW1wb3J0IHsgTW9kdWxlRW51bSB9IGZyb20gJy4uLy4uLy4uL2VudW1zL01vZHVsZUVudW0nXG5pbXBvcnQgeyB1c2VUYWdzQ29sb3JzIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MnXG5pbXBvcnQgeyBUYWdzQ29tcG9zaXRpb25Nb2R1bGUgfSBmcm9tICcuLi8uLi8uLi9ob29rcy90YWdzQ29sb3JzJ1xuXG5pbnRlcmZhY2UgTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdFByb3BzIHtcbiAgdGV4dDogc3RyaW5nXG4gIG1vZHVsZT86IE1vZHVsZUVudW1cbiAgbm90aWZpY2F0aW9uczogQXBwTm90aWZpY2F0aW9uW11cbn1cblxuY29uc3QgTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdDogRkM8Tm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdFByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IHRleHQsIG1vZHVsZSwgbm90aWZpY2F0aW9ucyB9ID0gcHJvcHNcbiAgY29uc3Qgc3R5bGVzID0gdXNlU3R5bGVzKDEpXG5cbiAgY29uc3QgY291bnROb3RpZmljYXRpb25zID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgZmlsdGVyZWZMaXN0QnlWaWV3ID0gbm90aWZpY2F0aW9ucz8uZmlsdGVyKGl0ZW0gPT4gaXRlbS5wZW5kZW50ZSlcbiAgICBpZiAobW9kdWxlKSB7XG4gICAgICBjb25zdCBmaWx0ZXJlZExpc3QgPSBmaWx0ZXJlZkxpc3RCeVZpZXc/LmZpbHRlcihpdGVtID0+IGl0ZW0ubW9kdWxvID09PSBtb2R1bGUpXG4gICAgICByZXR1cm4gZmlsdGVyZWRMaXN0Lmxlbmd0aFxuICAgIH1cblxuICAgIHJldHVybiBmaWx0ZXJlZkxpc3RCeVZpZXcubGVuZ3RoXG4gIH0sIFttb2R1bGUsIG5vdGlmaWNhdGlvbnNdKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250ZW50fT5cbiAgICAgIHt0ZXh0fVxuICAgICAge2NvdW50Tm90aWZpY2F0aW9ucyA+IDAgJiZcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9Pntjb3VudE5vdGlmaWNhdGlvbnN9PC9kaXY+XG4gICAgICB9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uQ2VudGVyVGl0bGVQaXZvdFxuXG5jb25zdCB1c2VTdHlsZXMgPSAocHJvcHM6IE1vZHVsZUVudW0pID0+IHtcbiAgY29uc3QgeyBiYWNrZ3JvdW5kLCBjb2xvciB9ID0gdXNlVGFnc0NvbG9ycyhwcm9wcywgTGlzdFRhZ3MpXG4gIHJldHVybiBtZXJnZVN0eWxlU2V0cyh7XG4gICAgY29udGVudDoge1xuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICB9LFxuICAgIGNvbnRhaW5lcjoge1xuICAgICAgbWFyZ2luTGVmdDogJzVweCcsXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgIGZvbnRTaXplOiBGb250U2l6ZXMubWluaSxcbiAgICAgIGZvbnRXZWlnaHQ6IEZvbnRXZWlnaHRzLmJvbGQsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGJhY2tncm91bmQsXG4gICAgICBjb2xvcjogY29sb3IsXG4gICAgICBoZWlnaHQ6IDIwLFxuICAgICAgcGFkZGluZzogJzRweCcsXG4gICAgICBib3JkZXJSYWRpdXM6ICcycHgnLFxuICAgIH0sXG4gIH0pXG59XG5cbmNvbnN0IExpc3RUYWdzID0gW1xuICB7XG4gICAgdmFsdWU6IDEsXG4gICAgdHlwZTogJ0NvdW50JyxcbiAgfSxcbl0gYXMgVGFnc0NvbXBvc2l0aW9uTW9kdWxlW11cbiJdfQ==