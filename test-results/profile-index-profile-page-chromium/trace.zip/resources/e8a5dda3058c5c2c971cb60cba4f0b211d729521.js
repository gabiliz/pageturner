import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { FlexColumn, ProgressIndicator } from "/src/shared/components/index.ts?t=1701096626433";
const RiskFormForwardProgressIndicator = (props) => {
  _s();
  const [progress, setProgress] = useState({
    answeredCount: 0,
    percentual: 0,
    decimal: 0
  });
  const answeredQuestionsProgress = useCallback((receivedAnswers) => {
    const totalOfQuestions = receivedAnswers.perguntas.length;
    const totalOfAnsweredQuestions = receivedAnswers.perguntas.reduce((prevCount, currentAnswer) => {
      if (currentAnswer.resposta !== void 0 && currentAnswer.resposta !== 4) {
        return prevCount + 1;
      }
      return prevCount;
    }, 0);
    const progressCount = totalOfAnsweredQuestions / totalOfQuestions;
    const progressPercent = Math.round(progressCount * 100);
    setProgress({
      answeredCount: totalOfAnsweredQuestions,
      percentual: progressPercent,
      decimal: progressCount
    });
  }, [props.answers]);
  useEffect(() => {
    answeredQuestionsProgress(props.answers);
  }, [props.answers]);
  return /* @__PURE__ */ jsxDEV(FlexColumn, { children: /* @__PURE__ */ jsxDEV(ProgressIndicator, { description: `${progress.answeredCount}/${props.answers.perguntas.length} respondidas`, percentComplete: progress.decimal }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx",
    lineNumber: 35,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(RiskFormForwardProgressIndicator, "PtSJKPmBOQjiJmiKQs5uPXEq3/U=");
_c = RiskFormForwardProgressIndicator;
export default RiskFormForwardProgressIndicator;
var _c;
$RefreshReg$(_c, "RiskFormForwardProgressIndicator");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/riskForm/components/RiskFormForwardProgressIndicator.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkNOLFNBQWFBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUVyRCxTQUFTQyxZQUFZQyx5QkFBeUI7QUFNOUMsTUFBTUMsbUNBQStFQyxXQUFVO0FBQUFDLEtBQUE7QUFDN0YsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlQLFNBQXdDO0FBQUEsSUFDdEVRLGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLDRCQUE0QmIsWUFBWSxDQUFDYyxvQkFBeUM7QUFDdEYsVUFBTUMsbUJBQW1CRCxnQkFBZ0JFLFVBQVVDO0FBQ25ELFVBQU1DLDJCQUEyQkosZ0JBQWdCRSxVQUFVRyxPQUFPLENBQUNDLFdBQVdDLGtCQUFrQjtBQUM5RixVQUFJQSxjQUFjQyxhQUFhQyxVQUFhRixjQUFjQyxhQUFhLEdBQUc7QUFDeEUsZUFBT0YsWUFBWTtBQUFBLE1BQ3JCO0FBQ0EsYUFBT0E7QUFBQUEsSUFDVCxHQUFHLENBQUM7QUFDSixVQUFNSSxnQkFBZ0JOLDJCQUEyQkg7QUFDakQsVUFBTVUsa0JBQWtCQyxLQUFLQyxNQUFNSCxnQkFBZ0IsR0FBRztBQUV0RGYsZ0JBQVk7QUFBQSxNQUNWQyxlQUFlUTtBQUFBQSxNQUNmUCxZQUFZYztBQUFBQSxNQUNaYixTQUFTWTtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ2xCLE1BQU1zQixPQUFPLENBQUM7QUFFbEIzQixZQUFVLE1BQU07QUFDZFksOEJBQTBCUCxNQUFNc0IsT0FBTztBQUFBLEVBQ3pDLEdBQUcsQ0FBQ3RCLE1BQU1zQixPQUFPLENBQUM7QUFFbEIsU0FDRSx1QkFBQyxjQUNDLGlDQUFDLHFCQUNDLGFBQWMsR0FBRXBCLFNBQVNFLGlCQUFpQkosTUFBTXNCLFFBQVFaLFVBQVVDLHNCQUNsRSxpQkFBaUJULFNBQVNJLFdBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFb0MsS0FIdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0wsR0FyQ0tGLGtDQUEyRTtBQUFBd0IsS0FBM0V4QjtBQXVDTixlQUFlQTtBQUFnQyxJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJGbGV4Q29sdW1uIiwiUHJvZ3Jlc3NJbmRpY2F0b3IiLCJSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvciIsInByb3BzIiwiX3MiLCJwcm9ncmVzcyIsInNldFByb2dyZXNzIiwiYW5zd2VyZWRDb3VudCIsInBlcmNlbnR1YWwiLCJkZWNpbWFsIiwiYW5zd2VyZWRRdWVzdGlvbnNQcm9ncmVzcyIsInJlY2VpdmVkQW5zd2VycyIsInRvdGFsT2ZRdWVzdGlvbnMiLCJwZXJndW50YXMiLCJsZW5ndGgiLCJ0b3RhbE9mQW5zd2VyZWRRdWVzdGlvbnMiLCJyZWR1Y2UiLCJwcmV2Q291bnQiLCJjdXJyZW50QW5zd2VyIiwicmVzcG9zdGEiLCJ1bmRlZmluZWQiLCJwcm9ncmVzc0NvdW50IiwicHJvZ3Jlc3NQZXJjZW50IiwiTWF0aCIsInJvdW5kIiwiYW5zd2VycyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmlza0Zvcm1Gb3J3YXJkUHJvZ3Jlc3NJbmRpY2F0b3IudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9yaXNrRm9ybS9jb21wb25lbnRzL1Jpc2tGb3JtRm9yd2FyZFByb2dyZXNzSW5kaWNhdG9yLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBSaXNrRm9ybUFuc3dlckdyb3VwLCBSaXNrRm9ybUZvcndhcmRBbnN3ZXJQcm9ncmVzcyB9IGZyb20gJy4uLy4uLy4uLy4uL2RvbWFpbi9SaXNrRm9ybSdcclxuaW1wb3J0IHsgRmxleENvbHVtbiwgUHJvZ3Jlc3NJbmRpY2F0b3IgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuXHJcbmludGVyZmFjZSBSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvclByb3BzIHtcclxuICBhbnN3ZXJzOiBSaXNrRm9ybUFuc3dlckdyb3VwXHJcbn1cclxuXHJcbmNvbnN0IFJpc2tGb3JtRm9yd2FyZFByb2dyZXNzSW5kaWNhdG9yOiBGQzxSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvclByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IFtwcm9ncmVzcywgc2V0UHJvZ3Jlc3NdID0gdXNlU3RhdGU8Umlza0Zvcm1Gb3J3YXJkQW5zd2VyUHJvZ3Jlc3M+KHtcclxuICAgIGFuc3dlcmVkQ291bnQ6IDAsXHJcbiAgICBwZXJjZW50dWFsOiAwLFxyXG4gICAgZGVjaW1hbDogMCxcclxuICB9KVxyXG5cclxuICBjb25zdCBhbnN3ZXJlZFF1ZXN0aW9uc1Byb2dyZXNzID0gdXNlQ2FsbGJhY2soKHJlY2VpdmVkQW5zd2VyczogUmlza0Zvcm1BbnN3ZXJHcm91cCkgPT4ge1xyXG4gICAgY29uc3QgdG90YWxPZlF1ZXN0aW9ucyA9IHJlY2VpdmVkQW5zd2Vycy5wZXJndW50YXMubGVuZ3RoXHJcbiAgICBjb25zdCB0b3RhbE9mQW5zd2VyZWRRdWVzdGlvbnMgPSByZWNlaXZlZEFuc3dlcnMucGVyZ3VudGFzLnJlZHVjZSgocHJldkNvdW50LCBjdXJyZW50QW5zd2VyKSA9PiB7XHJcbiAgICAgIGlmIChjdXJyZW50QW5zd2VyLnJlc3Bvc3RhICE9PSB1bmRlZmluZWQgJiYgY3VycmVudEFuc3dlci5yZXNwb3N0YSAhPT0gNCkge1xyXG4gICAgICAgIHJldHVybiBwcmV2Q291bnQgKyAxXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHByZXZDb3VudFxyXG4gICAgfSwgMClcclxuICAgIGNvbnN0IHByb2dyZXNzQ291bnQgPSB0b3RhbE9mQW5zd2VyZWRRdWVzdGlvbnMgLyB0b3RhbE9mUXVlc3Rpb25zXHJcbiAgICBjb25zdCBwcm9ncmVzc1BlcmNlbnQgPSBNYXRoLnJvdW5kKHByb2dyZXNzQ291bnQgKiAxMDApXHJcblxyXG4gICAgc2V0UHJvZ3Jlc3Moe1xyXG4gICAgICBhbnN3ZXJlZENvdW50OiB0b3RhbE9mQW5zd2VyZWRRdWVzdGlvbnMsXHJcbiAgICAgIHBlcmNlbnR1YWw6IHByb2dyZXNzUGVyY2VudCxcclxuICAgICAgZGVjaW1hbDogcHJvZ3Jlc3NDb3VudCxcclxuICAgIH0pXHJcbiAgfSwgW3Byb3BzLmFuc3dlcnNdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYW5zd2VyZWRRdWVzdGlvbnNQcm9ncmVzcyhwcm9wcy5hbnN3ZXJzKVxyXG4gIH0sIFtwcm9wcy5hbnN3ZXJzXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxGbGV4Q29sdW1uPlxyXG4gICAgICA8UHJvZ3Jlc3NJbmRpY2F0b3JcclxuICAgICAgICBkZXNjcmlwdGlvbj17YCR7cHJvZ3Jlc3MuYW5zd2VyZWRDb3VudH0vJHtwcm9wcy5hbnN3ZXJzLnBlcmd1bnRhcy5sZW5ndGh9IHJlc3BvbmRpZGFzYH1cclxuICAgICAgICBwZXJjZW50Q29tcGxldGU9e3Byb2dyZXNzLmRlY2ltYWx9XHJcbiAgICAgIC8+XHJcbiAgICA8L0ZsZXhDb2x1bW4+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSaXNrRm9ybUZvcndhcmRQcm9ncmVzc0luZGljYXRvclxyXG4iXX0=