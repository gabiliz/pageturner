import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditChangeSituationModal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useCallback = __vite__cjsImport4_react["useCallback"];
import { ChoiceGroup, DefaultButton, Modal, PrimaryButton, TextField } from "/src/shared/components/index.ts?t=1701096626433";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
import { useTheme } from "/src/shared/hooks/index.ts";
import { AuditSituationRecord } from "/src/shared/record/AuditSituationRecord.ts";
const TEXTFIELD_VARS = {
  cols: 5,
  maxChars: 200,
  resizeable: false
};
const MODAL_WIDTH = 424;
const AuditChangeSituationModal = (props) => {
  _s();
  const {
    onDismiss,
    isOpen,
    formData,
    onChangeSituation,
    onTextChange,
    saveChanges,
    isLoading
  } = props;
  const styles = useStyles();
  const handleSaveClick = useCallback(() => {
    saveChanges(formData);
    onDismiss();
  }, [formData, onDismiss]);
  return /* @__PURE__ */ jsxDEV(Modal, { onDismiss, isOpen, title: "Alterar situação", width: MODAL_WIDTH, children: [
    /* @__PURE__ */ jsxDEV(ChoiceGroup, { options: choiceOptions, onChange: onChangeSituation, selectedKey: formData.situacao?.toString(), disabled: isLoading }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { label: "Justificativa", maxLength: TEXTFIELD_VARS.maxChars, multiline: true, cols: TEXTFIELD_VARS.cols, resizable: TEXTFIELD_VARS.resizeable, value: formData.justificativaSituacao, onChange: onTextChange, disabled: isLoading }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: styles.actionStyles.actions, children: [
      /* @__PURE__ */ jsxDEV(DefaultButton, { text: "Cancelar", onClick: () => onDismiss() }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrimaryButton, { text: "Salvar", onClick: handleSaveClick, disabled: isLoading || formData.justificativaSituacao?.trim().length === 0 }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx",
    lineNumber: 39,
    columnNumber: 10
  }, this);
};
_s(AuditChangeSituationModal, "gOQeZ+59mxvMjp0cYNcnnU/fZa4=", false, function() {
  return [useStyles];
});
_c = AuditChangeSituationModal;
const choiceOptions = [{
  key: AuditSituationEnum.EmAndamento.toString(),
  text: AuditSituationRecord[AuditSituationEnum.EmAndamento]
}, {
  key: AuditSituationEnum.EmSolicitacao.toString(),
  text: AuditSituationRecord[AuditSituationEnum.EmSolicitacao]
}, {
  key: AuditSituationEnum.EmLevantamento.toString(),
  text: AuditSituationRecord[AuditSituationEnum.EmLevantamento]
}, {
  key: AuditSituationEnum.Conferencia.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Conferencia]
}, {
  key: AuditSituationEnum.Apresentacao.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Apresentacao]
}, {
  key: AuditSituationEnum.Recorrente.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Recorrente]
}, {
  key: AuditSituationEnum.Implementacao.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Implementacao]
}, {
  key: AuditSituationEnum.Faturamento.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Faturamento]
}, {
  key: AuditSituationEnum.AIniciar.toString(),
  text: AuditSituationRecord[AuditSituationEnum.AIniciar]
}, {
  key: AuditSituationEnum.Restituicao.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Restituicao]
}, {
  key: AuditSituationEnum.AcaoJudicial.toString(),
  text: AuditSituationRecord[AuditSituationEnum.AcaoJudicial]
}, {
  key: AuditSituationEnum.StandBy.toString(),
  text: AuditSituationRecord[AuditSituationEnum.StandBy]
}, {
  key: AuditSituationEnum.Planejamento.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Planejamento]
}, {
  key: AuditSituationEnum.Acompanhamento.toString(),
  text: AuditSituationRecord[AuditSituationEnum.Acompanhamento]
}];
const useStyles = () => {
  _s2();
  const {
    spacing
  } = useTheme();
  const actionStyles = mergeStyleSets({
    actions: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 40,
      selectors: {
        "& > :not(:last-child)": {
          marginRight: spacing.lg
        }
      }
    }
  });
  return {
    actionStyles
  };
};
_s2(useStyles, "lSLd3AqB2wvfAVHj7LizcL6RJC4=", false, function() {
  return [useTheme];
});
export default AuditChangeSituationModal;
var _c;
$RefreshReg$(_c, "AuditChangeSituationModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditChangeSituationModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NNOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0NOLFNBQTZCQSxzQkFBc0I7QUFDbkQsU0FBd0JDLG1CQUFtQjtBQUUzQyxTQUFTQyxhQUFhQyxlQUFlQyxPQUFtQkMsZUFBZUMsaUJBQWlCO0FBQ3hGLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsNEJBQTRCO0FBVXJDLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCQyxNQUFNO0FBQUEsRUFDTkMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFDZDtBQUVBLE1BQU1DLGNBQWM7QUFFcEIsTUFBTUMsNEJBQWlFQyxXQUFVO0FBQUFDLEtBQUE7QUFDL0UsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsSUFBSVI7QUFDSixRQUFNUyxTQUFTQyxVQUFVO0FBRXpCLFFBQU1DLGtCQUFrQjFCLFlBQVksTUFBTTtBQUN4Q3NCLGdCQUFZSCxRQUFRO0FBQ3BCRixjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNFLFVBQVVGLFNBQVMsQ0FBQztBQUN4QixTQUNFLHVCQUFDLFNBQ0MsV0FDQSxRQUNBLE9BQU0sb0JBQ04sT0FBT0osYUFFUDtBQUFBLDJCQUFDLGVBQ0MsU0FBU2MsZUFDVCxVQUFVUCxtQkFDVixhQUFhRCxTQUFTUyxVQUFVQyxTQUFTLEdBQ3pDLFVBQVVOLGFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlzQjtBQUFBLElBRXRCLHVCQUFDLGFBQ0MsT0FBTSxpQkFDTixXQUFXZCxlQUFlRSxVQUMxQixXQUFTLE1BQ1QsTUFBTUYsZUFBZUMsTUFDckIsV0FBV0QsZUFBZUcsWUFDMUIsT0FBT08sU0FBU1csdUJBQ2hCLFVBQVVULGNBQ1YsVUFBVUUsYUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUXNCO0FBQUEsSUFFdEIsdUJBQUMsU0FBSSxXQUFXQyxPQUFPTyxhQUFhQyxTQUNsQztBQUFBLDZCQUFDLGlCQUNDLE1BQUssWUFDTCxTQUFTLE1BQU1mLFVBQVUsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU2QjtBQUFBLE1BRTdCLHVCQUFDLGlCQUNDLE1BQUssVUFDTCxTQUFTUyxpQkFDVCxVQUFVSCxhQUFhSixTQUFTVyx1QkFBdUJHLEtBQUssRUFBRUMsV0FBVyxLQUgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZFO0FBQUEsU0FSL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsT0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNsQixHQXBES0YsMkJBQTZEO0FBQUEsVUFVbERXLFNBQVM7QUFBQTtBQUFBVSxLQVZwQnJCO0FBc0ROLE1BQU1hLGdCQUFzQyxDQUMxQztBQUFBLEVBQ0VTLEtBQUs5QixtQkFBbUIrQixZQUFZUixTQUFTO0FBQUEsRUFDN0NTLE1BQU05QixxQkFBcUJGLG1CQUFtQitCLFdBQVc7QUFDM0QsR0FDQTtBQUFBLEVBQ0VELEtBQUs5QixtQkFBbUJpQyxjQUFjVixTQUFTO0FBQUEsRUFDL0NTLE1BQU05QixxQkFBcUJGLG1CQUFtQmlDLGFBQWE7QUFDN0QsR0FDQTtBQUFBLEVBQ0VILEtBQUs5QixtQkFBbUJrQyxlQUFlWCxTQUFTO0FBQUEsRUFDaERTLE1BQU05QixxQkFBcUJGLG1CQUFtQmtDLGNBQWM7QUFDOUQsR0FDQTtBQUFBLEVBQ0VKLEtBQUs5QixtQkFBbUJtQyxZQUFZWixTQUFTO0FBQUEsRUFDN0NTLE1BQU05QixxQkFBcUJGLG1CQUFtQm1DLFdBQVc7QUFDM0QsR0FDQTtBQUFBLEVBQ0VMLEtBQUs5QixtQkFBbUJvQyxhQUFhYixTQUFTO0FBQUEsRUFDOUNTLE1BQU05QixxQkFBcUJGLG1CQUFtQm9DLFlBQVk7QUFDNUQsR0FDQTtBQUFBLEVBQ0VOLEtBQUs5QixtQkFBbUJxQyxXQUFXZCxTQUFTO0FBQUEsRUFDNUNTLE1BQU05QixxQkFBcUJGLG1CQUFtQnFDLFVBQVU7QUFDMUQsR0FDQTtBQUFBLEVBQ0VQLEtBQUs5QixtQkFBbUJzQyxjQUFjZixTQUFTO0FBQUEsRUFDL0NTLE1BQU05QixxQkFBcUJGLG1CQUFtQnNDLGFBQWE7QUFDN0QsR0FDQTtBQUFBLEVBQ0VSLEtBQUs5QixtQkFBbUJ1QyxZQUFZaEIsU0FBUztBQUFBLEVBQzdDUyxNQUFNOUIscUJBQXFCRixtQkFBbUJ1QyxXQUFXO0FBQzNELEdBQ0E7QUFBQSxFQUNFVCxLQUFLOUIsbUJBQW1Cd0MsU0FBU2pCLFNBQVM7QUFBQSxFQUMxQ1MsTUFBTTlCLHFCQUFxQkYsbUJBQW1Cd0MsUUFBUTtBQUN4RCxHQUNBO0FBQUEsRUFDRVYsS0FBSzlCLG1CQUFtQnlDLFlBQVlsQixTQUFTO0FBQUEsRUFDN0NTLE1BQU05QixxQkFBcUJGLG1CQUFtQnlDLFdBQVc7QUFDM0QsR0FDQTtBQUFBLEVBQ0VYLEtBQUs5QixtQkFBbUIwQyxhQUFhbkIsU0FBUztBQUFBLEVBQzlDUyxNQUFNOUIscUJBQXFCRixtQkFBbUIwQyxZQUFZO0FBQzVELEdBQ0E7QUFBQSxFQUNFWixLQUFLOUIsbUJBQW1CMkMsUUFBUXBCLFNBQVM7QUFBQSxFQUN6Q1MsTUFBTTlCLHFCQUFxQkYsbUJBQW1CMkMsT0FBTztBQUN2RCxHQUNBO0FBQUEsRUFDRWIsS0FBSzlCLG1CQUFtQjRDLGFBQWFyQixTQUFTO0FBQUEsRUFDOUNTLE1BQU05QixxQkFBcUJGLG1CQUFtQjRDLFlBQVk7QUFDNUQsR0FDQTtBQUFBLEVBQ0VkLEtBQUs5QixtQkFBbUI2QyxlQUFldEIsU0FBUztBQUFBLEVBQ2hEUyxNQUFNOUIscUJBQXFCRixtQkFBbUI2QyxjQUFjO0FBQzlELENBQUM7QUFHSCxNQUFNMUIsWUFBWUEsTUFBTTtBQUFBMkIsTUFBQTtBQUN0QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBUSxJQUFJOUMsU0FBUztBQUU3QixRQUFNd0IsZUFBZWhDLGVBQWU7QUFBQSxJQUNsQ2lDLFNBQVM7QUFBQSxNQUNQc0IsU0FBUztBQUFBLE1BQ1RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxXQUFXO0FBQUEsTUFDWEMsV0FBVztBQUFBLFFBQ1QseUJBQXlCO0FBQUEsVUFDdkJDLGFBQWFMLFFBQVFNO0FBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFFRCxTQUFPO0FBQUEsSUFDTDVCO0FBQUFBLEVBQ0Y7QUFDRjtBQUFDcUIsSUFuQkszQixXQUFTO0FBQUEsVUFDT2xCLFFBQVE7QUFBQTtBQW9COUIsZUFBZU87QUFBeUIsSUFBQXFCO0FBQUF5QixhQUFBekIsSUFBQSIsIm5hbWVzIjpbIm1lcmdlU3R5bGVTZXRzIiwidXNlQ2FsbGJhY2siLCJDaG9pY2VHcm91cCIsIkRlZmF1bHRCdXR0b24iLCJNb2RhbCIsIlByaW1hcnlCdXR0b24iLCJUZXh0RmllbGQiLCJBdWRpdFNpdHVhdGlvbkVudW0iLCJ1c2VUaGVtZSIsIkF1ZGl0U2l0dWF0aW9uUmVjb3JkIiwiVEVYVEZJRUxEX1ZBUlMiLCJjb2xzIiwibWF4Q2hhcnMiLCJyZXNpemVhYmxlIiwiTU9EQUxfV0lEVEgiLCJBdWRpdENoYW5nZVNpdHVhdGlvbk1vZGFsIiwicHJvcHMiLCJfcyIsIm9uRGlzbWlzcyIsImlzT3BlbiIsImZvcm1EYXRhIiwib25DaGFuZ2VTaXR1YXRpb24iLCJvblRleHRDaGFuZ2UiLCJzYXZlQ2hhbmdlcyIsImlzTG9hZGluZyIsInN0eWxlcyIsInVzZVN0eWxlcyIsImhhbmRsZVNhdmVDbGljayIsImNob2ljZU9wdGlvbnMiLCJzaXR1YWNhbyIsInRvU3RyaW5nIiwianVzdGlmaWNhdGl2YVNpdHVhY2FvIiwiYWN0aW9uU3R5bGVzIiwiYWN0aW9ucyIsInRyaW0iLCJsZW5ndGgiLCJfYyIsImtleSIsIkVtQW5kYW1lbnRvIiwidGV4dCIsIkVtU29saWNpdGFjYW8iLCJFbUxldmFudGFtZW50byIsIkNvbmZlcmVuY2lhIiwiQXByZXNlbnRhY2FvIiwiUmVjb3JyZW50ZSIsIkltcGxlbWVudGFjYW8iLCJGYXR1cmFtZW50byIsIkFJbmljaWFyIiwiUmVzdGl0dWljYW8iLCJBY2FvSnVkaWNpYWwiLCJTdGFuZEJ5IiwiUGxhbmVqYW1lbnRvIiwiQWNvbXBhbmhhbWVudG8iLCJfczIiLCJzcGFjaW5nIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwibWFyZ2luVG9wIiwic2VsZWN0b3JzIiwibWFyZ2luUmlnaHQiLCJsZyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkF1ZGl0Q2hhbmdlU2l0dWF0aW9uTW9kYWwudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cy9BdWRpdENoYW5nZVNpdHVhdGlvbk1vZGFsLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElDaG9pY2VHcm91cE9wdGlvbiwgbWVyZ2VTdHlsZVNldHMgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCBGb3JtRXZlbnQsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBBdWRpdCBmcm9tICcuLi8uLi8uLi8uLi9kb21haW4vQXVkaXQnXHJcbmltcG9ydCB7IENob2ljZUdyb3VwLCBEZWZhdWx0QnV0dG9uLCBNb2RhbCwgTW9kYWxQcm9wcywgUHJpbWFyeUJ1dHRvbiwgVGV4dEZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5pbXBvcnQgeyBBdWRpdFNpdHVhdGlvblJlY29yZCB9IGZyb20gJy4uLy4uLy4uLy4uL3NoYXJlZC9yZWNvcmQvQXVkaXRTaXR1YXRpb25SZWNvcmQnXHJcblxyXG5pbnRlcmZhY2UgQXVkaXRDaGFuZ2VTaXR1YXRpb25Nb2RhbFByb3BzIGV4dGVuZHMgTW9kYWxQcm9wcyB7XHJcbiAgZm9ybURhdGE6IEF1ZGl0XHJcbiAgb25DaGFuZ2VTaXR1YXRpb246IChfZXY/OiBGb3JtRXZlbnQ8SFRNTEVsZW1lbnQgfCBIVE1MSW5wdXRFbGVtZW50Piwgb3B0aW9uPzogSUNob2ljZUdyb3VwT3B0aW9uKSA9PiB2b2lkXHJcbiAgb25UZXh0Q2hhbmdlOiAoXz86IHVua25vd24sIHZhbHVlPzogc3RyaW5nIHwgdW5kZWZpbmVkKSA9PiB2b2lkXHJcbiAgc2F2ZUNoYW5nZXM6IChkYXRhPzogQXVkaXQpID0+IFByb21pc2U8dm9pZD5cclxuICBpc0xvYWRpbmc6IGJvb2xlYW5cclxufVxyXG5cclxuY29uc3QgVEVYVEZJRUxEX1ZBUlMgPSB7XHJcbiAgY29sczogNSxcclxuICBtYXhDaGFyczogMjAwLFxyXG4gIHJlc2l6ZWFibGU6IGZhbHNlLFxyXG59IGFzIGNvbnN0XHJcblxyXG5jb25zdCBNT0RBTF9XSURUSCA9IDQyNFxyXG5cclxuY29uc3QgQXVkaXRDaGFuZ2VTaXR1YXRpb25Nb2RhbDogRkM8QXVkaXRDaGFuZ2VTaXR1YXRpb25Nb2RhbFByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIG9uRGlzbWlzcyxcclxuICAgIGlzT3BlbixcclxuICAgIGZvcm1EYXRhLFxyXG4gICAgb25DaGFuZ2VTaXR1YXRpb24sXHJcbiAgICBvblRleHRDaGFuZ2UsXHJcbiAgICBzYXZlQ2hhbmdlcyxcclxuICAgIGlzTG9hZGluZyxcclxuICB9ID0gcHJvcHNcclxuICBjb25zdCBzdHlsZXMgPSB1c2VTdHlsZXMoKVxyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlQ2xpY2sgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzYXZlQ2hhbmdlcyhmb3JtRGF0YSlcclxuICAgIG9uRGlzbWlzcygpXHJcbiAgfSwgW2Zvcm1EYXRhLCBvbkRpc21pc3NdKVxyXG4gIHJldHVybiAoXHJcbiAgICA8TW9kYWxcclxuICAgICAgb25EaXNtaXNzPXtvbkRpc21pc3N9XHJcbiAgICAgIGlzT3Blbj17aXNPcGVufVxyXG4gICAgICB0aXRsZT0nQWx0ZXJhciBzaXR1YcOnw6NvJ1xyXG4gICAgICB3aWR0aD17TU9EQUxfV0lEVEh9XHJcbiAgICA+XHJcbiAgICAgIDxDaG9pY2VHcm91cFxyXG4gICAgICAgIG9wdGlvbnM9e2Nob2ljZU9wdGlvbnN9XHJcbiAgICAgICAgb25DaGFuZ2U9e29uQ2hhbmdlU2l0dWF0aW9ufVxyXG4gICAgICAgIHNlbGVjdGVkS2V5PXtmb3JtRGF0YS5zaXR1YWNhbz8udG9TdHJpbmcoKX1cclxuICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAvPlxyXG4gICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgbGFiZWw9J0p1c3RpZmljYXRpdmEnXHJcbiAgICAgICAgbWF4TGVuZ3RoPXtURVhURklFTERfVkFSUy5tYXhDaGFyc31cclxuICAgICAgICBtdWx0aWxpbmVcclxuICAgICAgICBjb2xzPXtURVhURklFTERfVkFSUy5jb2xzfVxyXG4gICAgICAgIHJlc2l6YWJsZT17VEVYVEZJRUxEX1ZBUlMucmVzaXplYWJsZX1cclxuICAgICAgICB2YWx1ZT17Zm9ybURhdGEuanVzdGlmaWNhdGl2YVNpdHVhY2FvfVxyXG4gICAgICAgIG9uQ2hhbmdlPXtvblRleHRDaGFuZ2V9XHJcbiAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cclxuICAgICAgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5hY3Rpb25TdHlsZXMuYWN0aW9uc30+XHJcbiAgICAgICAgPERlZmF1bHRCdXR0b25cclxuICAgICAgICAgIHRleHQ9J0NhbmNlbGFyJ1xyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25EaXNtaXNzKCl9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8UHJpbWFyeUJ1dHRvblxyXG4gICAgICAgICAgdGV4dD0nU2FsdmFyJ1xyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUNsaWNrfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZyB8fCBmb3JtRGF0YS5qdXN0aWZpY2F0aXZhU2l0dWFjYW8/LnRyaW0oKS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L01vZGFsPlxyXG4gIClcclxufVxyXG5cclxuY29uc3QgY2hvaWNlT3B0aW9uczogSUNob2ljZUdyb3VwT3B0aW9uW10gPSBbXHJcbiAge1xyXG4gICAga2V5OiBBdWRpdFNpdHVhdGlvbkVudW0uRW1BbmRhbWVudG8udG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5FbUFuZGFtZW50b10sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IEF1ZGl0U2l0dWF0aW9uRW51bS5FbVNvbGljaXRhY2FvLnRvU3RyaW5nKCksXHJcbiAgICB0ZXh0OiBBdWRpdFNpdHVhdGlvblJlY29yZFtBdWRpdFNpdHVhdGlvbkVudW0uRW1Tb2xpY2l0YWNhb10sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IEF1ZGl0U2l0dWF0aW9uRW51bS5FbUxldmFudGFtZW50by50b1N0cmluZygpLFxyXG4gICAgdGV4dDogQXVkaXRTaXR1YXRpb25SZWNvcmRbQXVkaXRTaXR1YXRpb25FbnVtLkVtTGV2YW50YW1lbnRvXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogQXVkaXRTaXR1YXRpb25FbnVtLkNvbmZlcmVuY2lhLnRvU3RyaW5nKCksXHJcbiAgICB0ZXh0OiBBdWRpdFNpdHVhdGlvblJlY29yZFtBdWRpdFNpdHVhdGlvbkVudW0uQ29uZmVyZW5jaWFdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAga2V5OiBBdWRpdFNpdHVhdGlvbkVudW0uQXByZXNlbnRhY2FvLnRvU3RyaW5nKCksXHJcbiAgICB0ZXh0OiBBdWRpdFNpdHVhdGlvblJlY29yZFtBdWRpdFNpdHVhdGlvbkVudW0uQXByZXNlbnRhY2FvXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogQXVkaXRTaXR1YXRpb25FbnVtLlJlY29ycmVudGUudG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5SZWNvcnJlbnRlXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogQXVkaXRTaXR1YXRpb25FbnVtLkltcGxlbWVudGFjYW8udG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5JbXBsZW1lbnRhY2FvXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogQXVkaXRTaXR1YXRpb25FbnVtLkZhdHVyYW1lbnRvLnRvU3RyaW5nKCksXHJcbiAgICB0ZXh0OiBBdWRpdFNpdHVhdGlvblJlY29yZFtBdWRpdFNpdHVhdGlvbkVudW0uRmF0dXJhbWVudG9dLFxyXG4gIH0sXHJcbiAge1xyXG4gICAga2V5OiBBdWRpdFNpdHVhdGlvbkVudW0uQUluaWNpYXIudG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5BSW5pY2lhcl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IEF1ZGl0U2l0dWF0aW9uRW51bS5SZXN0aXR1aWNhby50b1N0cmluZygpLFxyXG4gICAgdGV4dDogQXVkaXRTaXR1YXRpb25SZWNvcmRbQXVkaXRTaXR1YXRpb25FbnVtLlJlc3RpdHVpY2FvXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGtleTogQXVkaXRTaXR1YXRpb25FbnVtLkFjYW9KdWRpY2lhbC50b1N0cmluZygpLFxyXG4gICAgdGV4dDogQXVkaXRTaXR1YXRpb25SZWNvcmRbQXVkaXRTaXR1YXRpb25FbnVtLkFjYW9KdWRpY2lhbF0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IEF1ZGl0U2l0dWF0aW9uRW51bS5TdGFuZEJ5LnRvU3RyaW5nKCksXHJcbiAgICB0ZXh0OiBBdWRpdFNpdHVhdGlvblJlY29yZFtBdWRpdFNpdHVhdGlvbkVudW0uU3RhbmRCeV0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IEF1ZGl0U2l0dWF0aW9uRW51bS5QbGFuZWphbWVudG8udG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5QbGFuZWphbWVudG9dLFxyXG4gIH0sXHJcbiAge1xyXG4gICAga2V5OiBBdWRpdFNpdHVhdGlvbkVudW0uQWNvbXBhbmhhbWVudG8udG9TdHJpbmcoKSxcclxuICAgIHRleHQ6IEF1ZGl0U2l0dWF0aW9uUmVjb3JkW0F1ZGl0U2l0dWF0aW9uRW51bS5BY29tcGFuaGFtZW50b10sXHJcbiAgfSxcclxuXVxyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc3BhY2luZyB9ID0gdXNlVGhlbWUoKVxyXG5cclxuICBjb25zdCBhY3Rpb25TdHlsZXMgPSBtZXJnZVN0eWxlU2V0cyh7XHJcbiAgICBhY3Rpb25zOiB7XHJcbiAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCcsXHJcbiAgICAgIG1hcmdpblRvcDogNDAsXHJcbiAgICAgIHNlbGVjdG9yczoge1xyXG4gICAgICAgICcmID4gOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICBtYXJnaW5SaWdodDogc3BhY2luZy5sZyxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgYWN0aW9uU3R5bGVzLFxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVkaXRDaGFuZ2VTaXR1YXRpb25Nb2RhbFxyXG4iXX0=