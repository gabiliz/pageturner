import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/users/components/UserAvatar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyleSets, Icon } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { useTheme } from "/src/shared/hooks/index.ts";
const BASE64_URL = "data:image/*;base64,";
const UserAvatar = (props) => {
  _s();
  const {
    image
  } = props;
  const [imageUrl, setImageUrl] = useState(image ? `${BASE64_URL}${image}` : "");
  const avatarStyles = useAvatarStyles(props);
  useEffect(() => {
    setImageUrl(`${BASE64_URL}${image}`);
  }, [image]);
  return /* @__PURE__ */ jsxDEV("div", { className: avatarStyles.avatar, children: image ? /* @__PURE__ */ jsxDEV("img", { src: imageUrl }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatar.tsx",
    lineNumber: 23,
    columnNumber: 16
  }, this) : /* @__PURE__ */ jsxDEV(Icon, { iconName: "Contact" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatar.tsx",
    lineNumber: 23,
    columnNumber: 41
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatar.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(UserAvatar, "95Rp0G7aYuw7n4CNhbxzEWtr6lA=", false, function() {
  return [useAvatarStyles];
});
_c = UserAvatar;
const useAvatarStyles = (props) => {
  _s2();
  const theme = useTheme();
  return mergeStyleSets({
    avatar: {
      width: props.size ?? "40px",
      height: props.size ?? "40px",
      borderRadius: "50%",
      backgroundColor: theme.colors.purple[300],
      color: theme.colors.gray[100],
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: props.fontSize ?? theme.fontSize.p16,
      overflow: "hidden",
      "& > img": {
        width: "100%",
        height: "100%",
        objectFit: "cover"
      }
    }
  });
};
_s2(useAvatarStyles, "VrMvFCCB9Haniz3VCRPNUiCauHs=", false, function() {
  return [useTheme];
});
export default UserAvatar;
var _c;
$RefreshReg$(_c, "UserAvatar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/users/components/UserAvatar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBekJWLFNBQVNBLGdCQUFnQkMsWUFBWTtBQUNyQyxTQUFhQyxVQUFVQyxpQkFBaUI7QUFDeEMsU0FBU0MsZ0JBQWdCO0FBUXpCLE1BQU1DLGFBQWE7QUFFbkIsTUFBTUMsYUFBOEJBLENBQUNDLFVBQXVCO0FBQUFDLEtBQUE7QUFDMUQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU0sSUFBSUY7QUFFbEIsUUFBTSxDQUFDRyxVQUFVQyxXQUFXLElBQUlULFNBQVNPLFFBQVMsR0FBRUosYUFBYUksVUFBVSxFQUFFO0FBQzdFLFFBQU1HLGVBQWVDLGdCQUFnQk4sS0FBSztBQUUxQ0osWUFBVSxNQUFNO0FBQ2RRLGdCQUFhLEdBQUVOLGFBQWFJLE9BQU87QUFBQSxFQUNyQyxHQUFHLENBQUNBLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsU0FBSSxXQUFXRyxhQUFhRSxRQUMxQkwsa0JBQ0csdUJBQUMsU0FBSSxLQUFLQyxZQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUIsSUFDbkIsdUJBQUMsUUFBSyxVQUFTLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QixLQUg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDRixHQWxCS0YsWUFBMkI7QUFBQSxVQUlWTyxlQUFlO0FBQUE7QUFBQUUsS0FKaENUO0FBb0JOLE1BQU1PLGtCQUFrQkEsQ0FBQ04sVUFBdUI7QUFBQVMsTUFBQTtBQUM5QyxRQUFNQyxRQUFRYixTQUFTO0FBRXZCLFNBQU9KLGVBQWU7QUFBQSxJQUNwQmMsUUFBUTtBQUFBLE1BQ05JLE9BQU9YLE1BQU1ZLFFBQVE7QUFBQSxNQUNyQkMsUUFBUWIsTUFBTVksUUFBUTtBQUFBLE1BQ3RCRSxjQUFjO0FBQUEsTUFDZEMsaUJBQWlCTCxNQUFNTSxPQUFPQyxPQUFPLEdBQUc7QUFBQSxNQUN4Q0MsT0FBT1IsTUFBTU0sT0FBT0csS0FBSyxHQUFHO0FBQUEsTUFDNUJDLFNBQVM7QUFBQSxNQUNUQyxZQUFZO0FBQUEsTUFDWkMsZ0JBQWdCO0FBQUEsTUFDaEJDLFVBQVV2QixNQUFNdUIsWUFBWWIsTUFBTWEsU0FBU0M7QUFBQUEsTUFDM0NDLFVBQVU7QUFBQSxNQUNWLFdBQVc7QUFBQSxRQUNUZCxPQUFPO0FBQUEsUUFDUEUsUUFBUTtBQUFBLFFBQ1JhLFdBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQUNqQixJQXRCS0gsaUJBQWU7QUFBQSxVQUNMVCxRQUFRO0FBQUE7QUF1QnhCLGVBQWVFO0FBQVUsSUFBQVM7QUFBQW1CLGFBQUFuQixJQUFBIiwibmFtZXMiOlsibWVyZ2VTdHlsZVNldHMiLCJJY29uIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VUaGVtZSIsIkJBU0U2NF9VUkwiLCJVc2VyQXZhdGFyIiwicHJvcHMiLCJfcyIsImltYWdlIiwiaW1hZ2VVcmwiLCJzZXRJbWFnZVVybCIsImF2YXRhclN0eWxlcyIsInVzZUF2YXRhclN0eWxlcyIsImF2YXRhciIsIl9jIiwiX3MyIiwidGhlbWUiLCJ3aWR0aCIsInNpemUiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvcnMiLCJwdXJwbGUiLCJjb2xvciIsImdyYXkiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZm9udFNpemUiLCJwMTYiLCJvdmVyZmxvdyIsIm9iamVjdEZpdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVzZXJBdmF0YXIudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hZG1pbi91c2Vycy9jb21wb25lbnRzL1VzZXJBdmF0YXIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWVyZ2VTdHlsZVNldHMsIEljb24gfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL2hvb2tzJ1xyXG5cclxuaW50ZXJmYWNlIEF2YXRhclByb3BzIHtcclxuICBpbWFnZT86IHN0cmluZyB8IG51bGxcclxuICBzaXplPzogc3RyaW5nXHJcbiAgZm9udFNpemU/OiBzdHJpbmdcclxufVxyXG5cclxuY29uc3QgQkFTRTY0X1VSTCA9ICdkYXRhOmltYWdlLyo7YmFzZTY0LCdcclxuXHJcbmNvbnN0IFVzZXJBdmF0YXI6IEZDPEF2YXRhclByb3BzPiA9IChwcm9wczogQXZhdGFyUHJvcHMpID0+IHtcclxuICBjb25zdCB7IGltYWdlIH0gPSBwcm9wc1xyXG5cclxuICBjb25zdCBbaW1hZ2VVcmwsIHNldEltYWdlVXJsXSA9IHVzZVN0YXRlKGltYWdlID8gYCR7QkFTRTY0X1VSTH0ke2ltYWdlfWAgOiAnJylcclxuICBjb25zdCBhdmF0YXJTdHlsZXMgPSB1c2VBdmF0YXJTdHlsZXMocHJvcHMpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRJbWFnZVVybChgJHtCQVNFNjRfVVJMfSR7aW1hZ2V9YClcclxuICB9LCBbaW1hZ2VdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2F2YXRhclN0eWxlcy5hdmF0YXJ9PlxyXG4gICAgICB7aW1hZ2VcclxuICAgICAgICA/IDxpbWcgc3JjPXtpbWFnZVVybH0gLz5cclxuICAgICAgICA6IDxJY29uIGljb25OYW1lPSdDb250YWN0JyAvPlxyXG4gICAgICB9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmNvbnN0IHVzZUF2YXRhclN0eWxlcyA9IChwcm9wczogQXZhdGFyUHJvcHMpID0+IHtcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKClcclxuXHJcbiAgcmV0dXJuIG1lcmdlU3R5bGVTZXRzKHtcclxuICAgIGF2YXRhcjoge1xyXG4gICAgICB3aWR0aDogcHJvcHMuc2l6ZSA/PyAnNDBweCcsXHJcbiAgICAgIGhlaWdodDogcHJvcHMuc2l6ZSA/PyAnNDBweCcsXHJcbiAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29sb3JzLnB1cnBsZVszMDBdLFxyXG4gICAgICBjb2xvcjogdGhlbWUuY29sb3JzLmdyYXlbMTAwXSxcclxuICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxyXG4gICAgICBmb250U2l6ZTogcHJvcHMuZm9udFNpemUgPz8gdGhlbWUuZm9udFNpemUucDE2LFxyXG4gICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXHJcbiAgICAgICcmID4gaW1nJzoge1xyXG4gICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgaGVpZ2h0OiAnMTAwJScsXHJcbiAgICAgICAgb2JqZWN0Rml0OiAnY292ZXInLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyQXZhdGFyXHJcbiJdfQ==