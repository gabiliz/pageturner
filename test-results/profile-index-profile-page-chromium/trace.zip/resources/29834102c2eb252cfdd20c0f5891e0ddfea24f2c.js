import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/SideMenuRoutes.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { AdminSideMenu } from "/src/modules/admin/components/index.ts?t=1701096626433";
import { AuditAnalysisSideMenu, AuditControlPanelSideMenu, AuditExecutionTestSideMenu, AuditInternalControlSideMenu, AuditPlanningSideMenu, AuditSideMenu, AuditCommunicationSideMenu, AuditExecutionTestProcessSideMenu, AuditFinancialStatementsSideMenu, AuditFinancialStatementImportSideMenu } from "/src/modules/audit/components/index.ts?t=1701096626433";
import { FiscalSideMenu } from "/src/modules/fiscal/components/index.ts?t=1701096626433";
const SideMenuRoutes = () => {
  return /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/admin/*", element: /* @__PURE__ */ jsxDEV(AdminSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 8,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/fiscal/*", element: /* @__PURE__ */ jsxDEV(FiscalSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 9,
      columnNumber: 40
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/*", element: /* @__PURE__ */ jsxDEV(AuditSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 10,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/*", element: /* @__PURE__ */ jsxDEV(AuditControlPanelSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 11,
      columnNumber: 64
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/planning/*", element: /* @__PURE__ */ jsxDEV(AuditPlanningSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 12,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/communication/*", element: /* @__PURE__ */ jsxDEV(AuditCommunicationSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 13,
      columnNumber: 78
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/analysis/*", element: /* @__PURE__ */ jsxDEV(AuditAnalysisSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 14,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/internal-control/*", element: /* @__PURE__ */ jsxDEV(AuditInternalControlSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 15,
      columnNumber: 81
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/test-process/financial-statements/*", element: /* @__PURE__ */ jsxDEV(AuditFinancialStatementsSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 16,
      columnNumber: 98
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/test-process/financial-statements/details/:financialId", element: /* @__PURE__ */ jsxDEV(AuditFinancialStatementImportSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 17,
      columnNumber: 117
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:id/control-panel/test-process/financial-statements/details/:financialId/teste", element: /* @__PURE__ */ jsxDEV(AuditFinancialStatementImportSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 18,
      columnNumber: 123
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:auditId/control-panel/analysis/:revisionType/:groupToShow/:companyId/:codeAcc/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(AuditExecutionTestSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 19,
      columnNumber: 151
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/audit/audits/:auditId/control-panel/:auditMenu/:testProcessType/tests/:visionType/:testId/*", element: /* @__PURE__ */ jsxDEV(AuditExecutionTestProcessSideMenu, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 20,
      columnNumber: 123
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
};
_c = SideMenuRoutes;
export default SideMenuRoutes;
var _c;
$RefreshReg$(_c, "SideMenuRoutes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/routes/SideMenuRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JzQztBQXBCdEMsMkJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDMUIsU0FBU0EsT0FBT0MsY0FBYztBQUM5QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FDRUMsdUJBQ0FDLDJCQUNBQyw0QkFDQUMsOEJBQ0FDLHVCQUNBQyxlQUNBQyw0QkFDQUMsbUNBQ0FDLGtDQUNBQyw2Q0FDSztBQUNQLFNBQVNDLHNCQUFzQjtBQUUvQixNQUFNQyxpQkFBcUJBLE1BQU07QUFDL0IsU0FDRSx1QkFBQyxVQUNDO0FBQUEsMkJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWMsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLElBQ2pELHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUQ7QUFBQSxJQUNuRCx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQsdUJBQUMsU0FDQyxNQUFLLHFDQUNMLFNBQVMsdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQixLQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXdDO0FBQUEsSUFFeEMsdUJBQUMsU0FDQyxNQUFLLDhDQUNMLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQixLQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRW9DO0FBQUEsSUFFcEMsdUJBQUMsU0FDQyxNQUFLLG1EQUNMLFNBQVMsdUJBQUMsZ0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQixLQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXlDO0FBQUEsSUFFekMsdUJBQUMsU0FDQyxNQUFLLDhDQUNMLFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQixLQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRW9DO0FBQUEsSUFFcEMsdUJBQUMsU0FDQyxNQUFLLHNEQUNMLFNBQVMsdUJBQUMsa0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QixLQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRTJDO0FBQUEsSUFFM0MsdUJBQUMsU0FDQyxNQUFLLHVFQUNMLFNBQVMsdUJBQUMsc0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQyxLQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWdEO0FBQUEsSUFFaEQsdUJBQUMsU0FDQyxNQUFLLDBGQUNMLFNBQVMsdUJBQUMsMkNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQyxLQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFEO0FBQUEsSUFFckQsdUJBQUMsU0FDQyxNQUFLLGdHQUNMLFNBQVMsdUJBQUMsMkNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQyxLQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXFEO0FBQUEsSUFFckQsdUJBQUMsU0FDQyxNQUFLLDRIQUNMLFNBQVMsdUJBQUMsZ0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQixLQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXlDO0FBQUEsSUFFekMsdUJBQUMsU0FDQyxNQUFLLGdHQUNMLFNBQVMsdUJBQUMsdUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQyxLQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWdEO0FBQUEsT0ExQ2xEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0Q0E7QUFFSjtBQUFDQyxLQWhES0Q7QUFrRE4sZUFBZUE7QUFBYyxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUm91dGUiLCJSb3V0ZXMiLCJBZG1pblNpZGVNZW51IiwiQXVkaXRBbmFseXNpc1NpZGVNZW51IiwiQXVkaXRDb250cm9sUGFuZWxTaWRlTWVudSIsIkF1ZGl0RXhlY3V0aW9uVGVzdFNpZGVNZW51IiwiQXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudSIsIkF1ZGl0UGxhbm5pbmdTaWRlTWVudSIsIkF1ZGl0U2lkZU1lbnUiLCJBdWRpdENvbW11bmljYXRpb25TaWRlTWVudSIsIkF1ZGl0RXhlY3V0aW9uVGVzdFByb2Nlc3NTaWRlTWVudSIsIkF1ZGl0RmluYW5jaWFsU3RhdGVtZW50c1NpZGVNZW51IiwiQXVkaXRGaW5hbmNpYWxTdGF0ZW1lbnRJbXBvcnRTaWRlTWVudSIsIkZpc2NhbFNpZGVNZW51IiwiU2lkZU1lbnVSb3V0ZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpZGVNZW51Um91dGVzLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3JvdXRlcy9TaWRlTWVudVJvdXRlcy50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUm91dGUsIFJvdXRlcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBZG1pblNpZGVNZW51IH0gZnJvbSAnLi4vbW9kdWxlcy9hZG1pbi9jb21wb25lbnRzJ1xuaW1wb3J0IHtcbiAgQXVkaXRBbmFseXNpc1NpZGVNZW51LFxuICBBdWRpdENvbnRyb2xQYW5lbFNpZGVNZW51LFxuICBBdWRpdEV4ZWN1dGlvblRlc3RTaWRlTWVudSxcbiAgQXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudSxcbiAgQXVkaXRQbGFubmluZ1NpZGVNZW51LFxuICBBdWRpdFNpZGVNZW51LFxuICBBdWRpdENvbW11bmljYXRpb25TaWRlTWVudSxcbiAgQXVkaXRFeGVjdXRpb25UZXN0UHJvY2Vzc1NpZGVNZW51LFxuICBBdWRpdEZpbmFuY2lhbFN0YXRlbWVudHNTaWRlTWVudSxcbiAgQXVkaXRGaW5hbmNpYWxTdGF0ZW1lbnRJbXBvcnRTaWRlTWVudSxcbn0gZnJvbSAnLi4vbW9kdWxlcy9hdWRpdC9jb21wb25lbnRzJ1xuaW1wb3J0IHsgRmlzY2FsU2lkZU1lbnUgfSBmcm9tICcuLi9tb2R1bGVzL2Zpc2NhbC9jb21wb25lbnRzJ1xuXG5jb25zdCBTaWRlTWVudVJvdXRlczogRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPFJvdXRlcz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2FkbWluLypcIiBlbGVtZW50PXs8QWRtaW5TaWRlTWVudS8+fS8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9maXNjYWwvKlwiIGVsZW1lbnQ9ezxGaXNjYWxTaWRlTWVudS8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXVkaXQvKlwiIGVsZW1lbnQ9ezxBdWRpdFNpZGVNZW51Lz59IC8+XG4gICAgICA8Um91dGVcbiAgICAgICAgcGF0aD1cIi9hdWRpdC9hdWRpdHMvOmlkL2NvbnRyb2wtcGFuZWwvKlwiXG4gICAgICAgIGVsZW1lbnQ9ezxBdWRpdENvbnRyb2xQYW5lbFNpZGVNZW51Lz59XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYXVkaXQvYXVkaXRzLzppZC9jb250cm9sLXBhbmVsL3BsYW5uaW5nLypcIlxuICAgICAgICBlbGVtZW50PXs8QXVkaXRQbGFubmluZ1NpZGVNZW51Lz59XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYXVkaXQvYXVkaXRzLzppZC9jb250cm9sLXBhbmVsL2NvbW11bmljYXRpb24vKlwiXG4gICAgICAgIGVsZW1lbnQ9ezxBdWRpdENvbW11bmljYXRpb25TaWRlTWVudS8+fVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2F1ZGl0L2F1ZGl0cy86aWQvY29udHJvbC1wYW5lbC9hbmFseXNpcy8qXCJcbiAgICAgICAgZWxlbWVudD17PEF1ZGl0QW5hbHlzaXNTaWRlTWVudS8+fVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2F1ZGl0L2F1ZGl0cy86aWQvY29udHJvbC1wYW5lbC9pbnRlcm5hbC1jb250cm9sLypcIlxuICAgICAgICBlbGVtZW50PXs8QXVkaXRJbnRlcm5hbENvbnRyb2xTaWRlTWVudS8+fVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2F1ZGl0L2F1ZGl0cy86aWQvY29udHJvbC1wYW5lbC90ZXN0LXByb2Nlc3MvZmluYW5jaWFsLXN0YXRlbWVudHMvKlwiXG4gICAgICAgIGVsZW1lbnQ9ezxBdWRpdEZpbmFuY2lhbFN0YXRlbWVudHNTaWRlTWVudSAvPn1cbiAgICAgIC8+XG4gICAgICA8Um91dGVcbiAgICAgICAgcGF0aD1cIi9hdWRpdC9hdWRpdHMvOmlkL2NvbnRyb2wtcGFuZWwvdGVzdC1wcm9jZXNzL2ZpbmFuY2lhbC1zdGF0ZW1lbnRzL2RldGFpbHMvOmZpbmFuY2lhbElkXCJcbiAgICAgICAgZWxlbWVudD17PEF1ZGl0RmluYW5jaWFsU3RhdGVtZW50SW1wb3J0U2lkZU1lbnUgLz59XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYXVkaXQvYXVkaXRzLzppZC9jb250cm9sLXBhbmVsL3Rlc3QtcHJvY2Vzcy9maW5hbmNpYWwtc3RhdGVtZW50cy9kZXRhaWxzLzpmaW5hbmNpYWxJZC90ZXN0ZVwiXG4gICAgICAgIGVsZW1lbnQ9ezxBdWRpdEZpbmFuY2lhbFN0YXRlbWVudEltcG9ydFNpZGVNZW51IC8+fVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2F1ZGl0L2F1ZGl0cy86YXVkaXRJZC9jb250cm9sLXBhbmVsL2FuYWx5c2lzLzpyZXZpc2lvblR5cGUvOmdyb3VwVG9TaG93Lzpjb21wYW55SWQvOmNvZGVBY2MvdGVzdHMvOnZpc2lvblR5cGUvOnRlc3RJZC8qXCJcbiAgICAgICAgZWxlbWVudD17PEF1ZGl0RXhlY3V0aW9uVGVzdFNpZGVNZW51Lz59XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYXVkaXQvYXVkaXRzLzphdWRpdElkL2NvbnRyb2wtcGFuZWwvOmF1ZGl0TWVudS86dGVzdFByb2Nlc3NUeXBlL3Rlc3RzLzp2aXNpb25UeXBlLzp0ZXN0SWQvKlwiXG4gICAgICAgIGVsZW1lbnQ9ezxBdWRpdEV4ZWN1dGlvblRlc3RQcm9jZXNzU2lkZU1lbnUvPn1cbiAgICAgIC8+XG4gICAgPC9Sb3V0ZXM+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2lkZU1lbnVSb3V0ZXNcbiJdfQ==