import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/primefaces-override.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/gabiliz/Documents/auditor_frontend/src/primefaces-override.css"
const __vite__css = ".p-tree {\r\n  border: none;\r\n  padding: 0;\r\n}\r\n\r\n.p-checkbox\r\n.p-checkbox-box.p-highlight {\r\n  background: #402560;\r\n  border-color: #402560;\r\n}\r\n\r\n.p-checkbox:not(.p-checkbox-disabled)\r\n.p-checkbox-box.p-highlight:hover {\r\n  background: #703FAB;\r\n  border-color: #703FAB;\r\n}\r\n\r\n.p-chips\r\n.p-chips-multiple-container:not(.p-disabled).p-focus {\r\n  box-shadow: inset 0 0 0 1px #77B5F1;\r\n  border-color: #77B5F1;\r\n}\r\n\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))