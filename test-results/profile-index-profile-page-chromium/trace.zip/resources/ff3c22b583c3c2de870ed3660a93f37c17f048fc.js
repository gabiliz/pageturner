import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/providers/index.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { BrowserRouter as Router } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { ThemeProvider as StyledThemeProvider } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
import { GlobalStyle } from "/src/shared/style/global.ts";
import { defaultTheme } from "/src/shared/style/theme/default.ts";
import FluentThemeProvider from "/src/shared/providers/FluentThemeProvider.tsx";
import QueryProvider from "/src/shared/providers/QueryProvider.tsx";
import ReduxProvider from "/src/shared/providers/ReduxProvider.tsx";
const AppProvider = ({
  children
}) => {
  return /* @__PURE__ */ jsxDEV(ReduxProvider, { children: /* @__PURE__ */ jsxDEV(QueryProvider, { children: /* @__PURE__ */ jsxDEV(FluentThemeProvider, { children: /* @__PURE__ */ jsxDEV(StyledThemeProvider, { theme: defaultTheme, children: [
    /* @__PURE__ */ jsxDEV(Router, { children }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
      lineNumber: 16,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(GlobalStyle, {}, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
      lineNumber: 19,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
    lineNumber: 15,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
    lineNumber: 14,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_c = AppProvider;
export { AppProvider };
var _c;
$RefreshReg$(_c, "AppProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/providers/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVk7QUFmWiwyQkFBYUE7QUFBZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDN0MsU0FBU0MsaUJBQWlCQyxjQUFjO0FBQ3hDLFNBQVNDLGlCQUFpQkMsMkJBQTJCO0FBQ3JELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxtQkFBbUI7QUFFMUIsTUFBTUMsY0FBMkRBLENBQUM7QUFBQSxFQUFFQztBQUFTLE1BQU07QUFDakYsU0FDRSx1QkFBQyxpQkFDQyxpQ0FBQyxpQkFDQyxpQ0FBQyx1QkFDQyxpQ0FBQyx1QkFBb0IsT0FBT0wsY0FDMUI7QUFBQSwyQkFBQyxVQUNFSyxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsT0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDQyxLQWZLRjtBQWlCTixTQUFTQTtBQUFhLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQcm9wc1dpdGhDaGlsZHJlbiIsIkJyb3dzZXJSb3V0ZXIiLCJSb3V0ZXIiLCJUaGVtZVByb3ZpZGVyIiwiU3R5bGVkVGhlbWVQcm92aWRlciIsIkdsb2JhbFN0eWxlIiwiZGVmYXVsdFRoZW1lIiwiRmx1ZW50VGhlbWVQcm92aWRlciIsIlF1ZXJ5UHJvdmlkZXIiLCJSZWR1eFByb3ZpZGVyIiwiQXBwUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL3Byb3ZpZGVycy9pbmRleC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQywgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBUaGVtZVByb3ZpZGVyIGFzIFN0eWxlZFRoZW1lUHJvdmlkZXIgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IHsgR2xvYmFsU3R5bGUgfSBmcm9tICcuLi9zdHlsZS9nbG9iYWwnXHJcbmltcG9ydCB7IGRlZmF1bHRUaGVtZSB9IGZyb20gJy4uL3N0eWxlL3RoZW1lL2RlZmF1bHQnXHJcbmltcG9ydCBGbHVlbnRUaGVtZVByb3ZpZGVyIGZyb20gJy4vRmx1ZW50VGhlbWVQcm92aWRlcidcclxuaW1wb3J0IFF1ZXJ5UHJvdmlkZXIgZnJvbSAnLi9RdWVyeVByb3ZpZGVyJ1xyXG5pbXBvcnQgUmVkdXhQcm92aWRlciBmcm9tICcuL1JlZHV4UHJvdmlkZXInXHJcblxyXG5jb25zdCBBcHBQcm92aWRlcjogRkM8UHJvcHNXaXRoQ2hpbGRyZW48UmVjb3JkPG5ldmVyLCBuZXZlcj4+PiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPFJlZHV4UHJvdmlkZXI+XHJcbiAgICAgIDxRdWVyeVByb3ZpZGVyPlxyXG4gICAgICAgIDxGbHVlbnRUaGVtZVByb3ZpZGVyPlxyXG4gICAgICAgICAgPFN0eWxlZFRoZW1lUHJvdmlkZXIgdGhlbWU9e2RlZmF1bHRUaGVtZX0+XHJcbiAgICAgICAgICAgIDxSb3V0ZXI+XHJcbiAgICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgICAgICA8L1JvdXRlcj5cclxuICAgICAgICAgICAgPEdsb2JhbFN0eWxlIC8+XHJcbiAgICAgICAgICA8L1N0eWxlZFRoZW1lUHJvdmlkZXI+XHJcbiAgICAgICAgPC8gRmx1ZW50VGhlbWVQcm92aWRlcj5cclxuICAgICAgPC9RdWVyeVByb3ZpZGVyPlxyXG4gICAgPC8gUmVkdXhQcm92aWRlcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCB7IEFwcFByb3ZpZGVyIH1cclxuIl19