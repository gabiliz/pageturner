import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractListActions.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractListActions.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { CommandButton, PrimaryButton } from "/src/shared/components/index.ts?t=1701096626433";
const ContractListActions = (props) => {
  const {
    disabledRemoveButton,
    onAddClick,
    onRemoveClick,
    deletePermission,
    createPermission
  } = props;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    createPermission && /* @__PURE__ */ jsxDEV(PrimaryButton, { iconProps: {
      iconName: "Add",
      style: {
        fontSize: 14
      }
    }, text: "Adicionar", onClick: onAddClick }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractListActions.tsx",
      lineNumber: 19,
      columnNumber: 26
    }, this),
    deletePermission && /* @__PURE__ */ jsxDEV(CommandButton, { iconProps: {
      iconName: "Trash",
      style: {
        fontSize: 14
      }
    }, text: "Excluir", disabled: disabledRemoveButton, onClick: onRemoveClick }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractListActions.tsx",
      lineNumber: 25,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractListActions.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = ContractListActions;
export default ContractListActions;
var _c;
$RefreshReg$(_c, "ContractListActions");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractListActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJTLG1CQUNnQixjQURoQjtBQW5CVCwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixTQUFTQSxlQUFlQyxxQkFBcUI7QUFVN0MsTUFBTUMsc0JBQW9EQSxDQUFDQyxVQUFvQztBQUM3RixRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJTDtBQUNKLFNBQU8sbUNBQ0pLO0FBQUFBLHdCQUFvQix1QkFBQyxpQkFDcEIsV0FBVztBQUFBLE1BQUVDLFVBQVU7QUFBQSxNQUFPQyxPQUFPO0FBQUEsUUFBRUMsVUFBVTtBQUFBLE1BQUc7QUFBQSxJQUFFLEdBQ3RELE1BQUssYUFDTCxTQUFTTixjQUhVO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQztBQUFBLElBRXJCRSxvQkFBb0IsdUJBQUMsaUJBQ3BCLFdBQVc7QUFBQSxNQUFFRSxVQUFVO0FBQUEsTUFBU0MsT0FBTztBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFHO0FBQUEsSUFBRSxHQUN4RCxNQUFLLFdBQ0wsVUFBVVAsc0JBQ1YsU0FBU0UsaUJBSlU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlJO0FBQUEsT0FWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlQO0FBQ0Y7QUFBQ00sS0FyQktWO0FBdUJOLGVBQWVBO0FBQW1CLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb21tYW5kQnV0dG9uIiwiUHJpbWFyeUJ1dHRvbiIsIkNvbnRyYWN0TGlzdEFjdGlvbnMiLCJwcm9wcyIsImRpc2FibGVkUmVtb3ZlQnV0dG9uIiwib25BZGRDbGljayIsIm9uUmVtb3ZlQ2xpY2siLCJkZWxldGVQZXJtaXNzaW9uIiwiY3JlYXRlUGVybWlzc2lvbiIsImljb25OYW1lIiwic3R5bGUiLCJmb250U2l6ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJhY3RMaXN0QWN0aW9ucy50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0TGlzdEFjdGlvbnMudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENvbW1hbmRCdXR0b24sIFByaW1hcnlCdXR0b24gfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcblxuaW50ZXJmYWNlIENvbnRyYWN0TGlzdEFjdGlvbnNQcm9wcyB7XG4gIGRpc2FibGVkUmVtb3ZlQnV0dG9uOiBib29sZWFuXG4gIG9uQWRkQ2xpY2s6ICgpID0+IHZvaWRcbiAgb25SZW1vdmVDbGljazogKCkgPT4gdm9pZFxuICBkZWxldGVQZXJtaXNzaW9uOiBib29sZWFuXG4gIGNyZWF0ZVBlcm1pc3Npb246IGJvb2xlYW5cbn1cblxuY29uc3QgQ29udHJhY3RMaXN0QWN0aW9uczogRkM8Q29udHJhY3RMaXN0QWN0aW9uc1Byb3BzPiA9IChwcm9wczogQ29udHJhY3RMaXN0QWN0aW9uc1Byb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBkaXNhYmxlZFJlbW92ZUJ1dHRvbixcbiAgICBvbkFkZENsaWNrLFxuICAgIG9uUmVtb3ZlQ2xpY2ssXG4gICAgZGVsZXRlUGVybWlzc2lvbixcbiAgICBjcmVhdGVQZXJtaXNzaW9uLFxuICB9ID0gcHJvcHNcbiAgcmV0dXJuIDw+XG4gICAge2NyZWF0ZVBlcm1pc3Npb24gJiYgPFByaW1hcnlCdXR0b25cbiAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ0FkZCcsIHN0eWxlOiB7IGZvbnRTaXplOiAxNCB9IH19XG4gICAgICB0ZXh0PVwiQWRpY2lvbmFyXCJcbiAgICAgIG9uQ2xpY2s9e29uQWRkQ2xpY2t9XG4gICAgLz59XG4gICAge2RlbGV0ZVBlcm1pc3Npb24gJiYgPENvbW1hbmRCdXR0b25cbiAgICAgIGljb25Qcm9wcz17eyBpY29uTmFtZTogJ1RyYXNoJywgc3R5bGU6IHsgZm9udFNpemU6IDE0IH0gfX1cbiAgICAgIHRleHQ9XCJFeGNsdWlyXCJcbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZFJlbW92ZUJ1dHRvbn1cbiAgICAgIG9uQ2xpY2s9e29uUmVtb3ZlQ2xpY2t9XG4gICAgLz59XG4gIDwvPlxufVxuXG5leHBvcnQgZGVmYXVsdCBDb250cmFjdExpc3RBY3Rpb25zXG4iXX0=