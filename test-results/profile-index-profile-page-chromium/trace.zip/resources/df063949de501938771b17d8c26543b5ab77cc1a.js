import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/components/AuditCommunicationSideMenu.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditCommunicationSideMenu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Text } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useLocation, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9f90a7ff";
import { Link, SideMenu } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import getSelectedKeyFromNavLinks from "/src/shared/utils/getSelectedKeyFromNavLinks.ts";
import { usePermissions } from "/src/modules/auth/hooks/permissions.ts";
import { auditQueryService } from "/src/modules/audit/audits/services/index.ts";
import { AuditSituationEnum } from "/src/shared/enums/AuditSituationEnum.ts";
const AuditCommunicationSideMenu = () => {
  _s();
  const navigate = useNavigate();
  const {
    pathname
  } = useLocation();
  const {
    hasPermission
  } = usePermissions();
  const {
    colors,
    spacing,
    fontWeight,
    fontSize
  } = useTheme();
  const [disableTabs, setDisableTabs] = useState(false);
  const [isGroupExpanded, setIsGroupExpanded] = useState(false);
  const {
    id: auditId
  } = useParams();
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  const path = `/audit/audits/${auditId}/control-panel/communication`;
  const navLinkGroups = useMemo(() => [{
    links: [{
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "BIDashboard",
      key: "adjustment-ballot",
      title: "Cédula de ajuste",
      name: "Cédula de ajuste",
      permission: "Auditoria",
      url: `${path}/adjustment-ballot`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "CalendarDay",
      key: "meeting-minutes",
      title: "Minuta de reunião",
      name: "Minuta de reunião",
      permission: "Auditoria",
      url: `${path}/meeting-minutes`
    }, {
      disabled: audit?.situacao === AuditSituationEnum.Cancelado,
      icon: "Communications",
      key: "team-comms",
      title: "Comunicação com a equipe",
      name: "Comunicação com a equipe",
      permission: "Auditoria",
      url: `${path}/team-comms`
    }]
  }], [disableTabs, isGroupExpanded]);
  const permissionNav = useMemo(() => {
    const filteredGroup = [...navLinkGroups];
    filteredGroup.forEach((group, index) => {
      filteredGroup[index].links = group.links.filter((navLink) => hasPermission(navLink.permission, "Visualizar"));
    });
    return filteredGroup;
  }, [navLinkGroups]);
  const selectedKey = useMemo(() => getSelectedKeyFromNavLinks(pathname, permissionNav), [pathname, permissionNav]);
  const handleClick = (ev, item) => {
    if (ev !== void 0 && item !== void 0) {
      ev.preventDefault();
      if (item.links) {
        setIsGroupExpanded(!isGroupExpanded);
      } else {
        navigate(item.url);
      }
    }
  };
  useEffect(() => {
    const verifySituation = audit?.empresas.some((empresa) => empresa.situacaoRevisao === (0 | 1));
    setDisableTabs(verifySituation || audit?.situacao === 0);
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(SideMenu, { title: "Comunicação com a equipe", subtitle: /* @__PURE__ */ jsxDEV(Link, { href: `/admin/clients/${audit?.contrato?.clienteId}/contracts/${audit?.contrato?.contratoPrincipalId ? `${audit?.contrato.contratoPrincipalId}?subcontract=${audit?.contrato?.numeroProposta}` : audit?.contrato?.id}`, target: "blank", children: /* @__PURE__ */ jsxDEV(Text, { styles: {
    root: {
      color: colors.gray[600],
      fontWeight: fontWeight.semibold,
      fontSize: fontSize.p14,
      textDecorationColor: colors.gray[600],
      marginLeft: spacing.lg,
      maxWidth: 200,
      marginBottom: spacing.md,
      "::hover": {
        textDecorationColor: colors.gray[600]
      }
    }
  }, block: true, children: [
    audit?.contrato?.nomeFantasia,
    " - ",
    formatProposalNumber(audit?.contrato?.numeroProposta)
  ] }, void 0, true, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditCommunicationSideMenu.tsx",
    lineNumber: 86,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditCommunicationSideMenu.tsx",
    lineNumber: 85,
    columnNumber: 63
  }, this), groups: permissionNav, onLinkClick: handleClick, selectedKey, goBack: () => navigate(`/audit/audits/${auditId}/control-panel/dashboard`) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditCommunicationSideMenu.tsx",
    lineNumber: 85,
    columnNumber: 10
  }, this);
};
_s(AuditCommunicationSideMenu, "TefNqRmcBkOs1ZiqDnvdqu5QyeM=", false, function() {
  return [useNavigate, useLocation, usePermissions, useTheme, useParams, auditQueryService.useFindOne];
});
_c = AuditCommunicationSideMenu;
export default AuditCommunicationSideMenu;
var _c;
$RefreshReg$(_c, "AuditCommunicationSideMenu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/components/AuditCommunicationSideMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdVOzs7Ozs7Ozs7Ozs7Ozs7O0FBckdWLFNBQWtDQSxZQUFZO0FBQzlDLFNBQXlCQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0QsU0FBU0MsYUFBYUMsYUFBYUMsaUJBQWlCO0FBQ3BELFNBQVNDLE1BQU1DLGdCQUFnQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsNEJBQTRCO0FBQ3JDLE9BQU9DLGdDQUFnQztBQUN2QyxTQUF1QkMsc0JBQXNCO0FBQzdDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywwQkFBMEI7QUFFbkMsTUFBTUMsNkJBQWdDQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUMsUUFBTUMsV0FBV1osWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRWE7QUFBQUEsRUFBUyxJQUFJZCxZQUFZO0FBQ2pDLFFBQU07QUFBQSxJQUFFZTtBQUFBQSxFQUFjLElBQUlQLGVBQWU7QUFDekMsUUFBTTtBQUFBLElBQUVRO0FBQUFBLElBQVFDO0FBQUFBLElBQVNDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVMsSUFBSWQsU0FBUztBQUMzRCxRQUFNLENBQUNlLGFBQWFDLGNBQWMsSUFBSXRCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN1QixpQkFBaUJDLGtCQUFrQixJQUFJeEIsU0FBa0IsS0FBSztBQUVyRSxRQUFNO0FBQUEsSUFBRXlCLElBQUlDO0FBQUFBLEVBQVEsSUFBSXZCLFVBQVU7QUFFbEMsUUFBTTtBQUFBLElBQUV3QixNQUFNQztBQUFBQSxFQUFNLElBQUlsQixrQkFBa0JtQixXQUFXSCxPQUFpQjtBQUV0RSxRQUFNSSxPQUFRLGlCQUFnQko7QUFFOUIsUUFBTUssZ0JBQWlDaEMsUUFBUSxNQUFNLENBQ25EO0FBQUEsSUFDRWlDLE9BQU8sQ0FDTDtBQUFBLE1BQ0VDLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsR0FDQTtBQUFBLE1BQ0VHLFVBQVVMLE9BQU9NLGFBQWF2QixtQkFBbUJ3QjtBQUFBQSxNQUNqREMsTUFBTTtBQUFBLE1BQ05DLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxLQUFNLEdBQUVYO0FBQUFBLElBQ1YsQ0FBQztBQUFBLEVBRUwsQ0FBQyxHQUNBLENBQUNULGFBQWFFLGVBQWUsQ0FBQztBQUVqQyxRQUFNbUIsZ0JBQWdCM0MsUUFBUSxNQUFNO0FBQ2xDLFVBQU00QyxnQkFBaUMsQ0FBQyxHQUFHWixhQUFhO0FBQ3hEWSxrQkFBY0MsUUFBUSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3RDSCxvQkFBY0csS0FBSyxFQUFFZCxRQUFRYSxNQUFNYixNQUFNZSxPQUFPQyxhQUFXaEMsY0FBY2dDLFFBQVFSLFlBQTRCLFlBQVksQ0FBQztBQUFBLElBQzVILENBQUM7QUFDRCxXQUFPRztBQUFBQSxFQUNULEdBQUcsQ0FBQ1osYUFBYSxDQUFDO0FBRWxCLFFBQU1rQixjQUFjbEQsUUFBUSxNQUMxQlMsMkJBQTJCTyxVQUFVMkIsYUFBYSxHQUNwRCxDQUFDM0IsVUFBVTJCLGFBQWEsQ0FBQztBQUV6QixRQUFNUSxjQUFjQSxDQUFDQyxJQUFpQkMsU0FBb0I7QUFDeEQsUUFBSUQsT0FBT0UsVUFBYUQsU0FBU0MsUUFBVztBQUMxQ0YsU0FBR0csZUFBZTtBQUNsQixVQUFJRixLQUFLcEIsT0FBTztBQUNkUiwyQkFBbUIsQ0FBQ0QsZUFBZTtBQUFBLE1BQ3JDLE9BQU87QUFDTFQsaUJBQVNzQyxLQUFLWCxHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBM0MsWUFBVSxNQUFNO0FBQ2QsVUFBTXlELGtCQUFrQjNCLE9BQU80QixTQUFTQyxLQUFLQyxhQUFXQSxRQUFRQyxxQkFBcUIsSUFBSSxFQUFFO0FBQzNGckMsbUJBQWVpQyxtQkFBbUIzQixPQUFPTSxhQUFhLENBQUM7QUFBQSxFQUN6RCxHQUFHLENBQUNOLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsWUFDQyxPQUFNLDRCQUNOLFVBQ0UsdUJBQUMsUUFDQyxNQUNHLGtCQUFpQkEsT0FBT2dDLFVBQVVDLHVCQUNqQ2pDLE9BQU9nQyxVQUFVRSxzQkFDWixHQUFFbEMsT0FBT2dDLFNBQVNFLG1DQUFtQ2xDLE9BQU9nQyxVQUFVRyxtQkFDdkVuQyxPQUFPZ0MsVUFBVW5DLE1BR3pCLFFBQU8sU0FFUCxpQ0FBQyxRQUNDLFFBQVE7QUFBQSxJQUNOdUMsTUFBTTtBQUFBLE1BQ0pDLE9BQU9oRCxPQUFPaUQsS0FBSyxHQUFHO0FBQUEsTUFDdEIvQyxZQUFZQSxXQUFXZ0Q7QUFBQUEsTUFDdkIvQyxVQUFVQSxTQUFTZ0Q7QUFBQUEsTUFDbkJDLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUNwQ0ksWUFBWXBELFFBQVFxRDtBQUFBQSxNQUNwQkMsVUFBVTtBQUFBLE1BQ1ZDLGNBQWN2RCxRQUFRd0Q7QUFBQUEsTUFDdEIsV0FBVztBQUFBLFFBQ1RMLHFCQUFxQnBELE9BQU9pRCxLQUFLLEdBQUc7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQ0EsT0FBSyxNQUVKdEM7QUFBQUEsV0FBT2dDLFVBQVVlO0FBQUFBLElBQWE7QUFBQSxJQUFJcEUscUJBQXFCcUIsT0FBT2dDLFVBQVVHLGNBQXdCO0FBQUEsT0FqQm5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQSxHQUVGLFFBQVFyQixlQUNSLGFBQWFRLGFBQ2IsYUFDQSxRQUFRLE1BQU1wQyxTQUFVLGlCQUFnQlksaUNBQWlDLEtBckMzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUM2RTtBQUdqRjtBQUFDYixHQXJIS0QsNEJBQTZCO0FBQUEsVUFDaEJWLGFBQ0lELGFBQ0tRLGdCQUN3QkgsVUFJMUJILFdBRUFPLGtCQUFrQm1CLFVBQVU7QUFBQTtBQUFBK0MsS0FWaERoRTtBQXVITixlQUFlQTtBQUEwQixJQUFBZ0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwiTGluayIsIlNpZGVNZW51IiwidXNlVGhlbWUiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsImdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzIiwidXNlUGVybWlzc2lvbnMiLCJhdWRpdFF1ZXJ5U2VydmljZSIsIkF1ZGl0U2l0dWF0aW9uRW51bSIsIkF1ZGl0Q29tbXVuaWNhdGlvblNpZGVNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsInBhdGhuYW1lIiwiaGFzUGVybWlzc2lvbiIsImNvbG9ycyIsInNwYWNpbmciLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJkaXNhYmxlVGFicyIsInNldERpc2FibGVUYWJzIiwiaXNHcm91cEV4cGFuZGVkIiwic2V0SXNHcm91cEV4cGFuZGVkIiwiaWQiLCJhdWRpdElkIiwiZGF0YSIsImF1ZGl0IiwidXNlRmluZE9uZSIsInBhdGgiLCJuYXZMaW5rR3JvdXBzIiwibGlua3MiLCJkaXNhYmxlZCIsInNpdHVhY2FvIiwiQ2FuY2VsYWRvIiwiaWNvbiIsImtleSIsInRpdGxlIiwibmFtZSIsInBlcm1pc3Npb24iLCJ1cmwiLCJwZXJtaXNzaW9uTmF2IiwiZmlsdGVyZWRHcm91cCIsImZvckVhY2giLCJncm91cCIsImluZGV4IiwiZmlsdGVyIiwibmF2TGluayIsInNlbGVjdGVkS2V5IiwiaGFuZGxlQ2xpY2siLCJldiIsIml0ZW0iLCJ1bmRlZmluZWQiLCJwcmV2ZW50RGVmYXVsdCIsInZlcmlmeVNpdHVhdGlvbiIsImVtcHJlc2FzIiwic29tZSIsImVtcHJlc2EiLCJzaXR1YWNhb1JldmlzYW8iLCJjb250cmF0byIsImNsaWVudGVJZCIsImNvbnRyYXRvUHJpbmNpcGFsSWQiLCJudW1lcm9Qcm9wb3N0YSIsInJvb3QiLCJjb2xvciIsImdyYXkiLCJzZW1pYm9sZCIsInAxNCIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJtYXJnaW5MZWZ0IiwibGciLCJtYXhXaWR0aCIsIm1hcmdpbkJvdHRvbSIsIm1kIiwibm9tZUZhbnRhc2lhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdWRpdENvbW11bmljYXRpb25TaWRlTWVudS50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2F1ZGl0L2NvbXBvbmVudHMvQXVkaXRDb21tdW5pY2F0aW9uU2lkZU1lbnUudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSU5hdkxpbmssIElOYXZMaW5rR3JvdXAsIFRleHQgfSBmcm9tICdAZmx1ZW50dWkvcmVhY3QnXHJcbmltcG9ydCB7IEZDLCBNb3VzZUV2ZW50LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgTGluaywgU2lkZU1lbnUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcclxuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvaG9va3MnXHJcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xyXG5pbXBvcnQgZ2V0U2VsZWN0ZWRLZXlGcm9tTmF2TGlua3MgZnJvbSAnLi4vLi4vLi4vc2hhcmVkL3V0aWxzL2dldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzJ1xyXG5pbXBvcnQgeyBzZXJ2aWNlQ29kZXMsIHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vYXV0aC9ob29rcy9wZXJtaXNzaW9ucydcclxuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UgfSBmcm9tICcuLi9hdWRpdHMvc2VydmljZXMnXHJcbmltcG9ydCB7IEF1ZGl0U2l0dWF0aW9uRW51bSB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9lbnVtcy9BdWRpdFNpdHVhdGlvbkVudW0nXHJcblxyXG5jb25zdCBBdWRpdENvbW11bmljYXRpb25TaWRlTWVudTpGQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXHJcbiAgY29uc3QgeyBoYXNQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpXHJcbiAgY29uc3QgeyBjb2xvcnMsIHNwYWNpbmcsIGZvbnRXZWlnaHQsIGZvbnRTaXplIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgW2Rpc2FibGVUYWJzLCBzZXREaXNhYmxlVGFic10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNHcm91cEV4cGFuZGVkLCBzZXRJc0dyb3VwRXhwYW5kZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpXHJcblxyXG4gIGNvbnN0IHsgaWQ6IGF1ZGl0SWQgfSA9IHVzZVBhcmFtcygpXHJcblxyXG4gIGNvbnN0IHsgZGF0YTogYXVkaXQgfSA9IGF1ZGl0UXVlcnlTZXJ2aWNlLnVzZUZpbmRPbmUoYXVkaXRJZCBhcyBzdHJpbmcpXHJcblxyXG4gIGNvbnN0IHBhdGggPSBgL2F1ZGl0L2F1ZGl0cy8ke2F1ZGl0SWR9L2NvbnRyb2wtcGFuZWwvY29tbXVuaWNhdGlvbmBcclxuXHJcbiAgY29uc3QgbmF2TGlua0dyb3VwczogSU5hdkxpbmtHcm91cFtdID0gdXNlTWVtbygoKSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIGxpbmtzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkbyxcclxuICAgICAgICAgIGljb246ICdCSURhc2hib2FyZCcsXHJcbiAgICAgICAgICBrZXk6ICdhZGp1c3RtZW50LWJhbGxvdCcsXHJcbiAgICAgICAgICB0aXRsZTogJ0PDqWR1bGEgZGUgYWp1c3RlJyxcclxuICAgICAgICAgIG5hbWU6ICdDw6lkdWxhIGRlIGFqdXN0ZScsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vYWRqdXN0bWVudC1iYWxsb3RgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGlzYWJsZWQ6IGF1ZGl0Py5zaXR1YWNhbyA9PT0gQXVkaXRTaXR1YXRpb25FbnVtLkNhbmNlbGFkbyxcclxuICAgICAgICAgIGljb246ICdDYWxlbmRhckRheScsXHJcbiAgICAgICAgICBrZXk6ICdtZWV0aW5nLW1pbnV0ZXMnLFxyXG4gICAgICAgICAgdGl0bGU6ICdNaW51dGEgZGUgcmV1bmnDo28nLFxyXG4gICAgICAgICAgbmFtZTogJ01pbnV0YSBkZSByZXVuacOjbycsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vbWVldGluZy1taW51dGVzYCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGRpc2FibGVkOiBhdWRpdD8uc2l0dWFjYW8gPT09IEF1ZGl0U2l0dWF0aW9uRW51bS5DYW5jZWxhZG8sXHJcbiAgICAgICAgICBpY29uOiAnQ29tbXVuaWNhdGlvbnMnLFxyXG4gICAgICAgICAga2V5OiAndGVhbS1jb21tcycsXHJcbiAgICAgICAgICB0aXRsZTogJ0NvbXVuaWNhw6fDo28gY29tIGEgZXF1aXBlJyxcclxuICAgICAgICAgIG5hbWU6ICdDb211bmljYcOnw6NvIGNvbSBhIGVxdWlwZScsXHJcbiAgICAgICAgICBwZXJtaXNzaW9uOiAnQXVkaXRvcmlhJyxcclxuICAgICAgICAgIHVybDogYCR7cGF0aH0vdGVhbS1jb21tc2AsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgXSwgW2Rpc2FibGVUYWJzLCBpc0dyb3VwRXhwYW5kZWRdKVxyXG5cclxuICBjb25zdCBwZXJtaXNzaW9uTmF2ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZEdyb3VwOiBJTmF2TGlua0dyb3VwW10gPSBbLi4ubmF2TGlua0dyb3Vwc11cclxuICAgIGZpbHRlcmVkR3JvdXAuZm9yRWFjaCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgIGZpbHRlcmVkR3JvdXBbaW5kZXhdLmxpbmtzID0gZ3JvdXAubGlua3MuZmlsdGVyKG5hdkxpbmsgPT4gaGFzUGVybWlzc2lvbihuYXZMaW5rLnBlcm1pc3Npb24gYXMgc2VydmljZUNvZGVzLCAnVmlzdWFsaXphcicpKVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmaWx0ZXJlZEdyb3VwXHJcbiAgfSwgW25hdkxpbmtHcm91cHNdKVxyXG5cclxuICBjb25zdCBzZWxlY3RlZEtleSA9IHVzZU1lbW8oKCkgPT5cclxuICAgIGdldFNlbGVjdGVkS2V5RnJvbU5hdkxpbmtzKHBhdGhuYW1lLCBwZXJtaXNzaW9uTmF2KSxcclxuICBbcGF0aG5hbWUsIHBlcm1pc3Npb25OYXZdKVxyXG5cclxuICBjb25zdCBoYW5kbGVDbGljayA9IChldj86IE1vdXNlRXZlbnQsIGl0ZW0/OiBJTmF2TGluaykgPT4ge1xyXG4gICAgaWYgKGV2ICE9PSB1bmRlZmluZWQgJiYgaXRlbSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgaWYgKGl0ZW0ubGlua3MpIHtcclxuICAgICAgICBzZXRJc0dyb3VwRXhwYW5kZWQoIWlzR3JvdXBFeHBhbmRlZClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBuYXZpZ2F0ZShpdGVtLnVybClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHZlcmlmeVNpdHVhdGlvbiA9IGF1ZGl0Py5lbXByZXNhcy5zb21lKGVtcHJlc2EgPT4gZW1wcmVzYS5zaXR1YWNhb1JldmlzYW8gPT09ICgwIHwgMSkpIGFzIGJvb2xlYW5cclxuICAgIHNldERpc2FibGVUYWJzKHZlcmlmeVNpdHVhdGlvbiB8fCBhdWRpdD8uc2l0dWFjYW8gPT09IDApXHJcbiAgfSwgW2F1ZGl0XSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTaWRlTWVudVxyXG4gICAgICB0aXRsZT0nQ29tdW5pY2HDp8OjbyBjb20gYSBlcXVpcGUnXHJcbiAgICAgIHN1YnRpdGxlPXtcclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17XHJcbiAgICAgICAgICAgIGAvYWRtaW4vY2xpZW50cy8ke2F1ZGl0Py5jb250cmF0bz8uY2xpZW50ZUlkfS9jb250cmFjdHMvJHtcclxuICAgICAgICAgICAgICBhdWRpdD8uY29udHJhdG8/LmNvbnRyYXRvUHJpbmNpcGFsSWRcclxuICAgICAgICAgICAgICAgID8gYCR7YXVkaXQ/LmNvbnRyYXRvLmNvbnRyYXRvUHJpbmNpcGFsSWR9P3N1YmNvbnRyYWN0PSR7YXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YX1gXHJcbiAgICAgICAgICAgICAgICA6IGF1ZGl0Py5jb250cmF0bz8uaWRcclxuICAgICAgICAgICAgfWBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRhcmdldD1cImJsYW5rXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IGZvbnRXZWlnaHQuc2VtaWJvbGQsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udFNpemUucDE0LFxyXG4gICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25Db2xvcjogY29sb3JzLmdyYXlbNjAwXSxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IHNwYWNpbmcubGcsXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogMjAwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBzcGFjaW5nLm1kLFxyXG4gICAgICAgICAgICAgICAgJzo6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uQ29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthdWRpdD8uY29udHJhdG8/Lm5vbWVGYW50YXNpYX0gLSB7Zm9ybWF0UHJvcG9zYWxOdW1iZXIoYXVkaXQ/LmNvbnRyYXRvPy5udW1lcm9Qcm9wb3N0YSBhcyBzdHJpbmcpfVxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgfVxyXG4gICAgICBncm91cHM9e3Blcm1pc3Npb25OYXZ9XHJcbiAgICAgIG9uTGlua0NsaWNrPXtoYW5kbGVDbGlja31cclxuICAgICAgc2VsZWN0ZWRLZXk9e3NlbGVjdGVkS2V5fVxyXG4gICAgICBnb0JhY2s9eygpID0+IG5hdmlnYXRlKGAvYXVkaXQvYXVkaXRzLyR7YXVkaXRJZH0vY29udHJvbC1wYW5lbC9kYXNoYm9hcmRgKX1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWRpdENvbW11bmljYXRpb25TaWRlTWVudVxyXG4iXX0=