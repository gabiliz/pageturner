import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/filter/FilterInputRender.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { mergeStyles, TooltipHost } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const memo = __vite__cjsImport4_react["memo"]; const useCallback = __vite__cjsImport4_react["useCallback"]; const useContext = __vite__cjsImport4_react["useContext"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { FilterInputSearch } from "/src/shared/components/filter/index.ts?t=1701096626433";
import { SearchableDropdown } from "/src/shared/components/index.ts?t=1701096626433";
import { useTheme } from "/src/shared/hooks/index.ts";
import { filterGroupContext } from "/src/shared/components/filter/filterGroupContext.ts";
const MAX_SIZE_PER_GROUP = 20;
const FilterInputRender = ({
  groupName
}) => {
  _s();
  const {
    handleItemsChange,
    isDisabledAddItems,
    filterGroups
  } = useContext(filterGroupContext);
  const group = useMemo(() => filterGroups.find((group2) => group2.filterGroupName === groupName), [filterGroups]);
  const groupItems = group.items;
  const hasActiveFilters = useMemo(() => groupItems ? groupItems.length > 0 : false, [groupItems]);
  const selectedKeys = groupItems.map((item) => String(item.key));
  const {
    circleStyles,
    dropdownStyles
  } = useFilterInputRenderStyles(hasActiveFilters, group.color, isDisabledAddItems || group.disabled || false);
  const options = useMemo(() => {
    return group.dropdownOptions ? group.dropdownOptions.map((option) => ({
      ...option,
      key: String(option.key)
    })) : [];
  }, [group.dropdownOptions]);
  const [hasSelectAll, setHasSelectAll] = useState(false);
  const [isAllSelectedInSearch, setIsAllSelectedInSearch] = useState(false);
  const disabledAddFilter = isDisabledAddItems || group.items.length >= MAX_SIZE_PER_GROUP;
  const onTitleRenderOption = useCallback(() => {
    const itemsCount = group.items.length;
    if (hasActiveFilters) {
      return /* @__PURE__ */ jsxDEV(Fragment, { children: [
        group.filterGroupName,
        /* @__PURE__ */ jsxDEV("span", { children: [
          "(",
          itemsCount,
          ")"
        ] }, void 0, true, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
          lineNumber: 45,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: circleStyles }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
          lineNumber: 46,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
        lineNumber: 43,
        columnNumber: 14
      }, this);
    }
    return /* @__PURE__ */ jsxDEV(Fragment, { children: group.filterGroupName }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
      lineNumber: 49,
      columnNumber: 12
    }, this);
  }, [group.filterGroupName, group.items, hasActiveFilters]);
  const verifyHasSelectAll = (options2) => {
    const unselectedOptions = options2.filter((opt) => group.items.every((item) => item.key !== opt.key));
    const sumVisibleAndSelectedOptions = unselectedOptions.length + group.items.length;
    setHasSelectAll(sumVisibleAndSelectedOptions <= MAX_SIZE_PER_GROUP);
  };
  const verifyIsSelectedAll = (options2) => {
    if (selectedKeys === void 0)
      return;
    setIsAllSelectedInSearch(options2.every((option) => selectedKeys?.some((key) => key === String(option.key))));
  };
  const handleChangeItems = (options2) => {
    const filteredOptionsWithoutHidden = options2.filter((opt) => !opt.hidden);
    verifyIsSelectedAll(filteredOptionsWithoutHidden);
    verifyHasSelectAll(filteredOptionsWithoutHidden);
  };
  const handleDropdownChange = useCallback((_, value) => {
    if (value === void 0 || !group)
      return void 0;
    const oldGroupItems = group.items;
    const newItem = {
      key: String(value.key),
      text: value.text
    };
    const newGroupItems = value.selected ? [...oldGroupItems, newItem] : oldGroupItems.filter((item) => item.key !== value.key);
    const newGroup = {
      ...group,
      items: newGroupItems
    };
    handleItemsChange(newGroup);
  }, [group]);
  const handleSelectAll = (_, checked, checkedOptions) => {
    if (checked === void 0 || checkedOptions === void 0)
      return;
    let updateValues = group.items;
    checkedOptions.forEach((option) => {
      const disabledOption = option.hidden;
      const alreadyChecked = updateValues.some((item) => item.key === option.key);
      if (checked) {
        if (!alreadyChecked && !disabledOption) {
          updateValues = [...updateValues, {
            key: String(option.key),
            text: option.text
          }];
        }
      }
      if (!checked) {
        if (!disabledOption) {
          updateValues = updateValues.filter((item) => item.key !== String(option.key));
        }
      }
    });
    const newGroup = {
      ...group,
      items: updateValues
    };
    handleItemsChange(newGroup);
  };
  if (group.queryMode === "searchableDropdown") {
    return /* @__PURE__ */ jsxDEV(TooltipHost, { content: disabledAddFilter ? "Máximo de itens filtrados atingido" : void 0, children: /* @__PURE__ */ jsxDEV(SearchableDropdown, { disabled: disabledAddFilter || group.disabled, placeholder: group.filterGroupName, onRenderTitle: onTitleRenderOption, options, title: group.filterGroupName, selectedKeys, autoDropdownWidth: true, hasSelectAll: true, disabledSelectAllHint: "Não é possível selecionar todos, há opções demais.", disabledSelectAll: !hasSelectAll, onSelectAll: handleSelectAll, multiSelect: true, hasSearch: true, checked: isAllSelectedInSearch, onChange: handleDropdownChange, onChangeItems: handleChangeItems, styles: dropdownStyles }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
      lineNumber: 107,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
      lineNumber: 106,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(FilterInputSearch, { group }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx",
    lineNumber: 110,
    columnNumber: 10
  }, this);
};
_s(FilterInputRender, "GxOF2pYf78lYkBnaP1iANMLzo8w=", false, function() {
  return [useFilterInputRenderStyles];
});
_c = FilterInputRender;
const useFilterInputRenderStyles = (hasActiveItems, groupColor, disabledGroup) => {
  _s2();
  const {
    colors,
    fontSize,
    fontWeight,
    spacing
  } = useTheme();
  const circleStyles = mergeStyles({
    display: "inline-block",
    paddingLeft: spacing.xs,
    width: 8,
    height: 8,
    borderRadius: "50%",
    backgroundColor: groupColor || colors.purple[500]
  });
  const dropdownStyles = {
    root: {
      height: 32,
      ":hover": {
        backgroundColor: colors.gray[200]
      }
    },
    dropdown: {
      height: "100%",
      fontSize: fontSize.p14,
      color: colors.gray[600],
      fontWeight: hasActiveItems ? fontWeight.semibold : fontWeight.regular,
      ":hover .ms-Dropdown-title": {
        color: colors.gray[600],
        backgroundColor: colors.gray[200]
      },
      ":active .ms-Dropdown-title": {
        color: colors.gray[600]
      },
      ":focus .ms-Dropdown-title": {
        color: colors.gray[600]
      },
      ":focus::after": {
        border: colors.gray[600]
      },
      ".is-disabled .ms-Dropdown-title": {
        backgroundColor: colors.gray[200]
      }
    },
    dropdownItemDisabled: {
      backgroundColor: colors.gray[200]
    },
    title: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gridGap: spacing.xs,
      padding: "0px 26px 0px 0px",
      lineHeight: "auto",
      borderWidth: 0,
      height: "100%",
      color: colors.gray[600]
    },
    caretDownWrapper: {
      display: "inline-flex",
      alignItems: "center",
      height: "100%"
    },
    callout: {
      maxHeight: 290,
      display: disabledGroup ? "none" : "flex"
    }
  };
  return {
    dropdownStyles,
    circleStyles
  };
};
_s2(useFilterInputRenderStyles, "x5uMmp/puAu3QTxOIpKvxrk7EyE=", false, function() {
  return [useTheme];
});
export default _c2 = memo(FilterInputRender);
var _c, _c2;
$RefreshReg$(_c, "FilterInputRender");
$RefreshReg$(_c2, "%default%");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterInputRender.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURRLG1CQUVFLGNBRkY7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqRFIsU0FBMkNBLGFBQWFDLG1CQUFtQjtBQUMzRSxTQUFhQyxNQUFNQyxhQUFhQyxZQUFZQyxTQUFTQyxnQkFBZ0I7QUFDckUsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsMEJBQTBCO0FBT25DLE1BQU1DLHFCQUFxQjtBQUUzQixNQUFNQyxvQkFBZ0RBLENBQUM7QUFBQSxFQUFFQztBQUFVLE1BQU07QUFBQUMsS0FBQTtBQUN2RSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBbUJDO0FBQUFBLElBQW9CQztBQUFBQSxFQUFhLElBQUliLFdBQVdNLGtCQUFrQjtBQUU3RixRQUFNUSxRQUFRYixRQUFRLE1BQ3BCWSxhQUFhRSxLQUFLRCxZQUFTQSxPQUFNRSxvQkFBb0JQLFNBQVMsR0FDOUQsQ0FBQ0ksWUFBWSxDQUFDO0FBRWhCLFFBQU1JLGFBQWFILE1BQU1JO0FBQ3pCLFFBQU1DLG1CQUFtQmxCLFFBQVEsTUFBTWdCLGFBQWFBLFdBQVdHLFNBQVMsSUFBSSxPQUFPLENBQUNILFVBQVUsQ0FBQztBQUMvRixRQUFNSSxlQUFlSixXQUFXSyxJQUFJQyxVQUFRQyxPQUFPRCxLQUFLRSxHQUFHLENBQUM7QUFFNUQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQWNDO0FBQUFBLEVBQWUsSUFBSUMsMkJBQ3ZDVCxrQkFDQUwsTUFBTWUsT0FDTmpCLHNCQUFzQkUsTUFBTWdCLFlBQVksS0FDMUM7QUFFQSxRQUFNQyxVQUFVOUIsUUFBUSxNQUFNO0FBQzVCLFdBQU9hLE1BQU1rQixrQkFDVGxCLE1BQU1rQixnQkFDTFYsSUFBSVcsYUFBVztBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBUVIsS0FBS0QsT0FBT1MsT0FBT1IsR0FBRztBQUFBLElBQUUsRUFBRSxJQUN2RDtBQUFBLEVBQ04sR0FBRyxDQUNEWCxNQUFNa0IsZUFBZSxDQUN0QjtBQUVELFFBQU0sQ0FBQ0UsY0FBY0MsZUFBZSxJQUFJakMsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2tDLHVCQUF1QkMsd0JBQXdCLElBQUluQyxTQUFTLEtBQUs7QUFDeEUsUUFBTW9DLG9CQUFvQjFCLHNCQUFzQkUsTUFBTUksTUFBTUUsVUFBVWI7QUFFdEUsUUFBTWdDLHNCQUFzQnhDLFlBQVksTUFBTTtBQUM1QyxVQUFNeUMsYUFBYTFCLE1BQU1JLE1BQU1FO0FBRS9CLFFBQUlELGtCQUFrQjtBQUNwQixhQUNFLG1DQUNHTDtBQUFBQSxjQUFNRTtBQUFBQSxRQUNQLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQUV3QjtBQUFBQSxVQUFXO0FBQUEsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQ3BCLHVCQUFDLFVBQUssV0FBV2QsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxXQUhoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxJQUVKO0FBRUEsV0FBTyxtQ0FBR1osZ0JBQU1FLG1CQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxFQUNsQyxHQUFHLENBQ0RGLE1BQU1FLGlCQUNORixNQUFNSSxPQUNOQyxnQkFBZ0IsQ0FDakI7QUFFRCxRQUFNc0IscUJBQXFCQSxDQUFDVixhQUErQjtBQUN6RCxVQUFNVyxvQkFBb0JYLFNBQVFZLE9BQU9DLFNBQU85QixNQUFNSSxNQUFNMkIsTUFBTXRCLFVBQVFBLEtBQUtFLFFBQVFtQixJQUFJbkIsR0FBRyxDQUFDO0FBQy9GLFVBQU1xQiwrQkFBK0JKLGtCQUFrQnRCLFNBQVNOLE1BQU1JLE1BQU1FO0FBRTVFZSxvQkFBZ0JXLGdDQUFnQ3ZDLGtCQUFrQjtBQUFBLEVBQ3BFO0FBRUEsUUFBTXdDLHNCQUFzQkEsQ0FBQ2hCLGFBQStCO0FBQzFELFFBQUlWLGlCQUFpQjJCO0FBQVc7QUFFaENYLDZCQUNFTixTQUNHYyxNQUFNWixZQUFVWixjQUFjNEIsS0FBS3hCLFNBQU9BLFFBQVFELE9BQU9TLE9BQU9SLEdBQUcsQ0FBQyxDQUFDLENBQzFFO0FBQUEsRUFDRjtBQUVBLFFBQU15QixvQkFBb0JBLENBQUNuQixhQUErQjtBQUN4RCxVQUFNb0IsK0JBQStCcEIsU0FBUVksT0FBT0MsU0FBTyxDQUFDQSxJQUFJUSxNQUFNO0FBRXRFTCx3QkFBb0JJLDRCQUE0QjtBQUNoRFYsdUJBQW1CVSw0QkFBNEI7QUFBQSxFQUNqRDtBQUVBLFFBQU1FLHVCQUF1QnRELFlBQVksQ0FBQ3VELEdBQWFDLFVBQTRCO0FBQ2pGLFFBQUlBLFVBQVVQLFVBQWEsQ0FBQ2xDO0FBQU8sYUFBT2tDO0FBQzFDLFVBQU1RLGdCQUFnQjFDLE1BQU1JO0FBQzVCLFVBQU11QyxVQUE0QjtBQUFBLE1BQ2hDaEMsS0FBS0QsT0FBTytCLE1BQU05QixHQUFHO0FBQUEsTUFDckJpQyxNQUFNSCxNQUFNRztBQUFBQSxJQUNkO0FBRUEsVUFBTUMsZ0JBQWdCSixNQUFNSyxXQUN4QixDQUFDLEdBQUdKLGVBQWVDLE9BQU8sSUFDMUJELGNBQWNiLE9BQU9wQixVQUFRQSxLQUFLRSxRQUFROEIsTUFBTTlCLEdBQUc7QUFFdkQsVUFBTW9DLFdBQXlCO0FBQUEsTUFDN0IsR0FBRy9DO0FBQUFBLE1BQ0hJLE9BQU95QztBQUFBQSxJQUNUO0FBRUFoRCxzQkFBa0JrRCxRQUFRO0FBQUEsRUFDNUIsR0FBRyxDQUFDL0MsS0FBSyxDQUFDO0FBRVYsUUFBTWdELGtCQUFrQkEsQ0FBQ1IsR0FBYVMsU0FBbUJDLG1CQUF1QztBQUM5RixRQUFJRCxZQUFZZixVQUFhZ0IsbUJBQW1CaEI7QUFBVztBQUMzRCxRQUFJaUIsZUFBZW5ELE1BQU1JO0FBRXpCOEMsbUJBQWVFLFFBQVFqQyxZQUFVO0FBQy9CLFlBQU1rQyxpQkFBaUJsQyxPQUFPbUI7QUFDOUIsWUFBTWdCLGlCQUFpQkgsYUFBYWhCLEtBQUsxQixVQUFRQSxLQUFLRSxRQUFRUSxPQUFPUixHQUFHO0FBRXhFLFVBQUlzQyxTQUFTO0FBQ1gsWUFBSSxDQUFDSyxrQkFBa0IsQ0FBQ0QsZ0JBQWdCO0FBQ3RDRix5QkFBZSxDQUNiLEdBQUdBLGNBQWM7QUFBQSxZQUFFeEMsS0FBS0QsT0FBT1MsT0FBT1IsR0FBRztBQUFBLFlBQUdpQyxNQUFNekIsT0FBT3lCO0FBQUFBLFVBQUssQ0FBQztBQUFBLFFBRW5FO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBQ0ssU0FBUztBQUNaLFlBQUksQ0FBQ0ksZ0JBQWdCO0FBQ25CRix5QkFBZUEsYUFBYXRCLE9BQU9wQixVQUFRQSxLQUFLRSxRQUFRRCxPQUFPUyxPQUFPUixHQUFHLENBQUM7QUFBQSxRQUM1RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNb0MsV0FBeUI7QUFBQSxNQUM3QixHQUFHL0M7QUFBQUEsTUFDSEksT0FBTytDO0FBQUFBLElBQ1Q7QUFFQXRELHNCQUFrQmtELFFBQVE7QUFBQSxFQUM1QjtBQUVBLE1BQUkvQyxNQUFNdUQsY0FBYyxzQkFBc0I7QUFDNUMsV0FDRSx1QkFBQyxlQUNDLFNBQ0UvQixvQkFDSSx1Q0FDQVUsUUFHTixpQ0FBQyxzQkFDQyxVQUFVVixxQkFBcUJ4QixNQUFNZ0IsVUFDckMsYUFBYWhCLE1BQU1FLGlCQUNuQixlQUFldUIscUJBQ2YsU0FDQSxPQUFPekIsTUFBTUUsaUJBQ2IsY0FDQSxtQkFBaUIsTUFDakIsY0FBWSxNQUNaLHVCQUFzQixzREFDdEIsbUJBQW1CLENBQUNrQixjQUNwQixhQUFhNEIsaUJBQ2IsYUFBVyxNQUNYLFdBQVMsTUFDVCxTQUFTMUIsdUJBQ1QsVUFBVWlCLHNCQUNWLGVBQWVILG1CQUNmLFFBQVF2QixrQkFqQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCeUIsS0F4QjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxxQkFDQyxTQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FDZTtBQUduQjtBQUFDakIsR0FqS0tGLG1CQUE2QztBQUFBLFVBV1JvQiwwQkFBMEI7QUFBQTtBQUFBMEMsS0FYL0Q5RDtBQW1LTixNQUFNb0IsNkJBQTZCQSxDQUNqQzJDLGdCQUNBQyxZQUNBQyxrQkFDRztBQUFBQyxNQUFBO0FBQ0gsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQVVDO0FBQUFBLElBQVlDO0FBQUFBLEVBQVEsSUFBSXpFLFNBQVM7QUFFM0QsUUFBTXFCLGVBQWU5QixZQUFZO0FBQUEsSUFDL0JtRixTQUFTO0FBQUEsSUFDVEMsYUFBYUYsUUFBUUc7QUFBQUEsSUFDckJDLE9BQU87QUFBQSxJQUNQQyxRQUFRO0FBQUEsSUFDUkMsY0FBYztBQUFBLElBQ2RDLGlCQUFpQmIsY0FBY0csT0FBT1csT0FBTyxHQUFHO0FBQUEsRUFDbEQsQ0FBQztBQUVELFFBQU0zRCxpQkFBMkM7QUFBQSxJQUMvQzRELE1BQU07QUFBQSxNQUNKSixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsUUFDUkUsaUJBQWlCVixPQUFPYSxLQUFLLEdBQUc7QUFBQSxNQUNsQztBQUFBLElBQ0Y7QUFBQSxJQUVBQyxVQUFVO0FBQUEsTUFDUk4sUUFBUTtBQUFBLE1BQ1JQLFVBQVVBLFNBQVNjO0FBQUFBLE1BQ25CN0QsT0FBTzhDLE9BQU9hLEtBQUssR0FBRztBQUFBLE1BQ3RCWCxZQUFZTixpQkFBaUJNLFdBQVdjLFdBQVdkLFdBQVdlO0FBQUFBLE1BQzlELDZCQUE2QjtBQUFBLFFBQzNCL0QsT0FBTzhDLE9BQU9hLEtBQUssR0FBRztBQUFBLFFBQ3RCSCxpQkFBaUJWLE9BQU9hLEtBQUssR0FBRztBQUFBLE1BQ2xDO0FBQUEsTUFDQSw4QkFBOEI7QUFBQSxRQUM1QjNELE9BQU84QyxPQUFPYSxLQUFLLEdBQUc7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsNkJBQTZCO0FBQUEsUUFDM0IzRCxPQUFPOEMsT0FBT2EsS0FBSyxHQUFHO0FBQUEsTUFDeEI7QUFBQSxNQUNBLGlCQUFpQjtBQUFBLFFBQ2ZLLFFBQVFsQixPQUFPYSxLQUFLLEdBQUc7QUFBQSxNQUN6QjtBQUFBLE1BQ0EsbUNBQW1DO0FBQUEsUUFDakNILGlCQUFpQlYsT0FBT2EsS0FBSyxHQUFHO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQUEsSUFDQU0sc0JBQXNCO0FBQUEsTUFDcEJULGlCQUFpQlYsT0FBT2EsS0FBSyxHQUFHO0FBQUEsSUFDbEM7QUFBQSxJQUNBTyxPQUFPO0FBQUEsTUFDTGhCLFNBQVM7QUFBQSxNQUNUaUIsWUFBWTtBQUFBLE1BQ1pDLGdCQUFnQjtBQUFBLE1BQ2hCQyxTQUFTcEIsUUFBUUc7QUFBQUEsTUFDakJrQixTQUFTO0FBQUEsTUFDVEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNibEIsUUFBUTtBQUFBLE1BQ1J0RCxPQUFPOEMsT0FBT2EsS0FBSyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxJQUNBYyxrQkFBa0I7QUFBQSxNQUNoQnZCLFNBQVM7QUFBQSxNQUNUaUIsWUFBWTtBQUFBLE1BQ1piLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQW9CLFNBQVM7QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWHpCLFNBQVNOLGdCQUFnQixTQUFTO0FBQUEsSUFDcEM7QUFBQSxFQUNGO0FBRUEsU0FBTztBQUFBLElBQ0w5QztBQUFBQSxJQUNBRDtBQUFBQSxFQUNGO0FBQ0Y7QUFBQ2dELElBM0VLOUMsNEJBQTBCO0FBQUEsVUFLb0J2QixRQUFRO0FBQUE7QUF3RTVELGVBQUFvRyxNQUFlM0csS0FBS1UsaUJBQWlCO0FBQUMsSUFBQThELElBQUFtQztBQUFBQyxhQUFBcEMsSUFBQTtBQUFBb0MsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIm1lcmdlU3R5bGVzIiwiVG9vbHRpcEhvc3QiLCJtZW1vIiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiRmlsdGVySW5wdXRTZWFyY2giLCJTZWFyY2hhYmxlRHJvcGRvd24iLCJ1c2VUaGVtZSIsImZpbHRlckdyb3VwQ29udGV4dCIsIk1BWF9TSVpFX1BFUl9HUk9VUCIsIkZpbHRlcklucHV0UmVuZGVyIiwiZ3JvdXBOYW1lIiwiX3MiLCJoYW5kbGVJdGVtc0NoYW5nZSIsImlzRGlzYWJsZWRBZGRJdGVtcyIsImZpbHRlckdyb3VwcyIsImdyb3VwIiwiZmluZCIsImZpbHRlckdyb3VwTmFtZSIsImdyb3VwSXRlbXMiLCJpdGVtcyIsImhhc0FjdGl2ZUZpbHRlcnMiLCJsZW5ndGgiLCJzZWxlY3RlZEtleXMiLCJtYXAiLCJpdGVtIiwiU3RyaW5nIiwia2V5IiwiY2lyY2xlU3R5bGVzIiwiZHJvcGRvd25TdHlsZXMiLCJ1c2VGaWx0ZXJJbnB1dFJlbmRlclN0eWxlcyIsImNvbG9yIiwiZGlzYWJsZWQiLCJvcHRpb25zIiwiZHJvcGRvd25PcHRpb25zIiwib3B0aW9uIiwiaGFzU2VsZWN0QWxsIiwic2V0SGFzU2VsZWN0QWxsIiwiaXNBbGxTZWxlY3RlZEluU2VhcmNoIiwic2V0SXNBbGxTZWxlY3RlZEluU2VhcmNoIiwiZGlzYWJsZWRBZGRGaWx0ZXIiLCJvblRpdGxlUmVuZGVyT3B0aW9uIiwiaXRlbXNDb3VudCIsInZlcmlmeUhhc1NlbGVjdEFsbCIsInVuc2VsZWN0ZWRPcHRpb25zIiwiZmlsdGVyIiwib3B0IiwiZXZlcnkiLCJzdW1WaXNpYmxlQW5kU2VsZWN0ZWRPcHRpb25zIiwidmVyaWZ5SXNTZWxlY3RlZEFsbCIsInVuZGVmaW5lZCIsInNvbWUiLCJoYW5kbGVDaGFuZ2VJdGVtcyIsImZpbHRlcmVkT3B0aW9uc1dpdGhvdXRIaWRkZW4iLCJoaWRkZW4iLCJoYW5kbGVEcm9wZG93bkNoYW5nZSIsIl8iLCJ2YWx1ZSIsIm9sZEdyb3VwSXRlbXMiLCJuZXdJdGVtIiwidGV4dCIsIm5ld0dyb3VwSXRlbXMiLCJzZWxlY3RlZCIsIm5ld0dyb3VwIiwiaGFuZGxlU2VsZWN0QWxsIiwiY2hlY2tlZCIsImNoZWNrZWRPcHRpb25zIiwidXBkYXRlVmFsdWVzIiwiZm9yRWFjaCIsImRpc2FibGVkT3B0aW9uIiwiYWxyZWFkeUNoZWNrZWQiLCJxdWVyeU1vZGUiLCJfYyIsImhhc0FjdGl2ZUl0ZW1zIiwiZ3JvdXBDb2xvciIsImRpc2FibGVkR3JvdXAiLCJfczIiLCJjb2xvcnMiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJzcGFjaW5nIiwiZGlzcGxheSIsInBhZGRpbmdMZWZ0IiwieHMiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmRDb2xvciIsInB1cnBsZSIsInJvb3QiLCJncmF5IiwiZHJvcGRvd24iLCJwMTQiLCJzZW1pYm9sZCIsInJlZ3VsYXIiLCJib3JkZXIiLCJkcm9wZG93bkl0ZW1EaXNhYmxlZCIsInRpdGxlIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZ3JpZEdhcCIsInBhZGRpbmciLCJsaW5lSGVpZ2h0IiwiYm9yZGVyV2lkdGgiLCJjYXJldERvd25XcmFwcGVyIiwiY2FsbG91dCIsIm1heEhlaWdodCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZpbHRlcklucHV0UmVuZGVyLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL3NoYXJlZC9jb21wb25lbnRzL2ZpbHRlci9GaWx0ZXJJbnB1dFJlbmRlci50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJRHJvcGRvd25PcHRpb24sIElEcm9wZG93blN0eWxlcywgbWVyZ2VTdHlsZXMsIFRvb2x0aXBIb3N0IH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQywgbWVtbywgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEZpbHRlcklucHV0U2VhcmNoIH0gZnJvbSAnLidcclxuaW1wb3J0IHsgU2VhcmNoYWJsZURyb3Bkb3duIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MnXHJcbmltcG9ydCB7IGZpbHRlckdyb3VwQ29udGV4dCB9IGZyb20gJy4vZmlsdGVyR3JvdXBDb250ZXh0J1xyXG5pbXBvcnQgeyBJRmlsdGVyR3JvdXAsIElGaWx0ZXJHcm91cEl0ZW0gfSBmcm9tICcuL3R5cGVzJ1xyXG5cclxuaW50ZXJmYWNlIEZpbHRlcklucHV0UmVuZGVyUHJvcHMge1xyXG4gIGdyb3VwTmFtZTogc3RyaW5nXHJcbn1cclxuXHJcbmNvbnN0IE1BWF9TSVpFX1BFUl9HUk9VUCA9IDIwXHJcblxyXG5jb25zdCBGaWx0ZXJJbnB1dFJlbmRlcjogRkM8RmlsdGVySW5wdXRSZW5kZXJQcm9wcz4gPSAoeyBncm91cE5hbWUgfSkgPT4ge1xyXG4gIGNvbnN0IHsgaGFuZGxlSXRlbXNDaGFuZ2UsIGlzRGlzYWJsZWRBZGRJdGVtcywgZmlsdGVyR3JvdXBzIH0gPSB1c2VDb250ZXh0KGZpbHRlckdyb3VwQ29udGV4dClcclxuXHJcbiAgY29uc3QgZ3JvdXAgPSB1c2VNZW1vKCgpID0+XHJcbiAgICBmaWx0ZXJHcm91cHMuZmluZChncm91cCA9PiBncm91cC5maWx0ZXJHcm91cE5hbWUgPT09IGdyb3VwTmFtZSkgYXMgSUZpbHRlckdyb3VwXHJcbiAgLCBbZmlsdGVyR3JvdXBzXSlcclxuXHJcbiAgY29uc3QgZ3JvdXBJdGVtcyA9IGdyb3VwLml0ZW1zXHJcbiAgY29uc3QgaGFzQWN0aXZlRmlsdGVycyA9IHVzZU1lbW8oKCkgPT4gZ3JvdXBJdGVtcyA/IGdyb3VwSXRlbXMubGVuZ3RoID4gMCA6IGZhbHNlLCBbZ3JvdXBJdGVtc10pXHJcbiAgY29uc3Qgc2VsZWN0ZWRLZXlzID0gZ3JvdXBJdGVtcy5tYXAoaXRlbSA9PiBTdHJpbmcoaXRlbS5rZXkpKVxyXG5cclxuICBjb25zdCB7IGNpcmNsZVN0eWxlcywgZHJvcGRvd25TdHlsZXMgfSA9IHVzZUZpbHRlcklucHV0UmVuZGVyU3R5bGVzKFxyXG4gICAgaGFzQWN0aXZlRmlsdGVycyxcclxuICAgIGdyb3VwLmNvbG9yLFxyXG4gICAgaXNEaXNhYmxlZEFkZEl0ZW1zIHx8IGdyb3VwLmRpc2FibGVkIHx8IGZhbHNlLFxyXG4gIClcclxuXHJcbiAgY29uc3Qgb3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGdyb3VwLmRyb3Bkb3duT3B0aW9uc1xyXG4gICAgICA/IGdyb3VwLmRyb3Bkb3duT3B0aW9uc1xyXG4gICAgICAgIC5tYXAob3B0aW9uID0+ICh7IC4uLm9wdGlvbiwga2V5OiBTdHJpbmcob3B0aW9uLmtleSkgfSkpXHJcbiAgICAgIDogW11cclxuICB9LCBbXHJcbiAgICBncm91cC5kcm9wZG93bk9wdGlvbnMsXHJcbiAgXSlcclxuXHJcbiAgY29uc3QgW2hhc1NlbGVjdEFsbCwgc2V0SGFzU2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtpc0FsbFNlbGVjdGVkSW5TZWFyY2gsIHNldElzQWxsU2VsZWN0ZWRJblNlYXJjaF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBkaXNhYmxlZEFkZEZpbHRlciA9IGlzRGlzYWJsZWRBZGRJdGVtcyB8fCBncm91cC5pdGVtcy5sZW5ndGggPj0gTUFYX1NJWkVfUEVSX0dST1VQXHJcblxyXG4gIGNvbnN0IG9uVGl0bGVSZW5kZXJPcHRpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBjb25zdCBpdGVtc0NvdW50ID0gZ3JvdXAuaXRlbXMubGVuZ3RoXHJcblxyXG4gICAgaWYgKGhhc0FjdGl2ZUZpbHRlcnMpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAge2dyb3VwLmZpbHRlckdyb3VwTmFtZX1cclxuICAgICAgICAgIDxzcGFuPih7aXRlbXNDb3VudH0pPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjaXJjbGVTdHlsZXN9IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gPD57Z3JvdXAuZmlsdGVyR3JvdXBOYW1lfTwvPlxyXG4gIH0sIFtcclxuICAgIGdyb3VwLmZpbHRlckdyb3VwTmFtZSxcclxuICAgIGdyb3VwLml0ZW1zLFxyXG4gICAgaGFzQWN0aXZlRmlsdGVycyxcclxuICBdKVxyXG5cclxuICBjb25zdCB2ZXJpZnlIYXNTZWxlY3RBbGwgPSAob3B0aW9uczogSURyb3Bkb3duT3B0aW9uW10pID0+IHtcclxuICAgIGNvbnN0IHVuc2VsZWN0ZWRPcHRpb25zID0gb3B0aW9ucy5maWx0ZXIob3B0ID0+IGdyb3VwLml0ZW1zLmV2ZXJ5KGl0ZW0gPT4gaXRlbS5rZXkgIT09IG9wdC5rZXkpKVxyXG4gICAgY29uc3Qgc3VtVmlzaWJsZUFuZFNlbGVjdGVkT3B0aW9ucyA9IHVuc2VsZWN0ZWRPcHRpb25zLmxlbmd0aCArIGdyb3VwLml0ZW1zLmxlbmd0aFxyXG5cclxuICAgIHNldEhhc1NlbGVjdEFsbChzdW1WaXNpYmxlQW5kU2VsZWN0ZWRPcHRpb25zIDw9IE1BWF9TSVpFX1BFUl9HUk9VUClcclxuICB9XHJcblxyXG4gIGNvbnN0IHZlcmlmeUlzU2VsZWN0ZWRBbGwgPSAob3B0aW9uczogSURyb3Bkb3duT3B0aW9uW10pID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEtleXMgPT09IHVuZGVmaW5lZCkgcmV0dXJuXHJcblxyXG4gICAgc2V0SXNBbGxTZWxlY3RlZEluU2VhcmNoKFxyXG4gICAgICBvcHRpb25zXHJcbiAgICAgICAgLmV2ZXJ5KG9wdGlvbiA9PiBzZWxlY3RlZEtleXM/LnNvbWUoa2V5ID0+IGtleSA9PT0gU3RyaW5nKG9wdGlvbi5rZXkpKSksXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VJdGVtcyA9IChvcHRpb25zOiBJRHJvcGRvd25PcHRpb25bXSkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWRPcHRpb25zV2l0aG91dEhpZGRlbiA9IG9wdGlvbnMuZmlsdGVyKG9wdCA9PiAhb3B0LmhpZGRlbilcclxuXHJcbiAgICB2ZXJpZnlJc1NlbGVjdGVkQWxsKGZpbHRlcmVkT3B0aW9uc1dpdGhvdXRIaWRkZW4pXHJcbiAgICB2ZXJpZnlIYXNTZWxlY3RBbGwoZmlsdGVyZWRPcHRpb25zV2l0aG91dEhpZGRlbilcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZURyb3Bkb3duQ2hhbmdlID0gdXNlQ2FsbGJhY2soKF8/OiB1bmtub3duLCB2YWx1ZT86IElEcm9wZG93bk9wdGlvbikgPT4ge1xyXG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgIWdyb3VwKSByZXR1cm4gdW5kZWZpbmVkXHJcbiAgICBjb25zdCBvbGRHcm91cEl0ZW1zID0gZ3JvdXAuaXRlbXNcclxuICAgIGNvbnN0IG5ld0l0ZW06IElGaWx0ZXJHcm91cEl0ZW0gPSB7XHJcbiAgICAgIGtleTogU3RyaW5nKHZhbHVlLmtleSksXHJcbiAgICAgIHRleHQ6IHZhbHVlLnRleHQsXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbmV3R3JvdXBJdGVtcyA9IHZhbHVlLnNlbGVjdGVkXHJcbiAgICAgID8gWy4uLm9sZEdyb3VwSXRlbXMsIG5ld0l0ZW1dXHJcbiAgICAgIDogb2xkR3JvdXBJdGVtcy5maWx0ZXIoaXRlbSA9PiBpdGVtLmtleSAhPT0gdmFsdWUua2V5KVxyXG5cclxuICAgIGNvbnN0IG5ld0dyb3VwOiBJRmlsdGVyR3JvdXAgPSB7XHJcbiAgICAgIC4uLmdyb3VwLFxyXG4gICAgICBpdGVtczogbmV3R3JvdXBJdGVtcyxcclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVJdGVtc0NoYW5nZShuZXdHcm91cClcclxuICB9LCBbZ3JvdXBdKVxyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RBbGwgPSAoXz86IHVua25vd24sIGNoZWNrZWQ/OiBib29sZWFuLCBjaGVja2VkT3B0aW9ucz86IElEcm9wZG93bk9wdGlvbltdKSA9PiB7XHJcbiAgICBpZiAoY2hlY2tlZCA9PT0gdW5kZWZpbmVkIHx8IGNoZWNrZWRPcHRpb25zID09PSB1bmRlZmluZWQpIHJldHVyblxyXG4gICAgbGV0IHVwZGF0ZVZhbHVlcyA9IGdyb3VwLml0ZW1zXHJcblxyXG4gICAgY2hlY2tlZE9wdGlvbnMuZm9yRWFjaChvcHRpb24gPT4ge1xyXG4gICAgICBjb25zdCBkaXNhYmxlZE9wdGlvbiA9IG9wdGlvbi5oaWRkZW5cclxuICAgICAgY29uc3QgYWxyZWFkeUNoZWNrZWQgPSB1cGRhdGVWYWx1ZXMuc29tZShpdGVtID0+IGl0ZW0ua2V5ID09PSBvcHRpb24ua2V5KVxyXG5cclxuICAgICAgaWYgKGNoZWNrZWQpIHtcclxuICAgICAgICBpZiAoIWFscmVhZHlDaGVja2VkICYmICFkaXNhYmxlZE9wdGlvbikge1xyXG4gICAgICAgICAgdXBkYXRlVmFsdWVzID0gW1xyXG4gICAgICAgICAgICAuLi51cGRhdGVWYWx1ZXMsIHsga2V5OiBTdHJpbmcob3B0aW9uLmtleSksIHRleHQ6IG9wdGlvbi50ZXh0IH0sXHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoIWNoZWNrZWQpIHtcclxuICAgICAgICBpZiAoIWRpc2FibGVkT3B0aW9uKSB7XHJcbiAgICAgICAgICB1cGRhdGVWYWx1ZXMgPSB1cGRhdGVWYWx1ZXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5rZXkgIT09IFN0cmluZyhvcHRpb24ua2V5KSlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgY29uc3QgbmV3R3JvdXA6IElGaWx0ZXJHcm91cCA9IHtcclxuICAgICAgLi4uZ3JvdXAsXHJcbiAgICAgIGl0ZW1zOiB1cGRhdGVWYWx1ZXMsXHJcbiAgICB9XHJcblxyXG4gICAgaGFuZGxlSXRlbXNDaGFuZ2UobmV3R3JvdXApXHJcbiAgfVxyXG5cclxuICBpZiAoZ3JvdXAucXVlcnlNb2RlID09PSAnc2VhcmNoYWJsZURyb3Bkb3duJykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPFRvb2x0aXBIb3N0XHJcbiAgICAgICAgY29udGVudD17XHJcbiAgICAgICAgICBkaXNhYmxlZEFkZEZpbHRlclxyXG4gICAgICAgICAgICA/ICdNw6F4aW1vIGRlIGl0ZW5zIGZpbHRyYWRvcyBhdGluZ2lkbydcclxuICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICA8U2VhcmNoYWJsZURyb3Bkb3duXHJcbiAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWRBZGRGaWx0ZXIgfHwgZ3JvdXAuZGlzYWJsZWR9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17Z3JvdXAuZmlsdGVyR3JvdXBOYW1lfVxyXG4gICAgICAgICAgb25SZW5kZXJUaXRsZT17b25UaXRsZVJlbmRlck9wdGlvbn1cclxuICAgICAgICAgIG9wdGlvbnM9e29wdGlvbnN9XHJcbiAgICAgICAgICB0aXRsZT17Z3JvdXAuZmlsdGVyR3JvdXBOYW1lfVxyXG4gICAgICAgICAgc2VsZWN0ZWRLZXlzPXtzZWxlY3RlZEtleXN9XHJcbiAgICAgICAgICBhdXRvRHJvcGRvd25XaWR0aFxyXG4gICAgICAgICAgaGFzU2VsZWN0QWxsXHJcbiAgICAgICAgICBkaXNhYmxlZFNlbGVjdEFsbEhpbnQ9J07Do28gw6kgcG9zc8OtdmVsIHNlbGVjaW9uYXIgdG9kb3MsIGjDoSBvcMOnw7VlcyBkZW1haXMuJ1xyXG4gICAgICAgICAgZGlzYWJsZWRTZWxlY3RBbGw9eyFoYXNTZWxlY3RBbGx9XHJcbiAgICAgICAgICBvblNlbGVjdEFsbD17aGFuZGxlU2VsZWN0QWxsfVxyXG4gICAgICAgICAgbXVsdGlTZWxlY3RcclxuICAgICAgICAgIGhhc1NlYXJjaFxyXG4gICAgICAgICAgY2hlY2tlZD17aXNBbGxTZWxlY3RlZEluU2VhcmNofVxyXG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURyb3Bkb3duQ2hhbmdlfVxyXG4gICAgICAgICAgb25DaGFuZ2VJdGVtcz17aGFuZGxlQ2hhbmdlSXRlbXN9XHJcbiAgICAgICAgICBzdHlsZXM9e2Ryb3Bkb3duU3R5bGVzfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvVG9vbHRpcEhvc3Q+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEZpbHRlcklucHV0U2VhcmNoXHJcbiAgICAgIGdyb3VwPXtncm91cH1cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VGaWx0ZXJJbnB1dFJlbmRlclN0eWxlcyA9IChcclxuICBoYXNBY3RpdmVJdGVtczogYm9vbGVhbixcclxuICBncm91cENvbG9yOiBzdHJpbmcgfCB1bmRlZmluZWQsXHJcbiAgZGlzYWJsZWRHcm91cDogYm9vbGVhbixcclxuKSA9PiB7XHJcbiAgY29uc3QgeyBjb2xvcnMsIGZvbnRTaXplLCBmb250V2VpZ2h0LCBzcGFjaW5nIH0gPSB1c2VUaGVtZSgpXHJcblxyXG4gIGNvbnN0IGNpcmNsZVN0eWxlcyA9IG1lcmdlU3R5bGVzKHtcclxuICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxyXG4gICAgcGFkZGluZ0xlZnQ6IHNwYWNpbmcueHMsXHJcbiAgICB3aWR0aDogOCxcclxuICAgIGhlaWdodDogOCxcclxuICAgIGJvcmRlclJhZGl1czogJzUwJScsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IGdyb3VwQ29sb3IgfHwgY29sb3JzLnB1cnBsZVs1MDBdLFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IGRyb3Bkb3duU3R5bGVzOiBQYXJ0aWFsPElEcm9wZG93blN0eWxlcz4gPSB7XHJcbiAgICByb290OiB7XHJcbiAgICAgIGhlaWdodDogMzIsXHJcbiAgICAgICc6aG92ZXInOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuZ3JheVsyMDBdLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICBkcm9wZG93bjoge1xyXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgZm9udFNpemU6IGZvbnRTaXplLnAxNCxcclxuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgIGZvbnRXZWlnaHQ6IGhhc0FjdGl2ZUl0ZW1zID8gZm9udFdlaWdodC5zZW1pYm9sZCA6IGZvbnRXZWlnaHQucmVndWxhcixcclxuICAgICAgJzpob3ZlciAubXMtRHJvcGRvd24tdGl0bGUnOiB7XHJcbiAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuZ3JheVsyMDBdLFxyXG4gICAgICB9LFxyXG4gICAgICAnOmFjdGl2ZSAubXMtRHJvcGRvd24tdGl0bGUnOiB7XHJcbiAgICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgIH0sXHJcbiAgICAgICc6Zm9jdXMgLm1zLURyb3Bkb3duLXRpdGxlJzoge1xyXG4gICAgICAgIGNvbG9yOiBjb2xvcnMuZ3JheVs2MDBdLFxyXG4gICAgICB9LFxyXG4gICAgICAnOmZvY3VzOjphZnRlcic6IHtcclxuICAgICAgICBib3JkZXI6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICAgIH0sXHJcbiAgICAgICcuaXMtZGlzYWJsZWQgLm1zLURyb3Bkb3duLXRpdGxlJzoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3JzLmdyYXlbMjAwXSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBkcm9wZG93bkl0ZW1EaXNhYmxlZDoge1xyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5ncmF5WzIwMF0sXHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgZGlzcGxheTogJ2lubGluZS1mbGV4JyxcclxuICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXHJcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcclxuICAgICAgZ3JpZEdhcDogc3BhY2luZy54cyxcclxuICAgICAgcGFkZGluZzogJzBweCAyNnB4IDBweCAwcHgnLFxyXG4gICAgICBsaW5lSGVpZ2h0OiAnYXV0bycsXHJcbiAgICAgIGJvcmRlcldpZHRoOiAwLFxyXG4gICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgY29sb3I6IGNvbG9ycy5ncmF5WzYwMF0sXHJcbiAgICB9LFxyXG4gICAgY2FyZXREb3duV3JhcHBlcjoge1xyXG4gICAgICBkaXNwbGF5OiAnaW5saW5lLWZsZXgnLFxyXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgaGVpZ2h0OiAnMTAwJScsXHJcbiAgICB9LFxyXG4gICAgY2FsbG91dDoge1xyXG4gICAgICBtYXhIZWlnaHQ6IDI5MCxcclxuICAgICAgZGlzcGxheTogZGlzYWJsZWRHcm91cCA/ICdub25lJyA6ICdmbGV4JyxcclxuICAgIH0sXHJcbiAgfVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgZHJvcGRvd25TdHlsZXMsXHJcbiAgICBjaXJjbGVTdHlsZXMsXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBtZW1vKEZpbHRlcklucHV0UmVuZGVyKVxyXG4iXX0=