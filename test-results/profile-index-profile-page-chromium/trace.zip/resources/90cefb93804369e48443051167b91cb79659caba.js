import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/filter/FilterGroupTagsDisplay.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"];
import { FlexRow, Tag, TooltipHost } from "/src/shared/components/index.ts?t=1701096626433";
import { filterGroupContext } from "/src/shared/components/filter/filterGroupContext.ts";
import { useTheme } from "/node_modules/.vite/deps/styled-components.js?v=9f90a7ff";
const MAX_TAGS_PER_GROUP = 5;
const FilterGroupTagsDisplay = ({
  groups
}) => {
  _s();
  const theme = useTheme();
  const {
    handleRemoveItem
  } = useContext(filterGroupContext);
  return /* @__PURE__ */ jsxDEV(FlexRow, { verticalAlign: "center", gap: 12, styles: {
    minHeight: "48px",
    width: "100%",
    padding: "12px",
    backgroundColor: theme.colors.blue[30],
    border: `1px solid ${theme.colors.blue[150]}`,
    borderRadius: "4px"
  }, children: groups.map((group) => group.items.map((item, i) => {
    if (i < MAX_TAGS_PER_GROUP) {
      return /* @__PURE__ */ jsxDEV(Tag, { text: item.text, color: theme.colors.purple[800], backgroundColor: group.color ? group.color : theme.colors.purple[200], onRemove: group.disabled ? void 0 : () => handleRemoveItem(group, item.key) }, item.key, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx",
        lineNumber: 29,
        columnNumber: 16
      }, this);
    } else if (i === MAX_TAGS_PER_GROUP) {
      const lastingItemsCount = group.items.length - MAX_TAGS_PER_GROUP;
      const lastingItemsTagText = `mais ${lastingItemsCount}...`;
      const lastingItemsText = group.items.map((item2, i2) => {
        if (i2 > MAX_TAGS_PER_GROUP)
          return item2.text;
        return void 0;
      }).filter((item2) => item2).join(", ");
      return /* @__PURE__ */ jsxDEV(TooltipHost, { content: lastingItemsText, children: /* @__PURE__ */ jsxDEV(Tag, { text: lastingItemsTagText, color: theme.colors.purple[800], backgroundColor: group.color ? group.color : theme.colors.purple[200] }, void 0, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx",
        lineNumber: 38,
        columnNumber: 17
      }, this) }, `resting-items-${group.filterGroupName}`, false, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx",
        lineNumber: 37,
        columnNumber: 16
      }, this);
    }
    return null;
  })) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(FilterGroupTagsDisplay, "FLYauQtn2CMpAzC26wbe+c7l3U0=", false, function() {
  return [useTheme];
});
_c = FilterGroupTagsDisplay;
export default FilterGroupTagsDisplay;
var _c;
$RefreshReg$(_c, "FilterGroupTagsDisplay");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/filter/FilterGroupTagsDisplay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NjOzs7Ozs7Ozs7Ozs7Ozs7O0FBbENkLFNBQWFBLGtCQUFrQjtBQUUvQixTQUFTQyxTQUFTQyxLQUFLQyxtQkFBbUI7QUFDMUMsU0FBU0MsMEJBQTBCO0FBRW5DLFNBQVNDLGdCQUFnQjtBQU16QixNQUFNQyxxQkFBcUI7QUFFM0IsTUFBTUMseUJBQ0pBLENBQUM7QUFBQSxFQUFFQztBQUFPLE1BQU07QUFBQUMsS0FBQTtBQUNkLFFBQU1DLFFBQVFMLFNBQVM7QUFDdkIsUUFBTTtBQUFBLElBQUVNO0FBQUFBLEVBQWlCLElBQUlYLFdBQVdJLGtCQUFrQjtBQUUxRCxTQUNFLHVCQUFDLFdBQ0MsZUFBYyxVQUNkLEtBQUssSUFDTCxRQUFRO0FBQUEsSUFDTlEsV0FBVztBQUFBLElBQ1hDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsaUJBQWlCTCxNQUFNTSxPQUFPQyxLQUFLLEVBQUU7QUFBQSxJQUNyQ0MsUUFBUyxhQUFZUixNQUFNTSxPQUFPQyxLQUFLLEdBQUc7QUFBQSxJQUMxQ0UsY0FBYztBQUFBLEVBQ2hCLEdBRUNYLGlCQUFPWSxJQUFJQyxXQUFTQSxNQUFNQyxNQUFNRixJQUFJLENBQUNHLE1BQU1DLE1BQU07QUFDaEQsUUFBSUEsSUFBSWxCLG9CQUFvQjtBQUMxQixhQUNFLHVCQUFDLE9BRUMsTUFBTWlCLEtBQUtFLE1BQ1gsT0FBT2YsTUFBTU0sT0FBT1UsT0FBTyxHQUFHLEdBQzlCLGlCQUFpQkwsTUFBTU0sUUFBUU4sTUFBTU0sUUFBUWpCLE1BQU1NLE9BQU9VLE9BQU8sR0FBRyxHQUNwRSxVQUFVTCxNQUFNTyxXQUFXQyxTQUFZLE1BQU1sQixpQkFBaUJVLE9BQU9FLEtBQUtPLEdBQUcsS0FKeEVQLEtBQUtPLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtpRjtBQUFBLElBR3JGLFdBQVdOLE1BQU1sQixvQkFBb0I7QUFDbkMsWUFBTXlCLG9CQUFvQlYsTUFBTUMsTUFBTVUsU0FBUzFCO0FBQy9DLFlBQU0yQixzQkFBdUIsUUFBT0Y7QUFDcEMsWUFBTUcsbUJBQW1CYixNQUFNQyxNQUFNRixJQUFJLENBQUNHLE9BQU1DLE9BQU07QUFDcEQsWUFBSUEsS0FBSWxCO0FBQW9CLGlCQUFPaUIsTUFBS0U7QUFDeEMsZUFBT0k7QUFBQUEsTUFDVCxDQUFDLEVBQUVNLE9BQU9aLFdBQVFBLEtBQUksRUFBRWEsS0FBSyxJQUFJO0FBQ2pDLGFBQ0UsdUJBQUMsZUFBMkQsU0FBU0Ysa0JBQ25FLGlDQUFDLE9BQ0MsTUFBTUQscUJBQ04sT0FBT3ZCLE1BQU1NLE9BQU9VLE9BQU8sR0FBRyxHQUM5QixpQkFBaUJMLE1BQU1NLFFBQVFOLE1BQU1NLFFBQVFqQixNQUFNTSxPQUFPVSxPQUFPLEdBQUcsS0FIdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUd3RSxLQUp2RCxpQkFBZ0JMLE1BQU1nQixtQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsSUFFSjtBQUNBLFdBQU87QUFBQSxFQUNULENBQUMsQ0FBQyxLQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMENBO0FBRUo7QUFBQzVCLEdBbERHRix3QkFBdUQ7QUFBQSxVQUUzQ0YsUUFBUTtBQUFBO0FBQUFpQyxLQUZwQi9CO0FBb0ROLGVBQWVBO0FBQXNCLElBQUErQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ29udGV4dCIsIkZsZXhSb3ciLCJUYWciLCJUb29sdGlwSG9zdCIsImZpbHRlckdyb3VwQ29udGV4dCIsInVzZVRoZW1lIiwiTUFYX1RBR1NfUEVSX0dST1VQIiwiRmlsdGVyR3JvdXBUYWdzRGlzcGxheSIsImdyb3VwcyIsIl9zIiwidGhlbWUiLCJoYW5kbGVSZW1vdmVJdGVtIiwibWluSGVpZ2h0Iiwid2lkdGgiLCJwYWRkaW5nIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3JzIiwiYmx1ZSIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsIm1hcCIsImdyb3VwIiwiaXRlbXMiLCJpdGVtIiwiaSIsInRleHQiLCJwdXJwbGUiLCJjb2xvciIsImRpc2FibGVkIiwidW5kZWZpbmVkIiwia2V5IiwibGFzdGluZ0l0ZW1zQ291bnQiLCJsZW5ndGgiLCJsYXN0aW5nSXRlbXNUYWdUZXh0IiwibGFzdGluZ0l0ZW1zVGV4dCIsImZpbHRlciIsImpvaW4iLCJmaWx0ZXJHcm91cE5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZpbHRlckdyb3VwVGFnc0Rpc3BsYXkudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvc2hhcmVkL2NvbXBvbmVudHMvZmlsdGVyL0ZpbHRlckdyb3VwVGFnc0Rpc3BsYXkudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCdcclxuXHJcbmltcG9ydCB7IEZsZXhSb3csIFRhZywgVG9vbHRpcEhvc3QgfSBmcm9tICcuLidcclxuaW1wb3J0IHsgZmlsdGVyR3JvdXBDb250ZXh0IH0gZnJvbSAnLi9maWx0ZXJHcm91cENvbnRleHQnXHJcbmltcG9ydCB7IElGaWx0ZXJHcm91cCB9IGZyb20gJy4vdHlwZXMnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5pbnRlcmZhY2UgRmlsdGVyR3JvdXBUYWdzRGlzcGxheVByb3BzIHtcclxuICBncm91cHM6IElGaWx0ZXJHcm91cFtdLFxyXG59XHJcblxyXG5jb25zdCBNQVhfVEFHU19QRVJfR1JPVVAgPSA1XHJcblxyXG5jb25zdCBGaWx0ZXJHcm91cFRhZ3NEaXNwbGF5OiBGQzxGaWx0ZXJHcm91cFRhZ3NEaXNwbGF5UHJvcHM+ID1cclxuICAoeyBncm91cHMgfSkgPT4ge1xyXG4gICAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpXHJcbiAgICBjb25zdCB7IGhhbmRsZVJlbW92ZUl0ZW0gfSA9IHVzZUNvbnRleHQoZmlsdGVyR3JvdXBDb250ZXh0KVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxGbGV4Um93XHJcbiAgICAgICAgdmVydGljYWxBbGlnbj0nY2VudGVyJ1xyXG4gICAgICAgIGdhcD17MTJ9XHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICBtaW5IZWlnaHQ6ICc0OHB4JyxcclxuICAgICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICBwYWRkaW5nOiAnMTJweCcsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbG9ycy5ibHVlWzMwXSxcclxuICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke3RoZW1lLmNvbG9ycy5ibHVlWzE1MF19YCxcclxuICAgICAgICAgIGJvcmRlclJhZGl1czogJzRweCcsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtncm91cHMubWFwKGdyb3VwID0+IGdyb3VwLml0ZW1zLm1hcCgoaXRlbSwgaSkgPT4ge1xyXG4gICAgICAgICAgaWYgKGkgPCBNQVhfVEFHU19QRVJfR1JPVVApIHtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8VGFnXHJcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxyXG4gICAgICAgICAgICAgICAgdGV4dD17aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgY29sb3I9e3RoZW1lLmNvbG9ycy5wdXJwbGVbODAwXX1cclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcj17Z3JvdXAuY29sb3IgPyBncm91cC5jb2xvciA6IHRoZW1lLmNvbG9ycy5wdXJwbGVbMjAwXX1cclxuICAgICAgICAgICAgICAgIG9uUmVtb3ZlPXtncm91cC5kaXNhYmxlZCA/IHVuZGVmaW5lZCA6ICgpID0+IGhhbmRsZVJlbW92ZUl0ZW0oZ3JvdXAsIGl0ZW0ua2V5KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9IGVsc2UgaWYgKGkgPT09IE1BWF9UQUdTX1BFUl9HUk9VUCkge1xyXG4gICAgICAgICAgICBjb25zdCBsYXN0aW5nSXRlbXNDb3VudCA9IGdyb3VwLml0ZW1zLmxlbmd0aCAtIE1BWF9UQUdTX1BFUl9HUk9VUFxyXG4gICAgICAgICAgICBjb25zdCBsYXN0aW5nSXRlbXNUYWdUZXh0ID0gYG1haXMgJHtsYXN0aW5nSXRlbXNDb3VudH0uLi5gXHJcbiAgICAgICAgICAgIGNvbnN0IGxhc3RpbmdJdGVtc1RleHQgPSBncm91cC5pdGVtcy5tYXAoKGl0ZW0sIGkpID0+IHtcclxuICAgICAgICAgICAgICBpZiAoaSA+IE1BWF9UQUdTX1BFUl9HUk9VUCkgcmV0dXJuIGl0ZW0udGV4dFxyXG4gICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfSkuZmlsdGVyKGl0ZW0gPT4gaXRlbSkuam9pbignLCAnKVxyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxUb29sdGlwSG9zdCBrZXk9e2ByZXN0aW5nLWl0ZW1zLSR7Z3JvdXAuZmlsdGVyR3JvdXBOYW1lfWB9IGNvbnRlbnQ9e2xhc3RpbmdJdGVtc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICB0ZXh0PXtsYXN0aW5nSXRlbXNUYWdUZXh0fVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj17dGhlbWUuY29sb3JzLnB1cnBsZVs4MDBdfVxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I9e2dyb3VwLmNvbG9yID8gZ3JvdXAuY29sb3IgOiB0aGVtZS5jb2xvcnMucHVycGxlWzIwMF19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvVG9vbHRpcEhvc3Q+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiBudWxsXHJcbiAgICAgICAgfSkpfVxyXG4gICAgICA8L0ZsZXhSb3c+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyR3JvdXBUYWdzRGlzcGxheVxyXG4iXX0=