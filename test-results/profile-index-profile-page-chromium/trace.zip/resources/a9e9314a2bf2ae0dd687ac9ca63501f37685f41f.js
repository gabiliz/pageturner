import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditFlowRoleName.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditFlowRoleName.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { auditFlowQueryService } from "/src/modules/audit/audits/services/index.ts";
const AuditFlowRoleName = ({
  id
}) => {
  _s();
  const {
    data: flowList
  } = auditFlowQueryService.useFindAllPaginated();
  const role = flowList?.value?.filter((item) => item.id === id);
  return /* @__PURE__ */ jsxDEV("span", { children: role?.[0]?.descricao ?? "Finalizar" }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditFlowRoleName.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(AuditFlowRoleName, "gRjMa3033L83qmXJYJovYXXQs9s=", false, function() {
  return [auditFlowQueryService.useFindAllPaginated];
});
_c = AuditFlowRoleName;
export default AuditFlowRoleName;
var _c;
$RefreshReg$(_c, "AuditFlowRoleName");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditFlowRoleName.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSVCxTQUFTQSw2QkFBNkI7QUFFdEMsTUFBTUMsb0JBQXNDQSxDQUFDO0FBQUEsRUFBRUM7QUFBRyxNQUFNO0FBQUFDLEtBQUE7QUFDdEQsUUFBTTtBQUFBLElBQ0pDLE1BQU1DO0FBQUFBLEVBQ1IsSUFBSUwsc0JBQXNCTSxvQkFBb0I7QUFFOUMsUUFBTUMsT0FBT0YsVUFBVUcsT0FBT0MsT0FBT0MsVUFBUUEsS0FBS1IsT0FBT0EsRUFBRTtBQUMzRCxTQUFPLHVCQUFDLFVBQU1LLGlCQUFPLENBQUMsR0FBR0ksYUFBYSxlQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJDO0FBQ3BEO0FBQUNSLEdBUEtGLG1CQUFtQztBQUFBLFVBR25DRCxzQkFBc0JNLG1CQUFtQjtBQUFBO0FBQUFNLEtBSHpDWDtBQVNOLGVBQWVBO0FBQWlCLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJhdWRpdEZsb3dRdWVyeVNlcnZpY2UiLCJBdWRpdEZsb3dSb2xlTmFtZSIsImlkIiwiX3MiLCJkYXRhIiwiZmxvd0xpc3QiLCJ1c2VGaW5kQWxsUGFnaW5hdGVkIiwicm9sZSIsInZhbHVlIiwiZmlsdGVyIiwiaXRlbSIsImRlc2NyaWNhbyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXVkaXRGbG93Um9sZU5hbWUudHN4Il0sImZpbGUiOiIvVXNlcnMvZ2FiaWxpei9Eb2N1bWVudHMvYXVkaXRvcl9mcm9udGVuZC9zcmMvbW9kdWxlcy9hdWRpdC9hdWRpdHMvY29tcG9uZW50cy9BdWRpdEZsb3dSb2xlTmFtZS50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGQyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgYXVkaXRGbG93UXVlcnlTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMnXG5cbmNvbnN0IEF1ZGl0Rmxvd1JvbGVOYW1lOiBGQzx7aWQ6IHN0cmluZ30+ID0gKHsgaWQgfSkgPT4ge1xuICBjb25zdCB7XG4gICAgZGF0YTogZmxvd0xpc3QsXG4gIH0gPSBhdWRpdEZsb3dRdWVyeVNlcnZpY2UudXNlRmluZEFsbFBhZ2luYXRlZCgpXG5cbiAgY29uc3Qgcm9sZSA9IGZsb3dMaXN0Py52YWx1ZT8uZmlsdGVyKGl0ZW0gPT4gaXRlbS5pZCA9PT0gaWQpXG4gIHJldHVybiA8c3Bhbj57cm9sZT8uWzBdPy5kZXNjcmljYW8gPz8gJ0ZpbmFsaXphcid9PC9zcGFuPlxufVxuXG5leHBvcnQgZGVmYXVsdCBBdWRpdEZsb3dSb2xlTmFtZVxuIl19