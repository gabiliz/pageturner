import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/components/notifications/components/NotificationsDeadlineDropdown.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsDeadlineDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { DeadlineEnum } from "/src/shared/enums/DeadlineEnum.ts";
import { DeadlineRecord } from "/src/shared/record/index.ts";
import { ComboBox } from "/src/shared/components/comboBox/index.ts";
const deadlineList = [DeadlineEnum.all, DeadlineEnum.oneMonth, DeadlineEnum.twoWeeks, DeadlineEnum.oneWeek, DeadlineEnum.oneDay];
const NotificationsDeadlineDropdown = (props) => {
  _s();
  const {
    label,
    disabled = false
  } = props;
  const dropdownStyles = useDropdownStyles();
  const options = useMemo(() => deadlineList.map((key) => ({
    key,
    text: DeadlineRecord[key]
  })) ?? [], []);
  return /* @__PURE__ */ jsxDEV(ComboBox, { label, options, defaultSelectedKey: DeadlineEnum.all, disabled, styles: dropdownStyles, calloutProps: {
    calloutMinWidth: 80
  }, ...props }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsDeadlineDropdown.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(NotificationsDeadlineDropdown, "WTiYLzdu/4+7yXOD+YNNhtRZJTw=", false, function() {
  return [useDropdownStyles];
});
_c = NotificationsDeadlineDropdown;
const useDropdownStyles = () => {
  const dropdown = {
    root: {
      maxWidth: 180
    }
  };
  return dropdown;
};
export default NotificationsDeadlineDropdown;
var _c;
$RefreshReg$(_c, "NotificationsDeadlineDropdown");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/shared/components/notifications/components/NotificationsDeadlineDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NJOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkNKLFNBQWFBLGVBQWU7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFPekIsTUFBTUMsZUFBK0IsQ0FDbkNILGFBQWFJLEtBQ2JKLGFBQWFLLFVBQ2JMLGFBQWFNLFVBQ2JOLGFBQWFPLFNBQ2JQLGFBQWFRLE1BQU07QUFHckIsTUFBTUMsZ0NBQTREQyxXQUFVO0FBQUFDLEtBQUE7QUFDMUUsUUFBTTtBQUFBLElBQ0pDO0FBQUFBLElBQ0FDLFdBQVc7QUFBQSxFQUNiLElBQUlIO0FBRUosUUFBTUksaUJBQWlCQyxrQkFBa0I7QUFFekMsUUFBTUMsVUFBVWpCLFFBQ2QsTUFBTUksYUFBYWMsSUFBSUMsVUFBUTtBQUFBLElBQzdCQTtBQUFBQSxJQUNBQyxNQUFNbEIsZUFBZWlCLEdBQUc7QUFBQSxFQUMxQixFQUFFLEtBQUssSUFDUCxFQUNGO0FBRUEsU0FDRSx1QkFBQyxZQUNDLE9BQ0EsU0FDQSxvQkFBb0JsQixhQUFhSSxLQUNqQyxVQUNBLFFBQVFVLGdCQUNSLGNBQWM7QUFBQSxJQUNaTSxpQkFBaUI7QUFBQSxFQUNuQixHQUNBLEdBQUlWLFNBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNZO0FBR2hCO0FBQUNDLEdBN0JLRiwrQkFBd0Q7QUFBQSxVQU1yQ00saUJBQWlCO0FBQUE7QUFBQU0sS0FOcENaO0FBK0JOLE1BQU1NLG9CQUFvQkEsTUFBTTtBQUM5QixRQUFNTyxXQUFxQztBQUFBLElBQ3pDQyxNQUFNO0FBQUEsTUFDSkMsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBRUEsU0FBT0Y7QUFDVDtBQUVBLGVBQWViO0FBQTZCLElBQUFZO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwiRGVhZGxpbmVFbnVtIiwiRGVhZGxpbmVSZWNvcmQiLCJDb21ib0JveCIsImRlYWRsaW5lTGlzdCIsImFsbCIsIm9uZU1vbnRoIiwidHdvV2Vla3MiLCJvbmVXZWVrIiwib25lRGF5IiwiTm90aWZpY2F0aW9uc0RlYWRsaW5lRHJvcGRvd24iLCJwcm9wcyIsIl9zIiwibGFiZWwiLCJkaXNhYmxlZCIsImRyb3Bkb3duU3R5bGVzIiwidXNlRHJvcGRvd25TdHlsZXMiLCJvcHRpb25zIiwibWFwIiwia2V5IiwidGV4dCIsImNhbGxvdXRNaW5XaWR0aCIsIl9jIiwiZHJvcGRvd24iLCJyb290IiwibWF4V2lkdGgiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zRGVhZGxpbmVEcm9wZG93bi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9zaGFyZWQvY29tcG9uZW50cy9ub3RpZmljYXRpb25zL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uc0RlYWRsaW5lRHJvcGRvd24udHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSUNvbWJvQm94UHJvcHMsIElDb21ib0JveFN0eWxlcywgSURyb3Bkb3duT3B0aW9uIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xyXG5pbXBvcnQgeyBGQywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBEZWFkbGluZUVudW0gfSBmcm9tICcuLi8uLi8uLi9lbnVtcy9EZWFkbGluZUVudW0nXHJcbmltcG9ydCB7IERlYWRsaW5lUmVjb3JkIH0gZnJvbSAnLi4vLi4vLi4vcmVjb3JkJ1xyXG5pbXBvcnQgeyBDb21ib0JveCB9IGZyb20gJy4uLy4uL2NvbWJvQm94J1xyXG5cclxuaW50ZXJmYWNlIERlYWRsaW5lRHJvcGRvd25Qcm9wcyBleHRlbmRzIFBhcnRpYWw8SUNvbWJvQm94UHJvcHM+IHtcclxuICBsYWJlbD86IHN0cmluZ1xyXG4gIGRpc2FibGVkPzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBkZWFkbGluZUxpc3Q6IERlYWRsaW5lRW51bVtdID0gW1xyXG4gIERlYWRsaW5lRW51bS5hbGwsXHJcbiAgRGVhZGxpbmVFbnVtLm9uZU1vbnRoLFxyXG4gIERlYWRsaW5lRW51bS50d29XZWVrcyxcclxuICBEZWFkbGluZUVudW0ub25lV2VlayxcclxuICBEZWFkbGluZUVudW0ub25lRGF5LFxyXG5dXHJcblxyXG5jb25zdCBOb3RpZmljYXRpb25zRGVhZGxpbmVEcm9wZG93bjogRkM8RGVhZGxpbmVEcm9wZG93blByb3BzPiA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIGxhYmVsLFxyXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcclxuICB9ID0gcHJvcHNcclxuXHJcbiAgY29uc3QgZHJvcGRvd25TdHlsZXMgPSB1c2VEcm9wZG93blN0eWxlcygpXHJcblxyXG4gIGNvbnN0IG9wdGlvbnMgPSB1c2VNZW1vPElEcm9wZG93bk9wdGlvbltdPihcclxuICAgICgpID0+IGRlYWRsaW5lTGlzdC5tYXAoa2V5ID0+ICh7XHJcbiAgICAgIGtleToga2V5LFxyXG4gICAgICB0ZXh0OiBEZWFkbGluZVJlY29yZFtrZXldLFxyXG4gICAgfSkpID8/IFtdLFxyXG4gICAgW10sXHJcbiAgKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPENvbWJvQm94XHJcbiAgICAgIGxhYmVsPXtsYWJlbH1cclxuICAgICAgb3B0aW9ucz17b3B0aW9uc31cclxuICAgICAgZGVmYXVsdFNlbGVjdGVkS2V5PXtEZWFkbGluZUVudW0uYWxsfVxyXG4gICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XHJcbiAgICAgIHN0eWxlcz17ZHJvcGRvd25TdHlsZXN9XHJcbiAgICAgIGNhbGxvdXRQcm9wcz17e1xyXG4gICAgICAgIGNhbGxvdXRNaW5XaWR0aDogODAsXHJcbiAgICAgIH19XHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgIC8+XHJcbiAgKVxyXG59XHJcblxyXG5jb25zdCB1c2VEcm9wZG93blN0eWxlcyA9ICgpID0+IHtcclxuICBjb25zdCBkcm9wZG93bjogUGFydGlhbDxJQ29tYm9Cb3hTdHlsZXM+ID0ge1xyXG4gICAgcm9vdDoge1xyXG4gICAgICBtYXhXaWR0aDogMTgwLFxyXG4gICAgfSxcclxuICB9XHJcblxyXG4gIHJldHVybiBkcm9wZG93blxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25zRGVhZGxpbmVEcm9wZG93blxyXG4iXX0=