import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/admin/contracts/components/ContractConfigurationBreadCrumb.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationBreadCrumb.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"];
import { BreadCrumb } from "/src/shared/components/index.ts?t=1701096626433";
import { formatProposalNumber } from "/src/shared/utils/index.ts";
import { ContractConfigurationContext } from "/src/modules/admin/contracts/context/ContractConfigurationPageContext.ts";
const ContractConfigurationBreadCrumb = () => {
  _s();
  const {
    client,
    contract
  } = useContext(ContractConfigurationContext);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: client && contract && /* @__PURE__ */ jsxDEV(BreadCrumb, { items: [{
    label: "Clientes",
    url: "/admin/clients"
  }, {
    label: client.nomeFantasia
  }, {
    label: "Contratos",
    url: `/admin/clients/${client.id}/contracts`
  }, {
    label: `${formatProposalNumber(contract.numeroProposta)}`
  }] }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationBreadCrumb.tsx",
    lineNumber: 13,
    columnNumber: 28
  }, this) }, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationBreadCrumb.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(ContractConfigurationBreadCrumb, "5OoiMOoeove6z9TE38FEqobv/qM=");
_c = ContractConfigurationBreadCrumb;
export default ContractConfigurationBreadCrumb;
var _c;
$RefreshReg$(_c, "ContractConfigurationBreadCrumb");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/admin/contracts/components/ContractConfigurationBreadCrumb.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVMsbUJBRUgsY0FGRzs7Ozs7Ozs7Ozs7Ozs7OztBQVJULFNBQWFBLGtCQUFrQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLG9DQUFvQztBQUU3QyxNQUFNQyxrQ0FBc0NBLE1BQU07QUFBQUMsS0FBQTtBQUNoRCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBUUM7QUFBQUEsRUFBUyxJQUFJUCxXQUFXRyw0QkFBNEI7QUFFcEUsU0FBTyxtQ0FDSkcsb0JBQVVDLFlBQ1QsdUJBQUMsY0FBVyxPQUFPLENBQ2pCO0FBQUEsSUFDRUMsT0FBTztBQUFBLElBQ1BDLEtBQUs7QUFBQSxFQUNQLEdBQ0E7QUFBQSxJQUNFRCxPQUFPRixPQUFPSTtBQUFBQSxFQUNoQixHQUNBO0FBQUEsSUFDRUYsT0FBTztBQUFBLElBQ1BDLEtBQU0sa0JBQWlCSCxPQUFPSztBQUFBQSxFQUNoQyxHQUNBO0FBQUEsSUFDRUgsT0FBUSxHQUFFTixxQkFBcUJLLFNBQVNLLGNBQWM7QUFBQSxFQUN4RCxDQUFDLEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVFLEtBakJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQlA7QUFDRjtBQUFDUCxHQXZCS0QsaUNBQW1DO0FBQUFTLEtBQW5DVDtBQXlCTixlQUFlQTtBQUErQixJQUFBUztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ29udGV4dCIsIkJyZWFkQ3J1bWIiLCJmb3JtYXRQcm9wb3NhbE51bWJlciIsIkNvbnRyYWN0Q29uZmlndXJhdGlvbkNvbnRleHQiLCJDb250cmFjdENvbmZpZ3VyYXRpb25CcmVhZENydW1iIiwiX3MiLCJjbGllbnQiLCJjb250cmFjdCIsImxhYmVsIiwidXJsIiwibm9tZUZhbnRhc2lhIiwiaWQiLCJudW1lcm9Qcm9wb3N0YSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJhY3RDb25maWd1cmF0aW9uQnJlYWRDcnVtYi50c3giXSwiZmlsZSI6Ii9Vc2Vycy9nYWJpbGl6L0RvY3VtZW50cy9hdWRpdG9yX2Zyb250ZW5kL3NyYy9tb2R1bGVzL2FkbWluL2NvbnRyYWN0cy9jb21wb25lbnRzL0NvbnRyYWN0Q29uZmlndXJhdGlvbkJyZWFkQ3J1bWIudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEJyZWFkQ3J1bWIgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IGZvcm1hdFByb3Bvc2FsTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2hhcmVkL3V0aWxzJ1xuaW1wb3J0IHsgQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvQ29udHJhY3RDb25maWd1cmF0aW9uUGFnZUNvbnRleHQnXG5cbmNvbnN0IENvbnRyYWN0Q29uZmlndXJhdGlvbkJyZWFkQ3J1bWI6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNsaWVudCwgY29udHJhY3QgfSA9IHVzZUNvbnRleHQoQ29udHJhY3RDb25maWd1cmF0aW9uQ29udGV4dClcblxuICByZXR1cm4gPD5cbiAgICB7Y2xpZW50ICYmIGNvbnRyYWN0ICYmIChcbiAgICAgIDxCcmVhZENydW1iIGl0ZW1zPXtbXG4gICAgICAgIHtcbiAgICAgICAgICBsYWJlbDogJ0NsaWVudGVzJyxcbiAgICAgICAgICB1cmw6ICcvYWRtaW4vY2xpZW50cycsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBsYWJlbDogY2xpZW50Lm5vbWVGYW50YXNpYSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiAnQ29udHJhdG9zJyxcbiAgICAgICAgICB1cmw6IGAvYWRtaW4vY2xpZW50cy8ke2NsaWVudC5pZH0vY29udHJhY3RzYCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiBgJHtmb3JtYXRQcm9wb3NhbE51bWJlcihjb250cmFjdC5udW1lcm9Qcm9wb3N0YSl9YCxcbiAgICAgICAgfSxcbiAgICAgIF19IC8+XG4gICAgKX1cbiAgPC8+XG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbnRyYWN0Q29uZmlndXJhdGlvbkJyZWFkQ3J1bWJcbiJdfQ==