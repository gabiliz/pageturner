import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/audit/audits/components/AuditProcessing.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditProcessing.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f90a7ff"; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Outlet, useParams } from "/node_modules/.vite/deps/react-router.js?v=9f90a7ff";
import { auditQueryService, auditService } from "/src/modules/audit/audits/services/index.ts";
import { MessageContext } from "/src/shared/context/MessageContext.ts";
import { MessageBarType } from "/node_modules/.vite/deps/@fluentui_react.js?v=9f90a7ff";
import { AuditApprovalSituationEnum } from "/src/modules/audit/audits/enums/index.ts";
import { Link } from "/src/shared/components/index.ts?t=1701096626433";
import { useNotifications } from "/src/shared/store/notifications/notifications.ts";
const AuditProcessing = () => {
  _s();
  const {
    auditId
  } = useParams();
  const {
    showNotification
  } = useNotifications();
  const {
    showMessage,
    hideMessage
  } = useContext(MessageContext);
  const {
    data: audit
  } = auditQueryService.useFindOne(auditId);
  async function handleReprocess() {
    try {
      await auditService.reprocessAudit(auditId);
      auditQueryService.invalidateQueries();
      hideMessage();
    } catch (err) {
      showNotification({
        message: "Erro ao reprocessar projeto!",
        type: MessageBarType.error
      });
    }
  }
  function showWarningMessage() {
    showMessage({
      children: "O projeto ainda está sendo preparado. Algumas páginas podem estar indisponíveis.",
      messageBarType: MessageBarType.warning,
      messageBarIconProps: {
        iconName: "HourGlass"
      }
    });
  }
  function showErrorMessage() {
    showMessage({
      children: /* @__PURE__ */ jsxDEV("span", { children: [
        "Aconteceu um erro na preparação do projeto. Entre em contato com o suporte para solucionar.",
        " ",
        /* @__PURE__ */ jsxDEV(Link, { underline: true, onClick: handleReprocess, children: "Clique aqui para reprocessar o projeto." }, void 0, false, {
          fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditProcessing.tsx",
          lineNumber: 50,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditProcessing.tsx",
        lineNumber: 48,
        columnNumber: 17
      }, this),
      messageBarType: MessageBarType.error,
      messageBarIconProps: {
        iconName: "Error"
      }
    });
  }
  useEffect(() => {
    switch (audit?.situacaoAprovacao) {
      case AuditApprovalSituationEnum.PENDING:
      case AuditApprovalSituationEnum.IN_PROGRESS:
        showWarningMessage();
        break;
      case AuditApprovalSituationEnum.ERROR:
        showErrorMessage();
        break;
    }
    return () => {
      hideMessage();
    };
  }, [audit]);
  return /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditProcessing.tsx",
    lineNumber: 74,
    columnNumber: 10
  }, this);
};
_s(AuditProcessing, "WI6/V+0OKY89zuc+L9cqI++OoDg=", false, function() {
  return [useParams, useNotifications, auditQueryService.useFindOne];
});
_c = AuditProcessing;
export default AuditProcessing;
var _c;
$RefreshReg$(_c, "AuditProcessing");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/gabiliz/Documents/auditor_frontend/src/modules/audit/audits/components/AuditProcessing.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNVOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0NWLFNBQWFBLFlBQVlDLGlCQUFpQjtBQUMxQyxTQUFTQyxRQUFRQyxpQkFBaUI7QUFDbEMsU0FBU0MsbUJBQW1CQyxvQkFBb0I7QUFDaEQsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQ0FBa0M7QUFDM0MsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyx3QkFBd0I7QUFFakMsTUFBTUMsa0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVEsSUFBSVYsVUFBVTtBQUU5QixRQUFNO0FBQUEsSUFBRVc7QUFBQUEsRUFBaUIsSUFBSUosaUJBQWlCO0FBQzlDLFFBQU07QUFBQSxJQUFFSztBQUFBQSxJQUFhQztBQUFBQSxFQUFZLElBQUloQixXQUFXTSxjQUFjO0FBRTlELFFBQU07QUFBQSxJQUFFVyxNQUFNQztBQUFBQSxFQUFNLElBQUlkLGtCQUFrQmUsV0FBV04sT0FBaUI7QUFFdEUsaUJBQWVPLGtCQUFtQjtBQUNoQyxRQUFJO0FBQ0YsWUFBTWYsYUFBYWdCLGVBQWVSLE9BQWlCO0FBQ25EVCx3QkFBa0JrQixrQkFBa0I7QUFDcENOLGtCQUFZO0FBQUEsSUFDZCxTQUFTTyxLQUFQO0FBQ0FULHVCQUFpQjtBQUFBLFFBQ2ZVLFNBQVM7QUFBQSxRQUNUQyxNQUFNbEIsZUFBZW1CO0FBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFdBQVNDLHFCQUFzQjtBQUM3QlosZ0JBQVk7QUFBQSxNQUNWYSxVQUFVO0FBQUEsTUFDVkMsZ0JBQWdCdEIsZUFBZXVCO0FBQUFBLE1BQy9CQyxxQkFBcUI7QUFBQSxRQUNuQkMsVUFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBU0MsbUJBQW9CO0FBQzNCbEIsZ0JBQVk7QUFBQSxNQUNWYSxVQUNFLHVCQUFDLFVBQUk7QUFBQTtBQUFBLFFBQ3lGO0FBQUEsUUFDNUYsdUJBQUMsUUFDQyxXQUFTLE1BQ1QsU0FBU1IsaUJBQWdCLHVEQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUZTLGdCQUFnQnRCLGVBQWVtQjtBQUFBQSxNQUMvQksscUJBQXFCO0FBQUEsUUFDbkJDLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBL0IsWUFBVSxNQUFNO0FBQ2QsWUFBUWlCLE9BQU9nQixtQkFBaUI7QUFBQSxNQUM5QixLQUFLMUIsMkJBQTJCMkI7QUFBQUEsTUFDaEMsS0FBSzNCLDJCQUEyQjRCO0FBQzlCVCwyQkFBbUI7QUFDbkI7QUFBQSxNQUNGLEtBQUtuQiwyQkFBMkI2QjtBQUM5QkoseUJBQWlCO0FBQ2pCO0FBQUEsSUFDSjtBQUNBLFdBQU8sTUFBTTtBQUNYakIsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLENBQUNFLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU87QUFFWDtBQUFDTixHQXJFS0QsaUJBQW1CO0FBQUEsVUFDSFIsV0FFU08sa0JBR0xOLGtCQUFrQmUsVUFBVTtBQUFBO0FBQUFtQixLQU5oRDNCO0FBdUVOLGVBQWVBO0FBQWUsSUFBQTJCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwiT3V0bGV0IiwidXNlUGFyYW1zIiwiYXVkaXRRdWVyeVNlcnZpY2UiLCJhdWRpdFNlcnZpY2UiLCJNZXNzYWdlQ29udGV4dCIsIk1lc3NhZ2VCYXJUeXBlIiwiQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0iLCJMaW5rIiwidXNlTm90aWZpY2F0aW9ucyIsIkF1ZGl0UHJvY2Vzc2luZyIsIl9zIiwiYXVkaXRJZCIsInNob3dOb3RpZmljYXRpb24iLCJzaG93TWVzc2FnZSIsImhpZGVNZXNzYWdlIiwiZGF0YSIsImF1ZGl0IiwidXNlRmluZE9uZSIsImhhbmRsZVJlcHJvY2VzcyIsInJlcHJvY2Vzc0F1ZGl0IiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJlcnIiLCJtZXNzYWdlIiwidHlwZSIsImVycm9yIiwic2hvd1dhcm5pbmdNZXNzYWdlIiwiY2hpbGRyZW4iLCJtZXNzYWdlQmFyVHlwZSIsIndhcm5pbmciLCJtZXNzYWdlQmFySWNvblByb3BzIiwiaWNvbk5hbWUiLCJzaG93RXJyb3JNZXNzYWdlIiwic2l0dWFjYW9BcHJvdmFjYW8iLCJQRU5ESU5HIiwiSU5fUFJPR1JFU1MiLCJFUlJPUiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXVkaXRQcm9jZXNzaW5nLnRzeCJdLCJmaWxlIjoiL1VzZXJzL2dhYmlsaXovRG9jdW1lbnRzL2F1ZGl0b3JfZnJvbnRlbmQvc3JjL21vZHVsZXMvYXVkaXQvYXVkaXRzL2NvbXBvbmVudHMvQXVkaXRQcm9jZXNzaW5nLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IE91dGxldCwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgYXVkaXRRdWVyeVNlcnZpY2UsIGF1ZGl0U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzJ1xuaW1wb3J0IHsgTWVzc2FnZUNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29udGV4dC9NZXNzYWdlQ29udGV4dCdcbmltcG9ydCB7IE1lc3NhZ2VCYXJUeXBlIH0gZnJvbSAnQGZsdWVudHVpL3JlYWN0J1xuaW1wb3J0IHsgQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0gfSBmcm9tICcuLi9lbnVtcydcbmltcG9ydCB7IExpbmsgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvY29tcG9uZW50cydcbmltcG9ydCB7IHVzZU5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi8uLi8uLi8uLi9zaGFyZWQvc3RvcmUvbm90aWZpY2F0aW9ucy9ub3RpZmljYXRpb25zJ1xuXG5jb25zdCBBdWRpdFByb2Nlc3Npbmc6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IGF1ZGl0SWQgfSA9IHVzZVBhcmFtcygpXG5cbiAgY29uc3QgeyBzaG93Tm90aWZpY2F0aW9uIH0gPSB1c2VOb3RpZmljYXRpb25zKClcbiAgY29uc3QgeyBzaG93TWVzc2FnZSwgaGlkZU1lc3NhZ2UgfSA9IHVzZUNvbnRleHQoTWVzc2FnZUNvbnRleHQpXG5cbiAgY29uc3QgeyBkYXRhOiBhdWRpdCB9ID0gYXVkaXRRdWVyeVNlcnZpY2UudXNlRmluZE9uZShhdWRpdElkIGFzIHN0cmluZylcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVSZXByb2Nlc3MgKCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhdWRpdFNlcnZpY2UucmVwcm9jZXNzQXVkaXQoYXVkaXRJZCBhcyBzdHJpbmcpXG4gICAgICBhdWRpdFF1ZXJ5U2VydmljZS5pbnZhbGlkYXRlUXVlcmllcygpXG4gICAgICBoaWRlTWVzc2FnZSgpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzaG93Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgbWVzc2FnZTogJ0Vycm8gYW8gcmVwcm9jZXNzYXIgcHJvamV0byEnLFxuICAgICAgICB0eXBlOiBNZXNzYWdlQmFyVHlwZS5lcnJvcixcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gc2hvd1dhcm5pbmdNZXNzYWdlICgpIHtcbiAgICBzaG93TWVzc2FnZSh7XG4gICAgICBjaGlsZHJlbjogJ08gcHJvamV0byBhaW5kYSBlc3TDoSBzZW5kbyBwcmVwYXJhZG8uIEFsZ3VtYXMgcMOhZ2luYXMgcG9kZW0gZXN0YXIgaW5kaXNwb27DrXZlaXMuJyxcbiAgICAgIG1lc3NhZ2VCYXJUeXBlOiBNZXNzYWdlQmFyVHlwZS53YXJuaW5nLFxuICAgICAgbWVzc2FnZUJhckljb25Qcm9wczoge1xuICAgICAgICBpY29uTmFtZTogJ0hvdXJHbGFzcycsXG4gICAgICB9LFxuICAgIH0pXG4gIH1cblxuICBmdW5jdGlvbiBzaG93RXJyb3JNZXNzYWdlICgpIHtcbiAgICBzaG93TWVzc2FnZSh7XG4gICAgICBjaGlsZHJlbjogKFxuICAgICAgICA8c3Bhbj5cbiAgICAgICAgICBBY29udGVjZXUgdW0gZXJybyBuYSBwcmVwYXJhw6fDo28gZG8gcHJvamV0by4gRW50cmUgZW0gY29udGF0byBjb20gbyBzdXBvcnRlIHBhcmEgc29sdWNpb25hci57JyAnfVxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB1bmRlcmxpbmVcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlcHJvY2Vzc31cbiAgICAgICAgICA+XG4gICAgICAgICAgICBDbGlxdWUgYXF1aSBwYXJhIHJlcHJvY2Vzc2FyIG8gcHJvamV0by5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICksXG4gICAgICBtZXNzYWdlQmFyVHlwZTogTWVzc2FnZUJhclR5cGUuZXJyb3IsXG4gICAgICBtZXNzYWdlQmFySWNvblByb3BzOiB7XG4gICAgICAgIGljb25OYW1lOiAnRXJyb3InLFxuICAgICAgfSxcbiAgICB9KVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzd2l0Y2ggKGF1ZGl0Py5zaXR1YWNhb0Fwcm92YWNhbykge1xuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5QRU5ESU5HOlxuICAgICAgY2FzZSBBdWRpdEFwcHJvdmFsU2l0dWF0aW9uRW51bS5JTl9QUk9HUkVTUzpcbiAgICAgICAgc2hvd1dhcm5pbmdNZXNzYWdlKClcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgQXVkaXRBcHByb3ZhbFNpdHVhdGlvbkVudW0uRVJST1I6XG4gICAgICAgIHNob3dFcnJvck1lc3NhZ2UoKVxuICAgICAgICBicmVha1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaGlkZU1lc3NhZ2UoKVxuICAgIH1cbiAgfSwgW2F1ZGl0XSlcblxuICByZXR1cm4gKFxuICAgIDxPdXRsZXQgLz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBdWRpdFByb2Nlc3NpbmdcbiJdfQ==